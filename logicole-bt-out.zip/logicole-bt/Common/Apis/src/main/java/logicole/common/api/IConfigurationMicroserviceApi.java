package logicole.common.api;

import logicole.common.datamodels.Configuration;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IConfigurationMicroserviceApi extends IMicroserviceApi {

    @GET
    @Path("/getAllConfigurations")
    List<Configuration> getAllConfigurations();

    @POST
    @Path("/addUpdateConfiguration")
    Configuration addUpdateConfiguration(Configuration configuration);

    @GET
    @Path("/getConfiguration")
    Configuration getConfiguration(@QueryParam("id") String id);

    @GET
    @Path("/getConfigurationByName")
    Configuration getConfigurationByName(@QueryParam("name") String name);


}
