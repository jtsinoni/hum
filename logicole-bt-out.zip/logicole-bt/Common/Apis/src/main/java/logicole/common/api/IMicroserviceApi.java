package logicole.common.api;

import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.VersionInformation;
import logicole.common.datamodels.businessevent.BusinessEventHistory;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.system.InitializationRoutineRef;
import logicole.common.datamodels.system.InitializationRoutineResult;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.List;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public interface IMicroserviceApi {

    @GET
    @Path("/checkHealth")
    HealthCheckResult checkHealth();

    @GET
    @Path("/getVersionInformation")
    VersionInformation getVersionInformation() throws IOException;

    @POST
    @Path("/executeInitializationRoutine")
    InitializationRoutineResult executeInitializationRoutine(InitializationRoutineRef initializationRoutineRef);

    @POST
    @Path("/processDataReferenceUpdate")
    void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate);

    @GET
    @Path("/searchBusinessEvents")
    List<BusinessEventHistory> searchBusinessEventHistory(
            @QueryParam("searchValues") String searchString);

    @GET
    @Path("/findByReferenceObjectId")
    List<BusinessEventHistory> findByReferenceObjectId(@QueryParam("id") String id);

    @GET
    @Path("/getBusinessEventById")
    BusinessEventHistory getBusinessEventById(@QueryParam("id") String id);

    @GET
    @Path("/getSearchEngine")
    ESearchEngine getSearchEngine();

    @POST
    @Path("/getTransactionHistorySearchResults")
    SearchResult<BusinessEventHistory> getTransactionHistorySearchResults(SearchInput searchInput);

}
