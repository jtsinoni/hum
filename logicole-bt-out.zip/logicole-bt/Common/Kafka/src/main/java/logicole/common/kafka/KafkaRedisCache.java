package logicole.common.kafka;


import logicole.common.cache.LogicoleCache;

public class KafkaRedisCache extends LogicoleCache<String> {
}
