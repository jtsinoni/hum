package logicole.common.kafka;

import logicole.common.general.logging.ILogger;
import logicole.common.general.logging.LogManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public enum EKafkaTopic {
    LogiColeTestTopic("LogiColeTestTopic", 10, 2, ETopicSerde.String, ETopicSerde.String),
    ;

    private static ILogger logger = LogManager.developerLogger;

    public final String name;
    public final int numberOfPartitions;
    public final int numberOfReplicas;
    public final ETopicSerde keySerde;
    public final ETopicSerde valueSerde;

    private final Map<String, ConsumerGroup> consumerGroupMap = new HashMap<>();

    public static EKafkaTopic getByName(String topicName) {
        return Arrays.stream(values()).filter(t -> t.name.equals(topicName)).findFirst().orElse(null);
    }

    EKafkaTopic(String name, int numberOfPartitions, int numberOfReplicas, ETopicSerde keySerde, ETopicSerde valueSerde) {
        this.name = name;
        this.numberOfPartitions = numberOfPartitions;
        this.numberOfReplicas = numberOfReplicas;
        this.keySerde = keySerde;
        this.valueSerde = valueSerde;
    }

    void addConsumerGrouptoMap(ConsumerGroup consumerGroup){
        consumerGroupMap.put(consumerGroup.name, consumerGroup);
    }

    void removeConsumerGroupFromMap(String consumerGroupName){
        consumerGroupMap.remove(consumerGroupName);
    }

    public List<ConsumerGroup> getConsumerGroups() {
        return new ArrayList<ConsumerGroup>(consumerGroupMap.values());
    }

    public ConsumerGroup getConsumerGroup(String name) {
        return consumerGroupMap.get(name);
    }
}

