package logicole.common.kafka;

class TopicSerde {
    public final Class deserializer;
    public final Class serializer;

    public TopicSerde(Class serializer, Class deserializer) {
        this.serializer = serializer;
        this.deserializer = deserializer;
    }
}
