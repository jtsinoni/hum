package logicole.common.kafka;

import com.fasterxml.jackson.annotation.JsonIgnore;
import logicole.common.general.logging.ILogger;
import logicole.common.general.logging.LogManager;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;

import java.time.Duration;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;

class LogiColeConsumer {

    public ILogger logger = LogManager.developerLogger;

    @JsonIgnore
    private KafkaConsumer kafkaConsumer;
    public String name;
    public ConsumerGroup consumerGroup;

    @JsonIgnore
    private Map<TopicPartition, OffsetAndMetadata> currentOffsets = new HashMap<>();

    private EStatus status = EStatus.Created;

    public LogiColeConsumer(ConsumerGroup consumerGroup, KafkaServerClient kafkaServerClient, String name) {
        this.kafkaConsumer = kafkaServerClient.createConsumer(
                consumerGroup.kafkaTopic.keySerde.deserializerClassName,
                consumerGroup.kafkaTopic.valueSerde.deserializerClassName,
                consumerGroup.name,
                name);
        this.name = name;
        this.consumerGroup = consumerGroup;

        if (kafkaConsumer.subscription().isEmpty()) kafkaConsumer.subscribe(List.of(consumerGroup.kafkaTopic.name));
    }

    public void start(ExecutorService executorService) {
        CompletableFuture.runAsync(() -> startAsync(), executorService)
                .whenComplete((result, ex) -> {
                    if (ex != null) {
                        logger.error("LogiCole consumer failed", ex);
                    } else {
                        logger.debug("LogiCole consumer completed successfully");
                    }
                });
    }

    public void startAsync() {
        if (status == EStatus.Running) return;
        if (status == EStatus.ShutdownRequested)
            throw new RuntimeException(String.format("Consumer %s cannot be started.  It has not yet completely shut down", this));

        status = EStatus.Running;
        try {
            while (status != EStatus.ShutdownRequested) {
                try {
                    while (true) {
                        ConsumerRecords<String, String> records = kafkaConsumer.poll(Duration.ofMillis(consumerGroup.durationInMilliseconds));

                        for (TopicPartition topicPartition : records.partitions()) {
                            List<ConsumerRecord<String, String>> partitionRecords = records.records(topicPartition);
                            for (ConsumerRecord<String, String> partitionRecord : partitionRecords) {
                                try {
                                    consumerGroup.consumerFunction.accept(partitionRecord);
                                } catch (Exception e) {
                                    consumerGroup.kafkaClient.sendFailure(consumerGroup.kafkaTopic, partitionRecord, e);
                                    logger.error("Error processing a Kafka Queue message.", e);
                                }
                            }
                            long lastOffset = partitionRecords.get(partitionRecords.size() - 1).offset();
                            kafkaConsumer.commitSync(Collections.singletonMap(topicPartition, new OffsetAndMetadata(lastOffset + 1)));
                        }
                    }
                } catch (WakeupException e) {
                    if (status == EStatus.PauseRequested) {
                        status = EStatus.Paused;
                        kafkaConsumer.pause(kafkaConsumer.assignment());

                    } else if (status == EStatus.ResumeRequested) {
                        status = EStatus.Running;
                        kafkaConsumer.resume(kafkaConsumer.assignment());
                    } else {
                        throw e;
                    }
                }
            }

        } catch (WakeupException e) {
            logger.error(e);
        } finally {
            logger.debug("LogiColeConsumer poll loop is closing.");
            kafkaConsumer.close();
            status = EStatus.ShutdownComplete;
        }
    }

    public void pause() {
        status = EStatus.PauseRequested;
        kafkaConsumer.wakeup();
    }

    public void resume() {
        status = EStatus.ResumeRequested;
        kafkaConsumer.wakeup();
    }

    public void close() {
        status = EStatus.ShutdownRequested;
        kafkaConsumer.wakeup();
    }

    public EStatus getStatus() {
        return status;
    }

    public enum EStatus {
        Created,
        Running,
        PauseRequested,
        Paused,
        ResumeRequested,
        ShutdownRequested,
        ShutdownComplete
    }
}
