package logicole.common.kafka;

import logicole.common.general.configuration.ConfigurationManager;
import logicole.common.general.logging.ILogger;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.CreateTopicsResult;
import org.apache.kafka.clients.admin.DeleteTopicsResult;
import org.apache.kafka.clients.admin.DescribeClusterResult;
import org.apache.kafka.clients.admin.ListTopicsOptions;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.admin.TopicDescription;
import org.apache.kafka.clients.admin.TopicListing;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.Node;
import org.apache.kafka.common.config.SslConfigs;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;
import java.util.stream.Collectors;


@ApplicationScoped
class KafkaServerClient {
    @Inject
    ConfigurationManager configurationManager;

    @Inject
    ILogger logger;

    private final Properties properties = new Properties();

    @PostConstruct
    private void postConstruct() {
        try {
            Object kafkaBootstrapServers = configurationManager.getKafkaBootstrapServers();
            logger.debug("Kafka Bootstrap Servers: {}", kafkaBootstrapServers);

            properties.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaBootstrapServers);
            properties.put(AdminClientConfig.RETRIES_CONFIG, "3");

            String kafkaSecurityProtocol = configurationManager.getKafkaSecurityProtocol();

            if (kafkaSecurityProtocol.equals("ssl")) {

                //configure the following three settings for SSL Encryption
                properties.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, "SSL");
                properties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, configurationManager.getTrustStorePath());
                properties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, configurationManager.getTrustStorePassword());
                properties.put(SslConfigs.SSL_PROTOCOL_CONFIG, "TLSv1.2");
                properties.put(SslConfigs.SSL_ENABLED_PROTOCOLS_CONFIG, "TLSv1.2");

                properties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, configurationManager.getKeyStorePath());
                properties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, configurationManager.getKeyStorePassword());
                properties.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, configurationManager.getKeyStorePassword());
            }
        } catch (Exception e) {
            logger.error("postConstruct in KafkaServerClient failed", e);
            throw e;
        }
    }

    public void createTopic(String topicName, int numPartitions, int replicationFactor) {
        withAdminClient(adminClient -> {
            CreateTopicsResult topics = adminClient.createTopics(List.of(new NewTopic(topicName, numPartitions, (short) replicationFactor)));
            try {
                topics.all().get(5, TimeUnit.SECONDS);
            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                throw new RuntimeException(String.format("Could not create Kafka topic %s", topicName), e);
            }
            return null;
        });
    }

    public void deleteTopic(String topicName) {
        withAdminClient(adminClient -> {

            DeleteTopicsResult deleteTopicsResult = adminClient.deleteTopics(List.of(topicName));
            try {
                deleteTopicsResult.all().get();
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException(String.format("Could not delete Kafka topic %s", topicName), e);
            }
            return null;
        });
    }

    public List<KafkaServerTopic> getKafkaServerTopics() {
        return withAdminClient(adminClient -> {
            try {
                ListTopicsOptions listTopicsOptions = new ListTopicsOptions();
                listTopicsOptions.listInternal(false);

                Collection<TopicListing> topicListings = adminClient.listTopics(listTopicsOptions).listings().get();

                Map<String, TopicDescription> topicDescriptionMap = adminClient.describeTopics(
                        topicListings.stream().map(tl -> tl.name()).collect(Collectors.toList())
                ).all().get();

                List<KafkaServerTopic> kafkaServerTopics = topicDescriptionMap.values().stream()
                        .map(t -> new KafkaServerTopic(t))
                        .collect(Collectors.toList());

                return kafkaServerTopics;
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException("Could not list Kafka topics", e);
            }
        });
    }

    public KafkaProducer getPublisher(String keySerializerClassName, String valueSerializerClassName) {
        Properties publisherProperties = new Properties();
        publisherProperties.putAll(properties);
        publisherProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, keySerializerClassName);
        publisherProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, valueSerializerClassName);

        return new KafkaProducer<>(publisherProperties);
    }

    public KafkaConsumer createConsumer(String keyDeserializerClassName, String valueDeserializerClassName, String groupId, String clientId) {
        Properties consumerProperties = new Properties();
        consumerProperties.putAll(properties);
        consumerProperties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, keyDeserializerClassName);
        consumerProperties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, valueDeserializerClassName);
        consumerProperties.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        consumerProperties.put(ConsumerConfig.CLIENT_ID_CONFIG, clientId);
        consumerProperties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");

        return new KafkaConsumer(consumerProperties);
    }

    public List<KafkaServerConsumerGroup> getKafkaServerConsumerGroups() {
        return withAdminClient(adminClient -> {
            try {
                List<KafkaServerConsumerGroup> kafkaServerConsumerGroups = adminClient.listConsumerGroups().all().get()
                        .stream()
                        .map(c -> new KafkaServerConsumerGroup(c))
                        .collect(Collectors.toList());

                return kafkaServerConsumerGroups;
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException("Could not retrieve Kafka consumer group listing", e);
            }
        });
    }

    public List<KafkaServerNode> getKafkaBrokers() {
        return withAdminClient(adminClient -> {
            DescribeClusterResult describeClusterResult = adminClient.describeCluster();
            try {
                Collection<Node> nodes = describeClusterResult.nodes().get();

                List<KafkaServerNode> kafkaServerNodes = nodes.stream()
                        .map(n -> new KafkaServerNode(n))
                        .collect(Collectors.toList());

                return kafkaServerNodes;
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException("Could not retrieve Kafka Broker list", e);
            }
        });
    }

    public void deleteConsumerGroup(String groupId) {
        withAdminClient(adminClient -> {
            try {
                adminClient.deleteConsumerGroups(Collections.singleton(groupId)).all().get();
            } catch (InterruptedException | ExecutionException e) {
                throw new RuntimeException("Could not delete consumer group", e);
            }
            return null;
        });
    }

    private <T> T withAdminClient(Function<AdminClient, T> consumer) {
        try (AdminClient adminClient = createKafkaAdminClient()) {
            return consumer.apply(adminClient);
        }
    }

    private AdminClient createKafkaAdminClient() {
        return AdminClient.create(properties);
    }
}
