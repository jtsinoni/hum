package logicole.common.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;

public class KafkaConsumerRecordException {
    public ConsumerRecord<String, String> consumerRecord;
    public Exception exception;

    public KafkaConsumerRecordException(){}

    public KafkaConsumerRecordException(ConsumerRecord<String, String> consumerRecord, Exception exception) {
        this.consumerRecord = consumerRecord;
        this.exception = exception;
    }

    @Override
    public String toString() {
        return "KafkaConsumerRecordException{" +
                "consumerRecord=" + consumerRecord.toString() +
                ", exception=" + exception.toString() +
                '}';
    }
}
