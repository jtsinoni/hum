package logicole.common.kafka;

import org.apache.kafka.clients.admin.ConsumerGroupListing;
import org.apache.kafka.common.ConsumerGroupState;

import java.util.Optional;

public class KafkaServerConsumerGroup {
    private String groupId;
    private boolean isSimpleConsumerGroup;
    private Optional<ConsumerGroupState> state;

    public KafkaServerConsumerGroup(){}

    public KafkaServerConsumerGroup(ConsumerGroupListing consumerGroupListing) {
        this.groupId = consumerGroupListing.groupId();
        this.isSimpleConsumerGroup = consumerGroupListing.isSimpleConsumerGroup();
        this.state = consumerGroupListing.state();
    }
}
