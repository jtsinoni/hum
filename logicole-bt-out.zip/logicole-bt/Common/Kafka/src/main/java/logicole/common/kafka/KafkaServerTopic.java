package logicole.common.kafka;

import org.apache.kafka.clients.admin.TopicDescription;

import java.util.List;
import java.util.stream.Collectors;

public class KafkaServerTopic {
    public String name;
    public boolean internal;
    public List<KafkaServerTopicPartitionInfo> partitions;

    public KafkaServerTopic(){}

    public KafkaServerTopic(TopicDescription topicDescription) {
        this.name = topicDescription.name();
        this.internal = topicDescription.isInternal();
        this.partitions = topicDescription.partitions()
                .stream()
                .map(t->new KafkaServerTopicPartitionInfo(t))
                .collect(Collectors.toList());
    }
}
