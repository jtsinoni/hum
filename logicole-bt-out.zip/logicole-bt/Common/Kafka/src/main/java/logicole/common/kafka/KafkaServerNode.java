package logicole.common.kafka;

import org.apache.kafka.common.Node;

public class KafkaServerNode {
    public static final KafkaServerNode NO_NODE = new KafkaServerNode(-1, "", -1);
    public int id;
    public String idString;
    public String host;
    public int port;
    public String rack;

    public KafkaServerNode(){}

    private KafkaServerNode(int id, String host, int port){
        this.id = id;
        this.idString = String.valueOf(id);
        this.host = host;
        this.port = port;
        this.rack = "";
    }

    public KafkaServerNode(Node node) {
        this.id = node.id();
        this.idString = node.idString();
        this.host = node.host();
        this.port = node.port();
        this.rack = node.rack();
    }
}
