package logicole.common.kafka;

import logicole.common.general.logging.ILogger;

import logicole.common.general.threading.LogiColeExecutorService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.time.Duration;
import java.util.*;
import java.util.function.Consumer;

@ApplicationScoped
public class KafkaClient {
    @Inject
    KafkaServerClient kafkaServerClient;

    @Inject
    LogiColeExecutorService logiColeExecutorService;

    @Inject
    ILogger logger;

    private KafkaProducer kafkaProducer;

    @PostConstruct
    private void postConstruct(){
        ensureAllEKafkaTopicsExist();
    }

    // ************************
    // Kafka Server Activity
    // ************************

    public List<KafkaServerNode> getKafkaBrokers(){
        return kafkaServerClient.getKafkaBrokers();
    }

    public List<KafkaServerTopic> getKafkaServerTopics(){
        return kafkaServerClient.getKafkaServerTopics();
    }

    public List<KafkaServerConsumerGroup> getKafkaServerConsumerGroups(){
        return kafkaServerClient.getKafkaServerConsumerGroups();
    }

    public void createKafkaServerTopic(String topicName, int numPartitions, int replicationFactor) {
        kafkaServerClient.createTopic(topicName, numPartitions, replicationFactor);
    }

    public void deleteKafkaServerTopic(String topicName) {
        kafkaServerClient.deleteTopic(topicName);
    }

    public void deleteKafkaServerConsumerGroup(String groupId) {
        kafkaServerClient.deleteConsumerGroup(groupId);
    }

    // ************************
    // Kafka Topic Activity
    // ************************

    public static EKafkaTopic getTopicByName(String topicName) {
        return EKafkaTopic.getByName(topicName);
    }

    public ConsumerGroup createConsumerGroup(EKafkaTopic kafkaTopic, String name, int numberOfConsumers, Duration duration, boolean autoStart, Consumer<ConsumerRecord> consumerFunction) {
        ConsumerGroup consumerGroup = new ConsumerGroup(this, kafkaTopic, name, numberOfConsumers, duration, autoStart, consumerFunction);
        consumerGroup.createConsumers(kafkaServerClient);

        kafkaTopic.addConsumerGrouptoMap(consumerGroup);
        if (consumerGroup.autoStart) {
            consumerGroup.startPolling(logiColeExecutorService.getExecutorService());
        }
        return consumerGroup;
    }

    public void deleteConsumerGroup(EKafkaTopic kafkaTopic, String name) {
        ConsumerGroup consumerGroup = kafkaTopic.getConsumerGroup(name);
        consumerGroup.deleteConsumers();
        kafkaServerClient.deleteConsumerGroup(name);
        kafkaTopic.removeConsumerGroupFromMap(name);
    }

    public void deleteAllConsumerGroups(EKafkaTopic kafkaTopic){
        kafkaTopic.getConsumerGroups().forEach(cg-> deleteConsumerGroup(kafkaTopic, cg.name));
    }

    public void startPolling(EKafkaTopic kafkaTopic) {
        kafkaTopic.getConsumerGroups().forEach(cg -> cg.startPolling(logiColeExecutorService.getExecutorService()));
    }

    public void stopPolling(EKafkaTopic kafkaTopic) {
        kafkaTopic.getConsumerGroups().forEach(cg -> cg.stopPolling());
    }

    public KafkaProducer getPublisher(EKafkaTopic kafkaTopic) {
        if (kafkaProducer == null) {
            kafkaProducer = kafkaServerClient.getPublisher(kafkaTopic.keySerde.serializerClassName, kafkaTopic.valueSerde.serializerClassName);
        }
        return kafkaProducer;
    }

    public void flushProducer() {
        if (kafkaProducer != null) {
            kafkaProducer.flush();
        }
    }

    public void closeProducer() {
        if (kafkaProducer != null) {
            kafkaProducer.close();
        }
        kafkaProducer = null;
    }

    public void send(EKafkaTopic kafkaTopic, String value) {
        ProducerRecord producerRecord = new ProducerRecord(kafkaTopic.name, value);
        getPublisher(kafkaTopic).send(producerRecord);
    }

    public void sendFailure(EKafkaTopic kafkaTopic, ConsumerRecord<String, String> consumerRecord, Exception e) {
        KafkaConsumerRecordException recordException = new KafkaConsumerRecordException(consumerRecord, e);
        ProducerRecord producerRecord = new ProducerRecord(kafkaTopic.name + "Failure", recordException.toString());
        getPublisher(kafkaTopic).send(producerRecord);
    }

    private boolean exists(EKafkaTopic kafkaTopic) {
        return exists(kafkaTopic.name);
    }

    private boolean exists(String topicName) {
        return kafkaServerClient.getKafkaServerTopics().stream()
                .filter(t -> t.name.equals(topicName)).findFirst().isPresent();
    }

    private void ensureAllEKafkaTopicsExist(){
        Arrays.stream(EKafkaTopic.values()).forEach(kt->ensureExists(kt));
    }

    private void ensureExists(EKafkaTopic kafkaTopic) {
        if (exists(kafkaTopic.name) == false) {
            logger.debug("Kafka topic {} did NOT already exist on the kakfa server. Creating it now...", kafkaTopic.name);
            createTopic(kafkaTopic.name, kafkaTopic.numberOfPartitions, kafkaTopic.numberOfReplicas);
        }

        String failureTopicName = kafkaTopic.name + "Failure";
        if (exists(failureTopicName) == false) {
            logger.debug("Kafka topic {} did NOT already exist on the kakfa server. Creating it now...", failureTopicName);
            createTopic(failureTopicName, kafkaTopic.numberOfPartitions, kafkaTopic.numberOfReplicas);
        }
    }

    private void createTopic(String topicName, int numberOfPartitions, int numberOfReplicas){
        kafkaServerClient.createTopic(topicName, numberOfPartitions, numberOfReplicas);
    }
}