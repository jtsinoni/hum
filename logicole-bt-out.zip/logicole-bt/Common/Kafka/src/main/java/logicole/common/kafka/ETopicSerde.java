package logicole.common.kafka;

import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;

enum ETopicSerde {
    String(new TopicSerde(StringSerializer.class, StringDeserializer.class)),
    ;

    public final TopicSerde topicSerde;
    public final String serializerClassName;
    public final String deserializerClassName;

    ETopicSerde(TopicSerde topicSerde) {
        this.topicSerde = topicSerde;
        this.serializerClassName = topicSerde.serializer.getName();
        this.deserializerClassName = topicSerde.deserializer.getName();
    }
}
