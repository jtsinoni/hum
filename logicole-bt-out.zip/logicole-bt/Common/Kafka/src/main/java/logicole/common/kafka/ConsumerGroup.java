package logicole.common.kafka;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.function.Consumer;

class ConsumerGroup {
    public final KafkaClient kafkaClient;
    public final EKafkaTopic kafkaTopic;
    public final String name;
    public final int numberOfConsumers;
    public final long durationInMilliseconds;
    public final boolean autoStart;
    private final List<LogiColeConsumer> kafkaConsumers = new ArrayList<>();

    @JsonIgnore
    public final Consumer consumerFunction;

    ConsumerGroup(KafkaClient kafkaClient, EKafkaTopic kafkaTopic, String name, int numberOfConsumers, Duration duration, boolean autoStart, java.util.function.Consumer consumerFunction){
        this.kafkaClient = kafkaClient;
        this.kafkaTopic = kafkaTopic;
        this.name = name;
        this.numberOfConsumers = numberOfConsumers;
        this.autoStart = autoStart;
        this.consumerFunction = consumerFunction;
        this.durationInMilliseconds = duration.toMillis();
    }

    void createConsumers(KafkaServerClient kafkaServerClient) {
        for (int i=0; i<numberOfConsumers; i++) {
            String clientId = generateNewClientId();
            LogiColeConsumer logiColeKafkaConsumer = new LogiColeConsumer(this, kafkaServerClient, clientId);
            kafkaConsumers.add(logiColeKafkaConsumer);
        }
    }

    public void startPolling(ExecutorService executorService) {
        kafkaConsumers.forEach(c->c.start(executorService));
    }

    public void stopPolling() {
        kafkaConsumers.forEach(c->c.pause());
    }

    public void deleteConsumers() {
        kafkaConsumers.forEach(c->c.close());
        kafkaConsumers.clear();
    }

    private String generateNewClientId() {
        return String.format("%s_Client_%d", name, kafkaConsumers.size());
    }
}
