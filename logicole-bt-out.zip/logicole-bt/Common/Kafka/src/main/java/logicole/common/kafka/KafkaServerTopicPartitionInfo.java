package logicole.common.kafka;

import org.apache.kafka.common.Node;
import org.apache.kafka.common.TopicPartitionInfo;

import java.util.List;
import java.util.stream.Collectors;

public class KafkaServerTopicPartitionInfo {
    public int partition;
    public KafkaServerNode leader;
    public List<KafkaServerNode> replicas;
    public List<KafkaServerNode> isr;

    public KafkaServerTopicPartitionInfo(){}

    public KafkaServerTopicPartitionInfo(TopicPartitionInfo topicPartitionInfo) {
        this.partition = topicPartitionInfo.partition();
        this.leader = new KafkaServerNode(topicPartitionInfo.leader());
        this.replicas = topicPartitionInfo.replicas().stream()
                .map(r -> new KafkaServerNode(r))
                .collect(Collectors.toList());
        this.isr = topicPartitionInfo.isr().stream()
                .map(r -> new KafkaServerNode(r))
                .collect(Collectors.toList());
    }
}
