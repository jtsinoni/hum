package logicole.common.cache;

import logicole.common.datamodels.user.Endpoint;
import logicole.common.general.logging.ILogger;
import logicole.common.general.util.JSONUtil;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.IOException;

@ApplicationScoped
public class TempWriteLineNumberCache extends LogicoleCache<String> {

    public TempWriteLineNumberCache() {
        super("/infinispan/cache/tempWriteLineNumberContainer/tempWriteLineNumberCache");
    }

    @Inject
    private JSONUtil jsonUtil;
    @Inject
    private ILogger logger;

    public Integer getCachedLineNumber(String key) {
        String val = super.getObject(key);
        Integer retVal = null;
        try {
            retVal = jsonUtil.deserialize(val, Integer.class);
        } catch (IOException e) {
            logger.error("failed to pull lineNumber from cache. key = " + key);
        }

        return retVal;
    }

    public Integer getCachedValue(String key) {
        Integer obj = getCachedLineNumber(key);
        Integer integerValue = null;
        if (obj != null) {
            integerValue =  (Integer)obj;
        }
        return integerValue;
    }

    public void putObject(String key, Integer value) {
        String strValue = null;
        try {
            strValue = jsonUtil.serialize(value);
        } catch (IOException e) {
            logger.error("failed to pull lineNumber from cache. key = " + key);
        }
        this.putObject(key, strValue);
    }
}
