package logicole.common.cache;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class TestJedisCache extends LogicoleCache<String>{

    public TestJedisCache() {
        super(String.class, "Test Jedis");
    }


}
