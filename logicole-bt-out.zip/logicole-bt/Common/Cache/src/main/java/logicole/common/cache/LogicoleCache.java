package logicole.common.cache;

import logicole.common.general.logging.ILogger;
import logicole.common.general.util.JSONUtil;
import org.infinispan.Cache;
import redis.clients.jedis.Jedis;
import org.infinispan.CacheSet;

import java.util.concurrent.TimeUnit;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.naming.NamingException;

public abstract class LogicoleCache<T extends Object> {

    private static Long DEFAULT_LIFESPAN_MILLIS = 3600000l; // 1 hour  TODO: Make configurable
    //private static Long DEFAULT_LIFESPAN_MILLIS  =  15000l;  // 15 seconds (for testing ONLY!)

    private Cache<String, T> infinispanCache;
    private Jedis jedisCache;

    private final boolean useJedis;

    private Class<T> clazz;
    private boolean isStringType;

    private String resourceName = null;
    private Long lifespanMillis;

    @Inject
    private ILogger logger;
    @Inject
    private ResourceFinder resourceFinder;
    @Inject
    private JedisCacheFactory jedisCacheFactory;
    @Inject
    JSONUtil jsonUtil;



    public LogicoleCache() {
        throw new UnsupportedOperationException();
    }

    public LogicoleCache(String resourceName) {
        this(null, resourceName, DEFAULT_LIFESPAN_MILLIS, false);
    }

    public LogicoleCache(Class<T> clazz, String resourceName) {
        this(clazz, resourceName, DEFAULT_LIFESPAN_MILLIS, true);
    }

    public LogicoleCache(Class<T> clazz, String resourceName, long lifespanMillis) {
        this(clazz, resourceName, lifespanMillis, true);
    }

    public LogicoleCache(Class<T> clazz, String resourceName, long lifespanMillis, boolean useJedis) {
        this.useJedis = useJedis;
        this.resourceName = resourceName;
        this.clazz = clazz;

        if (clazz != null) {
            isStringType = clazz.getTypeName().equals(String.class.getTypeName());
        }

        if (lifespanMillis > 0) {
            this.lifespanMillis = lifespanMillis;
        } else {
            this.lifespanMillis = DEFAULT_LIFESPAN_MILLIS;
        }
    }

    @PostConstruct
    public void postConstruct() {
        if (useJedis) {
            jedisCache = jedisCacheFactory.getCache();
        } else {
            try {
                this.infinispanCache = resourceFinder.getResource(resourceName);
                logger.debug("Cache definition found - {}. ", resourceName);
            } catch (NamingException e) {
                logger.warn("Cache definition not found - {}. Creating a disabled cache.", resourceName);
                this.infinispanCache = new DisabledCache<>();
            }
        }
    }

    public boolean exists(String key) {
        if (useJedis) {
            return jedisCache.exists(getJedisKey(key));
        } else {
            return infinispanCache.containsKey(key);
        }
    }

    protected int cacheCount() {
        if (useJedis) {
            return 0; //currently not implemented for Jedis
        } else {
            return this.infinispanCache.size();
        }
    }

    public T getObject(String key) {
        T cachedObject = null;
        if (exists(key)) {
            if (useJedis) {
                if (isStringType) {
                    cachedObject = (T) jedisCache.get(getJedisKey(key));
                } else {
                    cachedObject = jsonUtil.tryDeserialize(jedisCache.get(getJedisKey(key)), clazz);
                }

            } else {
                cachedObject = infinispanCache.get(key);
            }
        }
        return cachedObject;
    }

    public void putObject(String id, T objectToCache) {
        putObject(id, objectToCache, lifespanMillis);
    }

    public void putImmortalObject(String id, T objectToCache) {
        putObject(id, objectToCache, 0);
    }

    public void putObject(String id, T objectToCache, long lifespanMillis) {
        if (useJedis) {
            String jsonString;
            if (isStringType) {
                jsonString = objectToCache.toString();
            } else {
                jsonString = jsonUtil.trySerialize(objectToCache);
            }

            String jedisKey = getJedisKey(id);
            jedisCache.set(jedisKey, jsonString);

            if (lifespanMillis > 0) {
                jedisCache.expire(jedisKey, lifespanMillis / 1000);
            }
        } else {
            if (lifespanMillis > 0) {
                infinispanCache.put(id, objectToCache, lifespanMillis, TimeUnit.MILLISECONDS);
            } else {
                infinispanCache.put(id, objectToCache);
            }
        }

    }

    public void remove(String key) {
        if (key != null && !key.isEmpty()) {
            if (useJedis) {
                jedisCache.del(getJedisKey(key));
            } else {
                infinispanCache.remove(key);
            }
        }
    }

    public Long getLifespanMillis() {
        return lifespanMillis;
    }


    private String getJedisKey(String key) {
        return String.format("%s-%s", resourceName, key);
    }

    public CacheSet<String> getCacheKeys() {
        return infinispanCache.keySet();
    }
}
