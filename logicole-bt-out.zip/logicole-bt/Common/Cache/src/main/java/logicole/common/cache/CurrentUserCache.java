package logicole.common.cache;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class CurrentUserCache extends LogicoleCache<String>{

    public CurrentUserCache() {
        super("/infinispan/cache/currentUserBTContainer/currentUserBTCache");
    }


}
