package logicole.common.cache;

import logicole.common.datamodels.user.Endpoint;
import logicole.common.general.exception.NotFoundException;
import logicole.common.general.logging.ILogger;
import logicole.common.general.util.JSONUtil;

import java.io.IOException;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class EndpointCache extends LogicoleCache<String> {

    public EndpointCache() {
        super("/infinispan/cache/endpointContainer/endpointCache");
    }

    @Inject
    private JSONUtil jsonUtil;
    @Inject
    private ILogger logger;

    public Endpoint getCachedEndpoint(String key) {
        String val = super.getObject(key);
        Endpoint retVal = null;
        try {
            retVal = jsonUtil.deserialize(val, Endpoint.class);
        } catch (IOException e) {
            logger.error("failed to pull endpoint from cache. key = " + key);
        }

        return retVal;
    }

    public String getCachedValue(String key) {
        Endpoint obj = getCachedEndpoint(key);
        String stringValue = null;
        if (obj != null) {
            stringValue =  obj.toString();
        }
        return stringValue;
    }

    public void putObject(String key, Endpoint value) throws IOException {
        String strValue = jsonUtil.serialize(value);
        this.putObject(key, strValue);
    }
}
