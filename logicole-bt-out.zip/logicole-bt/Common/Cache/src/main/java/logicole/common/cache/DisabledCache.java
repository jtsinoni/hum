package logicole.common.cache;

import org.infinispan.*;
import org.infinispan.commons.util.concurrent.NotifyingFuture;
import org.infinispan.configuration.cache.Configuration;
import org.infinispan.filter.KeyFilter;
import org.infinispan.lifecycle.ComponentStatus;
import org.infinispan.manager.EmbeddedCacheManager;
import org.infinispan.notifications.cachelistener.filter.CacheEventConverter;
import org.infinispan.notifications.cachelistener.filter.CacheEventFilter;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/*
This class can be used when a cache definition is not found. It will behave as if an item is never cached.
 */
public class DisabledCache<K,V> implements Cache<K,V> {
    @Override
    public void putForExternalRead(K k, V v) {

    }

    @Override
    public void putForExternalRead(K k, V v, long l, TimeUnit timeUnit) {

    }

    @Override
    public void putForExternalRead(K k, V v, long l, TimeUnit timeUnit, long l1, TimeUnit timeUnit1) {

    }

    @Override
    public void evict(K k) {

    }

    @Override
    public Configuration getCacheConfiguration() {
        return null;
    }

    @Override
    public EmbeddedCacheManager getCacheManager() {
        return null;
    }

    @Override
    public AdvancedCache<K, V> getAdvancedCache() {
        return null;
    }

    @Override
    public ComponentStatus getStatus() {
        return null;
    }

    @Override
    public int size() {
        return 0;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    @Override
    public boolean containsKey(Object key) {
        return false;
    }

    @Override
    public boolean containsValue(Object value) {
        return false;
    }

    @Override
    public V get(Object key) {
        return null;
    }

    @Override
    public CacheSet<K> keySet() {
        return null;
    }

    @Override
    public CacheCollection<V> values() {
        return null;
    }

    @Override
    public CacheSet<Map.Entry<K, V>> entrySet() {
        return null;
    }

    @Override
    public void clear() {

    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getVersion() {
        return null;
    }

    @Override
    public V put(K k, V v) {
        return v;
    }

    @Override
    public V put(K k, V v, long l, TimeUnit timeUnit) {
        return v;
    }

    @Override
    public V putIfAbsent(K k, V v, long l, TimeUnit timeUnit) {
        return v;
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> map, long l, TimeUnit timeUnit) {

    }

    @Override
    public V replace(K k, V v, long l, TimeUnit timeUnit) {
        return v;
    }

    @Override
    public boolean replace(K k, V v, V v1, long l, TimeUnit timeUnit) {
        return false;
    }

    @Override
    public V put(K k, V v, long l, TimeUnit timeUnit, long l1, TimeUnit timeUnit1) {
        return v;
    }

    @Override
    public V putIfAbsent(K k, V v, long l, TimeUnit timeUnit, long l1, TimeUnit timeUnit1) {
        return v;
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> map, long l, TimeUnit timeUnit, long l1, TimeUnit timeUnit1) {

    }

    @Override
    public V replace(K k, V v, long l, TimeUnit timeUnit, long l1, TimeUnit timeUnit1) {
        return v;
    }

    @Override
    public boolean replace(K k, V v, V v1, long l, TimeUnit timeUnit, long l1, TimeUnit timeUnit1) {
        return false;
    }

    @Override
    public V remove(Object o) {
        return null;
    }

    @Override
    public void putAll(Map<? extends K, ? extends V> m) {

    }

    @Override
    public V putIfAbsent(K key, V value) {
        return value;
    }

    @Override
    public boolean remove(Object key, Object value) {
        return false;
    }

    @Override
    public boolean replace(K key, V oldValue, V newValue) {
        return false;
    }

    @Override
    public V replace(K key, V value) {
        return value;
    }

    @Override
    public NotifyingFuture<V> putAsync(K k, V v) {
        return null;
    }

    @Override
    public NotifyingFuture<V> putAsync(K k, V v, long l, TimeUnit timeUnit) {
        return null;
    }

    @Override
    public NotifyingFuture<V> putAsync(K k, V v, long l, TimeUnit timeUnit, long l1, TimeUnit timeUnit1) {
        return null;
    }

    @Override
    public NotifyingFuture<Void> putAllAsync(Map<? extends K, ? extends V> map) {
        return null;
    }

    @Override
    public NotifyingFuture<Void> putAllAsync(Map<? extends K, ? extends V> map, long l, TimeUnit timeUnit) {
        return null;
    }

    @Override
    public NotifyingFuture<Void> putAllAsync(Map<? extends K, ? extends V> map, long l, TimeUnit timeUnit, long l1, TimeUnit timeUnit1) {
        return null;
    }

    @Override
    public NotifyingFuture<Void> clearAsync() {
        return null;
    }

    @Override
    public NotifyingFuture<V> putIfAbsentAsync(K k, V v) {
        return null;
    }

    @Override
    public NotifyingFuture<V> putIfAbsentAsync(K k, V v, long l, TimeUnit timeUnit) {
        return null;
    }

    @Override
    public NotifyingFuture<V> putIfAbsentAsync(K k, V v, long l, TimeUnit timeUnit, long l1, TimeUnit timeUnit1) {
        return null;
    }

    @Override
    public NotifyingFuture<V> removeAsync(Object o) {
        return null;
    }

    @Override
    public NotifyingFuture<Boolean> removeAsync(Object o, Object o1) {
        return null;
    }

    @Override
    public NotifyingFuture<V> replaceAsync(K k, V v) {
        return null;
    }

    @Override
    public NotifyingFuture<V> replaceAsync(K k, V v, long l, TimeUnit timeUnit) {
        return null;
    }

    @Override
    public NotifyingFuture<V> replaceAsync(K k, V v, long l, TimeUnit timeUnit, long l1, TimeUnit timeUnit1) {
        return null;
    }

    @Override
    public NotifyingFuture<Boolean> replaceAsync(K k, V v, V v1) {
        return null;
    }

    @Override
    public NotifyingFuture<Boolean> replaceAsync(K k, V v, V v1, long l, TimeUnit timeUnit) {
        return null;
    }

    @Override
    public NotifyingFuture<Boolean> replaceAsync(K k, V v, V v1, long l, TimeUnit timeUnit, long l1, TimeUnit timeUnit1) {
        return null;
    }

    @Override
    public NotifyingFuture<V> getAsync(K k) {
        return null;
    }

    @Override
    public boolean startBatch() {
        return false;
    }

    @Override
    public void endBatch(boolean b) {

    }

    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }

    @Override
    public void addListener(Object o, KeyFilter<? super K> keyFilter) {

    }

    @Override
    public <C> void addListener(Object o, CacheEventFilter<? super K, ? super V> cacheEventFilter, CacheEventConverter<? super K, ? super V, C> cacheEventConverter) {

    }

    @Override
    public void addListener(Object o) {

    }

    @Override
    public void removeListener(Object o) {

    }

    @Override
    public Set<Object> getListeners() {
        return null;
    }
}
