package logicole.common.cache;

import logicole.common.general.configuration.ConfigurationManager;
import redis.clients.jedis.JedisClientConfig;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.net.ssl.*;
import java.io.File;
import java.security.KeyStore;
import java.security.SecureRandom;

@ApplicationScoped
public class LogiColeJedisClientConfig implements JedisClientConfig {
    @Inject
    ConfigurationManager configurationManager;

    private SSLSocketFactory sslSocketFactory = null;

    @Override
    public boolean isSsl() {
        return true;
    }

    @Override
    public SSLSocketFactory getSslSocketFactory() {
        if (sslSocketFactory == null){
            sslSocketFactory = createSslSocketFactory();
        }
        return sslSocketFactory;
    }

    @Override
    public String getPassword() {
        return configurationManager.getRedisPassword();
    }

    @Override
    public String getUser() {
        return "default";
    }

    private SSLSocketFactory createSslSocketFactory() {
        try {
            String keyStoreType = "jks";
            String trustStoreType = "jks";

            String trustStorePath = configurationManager.getTrustStorePath();
            String trustStorePassword = configurationManager.getTrustStorePassword();

            String keyStorePath = configurationManager.getKeyStorePath();
            String keyStorePassword = configurationManager.getKeyStorePassword();


            File trustStoreFile = new File(trustStorePath);
            KeyStore trustStore = KeyStore.getInstance(trustStoreFile, trustStorePassword.toCharArray());

            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(("PKIX"));
            trustManagerFactory.init(trustStore);
            TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();

            File keyStoreFile = new File(keyStorePath);
            KeyStore keyStore = KeyStore.getInstance(keyStoreFile, keyStorePassword.toCharArray());

            KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("PKIX");
            keyManagerFactory.init(keyStore, keyStorePassword.toCharArray());
            KeyManager[] keyManagers = keyManagerFactory.getKeyManagers();


            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(keyManagers, trustManagers, new SecureRandom());
            return sslContext.getSocketFactory();
        }catch(Exception e){
            throw new RuntimeException("Failed to create Ssl Socket Factory for Redis", e);
        }
    }

}