package logicole.common.cache;

import logicole.common.general.configuration.ConfigurationManager;
import redis.clients.jedis.*;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.net.ssl.*;
import java.io.File;
import java.net.URI;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

@ApplicationScoped
public class JedisCacheFactory {
    @Inject
    private ConfigurationManager configurationManager;

    @Inject
    LogiColeJedisClientConfig logiColeJedisClientConfig;

    public Jedis getCache(){
        return getSentinelConnection();
    }

    private Jedis getSentinelConnection() {
        String masterName = configurationManager.getRedisClusterName();
        String sentinalString = configurationManager.getRedisSentinals();

        Set<HostAndPort> sentinels = Arrays.stream(sentinalString.split(","))
                .map(t -> {
                    String[] split = t.split(":");
                    HostAndPort hostAndPort = new HostAndPort(split[0], Integer.parseInt(split[1]));
                    return hostAndPort;
                })
                .collect(Collectors.toSet());

        JedisSentinelPool pool = new JedisSentinelPool(masterName, sentinels, logiColeJedisClientConfig, logiColeJedisClientConfig);
        Jedis jedis = pool.getResource();
        return jedis;
    }
}
