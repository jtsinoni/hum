package logicole.common.restserver;

import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;

import javax.annotation.Priority;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.ext.Provider;

import static javax.ws.rs.Priorities.USER;

@Provider
@Consumes({"application/json", "application/*+json", "text/json"})
@Produces({"application/json", "application/*+json", "text/json"})
@Priority(USER-1)
public class LogiColeJacksonJsonProvider extends JacksonJsonProvider {

}
