package logicole.common.restserver;

import io.swagger.jaxrs.config.BeanConfig;
import io.swagger.jaxrs.config.SwaggerContextService;
import io.swagger.models.SecurityRequirement;
import io.swagger.models.Swagger;
import io.swagger.models.auth.ApiKeyAuthDefinition;
import io.swagger.models.auth.In;

import javax.annotation.PostConstruct;
import javax.ws.rs.core.Application;
import java.util.HashSet;
import java.util.Set;

public class JaxRsModuleApplication extends Application {
    private final String moduleName;

    private static final String CLIENT_AUTH = "clientAuth";
    private static final String TOKEN_AUTH = "tokenAuth";

    protected final Set<Class<?>> moduleResources = new HashSet<>();

    private JaxRsModuleApplication() {this.moduleName = null;}

    public JaxRsModuleApplication(String moduleName) {
        this.moduleName = moduleName;
    }

    private String[] getSchemes() {
        var swaggerSchemes = "https";
        return swaggerSchemes.split(",");
    }

    private void initSwagger() {
        var projectVersion = "1.0-SNAPSHOT";

        var swaggerHost = "localhost";
        var swaggerPort = "4431";
        var basePath = String.format("logicole-%s", moduleName);
        var resourcePackage = "logicole.gateway";

        var beanConfig = new BeanConfig();

        beanConfig.setVersion(projectVersion);
        beanConfig.setSchemes(getSchemes());
        beanConfig.setHost(String.format("%s:%s", swaggerHost, swaggerPort));
        beanConfig.setBasePath(basePath);
        beanConfig.setResourcePackage(resourcePackage);
        beanConfig.setPrettyPrint(true);
        beanConfig.setScan(true);

        setSecurityConfig();
    }

    /**
     * Currently the Swagger application does not provide the 'Authorize' button which allows for
     * the user to reset authentication values.  Manually adding the security definitions to
     * the generated swagger.json allows the Swagger application to provide this functionality.
     */
    private void setSecurityConfig() {
        var swagger = new Swagger();
        swagger.addSecurityDefinition(CLIENT_AUTH, new ApiKeyAuthDefinition("ClientId", In.HEADER));
        swagger.addSecurityDefinition(TOKEN_AUTH, new ApiKeyAuthDefinition("Authorization", In.HEADER));
        var apiKeyRequirement = new SecurityRequirement();
        // security values must match the definition names above
        apiKeyRequirement.requirement(CLIENT_AUTH);
        apiKeyRequirement.requirement(TOKEN_AUTH);
        swagger.addSecurity(apiKeyRequirement);

        new SwaggerContextService().updateSwagger(swagger);
    }

    @PostConstruct
    public void init() {
        initSwagger();
    }

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new HashSet<>();

        resources.add(io.swagger.jaxrs.listing.ApiListingResource.class);
        resources.add(io.swagger.jaxrs.listing.SwaggerSerializers.class);
        resources.add(LogiColeJacksonJsonProvider.class);

        resources.addAll(moduleResources);
        resources.add(CorsFilter.class);
        resources.add(ObjectMapperContextResolver.class);
        return resources;
    }
}
