package logicole.common.restserver;

import logicole.common.general.util.string.StringUtil;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Provider
public class CorsFilter implements ContainerResponseFilter {

    Map<String, String> headers = new HashMap<>();

    @PostConstruct
    public void start() {
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Access-Control-Allow-Headers", "Origin, X-PINGOTHER, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Origin, Authorization, ClientId, Pragma, CallerHandlesError, X-IAS-JWT");
        headers.put("Access-Control-Allow-Methods", "POST, GET");
        headers.put("Access-Control-Max-Age", "900000");
    }

    @Override
    public void filter(final ContainerRequestContext requestContext, final ContainerResponseContext cres) {
        boolean addHeaderToResponse;
        String requestOrigin = requestContext.getHeaderString("Origin");
        if (cres.getHeaders().size() != headers.size()) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                String keyStr = entry.getKey();
                String valueStr = entry.getValue();
                addHeaderToResponse = true;

                // The only time the Access-Control-Allow-Origin header will be added to the Response is when we are
                // running in Swagger or when the X-Requested-With header is set on the Request.
                if (StringUtil.safeEqualsIgnoreCase(keyStr, "Access-Control-Allow-Origin")) {
                    if (addOriginHeader(requestContext)) {
                        valueStr = requestOrigin;
                    } else {
                        addHeaderToResponse = false;
                    }
                }

                if (addHeaderToResponse) {
                    cres.getHeaders().add(keyStr, valueStr);
                }
            }
        }
    }

    public void addCorsToResponseHeader(HttpServletResponse response){
        if(response.getHeaderNames().size() != headers.size()) {
            for (Map.Entry entry : headers.entrySet()) {
                response.addHeader(entry.getKey().toString(), entry.getValue().toString());
            }
        }
    }

    // Special logic to only add the Access-Control-Allow-Origin header if the X-Requested-With header is set on the
    // Request or if we are using swagger.
    public boolean addOriginHeader(final ContainerRequestContext requestContext) {
        boolean returnValue;
        String requestOrigin = requestContext.getHeaderString("Origin");

        if (StringUtil.doesStringContain(requestOrigin,"localhost:3200", true)) {
            returnValue = true;
        } else {
            returnValue = (StringUtil.safeEqualsIgnoreCase(requestContext.getHeaderString("X-Requested-With"), "XMLHttpRequest")
                    && Objects.nonNull(requestOrigin));
        }

        return returnValue;
    }
}