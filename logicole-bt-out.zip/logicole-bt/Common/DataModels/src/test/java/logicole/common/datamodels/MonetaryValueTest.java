package logicole.common.datamodels;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;


@RunWith(MockitoJUnitRunner.class)
public class MonetaryValueTest {

    @Test
    public void verifyRoundToMaxScale() {

        // Based on MonetaryValue having DECIMAL_SCALE_MAX of 10..testing that things
        // round to this scale if you try to create a MonetaryValue with higher precision
        String stringWithTooHighPrecision = "36.987655323989";
        BigDecimal bigDecimalWithTooHighPrecision = new BigDecimal(stringWithTooHighPrecision);

        BigDecimal expectedResultBigDecimalVal = new BigDecimal("36.9876553240");

        MonetaryValue monetaryValueFromString = new MonetaryValue(stringWithTooHighPrecision, 12);
        MonetaryValue monetaryValueFromBigDecimal = new MonetaryValue(bigDecimalWithTooHighPrecision, 12);

        assertEquals(expectedResultBigDecimalVal, monetaryValueFromString.getBigDecimalVal());
        assertEquals(expectedResultBigDecimalVal, monetaryValueFromBigDecimal.getBigDecimalVal());
    }

    @Test
    public void verifyRoundToArbitraryScale() {

        String stringWithTooHighPrecision = "0.54789";
        BigDecimal bigDecimalWithTooHighPrecision = new BigDecimal(stringWithTooHighPrecision);

        BigDecimal expectedResultBigDecimalVal = new BigDecimal("0.5479");

        MonetaryValue monetaryValueFromString = new MonetaryValue(stringWithTooHighPrecision, 4);
        MonetaryValue monetaryValueFromBigDecimal = new MonetaryValue(bigDecimalWithTooHighPrecision, 4);

        assertEquals(expectedResultBigDecimalVal, monetaryValueFromString.getBigDecimalVal());
        assertEquals(expectedResultBigDecimalVal, monetaryValueFromBigDecimal.getBigDecimalVal());
    }

    @Test
    public void verifyRoundToDefaultMonetaryScale() {

        String stringWithTooHighPrecision = "61.78948";
        BigDecimal bigDecimalWithTooHighPrecision = new BigDecimal(stringWithTooHighPrecision);

        BigDecimal expectedResultBigDecimalVal = new BigDecimal("61.79");

        MonetaryValue monetaryValueFromString = new MonetaryValue(stringWithTooHighPrecision);
        MonetaryValue monetaryValueFromBigDecimal = new MonetaryValue(bigDecimalWithTooHighPrecision);

        assertEquals(expectedResultBigDecimalVal, monetaryValueFromString.getBigDecimalVal());
        assertEquals(expectedResultBigDecimalVal, monetaryValueFromBigDecimal.getBigDecimalVal());
    }

    @Test
    public void verifyGetScaleWithArbitraryScale1() {

        int theScale = 4;
        MonetaryValue monetaryValue = new MonetaryValue("64.99888", 4);
        assertEquals(theScale, monetaryValue.getScale());
    }

//    @Test
//    public void verifyGetScaleWithArbitraryScale2() {
//
//        int theScale1 = 4;
//        int theScale2 = 2;
//
//        MonetaryValue monetaryValue = new MonetaryValue("64.99888", 4);
//        assertEquals(theScale1, monetaryValue.getScale());
//
//        BigDecimal result = monetaryValue.divide(2, 4);
//        assertEquals(theScale1, result.getScale());
//
//        monetaryValue = monetaryValue.multiply(10);
//        assertEquals(theScale2, monetaryValue.getScale());
//    }

    @Test
    public void verifyGetScaleWithDefaultMonetaryScale() {

        int theScale = 2;
        MonetaryValue monetaryValue = new MonetaryValue("64.99888");
        assertEquals(theScale, monetaryValue.getScale());
    }

    @Test
    public void verifyDifferentWaysToRoundToScale1() {

        MonetaryValue monetaryValue1 = new MonetaryValue("56.78989", 5);
        monetaryValue1 = monetaryValue1.roundToScale(4);

        MonetaryValue monetaryValue2 = new MonetaryValue("56.78989", 5).roundToScale(4);

        MonetaryValue expectedValue = new MonetaryValue("56.7899", 4);
        assertEquals(monetaryValue1, expectedValue);
        assertEquals(monetaryValue2, expectedValue);
        assertEquals(monetaryValue1, monetaryValue2);

        assertEquals(monetaryValue1.getScale(), 4);
    }

    @Test
    public void verifyDifferentWaysToRoundToScale2() {

        MonetaryValue monetaryValue1 = new MonetaryValue("56.78989", 5);
        monetaryValue1 = monetaryValue1.roundToMonetaryScale();

        MonetaryValue monetaryValue2 = new MonetaryValue("56.78989", 5).roundToMonetaryScale();

        MonetaryValue expectedValue = new MonetaryValue("56.79");
        assertEquals(monetaryValue1, expectedValue);
        assertEquals(monetaryValue2, expectedValue);
        assertEquals(monetaryValue1, monetaryValue2);

        assertEquals(monetaryValue1.getScale(), 2);
    }


    @Test
    public void verifyEqualsWhenComparingWithItself() {

        MonetaryValue monetaryValue1 = new MonetaryValue("50.15");
        assertTrue(monetaryValue1.equals(monetaryValue1));

        MonetaryValue monetaryValue2 = new MonetaryValue(new BigDecimal("56.998521"), 6);
        assertTrue(monetaryValue2.equals(monetaryValue2));
    }

    @Test
    public void verifyEqualsWhenComparingWithNull() {

        MonetaryValue monetaryValue1 = new MonetaryValue("40.00");
        assertFalse(monetaryValue1.equals(null));
    }

    @Test
    public void verifyEqualsWhenComparingWithDifferentClass() {

        MonetaryValue monetaryValue1 = new MonetaryValue("40.00");
        BigDecimal bigDecimal1 = new BigDecimal("40.00");
        assertNotEquals(monetaryValue1, bigDecimal1);
    }

    @Test
    public void verifyCompareToAndEquals_EqualValues() {

        MonetaryValue monetaryValue1 = new MonetaryValue("647.55777", 3);
        MonetaryValue monetaryValue2 = new MonetaryValue("647.5579", 3);
        MonetaryValue monetaryValue3 = new MonetaryValue(new BigDecimal("647.557989"), 3);

        assertEquals(0, monetaryValue1.compareTo(monetaryValue2));
        assertTrue(monetaryValue1.equals(monetaryValue2));

        assertEquals(0, monetaryValue1.compareTo(monetaryValue3));
        assertTrue(monetaryValue1.equals(monetaryValue3));

        assertEquals(0, monetaryValue2.compareTo(monetaryValue1));
        assertTrue(monetaryValue2.equals(monetaryValue1));

        assertEquals(0, monetaryValue2.compareTo(monetaryValue3));
        assertTrue(monetaryValue2.equals(monetaryValue3));

        assertEquals(0, monetaryValue3.compareTo(monetaryValue1));
        assertTrue(monetaryValue3.equals(monetaryValue1));

        assertEquals(0, monetaryValue3.compareTo(monetaryValue2));
        assertTrue(monetaryValue3.equals(monetaryValue2));

        MonetaryValue monetaryValue4 = new MonetaryValue(new BigDecimal("566"));
        MonetaryValue monetaryValue5 = new MonetaryValue(new BigDecimal("566.00"));

        assertEquals(0, monetaryValue4.compareTo(monetaryValue5));
        assertTrue(monetaryValue4.equals(monetaryValue5));

        assertEquals(0, monetaryValue5.compareTo(monetaryValue4));
        assertTrue(monetaryValue5.equals(monetaryValue4));
    }

    @Test
    public void verifyCompareToAndEquals_EqualValuesDifferentScalesPt1() {

        MonetaryValue monetaryValue1 = new MonetaryValue("56");
        MonetaryValue monetaryValue2 = new MonetaryValue("56.0");
        MonetaryValue monetaryValue3 = new MonetaryValue("56.00");
        MonetaryValue monetaryValue4 = new MonetaryValue("56.0000", 4);

        assertEquals(0, monetaryValue1.compareTo(monetaryValue2));
        assertTrue(monetaryValue1.equals(monetaryValue2));

        assertEquals(0, monetaryValue1.compareTo(monetaryValue3));
        assertTrue(monetaryValue1.equals(monetaryValue3));

        assertEquals(0, monetaryValue1.compareTo(monetaryValue4));
        assertTrue(monetaryValue1.equals(monetaryValue4));

        assertEquals(0, monetaryValue2.compareTo(monetaryValue1));
        assertTrue(monetaryValue2.equals(monetaryValue1));

        assertEquals(0, monetaryValue2.compareTo(monetaryValue3));
        assertTrue(monetaryValue2.equals(monetaryValue3));

        assertEquals(0, monetaryValue2.compareTo(monetaryValue4));
        assertTrue(monetaryValue2.equals(monetaryValue4));

        assertEquals(0, monetaryValue3.compareTo(monetaryValue1));
        assertTrue(monetaryValue3.equals(monetaryValue1));

        assertEquals(0, monetaryValue3.compareTo(monetaryValue2));
        assertTrue(monetaryValue3.equals(monetaryValue2));

        assertEquals(0, monetaryValue3.compareTo(monetaryValue4));
        assertTrue(monetaryValue3.equals(monetaryValue4));

        assertEquals(0, monetaryValue4.compareTo(monetaryValue1));
        assertTrue(monetaryValue4.equals(monetaryValue1));

        assertEquals(0, monetaryValue4.compareTo(monetaryValue2));
        assertTrue(monetaryValue4.equals(monetaryValue2));

        assertEquals(0, monetaryValue4.compareTo(monetaryValue3));
        assertTrue(monetaryValue4.equals(monetaryValue3));
    }

    @Test
    public void verifyCompareToAndEquals_EqualValuesDifferentScalePt2() {

        MonetaryValue monetaryValue1 = new MonetaryValue("56.5");
        MonetaryValue monetaryValue2 = new MonetaryValue("56.50");
        MonetaryValue monetaryValue3 = new MonetaryValue("56.5000", 4);

        assertEquals(0, monetaryValue1.compareTo(monetaryValue2));
        assertTrue(monetaryValue1.equals(monetaryValue2));

        assertEquals(0, monetaryValue1.compareTo(monetaryValue3));
        assertTrue(monetaryValue1.equals(monetaryValue3));

        assertEquals(0, monetaryValue2.compareTo(monetaryValue1));
        assertTrue(monetaryValue2.equals(monetaryValue1));

        assertEquals(0, monetaryValue2.compareTo(monetaryValue3));
        assertTrue(monetaryValue2.equals(monetaryValue3));

        assertEquals(0, monetaryValue3.compareTo(monetaryValue1));
        assertTrue(monetaryValue3.equals(monetaryValue1));

        assertEquals(0, monetaryValue3.compareTo(monetaryValue2));
        assertTrue(monetaryValue3.equals(monetaryValue2));
    }

    @Test
    public void verifyCompareToAndEquals_UnequalValuesPt1() {

        MonetaryValue monetaryValue1 = new MonetaryValue("56.5778", 4);
        MonetaryValue monetaryValue2 = new MonetaryValue("56.5778000", 7);
        MonetaryValue monetaryValue3 = new MonetaryValue("56.5778"); //will round to 56.58

        assertEquals(0, monetaryValue1.compareTo(monetaryValue2));
        assertTrue(monetaryValue1.equals(monetaryValue2));

        assertEquals(-1, monetaryValue1.compareTo(monetaryValue3));
        assertFalse(monetaryValue1.equals(monetaryValue3));

        assertEquals(0, monetaryValue2.compareTo(monetaryValue1));
        assertTrue(monetaryValue2.equals(monetaryValue1));

        assertEquals(-1, monetaryValue2.compareTo(monetaryValue3));
        assertFalse(monetaryValue2.equals(monetaryValue3));

        assertEquals(1, monetaryValue3.compareTo(monetaryValue1));
        assertFalse(monetaryValue3.equals(monetaryValue1));

        assertEquals(1, monetaryValue3.compareTo(monetaryValue2));
        assertFalse(monetaryValue3.equals(monetaryValue2));
    }

    @Test
    public void verifyCompareToEquals_UnequalValues_Pt2() {

        MonetaryValue monetaryValue1 = new MonetaryValue("34.55");
        MonetaryValue monetaryValue2 = new MonetaryValue(new BigDecimal("34.56"));

        assertEquals(-1, monetaryValue1.compareTo(monetaryValue2));
        assertFalse(monetaryValue1.equals(monetaryValue2));


        assertEquals(1, monetaryValue2.compareTo(monetaryValue1));
        assertFalse(monetaryValue2.equals(monetaryValue1));

        MonetaryValue monetaryValue3 = new MonetaryValue("655.9994", 3); // will round to 655.999
        MonetaryValue monetaryValue4 = new MonetaryValue("655.9994", 4);

        assertEquals(-1, monetaryValue3.compareTo(monetaryValue4));
        assertFalse(monetaryValue3.equals(monetaryValue4));

        assertEquals(1, monetaryValue4.compareTo(monetaryValue3));
        assertFalse(monetaryValue4.equals(monetaryValue3));
    }

    @Test
    public void verifyDifferentConstructorsProduceSameResult_Pt1() {

        MonetaryValue monetaryValue1 = new MonetaryValue("36.55");
        MonetaryValue monetaryValue2 = new MonetaryValue("36.55", 2);
        MonetaryValue monetaryValue25 = new MonetaryValue("36.5500", 4);

        MonetaryValue monetaryValue3 = new MonetaryValue(new BigDecimal("36.55"));
        MonetaryValue monetaryValue4 = new MonetaryValue(new BigDecimal("36.55"), 2);
        MonetaryValue monetaryValue45 = new MonetaryValue(new BigDecimal("36.5500"), 4);

        double d = 36.55d;
        double dd = 36.5500d;
        MonetaryValue monetaryValue5 = new MonetaryValue(d);
        MonetaryValue monetaryValue6 = new MonetaryValue(d, 2);
        MonetaryValue monetaryValue7 = new MonetaryValue(dd, 4);

        assertEquals(monetaryValue1, monetaryValue2);
        assertEquals(monetaryValue2, monetaryValue25);
        assertEquals(monetaryValue25, monetaryValue3);
        assertEquals(monetaryValue3, monetaryValue4);
        assertEquals(monetaryValue4, monetaryValue45);
        assertEquals(monetaryValue45, monetaryValue5);
        assertEquals(monetaryValue5, monetaryValue6);
        assertEquals(monetaryValue6, monetaryValue7);
    }

    @Test
    public void verifyDifferentConstructorsProduceSameResult_Pt2() {

        MonetaryValue monetaryValue1 = new MonetaryValue("36.5587", 4);
        MonetaryValue monetaryValue2 = new MonetaryValue(new BigDecimal("36.5587"), 4);
        double d = 36.5587d;
        MonetaryValue monetaryValue3 = new MonetaryValue(d, 4);

        assertEquals(monetaryValue1, monetaryValue2);
        assertEquals(monetaryValue2, monetaryValue3);
    }

    @Test
    public void verifyDifferentConstructorsProduceSameResult_Pt3() {

        int intVal = 15;
        long longVal = 15L;
        double doubleVal = 15.0000d;
        BigDecimal bigDecimalVal = new BigDecimal("15.0");

        MonetaryValue monetaryValueFromInt1 = new MonetaryValue(intVal);
        MonetaryValue monetaryValueFromLong1 = new MonetaryValue(longVal);
        MonetaryValue monetaryValueFromDouble1 = new MonetaryValue(doubleVal);
        MonetaryValue monetaryValueFromBigDecimal1 = new MonetaryValue(bigDecimalVal);

        MonetaryValue monetaryValueFromInt2 = new MonetaryValue(intVal, 2);
        MonetaryValue monetaryValueFromLong2 = new MonetaryValue(longVal, 2);
        MonetaryValue monetaryValueFromDouble2 = new MonetaryValue(doubleVal, 2);
        MonetaryValue monetaryValueFromBigDecimal2 = new MonetaryValue(bigDecimalVal, 2);

        assertEquals(monetaryValueFromInt1, monetaryValueFromLong1);
        assertEquals(monetaryValueFromLong1, monetaryValueFromDouble1);
        assertEquals(monetaryValueFromDouble1, monetaryValueFromBigDecimal1);
        assertEquals(monetaryValueFromBigDecimal1, monetaryValueFromInt2);
        assertEquals(monetaryValueFromInt2, monetaryValueFromLong2);
        assertEquals(monetaryValueFromLong2, monetaryValueFromDouble2);
        assertEquals(monetaryValueFromDouble2, monetaryValueFromBigDecimal2);
    }

    @Test
    public void verifyDifferentConstructorsProductSameResult_Pt4() {

        MonetaryValue monetaryValue1 = new MonetaryValue();
        MonetaryValue monetaryValue2 = new MonetaryValue("0.00");
        MonetaryValue monetaryValue3 = new MonetaryValue("0.00", 2);
        MonetaryValue monetaryValue4 = new MonetaryValue("0.0000000000", 10);

        assertEquals(monetaryValue1, monetaryValue2);
        assertEquals(monetaryValue1, monetaryValue3);
        assertEquals(monetaryValue1, monetaryValue4);
        assertEquals(monetaryValue2, monetaryValue1);
        assertEquals(monetaryValue2, monetaryValue3);
        assertEquals(monetaryValue2, monetaryValue4);
        assertEquals(monetaryValue3, monetaryValue1);
        assertEquals(monetaryValue3, monetaryValue2);
        assertEquals(monetaryValue3, monetaryValue4);
        assertEquals(monetaryValue4, monetaryValue1);
        assertEquals(monetaryValue4, monetaryValue2);
        assertEquals(monetaryValue4, monetaryValue3);
    }

    @Test
    public void verifyImmutability1() {

        MonetaryValue monetaryValue1 = new MonetaryValue("64.9987848", 7);
        MonetaryValue monetaryValue2 = new MonetaryValue("64.9987848", 7);

        assertEquals(monetaryValue1, monetaryValue2);

        monetaryValue1 = monetaryValue1.roundToScale(4);
        monetaryValue2.roundToScale(4);

        assertEquals(monetaryValue1.getScale(), 4);
        assertNotEquals(monetaryValue1, monetaryValue2);
    }

    @Test
    public void verifyImmutability2() {

        MonetaryValue monetaryValue1 = new MonetaryValue("20.998", 3);
        MonetaryValue monetaryValue2 = new MonetaryValue("20.998", 3);

        assertEquals(monetaryValue1, monetaryValue2);

        monetaryValue1.roundToMonetaryScale();
        monetaryValue2 = monetaryValue2.roundToMonetaryScale();

        assertEquals(monetaryValue2.getScale(), 2);
        assertNotEquals(monetaryValue1, monetaryValue2);
    }

    @Test
    public void verifyImmutability3() {

        MonetaryValue monetaryValue1 = new MonetaryValue("20.9987", 4);
        MonetaryValue monetaryValue2 = new MonetaryValue("20.9987", 4);

        MonetaryValue monetaryValue3 = new MonetaryValue("20.99");
        MonetaryValue monetaryValue4 = new MonetaryValue("20.99");

        assertEquals(monetaryValue1, monetaryValue2);
        assertEquals(monetaryValue3, monetaryValue4);

        monetaryValue1 = monetaryValue1.add(new MonetaryValue("10"), 4);
        monetaryValue2.add(new MonetaryValue("10"), 4);
        assertEquals(monetaryValue1, new MonetaryValue("30.9987", 4));
        assertNotEquals(monetaryValue1, monetaryValue2);

        monetaryValue3 = monetaryValue3.add(new MonetaryValue("10"));
        monetaryValue4.add(new MonetaryValue("10"));
        assertEquals(monetaryValue3, new MonetaryValue("30.99"));
        assertNotEquals(monetaryValue3, monetaryValue4);
    }

    @Test
    public void verifyImmutability4() {

        MonetaryValue monetaryValue1 = new MonetaryValue("20.9987", 4);
        MonetaryValue monetaryValue2 = new MonetaryValue("20.9987", 4);

        MonetaryValue monetaryValue3 = new MonetaryValue("20.99");
        MonetaryValue monetaryValue4 = new MonetaryValue("20.99");

        assertEquals(monetaryValue1, monetaryValue2);
        assertEquals(monetaryValue3, monetaryValue4);

        monetaryValue1 = monetaryValue1.subtract(new MonetaryValue("10"), 4);
        monetaryValue2.subtract(new MonetaryValue("10"), 4);
        assertEquals(monetaryValue1, new MonetaryValue("10.9987", 4));
        assertNotEquals(monetaryValue1, monetaryValue2);

        monetaryValue3 = monetaryValue3.subtract(new MonetaryValue("10"));
        monetaryValue4.subtract(new MonetaryValue("10"));
        assertEquals(monetaryValue3, new MonetaryValue(("10.99")));
        assertNotEquals(monetaryValue3, monetaryValue4);
    }

    @Test
    public void verifyImmutability5() {

        MonetaryValue monetaryValue1 = new MonetaryValue("20.99878", 5);
        MonetaryValue monetaryValue2 = new MonetaryValue("20.99878", 5);

        MonetaryValue monetaryValue3 = new MonetaryValue("20.99");
        MonetaryValue monetaryValue4 = new MonetaryValue("20.99");

        assertEquals(monetaryValue1, monetaryValue2);
        assertEquals(monetaryValue3, monetaryValue4);

        monetaryValue1 = monetaryValue1.multiply(5, 5);
        monetaryValue2.multiply(5, 5);
        assertNotEquals(monetaryValue1, monetaryValue2);

        monetaryValue3 = monetaryValue3.multiply(5);
        monetaryValue4.multiply(5);
        assertNotEquals(monetaryValue3, monetaryValue4);
    }

    @Test
    public void verifyImmutability6() {

        MonetaryValue monetaryValue1 = new MonetaryValue("20.99878", 5);
        MonetaryValue monetaryValue2 = new MonetaryValue("20.99878", 5);

        MonetaryValue monetaryValue3 = new MonetaryValue("20.99");
        MonetaryValue monetaryValue4 = new MonetaryValue("20.99");

        assertEquals(monetaryValue1, monetaryValue2);
        assertEquals(monetaryValue3, monetaryValue4);

//        monetaryValue1 = monetaryValue1.divide(5, 5);
//        monetaryValue2.divide(5, 5);
//        assertNotEquals(monetaryValue1, monetaryValue2);
//
//        monetaryValue3 = monetaryValue3.divide(5);
//        monetaryValue4.divide(5);
//        assertNotEquals(monetaryValue3, monetaryValue4);
    }

    @Test
    public void verifyAddMonetaryValueDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("80");
        MonetaryValue monetaryValue2 = new MonetaryValue("7.58");
        MonetaryValue sumOfValues_1_2 = monetaryValue1.add(monetaryValue2);
        MonetaryValue expectedSum_1_2 = new MonetaryValue("87.58");

        MonetaryValue monetaryValue3 = new MonetaryValue("20.15678", 5);
        MonetaryValue monetaryValue4 = new MonetaryValue("20.222", 3);
        MonetaryValue sumOfValues_3_4 = monetaryValue3.add(monetaryValue4);
        MonetaryValue expectedSum_3_4 = new MonetaryValue("40.38");

        assertEquals(expectedSum_1_2, sumOfValues_1_2);
        assertEquals(expectedSum_3_4, sumOfValues_3_4);
    }

    @Test
    public void verifyAddMonetaryValueArbitraryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("20.15678", 5);
        MonetaryValue monetaryValue2 = new MonetaryValue("20.222", 3);
        MonetaryValue sumOfValues_1_2 = monetaryValue1.add(monetaryValue2, 5);
        MonetaryValue expectedSum_1_2 = new MonetaryValue("40.37878", 5);

        MonetaryValue monetaryValue3 = new MonetaryValue("36.987654323989", 12);
        MonetaryValue monetaryValue4 = new MonetaryValue("1.001", 3);
        MonetaryValue sumOfValues_3_4 = monetaryValue3.add(monetaryValue4, 12);
        MonetaryValue expectedSum_3_4 = new MonetaryValue("37.988654324", 9);

        assertEquals(expectedSum_1_2, sumOfValues_1_2);
        assertEquals(expectedSum_3_4, sumOfValues_3_4);
    }

    @Test
    public void verifyAddMonetaryValueNegatives() {

        MonetaryValue monetaryValue1 = new MonetaryValue("-10.003", 3);
        MonetaryValue monetaryValue2 = new MonetaryValue("-5.001", 3);
        MonetaryValue sumOfValues_1_2_defaultMonetaryScale = monetaryValue1.add(monetaryValue2);
        MonetaryValue expectedSum_1_2_defaultMonetaryScale = new MonetaryValue("-15.00");
        MonetaryValue sumOfValues_1_2_arbitraryScale = monetaryValue1.add(monetaryValue2, 3);
        MonetaryValue expectedSum_1_2_arbitraryScale = new MonetaryValue("-15.004", 3);

        assertEquals(expectedSum_1_2_arbitraryScale, sumOfValues_1_2_arbitraryScale);
        assertEquals(expectedSum_1_2_defaultMonetaryScale, sumOfValues_1_2_defaultMonetaryScale);
    }

    @Test
    public void verifySubtractMonetaryValueNegatives() {

        MonetaryValue monetaryValue1 = new MonetaryValue("-10.003", 3);
        MonetaryValue monetaryValue2 = new MonetaryValue("-5.001", 3);

        MonetaryValue difference_1_2_defaultMonetaryScale = monetaryValue1.subtract(monetaryValue2);
        MonetaryValue expectedDifference_1_2_defaultMonetaryScale = new MonetaryValue("-5");

        MonetaryValue difference_1_2_arbitraryScale = monetaryValue1.subtract(monetaryValue2);
        MonetaryValue expectedDifference_1_2_arbitraryScale = new MonetaryValue("-5.002");

        assertEquals(expectedDifference_1_2_arbitraryScale, difference_1_2_arbitraryScale);
        assertEquals(expectedDifference_1_2_defaultMonetaryScale, difference_1_2_defaultMonetaryScale);
    }

    @Test
    public void verifyAddBigDecimalDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("58.01");
        BigDecimal bigDecimal = new BigDecimal("23.44");

        MonetaryValue sumOfValues = monetaryValue1.add(bigDecimal);
        MonetaryValue expectedSum = new MonetaryValue("81.45");

        assertEquals(expectedSum, sumOfValues);
    }

    @Test
    public void verifyAddBigDecimalArbitraryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("58.01943", 5);
        BigDecimal bigDecimal = new BigDecimal("23.442108");

        MonetaryValue sumOfValues1 = monetaryValue1.add(bigDecimal, 6);
        MonetaryValue expectedSum1 = new MonetaryValue("81.461538", 6);

        MonetaryValue sumOfValues2 = monetaryValue1.add(bigDecimal, 4);
        MonetaryValue expectedSum2 = new MonetaryValue("81.4615", 6);

        assertEquals(expectedSum1, sumOfValues1);
        assertEquals(expectedSum2, sumOfValues2);
    }

    @Test
    public void verifyAddDoubleDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("58.01");
        double doubleVal = 23.44d;

        MonetaryValue sumOfValues = monetaryValue1.add(doubleVal);
        MonetaryValue expectedSum = new MonetaryValue("81.45");

        assertEquals(expectedSum, sumOfValues);
    }

    @Test
    public void verifyAddDoubleArbitraryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("58.01943", 5);
        double doubleVal = 23.442108d;

        MonetaryValue sumOfValues1 = monetaryValue1.add(doubleVal, 6);
        MonetaryValue expectedSum1 = new MonetaryValue("81.461538", 6);

        MonetaryValue sumOfValues2 = monetaryValue1.add(doubleVal, 4);
        MonetaryValue expectedSum2 = new MonetaryValue("81.4615", 6);

        assertEquals(expectedSum1, sumOfValues1);
        assertEquals(expectedSum2, sumOfValues2);
    }

    @Test
    public void verifyAddIntDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("58.01");
        int intVal = 19;

        MonetaryValue sumOfValues = monetaryValue1.add(intVal);
        MonetaryValue expectedSum = new MonetaryValue("77.01");

        assertEquals(expectedSum, sumOfValues);
    }

    @Test
    public void verifyAddIntArbitraryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("58.0167", 4);
        int intVal = 19;

        MonetaryValue sumOfValues = monetaryValue1.add(intVal, 4);
        MonetaryValue expectedSum = new MonetaryValue("77.0167", 4);

        assertEquals(expectedSum, sumOfValues);
    }

    @Test
    public void verifyAddLongDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("58.01");
        long longValue = 5693872131L;

        MonetaryValue sumOfValues = monetaryValue1.add(longValue);
        MonetaryValue expectedSum = new MonetaryValue("5693872189.01");

        assertEquals(expectedSum, sumOfValues);
    }

    @Test
    public void verifyAddLongArbitraryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("58.0167", 4);
        long longValue = 5693872131L;

        MonetaryValue sumOfValues = monetaryValue1.add(longValue, 4);
        MonetaryValue expectedSum = new MonetaryValue("5693872189.0167", 4);

        assertEquals(expectedSum, sumOfValues);
    }

    @Test
    public void verifySubtractMonetaryValueDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("23.4756");
        MonetaryValue monetaryValue2 = new MonetaryValue("7.40");
        MonetaryValue difference_1_2 = monetaryValue1.subtract(monetaryValue2);
        MonetaryValue expectedDifference_1_2 = new MonetaryValue("16.08");

        MonetaryValue monetaryValue3 = new MonetaryValue("50.0094", 4);
        MonetaryValue monetaryValue4 = new MonetaryValue("50.0091", 4);
        MonetaryValue difference_3_4 = monetaryValue3.subtract(monetaryValue4);
        MonetaryValue expectedDifference_3_4 = new MonetaryValue("0");

        assertEquals(expectedDifference_1_2, difference_1_2);
        assertEquals(expectedDifference_3_4, difference_3_4);
    }

    @Test
    public void verifySubtractMonetaryValueArbitraryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("23.4756", 4);
        MonetaryValue monetaryValue2 = new MonetaryValue("7.40");
        MonetaryValue difference_1_2 = monetaryValue1.subtract(monetaryValue2, 4);
        MonetaryValue expectedDifference_1_2 = new MonetaryValue("16.0756", 4);

        MonetaryValue monetaryValue3 = new MonetaryValue("50.0094", 4);
        MonetaryValue monetaryValue4 = new MonetaryValue("50.0091", 4);
        MonetaryValue difference_3_4 = monetaryValue3.subtract(monetaryValue4, 4);
        MonetaryValue expectedDifference_3_4 = new MonetaryValue("0.0003", 4);

        MonetaryValue monetaryValue5 = new MonetaryValue("10.48776932", 8);
        MonetaryValue monetaryValue6 = new MonetaryValue("1.14873921", 8);
        MonetaryValue difference_5_6 = monetaryValue5.subtract(monetaryValue6, 8);
        MonetaryValue expectedDifference_5_6 = new MonetaryValue("9.33903011", 8);

        assertEquals(expectedDifference_1_2, difference_1_2);
        assertEquals(expectedDifference_3_4, difference_3_4);
        assertEquals(expectedDifference_5_6, difference_5_6);
    }

    @Test
    public void verifySubtractMonetaryValueWithNegativeResult() {

        MonetaryValue monetaryValue1 = new MonetaryValue("50.22");
        MonetaryValue monetaryValue2 = new MonetaryValue("60.19");
        MonetaryValue difference_1_2 = monetaryValue1.subtract(monetaryValue2);
        MonetaryValue expectedDifference_1_2 = new MonetaryValue("-9.97");

        MonetaryValue monetaryValue3 = new MonetaryValue("50.228", 3);
        MonetaryValue monetaryValue4 = new MonetaryValue("60.221", 3);
        MonetaryValue difference_3_4_defaultScale = monetaryValue3.subtract(monetaryValue4);
        MonetaryValue difference_3_4_arbitraryScale = monetaryValue3.subtract(monetaryValue4, 3);
        MonetaryValue expectedDifference_3_4_defaultScale = new MonetaryValue("-9.99");
        MonetaryValue expectedDifference_3_4_arbitraryScale = new MonetaryValue("-9.993", 3);

        assertEquals(expectedDifference_1_2, difference_1_2);
        assertEquals(expectedDifference_3_4_defaultScale, difference_3_4_defaultScale);
        assertEquals(expectedDifference_3_4_arbitraryScale, difference_3_4_arbitraryScale);
    }

    @Test
    public void verifySubtractBigDecimalDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("6755.91");
        BigDecimal bigDecimal = new BigDecimal("250.44");

        MonetaryValue difference = monetaryValue1.subtract(bigDecimal);
        MonetaryValue expectedDifference = new MonetaryValue("6505.47");

        assertEquals(expectedDifference, difference);
    }

    @Test
    public void verifySubtractBigDecimalArbitraryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("1023.9487", 4);
        BigDecimal bigDecimal = new BigDecimal("630.666545");

        MonetaryValue difference1 = monetaryValue1.subtract(bigDecimal, 4);
        MonetaryValue difference2 = monetaryValue1.subtract(bigDecimal, 6);

        MonetaryValue expectedDifference1 = new MonetaryValue("393.2822", 4);
        MonetaryValue expectedDifference2 = new MonetaryValue("393.282155", 6);

        assertTrue(difference1.equals(expectedDifference1));
        assertTrue(difference2.equals(expectedDifference2));
    }

    @Test
    public void verifySubtractDoubleDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("6755.91");
        double doubleVal = 250.44d;

        MonetaryValue difference = monetaryValue1.subtract(doubleVal);
        MonetaryValue expectedDifference = new MonetaryValue("6505.47");

        assertEquals(expectedDifference, difference);
    }

    @Test
    public void verifySubtractDoubleArbitraryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("1023.9487", 4);
        double doubleVal = 630.666545d;

        MonetaryValue difference1 = monetaryValue1.subtract(doubleVal, 4);
        MonetaryValue difference2 = monetaryValue1.subtract(doubleVal, 6);

        MonetaryValue expectedDifference1 = new MonetaryValue("393.2822", 4);
        MonetaryValue expectedDifference2 = new MonetaryValue("393.282155", 6);

        assertTrue(difference1.equals(expectedDifference1));
        assertTrue(difference2.equals(expectedDifference2));
    }

    @Test
    public void verifySubtractIntDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("6755.91");
        int intVal = 250;

        MonetaryValue difference1 = monetaryValue1.subtract(intVal);
        MonetaryValue expectedDifference1 = new MonetaryValue("6505.91");

        assertEquals(expectedDifference1, difference1);
    }

    @Test
    public void verifySubtractIntArbitraryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("6755.9134", 4);
        MonetaryValue monetaryValue2 = new MonetaryValue("6755.9189843", 7);
        int intVal = 250;

        MonetaryValue difference1 = monetaryValue1.subtract(intVal, 4);
        MonetaryValue difference2 = monetaryValue2.subtract(intVal);
        MonetaryValue difference2a = monetaryValue2.subtract(intVal, 7);

        MonetaryValue expectedDifference1 = new MonetaryValue("6505.9134", 4);
        MonetaryValue expectedDifference2 = new MonetaryValue("6505.92");
        MonetaryValue expectedDifference2a = new MonetaryValue("6505.9189843", 7);

        assertEquals(expectedDifference1, difference1);
        assertEquals(expectedDifference2, difference2);
        assertEquals(expectedDifference2a, difference2a);
    }

    @Test
    public void verifySubtractLongDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("676678.44");
        long longVal = 14574823456L;

        MonetaryValue difference = monetaryValue1.subtract(longVal);
        MonetaryValue expectedDifference = new MonetaryValue("-14574146777.56");

        assertEquals(expectedDifference, difference);
    }

    @Test
    public void verifySubtractLongArbitraryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("676678.4467", 4);
        long longVal = 14574823456L;

        MonetaryValue difference = monetaryValue1.subtract(longVal, 4);
        MonetaryValue expectedDifference = new MonetaryValue("-14574146777.5533", 4);

        assertEquals(expectedDifference, difference);
    }

    @Test
    public void verifyMultiplyByBigDecimalArbitraryScale() {

        int scale1 = 4;
        int scale2 = 7;

        MonetaryValue monetaryValue1 = new MonetaryValue("7.3986", scale1);
        BigDecimal multiplicand = new BigDecimal("6.444");

        MonetaryValue product1 = monetaryValue1.multiply(multiplicand, scale1);
        MonetaryValue product2 = monetaryValue1.multiply(multiplicand, scale2);

        MonetaryValue expectedProduct1 = new MonetaryValue("47.6766", scale1);
        MonetaryValue expectedProduct2 = new MonetaryValue("47.6765784", scale2);

        assertEquals(expectedProduct1, product1);
        assertEquals(expectedProduct2, product2);
    }

    @Test
    public void verifyMultiplyByBigDecimalMaxScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("15.68746898123465", 14);
        BigDecimal multiplicand = new BigDecimal("2.4385");

        MonetaryValue product1 = monetaryValue1.multiply(multiplicand, 14);
        MonetaryValue expectedProduct1 = new MonetaryValue("38.2538931107", 10);

        assertEquals(expectedProduct1, product1);
    }

    @Test
    public void verifyMultiplyByBigDecimalDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("15.68746898123465", 14);
        BigDecimal multiplicand = new BigDecimal("2.4385");

        MonetaryValue product1 = monetaryValue1.multiply(multiplicand);
        MonetaryValue expectedProduct1 = new MonetaryValue("38.25");

        assertEquals(expectedProduct1, product1);
    }

    @Test
    public void verifyMultiplyByMonetaryValueMaxScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("15.68746898123465", 14);
        BigDecimal multiplicand = new BigDecimal("2.4385");

        MonetaryValue product1 = monetaryValue1.multiply(multiplicand, 14);
        MonetaryValue expectedProduct1 = new MonetaryValue("38.2538931107", 10);

        assertEquals(expectedProduct1, product1);
    }

    @Test
    public void verifyMultiplyByMonetaryValueDefaultMonetaryScale() {

        MonetaryValue monetaryValue1 = new MonetaryValue("15.68746898123465", 14);
        BigDecimal multiplicand = new BigDecimal("2.4385");

        MonetaryValue product1 = monetaryValue1.multiply(multiplicand);
        MonetaryValue expectedProduct1 = new MonetaryValue("38.25");

        assertEquals(expectedProduct1, product1);
    }

    @Test
    public void verifyMultiplyByDouble() {

        MonetaryValue monetaryValue1 = new MonetaryValue("460.22");
        double multiplicand = 3.4895d;

        MonetaryValue productWithArbitraryScale = monetaryValue1.multiply(multiplicand, 4);
        MonetaryValue productWithDefaultMonetaryScale = monetaryValue1.multiply(multiplicand);

        MonetaryValue expectedProductWithArbitraryScale = new MonetaryValue("1605.9377", 4);
        MonetaryValue expectedProductWithDefaultMonetaryScale = new MonetaryValue("1605.94");

        assertEquals(expectedProductWithArbitraryScale, productWithArbitraryScale);
        assertEquals(expectedProductWithDefaultMonetaryScale, productWithDefaultMonetaryScale);
    }

    @Test
    public void verifyMultiplyByInt() {

        MonetaryValue monetaryValue1 = new MonetaryValue("460.22");
        MonetaryValue monetaryValue2 = new MonetaryValue("55.78455", 5);

        int multiplicand = 6;

        MonetaryValue product1DefaultMonetaryScale = monetaryValue1.multiply(multiplicand);
        MonetaryValue expectedProduct1DefaultMonetaryScale = new MonetaryValue("2761.32");

        MonetaryValue product2ArbitraryScale = monetaryValue2.multiply(multiplicand, 5);
        MonetaryValue expectedProduct2ArbitraryScale = new MonetaryValue("334.7073", 4);

        assertEquals(expectedProduct1DefaultMonetaryScale, product1DefaultMonetaryScale);
        assertEquals(expectedProduct2ArbitraryScale, product2ArbitraryScale);
    }

    @Test
    public void verifyMultiplyByLong() {

        MonetaryValue monetaryValue1 = new MonetaryValue("7.34");
        MonetaryValue monetaryValue2 = new MonetaryValue("1.78455", 5);

        long multiplicand = 68947638912L;

        MonetaryValue product1DefaultMonetaryScale = monetaryValue1.multiply(multiplicand);
        MonetaryValue expectedProduct1DefaultMonetaryScale = new MonetaryValue("506075669614.08");

        MonetaryValue product2ArbitraryScale = monetaryValue2.multiply(multiplicand, 5);
        MonetaryValue expectedProduct2ArbitraryScale = new MonetaryValue("123040509020.4096", 4);

        MonetaryValue product3ArbitraryScale = monetaryValue2.multiply(multiplicand, 3);
        MonetaryValue expectedProduct3ArbitraryScale = new MonetaryValue("123040509020.41", 2);

        assertEquals(expectedProduct1DefaultMonetaryScale, product1DefaultMonetaryScale);
        assertEquals(expectedProduct2ArbitraryScale, product2ArbitraryScale);
        assertEquals(expectedProduct3ArbitraryScale, product3ArbitraryScale);
    }

    @Test
    public void verifyDivideByBigDecimal() {

        MonetaryValue monetaryValue1 = new MonetaryValue("567.44878", 5);
        BigDecimal divisor = new BigDecimal("14.687");

        BigDecimal quotient1MaxScaleBd = monetaryValue1.divide(divisor, 15);
        MonetaryValue quotient1MaxScale = new MonetaryValue(quotient1MaxScaleBd, MonetaryValue.DECIMAL_SCALE_MAX);
        BigDecimal quotient2ArbitraryScaleBd = monetaryValue1.divide(divisor, 5);
        MonetaryValue quotient2ArbitraryScale = new MonetaryValue(quotient2ArbitraryScaleBd, MonetaryValue.DECIMAL_SCALE_MAX);
        BigDecimal quotient3DefaultMonetaryScaleBd = monetaryValue1.divide(divisor);
        MonetaryValue quotient3DefaultMonetaryScale = new MonetaryValue(quotient3DefaultMonetaryScaleBd, MonetaryValue.DECIMAL_SCALE_MAX);

        MonetaryValue expectedQuotient1MaxScale = new MonetaryValue("38.6361258256", MonetaryValue.DECIMAL_SCALE_MAX);
        MonetaryValue expectedQuotient2ArbitraryScale = new MonetaryValue("38.63613", 5);
        MonetaryValue expectedQuotient3DefaultMonetaryScale = new MonetaryValue("38.64");

        assertEquals(expectedQuotient1MaxScale, quotient1MaxScale);
        assertEquals(expectedQuotient2ArbitraryScale, quotient2ArbitraryScale);
        assertEquals(expectedQuotient3DefaultMonetaryScale, quotient3DefaultMonetaryScale);
    }

    @Test
    public void verifyDivideByDouble() {

        MonetaryValue monetaryValue1 = new MonetaryValue("567.44878", 5);
        double divisor = 14.687d;

        BigDecimal quotient1MaxScaleBd = monetaryValue1.divide(divisor, 15);
        MonetaryValue quotient1MaxScale = new MonetaryValue(quotient1MaxScaleBd, MonetaryValue.DECIMAL_SCALE_MAX);
        BigDecimal quotient2ArbitraryScaleBd = monetaryValue1.divide(divisor, 5);
        MonetaryValue quotient2ArbitraryScale = new MonetaryValue(quotient2ArbitraryScaleBd, MonetaryValue.DECIMAL_SCALE_MAX);
        BigDecimal quotient3DefaultMonetaryScaleBd = monetaryValue1.divide(divisor);
        MonetaryValue quotient3DefaultMonetaryScale = new MonetaryValue(quotient3DefaultMonetaryScaleBd, MonetaryValue.DECIMAL_SCALE_MAX);

        MonetaryValue expectedQuotient1MaxScale = new MonetaryValue("38.6361258256", MonetaryValue.DECIMAL_SCALE_MAX);
        MonetaryValue expectedQuotient2ArbitraryScale = new MonetaryValue("38.63613", 5);
        MonetaryValue expectedQuotient3DefaultMonetaryScale = new MonetaryValue("38.64");

        assertEquals(expectedQuotient1MaxScale, quotient1MaxScale);
        assertEquals(expectedQuotient2ArbitraryScale, quotient2ArbitraryScale);
        assertEquals(expectedQuotient3DefaultMonetaryScale, quotient3DefaultMonetaryScale);
    }

    @Test
    public void verifyDivideByInt() {

        MonetaryValue monetaryValue1 = new MonetaryValue("567.44878", 5);
        int divisor = 8;

        BigDecimal quotient1MaxScale = monetaryValue1.divide(divisor, 15);
        BigDecimal quotient2ArbitraryScale = monetaryValue1.divide(divisor, 5);
        BigDecimal quotient3DefaultMonetaryScale = monetaryValue1.divide(divisor);

        MonetaryValue expectedQuotient1MaxScale = new MonetaryValue("70.9310975", MonetaryValue.DECIMAL_SCALE_MAX);
        MonetaryValue expectedQuotient2ArbitraryScale = new MonetaryValue("70.9311", 4);
        MonetaryValue expectedQuotient3DefaultMonetaryScale = new MonetaryValue("70.93");

        assertEquals((Double)expectedQuotient1MaxScale.getDoubleVal(), (Double)quotient1MaxScale.doubleValue());
        assertEquals((Double)expectedQuotient2ArbitraryScale.getDoubleVal(), (Double)quotient2ArbitraryScale.doubleValue());
    }

    @Test
    public void verifyDivideByLong() {

        MonetaryValue monetaryValue1 = new MonetaryValue("5678453212.44878", 5);
        long divisor = 7876543338L;

        BigDecimal quotient1MaxScaleBd = monetaryValue1.divide(divisor, 15);
        MonetaryValue quotient1MaxScale = new MonetaryValue(quotient1MaxScaleBd, MonetaryValue.DECIMAL_SCALE_MAX);
        BigDecimal quotient2ArbitraryScaleBd = monetaryValue1.divide(divisor, 5);
        MonetaryValue quotient2ArbitraryScale = new MonetaryValue(quotient2ArbitraryScaleBd, MonetaryValue.DECIMAL_SCALE_MAX);
        BigDecimal quotient3DefaultMonetaryScaleBd = monetaryValue1.divide(divisor);
        MonetaryValue quotient3DefaultMonetaryScale = new MonetaryValue(quotient3DefaultMonetaryScaleBd, MonetaryValue.DECIMAL_SCALE_MAX);


        MonetaryValue expectedQuotient1MaxScale = new MonetaryValue("0.7209321359", MonetaryValue.DECIMAL_SCALE_MAX);
        MonetaryValue expectedQuotient2ArbitraryScale = new MonetaryValue("0.72093", 5);
        MonetaryValue expectedQuotient3DefaultMonetaryScale = new MonetaryValue("0.72");

        assertEquals(expectedQuotient1MaxScale.getDoubleVal(), quotient1MaxScale.getDoubleVal());
        assertEquals(expectedQuotient2ArbitraryScale.getDoubleVal(), quotient2ArbitraryScale.getDoubleVal());
        assertEquals(expectedQuotient3DefaultMonetaryScale.getDoubleVal(), quotient3DefaultMonetaryScale.getDoubleVal());
    }

    @Test
    public void verifyDivideByMonetaryValue() {

        MonetaryValue monetaryValue1 = new MonetaryValue("23569.44");
        MonetaryValue monetaryValue2 = new MonetaryValue("33.99");

        BigDecimal quotient1 = monetaryValue1.divide(monetaryValue2, 5);
        BigDecimal expectedQuotient1 = new BigDecimal("693.42277");

        assertEquals(expectedQuotient1, quotient1);
    }

    @Test
    public void verifyDivideByMonetaryValue2() {

        MonetaryValue monetaryValue1 = new MonetaryValue("23569.44");
        MonetaryValue monetaryValue2 = new MonetaryValue("33.99");

        BigDecimal quotient1 = monetaryValue1.divide(monetaryValue2);
        BigDecimal expectedQuotient1 = new BigDecimal("693.42");

        assertEquals(expectedQuotient1, quotient1);
    }

    @Test
    public void verifyEmptyStringValue() {

        String emptyString = "";

        BigDecimal expectedResultBigDecimalVal = new BigDecimal("0.00");
        MonetaryValue monetaryValueFromString = new MonetaryValue(emptyString);

        assertEquals(expectedResultBigDecimalVal, monetaryValueFromString.getBigDecimalVal());
    }

    @Test
    public void verifyEmptyStringValueWithScale() {

        String emptyString = "";

        BigDecimal expectedResultBigDecimalVal = new BigDecimal("0.00000");
        MonetaryValue monetaryValueFromString = new MonetaryValue(emptyString, 5);

        assertEquals(expectedResultBigDecimalVal, monetaryValueFromString.getBigDecimalVal());
    }

    @Test
    public void verifyNullStringValue() {

        String nullString = null;

        BigDecimal expectedResultBigDecimalVal = new BigDecimal("0.00");
        MonetaryValue monetaryValueFromString = new MonetaryValue(nullString);

        assertEquals(expectedResultBigDecimalVal, monetaryValueFromString.getBigDecimalVal());
    }

    @Test
    public void verifyNullStringValueWithScale() {

        String nullString = null;

        BigDecimal expectedResultBigDecimalVal = new BigDecimal("0.00000");
        MonetaryValue monetaryValueFromString = new MonetaryValue(nullString, 5);

        assertEquals(expectedResultBigDecimalVal, monetaryValueFromString.getBigDecimalVal());
    }

    @Test
    public void verifyNullBigDecimalValue() {

        BigDecimal nullBigDecimal = null;

        BigDecimal expectedResultBigDecimalVal = new BigDecimal("0.00");
        MonetaryValue monetaryValueFromString = new MonetaryValue(nullBigDecimal);

        assertEquals(expectedResultBigDecimalVal, monetaryValueFromString.getBigDecimalVal());
    }

    @Test
    public void verifyNullBigDecimalValueWithScale() {

        BigDecimal nullBigDecimal = null;

        BigDecimal expectedResultBigDecimalVal = new BigDecimal("0.00000");
        MonetaryValue monetaryValueFromString = new MonetaryValue(nullBigDecimal, 5);

        assertEquals(expectedResultBigDecimalVal, monetaryValueFromString.getBigDecimalVal());
    }

    @Test
    public void verifyCompareToWithNull() {

        MonetaryValue monetaryValue1 = new MonetaryValue("56.5778", 4);
        MonetaryValue monetaryValue2 = new MonetaryValue("0.00", 4);

        MonetaryValue monetaryValueNull = null;

        assertEquals(1, monetaryValue1.compareTo(monetaryValueNull));
        assertEquals(0, monetaryValue2.compareTo(monetaryValueNull));
    }

    @Test
    public void verifySafeEquals() {

        MonetaryValue monetaryValue1 = new MonetaryValue("56.5778", 4);
        MonetaryValue monetaryValue2 = new MonetaryValue("0.00", 4);
        MonetaryValue monetaryValue3 = new MonetaryValue("56.5778", 4);
        MonetaryValue monetaryValue4 = new MonetaryValue();
        MonetaryValue monetaryValue5 = new MonetaryValue();
        MonetaryValue monetaryValueNull = null;

        assertFalse(monetaryValue1.safeEquals(monetaryValue2));
        assertTrue(monetaryValue1.safeEquals(monetaryValue3));
        assertFalse(monetaryValue1.safeEquals(monetaryValue4));
        assertFalse(monetaryValue1.safeEquals(monetaryValueNull));
        assertTrue(monetaryValue4.safeEquals(monetaryValue5));
        assertFalse(monetaryValue4.safeEquals(monetaryValueNull));

        boolean npeThrownWhenCallingFromNull = false;
        try {
            boolean nullCompare = monetaryValueNull.safeEquals(monetaryValue1);
        } catch(NullPointerException e) {
            npeThrownWhenCallingFromNull = true;
        }
        assertTrue(npeThrownWhenCallingFromNull);
    }

}