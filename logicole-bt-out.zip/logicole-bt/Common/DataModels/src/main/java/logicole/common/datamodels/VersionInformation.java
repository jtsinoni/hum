package logicole.common.datamodels;

import java.util.ArrayList;
import java.util.List;

public class VersionInformation {
    public String name;
    public String componentType;
    public String implementationVersion;
    public String buildDate;
    public String logicoleVersion;
    public List<VersionInformation> nestedVersionInformation = new ArrayList<>();
}
