package logicole.common.datamodels;

import org.bson.types.ObjectId;

public interface IPersistedEntity {
    String getId();

    ObjectId getObjectId();
}
