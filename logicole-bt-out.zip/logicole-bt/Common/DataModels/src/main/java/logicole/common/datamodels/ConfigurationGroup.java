package logicole.common.datamodels;

import java.util.ArrayList;
import java.util.List;

public class ConfigurationGroup {
    public String groupName;
    public String owner;
    public List<Configuration> groupConfigurations= new ArrayList<>();
}
