package logicole.common.datamodels;

import logicole.common.datamodels.reccurringfunctions.RecurringFunction;
import logicole.common.general.annotations.LcJsonFormatDate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HealthCheckResult {
    public final String componentName;
    public final String componentType;
    public final EHealthStatus componentResult;
    public EHealthStatus overallResult;
    @LcJsonFormatDate
    public final Date checkDate = new Date();

    public final List<HealthCheckResult> nestedHealthChecks = new ArrayList<>();

    public HealthCheckResult(){
        this("Unknown", "Unknown",EHealthStatus.Unknown, EHealthStatus.Unknown);
    }

    public HealthCheckResult(String componentName, String componentType, EHealthStatus componentResult,  EHealthStatus overalResult){
        this.componentName = componentName;
        this.componentType = componentType;
        this.componentResult = componentResult;
        this.overallResult = overalResult;
    }

    public enum EHealthStatus{
        Unknown,
        Skipped,
        Good,
        Failed;
    }
}
