package logicole.common.datamodels;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;
import java.math.BigDecimal;

public class MonetarySerializer extends JsonSerializer<MonetaryValue> {

    @Override
    public void serialize(MonetaryValue value, JsonGenerator jgen, SerializerProvider provider) throws IOException {

        if (value == null) {
            value = new MonetaryValue("0.00");
        }

        BigDecimal bigDecimalVal = value.getBigDecimalVal();
        jgen.writeNumber(bigDecimalVal);
    }

}
