package logicole.common.datamodels;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import logicole.common.general.util.string.StringUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Objects;


@JsonSerialize(using = MonetarySerializer.class)
@JsonDeserialize(using = MonetaryDeserializer.class)
public class MonetaryValue {

    public static final int DECIMAL_SCALE_MONETARY = 2;
    public static final int DECIMAL_SCALE_MAX = 10;
    public static final RoundingMode DECIMAL_ROUNDING_MODE_DEFAULT = RoundingMode.HALF_UP;
    public static final MonetaryValue ZERO = new MonetaryValue();

    private final BigDecimal val;

    public MonetaryValue() {
        val = new BigDecimal("0.00").setScale(DECIMAL_SCALE_MONETARY, DECIMAL_ROUNDING_MODE_DEFAULT);
    }

    public MonetaryValue(String stringVal, int scale) {
        int theScale = Math.min(scale, DECIMAL_SCALE_MAX);
        if (StringUtil.isBlankOrNull(stringVal)) {
            stringVal = "0.00";
        }
        val = new BigDecimal(stringVal.trim()).setScale(theScale, DECIMAL_ROUNDING_MODE_DEFAULT);
    }

    public MonetaryValue(String stringVal) {
        if (StringUtil.isBlankOrNull(stringVal)) {
            stringVal = "0.00";
        }
        val = new BigDecimal(stringVal.trim()).setScale(DECIMAL_SCALE_MONETARY, DECIMAL_ROUNDING_MODE_DEFAULT);
    }

    // This constructor used by MonetaryTypeConverter for mapping to MongoDB Decimal128
    public MonetaryValue(BigDecimal bigDecimalVal, int scale) {
        int theScale = Math.min(scale, DECIMAL_SCALE_MAX);
        if (bigDecimalVal == null) {
            bigDecimalVal = new BigDecimal("0.00");
        }
        val = bigDecimalVal.setScale(theScale, DECIMAL_ROUNDING_MODE_DEFAULT);
    }

    public MonetaryValue(BigDecimal bigDecimalVal) {
        if (bigDecimalVal == null) {
            bigDecimalVal = new BigDecimal("0.00");
        }
        val = bigDecimalVal.setScale(DECIMAL_SCALE_MONETARY, DECIMAL_ROUNDING_MODE_DEFAULT);
    }

    public MonetaryValue(double doubleVal, int scale) {
        int theScale = Math.min(scale, DECIMAL_SCALE_MAX);
        val = BigDecimal.valueOf(doubleVal).setScale(theScale, DECIMAL_ROUNDING_MODE_DEFAULT);
    }

    public MonetaryValue(double doubleVal) {
        val = BigDecimal.valueOf(doubleVal).setScale(DECIMAL_SCALE_MONETARY, DECIMAL_ROUNDING_MODE_DEFAULT);
    }

    public MonetaryValue(int intVal, int scale) {
        int theScale = Math.min(scale, DECIMAL_SCALE_MAX);
        val = new BigDecimal(intVal).setScale(theScale, DECIMAL_ROUNDING_MODE_DEFAULT);
    }

    public MonetaryValue(int intVal) {
        val = new BigDecimal(intVal).setScale(DECIMAL_SCALE_MONETARY, DECIMAL_ROUNDING_MODE_DEFAULT);
    }

    public MonetaryValue(long longVal, int scale) {
        int theScale = Math.min(scale, DECIMAL_SCALE_MAX);
        val = BigDecimal.valueOf(longVal).setScale(theScale, DECIMAL_ROUNDING_MODE_DEFAULT);
    }

    public MonetaryValue(long longVal) {
        val = BigDecimal.valueOf(longVal).setScale(DECIMAL_SCALE_MONETARY, DECIMAL_ROUNDING_MODE_DEFAULT);
    }

    public int compareTo(MonetaryValue value) {

        int retval;

        if (value == null) {
            value = new MonetaryValue();
        }

        BigDecimal thisBigDecimal = this.getBigDecimalVal();
        BigDecimal thatBigDecimal = value.getBigDecimalVal();
        retval = thisBigDecimal.compareTo(thatBigDecimal);
        return retval;
    }

    @Override
    public boolean equals(Object other) {
        //This works different than for BigDecimal. For this, diffs in scale due to trailing zeros don't affect it.
        //For example, 56 equals 56.0 equals 56.000.
        boolean retval = false;
        if (other instanceof MonetaryValue && (other == this || this.compareTo((MonetaryValue) other) == 0)) {
            retval = true;
        }
        return retval;
    }

    public boolean safeEquals(Object other) {
        if (other == null) {
            return false;
        }
        return equals(other);
    }

    @Override
    public int hashCode() {
        return Objects.hash(val);
    }

    public MonetaryValue roundToScale(int desiredScale) {
        int theScale = Math.min(desiredScale, DECIMAL_SCALE_MAX);
        return new MonetaryValue(this.val, theScale);
    }

    public MonetaryValue roundToMonetaryScale() {
        return roundToScale(DECIMAL_SCALE_MONETARY);
    }

    public Double getDoubleVal() {
        return val.doubleValue();
    }

    public float getFloatVal() {
        return val.floatValue();
    }

    public BigDecimal getBigDecimalVal() {
        return val;
    }

    public String getStringVal() {
        return val.toString();
    }

    public String getUSCurrencyFormat(){
        String retVal;
        if(val != null){
            retVal = NumberFormat.getCurrencyInstance(new Locale("en", "US")).format(getDoubleVal());
        }else{
            retVal = NumberFormat.getCurrencyInstance(new Locale("en", "US")).format(0);
        }
        return retVal;
    }

    public int getScale() {
        return val.scale();
    }

    public MonetaryValue add(MonetaryValue value, int scale) {

        MonetaryValue retval;

        if (value == null) {
            value = new MonetaryValue();
        }

        BigDecimal thisBigDecimal = this.getBigDecimalVal();
        BigDecimal thatBigDecimal = value.getBigDecimalVal();
        BigDecimal newBigDecimal = thisBigDecimal.add(thatBigDecimal);
        retval = new MonetaryValue(newBigDecimal, scale);
        return retval;
    }

    public MonetaryValue add(MonetaryValue value) {
        return add(value, DECIMAL_SCALE_MONETARY);
    }

    public MonetaryValue add(BigDecimal value, int scale) {

        if (value == null) {
            value = new BigDecimal("0.00");
        }

        MonetaryValue mvValue = new MonetaryValue(value, scale);
        return add(mvValue, scale);
    }

    public MonetaryValue add(BigDecimal value) {
        return add(value, DECIMAL_SCALE_MONETARY);
    }

    public MonetaryValue add(double value, int scale) {
        MonetaryValue mvValue = new MonetaryValue(value, scale);
        return add(mvValue, scale);
    }

    public MonetaryValue add(double value) {
        return add(value, DECIMAL_SCALE_MONETARY);
    }

    public MonetaryValue add(int value, int scale) {
        MonetaryValue mvValue = new MonetaryValue(value, scale);
        return add(mvValue, scale);
    }

    public MonetaryValue add(int value) {
        return add(value, DECIMAL_SCALE_MONETARY);
    }

    public MonetaryValue add(long value, int scale) {
        MonetaryValue mvValue = new MonetaryValue(value, scale);
        return add(mvValue, scale);
    }

    public MonetaryValue add(long value) {
        return add(value, DECIMAL_SCALE_MONETARY);
    }

    public MonetaryValue subtract(MonetaryValue value, int scale) {

        MonetaryValue retval;

        if (value == null) {
            value = new MonetaryValue();
        }

        BigDecimal thisBigDecimal = this.getBigDecimalVal();
        BigDecimal thatBigDecimal = value.getBigDecimalVal();
        BigDecimal newBigDecimal = thisBigDecimal.subtract(thatBigDecimal);
        retval = new MonetaryValue(newBigDecimal, scale);
        return retval;
    }

    public MonetaryValue subtract(MonetaryValue value) {
        return subtract(value, DECIMAL_SCALE_MONETARY);
    }

    public MonetaryValue subtract(BigDecimal value, int scale) {

        if (value == null) {
            value = new BigDecimal("0.00");
        }

        MonetaryValue mvValue = new MonetaryValue(value, scale);
        return subtract(mvValue, scale);
    }

    public MonetaryValue subtract(BigDecimal value) {
        return subtract(value, DECIMAL_SCALE_MONETARY);
    }

    public MonetaryValue subtract(double value, int scale) {
        MonetaryValue mvValue = new MonetaryValue(value, scale);
        return subtract(mvValue, scale);
    }

    public MonetaryValue subtract(double value) {
        return subtract(value, DECIMAL_SCALE_MONETARY);
    }

    public MonetaryValue subtract(int value, int scale) {
        MonetaryValue mvValue = new MonetaryValue(value, scale);
        return subtract(mvValue, scale);
    }

    public MonetaryValue subtract(int value) {
        return subtract(value, DECIMAL_SCALE_MONETARY);
    }

    public MonetaryValue subtract(long value, int scale) {
        MonetaryValue mvValue = new MonetaryValue(value, scale);
        return subtract(mvValue, scale);
    }

    public MonetaryValue subtract(long value) {
        return subtract(value, DECIMAL_SCALE_MONETARY);
    }

    public MonetaryValue multiply(BigDecimal multiplicand, int scale) {

        MonetaryValue retval;

        if (multiplicand == null) {
            multiplicand = new BigDecimal("1");
        }

        BigDecimal thisBigDecimal = this.getBigDecimalVal();
        BigDecimal bigDecimalResult = thisBigDecimal.multiply(multiplicand);
        retval = new MonetaryValue(bigDecimalResult, scale);
        return retval;
    }

    public MonetaryValue multiply(BigDecimal multiplicand) {
        return multiply(multiplicand, DECIMAL_SCALE_MONETARY);
    }

    public MonetaryValue multiply(double multiplicand, int scale) {
        return multiply(BigDecimal.valueOf(multiplicand), scale);
    }

    public MonetaryValue multiply(double multiplicand) {
        return multiply(BigDecimal.valueOf(multiplicand));
    }

    public MonetaryValue multiply(int multiplicand, int scale) {
        return multiply(new BigDecimal(multiplicand), scale);
    }

    public MonetaryValue multiply(int multiplicand) {
        return multiply(new BigDecimal(multiplicand));
    }

    public MonetaryValue multiply(long multiplicand, int scale) {
        return multiply(BigDecimal.valueOf(multiplicand), scale);
    }

    public MonetaryValue multiply(long multiplicand) {
        return multiply(BigDecimal.valueOf(multiplicand));
    }

    public BigDecimal divide(BigDecimal divisor, int scale) {

        if (divisor == null) {
            divisor = new BigDecimal("1");
        }

        BigDecimal thisBigDecimal = this.getBigDecimalVal();
        BigDecimal bigDecimalResult = thisBigDecimal.divide(
                divisor, scale, MonetaryValue.DECIMAL_ROUNDING_MODE_DEFAULT);
        return bigDecimalResult;
    }

    public BigDecimal divide(BigDecimal divisor) {
        return divide(divisor, DECIMAL_SCALE_MONETARY);
    }

    public BigDecimal divide(MonetaryValue divisor, int scale) {

        BigDecimal retval;

        if (divisor == null) {
            divisor = new MonetaryValue("1");
        }

        BigDecimal thisBigDecimal = this.getBigDecimalVal();
        BigDecimal divisorBigDecimal = divisor.getBigDecimalVal();
        retval = thisBigDecimal.divide(
                divisorBigDecimal, scale, MonetaryValue.DECIMAL_ROUNDING_MODE_DEFAULT);
        return retval;
    }

    public BigDecimal divide(MonetaryValue divisor) {
        return divide(divisor, DECIMAL_SCALE_MONETARY);
    }

    public BigDecimal divide(double divisor, int scale) {
        return divide(BigDecimal.valueOf(divisor), scale);
    }

    public BigDecimal divide(double divisor) {
        return divide(BigDecimal.valueOf(divisor));
    }

    public BigDecimal divide(int divisor, int scale) {
        return divide(new BigDecimal(divisor), scale);
    }

    public BigDecimal divide(int divisor) {
        return divide(new BigDecimal(divisor));
    }

    public BigDecimal divide(long divisor, int scale) {
        return divide(BigDecimal.valueOf(divisor), scale);
    }

    public BigDecimal divide(long divisor) {
        return divide(BigDecimal.valueOf(divisor));
    }

    public boolean greaterThanZero() {
        return this.compareTo(MonetaryValue.ZERO) > 0;
    }

    public boolean lessThanZero() {
        return this.compareTo(MonetaryValue.ZERO) < 0;
    }

    public boolean equalZero() {
        return this.compareTo(MonetaryValue.ZERO) == 0;
    }
    public boolean notEqualZero() {
        return this.compareTo(MonetaryValue.ZERO) != 0;
    }
}
