package logicole.common.datamodels;

import logicole.common.general.configuration.FileConfiguration;

import java.util.ArrayList;
import java.util.List;

public class ConfigurationCollection {
    public String title;
    public List<ConfigurationGroup> configurationGroupList = new ArrayList<>();
    public List<FileConfiguration> fileConfigurationList = new ArrayList<>();

}
