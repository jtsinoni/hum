package logicole.common.datamodels;

import logicole.common.datamodels.user.UserProfile;

import java.util.ArrayList;
import java.util.List;

public class DataUploadObject {
    public int count;
    public String fileType;
    public String data;
    public UserProfile submitter;
    public List<UserProfile> usersToNotify = new ArrayList<>();
}
