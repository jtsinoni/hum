package logicole.common.datamodels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.general.annotations.LcJsonFormatDate;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Note extends PersistedEntity {

    public String noteId;  // Not an _id, but a GUID
    public String noteText;
    public String section;
    public String firstName;
    public String lastName;
    public String userId;
    @LcJsonFormatDate
    public Date dateCreated;
    @LcJsonFormatDate
    public Date dateModified;
}
