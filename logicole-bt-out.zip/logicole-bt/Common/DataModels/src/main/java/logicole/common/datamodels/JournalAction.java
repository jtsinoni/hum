package logicole.common.datamodels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.general.annotations.LcJsonFormatDate;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class JournalAction {
    public String journalActionId;  // Not an _id, but a GUID
    public String journalAction;
    public String firstName;
    public String lastName;
    public String userId;
    @LcJsonFormatDate
    public Date createdDate;
    @LcJsonFormatDate
    public Date modifiedDate;
    @LcJsonFormatDate
    public Date requiredDate;
    @LcJsonFormatDate
    public Date completedDate;
}
