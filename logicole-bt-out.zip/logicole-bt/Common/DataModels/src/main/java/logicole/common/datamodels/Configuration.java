package logicole.common.datamodels;

import org.bson.codecs.pojo.annotations.BsonIgnore;

public class Configuration extends PersistedEntity {

    public String owner;
    public String name;
    public String value;

    @BsonIgnore
    public boolean userEditable;

}
