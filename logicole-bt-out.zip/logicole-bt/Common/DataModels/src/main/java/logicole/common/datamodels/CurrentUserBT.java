package logicole.common.datamodels;

import logicole.common.datamodels.user.CurrentUser;

import javax.enterprise.context.RequestScoped;

@RequestScoped
public class CurrentUserBT {
    private boolean isAlreadySecure = false;
    private CurrentUser currentUser;
    private String jsonWebToken;
    private String correlationId;

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public boolean isAlreadySecure() {
        return isAlreadySecure;
    }

    public void setAlreadySecure(boolean alreadySecure) {
        this.isAlreadySecure = alreadySecure;
    }

    public CurrentUser getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(CurrentUser currentUser) {
        this.currentUser = currentUser;
    }

    public String getFullName() {
        String retval = "";
        if (currentUser != null && currentUser.profile != null) {
            retval = String.format("%s, %s", currentUser.profile.lastName, currentUser.profile.firstName);
        }
        return retval;
    }

    public String getCurrentNodeId() {
        return this.getCurrentUser().profile.currentNodeRef.id;
    }

    public String getProfileId() {
        return currentUser == null ? "" : currentUser.profile.getId();
    }

    public String getJsonWebToken() {
        return jsonWebToken;
    }

    public void setJsonWebToken(String jsonWebToken) {
        this.jsonWebToken = jsonWebToken;
    }

    public String getpkiDn() {
        return getCurrentUser().profile.pkiDn;
    }
}
