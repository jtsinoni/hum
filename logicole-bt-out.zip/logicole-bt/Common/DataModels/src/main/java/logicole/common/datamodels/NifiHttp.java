package logicole.common.datamodels;

import java.util.Date;

public class NifiHttp {
    public String id;
    public String responseContent;
    public Date startDate;
    public Date endDate;
    public String requestedById;
    public String requestedByName;
//    public HttpResponse httpResponse;
    public String url;
    public Integer statusCode;
}
