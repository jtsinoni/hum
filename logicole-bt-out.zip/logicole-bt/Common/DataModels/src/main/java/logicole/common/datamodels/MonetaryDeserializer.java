package logicole.common.datamodels;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import logicole.common.general.util.string.StringUtil;

import java.io.IOException;
import java.math.BigDecimal;

public class MonetaryDeserializer extends JsonDeserializer<MonetaryValue> {

    @Override
    public MonetaryValue deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {

        String stringVal = jp.getValueAsString();

        if (StringUtil.isBlankOrNull(stringVal)) {
            stringVal = "0.00";
        }

        BigDecimal bigDecimalVal = new BigDecimal(stringVal.trim());
        int scale = bigDecimalVal.scale();

        return new MonetaryValue(bigDecimalVal, scale);
    }

}
