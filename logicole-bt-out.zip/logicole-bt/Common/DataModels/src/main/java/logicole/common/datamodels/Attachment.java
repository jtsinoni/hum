package logicole.common.datamodels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.filemanager.FileRef;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Attachment {
    public String description;
    public FileRef fileRef;
    public String section;
    public String source;
    public String category;
}

