package logicole.common.datamodels;

public class EnumField {
    public final String fieldName;
    public Object object;

    public EnumField(String fieldName, Object object) {
        this.fieldName = fieldName;
        this.object = object;
    }
}
