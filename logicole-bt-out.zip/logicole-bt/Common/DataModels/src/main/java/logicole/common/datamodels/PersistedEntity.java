package logicole.common.datamodels;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.ref.IReferencedData;
import logicole.common.general.annotations.LcJsonFormatDate;
import org.bson.codecs.pojo.annotations.BsonId;
import org.bson.codecs.pojo.annotations.BsonIgnore;
import org.bson.types.ObjectId;

import java.util.Date;
import java.util.Objects;

@JsonIgnoreProperties(value = {"_id", "_isDeleted", "refHash", "modifiedMillis"})
public abstract class PersistedEntity implements IPersistedEntity {

    public static class Metadata{
        @JsonIgnore
        public Boolean isDeleted = false;
//        @JsonIgnore
//        public int refHash;
        @LcJsonFormatDate
        public Date modifiedDate;
        public long modifiedMillis ;
        @LcJsonFormatDate
        public Date createdDate;
        public long createdMillis ;

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Metadata metadata = (Metadata) o;
            return modifiedMillis == metadata.modifiedMillis && createdMillis == metadata.createdMillis && Objects.equals(isDeleted, metadata.isDeleted) && Objects.equals(modifiedDate, metadata.modifiedDate) && Objects.equals(createdDate, metadata.createdDate);
        }

        @Override
        public int hashCode() {
            return Objects.hash(isDeleted, modifiedDate, modifiedMillis, createdDate, createdMillis);
        }

        public static Metadata create(){
            Date now = new Date();

            Metadata metadata = new Metadata();
            metadata.modifiedDate = now;
            metadata.modifiedMillis = now.getTime();
            metadata.createdDate = now;
            metadata.createdMillis = now.getTime();

            return metadata;
        }
    }

    @BsonId
    @JsonIgnore
    public ObjectId _id;
    public Metadata _metadata = new Metadata();

    @BsonIgnore
    @JsonIgnore
    public ObjectId getObjectId() {
        return _id;
    }

    @BsonIgnore
    public String getId() {
        String val = null;
        if (_id != null) {
            val = _id.toString();
        }
        return val;
    }

    @BsonIgnore
    public void setId(String id) {
        if (id != null && id.length() > 0) {
            this._id = new ObjectId(id);
        }
    }

    @BsonIgnore
    public void setObjectId(ObjectId id) {
        this._id = id;
    }

    @BsonIgnore
    public void setNewObjectId() {
        this._id = new ObjectId();
    }

    @JsonIgnore
    @BsonIgnore
    public Boolean get_isDeleted() {
        if (_metadata.isDeleted == null) {
            _metadata.isDeleted = false;
        }
        return _metadata.isDeleted;
    }

    @JsonIgnore
    @BsonIgnore
    public void set_isDeleted(Boolean _isDeleted) {
        if (_isDeleted == null){
            if (_metadata.isDeleted != null && _metadata.isDeleted != true){
                _metadata.isDeleted = null;
            }
        }else if (_isDeleted == true) {
            this._metadata.isDeleted = _isDeleted;
        }
    }

    @JsonIgnore
    @BsonIgnore
    public int getRefHash() {
        int refHash = 0;
        if (this instanceof IReferencedData){
            refHash = ((IReferencedData) this).calculateRefHash();
        }

        return refHash;
    }

//    @JsonIgnore
//    @BsonIgnore
//    public int setRefHash() {
//        if (this instanceof IReferencedData){
//            this._metadata.refHash = ((IReferencedData) this).calculateRefHash();
//        }
//        return getRefHash();
//    }

    @JsonIgnore
    @BsonIgnore
    public void setModifiedDate() {
        this._metadata.modifiedDate = new Date();
        this._metadata.modifiedMillis = this._metadata.modifiedDate.getTime();
    }

    @JsonIgnore
    @BsonIgnore
    public Date getModifiedDate() {
        return _metadata.modifiedDate;
    }

    @JsonIgnore
    @BsonIgnore
    public void setCreatedDate() {
        this._metadata.createdDate = new Date();
        this._metadata.createdMillis = this._metadata.createdDate.getTime();
    }

    @JsonIgnore
    @BsonIgnore
    public Long getModifiedMillis() {
        return this._metadata.modifiedMillis;
    }

}
