package logicole.common.datamodels;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.general.annotations.LcJsonFormatDate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Journal {
    public String journalId;  // Not an _id, but a GUID
    public String journalSubject;
    public String journalEntry;
    public List<JournalAction> journalActions = new ArrayList<>();
    public String firstName;
    public String lastName;
    public String userId;
    @LcJsonFormatDate
    public Date createdDate;
    @LcJsonFormatDate
    public Date modifiedDate;
}
