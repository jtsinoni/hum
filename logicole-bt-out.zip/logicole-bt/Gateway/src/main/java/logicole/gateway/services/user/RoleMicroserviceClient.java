package logicole.gateway.services.user;

import logicole.apis.user.IRoleMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class RoleMicroserviceClient extends MicroserviceClient<IRoleMicroserviceApi> {
    public RoleMicroserviceClient() {
        super(IRoleMicroserviceApi.class, "logicole-user");
    }

    @Produces
    public IRoleMicroserviceApi getApi() {
        return createClient();
    }

}
