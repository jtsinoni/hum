package logicole.gateway.services.inventory;

import io.swagger.annotations.Api;
import logicole.common.datamodels.inventory.Return.InventoryReturn;
import logicole.common.datamodels.inventory.Return.ReturnType;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;


@Api(tags = {"Returns"})
@ApplicationScoped
@Path("/returns")
public class ReturnsRestApi extends ExternalRestApi<ReturnsService> {

    @GET
    @Path("/getReturnRecordById")
    public InventoryReturn getReturnRecordById(@QueryParam("inventoryReturnId") String inventoryReturnId) {
        return service.getInventoryReturnById(inventoryReturnId);
    }

    @GET
    @Path("/getReturnRecordsByOrgId")
    public List<InventoryReturn> getReturnRecordsByOrgId(@QueryParam("orgId") String orgId) {
        return service.getInventoryReturnsByOrgId(orgId);
    }

    @GET
    @Path("/getReturnTypes")
    public List<ReturnType> getReturnTypes() {
        return service.getReturnTypes();
    }

    @POST
    @Path("/saveReturnInfo")
    public InventoryReturn saveReturnInformation(InventoryReturn returnRecord) {
        return service.saveReturnInfo(returnRecord);
    }

    @POST
    @Path("/saveReturnPickupInfo")
    public InventoryReturn saveReturnPickupInfo(InventoryReturn returnRecord) {
        return service.saveReturnPickupInfo(returnRecord);
    }

    @POST
    @Path("/saveReturnDispositionInfo")
    public InventoryReturn saveReturnDispositionInfo(@QueryParam("dispositionType") String dispositionType, InventoryReturn returnRecord) {
        return service.saveReturnDispositionInfo(dispositionType, returnRecord);
    }

    @POST
    @Path("/completeReturn")
    public InventoryReturn completeReturn(InventoryReturn returnRecord) {
        return service.completeReturn(returnRecord);
    }

    @POST
    @Path("/cancelReturn")
    public InventoryReturn cancelReturn(InventoryReturn returnRecord) {
        return service.cancelReturn(returnRecord);

    }

}
