package logicole.gateway.services.receipt;

import io.swagger.annotations.Api;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.receipt.Receipt;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.MonetaryValue;

import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Receipt"})
@ApplicationScoped
@Path("/receipt")
public class ReceiptRestApi extends ExternalRestApi<ReceiptService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getReceiptsByBuyerId")
    public List<Receipt> getReceiptsByBuyerId(@QueryParam("id") String id){
        return service.getReceiptsByBuyerId(id);
    }

    @GET
    @Path("/getReceiptsBySellerId")
    public List<Receipt> getReceiptsBySellerId(@QueryParam("id") String id){
        return service.getReceiptsBySellerId(id);
    }

    @GET
    @Path("/getReceiptsByPartialEnterpriseProductIdentifier")
    public List<Receipt> getReceiptsByPartialEnterpriseProductIdentifier(@QueryParam("partialProductIdentifier") String partialProductIdentifier){
        return service.getReceiptsByPartialEnterpriseProductIdentifier(partialProductIdentifier);
    }

    @POST
    @Path("/addReceipt")
    public Receipt addReceipt(Receipt receipt){
        return service.addReceipt(receipt);
    }

    @GET
    @Path("/getReceiptByDueInId")
    public Receipt getReceiptByDueInId(@QueryParam("id") String id) {
        return service.getReceiptByDueInId(id);
    }


    @GET
    @Path("/addReceiptByDueInId")
    public Receipt addReceiptByDueInId(@QueryParam("dueInId") String dueInId, @QueryParam("quantity")Integer quantity, @QueryParam("price") MonetaryValue price){
        return service.addReceiptByDueInId(dueInId,quantity,price);
    }

    @GET
    @Path("/getDiscrepancyCodes")
    public List<String> getDiscrepancyCodes() {
        return service.getDiscrepancyCodes();
    }

    @GET
    @Path("/getDiscrepancyActionCodes")
    public List<String> getDiscrepancyActionCodes() {
        return service.getDiscrepancyActionCodes();
    }

}
