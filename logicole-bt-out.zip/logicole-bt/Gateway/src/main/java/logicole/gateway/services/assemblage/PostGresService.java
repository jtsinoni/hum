package logicole.gateway.services.assemblage;

import logicole.apis.assemblage.IPostGresMicroserviceApi;
import logicole.common.datamodels.assemblage.postgres.NsnProductDetail;
import logicole.common.datamodels.assemblage.postgres.PostGresProduct;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class PostGresService extends BaseGatewayService<IPostGresMicroserviceApi> {

    public PostGresService() {
        super("PostGres");
    }

    public PostGresProduct getProductData(String itemIdentifier) {
        return microservice.getProductData(itemIdentifier);
    }

    public SearchResult<NsnProductDetail> getAssemblageProductData(String nsn){
        return microservice.getAssemblageProductData(nsn);
    }
}

