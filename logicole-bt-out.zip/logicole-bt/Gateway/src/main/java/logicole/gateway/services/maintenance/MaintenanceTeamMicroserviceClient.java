package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.IMaintenanceTeamMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class MaintenanceTeamMicroserviceClient extends MicroserviceClient<IMaintenanceTeamMicroserviceApi> {

    public MaintenanceTeamMicroserviceClient() {
        super(IMaintenanceTeamMicroserviceApi.class, "logicole-maintenance");
    }

    @Produces
    public IMaintenanceTeamMicroserviceApi getIMaintenanceTeamMicroserviceApi() {
        return createClient();
    }

}
