package logicole.gateway.services.system;

import logicole.apis.system.IKafkaMicroserviceApi;
import logicole.common.kafka.*;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class KafkaService extends BaseGatewayService<IKafkaMicroserviceApi> {
    @Inject
    KafkaClient kafkaClient;

    public KafkaService() {
        super("Kafka");
    }

    @Override
    protected void onInitialized() {
        super.onInitialized();
        logger.debug("KafkaService is initialized");

    }

    public List<KafkaServerTopic> getKafkaServerTopics() {
        return kafkaClient.getKafkaServerTopics();
    }

    public List<KafkaServerNode> getKafkaBrokers() {
        return kafkaClient.getKafkaBrokers();
    }

    public List<KafkaServerConsumerGroup> getKafkaServerConsumerGroups() {
        return kafkaClient.getKafkaServerConsumerGroups();
    }

    public void createKafkaTestRecords(String topicName, int numberOfRecords) {
        EKafkaTopic kafkaTopic = EKafkaTopic.getByName(topicName);
        Objects.requireNonNull(kafkaTopic, String.format("Kafka Topic %s is not a valid LogiCole Kafka Topic", topicName));
        for (int i = 0; i < numberOfRecords; i++) {
            kafkaClient.send(kafkaTopic, String.format("Test Record %d - published %s", i, LocalDateTime.now().toLocalTime()));
        }
    }

    public void createKafkaServerTopic(String topicName, int numPartitions, int replicationFactor) {
        kafkaClient.createKafkaServerTopic(topicName, numPartitions, replicationFactor);
    }

    public void deleteKafkaServerTopic(String topicName) {
        kafkaClient.deleteKafkaServerTopic(topicName);
    }

    public void deleteKafkaServerConsumerGroup(String groupId) {
        kafkaClient.deleteKafkaServerConsumerGroup(groupId);
    }
}