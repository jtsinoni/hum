package logicole.gateway.services.inventory;

import logicole.apis.inventory.ILocationMicroserviceApi;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.abi.item.ItemSummary;
import logicole.common.datamodels.general.Contact;
import logicole.common.datamodels.general.TreeNode;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchCriterion;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.inventory.*;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.organization.OrganizationService;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class LocationService extends BaseGatewayService<ILocationMicroserviceApi> {


    @Inject
    protected FileManagerAdminService fileManagerAdminService;

    @Inject
    protected OrganizationService organizationService;


    public LocationService() {
        super("Location");
    }

    public List<InventorySystem> getInventorySystems() {
        String currentUserNodeId = this.currentUserBT.getCurrentNodeId();
        return microservice.getInventorySystems(currentUserNodeId);
    }

    public List<InventorySystem> getInventorySystemsByStatus(String status) {
        String currentUserNodeId = this.currentUserBT.getCurrentNodeId();
        return microservice.getInventorySystemsByStatus(currentUserNodeId, status);
    }

    public SearchResult<InventorySystem> getInventorySystemsSearchResults(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getInventorySystemSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            return microservice.getInventorySystemsSearchResults(searchInput);
        }
    }

    public InventorySystem getInventorySystemById(String inventorySystemId) {
        return microservice.getInventorySystemById(inventorySystemId);
    }

    public InventorySystem getInventorySystemByNodeId(String nodeId) {
        return microservice.getInventorySystemByCurrentNodeId(nodeId);
    }

    public InventorySystem getStorageInventorySystemByCurrentNodeId(String nodeId) {
        return microservice.getStorageInventorySystemByCurrentNodeId(nodeId);
    }


    public StorageLocation getStorageLocationById(String storageLocationId) {
        return microservice.getStorageLocationById(storageLocationId);
    }

    public List<StorageLocation> getStorageLocationsByNodeId(String nodeId) {
        return microservice.getStorageLocationsByNodeId(nodeId);
    }

    public List<StorageLocationRef> getStorageLocationRefsByNodeId(String nodeId) {
        return microservice.getStorageLocationRefsByNodeId(nodeId);
    }

    public List<StorageLocation> getStorageLocationsByParentId(String parentId) {
        return microservice.getStorageLocationsByParentId(parentId);
    }

    public List<StorageLocationRef> getStorageLocationRefsByParentId(String parentId) {
        return microservice.getStorageLocationRefsByParentId(parentId);
    }

    public List<LocationType> getLocationTypes() {
        return microservice.getLocationTypes();
    }

    public List<LocationTypeRef> getLocationTypeRefs() {
        return microservice.getLocationTypeRefs();
    }


    public StorageLocation lockStorageLocation(String storageLocationId) {
        return microservice.lockStorageLocation(storageLocationId);
    }

    public StorageLocation unlockStorageLocation(String storageLocationId) {
        return microservice.unlockStorageLocation(storageLocationId);
    }

    public StorageLocation setStorageLocationActive(String storageLocationId) {
        return microservice.setStorageLocationActive(storageLocationId);
    }

    public StorageLocation setStorageLocationInactive(String storageLocationId) {
        return microservice.setStorageLocationInactive(storageLocationId);
    }

    public StorageLocation saveStorageLocation(StorageLocation storageLocation) {
        return microservice.saveStorageLocation(storageLocation);
    }

    public StorageLocation saveStorageLocationInfo(StorageLocation storageLocation) {
        return microservice.saveStorageLocationInfo(storageLocation);
    }

    public StorageLocation saveStorageRequirements(StorageLocation storageLocation) {
        return microservice.saveStorageRequirements(storageLocation);
    }

    public StorageLocation createInventorySystemRootStorageLocation(StorageLocation storageLocation) {
        if (!StringUtil.isEmptyOrNull(storageLocation.parentId)) {
            throw new ApplicationException("The root location cannot have a parent");
        }
        if (Objects.isNull(storageLocation.inventorySystemRef)) {
            throw new ApplicationException("A root location must have an inventory system reference");
        }
        return microservice.createInventorySystemRootStorageLocation(storageLocation);
    }

    public StorageLocation createStorageLocation(StorageLocation storageLocation) {
        if (StringUtil.isEmptyOrNull(storageLocation.parentId)) {
            throw new ApplicationException("Child must have a parent");
        }
        return microservice.createStorageLocation(storageLocation);
    }

    public List<TreeNode<StorageLocation>> getInventorySystemsStorageLocationTrees() {
        String nodeId = this.currentUserBT.getCurrentNodeId();
        return microservice.getInventorySystemsStorageLocationTrees(nodeId);
    }

    public List<TreeNode<StorageLocation>> getCurrentUserInventoryStorageLocationTree() {
        String nodeId = this.currentUserBT.getCurrentNodeId();
        InventorySystem currentUserSystem = microservice.getInventorySystemByCurrentNodeId(nodeId);
        if (Objects.isNull(currentUserSystem)) {
            throw new ValidationException("No inventory system is available for your current organization");
        }
        return microservice.getInventoryStorageLocationTreeByNodeId(nodeId);
    }

    public List<TreeNode<StorageLocation>> getInventoryStorageLocationTree(String inventorySystemId) {
        return microservice.getInventoryStorageLocationTree(inventorySystemId);
    }

    public List<TreeNode<StorageLocation>> getInventoryTreeChildren(String parentId) {
        return microservice.getInventoryTreeChildren(parentId);
    }

    public InventorySystem getCurrentUserInventorySystem() {
        String inventorySystemNodeId = this.currentUserBT.getCurrentNodeId();
        return microservice.getInventorySystemByCurrentNodeId(inventorySystemNodeId);
    }

    public StorageLocation getRootStorageLocationByNodeId(String nodeId) {
        return microservice.getRootStorageLocationByNodeId(nodeId);
    }

    public StorageLocation getCurrentUserRootStorageLocation() {
        return microservice.getRootStorageLocationByNodeId(this.currentUserBT.getCurrentNodeId());
    }

    public InventorySystem createInventorySystem(boolean createStorageLocations, InventorySystem system) {
        if (StringUtil.isEmptyOrNull(system.nodeRef.getId())) {
            throw new ApplicationException("Unable to create Inventory System; No Organization selected.");
        }
        OrganizationRef organizationRef = organizationService.getOrganizationRefById(system.nodeRef.getId());
        system.nodeRef = organizationRef;
        InventorySystem existingSystem = this.getInventorySystemByCurrentNodeId(organizationRef.id);
        if (!Objects.isNull(existingSystem)) {
            throw new ApplicationException(String.format("An Inventory System already exists for %s .", organizationRef.name));
        }
        return microservice.createInventorySystem(createStorageLocations, system);
    }

    public InventorySystem updateInventorySystem(InventorySystem system) {
        return microservice.updateInventorySystem(system);
    }

    public List<InventorySystemRef> getDescendantInventorySystemRefs(String parentNodeId) {
        return microservice.getDescendantInventorySystemRefs(parentNodeId);
    }

    public InventorySystem getInventorySystemParent(String inventorySystemId) {
        return microservice.getInventorySystemParent(inventorySystemId);
    }

    public boolean hasInventorySystemParent(String inventoryNodeId) {
        OrganizationRef nodeRef = organizationService.getOrganizationRefById(inventoryNodeId);
        return microservice.hasInventorySystemParent(nodeRef);
    }

    public List<StorageLocation> getParentSystemOpenLocationsByNodeId(String nodeId) {
        OrganizationRef nodeRef = organizationService.getOrganizationRefById(nodeId);
        return microservice.getParentSystemOpenLocationsByNodeRef(nodeRef);
    }

    public InventorySystem updateInventorySystemLocationAndLeveling(String id, String defaultLevelingType, String defaultLevelingMethod, Integer defaultInventoryDays, StorageLocationRef defaultLocationRef) {
        return microservice.updateInventorySystemLocationAndLeveling(id, defaultLevelingType, defaultLevelingMethod, defaultInventoryDays, defaultLocationRef);
    }

    public InventorySystem updateInventorySystemContact(String id, Contact contact) {
        return microservice.updateInventorySystemContact(id, contact);
    }
    public InventorySystem getInventorySystemByCurrentNodeId(String currentOrgId) {
        return microservice.getInventorySystemByCurrentNodeId(currentOrgId);
    }

    public StorageLocation saveStorageLocationNote(String storageLocationId, Note note) {
        return microservice.saveStorageLocationNote(storageLocationId, note);
    }

    public StorageLocation saveStorageLocationNotes(String storageLocationId, List<Note> notes) {
        return microservice.saveStorageLocationNotes(storageLocationId, notes);
    }

    public StorageLocation uploadStorageLocationAttachment(MultipartFormDataInput form, String storageLocationId,
                                                           String description, String section)
            throws ApplicationException, IOException {
        // TODO: Attachments have changed, revisit
        /*
        // Ensure valid inputs
        if (form == null || storageAreaId == null || description == null) {
            throw new ApplicationException(
                    "Unable to upload StorageArea attachment. Form, storageAreaId, and description are required.");
        }
        // Perform actual file upload
        FileRef fileRef = uploadInventoryFile(form);

        // Add attachment info to StorageArea
        Attachment attachmentInfo = new Attachment();
        attachmentInfo.fileRef = fileRef;

        // Fill in other attachment info
        attachmentInfo.description = description;
        if (section != null) {
            attachmentInfo.section = section;
        }

        // Call microservice to add attachment info to StorageArea document
        return microservice.saveStorageAreaAttachmentInfo(storageAreaId, attachmentInfo);
        */
        return null;
    }

    public StorageLocation removeStorageLocationNote(String storageLocationId, String noteId) {
        return microservice.removeStorageLocationNote(storageLocationId, noteId);
    }

    public StorageLocation removeStorageLocationNotes(String storageLocationId, List<String> noteIds) {
        return microservice.removeStorageLocationNotes(storageLocationId, noteIds);
    }


    public StorageLocation removeStorageLocationAttachment(String storageLocationId, String fileId)
            throws ApplicationException, IOException {

        if (storageLocationId == null || fileId == null) {
            throw new ApplicationException(
                    "Unable to remove StorageLocation attachment. Need storageLocationId and fileId.");
        }

        // Update DB first. Throw ApplicationException if fileId not found.
        StorageLocation retval = microservice.removeStorageLocationAttachmentInfo(storageLocationId, fileId);

        // Call FileManager to remove actual file.
        fileManagerAdminService.removeFile(fileId);

        return retval;
    }


    public StorageLocation uploadLocationAttachment(MultipartFormDataInput form, String inventoryLocationId,
                                                    String description, String section)
            throws ApplicationException, IOException {

        // TODO: Attachments have changed, revisit
        /*
        // Ensure valid inputs
        if (form == null || inventoryLocationId == null || description == null) {
            throw new ApplicationException(
                    "Unable to upload InventoryLocation attachment. Form, inventoryLocationId, and description are required.");
        }
        // Perform actual file upload
        FileManagerFile fileRef = uploadInventoryFile(form);

        // Add attachment info to StorageLocation
        Attachment attachmentInfo = new Attachment();
        attachmentInfo.fileManagerFileRef = fileRef;

        // Fill in other attachment info
        attachmentInfo.description = description;
        if (section != null) {
            attachmentInfo.section = section;
        }

        // Call microservice to add attachment info to InventoryLocation document
        return microservice.saveLocationAttachmentInfo(inventoryLocationId, attachmentInfo);
        */
        return null;
    }


    // TODO refactor and separate Location and Inventory System
    @Override
    public void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate) {
        microservice.doDataReferenceUpdate(dataReferenceUpdate);
    }







}
