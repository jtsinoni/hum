package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetMaintenanceProcedureMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.businesscontact.Skill;
import logicole.common.datamodels.asset.businesscontact.SkillRef;
import logicole.common.datamodels.asset.classification.AssemblyCategory;
import logicole.common.datamodels.asset.classification.AssemblyCategoryRef;
import logicole.common.datamodels.asset.classification.FacilitySubsystem;
import logicole.common.datamodels.asset.classification.FacilitySubsystemRef;
import logicole.common.datamodels.asset.classification.FacilitySystem;
import logicole.common.datamodels.asset.classification.FacilitySystemRef;
import logicole.common.datamodels.asset.classification.Nomenclature;
import logicole.common.datamodels.asset.classification.NomenclatureForDropdown;
import logicole.common.datamodels.asset.classification.NomenclatureRef;
import logicole.common.datamodels.asset.classification.SpecialtyRef;
import logicole.common.datamodels.asset.maintenance.procedure.AuthoritativeProcedure;
import logicole.common.datamodels.asset.maintenance.procedure.DetailSearchCriteria;
import logicole.common.datamodels.asset.maintenance.procedure.EProcedureOccupancyType;
import logicole.common.datamodels.asset.maintenance.procedure.EProcedureType;
import logicole.common.datamodels.asset.maintenance.procedure.ItemRecipient;
import logicole.common.datamodels.asset.maintenance.procedure.MaintenanceProcedure;
import logicole.common.datamodels.asset.maintenance.procedure.MaintenanceProcedureRef;
import logicole.common.datamodels.asset.maintenance.procedure.MaintenanceProcedureRpss;
import logicole.common.datamodels.asset.maintenance.procedure.MaintenanceProcedureSummary;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceAction;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceCode;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceSubject;
import logicole.common.datamodels.asset.maintenance.procedure.Resource;
import logicole.common.datamodels.asset.maintenance.procedure.Review;
import logicole.common.datamodels.asset.maintenance.procedure.ToolsAndMaterial;
import logicole.common.datamodels.asset.maintenance.procedure.bulk.BulkResponse;
import logicole.common.datamodels.asset.maintenance.procedure.bulk.FailedItem;
import logicole.common.datamodels.asset.maintenance.procedure.dropDownFeeders.ProcedureTypeEntry;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.system.AuthoritativeSourceRef;
import logicole.common.datamodels.system.frequency.Frequency;
import logicole.common.datamodels.system.frequency.FrequencyRef;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.validation.MaintenanceProcedureValidator;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.system.SystemService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;
import java.util.Objects;


@ApplicationScoped
public class AssetMaintenanceProcedureService extends BaseGatewayService<IAssetMaintenanceProcedureMicroserviceApi> {

    @Inject
    private MaintenanceProcedureValidator maintenanceProcedureValidator;

    @Inject
    AssetScheduleService assetScheduleService;

    @Inject
    AssetClassificationService assetClassificationService;

    @Inject
    FacilityService facilityService;

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    OrganizationService organizationService;

    @Inject
    SystemService systemService;

    @Inject
    private StringUtil stringUtil;

    private static final String MESSAGE_STRING = "Procedure identifier %s: %s not found - %s | ";
    private static final String AUTHORITATIVE_SOURCE_CODE_RPSS = "RPSS";

    public AssetMaintenanceProcedureService() {
        super("Asset");
    }

    public boolean isManagedByNodeRPFuncEnabled() {
        return facilityService.isManagedByNodeRPFuncEnabled(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
    }

    public MaintenanceProcedure startNewMaintenanceProcedure(boolean isRpss) {
        MaintenanceProcedure maintenanceProcedure = new MaintenanceProcedure();
        if (isRpss) {
            maintenanceProcedure.authoritativeSourceRef = systemService.getAuthoritativeSourceRefByCode(AUTHORITATIVE_SOURCE_CODE_RPSS);
        }
        maintenanceProcedure.owningOrganizationRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        maintenanceProcedure.isActive = true;
        return maintenanceProcedure;
    }

    public List<String> getDocumentTypes() {
        return facilityService.getDocumentTypes();
    }

    public void loadRpssMaintenanceProcedures(List<MaintenanceProcedureRpss> rpssList) {
        rpssList.forEach(this::loadRpssMaintenanceProcedure);
    }

    public void loadRpssMaintenanceProcedure(MaintenanceProcedureRpss rpss) {
        MaintenanceProcedure mp = convertRpssToMaintenanceProcedure(rpss);
        microservice.loadRpssMaintenanceProcedure(mp);
    }

    public void deleteRpssMaintenanceProcedure(String procedureIdentifier) {
        AuthoritativeSourceRef rpssAuthSourceRef = getRpssAuthoritativeSourceRef();
        MaintenanceProcedure persistedMp =
                getProcedureByLogicalKey(procedureIdentifier, rpssAuthSourceRef.getId(), null);
        if (persistedMp != null) {
            setProcedureIsDeleted(persistedMp.getId());
        }
    }

    public MaintenanceProcedure getProcedureByLogicalKey(String procedureIdentifier,
                                                         String authoritativeSourceId,
                                                         String owningOrganizationId) {
        return microservice.getProcedureByLogicalKey(
                procedureIdentifier, authoritativeSourceId, owningOrganizationId);
    }

    public long getProcedureCountByNomenclature(String nomenclatureId) {
        NomenclatureRef nomenclatureRef = getNomenclatureRef(nomenclatureId);
        if (null == nomenclatureRef || StringUtil.isEmptyOrNull(nomenclatureRef.nomenclatureCode)) {
            throw new ApplicationException("Unable to find Nomenclature");
        }
        return microservice.getProcedureCountByNomenclature(nomenclatureRef.id);
    }

    public long getCountByRegulatoryComplianceActionAndScope(String regulatoryComplianceActionId, String scopeOrgId) {
        List<String> orgIds = organizationService.getOrganizationIdsAtAndBelow(scopeOrgId);
        return microservice.getCountByRegulatoryComplianceActionAndScope(regulatoryComplianceActionId, orgIds);
    }

    public long getCountByRegulatoryComplianceCodeAndScope(String regulatoryComplianceCodeId, String scopeOrgId) {
        List<String> orgIds = organizationService.getOrganizationIdsAtAndBelow(scopeOrgId);
        return microservice.getCountByRegulatoryComplianceCodeAndScope(regulatoryComplianceCodeId, orgIds);
    }

    public List<MaintenanceProcedure> findByOrgAndProcTypeAndDmlssSerial(String owningOrgId,
                                                                         String procedureType,
                                                                         Integer dmlssProcSerial) {
        return microservice.findByOrgAndProcTypeAndDmlssSerial(owningOrgId, procedureType, dmlssProcSerial);
    }

    private void ensureLegacyMaintenanceProcIsUnique(MaintenanceProcedure maintenanceProc) {
        if (maintenanceProc.dmlssProcSerial != null && maintenanceProc.procedureType != null &&
                maintenanceProc.owningOrganizationRef != null) {
            List<MaintenanceProcedure> persistedMaintenanceProcs = findByOrgAndProcTypeAndDmlssSerial(
                    maintenanceProc.owningOrganizationRef.id, maintenanceProc.procedureType, maintenanceProc.dmlssProcSerial);
            if (!ListUtil.isEmpty(persistedMaintenanceProcs)) {
                throw new ApplicationException(String.format("MaintenanceProcedure already exists (owningOrg %s, procedureType %s, dmlssProcSerial %d)",
                        maintenanceProc.owningOrganizationRef.getId(), maintenanceProc.procedureType, maintenanceProc.dmlssProcSerial));
            }
        }
    }

    public List<MaintenanceProcedure> getMaintenanceProcedureDetailsList(DetailSearchCriteria searchCriteria) {
        return microservice.getMaintenanceProcedureDetailsList(searchCriteria);
    }

    public List<String> migrateAuthoritativeProcedure(AuthoritativeProcedure authoritativeProcedure) {
        return this.migrateAuthoritativeProcedure(authoritativeProcedure, null);
    }

    public List<String> migrateAuthoritativeProcedure(AuthoritativeProcedure authoritativeProcedure, String authoritativeSourceCode) {
        List<String> errors = new ArrayList<>();

        if (authoritativeSourceCode != null) {
            AuthoritativeSourceRef authoritativeSourceRef = systemService.getAuthoritativeSourceRefByCode(authoritativeSourceCode);
            if (authoritativeSourceRef == null) {
                errors.add(String.format("AuthoritativeSourceRef not found for code of %s", authoritativeSourceCode));
            } else {
                authoritativeProcedure.authoritativeSourceRef = authoritativeSourceRef;
            }
        }

        Frequency frequency = systemService.getFrequencyByName(authoritativeProcedure.frequency);
        if (frequency == null) {
            errors.add(String.format(MESSAGE_STRING, authoritativeProcedure.procedureIdentifier, "frequency", authoritativeProcedure.frequency));
        } else {
            authoritativeProcedure.frequencyRef = frequency.getRef();
        }

        errors.addAll(microservice.migrateAuthoritativeProcedure(authoritativeProcedure));
        return errors;
    }

    public MaintenanceProcedure createMaintenanceProcedure(MaintenanceProcedure maintenanceProcedure) {
        // To support data loading...allows for owningOrganizationRef to be populated
        if (maintenanceProcedure.owningOrganizationRef == null ||
                StringUtil.isBlankOrNull(maintenanceProcedure.owningOrganizationRef.getId())) {
            maintenanceProcedure.owningOrganizationRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        }
        boolean procedureIdentifierExists = procedureIdentifierExists(
                maintenanceProcedure.procedureIdentifier, maintenanceProcedure.owningOrganizationRef.getId());
        maintenanceProcedureValidator.validate(maintenanceProcedure, procedureIdentifierExists);
        ensureLegacyMaintenanceProcIsUnique(maintenanceProcedure);
        return microservice.saveNewProcedure(maintenanceProcedure);
    }

    public SearchResult<MaintenanceProcedureSummary> findMaintenanceProcedures(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getMaintenanceProcedureSearchEngine();

        if (ESearchEngine.ELASTIC.equals(searchEngine)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            organizationService.setRPFuncFilterInSearch(searchInput);
            SearchResult<MaintenanceProcedureSummary> searchResult = microservice.findMaintenanceProcedures(searchInput);

            if (!ListUtil.isEmpty(searchResult.results)) {
                searchResult.total = (long) searchResult.results.size();
            }

            return searchResult;
        }
    }

    public MaintenanceProcedure cloneProcedure(String id) {
        MaintenanceProcedure clonedProcedure = microservice.cloneProcedure(id);
        clonedProcedure.authoritativeSourceRef = null;
        clonedProcedure.owningOrganizationRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        clonedProcedure.isActive = true;
        return clonedProcedure;
    }

    public MaintenanceProcedure setProcedureIsActive(String id, boolean isActive) {
        boolean schedulesExist = assetScheduleService.schedulesExistForMaintenanceProcedure(id);
        MaintenanceProcedure maintenanceProcedure = findById(id);

        if (!isActive && schedulesExist) {
            throw new ApplicationException("A maintenance procedure cannot be set to inactive if schedules exist.");
        }

        if (!maintenanceProcedure.owningOrganizationRef.getId().equals(currentUserBT.getCurrentUser().profile.currentNodeRef.getId())) {
            throw new ApplicationException("User does not have permissions/privileges to set procedure records to active/inactive.");
        }

        return microservice.setProcedureIsActive(id, isActive);
    }

    public BulkResponse bulkUpdateStatus(List<String> ids, boolean isActive) {
        validateBulkUpdateRecordLimit(ids.size());
        List<MaintenanceProcedure> maintenanceProcedures = microservice.findByIds(ids);
        BulkResponse bulkResponse = new BulkResponse();

        for (MaintenanceProcedure maintenanceProcedure : maintenanceProcedures) {
            try {
                setProcedureIsActive(maintenanceProcedure.getId(), isActive);
                bulkResponse.successfulItems.add(maintenanceProcedure.procedureIdentifier);
            } catch (Exception e) {
                // Fortify Note: Keeping this as a broad catch exception since it is in a for loop, and we want
                //               to continue processing the loop on exceptions.
                FailedItem item = new FailedItem();
                item.procedureIdentifier = maintenanceProcedure.procedureIdentifier;
                item.errorMsg = e.getMessage();
                bulkResponse.failedItems.add(item);
            }
        }

        return bulkResponse;
    }

    private void validateBulkUpdateRecordLimit(int recordsToProcessCount) {
        int limit = microservice.getBulkUpdateRecordLimit();
        if (recordsToProcessCount > limit) {
            throw new ApplicationException(String.format("Bulk update operation is limited to %s records", limit));
        }
    }

    public void setProcedureIsDeleted(String id) {
        List<String> scheduleIds = assetScheduleService.getScheduleIdsByMaintenanceProcedureId(id);
        if (scheduleIds == null || scheduleIds.isEmpty()) {
            microservice.setProcedureIsDeleted(id);
        } else {
            throw new ApplicationException("Cannot delete a Procedure in use by a Schedule");
        }
    }

    public MaintenanceProcedure findById(String id) {
        return microservice.findById(id);
    }

    public List<MaintenanceProcedure> findByIds(List<String> ids) {
        return microservice.findByIds(ids);
    }

    public List<ItemRecipient> getItemRecipients() {
        return microservice.getItemRecipients();
    }

    public List<ProcedureTypeEntry> getProcedureTypes() {
        List<ProcedureTypeEntry> procedureTypeEntries = new ArrayList<>();
        for (EProcedureType procedureType : EProcedureType.values()) {
            ProcedureTypeEntry procedureTypeEntry = new ProcedureTypeEntry();
            procedureTypeEntry.name = procedureType.name();
            procedureTypeEntry.description = procedureType.displayText;
            procedureTypeEntries.add(procedureTypeEntry);
        }
        return procedureTypeEntries;
    }

    public List<MaintenanceProcedure> getProceduresForAssemblyCategory(String id) {
        return microservice.getProceduresForAssemblyCategory(id);
    }

    public List<MaintenanceProcedure> getProceduresForFrequency(String id) {
        return microservice.getProceduresForFrequency(id);
    }

    public List<MaintenanceProcedure> getProceduresForOrganization(String id) {
        return microservice.getProceduresForOrganization(id);
    }

    public List<MaintenanceProcedure> getProceduresForFacilitySystem(String id) {
        return microservice.getProceduresForFacilitySystem(id);
    }

    public List<MaintenanceProcedure> getProceduresForFacilitySubsystem(String id) {
        return microservice.getProceduresForFacilitySubsystem(id);
    }

    public List<MaintenanceProcedure> getProceduresForNomenclature(String id) {
        return microservice.getProceduresForNomenclature(id);
    }

    public List<MaintenanceProcedureRef> getRegulatoryComplianceProcedureRefs() {
        return microservice.getRegulatoryComplianceProcedureRefs();
    }

    public List<MaintenanceProcedureRef> getProcedureRefsWithSameNomenclature(String nomenclatureId) {
        return microservice.getProcedureRefsWithSameNomenclature(nomenclatureId);
    }

    public NomenclatureRef getNomenclatureRef(String id) {
        return microservice.getNomenclatureRef(id);
    }

    public List<Nomenclature> getNomenclatures(String searchInput) {
        if (StringUtil.isEmptyOrNull(searchInput)) {
            throw new ApplicationException("Nomenclature search string is required");
        }
        return microservice.getNomenclatures(searchInput);
    }

    public List<NomenclatureForDropdown> getNomenclaturesForDropdown() {
        return assetClassificationService.getNomenclaturesForDropdown();
    }

    public List<MaintenanceProcedure> getProceduresForSkill(String id) {
        return microservice.getProceduresForSkill(id);
    }

    public RegulatoryComplianceAction addRegulatoryComplianceAction(RegulatoryComplianceAction action) {
        RegulatoryComplianceAction foundAction = microservice.getRegulatoryComplianceActionByName(action.name);
        if (foundAction == null) {
            action.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.addRegulatoryComplianceAction(action);
        } else {
            throw new ApplicationException("Regulatory Compliance Action already exists");
        }
    }

    public RegulatoryComplianceAction updateRegulatoryComplianceAction(RegulatoryComplianceAction action) {
        RegulatoryComplianceAction foundAction = microservice.getRegulatoryComplianceActionById(action.getId());
        if (foundAction == null) {
            throw new ApplicationException("Regulatory Compliance Action does not exist");
        } else {
            if (!foundAction.name.equalsIgnoreCase(action.name) && microservice.getRegulatoryComplianceActionByName(action.name) != null) {
                throw new ApplicationException("Regulatory Compliance Action already exists");
            } else {
                return microservice.updateRegulatoryComplianceAction(action);
            }
        }
    }

    public void deleteRegulatoryComplianceAction(String actionId) {
        microservice.deleteRegulatoryComplianceAction(actionId);
    }

    public List<RegulatoryComplianceAction> getRegulatoryComplianceActions() {
        return microservice.getRegulatoryComplianceActions();
    }

    public RegulatoryComplianceCode addRegulatoryComplianceCode(RegulatoryComplianceCode code) {
        RegulatoryComplianceCode foundCode = microservice.getRegulatoryComplianceCodeByName(code.name);
        if (foundCode == null) {
            code.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.addRegulatoryComplianceCode(code);
        } else {
            throw new ApplicationException("Regulatory Compliance Code already exists");
        }
    }

    public RegulatoryComplianceCode updateRegulatoryComplianceCode(RegulatoryComplianceCode code) {
        RegulatoryComplianceCode foundCode = microservice.getRegulatoryComplianceCodeById(code.getId());
        if (foundCode == null) {
            throw new ApplicationException("Regulatory Compliance Code does not exist");
        } else {
            if (!foundCode.name.equalsIgnoreCase(code.name) && microservice.getRegulatoryComplianceCodeByName(code.name) != null) {
                throw new ApplicationException("Regulatory Compliance Code already exists");
            } else {
                return microservice.updateRegulatoryComplianceCode(code);
            }
        }
    }

    public void deleteRegulatoryComplianceCode(String codeId) {
        microservice.deleteRegulatoryComplianceCode(codeId);
    }

    public List<RegulatoryComplianceCode> getRegulatoryComplianceCodes() {
        return microservice.getRegulatoryComplianceCodes();
    }

    public List<RegulatoryComplianceSubject> getRegulatoryComplianceSubjects() {
        return microservice.getRegulatoryComplianceSubjects();
    }

    public AssemblyCategory addAssemblyCategory(AssemblyCategory assemblyCategory) {
        AssemblyCategory foundAssemblyCategory = microservice.getAssemblyCategoryByCodeAndDescription(assemblyCategory.code, assemblyCategory.description);
        if (foundAssemblyCategory == null) {
            assemblyCategory.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.addAssemblyCategory(assemblyCategory);
        } else {
            throw new ApplicationException("Assembly Category already exists");
        }
    }

    public AssemblyCategory updateAssemblyCategory(AssemblyCategory assemblyCategory) {
        if (!assemblyCategory.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.managedByNodeRef.getId())) {
            throw new ApplicationException("Does not have the privileges to update the Assembly Category record.");
        } else {
            AssemblyCategory foundAssemblyCategory = microservice.getAssemblyCategoryById(assemblyCategory.getId());
            if (foundAssemblyCategory == null) {
                throw new ApplicationException("Assembly Category does not exist");
            } else {
                if (!(foundAssemblyCategory.code.equalsIgnoreCase(assemblyCategory.code) && foundAssemblyCategory.description.equalsIgnoreCase(assemblyCategory.description))
                        && microservice.getAssemblyCategoryByCodeAndDescription(assemblyCategory.code, assemblyCategory.description) != null) {
                    throw new ApplicationException("Assembly Category already exists");
                } else {
                    return microservice.updateAssemblyCategory(assemblyCategory);
                }
            }
        }
    }

    public void deleteAssemblyCategory(String assemblyCategoryId) {
        List<AssemblyCategory> listOfAssemblyCategories = microservice.getAllAssemblyCategories();
        AssemblyCategory foundAssemblyCategory = new AssemblyCategory();
        for (AssemblyCategory assemblyCategory : listOfAssemblyCategories) {
            if (assemblyCategory.getId().equals(assemblyCategoryId)) {
                foundAssemblyCategory = assemblyCategory;
            }
        }

        if (!foundAssemblyCategory.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.managedByNodeRef.getId())) {
            throw new ApplicationException("Does not have the privileges to delete the Assembly Category record.");
        }
        microservice.deleteAssemblyCategory(assemblyCategoryId);
    }

    public void deleteAssemblyCategoryById(String assemblyCategoryId) {
        // Version to be called as part of a data load...skips scoping check
        microservice.deleteAssemblyCategory(assemblyCategoryId);
    }

    public List<AssemblyCategory> getAllAssemblyCategories() {
        return microservice.getAllAssemblyCategories();
    }

    public void loadAssemblyCategory(AssemblyCategory assemblyCategory) {
        microservice.loadAssemblyCategory(assemblyCategory);
    }

    public void loadFacilitySubsystem(FacilitySubsystem facilitySubsystem) {
        microservice.loadFacilitySubsystem(facilitySubsystem);
    }

    public void loadFacilitySystem(FacilitySystem facilitySystem) {
        microservice.loadFacilitySystem(facilitySystem);
    }

    public FacilitySubsystem addFacilitySubsystem(FacilitySubsystem facilitySubsystem) {
        FacilitySubsystem foundFacilitySubsystem = microservice.getFacilitySubsystemByCodeAndDescription(facilitySubsystem.code, facilitySubsystem.description);
        if (foundFacilitySubsystem == null) {
            facilitySubsystem.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.addFacilitySubsystem(facilitySubsystem);
        } else {
            throw new ApplicationException("Facility Subsystem already exists");
        }
    }

    public FacilitySubsystem updateFacilitySubsystem(FacilitySubsystem facilitySubsystem) {
        if (!facilitySubsystem.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.managedByNodeRef.getId())) {
            throw new ApplicationException("Does not have the privileges to delete the Facility Subsystem record.");
        } else {
            FacilitySubsystem foundFacilitySubsystem = microservice.getFacilitySubsystemById(facilitySubsystem.getId());
            if (foundFacilitySubsystem == null) {
                throw new ApplicationException("Facility Subsystem does not exist");
            } else {
                if (!(foundFacilitySubsystem.code.equalsIgnoreCase(facilitySubsystem.code) && foundFacilitySubsystem.description.equalsIgnoreCase(facilitySubsystem.description))
                        && microservice.getFacilitySubsystemByCodeAndDescription(facilitySubsystem.code, facilitySubsystem.description) != null) {
                    throw new ApplicationException("Facility Subsystem already exists");
                } else {
                    return microservice.updateFacilitySubsystem(facilitySubsystem);
                }
            }
        }
    }

    public void deleteFacilitySubsystem(String facilitySubsystemId) {
        List<FacilitySubsystem> listOfFacilitySubsystems = microservice.getAllFacilitySubsystems();
        FacilitySubsystem foundFacilitySubsystem = new FacilitySubsystem();
        for (FacilitySubsystem fs : listOfFacilitySubsystems) {
            if (fs.getId().equals(facilitySubsystemId)) {
                foundFacilitySubsystem = fs;
            }
        }

        if (!foundFacilitySubsystem.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.managedByNodeRef.getId())) {
            throw new ApplicationException("Does not have the privileges to delete the Facility Subsystem record.");
        }
        microservice.deleteFacilitySubsystem(facilitySubsystemId);
    }

    public void deleteFacilitySubsystemById(String facilitySubsystemId) {
        // Version to be called as part of a data load...skips scoping check
        microservice.deleteFacilitySubsystem(facilitySubsystemId);
    }

    public List<FacilitySubsystem> getAllFacilitySubsystems() {
        return microservice.getAllFacilitySubsystems();
    }

    public FacilitySystem addFacilitySystem(FacilitySystem facilitySystem) {
        FacilitySystem foundFacilitySystem = microservice.getFacilitySystemByCodeAndDescription(facilitySystem.code, facilitySystem.description);
        if (foundFacilitySystem == null) {
            facilitySystem.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.addFacilitySystem(facilitySystem);
        } else {
            throw new ApplicationException("Facility System already exists");
        }
    }

    public FacilitySystem updateFacilitySystem(FacilitySystem facilitySystem) {
        if (!facilitySystem.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.managedByNodeRef.getId())) {
            throw new ApplicationException("Does not have the privileges to update the Facility System record.");
        } else {
            FacilitySystem foundFacilitySystem = microservice.getFacilitySystemById(facilitySystem.getId());
            if (foundFacilitySystem == null) {
                throw new ApplicationException("Facility System does not exist");
            } else {
                if (!(foundFacilitySystem.code.equalsIgnoreCase(facilitySystem.code) && foundFacilitySystem.description.equalsIgnoreCase(facilitySystem.description))
                        && microservice.getFacilitySystemByCodeAndDescription(facilitySystem.code, facilitySystem.description) != null) {
                    throw new ApplicationException("Facility System already exists");
                } else {
                    return microservice.updateFacilitySystem(facilitySystem);
                }
            }
        }
    }

    public void deleteFacilitySystem(String facilitySystemId) {
        List<FacilitySystem> listOfFacilitySystems = microservice.getAllFacilitySystems();
        FacilitySystem foundFacilityRecord = new FacilitySystem();
        for (FacilitySystem fs : listOfFacilitySystems) {
            if (fs.getId().equals(facilitySystemId)) {
                foundFacilityRecord = fs;
            }
        }

        if (!foundFacilityRecord.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.managedByNodeRef.getId())) {
            throw new ApplicationException("Does not have the privileges to delete the Facility System record.");
        }
        microservice.deleteFacilitySystem(facilitySystemId);
    }

    public void deleteFacilitySystemById(String facilitySystemId) {
        // Version to be called as part of a data load...skips scoping check
        microservice.deleteFacilitySystem(facilitySystemId);
    }

    public List<FacilitySystem> getAllFacilitySystems() {
        return microservice.getAllFacilitySystems();
    }

    public Integer getMaxUploadSize() {
        return microservice.getMaxUploadSize();
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }

    public Attachment saveAttachment(String id, Attachment attachmentToSave) {
        return microservice.saveAttachment(id, attachmentToSave);
    }

    public List<Attachment> removeAttachment(String id, String fileId) throws IOException {
        try {
            fileManagerAdminService.removeFile(fileId);
        } catch (FatalProcessingException | ApplicationException e) {
            throw new ApplicationException("Was not able to upload the file");
        }

        return microservice.removeAttachment(id, fileId);
    }

    public MaintenanceProcedure saveToolsAndMaterials(String id, List<ToolsAndMaterial> toolsAndMaterials) {
        for (ToolsAndMaterial toolsAndMaterial : toolsAndMaterials) {
            if (StringUtil.isEmptyOrNull(toolsAndMaterial.description)) {
                throw new ApplicationException("Description is required");
            }
        }
        return microservice.saveToolsAndMaterials(id, toolsAndMaterials);
    }

    public MaintenanceProcedure saveResources(String id, List<Resource> resources) {
        for (Resource resource : resources) {
            if (StringUtil.isEmptyOrNull(resource.name)) {
                throw new ApplicationException("Name is required");
            }
            if (StringUtil.isEmptyOrNull(resource.description)) {
                throw new ApplicationException("Description is required");
            }
        }
        return microservice.saveResources(id, resources);
    }

    public MaintenanceProcedure saveReview(@NotNull String id, @NotNull Review review) {
        if (StringUtil.isEmptyOrNull(review.auditedBy) && review.auditDate != null) {
            throw new ApplicationException("Review Audit By is required");
        }
        if (review.auditDate == null && !StringUtil.isEmptyOrNull(review.auditedBy)) {
            throw new ApplicationException("Review Audit Date is required");
        }
        return microservice.saveReview(id, review);
    }

    public MaintenanceProcedure saveProcedureHeader(MaintenanceProcedure procedure) {
        boolean schedulesExist = assetScheduleService.schedulesExistForMaintenanceProcedure(procedure.getId());
        if (schedulesExist) {
            MaintenanceProcedure persisted = findById(procedure.getId());
            checkChangesInReadonlyFields(procedure, persisted);
        }
        MaintenanceProcedure persisted = findById(procedure.getId());
        boolean procedureIdentifierExists = !persisted.procedureIdentifier.equals(procedure.procedureIdentifier) &&
                procedureIdentifierExists(procedure.procedureIdentifier);
        maintenanceProcedureValidator.validate(procedure, procedureIdentifierExists);

        return microservice.saveProcedureHeader(procedure);
    }

    public Frequency addFrequency(Frequency frequency) {
        return systemService.addFrequency(frequency);
    }

    public Frequency updateFrequency(Frequency frequency) {
        if (!frequency.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.managedByNodeRef.getId())) {
            throw new ApplicationException("Does not have the privileges to update the Frequency record");
        }
        return systemService.updateFrequency(frequency);
    }

    public void deleteFrequency(Frequency frequency) {
        if (!frequency.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.managedByNodeRef.getId())) {
            throw new ApplicationException("Does not have the privileges to delete the Frequency record.");
        }
        systemService.deleteFrequency(frequency);
    }

    public List<FrequencyRef> getAllFrequencyRefs() {
        return systemService.getAllFrequencyRefs();
    }

    public List<SpecialtyRef> getAllSpecialties() {
        return microservice.getAllSpecialties();
    }

    public MaintenanceProcedureSummary getMaintenanceProcedureSummaryById(String id) {
        return microservice.getMaintenanceProcedureSummaryById(id);
    }

    public MaintenanceProcedure saveTasks(String procedureIdentifier, List<String> tasks) {
        return microservice.saveTasks(procedureIdentifier, tasks);
    }

    public MaintenanceProcedure saveSafety(String id, String editSafety) {
        return microservice.saveSafety(id, editSafety);
    }

    public Skill addSkill(Skill skill) {
        Skill foundSkill = microservice.getSkillByCodeAndName(skill.authoritativeCode, skill.name);
        if (foundSkill == null) {
            skill.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.addSkill(skill);
        } else {
            throw new ApplicationException("Skill already exists");
        }
    }

    public Skill updateSkill(Skill skill) {
        if (!skill.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.managedByNodeRef.getId())) {
            throw new ApplicationException("Does not have the privileges to update the Skill record.");
        } else {
            Skill foundSkill = microservice.getSkillById(skill.getId());
            if (foundSkill == null) {
                throw new ApplicationException("Skill does not exist");
            } else {
                if (!(foundSkill.name.equalsIgnoreCase(skill.name) && foundSkill.authoritativeCode.equalsIgnoreCase(skill.authoritativeCode)) && microservice.getSkillByCodeAndName(skill.authoritativeCode, skill.name) != null) {
                    throw new ApplicationException("Skill already exists");
                } else {
                    return microservice.updateSkill(skill);
                }
            }
        }
    }

    public void deleteSkill(String skillId) {
        List<Skill> listOfSkills = getAllSkills();
        Skill foundSkillRecord = new Skill();
        for (Skill s : listOfSkills) {
            if (s.getId().equals(skillId)) {
                foundSkillRecord = s;
            }
        }

        if (!foundSkillRecord.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.managedByNodeRef.getId())) {
            throw new ApplicationException("Does not have the privileges to delete the Skill record.");
        }
        microservice.deleteSkill(skillId);
    }

    public void deleteSkillById(String skillId) {
        // Version to be called as part of a data load...skips scoping check
        microservice.deleteSkill(skillId);
    }

    public void loadSkill(Skill skill) {
        microservice.loadSkill(skill);
    }

    public List<Skill> getAllSkills() {
        return microservice.getAllSkills();
    }

    public MaintenanceProcedure saveNote(String id, Note note) {
        return microservice.saveNote(id, note);
    }

    public MaintenanceProcedure removeNote(String id, Note note) {
        return microservice.removeNote(id, note);
    }

    public MaintenanceProcedure saveInspection(String id, String candidate, String notes) {
        return microservice.saveInspection(id, candidate, notes);
    }

    public List<MaintenanceProcedure> getProceduresByAuthoritativeSourceId(String id) {
        return microservice.getProceduresByAuthoritativeSourceId(id);
    }

    public MaintenanceProcedure saveNewRpssProcedure(MaintenanceProcedure maintenanceProcedure) {
        boolean procedureIdentifierExists = procedureIdentifierExists(maintenanceProcedure.procedureIdentifier);
        maintenanceProcedureValidator.validate(maintenanceProcedure, procedureIdentifierExists);
        maintenanceProcedure.authoritativeSourceRef = systemService.getAuthoritativeSourceRefByCode(AUTHORITATIVE_SOURCE_CODE_RPSS);
        maintenanceProcedure.owningOrganizationRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.saveNewProcedure(maintenanceProcedure);
    }

    public MaintenanceProcedure saveNewProcedure(MaintenanceProcedure maintenanceProcedure) {
        boolean procedureIdentifierExists = procedureIdentifierExists(maintenanceProcedure.procedureIdentifier);
        maintenanceProcedureValidator.validate(maintenanceProcedure, procedureIdentifierExists);
        return microservice.saveNewProcedure(maintenanceProcedure);
    }

    private boolean procedureIdentifierExists(String procedureIdentifier, String owningOrgId) {
        return microservice.procedureIdentifierExists(procedureIdentifier, owningOrgId);
    }

    public boolean procedureIdentifierExists(String procedureIdentifier) {
        return procedureIdentifierExists(procedureIdentifier, currentUserBT.getCurrentNodeId());
    }

    public MaintenanceProcedure saveAssemblyCategoryRef(String id, AssemblyCategoryRef assemblyCategoryRef) {
        return microservice.saveAssemblyCategoryRef(id, assemblyCategoryRef);
    }

    public MaintenanceProcedure saveAuthoritativeSourceRef(String id, AuthoritativeSourceRef authoritativeSourceRef) {
        return microservice.saveAuthoritativeSourceRef(id, authoritativeSourceRef);
    }

    public MaintenanceProcedure saveFacilitySystemRef(String id, FacilitySystemRef facilitySystemRef) {
        return microservice.saveFacilitySystemRef(id, facilitySystemRef);
    }

    public MaintenanceProcedure saveFacilitySubsystemRef(String id, FacilitySubsystemRef facilitySubsystemRef) {
        return microservice.saveFacilitySubsystemRef(id, facilitySubsystemRef);
    }

    public MaintenanceProcedure saveFrequencyRef(String id, FrequencyRef frequencyRef) {
        return microservice.saveFrequencyRef(id, frequencyRef);
    }

    public MaintenanceProcedure saveNomenclatureRef(String id, NomenclatureRef nomenclatureRef) {
        return microservice.saveNomenclatureRef(id, nomenclatureRef);
    }

    public MaintenanceProcedure saveOwningOrganizationRef(String id, OrganizationRef owningOrganizationRef) {
        return microservice.saveOwningOrganizationRef(id, owningOrganizationRef);
    }

    public MaintenanceProcedure saveSkillRef(String id, SkillRef skillRef) {
        return microservice.saveSkillRef(id, skillRef);
    }

    private void checkChangesInReadonlyFields(MaintenanceProcedure procedure, MaintenanceProcedure persisted) {
        if (!persisted.procedureIdentifier.equals(procedure.procedureIdentifier)) {
            throw new ApplicationException("Cannot edit Procedure Identifier. This Procedure has Schedule(s) associated with it.");
        }
        if (!persisted.frequencyRef.id.equals(procedure.frequencyRef.id)) {
            throw new ApplicationException("Cannot edit Frequency. This Procedure has Schedule(s) associated with it.");
        }
        if (!persisted.skillRef.id.equals(procedure.skillRef.id)) {
            throw new ApplicationException("Cannot edit Skill. This Procedure has Schedule(s) associated with it.");
        }
        if (!persisted.nomenclatureRef.id.equals(procedure.nomenclatureRef.id)) {
            throw new ApplicationException("Cannot edit Nomenclature. This Procedure has Schedule(s) associated with it.");
        }
        if (persisted.isActive ^ procedure.isActive) {
            throw new ApplicationException("Cannot edit Active state. This Procedure has Schedule(s) associated with it.");
        }
    }

    public void processOrganizationRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processOrganizationRefUpdate(dataReferenceUpdate);
    }

    public void processFrequencyRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processFrequencyRefUpdate(dataReferenceUpdate);
    }

    public List<String> getEProcedureOccupancyTypes() {
        return EProcedureOccupancyType.getDisplayTextList();
    }

    public void processRegulatoryComplianceActionRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processRegulatoryComplianceActionRefUpdate(dataReferenceUpdate);
    }

    public void processRegulatoryComplianceCodeRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processRegulatoryComplianceCodeRefUpdate(dataReferenceUpdate);
    }

    public boolean schedulesExistForMaintenanceProcedure(String maintenanceProcedureId) {
        return assetScheduleService.schedulesExistForMaintenanceProcedure(maintenanceProcedureId);
    }

    private MaintenanceProcedure convertRpssToMaintenanceProcedure(MaintenanceProcedureRpss rpss) {
        MaintenanceProcedure mp = new MaintenanceProcedure();

        mp.procedureIdentifier = StringUtil.safeTrim(rpss.procedureIdentifier);
        mp.serviceSpecificMaint = StringUtil.safeTrim(rpss.serviceSpecificMaint);
        mp.safetyPrecautions = StringUtil.safeTrim(rpss.safetyPrecautions);
        mp.agencyName = StringUtil.safeTrim(rpss.agencyName);
        mp.accreditationParagraph = StringUtil.safeTrim(rpss.accreditationParagraph);
        mp.accreditationReference = StringUtil.safeTrim(rpss.accreditationReference);
        mp.ambulatoryParagraph = StringUtil.safeTrim(rpss.ambulatoryParagraph);
        mp.ambulatoryReference = StringUtil.safeTrim(rpss.ambulatoryReference);
        mp.procedureType = StringUtil.safeTrim(rpss.procedureType);
        mp.maintDriverAgency = StringUtil.safeTrim(rpss.maintDriverAgency);
        mp.maintDriver = StringUtil.safeTrim(rpss.maintDriverRefAndYear);
        mp.maintDriverPara = StringUtil.safeTrim(rpss.maintDriverPara);
        mp.ipiNotes = StringUtil.safeTrim(rpss.ipiNotes);
        mp.estimatedLaborHours = rpss.estimatedLaborHours;

        mp.frequencyRef = getFrequencyRefFromRpss(rpss);
        mp.facilitySystemRef = getFacilitySystemRefFromRpss(rpss);
        mp.facilitySubsystemRef = getFacilitySubsystemRefFromRpss(rpss);
        mp.assemblyCategoryRef = getAssemblyCategoryRefFromRpss(rpss);
        mp.nomenclatureRef = getNomenclatureRefFromRpss(rpss);
        mp.tasks = getTasksFromRpss(rpss);
        mp.toolsAndMaterials = getToolsAndMaterialsFromRpss(rpss);
        mp.skillRef = getSkillRefFromRpss(rpss);
        mp.eProcedureOccupancyTypes = getProcedureOccupancyTypesFromRpss(rpss);
        mp.ipiCandidate = getIpiCandidateFromRpss(rpss);

        mp.authoritativeSourceRef = getRpssAuthoritativeSourceRef();
        mp.owningOrganizationRef = null;
        mp.isActive = true;

        maintenanceProcedureValidator.validate(mp, false);
        return mp;
    }

    private AuthoritativeSourceRef getRpssAuthoritativeSourceRef() {
        return systemService.getAuthoritativeSourceRefByCode(AUTHORITATIVE_SOURCE_CODE_RPSS);
    }

    private FrequencyRef getFrequencyRefFromRpss(MaintenanceProcedureRpss rpss) {
        FrequencyRef ref = null;
        if (!StringUtil.isBlankOrNull(rpss.frequency)) {
            Frequency frequency = systemService.getFrequencyByName(rpss.frequency.trim());
            if (frequency != null) {
                ref = frequency.getRef();
            }
        }
        return ref;
    }

    private FacilitySystemRef getFacilitySystemRefFromRpss(MaintenanceProcedureRpss rpss) {
        FacilitySystemRef ref = null;
        if (!StringUtil.isBlankOrNull(rpss.facilitySystem)) {
            List<String> fields = StringUtil.splitIntoTwoAfterFirstSpace(rpss.facilitySystem.trim());
            if (!ListUtil.isEmpty(fields)) {
                ref = microservice.getFacilitySystemRefByCode(fields.get(0));
            }
        }
        return ref;
    }

    private FacilitySubsystemRef getFacilitySubsystemRefFromRpss(MaintenanceProcedureRpss rpss) {
        FacilitySubsystemRef ref = null;
        if (!StringUtil.isBlankOrNull(rpss.facilitySubsystem)) {
            List<String> fields = StringUtil.splitIntoTwoAfterFirstSpace(rpss.facilitySubsystem.trim());
            if (!ListUtil.isEmpty(fields)) {
                ref = microservice.getFacilitySubsystemRefByCode(fields.get(0));
            }
        }
        return ref;
    }

    private AssemblyCategoryRef getAssemblyCategoryRefFromRpss(MaintenanceProcedureRpss rpss) {
        AssemblyCategoryRef ref = null;
        if (!StringUtil.isBlankOrNull(rpss.assemblyCategory)) {
            List<String> fields = StringUtil.splitIntoTwoAfterFirstSpace(rpss.assemblyCategory.trim());
            if (!ListUtil.isEmpty(fields)) {
                ref = microservice.getAssemblyCategoryRefByCode(fields.get(0));
            }
        }
        return ref;
    }

    private NomenclatureRef getNomenclatureRefFromRpss(MaintenanceProcedureRpss rpss) {
        NomenclatureRef ref = null;
        if (!StringUtil.isBlankOrNull(rpss.nomenclature)) {
            List<String> fields = StringUtil.splitIntoTwoAfterFirstSpace(rpss.nomenclature.trim());
            if (!ListUtil.isEmpty(fields) && fields.size() == 2) {
                ref = microservice.getNomenclatureRefByCodeAndText(fields.get(0), fields.get(1));
            }
        }
        return ref;
    }

    private SkillRef getSkillRefFromRpss(MaintenanceProcedureRpss rpss) {
        SkillRef ref = null;
        if (!StringUtil.isBlankOrNull(rpss.specialtyShop)) {
            ref = microservice.getSkillRefByCode(rpss.specialtyShop.trim());
        }
        return ref;
    }

    private List<String> getTasksFromRpss(MaintenanceProcedureRpss rpss) {
        List<String> tasks = null;
        if (!ListUtil.isEmpty(rpss.tasksList)) {
            tasks = StringUtil.trimEachEntryOfList(rpss.tasksList);
        } else if (!StringUtil.isBlankOrNull(rpss.tasksString)) {
            tasks = StringUtil.convertLinefeedDelimitedToList(rpss.tasksString.trim());
        }
        return tasks;
    }

    private List<ToolsAndMaterial> getToolsAndMaterialsFromRpss(MaintenanceProcedureRpss rpss) {
        List<ToolsAndMaterial> tools = null;
        List<String> descriptions = new ArrayList<>();

        if (!ListUtil.isEmpty(rpss.toolsAndMaterialsList)) {
            descriptions = StringUtil.trimEachEntryOfList(rpss.toolsAndMaterialsList);
        } else if (!StringUtil.isBlankOrNull(rpss.toolsAndMaterialsString)) {
            descriptions = StringUtil.convertLinefeedDelimitedToList(rpss.toolsAndMaterialsString.trim());
        }

        // Fortify Note: This finding should be suppressed. The code is checking for null before referencing descriptions.
        if (Objects.nonNull(descriptions) && !ListUtil.isEmpty(descriptions)) {
            tools = new ArrayList<>();
            for (String desc : descriptions) {
                ToolsAndMaterial tool = new ToolsAndMaterial(desc);
                tools.add(tool);
            }
        }
        return tools;
    }

    private List<EProcedureOccupancyType> getProcedureOccupancyTypesFromRpss(MaintenanceProcedureRpss rpss) {
        List<EProcedureOccupancyType> eList = null;

        if (!ListUtil.isEmpty(rpss.procedureOccupancyTypesList)) {
            eList = rpss.procedureOccupancyTypesList;

        } else if (!StringUtil.isBlankOrNull(rpss.procedureOccupancyTypesString)) {
            List<String> entries =
                    StringUtil.convertCsvToList(rpss.procedureOccupancyTypesString.trim(), StringUtil.EIncludeEmpty.No);
            if (!ListUtil.isEmpty(entries)) {
                eList = new ArrayList<>();
                for (String entry : entries) {
                    try {
                        EProcedureOccupancyType eProcedureOccupancyType = EProcedureOccupancyType.fromValue(StringUtil.capitalize(entry.trim()));
                        eList.add(eProcedureOccupancyType);
                    } catch (IllegalArgumentException e) {
                        throw new ApplicationException(e);
                    }
                }
            }
        }
        return eList;
    }

    private Boolean getIpiCandidateFromRpss(MaintenanceProcedureRpss rpss) {
        Boolean retVal = null;
        String ipiCandidateString = StringUtil.safeTrim(rpss.ipiCandidate);
        if (!StringUtil.isBlankOrNull(ipiCandidateString)) {
            try {
                retVal = stringUtil.convertYesNoStringToBoolean(ipiCandidateString);
            } catch (EmptyStackException e) {
                throw new ApplicationException(e);
            }
        }
        return retVal;
    }

    public List<NomenclatureRef> getAllNomenclatureRefs() {
        return microservice.getAllNomenclatureRefs();
    }

    public Nomenclature getNomenclatureById(String id) {
        return microservice.getNomenclatureById(id);
    }

    public SkillRef getSkillRefByCodeOrNameIgnoreCase(String value) {
        return microservice.getSkillRefByCodeOrNameIgnoreCase(value);
    }

    public SkillRef getSkillRefByCode(String code) {
        return microservice.getSkillRefByCode(code);
    }

    public NomenclatureRef getNomenclatureRefByCodeAndText(String code, String text) {
        return microservice.getNomenclatureRefByCodeAndText(code, text);
    }

}
