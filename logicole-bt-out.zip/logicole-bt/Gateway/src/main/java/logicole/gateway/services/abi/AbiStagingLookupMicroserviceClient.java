package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiStagingLookupMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiStagingLookupMicroserviceClient extends MicroserviceClient<IAbiStagingLookupMicroserviceApi> {
    public AbiStagingLookupMicroserviceClient() {
        super(IAbiStagingLookupMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiStagingLookupMicroserviceApi getABiStagingLookupService() {
        return createClient();
    }
}

