package logicole.gateway.services.order;

import io.swagger.annotations.Api;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.communications.ordering.PurchasingStatusWrapper;
import logicole.common.datamodels.delivery.DueOutRef;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.output.AuthorizedNode;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.order.order.*;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountDTO;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Api(tags = {"Order"})
@ApplicationScoped
@Path("/order")
public class OrderRestApi extends ExternalRestApi<OrderService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @POST
    @Path("/addOrder")
    public List<OrderResponseDTO> submitOrder(OrderDTO order) {
        return service.addOrder(order);
    }

    @GET
    @Path("/getOrdersForReviewBySite")
    public List<BuyerOrderItems> getOrdersForReviewBySite(){
        return service.getOrdersForReviewBySite();
    }

    @GET
    @Path("/getOrders")
    public List<OrderItem> getOrdersByBuyerId() {
        return service.getOrders();
    }

    @GET
    @Path("/getOrdersByUserId")
    public List<OrderItem> getOrdersByUserId(@QueryParam("userId") String userId) {
        return service.getOrdersByUserId(userId);
    }

    @GET
    @Path("/changeQuantityOrderLineItem")
    public OrderItem changeQuantityOrderLineItem(@QueryParam("orderId") String orderId, @QueryParam("orderLineItemId") String orderLineItemId, @QueryParam("quantity") Integer quantity) {
        return service.changeQuantityOrderLineItem(orderId, orderLineItemId, quantity);
    }

    @GET
    @Path("/cancelOrder")
    public OrderDTO cancelOrder(@QueryParam("id") String id) {
        return service.cancelOrder(id);
    }

    @POST
    @Path("/updateOrderInformation")
    public OrderInformation updateOrderInformation(OrderInformation orderInformation){
        return service.updateOrderInformation(orderInformation);
    }

    @POST
    @Path("/updateOrderItemDetails")
    public OrderItem updateOrderItemDetails(OrderItem orderItem){
        return service.updateOrderItemDetails(orderItem);
    }

    @GET
    @Path("/updateItemRemainingQuantity")
    public OrderItem updateItemRemainingQuantity(@QueryParam("orderId") String orderId, @QueryParam("orderLineItemId") String orderLineItemId, @QueryParam("quantity") Integer quantity) {
        return service.updateItemRemainingQuantity(orderId, orderLineItemId, quantity);
    }

    @POST
    @Path("/updateItemPrice")
    public OrderItem updateItemPrice(@QueryParam("orderId") String orderId, @QueryParam("orderLineItemId") String orderLineItemId, MonetaryValue price) {
        return service.updateItemPrice(orderId, orderLineItemId, price);
    }

    @GET
    @Path("/sendItemFollowUp")
    public OrderItem sendItemFollowUp(@QueryParam("orderId") String orderId, @QueryParam("orderLineItemId") String orderLineItemId) {
        return service.sendItemFollowUp(orderId, orderLineItemId);
    }

    @GET
    @Path("/getInternalReferenceId")
    @Produces(MediaType.TEXT_PLAIN)
    public String getInternalReferenceId(@QueryParam("nodeID") String nodeID) {
        return service.getInternalReferenceId(nodeID);
    }

    @GET
    @Path("/getExternalOrderConfiguration")
    public ExternalOrderConfiguration getExternalOrderConfiguration(@QueryParam("id") String id) {
        return service.getExternalOrderConfiguration(id);
    }

    @GET
    @Path("/getExternalOrderConfigurationByOrganizationLabel")
    public ExternalOrderConfiguration getExternalOrderConfigurationByOrganizationLabel(@QueryParam("label") String label) {
        return service.getExternalOrderConfigurationByOrganizationLabel(label);
    }

    @GET
    @Path("/getExternalVendorByOrganizationLabelAndVendorCode")
    public ExternalVendor getExternalVendorByOrganizationLabelAndVendorCode(@QueryParam("label") String label, @QueryParam("vendorCode") String vendorCode) {
        return service.getExternalVendorByOrganizationLabelAndVendorCode(label, vendorCode);
    }

    @GET
    @Path("/getOrderInformationById")
    public OrderInformation getOrderInformationById(@QueryParam("orderId") String orderId) {
        return service.getOrderInformationById(orderId);
    }

    @GET
    @Path("/getOrderItemById")
    public OrderItem getOrderItemById(@QueryParam("orderItemId") String orderId) {
        return service.getOrderItemById(orderId);
    }

    @POST
    @Path("/addNoteToOrder")
    public OrderDTO addNoteToOrder(@QueryParam("orderId") String orderId, Note note){
        return service.addNoteToOrder(orderId, note);
    }

    @GET
    @Path("/removeNoteFromOrder")
    public OrderDTO removeNoteFromOrder(@QueryParam("orderId") String orderId, @QueryParam("noteId") String noteId){
        return service.removeNoteFromOrder(orderId, noteId);
    }

    @POST
    @Path("/getOrderItemSearchResults")
    public SearchResult<OrderItem> getOrderItemSearchResults(SearchInput searchInput) {
        return service.getOrderItemSearchResults(searchInput);
    }

    @GET
    @Path("/ingestOrderItemStatus")
    public void ingestOrderItemStatus(PurchasingStatusWrapper purchasingStatusWrapper) {
        service.ingestOrderItemStatus(purchasingStatusWrapper);
    }

    @GET
    @Path("/getOrderById")
    public OrderDTO getOrderById(@QueryParam("orderId") String orderId){
        return service.getOrderById(orderId);
    }

    @POST
    @Path("/updateLinkedDueOuts")
    public void updateLinkedDueOuts(List<DueOutRef> dueOutRefs) {
        service.updateLinkedDueOuts(dueOutRefs);
    }

    @GET
    @Path("/getCommodityCodeRefsByTransportation")
    public List<CommodityCodeRef> getCommodityCodeRefsByTransportation() {
        return service.getCommodityCodeRefsByTransportation();
    }

    @POST
    @Path("/getFundsByCommodity")
    public List<FundingNodeRef> getFundsByCommodity(CommodityCodeRef commodityCodeRef) {
        return service.getFundsByCommodity(commodityCodeRef);
    }

    @GET
    @Path("/rejectOrderItemRemainingQuantity")
    public List<BuyerOrderItems> rejectOrderItemRemainingQuantity(@QueryParam("orderItemId") String orderItemId){
        return service.rejectOrderItemRemainingQuantity(orderItemId);
    }

    @GET
    @Path("/cancelPendingOrderItem")
    public OrderItem cancelPendingOrderItem(@QueryParam("orderItemId") String orderItemId){
        return service.cancelPendingOrderItem(orderItemId);
    }

    @GET
    @Path("/getBuyerSellerAccountListByOrgId")
    public List<BuyerSellerAccountDTO> getBuyerSellerAccountListByOrgId(){
        return service.getBuyerSellerAccountListByOrgId();
    }

    @POST
    @Path("/approveOrder")
    public List<BuyerOrderItems> approveOrder(BuyerOrderItems buyerOrder) {
        return service.approveOrder(buyerOrder);
    }

    @POST
    @Path("/updateReceiptQuantity")
    public boolean updateReceiptQuantity(List<OrderItem> orderItems) {
        return service.updateReceiptQuantity(orderItems);
    }
}
