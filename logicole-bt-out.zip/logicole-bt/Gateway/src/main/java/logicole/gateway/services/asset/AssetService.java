package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.businesscontact.BusinessContact;
import logicole.common.datamodels.asset.businesscontact.BusinessContactRef;
import logicole.common.datamodels.asset.classification.AssemblyCategoryRef;
import logicole.common.datamodels.asset.classification.ManufacturerRef;
import logicole.common.datamodels.asset.classification.NomenclatureRef;
import logicole.common.datamodels.asset.classification.VendorRef;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceCodeRef;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceSubject;
import logicole.common.datamodels.asset.management.AcquisitionInformation;
import logicole.common.datamodels.asset.management.AdditionalInformation;
import logicole.common.datamodels.asset.management.AssemblyInformation;
import logicole.common.datamodels.asset.management.Assessment;
import logicole.common.datamodels.asset.management.AssessmentOrganizationRef;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.asset.management.AssetBulkUpdateCapacities;
import logicole.common.datamodels.asset.management.AssetBulkUpdateHazards;
import logicole.common.datamodels.asset.management.AssetBulkUpdateReference;
import logicole.common.datamodels.asset.management.AssetBulkUpdateRequest;
import logicole.common.datamodels.asset.management.AssetBulkUpdateResult;
import logicole.common.datamodels.asset.management.AssetBulkUpdateSpace;
import logicole.common.datamodels.asset.management.AssetBulkUpdateSpecifications;
import logicole.common.datamodels.asset.management.AssetBulkUpdateStandards;
import logicole.common.datamodels.asset.management.AssetBulkUpdateZones;
import logicole.common.datamodels.asset.management.AssetBusinessContact;
import logicole.common.datamodels.asset.management.AssetCostSummary;
import logicole.common.datamodels.asset.management.AssetGroup;
import logicole.common.datamodels.asset.management.AssetGroupRef;
import logicole.common.datamodels.asset.management.AssetInventoryStats;
import logicole.common.datamodels.asset.management.AssetProductInformation;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.AssetSearchResult;
import logicole.common.datamodels.asset.management.AssetSummary;
import logicole.common.datamodels.asset.management.AssetWarrantyInfo;
import logicole.common.datamodels.asset.management.AuditInformation;
import logicole.common.datamodels.asset.management.CapacityUnit;
import logicole.common.datamodels.asset.management.ConditionInformation;
import logicole.common.datamodels.asset.management.DeletedEquipment;
import logicole.common.datamodels.asset.management.EAssetType;
import logicole.common.datamodels.asset.management.ECalendarType;
import logicole.common.datamodels.asset.management.EEnvironmentalHazard;
import logicole.common.datamodels.asset.management.EQaQcInspectionMethod;
import logicole.common.datamodels.asset.management.ERelatedCause;
import logicole.common.datamodels.asset.management.ERiskFactor;
import logicole.common.datamodels.asset.management.Features;
import logicole.common.datamodels.asset.management.LocationInformation;
import logicole.common.datamodels.asset.management.MaintenanceContractInformation;
import logicole.common.datamodels.asset.management.PrimeComponent;
import logicole.common.datamodels.asset.management.RealPropertyAsset;
import logicole.common.datamodels.asset.management.ReferenceDocument;
import logicole.common.datamodels.asset.management.Specification;
import logicole.common.datamodels.asset.management.SpecificationUnit;
import logicole.common.datamodels.asset.management.Warranty;
import logicole.common.datamodels.asset.management.dropDownFeeders.ConditionEntry;
import logicole.common.datamodels.asset.management.dropDownFeeders.RiskLevelEntry;
import logicole.common.datamodels.asset.schedule.Schedule;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.filemanager.FileRef;
import logicole.common.datamodels.general.Contact;
import logicole.common.datamodels.general.EActiveStatus;
import logicole.common.datamodels.general.customfield.CustomField;
import logicole.common.datamodels.general.customfield.CustomFieldRef;
import logicole.common.datamodels.general.customfield.CustomFieldValue;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationType;
import logicole.common.datamodels.product.Capacity;
import logicole.common.datamodels.realproperty.Installation;
import logicole.common.datamodels.realproperty.InstallationRef;
import logicole.common.datamodels.realproperty.Site;
import logicole.common.datamodels.realproperty.SiteRef;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.realproperty.facility.FacilityRef;
import logicole.common.datamodels.realproperty.facility.FacilitySummary;
import logicole.common.datamodels.realpropertyproject.Requirement;
import logicole.common.datamodels.realpropertyproject.project.ProjectSummary;
import logicole.common.datamodels.realpropertysection.Section;
import logicole.common.datamodels.realpropertysection.SectionRef;
import logicole.common.datamodels.realpropertysection.SectionSummary;
import logicole.common.datamodels.space.Floor;
import logicole.common.datamodels.space.FloorPlanLegendEntry;
import logicole.common.datamodels.space.GraphicalSearchRecord;
import logicole.common.datamodels.space.RoomMetadata;
import logicole.common.datamodels.space.RoomRelatedRecordCounts;
import logicole.common.datamodels.space.RoomSummary;
import logicole.common.datamodels.space.Space;
import logicole.common.datamodels.space.SpaceRef;
import logicole.common.datamodels.space.Zone;
import logicole.common.datamodels.space.ZoneRef;
import logicole.common.datamodels.space.cobie.export.AssetCOBieExportData;
import logicole.common.datamodels.space.lookupdata.FloorPlanLayer;
import logicole.common.datamodels.system.EBusinessArea;
import logicole.common.datamodels.system.TagRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.workorder.ActualCost;
import logicole.common.datamodels.workorder.Assignment;
import logicole.common.datamodels.workorder.Standards;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.datamodels.workorder.WorkOrderHistory;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.DateUtil;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.validation.AssetValidator;
import logicole.gateway.services.asset.validation.StandardsValidator;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.realproperty.InstallationService;
import logicole.gateway.services.realpropertyproject.ProjectService;
import logicole.gateway.services.realpropertyproject.RequirementService;
import logicole.gateway.services.realpropertysection.SectionService;
import logicole.gateway.services.spacemanagement.DrawingService;
import logicole.gateway.services.spacemanagement.SpaceManagementService;
import logicole.gateway.services.system.CustomFieldService;
import logicole.gateway.services.system.TagService;
import logicole.gateway.services.user.UserService;
import logicole.gateway.services.workorder.WorkOrderService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import static logicole.gateway.services.workorder.WorkOrderService.CLASSIFICATION_TYPE_NAME_RECURRING_WORK;

@ApplicationScoped
public class AssetService extends BaseGatewayService<IAssetMicroserviceApi> {

    private static final String ASSET_ID_REQUIRED = "Equipment IDs are required.";
    private static final String ALREADY_EXISTS = "already exists on this record";
    private static final String DID_NOT_EXIST = "did not exist on this record";
    private static final String ADD = "ADD";
    private static final String REMOVE = "REMOVE";
    private static final String UPDATE = "UPDATE";
    private static final String VALIDATE_INSTALL_DATE_AFTER_WARRANTY_START_DATE_ERR = "Install / Major Upgrade Date must not be prior to Warranty Start Date.";
    private static final String VALIDATE_ALL_RPE_ERR = "This record cannot be removed as it is referenced elsewhere in the application. Please set this record to inactive.";
    private static final String VALIDATE_BULK_UPDATE_RPE_HAS_OPEN_WORKORDER_ERR = "This record has open work order(s) and cannot be set to inactive.";
    private static final String VALIDATE_BULK_UPDATE_RPE_HAS_OPEN_MAINTENANCE_SCHEDULE_ERR = "This record has open maintenance schedule(s) and cannot be set to inactive. ";
    private static final String VALIDATE_BULK_UPDATE_RPE_HAS_OPEN_REQUIREMENT_ERR = "This record has open requirement(s) and cannot be set to inactive.";
    private static final String VALIDATE_BULK_UPDATE_RPE_BELONGS_TO_GROUP = "This record belongs to an Equipment Group and cannot be set to inactive.";
    private static final String ASSET_CUSTOMIZABLE_TYPE_ID = "5fbc1626fa954c348feaf08e";
    private static final String INVALID_ATTACHMENT_MSG = "Attachment is missing or is not valid";
    private static final String INVALID_HAZARD_MSG = "Hazard is missing or is not valid";

    @Inject
    private DateUtil dateUtil;

    @Inject
    private StringUtil stringUtil;

    @Inject
    AssetGroupService assetGroupService;

    @Inject
    AssetScheduleService assetScheduleService;

    @Inject
    BusinessContactService businessContactService;

    @Inject
    CustomFieldService customFieldService;

    @Inject
    FacilityService facilityService;

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    InstallationService installationService;

    @Inject
    OrganizationService organizationService;

    @Inject
    RequirementService requirementService;

    @Inject
    SectionService sectionService;

    @Inject
    SpaceManagementService spaceManagementService;

    @Inject
    TagService tagService;

    @Inject
    UserService userService;

    @Inject
    WorkOrderService workOrderService;

    @Inject
    ProjectService projectService;

    @Inject
    DrawingService drawingService;

    @Inject
    StandardsValidator standardsValidator;

    @Inject
    AssetValidator assetValidator;

    private Integer maxUploadSize;

    public AssetService() {
        super("Asset");
    }

    public Asset addAssetNote(String assetId, Note note) {
        return microservice.addAssetNote(assetId, note);
    }

    public Asset addReferenceDocument(String assetId, ReferenceDocument referenceDocument) {
        return microservice.addReferenceDocument(assetId, referenceDocument);
    }

    public void addSectionRefToAssets(String sectionId, List<String> assetIdList) {
        Section section = sectionService.getSectionById(sectionId);
        SectionRef sectionRef = section.getRef();
        assetIdList.forEach(assetId -> microservice.addSectionRefToAsset(assetId, sectionRef));
    }

    public void removeSectionRefFromAssets(List<String> assetIdList) {
        assetIdList.forEach(assetId -> microservice.removeSectionRefFromAsset(assetId));
    }

    public Asset addStandard(String assetId, Standards standards) {
        standardsValidator.validate(standards);
        return microservice.addStandard(assetId, standards);
    }

    public Asset addSubComponents(String assetId, List<String> subComponentIdList) {
        return microservice.addSubComponents(assetId, subComponentIdList);
    }

    public void deleteAssetRefFromAssets(AssetRef assetRef) {
        microservice.deleteAssetRefFromAssets(assetRef);
    }

    public Asset removeAssetNote(String assetId, Note note) {
        return microservice.removeAssetNote(assetId, note);
    }

    public List<DeletedEquipment> removeEquipment(List<String> equipmentIdList) {
        boolean isDeleteOk;

        List<DeletedEquipment> deletedEquipmentList = new ArrayList<>();
        Asset asset;

        for (String id : equipmentIdList) {
            DeletedEquipment deletedEquipment = new DeletedEquipment();
            asset = getAssetById(id);

            if (asset.assetType == EAssetType.MEDICAL_EQUIPMENT) {
                isDeleteOk = validateMEForDelete();
            } else {
                isDeleteOk = validateRPEForDelete(asset);
            }

            if (isDeleteOk) {
                microservice.deleteEquipment(asset);
                deletedEquipment.identifier = asset.identifier;
                deletedEquipment.isDeleted = true;
            } else {
                deletedEquipment.identifier = asset.identifier;
                deletedEquipment.isDeleted = false;
            }

            deletedEquipmentList.add(deletedEquipment);
        }

        return deletedEquipmentList;
    }

    private boolean validateMEForDelete() {
        return false;
    }

    private boolean validateRPEForDelete(Asset asset) {
        boolean isDeleteOk = true;
        String id = asset.getId();
        long activeCount = workOrderService.getActiveWorkOrderCountByAssetId(id) +
                assetScheduleService.getActiveScheduleCountByAssetId(id) +
                requirementService.getActiveRequirementCountByAsset(id) +
                sectionService.getActiveSectionCountByAssetId(id);

        if (Boolean.TRUE.equals(asset.isActive) && (activeCount > 0 || (asset.assetGroupRef != null && asset.assetGroupRef.id != null))) {
            isDeleteOk = false;
        }

        return isDeleteOk;
    }

    public Asset addTagToAsset(String assetId, TagRef tagRef) {
        return microservice.addTagToAsset(assetId, tagRef);
    }

    public List<Installation> getAllActiveInstallations() {
        return installationService.getAllInstallations(true);
    }

    public Asset removeTagFromAsset(String assetId, TagRef tagRef) {
        return microservice.removeTagFromAsset(assetId, tagRef);
    }

    public List<String> getAssetTypes() {
        return EAssetType.getActiveDisplayTextList();
    }

    public Asset getAssetById(String id) {
        return microservice.getAssetById(id);
    }

    public List<AssetSummary> getAssetsByIds(List<AssetRef> assetList) {
        return microservice.getAssetsByIds(assetList);
    }

    public AssetInventoryStats getAssetInventoryStats() {
        return microservice.getAssetInventoryStats();
    }

    public List<AssetWarrantyInfo> getAssetsByWarrantyInfo(String assetWarrantyType, int daysRemainingCheck) {
        return microservice.getAssetsByWarrantyInfo(assetWarrantyType, daysRemainingCheck);
    }

    public List<String> getCustomFieldTypes() {
        return customFieldService.getCustomFieldTypes();
    }

    public List<CustomFieldRef> getAssetCustomFieldRefs() {
        return customFieldService.getAllCustomFields(ASSET_CUSTOMIZABLE_TYPE_ID).stream()
                .map(CustomField::getRef)
                .collect(Collectors.toList());
    }

    public List<AssetSummary> getRpeAssetsByFacilityId(String facilityId) {
        return microservice.getRpeAssetsByFacilityId(facilityId, EActiveStatus.ALL);
    }

    public List<AssetSummary> getRpeAssetsForSections(String sectionId, String facilityId) {
        return microservice.getRpeAssetsForSections(sectionId, facilityId);
    }

    public List<AssetSummary> getRpeAssetsByFacilityIds(List<FacilityRef> facilityList) {
        return microservice.getRpeAssetsByFacilityIds(facilityList);
    }

    public List<AssetSummary> getRpeAssetsForSpace(String facilityId, String roomId) {
        return microservice.getRpeAssetsForSpace(facilityId, roomId);
    }

    public List<Asset> getAssetsByGroupId(String assetGroupId) {
        return microservice.getAssetsByAssetGroupId(assetGroupId);
    }

    public List<PrimeComponent> getPrimeComponents(@NotNull String assetId, @NotNull String facilityId) {
        return microservice.getPrimeComponents(assetId, facilityId);
    }

    public List<RegulatoryComplianceCodeRef> getRcCodes() {
        return workOrderService.getRegulatoryComplianceCodeRefs();
    }

    public List<RegulatoryComplianceSubject> getRcSubjects() {
        return microservice.getRcSubjects();
    }

    public List<Asset> getRpeAssetsWithNoAssetGroup(String nomenclatureId, String facilityId) {
        return microservice.getRpeAssetsWithNoAssetGroup(nomenclatureId, facilityId);
    }

    public List<Asset> getSubComponentsForPrime(@NotNull String assetId) {
        return microservice.getSubComponentsForPrime(assetId);
    }

    public List<Asset> getSubComponentsNoPrime(@NotNull String assetId, @NotNull String facilityId, String primeId) {
        return microservice.getSubComponentsNoPrime(assetId, facilityId, primeId);
    }

    public List<SiteRef> getSiteRefsForInstallation(String installationId) {
        List<Site> sites = installationService.getSitesForInstallation(installationId);
        ArrayList<SiteRef> siteRefs = new ArrayList<>();
        sites.forEach(site -> siteRefs.add((SiteRef) site.getRef()));
        return siteRefs;
    }

    public Asset saveAsset(@NotNull Asset asset) {
        assetValidator.validateFacilityAndOrganization(asset);

        if (asset.managedByNodeRef == null || StringUtil.isEmptyOrNull(asset.managedByNodeRef.id)) {
            asset.managedByNodeRef = getManagedByNodeRef(asset.locationInformation.facilityRef.id);
        }
        assetValidator.validate(asset);

        boolean isNew = asset.getId() != null;
        Asset updatedAsset = microservice.saveAsset(asset);
        if (isNew) {
            assetScheduleService.onCreateAsset(asset);
        }

        return updatedAsset;
    }

    public SearchResult<AssetSearchResult> getAssetSearchResults(SearchInput searchInput) {
        SearchResult<AssetSearchResult> searchResult;
        ESearchEngine searchEngine = microservice.getAssetSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported at this time.");
        } else {
            organizationService.setRPFuncFilterInSearch(searchInput);
            searchResult = microservice.getAssetSearchResults(searchInput);
        }

        return searchResult;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateRecordStatus(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = validateBulkUpdate(request);

        List<String> validAssetIds = results.stream()
                .filter(result -> ListUtil.isEmpty(result.errorMessages))
                .map(result -> result.id)
                .collect(Collectors.toList());

        if (!validAssetIds.isEmpty()) {
            request.assetIds = validAssetIds;
            if (microservice.saveBulkUpdateRecordStatus(request) != request.assetIds.size()) {
                throw new ApplicationException("Error updating asset records.");
            }
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateRemoveRecords(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = validateBulkUpdateRPE(request);

        List<String> validAssetIds = results.stream()
                .filter(result -> ListUtil.isEmpty(result.errorMessages))
                .map(result -> result.id)
                .collect(Collectors.toList());

        if (!validAssetIds.isEmpty()) {
            request.assetIds = validAssetIds;
            for (String id : request.assetIds) {
                Asset asset = getAssetById(id);
                microservice.deleteEquipment(asset);
            }
        }
        return results;
    }

    public List<AssetBulkUpdateResult> validateBulkUpdate(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        List<Asset> assets = microservice.getAssetsByAssetIds(request.assetIds);
        for (Asset asset : assets) {
            AssetRef assetRef = asset.getRef();
            AssetBulkUpdateResult result = new AssetBulkUpdateResult(assetRef.id, assetRef.identifier, assetRef.nomenclatureRef, assetRef.facilityRef);
            List<String> errors = getBulkUpdateValidationErrors(asset, request);
            if (!errors.isEmpty()) {
                result.errorMessages.addAll(errors);
            }
            results.add(result);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> validateBulkUpdateRPE(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        List<Asset> assets = microservice.getAssetsByAssetIds(request.assetIds);
        for (Asset asset : assets) {
            AssetRef assetRef = asset.getRef();
            AssetBulkUpdateResult result = new AssetBulkUpdateResult(assetRef.id, assetRef.identifier, assetRef.nomenclatureRef, assetRef.facilityRef);
            List<String> errors = getBulkUpdateRPEValidationErrors(asset, request);
            if (!errors.isEmpty()) {
                result.errorMessages.addAll(errors);
            }
            results.add(result);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateAssembly(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        if (request.barcode != null) {
            results = saveBulkUpdateBarcode(request);
        }
        if (request.rpssEngineeringId != null) {
            results = saveBulkUpdateEngineeringRpeId(request);
        }
        if (request.rpssEngineeringId != null) {
            results = saveBulkUpdateEngineeringRpeId(request);
        }
        if (request.pmScheduleRequired != null) {
            results = saveBulkUpdatePmScheduleRequired(request);
        }
        if (request.pmPerformedWithPrimeComponent != null) {
            results = saveBulkUpdatePmPerformedOnPrimeComponent(request);
        }
        if (request.primeComponentId != null) {
            results = saveBulkUpdateParentAssetRef(request);
        }
        if (request.realPropertyEquipmentSpare != null) {
            results = saveBulkUpdateRealPropertyEquipmentSpare(request);
        }
        if (request.sectionId != null) {
            results = saveBulkUpdateSectionName(request);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateAudit(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        if (request.auditBy != null) {
            results = saveBulkUpdateAuditBy(request);
        }
        if (request.auditDate != null) {
            results = saveBulkUpdateAuditDate(request);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateAdditional(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        if (request.qaInspectionMethod != null) {
            results = saveBulkUpdateQaInspectionMethod(request);
        }
        if (request.qcInspectionMethod != null) {
            results = saveBulkUpdateQcInspectionMethod(request);
        }
        if (request.riskFactor != null) {
            results = saveBulkUpdateRiskFactor(request);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateConditionAssessment(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        if (isConditionAssessmentUpdated(request)) {
            results = new ArrayList<>();
            for (String assetId : request.assetIds) {
                Asset asset = microservice.getAssetById(assetId);
                List<Assessment> assessments = new ArrayList<>(asset.conditionInformation.assessments);
                Assessment newAssessment = getNewAssessmentData(request, assessments);

                assessments.add(0, newAssessment);
                Asset updatedAsset = microservice.saveBulkUpdateConditionAssessments(assetId, assessments);
                AssetRef assetRef = updatedAsset.getRef();
                AssetBulkUpdateResult result = new AssetBulkUpdateResult(assetRef.id, assetRef.identifier, assetRef.nomenclatureRef, assetRef.facilityRef);
                results.add(result);
            }
        }
        return results;
    }

    private Assessment getNewAssessmentData(AssetBulkUpdateRequest request, List<Assessment> assessments) {
        Assessment newAssessment = new Assessment();
        if (!assessments.isEmpty()) {
            newAssessment.assessingOrganization = assessments.get(0).assessingOrganization;
            newAssessment.pointOfContact = assessments.get(0).pointOfContact;
            newAssessment.condition = assessments.get(0).condition;
            newAssessment.conditionDeterminationDate = assessments.get(0).conditionDeterminationDate;
            newAssessment.relatedCause = assessments.get(0).relatedCause;
            newAssessment.lifeUsed = assessments.get(0).lifeUsed;
            newAssessment.conditionObservations = assessments.get(0).conditionObservations;
            newAssessment.conditionRecommendations = assessments.get(0).conditionRecommendations;
            newAssessment.createdBy = userService.getUserProfile().getFullName();
            newAssessment.createdDate = new Date();
        }
        if (request.assessingOrganization != null) {
            newAssessment.assessingOrganization = request.assessingOrganization;
            newAssessment.pointOfContact = request.pointOfContact;
        }
        if (request.condition != null) {
            newAssessment.condition = request.condition;
        }
        if (request.conditionDeterminationDate != null) {
            newAssessment.conditionDeterminationDate = request.conditionDeterminationDate;
        }
        if (request.relatedCause != null) {
            newAssessment.relatedCause = request.relatedCause;
        }
        if (request.lifeUsed != null) {
            newAssessment.lifeUsed = request.lifeUsed;
        }
        if (request.conditionObservations != null) {
            newAssessment.conditionObservations = request.conditionObservations;
        }
        if (request.conditionRecommendations != null) {
            newAssessment.conditionRecommendations = request.conditionRecommendations;
        }

        return newAssessment;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateConditionInformation(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        if (request.installDate != null) {
            results = saveBulkUpdateInstallDate(request);
        }
        if (request.lifeExpectancyInYears != null) {
            results = saveBulkUpdateLifeExpectancyInYears(request);
        }
        if (request.isAssessmentRequired != null) {
            results = saveBulkUpdateAssessmentRequired(request);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateCostInformation(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        if (request.acquisitionCost != null) {
            results = saveBulkUpdateAcquisitionCost(request);
        }
        if (request.costInformationReplacementCost != null) {
            results = saveBulkUpdateCostInformationReplacementCost(request);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateLocation(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        if (request.spaceRefId != null) {
            results = saveBulkUpdateSpaceRef(request);
        }
        if (request.otherLocation != null) {
            results = saveBulkUpdateOtherLocation(request);
        }
        if (request.zoneId != null) {
            results = saveBulkUpdateZone(request);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateMaintenanceContractInformation(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        if (request.maintenanceContractNumber != null) {
            results = saveBulkUpdateMaintenanceContractNumber(request);
        }
        if (request.maintenanceContractor != null) {
            results = saveBulkUpdateMaintenanceContractor(request);
        }
        if (request.maintenanceContractStartDate != null) {
            results = saveBulkUpdateMaintenanceContractStartDate(request);
        }
        if (request.maintenanceContractTitle != null) {
            results = saveBulkUpdateMaintenanceContractTitle(request);
        }
        if (request.maintenanceContractEndDate != null) {
            results = saveBulkUpdateMaintenanceContractEndDate(request);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateProductInformation(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        if (request.productManufacturerSerialNumber != null) {
            results = saveBulkUpdateProductManufacturerSerialNumber(request);
        }
        if (request.productManufacturerNameId != null) {
            results = saveBulkUpdateProductManufacturerName(request);
        }
        if (request.productModelNumber != null) {
            results = saveBulkUpdateProductModelNumber(request);
        }
        if (request.productCatalogNumber != null) {
            results = saveBulkUpdateProductCatalogNumber(request);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateSpaceRooms(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        for (String assetId : request.assetIds) {
            Asset asset = getAssetById(assetId);
            AssetRef assetRef = asset.getRef();
            AssetBulkUpdateResult result = new AssetBulkUpdateResult(assetRef.id, assetRef.identifier, assetRef.nomenclatureRef, assetRef.facilityRef);
            Map<String, SpaceRef> spaceMap = asset.spaceRefList.stream()
                    .collect(Collectors.toMap(SpaceRef::getId, Function.identity()));
            for (AssetBulkUpdateSpace bulkUpdateSpace : request.spaceBulkUpdates) {
                Space space = spaceManagementService.getRoomById(bulkUpdateSpace.spaceRef.getId());
                if (ADD.equalsIgnoreCase(bulkUpdateSpace.updateAction)) {
                    addSpaceBulkUpdate(spaceMap, space, result);
                } else if (REMOVE.equalsIgnoreCase(bulkUpdateSpace.updateAction)) {
                    removeSpaceBulkUpdate(spaceMap, space, result);
                }
            }
            List<SpaceRef> spaceRefs = new ArrayList<>(spaceMap.values());
            microservice.saveBulkUpdateSpaceRooms(assetId, spaceRefs);
            results.add(result);
        }
        return results;
    }

    private void addSpaceBulkUpdate(Map<String, SpaceRef> spaceMap, Space space, AssetBulkUpdateResult result) {
        if (spaceMap.containsKey(space.getId())) {
            String msg = "Add failed: Room '" + space.identifier + " - " + space.localName + "' " + ALREADY_EXISTS;
            result.errorMessages.add(msg);
        } else {
            spaceMap.put(space.getId(), space.getRef());
        }
    }

    private void removeSpaceBulkUpdate(Map<String, SpaceRef> spaceMap, Space space, AssetBulkUpdateResult result) {
        if (!spaceMap.containsKey(space.getId())) {
            String msg = "Remove failed: Room '" + space.identifier + " - " + space.localName + "' " + DID_NOT_EXIST;
            result.errorMessages.add(msg);
        } else {
            spaceMap.remove(space.getId());
        }
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateSpaceZones(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        for (String assetId : request.assetIds) {
            Asset asset = getAssetById(assetId);
            AssetRef assetRef = asset.getRef();
            AssetBulkUpdateResult result = new AssetBulkUpdateResult(assetRef.id, assetRef.identifier, assetRef.nomenclatureRef, assetRef.facilityRef);
            Map<String, ZoneRef> zonesMap = asset.zoneRefList.stream()
                    .collect(Collectors.toMap(ZoneRef::getId, Function.identity()));
            for (AssetBulkUpdateZones bulkUpdateZones : request.zonesBulkUpdates) {
                Zone zone = spaceManagementService.getZoneById(bulkUpdateZones.zoneId);
                if (ADD.equalsIgnoreCase(bulkUpdateZones.updateAction)) {
                    addZoneBulkUpdate(zonesMap, zone, result);
                } else if (REMOVE.equalsIgnoreCase(bulkUpdateZones.updateAction)) {
                    removeZoneBulkUpdate(zonesMap, zone, result);
                }
            }
            List<ZoneRef> zoneRefs = new ArrayList<>(zonesMap.values());
            microservice.saveBulkUpdateSpaceZones(assetId, zoneRefs);
            results.add(result);
        }
        return results;
    }

    private void addZoneBulkUpdate(Map<String, ZoneRef> zonesMap, Zone zone, AssetBulkUpdateResult result) {
        if (zonesMap.containsKey(zone.getId())) {
            String msg = "Add failed: Zone '" + zone.name + " - " + zone.description + "' " + ALREADY_EXISTS;
            result.errorMessages.add(msg);
        } else {
            zonesMap.put(zone.getId(), (ZoneRef) zone.getRef());
        }
    }

    private void removeZoneBulkUpdate(Map<String, ZoneRef> zonesMap, Zone zone, AssetBulkUpdateResult result) {
        if (!zonesMap.containsKey(zone.getId())) {
            String msg = "Remove failed: Zone '" + zone.name + " - " + zone.description + "' " + DID_NOT_EXIST;
            result.errorMessages.add(msg);
        } else {
            zonesMap.remove(zone.getId());
        }
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateWarrantyInformation(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        if (request.warrantyPurchaseOrderNumber != null) {
            results = saveBulkUpdateWarrantyPurchaseOrderNumber(request);
        }
        if (request.warrantyContact != null) {
            results = saveBulkUpdateWarrantyVendorContact(request);
        }
        if (request.warrantyLaborDuration != null) {
            results = saveBulkUpdateWarrantyLaborDuration(request);
        }
        if (request.warrantyPartsDuration != null) {
            results = saveBulkUpdateWarrantyPartsDuration(request);
        }
        if (request.warrantyStartDate != null) {
            results = saveBulkUpdateWarrantyStartDate(request);
        }
        return results;
    }

    private boolean isConditionAssessmentUpdated(AssetBulkUpdateRequest request) {
        return request.assessingOrganization != null
                || request.pointOfContact != null
                || request.condition != null
                || request.conditionDeterminationDate != null
                || request.relatedCause != null
                || request.lifeUsed != null
                || request.conditionObservations != null
                || request.conditionRecommendations != null;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateHazards(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        
        List<String> validHazards = EEnvironmentalHazard.getDisplayTextList();
        if ( request.hazardUpdates.stream().anyMatch(hazardUpdate-> hazardUpdate.hazard == null || !validHazards.contains(hazardUpdate.hazard.displayText)) ) {
            throw new ApplicationException(INVALID_HAZARD_MSG);
        }
        
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        for (String assetId : request.assetIds) {
            Asset asset = microservice.getAssetById(assetId);
            AssetRef assetRef = asset.getRef();
            AssetBulkUpdateResult result = new AssetBulkUpdateResult(assetRef.id, assetRef.identifier, assetRef.nomenclatureRef, assetRef.facilityRef);
            Set<EEnvironmentalHazard> hazards = new HashSet<>(asset.features.hazards);
            for (AssetBulkUpdateHazards hazardUpdate : request.hazardUpdates) {
                if (ADD.equalsIgnoreCase(hazardUpdate.updateAction) && !hazards.add(hazardUpdate.hazard)) {
                    String msg = "Hazard '" + hazardUpdate.hazard.getJsonValue() + "' " + ALREADY_EXISTS;
                    result.errorMessages.add(msg);
                }
                if (REMOVE.equalsIgnoreCase(hazardUpdate.updateAction) && !hazards.remove(hazardUpdate.hazard)) {
                    String msg = "Hazard '" + hazardUpdate.hazard.getJsonValue() + "' " + DID_NOT_EXIST;
                    result.errorMessages.add(msg);
                }
            }
            microservice.saveBulkUpdateHazards(assetId, hazards);
            results.add(result);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateCustomFields(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        Map<String, CustomFieldValue> customFieldUpdatesMap = request.customFieldUpdates.stream()
                .collect(Collectors.toMap(c -> c.customFieldRef.label, Function.identity()));
        for (String assetId : request.assetIds) {
            Asset asset = microservice.getAssetById(assetId);
            AssetRef assetRef = asset.getRef();
            AssetBulkUpdateResult result = new AssetBulkUpdateResult(assetRef.id, assetRef.identifier, assetRef.nomenclatureRef, assetRef.facilityRef);

            Map<String, CustomFieldValue> customFieldsMap = asset.customFieldValues.stream()
                    .collect(Collectors.toMap(c -> c.customFieldRef.label, Function.identity()));

            for (Map.Entry<String, CustomFieldValue> entry : customFieldUpdatesMap.entrySet()) {
                String label = entry.getKey();
                customFieldsMap.put(label, customFieldUpdatesMap.get(label));
            }

            List<CustomFieldValue> updatedCustomFields = new ArrayList<>(customFieldsMap.values());
            microservice.saveBulkUpdateCustomFields(assetId, updatedCustomFields);
            results.add(result);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateCapacities(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        for (String assetId : request.assetIds) {
            Asset asset = microservice.getAssetById(assetId);
            AssetRef assetRef = asset.getRef();
            AssetBulkUpdateResult result = new AssetBulkUpdateResult(assetRef.id, assetRef.identifier, assetRef.nomenclatureRef, assetRef.facilityRef);
            List<Capacity> capacities = new ArrayList<>(asset.features.capacity);
            Map<String, Capacity> capacitiesMap = capacities.stream()
                    .collect(Collectors.toMap(s -> s.capacityUnit, Function.identity()));
            for (AssetBulkUpdateCapacities capacityUpdate : request.capacityUpdates) {
                addBulkUpdateCapacities(capacityUpdate, capacitiesMap, result);
                removeBulkCapacities(capacityUpdate, capacitiesMap, result);
                updateBulkCapacities(capacityUpdate, capacitiesMap, result);
            }
            List updatedCapacities = new ArrayList<>(capacitiesMap.values());
            microservice.saveBulkUpdateCapacities(assetId, updatedCapacities);
            results.add(result);
        }
        return results;
    }

    private void addBulkUpdateCapacities(AssetBulkUpdateCapacities capacityUpdate, Map<String, Capacity> capacitiesMap, AssetBulkUpdateResult result) {
        if (ADD.equalsIgnoreCase(capacityUpdate.updateAction)) {
            if (!capacitiesMap.containsKey(capacityUpdate.capacity.capacityUnit)) {
                capacitiesMap.put(capacityUpdate.capacity.capacityUnit, capacityUpdate.capacity);
            } else {
                String msg = "Add failed: Capacity '" + capacityUpdate.capacity.capacityUnit + "' " + ALREADY_EXISTS;
                result.errorMessages.add(msg);
            }
        }
    }

    private void removeBulkCapacities(AssetBulkUpdateCapacities capacityUpdate, Map<String, Capacity> capacitiesMap, AssetBulkUpdateResult result) {
        if (REMOVE.equalsIgnoreCase(capacityUpdate.updateAction)) {
            if (capacitiesMap.containsKey((capacityUpdate.capacity.capacityUnit))) {
                capacitiesMap.remove(capacityUpdate.capacity.capacityUnit);
            } else {
                String msg = "Remove failed: Capacity '" + capacityUpdate.capacity.capacityUnit + "' " + DID_NOT_EXIST;
                result.errorMessages.add(msg);
            }
        }
    }

    private void updateBulkCapacities(AssetBulkUpdateCapacities capacityUpdate, Map<String, Capacity> capacitiesMap, AssetBulkUpdateResult result) {
        if (UPDATE.equalsIgnoreCase(capacityUpdate.updateAction)) {
            if (capacitiesMap.containsKey(capacityUpdate.capacity.capacityUnit)) {
                capacitiesMap.put(capacityUpdate.capacity.capacityUnit, capacityUpdate.capacity);
            } else {
                String msg = "Update failed: Capacity '" + capacityUpdate.capacity.capacityUnit + "' " + DID_NOT_EXIST;
                result.errorMessages.add(msg);
            }
        }
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateSpecifications(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        for (String assetId : request.assetIds) {
            Asset asset = microservice.getAssetById(assetId);
            AssetRef assetRef = asset.getRef();
            AssetBulkUpdateResult result = new AssetBulkUpdateResult(assetRef.id, assetRef.identifier, assetRef.nomenclatureRef, assetRef.facilityRef);
            List<Specification> specifications = new ArrayList<>(asset.features.specifications);
            Map<String, Specification> specificationsMap = specifications.stream()
                    .collect(Collectors.toMap(s -> s.specificationUnit, Function.identity()));
            for (AssetBulkUpdateSpecifications specificationUpdate : request.specificationUpdates) {
                addBulkUpdateSpecifications(specificationUpdate, specificationsMap, result);
                removeBulkSpecifications(specificationUpdate, specificationsMap, result);
                updateBulkSpecifications(specificationUpdate, specificationsMap, result);
            }
            List updatedSpecifications = new ArrayList<>(specificationsMap.values());
            microservice.saveBulkUpdateSpecifications(assetId, updatedSpecifications);
            results.add(result);
        }
        return results;
    }

    private void addBulkUpdateSpecifications(AssetBulkUpdateSpecifications specificationUpdate, Map<String, Specification> specificationsMap, AssetBulkUpdateResult result) {
        if (ADD.equalsIgnoreCase(specificationUpdate.updateAction)) {
            if (!specificationsMap.containsKey(specificationUpdate.specification.specificationUnit)) {
                specificationsMap.put(specificationUpdate.specification.specificationUnit, specificationUpdate.specification);
            } else {
                String msg = "Add failed: Specification '" + specificationUpdate.specification.specificationUnit + "' " + ALREADY_EXISTS;
                result.errorMessages.add(msg);
            }
        }
    }

    private void removeBulkSpecifications(AssetBulkUpdateSpecifications specificationUpdate, Map<String, Specification> specificationsMap, AssetBulkUpdateResult result) {
        if (REMOVE.equalsIgnoreCase(specificationUpdate.updateAction)) {
            if (specificationsMap.containsKey((specificationUpdate.specification.specificationUnit))) {
                specificationsMap.remove(specificationUpdate.specification.specificationUnit);
            } else {
                String msg = "Remove failed: Specification '" + specificationUpdate.specification.specificationUnit + "' " + DID_NOT_EXIST;
                result.errorMessages.add(msg);
            }
        }
    }

    private void updateBulkSpecifications(AssetBulkUpdateSpecifications specificationUpdate, Map<String, Specification> specificationsMap, AssetBulkUpdateResult result) {
        if (UPDATE.equalsIgnoreCase(specificationUpdate.updateAction)) {
            if (specificationsMap.containsKey(specificationUpdate.specification.specificationUnit)) {
                specificationsMap.put(specificationUpdate.specification.specificationUnit, specificationUpdate.specification);
            } else {
                String msg = "Update failed: Specification '" + specificationUpdate.specification.specificationUnit + "' " + DID_NOT_EXIST;
                result.errorMessages.add(msg);
            }
        }
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateReferenceDocuments(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        for (String assetId : request.assetIds) {
            Asset asset = microservice.getAssetById(assetId);
            AssetRef assetRef = asset.getRef();
            AssetBulkUpdateResult result = new AssetBulkUpdateResult(assetRef.id, assetRef.identifier, assetRef.nomenclatureRef, assetRef.facilityRef);
            List<ReferenceDocument> referenceDocuments = asset.referenceDocuments;
            if (referenceDocuments == null) {
                referenceDocuments = new ArrayList<>();
            }
            Map<String, ReferenceDocument> referenceDocumentsMap = referenceDocuments.stream()
                    .collect(Collectors.toMap(r -> r.text, Function.identity()));
            for (AssetBulkUpdateReference referenceUpdate : request.referenceUpdates) {
                if (StringUtil.isEmptyOrNull(referenceUpdate.referenceDocument.text)) {
                    String msg = referenceUpdate.updateAction + " failed. Reference Text is required";
                    result.errorMessages.add(msg);
                } else {
                    addBulkUpdateReferenceDocuments(referenceUpdate, referenceDocumentsMap, result);
                    removeBulkUpdateReferenceDocuments(referenceUpdate, referenceDocumentsMap, result);
                    updateBulkUpdateReferenceDocuments(referenceUpdate, referenceDocumentsMap, result);
                }
            }
            List<ReferenceDocument> updatedReferenceDocuments = new ArrayList<>(referenceDocumentsMap.values());
            microservice.saveBulkUpdateReferenceDocuments(asset.getId(), updatedReferenceDocuments);
            results.add(result);
        }
        return results;
    }

    private void addBulkUpdateReferenceDocuments(AssetBulkUpdateReference referenceUpdate, Map<String, ReferenceDocument> referenceDocumentsMap, AssetBulkUpdateResult result) {
        if (ADD.equalsIgnoreCase(referenceUpdate.updateAction)) {
            if (!referenceDocumentsMap.containsKey(referenceUpdate.referenceDocument.text)) {
                ReferenceDocument referenceDocument = new ReferenceDocument();
                referenceDocument.text = referenceUpdate.referenceDocument.text;
                referenceDocument.referenceDocumentId = stringUtil.getUUID();
                referenceDocumentsMap.put(referenceDocument.text, referenceDocument);
            } else {
                String msg = "Add failed: Reference Document '" + referenceUpdate.referenceDocument.text + "' " + ALREADY_EXISTS;
                result.errorMessages.add(msg);
            }
        }
    }

    private void removeBulkUpdateReferenceDocuments(AssetBulkUpdateReference referenceUpdate, Map<String, ReferenceDocument> referenceDocumentsMap, AssetBulkUpdateResult result) {
        if (REMOVE.equalsIgnoreCase(referenceUpdate.updateAction)) {
            if (referenceDocumentsMap.containsKey(referenceUpdate.referenceDocument.text)) {
                referenceDocumentsMap.remove(referenceUpdate.referenceDocument.text);
            } else {
                String msg = "Remove failed: Reference Document '" + referenceUpdate.referenceDocument.text + "' " + DID_NOT_EXIST;
                result.errorMessages.add(msg);
            }
        }
    }

    private void updateBulkUpdateReferenceDocuments(AssetBulkUpdateReference referenceUpdate, Map<String, ReferenceDocument> referenceDocumentsMap, AssetBulkUpdateResult result) {
        if (UPDATE.equalsIgnoreCase(referenceUpdate.updateAction)) {
            if (referenceUpdate.updatedReferenceDocument == null || StringUtil.isEmptyOrNull(referenceUpdate.updatedReferenceDocument.text)) {
                String msg = "Update failed: Reference Document update text is missing";
                result.errorMessages.add(msg);
            } else if (referenceDocumentsMap.containsKey(referenceUpdate.referenceDocument.text)) {
                ReferenceDocument updateReference = referenceDocumentsMap.get(referenceUpdate.referenceDocument.text);
                updateReference.text = referenceUpdate.updatedReferenceDocument.text;
                referenceDocumentsMap.remove(referenceUpdate.referenceDocument.text);
                referenceDocumentsMap.put(referenceUpdate.updatedReferenceDocument.text, updateReference);
            } else {
                String msg = "Update failed: Reference Document '" + referenceUpdate.referenceDocument.text + "' " + DID_NOT_EXIST;
                result.errorMessages.add(msg);
            }
        }
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateStandards(AssetBulkUpdateRequest request) {
        if (request == null || request.assetIds == null) {
            throw new ApplicationException(ASSET_ID_REQUIRED);
        }
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        for (String assetId : request.assetIds) {
            Asset asset = microservice.getAssetById(assetId);
            AssetRef assetRef = asset.getRef();
            AssetBulkUpdateResult result = new AssetBulkUpdateResult(assetRef.id, assetRef.identifier, assetRef.nomenclatureRef, assetRef.facilityRef);
            List<Standards> standards = asset.standards;
            if (standards == null) {
                standards = new ArrayList<>();
            }
            Map<String, Standards> standardsMap = standards.stream()
                    .collect(Collectors.toMap(s -> s.regulatoryComplianceCodeRef.getId(), Function.identity()));
            validateBulkUpdateStandards(request, result, standardsMap);

            List<Standards> standardsList = new ArrayList<>(standardsMap.values());
            microservice.saveBulkUpdateStandards(asset.getId(), standardsList);
            results.add(result);
        }
        return results;
    }

    private void validateBulkUpdateStandards(AssetBulkUpdateRequest request, AssetBulkUpdateResult result, Map<String, Standards> standardsMap) {
        for (AssetBulkUpdateStandards standardsUpdate : request.standardsUpdates) {
            String validationMsg = getStandardBulkUpdateValidation(standardsUpdate.standards);
            if (!StringUtil.isEmptyOrNull(validationMsg)) {
                String msg = standardsUpdate.updateAction + " failed: " + validationMsg;
                result.errorMessages.add(msg);
            } else {
                String regulatoryComplianceId = standardsUpdate.standards.regulatoryComplianceCodeRef.getId();
                if (ADD.equalsIgnoreCase(standardsUpdate.updateAction)) {
                    addBulkUpdateStandards(result, standardsUpdate, standardsMap, regulatoryComplianceId);
                } else if (REMOVE.equalsIgnoreCase(standardsUpdate.updateAction)) {
                    removeBulkUpdateStandards(result, standardsUpdate, standardsMap, regulatoryComplianceId);
                } else if (UPDATE.equalsIgnoreCase(standardsUpdate.updateAction)) {
                    updateBulkUpdateStandards(result, standardsUpdate, standardsMap, regulatoryComplianceId);
                }
            }
        }
    }

    private void addBulkUpdateStandards(AssetBulkUpdateResult result, AssetBulkUpdateStandards standardsUpdate, Map<String, Standards> standardsMap, String regulatoryComplianceId) {
        if (!standardsMap.containsKey(regulatoryComplianceId)) {
            Standards standard = new Standards();
            standard.regulatoryComplianceCodeRef = standardsUpdate.standards.regulatoryComplianceCodeRef;
            standard.paragraphNumber = standardsUpdate.standards.paragraphNumber;
            standard.paragraphText = standardsUpdate.standards.paragraphText;
            standard.regulatoryComplianceSubject = standardsUpdate.standards.regulatoryComplianceSubject;
            standardsMap.put(regulatoryComplianceId, standard);
        } else {
            String msg = "Add failed: Standards '" + standardsUpdate.standards.regulatoryComplianceCodeRef.name + "' " + ALREADY_EXISTS;
            result.errorMessages.add(msg);
        }
    }

    private void removeBulkUpdateStandards(AssetBulkUpdateResult result, AssetBulkUpdateStandards standardsUpdate, Map<String, Standards> standardsMap, String regulatoryComplianceId) {
        if (standardsMap.containsKey(regulatoryComplianceId)) {
            standardsMap.remove(regulatoryComplianceId);
        } else {
            String msg = "Remove failed: Standards '" + standardsUpdate.standards.regulatoryComplianceCodeRef.name + "' " + DID_NOT_EXIST;
            result.errorMessages.add(msg);
        }
    }

    private void updateBulkUpdateStandards(AssetBulkUpdateResult result, AssetBulkUpdateStandards standardsUpdate, Map<String, Standards> standardsMap, String regulatoryComplianceId) {
        if (standardsMap.containsKey(regulatoryComplianceId)) {
            Standards standard = standardsMap.get(regulatoryComplianceId);
            standard.regulatoryComplianceSubject = standardsUpdate.standards.regulatoryComplianceSubject;
            standard.paragraphText = standardsUpdate.standards.paragraphText;
            standard.paragraphNumber = standardsUpdate.standards.paragraphNumber;
            standardsMap.put(regulatoryComplianceId, standard);
        } else {
            String msg = "Update failed: Standards '" + standardsUpdate.standards.regulatoryComplianceCodeRef.name + "' " + DID_NOT_EXIST;
            result.errorMessages.add(msg);
        }
    }

    private String getStandardBulkUpdateValidation(Standards standards) {
        String msg = "";
        try {
            standardsValidator.validate(standards);
        } catch (ApplicationException appEx) {
            msg = appEx.getMessage();
        }
        return msg;
    }

    private List<AssetBulkUpdateResult> getAssetBulkUpdateResults(List<Asset> updatedAssets) {
        return updatedAssets.stream()
                .map(asset -> new AssetBulkUpdateResult(
                        asset.getId(),
                        asset.identifier,
                        asset.nomenclatureRef,
                        asset.locationInformation.facilityRef)
                )
                .collect(Collectors.toList());
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateSpaceRef(AssetBulkUpdateRequest request) {
        request.spaceRef = spaceManagementService.getRoomById(request.spaceRefId).getRef();
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateSpaceRef(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateOtherLocation(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateOtherLocation(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateZone(AssetBulkUpdateRequest request) {
        request.zoneRef = (ZoneRef) spaceManagementService.getZoneById(request.zoneId).getRef();
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateZone(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateAcquisitionCost(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateAcquisitionCost(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateMaintenanceContractNumber(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateMaintenanceContractNumber(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateMaintenanceContractor(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateMaintenanceContractor(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateMaintenanceContractStartDate(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateMaintenanceContractStartDate(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateMaintenanceContractTitle(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateMaintenanceContractTitle(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateMaintenanceContractEndDate(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateMaintenanceContractEndDate(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateProductManufacturerName(AssetBulkUpdateRequest request) {
        request.productManufacturerName = businessContactService.getBusinessContactById(request.productManufacturerNameId).getRef();
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateProductManufacturerName(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateProductManufacturerSerialNumber(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateProductManufacturerSerialNumber(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateProductModelNumber(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateProductModelNumber(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateProductCatalogNumber(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateProductCatalogNumber(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateCostInformationReplacementCost(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateCostInformationReplacementCost(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateWarrantyVendorContact(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateWarrantyVendorContact(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateWarrantyPurchaseOrderNumber(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateWarrantyPurchaseOrderNumber(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateWarrantyStartDate(AssetBulkUpdateRequest request) {
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        for (String assetId : request.assetIds) {
            var asset = microservice.getAssetById(assetId);
            var result = new AssetBulkUpdateResult(asset.getId(), asset.identifier, asset.nomenclatureRef, asset.locationInformation.facilityRef);
            LocalDate installDate = (asset.conditionInformation.installDate != null) ? DateUtil.localDateFromDate(asset.conditionInformation.installDate) : null;
            LocalDate warrantyStartDate = DateUtil.localDateFromDate(request.warrantyStartDate);
            if (installDate == null) {
                result.errorMessages.add("Warranty start date cannot be entered until an Install/Major Upgrade date is entered");
            } else if (installDate != null && installDate.isAfter(warrantyStartDate)) {
                result.errorMessages.add("Warranty Start Date must start on or after the Install/Major Upgrade Date");
            }
            if (result.errorMessages.isEmpty()) {
                Warranty warranty = new Warranty();
                warranty.warrantyBeginDate = request.warrantyStartDate;
                warranty.warrantyLaborEndDate = calculateWarrantyLaborEndDate(asset.acquisitionInformation.warranty, warranty);
                warranty.warrantyPartsEndDate = calculateWarrantyPartsEndDate(asset.acquisitionInformation.warranty, warranty);

                microservice.saveBulkUpdateWarrantyStartDate(assetId, warranty);
            }
            results.add(result);
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateWarrantyLaborDuration(AssetBulkUpdateRequest request) {
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        for (String assetId : request.assetIds) {
            var asset = microservice.getAssetById(assetId);
            var result = new AssetBulkUpdateResult(asset.getId(), asset.identifier, asset.nomenclatureRef, asset.locationInformation.facilityRef);
            LocalDate warrantyStartDate = null;
            LocalDate installDate = null;

            if (asset.conditionInformation.installDate != null) {
                installDate = DateUtil.localDateFromDate(asset.conditionInformation.installDate);
            }
            if (request.warrantyStartDate != null) {
                warrantyStartDate = DateUtil.localDateFromDate(request.warrantyStartDate);
            } else if (asset.acquisitionInformation.warranty.warrantyBeginDate != null) {
                warrantyStartDate = DateUtil.localDateFromDate(asset.acquisitionInformation.warranty.warrantyBeginDate);
            }

            warrantyUpdates(request, asset, result, assetId, installDate, warrantyStartDate);
            results.add(result);
        }
        return results;
    }

    private void warrantyUpdates(AssetBulkUpdateRequest request, Asset asset, AssetBulkUpdateResult result, String assetId, LocalDate installDate, LocalDate warrantyStartDate) {
        Warranty warranty = new Warranty();

        if (installDate == null || warrantyStartDate == null) {
            warranty.warrantyBeginDate = null;
        } else {
            if (installDate != null && warrantyStartDate != null && installDate.isAfter(warrantyStartDate)) {
                warranty.warrantyBeginDate = asset.acquisitionInformation.warranty.warrantyBeginDate;
            } else {
                warranty.warrantyBeginDate = request.warrantyStartDate;
            }
        }

        warranty.warrantyLaborDuration = request.warrantyLaborDuration;
        warranty.warrantyLaborCalendarType = request.warrantyLaborCalendarType;
        warranty.warrantyLaborEndDate = calculateWarrantyLaborEndDate(asset.acquisitionInformation.warranty, warranty);
        microservice.saveBulkUpdateWarrantyLaborDuration(assetId, warranty);
    }

    private Date calculateWarrantyLaborEndDate(Warranty warranty, Warranty warrantyUpdate) {
        LocalDate warrantyStartDate = null;
        int laborDuration = 0;
        ECalendarType laborCalendarType = null;

        if (warrantyUpdate.warrantyBeginDate != null) {
            warrantyStartDate = DateUtil.localDateFromDate(warrantyUpdate.warrantyBeginDate);
        } else if (warranty.warrantyBeginDate != null) {
            warrantyStartDate = DateUtil.localDateFromDate(warranty.warrantyBeginDate);
        }
        if (warrantyUpdate.warrantyLaborDuration != null) {
            laborDuration = warrantyUpdate.warrantyLaborDuration;
        } else if (warranty.warrantyLaborDuration != null) {
            laborDuration = warranty.warrantyLaborDuration;
        }
        if (warrantyUpdate.warrantyLaborCalendarType != null) {
            laborCalendarType = warrantyUpdate.warrantyLaborCalendarType;
        } else if (warranty.warrantyLaborCalendarType != null) {
            laborCalendarType = warranty.warrantyLaborCalendarType;
        }

        if (warrantyStartDate != null && laborCalendarType != null) {
            if (ECalendarType.DAYS.displayText.equalsIgnoreCase(laborCalendarType.displayText)) {
                warranty.warrantyLaborEndDate = Date.from(warrantyStartDate.plusDays(laborDuration).atStartOfDay(ZoneId.systemDefault()).toInstant());
            }
            if (ECalendarType.MONTHS.displayText.equalsIgnoreCase(laborCalendarType.displayText)) {
                warranty.warrantyLaborEndDate = Date.from(warrantyStartDate.plusMonths(laborDuration).atStartOfDay(ZoneId.systemDefault()).toInstant());
            }
            if (ECalendarType.YEARS.displayText.equalsIgnoreCase(laborCalendarType.displayText)) {
                warranty.warrantyLaborEndDate = Date.from(warrantyStartDate.plusYears(laborDuration).atStartOfDay(ZoneId.systemDefault()).toInstant());
            }
        }
        return warranty.warrantyLaborEndDate;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateWarrantyPartsDuration(AssetBulkUpdateRequest request) {
        List<AssetBulkUpdateResult> results = new ArrayList<>();
        for (String assetId : request.assetIds) {
            var asset = microservice.getAssetById(assetId);
            var result = new AssetBulkUpdateResult(asset.getId(), asset.identifier, asset.nomenclatureRef, asset.locationInformation.facilityRef);
            Warranty warranty = new Warranty();
            LocalDate installDate = null;
            LocalDate warrantyStartDate = null;

            if (asset.conditionInformation.installDate != null) {
                installDate = DateUtil.localDateFromDate(asset.conditionInformation.installDate);
            }
            if (request.warrantyStartDate != null) {
                warrantyStartDate = DateUtil.localDateFromDate(request.warrantyStartDate);
            } else if (asset.acquisitionInformation.warranty.warrantyBeginDate != null) {
                warrantyStartDate = DateUtil.localDateFromDate(asset.acquisitionInformation.warranty.warrantyBeginDate);
            }
            if (installDate == null || warrantyStartDate == null) {
                warranty.warrantyBeginDate = null;
            } else if (installDate != null && warrantyStartDate != null && installDate.isAfter(warrantyStartDate)) {
                warranty.warrantyBeginDate = asset.acquisitionInformation.warranty.warrantyBeginDate;
            } else {
                warranty.warrantyBeginDate = request.warrantyStartDate;
            }
            warranty.warrantyPartsDuration = request.warrantyPartsDuration;
            warranty.warrantyPartsCalendarType = request.warrantyPartsCalendarType;
            warranty.warrantyPartsEndDate = calculateWarrantyPartsEndDate(asset.acquisitionInformation.warranty, warranty);
            microservice.saveBulkUpdateWarrantyPartsDuration(assetId, warranty);
            results.add(result);
        }
        return results;
    }

    private Date calculateWarrantyPartsEndDate(Warranty warranty, Warranty warrantyUpdate) {
        LocalDate warrantyStartDate = null;
        int partsDuration = 0;
        ECalendarType partsCalendarType = null;

        if (warrantyUpdate.warrantyBeginDate != null) {
            warrantyStartDate = DateUtil.localDateFromDate(warrantyUpdate.warrantyBeginDate);
        } else if (warranty.warrantyBeginDate != null) {
            warrantyStartDate = DateUtil.localDateFromDate(warranty.warrantyBeginDate);
        }
        if (warrantyUpdate.warrantyPartsDuration != null) {
            partsDuration = warrantyUpdate.warrantyPartsDuration;
        } else if (warranty.warrantyPartsDuration != null) {
            partsDuration = warranty.warrantyPartsDuration;
        }
        if (warrantyUpdate.warrantyPartsCalendarType != null) {
            partsCalendarType = warrantyUpdate.warrantyPartsCalendarType;
        } else if (warranty.warrantyPartsCalendarType != null) {
            partsCalendarType = warranty.warrantyPartsCalendarType;
        }

        if (warrantyStartDate != null && partsCalendarType != null) {
            if (ECalendarType.DAYS.displayText.equalsIgnoreCase(partsCalendarType.displayText)) {
                warranty.warrantyPartsEndDate = Date.from(warrantyStartDate.plusDays(partsDuration).atStartOfDay(ZoneId.systemDefault()).toInstant());
            }
            if (ECalendarType.MONTHS.displayText.equalsIgnoreCase(partsCalendarType.displayText)) {
                warranty.warrantyPartsEndDate = Date.from(warrantyStartDate.plusMonths(partsDuration).atStartOfDay(ZoneId.systemDefault()).toInstant());
            }
            if (ECalendarType.YEARS.displayText.equalsIgnoreCase(partsCalendarType.displayText)) {
                warranty.warrantyPartsEndDate = Date.from(warrantyStartDate.plusYears(partsDuration).atStartOfDay(ZoneId.systemDefault()).toInstant());
            }
        }
        return warranty.warrantyPartsEndDate;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateRealPropertyEquipmentSpare(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateRealPropertyEquipmentSpare(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateSectionName(AssetBulkUpdateRequest request) {
        request.sectionRef = sectionService.getSectionById(request.sectionId).getRef();
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateSectionName(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateBarcode(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateBarcode(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateParentAssetRef(AssetBulkUpdateRequest request) {
        request.parentAssetRef = microservice.getAssetById(request.primeComponentId).getRef();
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateParentAssetRef(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateEngineeringRpeId(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateEngineeringRpeId(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdatePmScheduleRequired(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdatePmScheduleRequired(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdatePmPerformedOnPrimeComponent(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdatePmPerformedOnPrimeComponent(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateRiskFactor(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateRiskFactor(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateAuditBy(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateAuditBy(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateAuditDate(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateAuditDate(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateQaInspectionMethod(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateQaInspectionMethod(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateQcInspectionMethod(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateQcInspectionMethod(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateInstallDate(AssetBulkUpdateRequest request) {
        List<AssetBulkUpdateResult> results = validateBulkUpdate(request);
        List<String> validAssetIds = results.stream()
                .filter(result -> ListUtil.isEmpty(result.errorMessages))
                .map(result -> result.id)
                .collect(Collectors.toList());

        if (!validAssetIds.isEmpty()) {
            request.assetIds = validAssetIds;
            results.addAll(getAssetBulkUpdateResults(microservice.saveBulkUpdateInstallDate(request)));
        }
        return results;
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateLifeExpectancyInYears(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateLifeExpectancyInYears(request));
    }

    public List<AssetBulkUpdateResult> saveBulkUpdateAssessmentRequired(AssetBulkUpdateRequest request) {
        return getAssetBulkUpdateResults(microservice.saveBulkUpdateAssessmentRequired(request));
    }

    private List<String> getBulkUpdateRPEValidationErrors(Asset asset, AssetBulkUpdateRequest request) {
        List<String> errors = new ArrayList<>();
        String id = asset.getId();
        long activeCount = requirementService.getActiveRequirementCountByAsset(id) +
                assetScheduleService.getActiveScheduleCountByAssetId(id) +
                workOrderService.getActiveWorkOrderCountByAssetId(id) +
                sectionService.getActiveSectionCountByAssetId(id);

        // rules for setting record status to active

        // rules for setting record status to inactive
        if (request.isActive && (activeCount > 0 || (asset.assetGroupRef != null && asset.assetGroupRef.id != null))) {
            errors.add(VALIDATE_ALL_RPE_ERR);
        }

        return errors;
    }

    private List<String> getBulkUpdateValidationErrors(Asset asset, AssetBulkUpdateRequest request) {
        List<String> errors = new ArrayList<>();
        String id = asset.getId();
        long requirementCount = requirementService.getActiveRequirementCountByAsset(id);
        long scheduleCount = assetScheduleService.getActiveScheduleCountByAssetId(id);
        long workOrderCount = workOrderService.getActiveWorkOrderCountByAssetId(id);

        // rules for setting record status to inactive
        if (!request.isActive) {
            if (requirementCount > 0) {
                errors.add(VALIDATE_BULK_UPDATE_RPE_HAS_OPEN_REQUIREMENT_ERR);
            }
            if (scheduleCount > 0) {
                errors.add(VALIDATE_BULK_UPDATE_RPE_HAS_OPEN_MAINTENANCE_SCHEDULE_ERR);
            }
            if (workOrderCount > 0) {
                errors.add(VALIDATE_BULK_UPDATE_RPE_HAS_OPEN_WORKORDER_ERR);
            }
            if (asset.assetGroupRef != null && asset.assetGroupRef.id != null) {
                errors.add(VALIDATE_BULK_UPDATE_RPE_BELONGS_TO_GROUP);
            }
        }

        // rule for setting Install Date
        if (request.installDate != null && asset.acquisitionInformation.warranty.warrantyBeginDate != null) {
            LocalDate warrantyBeginDate = DateUtil.localDateFromDate(asset.acquisitionInformation.warranty.warrantyBeginDate);
            LocalDate installDate = DateUtil.localDateFromDate(request.installDate);
            if (installDate.isAfter((warrantyBeginDate))) {
                errors.add(VALIDATE_INSTALL_DATE_AFTER_WARRANTY_START_DATE_ERR);
            }
        }

        return errors;
    }

    public SearchResult<AssetSearchResult> getAssetSearchResultsByFacilityId(String facilityId, SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getAssetSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported at this time.");
        } else {
            organizationService.setRPFuncFilterInSearch(searchInput);

            SearchResult<AssetSearchResult> searchResult = microservice.getAssetSearchResults(searchInput);

            if (facilityId != null) {
                SearchResult<AssetSearchResult> filteredSearchResult = new SearchResult<>();
                filteredSearchResult.aggregations = searchResult.aggregations;

                if (!ListUtil.isEmpty(searchResult.results)) {
                    List<AssetSearchResult> assetSearchResults;

                    assetSearchResults = getLocationSearchResults(searchResult, facilityId);

                    filteredSearchResult.results = assetSearchResults;
                    filteredSearchResult.total = (long) filteredSearchResult.results.size();
                    searchResult = filteredSearchResult;
                }
            }

            return searchResult;
        }
    }

    private List<AssetSearchResult> getLocationSearchResults(SearchResult<AssetSearchResult> searchResult, String facilityId) {
        List<AssetSearchResult> assetSearchResults = new ArrayList<>();

        for (AssetSearchResult assetSearchResult : searchResult.results) {
            Asset asset = getAssetById(assetSearchResult.id);

            if (asset.locationInformation != null && asset.locationInformation.facilityRef != null &&
                    facilityId.equals(asset.locationInformation.facilityRef.id)) {
                assetSearchResults.add(assetSearchResult);
            }
        }

        return assetSearchResults;
    }

    public boolean removeAttachment(String id, String fileId) throws IOException {
        //This removes the file
        try {
            fileManagerAdminService.removeFile(fileId);
        } catch (FatalProcessingException | ApplicationException e) {
            throw new ApplicationException("Was not able to upload the file");
        }

        return microservice.removeAttachment(id, fileId);
    }

    public Asset saveAssetConditionInformation(String id, ConditionInformation conditionInformation) {
        Asset asset = microservice.getAssetById(id);
        if (asset.acquisitionInformation.warranty.warrantyBeginDate != null) {
            LocalDate warrantyBeginDate = DateUtil.localDateFromDate(asset.acquisitionInformation.warranty.warrantyBeginDate);
            if (conditionInformation.installDate != null) {
                LocalDate installDate = DateUtil.localDateFromDate(conditionInformation.installDate);
                if (warrantyBeginDate.isBefore(installDate)) {
                    throw new ApplicationException(VALIDATE_INSTALL_DATE_AFTER_WARRANTY_START_DATE_ERR);
                }
            }
        }
        microservice.saveAssetConditionInformation(id, conditionInformation);
        Assessment assessment = copyLatestAssessment(asset);
        if (assessment == null) {
            assessment = new Assessment();
        }
        assessment.conditionDeterminationDate = new Date();
        assessment.createdDate = new Date();
        assessment.createdBy = userService.getUserProfile().getFullName();
        assessment.lifeExpectancyInYears = asset.conditionInformation.lifeExpectancyInYears;
        assessment.installDate = asset.conditionInformation.installDate;
        assessment.isAssessmentRequired = asset.conditionInformation.isAssessmentRequired;
        asset.conditionInformation.assessments.add(assessment);
        return microservice.saveAssetConditionAssessments(asset.getId(), asset.conditionInformation);
    }

    public Asset saveAssetConditionAssessments(String id, ConditionInformation conditionInformation) {
        return microservice.saveAssetConditionAssessments(id, conditionInformation);
    }

    public Asset saveAssetCost(String id, AcquisitionInformation acquisitionInformation) {
        return microservice.saveAssetCost(id, acquisitionInformation);
    }

    public Asset saveAssetNote(String assetId, Note note) {
        return microservice.saveAssetNote(assetId, note);
    }

    public Asset saveAssetMaintenanceContractInformation(String assetId, MaintenanceContractInformation maintenanceContractInformation) {
        return microservice.saveAssetMaintenanceContractInformation(assetId, maintenanceContractInformation);
    }

    public Asset saveAssetWarranty(String id, AcquisitionInformation acquisitionInformation) {
        Asset asset = microservice.getAssetById(id);
        if (asset.conditionInformation.installDate != null) {
            LocalDate installDate = DateUtil.localDateFromDate(asset.conditionInformation.installDate);
            if (acquisitionInformation.warranty.warrantyBeginDate != null) {
                LocalDate warrantyBeginDate = DateUtil.localDateFromDate(acquisitionInformation.warranty.warrantyBeginDate);
                if (installDate.isAfter(warrantyBeginDate)) {
                    throw new ApplicationException("Warranty Start Date must start on or after the Install/Major Upgrade Date");
                }
            }
        } else if (asset.conditionInformation.installDate == null && acquisitionInformation.warranty.warrantyBeginDate != null) {
            throw new ApplicationException("Warranty start date cannot be entered until an Install/Major Upgrade date is entered");
        }
        return microservice.saveAssetWarranty(id, acquisitionInformation);
    }

    public AcquisitionInformation updateWarrantyEndDates(AcquisitionInformation acquisitionInformation) {
        return microservice.updateWarrantyEndDates(acquisitionInformation);
    }

    public Attachment saveAttachment(String id, Attachment attachmentToSave) {
        if (attachmentToSave == null ||
                attachmentToSave.fileRef == null ||
                (StringUtil.isBlankOrNull(attachmentToSave.fileRef.id) && StringUtil.isBlankOrNull(attachmentToSave.fileRef.fileId))) {
            throw new ApplicationException(INVALID_ATTACHMENT_MSG);
        }

        String theFileId = ((!StringUtil.isBlankOrNull(attachmentToSave.fileRef.id) ? attachmentToSave.fileRef.id : attachmentToSave.fileRef.fileId));

        FileRef theFileRef;
        if (!StringUtil.isBlankOrNull(attachmentToSave.fileRef.filePath)) {
            theFileRef = attachmentToSave.fileRef;
        } else {
            theFileRef = fileManagerAdminService.getFileRefById(theFileId);
            if (theFileRef == null) {
                throw new ApplicationException(INVALID_ATTACHMENT_MSG);
            }
        }

        makeFileIdsConsistent(theFileRef, theFileId);
        attachmentToSave.fileRef = theFileRef;
        return microservice.saveAttachment(id, attachmentToSave);
    }

    private void makeFileIdsConsistent(FileRef fileRef, String fileId) {
        fileRef.id = fileId;
        fileRef.fileId = fileId;
    }

    public Asset saveEquipmentIdentifier(@NotNull String id, String identifier) {
        if (StringUtil.isEmptyOrNull(identifier)) {
            throw new ApplicationException("Identifier is required");
        }

        Asset asset = getAssetById(id);
        asset.identifier = identifier;
        validateUniqueIndex(asset);

        // Save to asset > asset
        return microservice.saveEquipmentIdentifier(id, identifier);
    }

    public Asset saveEquipmentTags(@NotNull String id, List<TagRef> tagRefList) {
        // Verify and save new tags in dmlesSystem > tags
        tagRefList = tagService.verifyAndAddTags(tagRefList, EBusinessArea.EQUIP_MNG);
        return microservice.saveEquipmentTags(id, tagRefList);
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }

    public FileManager uploadFileWithCustomValues(byte[] fileContent,
                                                  String uploadedFileName,
                                                  String uploadedByUserId,
                                                  Date uploadedDateTime) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManagedWithCustomValues(
                    fileContent,
                    uploadedFileName,
                    uploadedByUserId,
                    uploadedDateTime);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }

    public List<TagRef> getAssetTags() {
        return tagService.getTagRefsForBusinessArea(EBusinessArea.EQUIP_MNG);
    }

    public List<String> getRiskFactors() {
        return ERiskFactor.getDisplayTextList();
    }

    public List<RiskLevelEntry> getRiskLevels() {
        return microservice.getRiskLevels();
    }

    public List<String> getQaQcInspectionMethods() {
        return EQaQcInspectionMethod.getDisplayTextList();
    }

    public List<SpecificationUnit> getSpecificationUnits() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        List<String> ancestors = new ArrayList<>();
        if (!StringUtil.isEmptyOrNull(currentUser.profile.currentNodeRef.ancestry)) {
            ancestors = Arrays.asList(currentUser.profile.currentNodeRef.ancestry.substring(1).split(","));
        }
        return microservice.getSpecificationUnits(ancestors);
    }

    public List<CapacityUnit> getCapacityUnits() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        List<String> ancestors = new ArrayList<>();
        if (!StringUtil.isEmptyOrNull(currentUser.profile.currentNodeRef.ancestry)) {
            ancestors = Arrays.asList(currentUser.profile.currentNodeRef.ancestry.substring(1).split(","));
        }
        return microservice.getCapacityUnits(ancestors);
    }

    public List<String> getEnvironmentalHazards() {
        return EEnvironmentalHazard.getDisplayTextList();
    }

    public List<ConditionEntry> getConditions() {
        return microservice.getConditions();
    }

    public List<AssessmentOrganizationRef> getAssessmentOrganizationRefs() {
        return microservice.getAssessmentOrganizationRefs();
    }

    public List<Installation> getUsersInstallations() {
        return installationService.getAllInstallations(true);
    }

    public List<Facility> getFacilitiesForNodeIdentifier() {
        return facilityService.getAllFacilities();
    }

    public List<Facility> getFacilitiesForSiteId() {
        String siteId = getSiteId();
        return facilityService.findBySiteId(siteId);
    }

    public List<FacilitySummary> getActiveFacilitiesBySiteUid(String rpsuid) {
        return facilityService.getActiveFacilitiesBySiteUid(rpsuid, true);
    }

    public List<BusinessContactRef> getRPEManufacturerNames() {
        return microservice.getRPEManufacturerNames();
    }

    public List<BusinessContactRef> getAllRPEBusinessContacts() {
        return microservice.getAllRPEBusinessContacts();
    }

    public Integer getMaxAttachmentSize() {
        return microservice.getMaxAttachmentSize();
    }

    public Integer getMaxUploadSize() {
        if (null == maxUploadSize) {
            maxUploadSize = fileManagerAdminService.getMaxPostSize();
        }
        return maxUploadSize;
    }

    public List<Space> getRoomsByFacilityId(String facilityId) {
        return spaceManagementService.getRoomsByFacilityId(facilityId);
    }

    public List<Section> getSectionsByEquipmentIds(List<String> equipmentIds) {
        return sectionService.getSectionsByAssetIds(equipmentIds);
    }

    public List<SectionRef> getSectionsRefsByIds(List<SectionRef> sectionRefList) {
        List<Section> sectionList;
        ArrayList<SectionRef> sectionRefs = new ArrayList<>();
        sectionList = sectionService.getSectionsByIds(sectionRefList);

        sectionList.forEach(section -> sectionRefs.add(section.getRef()));
        return sectionRefs;
    }

    public List<SectionSummary> getSectionNames(List<String> facilityIds) {
        return sectionService.getSectionSummariesByFacilityIds(facilityIds, "ALL");
    }

    public List<SectionRef> getSectionRefsByFacilityIds(List<String> facilityIds) {
        List<SectionRef> sectionRefList = new ArrayList<>();
        List<Section> sectionList = sectionService.getSectionsByFacilityIds(facilityIds);
        sectionList.forEach(section -> sectionRefList.add(section.getRef()));

        return sectionRefList;
    }

    public Asset removeReferenceDocument(String assetId, ReferenceDocument referenceDocument) {
        return microservice.removeReferenceDocument(assetId, referenceDocument);
    }

    public Asset removeStandard(String assetId, Standards standards) {
        return microservice.removeStandard(assetId, standards);
    }

    public Asset removeSubComponents(String assetId, List<String> subComponentIdList) {
        return microservice.removeSubComponents(assetId, subComponentIdList);
    }

    public Asset saveAdditionalInformation(String id, AdditionalInformation additionalInformation) {
        return microservice.saveAdditionalInformation(id, additionalInformation);
    }

    public Asset saveAssemblyInformation(String id, AssemblyInformation assemblyInformation) {
        Asset asset = getAssetById(id);
        AssetRef assetRef = asset.getRef();
        String newSectionId = assemblyInformation.sectionRef.id;
        String oldSectionId = asset.sectionRef.id;

        if (newSectionId == null && asset.sectionRef.id != null) {
            sectionService.removeAssetRefFromSection(oldSectionId, assetRef);
        } else if (newSectionId != null && asset.sectionRef.id == null) {
            sectionService.addAssetRefToSection(newSectionId, assetRef);
        } else if (!Objects.equals(newSectionId, asset.sectionRef.id)) {
            sectionService.removeAssetRefFromSection(oldSectionId, assetRef);
            sectionService.addAssetRefToSection(newSectionId, assetRef);
        }

        return microservice.saveAssemblyInformation(id, assemblyInformation);
    }

    public Asset saveAuditInformation(String id, AuditInformation auditInformation) {
        return microservice.saveAuditInformation(id, auditInformation);
    }

    public List<CustomField> getAllCustomFields(@NotNull @QueryParam("customizableTypeId") String customizableTypeId) {
        return microservice.getAllCustomFields(customizableTypeId);
    }

    public List<CustomFieldValue> getAllCustomFieldValues(String id) {
        return microservice.getAllCustomFieldValues(id);
    }

    public CustomField addCustomField(@QueryParam("maxCustomFieldRecords") Integer maxCustomFieldRecords,
                                      @NotNull CustomField customField) {
        return microservice.addCustomField(maxCustomFieldRecords, customField);
    }

    public CustomField updateCustomField(@NotNull CustomField customField) {
        return microservice.updateCustomField(customField);
    }

    public void deleteCustomField(@NotNull CustomField customField) {
        microservice.deleteCustomField(customField);
    }

    public boolean checkIfCustomFieldValuesExist(@NotNull @QueryParam("customFieldId") String customFieldId) {
        return microservice.checkIfCustomFieldValuesExist(customFieldId);
    }

    public boolean checkDuplicateLabel(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                       @QueryParam("label") String label) {
        return microservice.checkDuplicateLabel(customizableTypeId, label);
    }

    public List<CustomFieldValue> saveCustomFieldValues(String id, List<CustomFieldValue> customFieldValues) {
        return microservice.saveCustomFieldValues(id, customFieldValues);
    }

    public Asset saveCapacityInformation(String id, Features features) {
        Set<String> uniqueUnits = new HashSet<>();
        for (Capacity capacity : features.capacity) {
            if (uniqueUnits.contains(capacity.capacityUnit)) {
                throw new ApplicationException("Cannot select duplicate Unit of Measures");
            } else {
                uniqueUnits.add(capacity.capacityUnit);
            }
        }
        return microservice.saveCapacityInformation(id, features);
    }

    public Asset saveHazardsInformation(String id, String[] hazards) {
        List<String> hazardsSelected = EEnvironmentalHazard.getHazardsConstantNames(hazards);
        return microservice.saveHazardsInformation(id, hazardsSelected);
    }

    public Asset saveLocationInformation(String id, LocationInformation locationInformation) {
        Asset asset = getAssetById(id);
        asset.locationInformation = locationInformation;
        validateUniqueIndex(asset);

        // Remove asset from asset group if location is now different
        if (asset.assetGroupRef != null && asset.assetGroupRef.id != null && !"".equals(asset.assetGroupRef.id.trim())) {
            AssetGroup assetGroup = assetGroupService.getAssetGroupById(asset.assetGroupRef.getId());
            if (!assetGroup.facilityRef.getId().equals(asset.locationInformation.facilityRef.getId())
                    || !assetGroup.installationSiteRef.getId().equals(asset.locationInformation.installationSiteRef.getId())
                    || !assetGroup.installationRef.getId().equals(asset.locationInformation.installationRef.getId())) {
                removeAssetFromAssetGroup(asset.getId(), assetGroup.getId());
            }
        }

        return microservice.saveLocationInformation(id, locationInformation);
    }

    public Asset saveSpecificationsInformation(String id, Features features) {
        Set<String> uniqueUnits = new HashSet<>();
        for (Specification specification : features.specifications) {
            if (uniqueUnits.contains(specification.specificationUnit)) {
                throw new ApplicationException("Cannot select duplicate Unit of Measures");
            } else {
                uniqueUnits.add(specification.specificationUnit);
            }
        }
        return microservice.saveSpecificationsInformation(id, features);
    }

    public Asset saveReferenceDocument(String assetId, ReferenceDocument referenceDocument) {
        return microservice.saveReferenceDocument(assetId, referenceDocument);
    }

    public Asset saveStandard(String assetId, Standards standards) {
        standardsValidator.validate(standards);
        return microservice.saveStandard(assetId, standards);
    }

    public Asset removeAssetFromAssetGroup(String assetId, String assetGroupId) {
        Asset asset = microservice.removeAssetFromAssetGroup(assetId, assetGroupId);
        assetScheduleService.addRemoveAssetGroupRelationship(assetId,
                assetGroupId,
                AssetScheduleService.EAssetScheduleUpdateOption.REMOVE);
        return asset;
    }

    public AssetGroup addAssetsToAssetGroup(String assetGroupId, List<String> assetIdList) {
        AssetGroup group = microservice.addAssetsToAssetGroup(assetGroupId, assetIdList);
        assetScheduleService.addRemoveAssetGroupRelationship(assetGroupId,
                assetIdList,
                AssetScheduleService.EAssetScheduleUpdateOption.ADD);

        return group;
    }

    public AssetGroup removeAssetsFromAssetGroup(String assetGroupId, List<String> assetIdList) {
        AssetGroup group = microservice.removeAssetsFromAssetGroup(assetGroupId, assetIdList);
        assetScheduleService.addRemoveAssetGroupRelationship(assetGroupId,
                assetIdList,
                AssetScheduleService.EAssetScheduleUpdateOption.REMOVE);

        return group;
    }

    public void updateSectionRefInAssets(List<String> assetIdList, SectionRef sectionRef) {
        microservice.updateSectionRefInAssets(assetIdList, sectionRef);
    }

    public void updateAssetRefInAssets(AssetRef assetRef) {
        microservice.updateAssetRefInAssets(assetRef);
    }

    public void deleteAssetGroupRefFromAssets(AssetGroupRef assetGroupRef) {
        List<Asset> assets = microservice.getAssetsByAssetGroupId(assetGroupRef.id);
        List<AssetRef> refs = assets.stream().map(Asset::getRef).collect(Collectors.toList());
        microservice.deleteAssetGroupRefFromAssets(assetGroupRef);
        assetScheduleService.addRemoveAssetGroupRelationship(refs,
                assetGroupRef.id,
                AssetScheduleService.EAssetScheduleUpdateOption.REMOVE);
    }

    public void updateAssetGroupRefInAssets(AssetGroupRef assetGroupRef) {
        List<Asset> assets = microservice.getAssetsByAssetGroupId(assetGroupRef.id);
        List<AssetRef> refs = assets.stream().map(Asset::getRef).collect(Collectors.toList());
        microservice.updateAssetGroupRefInAssets(assetGroupRef);
        assetScheduleService.addRemoveAssetGroupRelationship(refs,
                assetGroupRef.id,
                AssetScheduleService.EAssetScheduleUpdateOption.ADD);
    }

    public void updateAssemblyCategoryRefsInAssets(AssemblyCategoryRef assemblyCategoryRef) {
        microservice.updateAssemblyCategoryRefsInAssets(assemblyCategoryRef);
    }

    public void updateNomenclatureRefsInAssets(NomenclatureRef nomenclatureRef) {
        microservice.updateNomenclatureRefsInAssets(nomenclatureRef);
    }

    public void updateManufacturerRefsInAssets(ManufacturerRef manufacturerRef) {
        microservice.updateManufacturerRefsInAssets(manufacturerRef);
    }

    public void updateFacilityRefsInAssets(FacilityRef facilityRef) {
        microservice.updateFacilityRefsInAssets(facilityRef);
    }

    public void updateInstallationRefsInAssets(InstallationRef installationRef) {
        microservice.updateInstallationRefsInAssets(installationRef);
    }

    public void updateInstallationSiteRefsInAssets(SiteRef installationSiteRef) {
        microservice.updateInstallationSiteRefsInAssets(installationSiteRef);
    }

    public void updateOrganizationRefsInAssets(OrganizationRef organizationRef) {
        microservice.updateOrganizationRefsInAssets(organizationRef);
    }

    public void updateSpaceRefsInAssets(SpaceRef spaceRef) {
        microservice.updateSpaceRefsInAssets(spaceRef);
    }

    public void updateTagRefInAssets(TagRef tagRef) {
        microservice.updateTagRefInAssets(tagRef);
    }

    public void updateCustomFieldRefInAssets(CustomFieldRef customFieldRef) {
        microservice.updateCustomFieldRefInAssets(customFieldRef);
    }

    public void deleteVendorRefsInAssets(VendorRef vendorRef) {
        microservice.deleteVendorRefsInAssets(vendorRef);
    }

    public void updateVendorRefsInAssets(VendorRef vendorRef) {
        microservice.updateVendorRefsInAssets(vendorRef);
    }

    public void deleteZoneRefsInAssets(ZoneRef zoneRef) {
        microservice.deleteZoneRefsInAssets(zoneRef);
    }

    public void updateZoneRefsInAssets(ZoneRef zoneRef) {
        microservice.updateZoneRefsInAssets(zoneRef);
    }

    public void removeCustomFieldRefFromAssets(CustomFieldRef customFieldRef) {
        microservice.removeCustomFieldRefFromAssets(customFieldRef);
    }

    private String getSiteId() {
        String siteId = null;
        Organization organization = organizationService.getOrganization(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if (organization.nodeTypeRef.name.equals(OrganizationType.RP_INSTALLATION_SITE_TYPE_NAME)) {
            siteId = organization.getId();
        }

        return siteId;
    }

    private OrganizationRef getManagedByNodeRef(String facilityId) {
        Facility facility = facilityService.getFacilityById(facilityId);
        Organization node = organizationService.getOrganization(facility.managedByNodeRef.id);
        return node.getRef();
    }

    public Asset saveProductCapacity(String id, Capacity capacity) {
        return microservice.saveProductCapacity(id, capacity);
    }

    public Asset saveMEProductInformation(String id, AssetProductInformation assetProductInformation) {
        return microservice.saveMEProductInformation(id, assetProductInformation);
    }

    public Asset saveRoomsSupported(String id, List<SpaceRef> roomsToSave) {
        return microservice.saveRoomsSupported(id, roomsToSave);
    }

    public Asset saveRPEProductInformation(String id, RealPropertyAsset realPropertyAsset) {
        return microservice.saveRPEProductInformation(id, realPropertyAsset);
    }

    public Asset saveProductSpecifications(String id, List<Specification> productSpecifications) {
        return microservice.saveProductSpecifications(id, productSpecifications);
    }

    public Asset saveZonesSupported(String id, List<ZoneRef> zonesToSave) {
        return microservice.saveZonesSupported(id, zonesToSave);
    }

    public Asset setAssetActive(String assetId) {
        assetScheduleService.onActiveChange(assetId, AssetScheduleService.EAssetScheduleUpdateOption.ADD);
        return microservice.setAssetActive(assetId);
    }

    public Asset setAssetInactive(String assetId) {
        Asset asset = getAssetById(assetId);
        long activeWorkOrders = workOrderService.getActiveWorkOrderCountByAssetId(assetId);
        if (activeWorkOrders > 0) {
            throw new ApplicationException(String.format("This record has %d work order(s) which have a status of not Closed. " +
                    "This record may not be Set to Inactive until all associated work order(s) are Set to Closed.", activeWorkOrders));
        }
        long activeRequirements = requirementService.getActiveRequirementCountByAsset(assetId);
        if (activeRequirements > 0) {
            throw new ApplicationException(String.format("This record has %d requirement(s) which have a status of not Closed. " +
                    "This record may not be Set to Inactive until all associated requirement(s) are Set to Closed.", activeRequirements));
        }
        long activeProjects = projectService.getActiveProjectCountByAssetId(assetId);
        if (activeProjects > 0) {
            throw new ApplicationException(String.format("This record has %d projects(s) which have a status of not Closed. " +
                    "This record may not be Set to Inactive until all associated projects(s) are Set to Closed.", activeProjects));
        }
        if (asset.assetGroupRef != null && asset.assetGroupRef.id != null) {
            throw new ApplicationException(VALIDATE_BULK_UPDATE_RPE_BELONGS_TO_GROUP);
        }

        // Delete all schedules
        List<Schedule> schedules = assetScheduleService.getSchedulesByAssetId(assetId);
        for (Schedule schedule : schedules) {
            assetScheduleService.deleteSchedule(schedule.getId());
        }

        assetScheduleService.onActiveChange(assetId, AssetScheduleService.EAssetScheduleUpdateOption.REMOVE);

        return microservice.setAssetInactive(assetId);
    }

    public Integer getAssetAge(String id) {
        Asset asset = getAssetById(id);
        Integer age = 0;
        if (asset.conditionInformation != null && asset.conditionInformation.installDate != null) {
            age = Math.max(0,
                    dateUtil.getYearsBetween(asset.conditionInformation.installDate, new Date()));
        }
        return age;
    }

    public Integer getAssetLifeRemaining(String id) {
        Asset asset = getAssetById(id);
        Integer age = getAssetAge(id);
        int lifeRemaining = 0;
        if (asset.conditionInformation != null && asset.conditionInformation.lifeExpectancyInYears != null) {
            lifeRemaining = Math.max(0,
                    asset.conditionInformation.lifeExpectancyInYears - age);
        }
        return lifeRemaining;
    }

    public List<Zone> getZonesByFacilityId(String id) {
        return spaceManagementService.getZonesByFacilityId(id);
    }

    public List<String> getRelatedCauses() {
        return ERelatedCause.getDisplayTextList();
    }

    public List<WorkOrderHistory> getWorkOrderHistoryByAssetId(String assetId,
                                                               Boolean includeScheduled,
                                                               Boolean includeUnscheduled) {
        return workOrderService.getWorkOrderHistoryByAssetId(assetId, includeScheduled, includeUnscheduled);
    }

    public Requirement createRequirementFromAsset(String assetId) {
        Requirement requirement = requirementService.createRequirementFromAsset(assetId);
        Asset asset = getAssetById(assetId);

        Assessment assessment = copyLatestAssessment(asset);
        if (assessment == null) {
            assessment = new Assessment();
        }
        assessment.createdDate = new Date();
        assessment.createdBy = userService.getUserProfile().getFullName();
        assessment.conditionDeterminationDate = new Date();
        assessment.conditionRecommendations = "Created Requirement # " + requirement.requirementNumber == null ? "" : requirement.requirementNumber ;
        asset.conditionInformation.assessments.add(assessment);
        saveAssetConditionAssessments(asset.getId(), asset.conditionInformation);
        return requirement;
    }

    private Assessment copyLatestAssessment(Asset asset) {
        Assessment latestAssessment = null;
        if (asset.conditionInformation != null && !ListUtil.isEmpty(asset.conditionInformation.assessments)) {
            for (Assessment assessment : asset.conditionInformation.assessments) {
                if (latestAssessment == null
                        || (latestAssessment.conditionDeterminationDate.before(assessment.conditionDeterminationDate))) {
                    latestAssessment = new Assessment();
                    latestAssessment.lifeUsed = assessment.lifeUsed;
                    latestAssessment.condition = assessment.condition;
                    latestAssessment.assessingOrganization = assessment.assessingOrganization;
                    latestAssessment.pointOfContact = assessment.pointOfContact;
                    latestAssessment.conditionDeterminationDate = assessment.conditionDeterminationDate;
                    latestAssessment.conditionRecommendations = assessment.conditionRecommendations;
                    latestAssessment.conditionObservations = assessment.conditionObservations;
                    latestAssessment.relatedCause = assessment.relatedCause;
                    latestAssessment.isAssessmentRequired = assessment.isAssessmentRequired;
                    latestAssessment.installDate = assessment.installDate;
                    latestAssessment.lifeExpectancyInYears = assessment.lifeExpectancyInYears;
                }
            }
        }
        return latestAssessment;
    }

    public long getActiveRequirementCountByAsset(String assetId) {
        return requirementService.getActiveRequirementCountByAsset(assetId);
    }

    public WorkOrder createDeficiencyWorkOrder(String assetId) {
        Asset asset = this.microservice.getAssetById(assetId);
        WorkOrder workOrder = this.workOrderService.createDeficiencyWorkOrder(asset);

        Assessment assessment = copyLatestAssessment(asset);
        if (assessment == null) {
            assessment = new Assessment();
        }
        assessment.createdDate = new Date();
        assessment.createdBy = userService.getUserProfile().getFullName();
        assessment.conditionDeterminationDate = new Date();
        assessment.conditionRecommendations = "Created Work Order # " + workOrder.workOrderNumber;
        asset.conditionInformation.assessments.add(assessment);
        saveAssetConditionAssessments(asset.getId(), asset.conditionInformation);
        return workOrder;
    }

    public List<BusinessContactRef> getBusinessContactRefs(String isActive) {
        List<BusinessContact> businessContacts = businessContactService.getBusinessContacts(isActive);
        List<BusinessContactRef> businessContactRefs = new ArrayList<>();

        for (BusinessContact businessContact : businessContacts) {
            businessContactRefs.add(businessContact.getRef());
        }
        return businessContactRefs;
    }

    public List<BusinessContact> getBusinessContacts(String isActive) {
        return businessContactService.getBusinessContacts(isActive);
    }

    public AssetBusinessContact getAssetContactByBusinessContactId(String businessContactId) {
        BusinessContact businessContact = businessContactService.getBusinessContactById(businessContactId);
        AssetBusinessContact assetBusinessContact = new AssetBusinessContact();

        if (businessContact != null) {
            assetBusinessContact.businessContactRef = businessContact.getRef();
            assetBusinessContact.address = businessContact.address;
            assetBusinessContact.contacts = businessContact.contacts;
        }

        return assetBusinessContact;
    }

    public AssetBusinessContact getAssetContactByContactId(String contactId) {
        List<BusinessContact> businessContacts = businessContactService.getBusinessContactsByContactIds(Arrays.asList(contactId));
        AssetBusinessContact assetBusinessContact = null;

        if (!businessContacts.isEmpty()) {
            BusinessContact businessContact = businessContacts.get(0);
            assetBusinessContact = new AssetBusinessContact();
            assetBusinessContact.businessContactRef = businessContact.getRef();
            assetBusinessContact.address = businessContact.address;
            for (Contact contact : businessContact.contacts) {
                if (contactId.equals(contact.contactId)) {
                    assetBusinessContact.contacts.add(contact);
                }
            }
        }

        return assetBusinessContact;
    }

    public List<Asset> getAssetsByAssetIds(List<String> ids) {
        return microservice.getAssetsByAssetIds(ids);
    }

    public List<AssetSummary> getAssetSummariesByFacilityId(String facilityId, boolean excludeAssetsInGroup, EActiveStatus activeStatus) {
        if (excludeAssetsInGroup) {
            return microservice.getRpeAssetSummariesByFacilityIdWithNoAssetGroup(facilityId);
        } else {
            return microservice.getRpeAssetsByFacilityId(facilityId, activeStatus);
        }
    }

    public List<AssetSummary> getAssetSummariesByFacilityIdAndNomenclatureId(String facilityId, String nomenclatureId) {
        return microservice.getAssetsByFacilityIdAndNomenclatureId(facilityId, nomenclatureId);
    }

    public List<AssetGroup> getAssetGroupsByFacilityId(String facilityId) {
        return assetGroupService.getAssetGroupsByFacilityId(facilityId);
    }

    public List<AssetGroup> getAssetGroupsByFacilityIdAndNomenclatureId(String facilityId, String nomenclatureId) {
        return assetGroupService.getAssetGroupsByFacilityIdAndNomenclatureId(facilityId, nomenclatureId);
    }

    public List<AssetSummary> getAssetSummariesByAssetGroupId(String assetGroupId) {
        return microservice.getAssetSummariesByAssetGroupId(assetGroupId);
    }

    public long getAssetCountInSpace(String spaceId, String spaceIdentifier) {
        return microservice.getAssetCountInSpace(spaceId, spaceIdentifier);
    }

    public void validateUniqueIndex(Asset asset) {
        if (microservice.getAssetCountByUniqueIndex(asset) > 0) {
            throw new ApplicationException("Equipment with the identifier " + asset.identifier + " in facility " + asset.locationInformation.facilityRef.facilityNumber + " - " + asset.locationInformation.facilityRef.name + " already exists.");
        }
    }

    public AssetCostSummary getAssetCostSummaryByAssetId(String assetId) {
        AssetCostSummary assetCostSummary = new AssetCostSummary();
        String currentFiscalYear = String.valueOf(DateUtil.getCurrentFiscalYear());

        List<WorkOrder> workOrders = workOrderService.getWorkOrdersByAssetIds(Collections.singletonList(assetId));

        if (!ListUtil.isEmpty(workOrders)) {
            for (WorkOrder workOrder : workOrders) {
                String workOrderFiscalYear = String.valueOf(workOrder.fundingFiscalYear);
                if(!ListUtil.isEmpty(workOrder.assignments)) {
                    for (Assignment assignment : workOrder.assignments) {
                        if (!ListUtil.isEmpty(assignment.actualCosts)) {
                            for (ActualCost actualCost : assignment.actualCosts) {
                                getAssetCostSummaryData(assetCostSummary, actualCost, workOrder, assetId, currentFiscalYear, workOrderFiscalYear);
                            }
                        }
                    }
                }
            }
        }

        return assetCostSummary;
    }

    private void getAssetCostSummaryData(AssetCostSummary assetCostSummary, ActualCost actualCost, WorkOrder workOrder, String assetId, String currentFiscalYear, String workOrderFiscalYear) {
        if (actualCost.assetRef != null && assetId.equals(actualCost.assetRef.getId())) {
            if (CLASSIFICATION_TYPE_NAME_RECURRING_WORK.equalsIgnoreCase(workOrder.classificationTypeRef.name)) {
                if (currentFiscalYear.equals(workOrderFiscalYear)) {
                    if ( actualCost.costSummary != null ) {
                        assetCostSummary.currentYearMaintenanceCost = assetCostSummary.currentYearMaintenanceCost.add(actualCost.costSummary.total);
                    }
                    assetCostSummary.currentYearMaintenanceHours = Float.sum(assetCostSummary.currentYearMaintenanceHours, actualCost.laborHours);
                }
                if ( actualCost.costSummary != null ) {
                    assetCostSummary.allYearsMaintenanceCost = assetCostSummary.allYearsMaintenanceCost.add(actualCost.costSummary.total);
                }
                assetCostSummary.allYearsMaintenanceHours = Float.sum(assetCostSummary.allYearsMaintenanceHours, actualCost.laborHours);
            } else {
                if (currentFiscalYear.equals(workOrderFiscalYear)) {
                    if ( actualCost.costSummary != null ) {
                        assetCostSummary.currentYearRepairCost = assetCostSummary.currentYearRepairCost.add(actualCost.costSummary.total);
                    }
                    assetCostSummary.currentYearRepairHours = Float.sum(assetCostSummary.currentYearRepairHours, actualCost.laborHours);
                }
                if ( actualCost.costSummary != null ) {
                    assetCostSummary.allYearsRepairCost = assetCostSummary.allYearsRepairCost.add(actualCost.costSummary.total);
                }
                assetCostSummary.allYearsRepairHours = Float.sum(assetCostSummary.allYearsRepairHours, actualCost.laborHours);
            }
        }
    }

    public long getActiveScheduleCountByAssetId(String assetId) {
        return assetScheduleService.getActiveScheduleCountByAssetId(assetId);
    }

    public AssetCOBieExportData getCOBieExportData(String facilityId) {
        return microservice.getCOBieExportData(facilityId);
    }

    public Asset getAssetByIdentifier(String facilityId, String assetIdentifier) {
        return microservice.getAssetByIdentifier(facilityId, assetIdentifier);
    }

    public long setAssetsActiveByFacilityIds(List<String> facilityIds) {
        return microservice.setAssetsActiveByFacilityIds(facilityIds);
    }

    public long getAssetStatusCountByFacilityId(String facilityId, Boolean isActive) {
        return microservice.getAssetStatusCountByFacilityId(facilityId, isActive);
    }

    public List<ManufacturerRef> getManufacturerRefListByManufacturerNameList(List<String> manufacturerNameList) {
        return microservice.getManufacturerRefListByManufacturerNameList(manufacturerNameList);
    }

    public List<AssetRef> getParentManagedChildAssets(List<String> assetIds, String facilityId) {
        return microservice.getParentManagedChildAssets(assetIds, facilityId);
    }

    public void syncFacilityManagedByNodeRef(String facilityId, OrganizationRef managedBy) {
        microservice.syncFacilityManagedByNodeRef(facilityId, managedBy);
    }

    public List<RoomSummary> getRoomSummariesByFacilityIds(List<String> facilityIds) {
        return spaceManagementService.getRoomSummariesByFacilityIds(facilityIds);
    }

    public List<Zone> getZonesByIds(List<String> zoneIds) {
        return spaceManagementService.getZonesByIds(zoneIds);
    }

    public List<RoomSummary> getRoomSummariesByIds(List<String> roomIdList) {
        return spaceManagementService.getRoomSummariesByIds(roomIdList);
    }

    public List<Zone> getZonesByFacilityIds(List<String> facilityIds) {
        return spaceManagementService.getZonesByFacilityIds(facilityIds);
    }

    public List<FloorPlanLegendEntry> getDrawingLegend(String floorId, String legendType) {
        return drawingService.getDrawingLegend(floorId, legendType);
    }

    public List<FloorPlanLayer> getFloorPlanLayers() {
        return drawingService.getFloorPlanLayers();
    }

    public List<GraphicalSearchRecord> getGraphicalSearchRecordsByRoomIds(List<String> roomIds) {
        return drawingService.getGraphicalSearchRecordsByRoomIds(roomIds);
    }

    public Floor getFloorById(String id) {
        return drawingService.getFloorById(id);
    }

    public Floor getFloorBySpaceId(String spaceId) {
        return spaceManagementService.getFloorBySpaceId(spaceId);
    }

    public RoomMetadata getRoomMetadataByRoomNumber(String facilityId, String identifier) {
        return drawingService.getRoomMetadataByRoomNumber(facilityId, identifier);
    }

    public RoomRelatedRecordCounts getRelatedRecordCountsByRoomNumber(String facilityId, String identifier) {
        return drawingService.getRelatedRecordCountsByRoomNumber(facilityId, identifier);
    }

    public List<ProjectSummary> getProjectsByAssetId(String assetId) {
        return projectService.getProjectsByAssetId(assetId);
    }

    public List<String> getDocumentTypes() {
        return facilityService.getDocumentTypes();
    }

    public List<AssetRef> getMedicalAssetRefsByNomenclatureId(String nomenclatureId) {
        return microservice.getMedicalAssetRefsByNomenclatureId(nomenclatureId);
    }

    public List<AssetRef> getMedicalAssetRefsByItemId(String itemId) {
        return microservice.getMedicalAssetRefsByItemId(itemId);
    }

    public SearchResult<Asset> getMedicalEquipmentAssets(SearchInput searchInput) {
        return microservice.getMedicalEquipmentAssets(searchInput);
    }
}
