package logicole.gateway.services.product;

import logicole.apis.product.IProductMicroserviceApi;
import logicole.common.datamodels.abi.ABiCatalogRecordRef;
import logicole.common.datamodels.abi.staging.ABiCatalogRecordUpdate;
import logicole.common.datamodels.abi.staging.AbiCatalogRecord;
import logicole.common.datamodels.abi.staging.CommodityClass;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.product.*;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.AbiCatalogService;
import logicole.gateway.services.abi.AbiStagingLookupService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.system.SystemService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@ApplicationScoped
public class ProductService extends BaseGatewayService<IProductMicroserviceApi> {
    @Inject
    AbiCatalogService abiCatalogService;

    @Inject
    AbiStagingLookupService abiStagingLookupService;

    @Inject
    OfferService offerService;

    @Inject
    OrganizationService organizationService;

    @Inject
    SystemService systemService;

    public ProductService() {
        super("Product");
    }

    public List<CommodityClass> getCommodityClassList(@QueryParam("militaryServiceCode") String militaryServiceCode) {
        return abiStagingLookupService.getCommodityClassList(militaryServiceCode);
    }

    public List<CommodityClass> getCommodityClassListForCustomer(@QueryParam("customerId") String customerId) {
        List<CommodityClass> recordList = new ArrayList<>();
        List<Organization> organizations = organizationService.findOrganizationsByIdentifier(customerId);
        HashSet<String> milServiceIds = new HashSet<>();  // get a unique list
        if (organizations != null && organizations.size() > 0) {
            for (Organization organization : organizations) {
                if (!milServiceIds.contains(organization.milServiceId)) {
                    milServiceIds.add(convertMilitaryServiceCode(organization.milServiceId));
                }
            }
            if (!milServiceIds.isEmpty()) {
                for (String milServiceId : milServiceIds) {
                    List<CommodityClass> list = abiStagingLookupService.getCommodityClassList(milServiceId);
                    recordList.addAll(list);
                }
            }
        }
        return recordList;
    }

    public List<SiteCatalogRecord> getCustomerCatalog(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId) {
        return microservice.getCustomerCatalog(siteId, customerId);
    }

    public List<SiteCatalogRecord> getCustomerCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId, @QueryParam("commType") String commType) {
        return microservice.getCustomerCatalogByCommType(siteId, customerId, commType);
    }

    public String getEnterpriseProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier) {
        return microservice.getEnterpriseProductIdentifier(enterpriseItemIdentifier);
    }

    public List<SiteCatalogRecord> getEquipmentByPartialMatch(@QueryParam("siteId") String siteId, @QueryParam("searchString") String searchString) {
        return microservice.getEquipmentByPartialMatch(siteId, searchString);
    }

    public List<SiteCatalogRecord> getEquipmentByItemId(@QueryParam("siteId") String siteId, @QueryParam("partialItemId") String partialItemId) {
        return microservice.getEquipmentByItemId(siteId, partialItemId);
    }

    public List<ItemId> getEquipmentItemIdList(@QueryParam("siteId") String siteId, @QueryParam("partialItemId") String partialItemId) {
        return microservice.getEquipmentItemIdList(siteId, partialItemId);
    }

    public List<ProductSeqIdInfo> getMedicalSupplyProductSeqIdInfo() {
        return microservice.getMedicalSupplyProductSeqIdInfo();
    }

    public MmcSearchResult getMmcItems(String customerId,
                                       String manufacturerName,
                                       String manufacturerCatalogNumber,
                                       String itemNumber,
                                       String ndc,
                                       String itemDescription,
                                       String pvon,
                                       Integer ecatItemId,
                                       String genericSequenceNum,
                                       String slProductCd) {
        return microservice.getMmcItems(customerId, manufacturerName, manufacturerCatalogNumber, itemNumber, ndc, itemDescription, pvon, ecatItemId, genericSequenceNum, slProductCd);
    }

    public MmcItem getMmcItem(String customerId, Integer productSeqId) {
        return microservice.getMmcItem(customerId, productSeqId);
    }

    // Get a distinct list of the NDCs contained in the Site SlepCatalog.")
    public List<String> getNdcList() {
        return microservice.getNdcList();
    }

    public List<Integer> getProductSeqIdList() {
        return microservice.getProductSeqIdList();
    }

    public List<SiteCatalogRecord> getSiteCatalog(@QueryParam("siteId") String siteId) {
        return microservice.getSiteCatalog(siteId);
    }

    public List<SiteCatalogRecord> getSiteCatalogByBarcode(@QueryParam("siteId") String siteId, @QueryParam("barcodes") String barcode) {
        return microservice.getSiteCatalogByBarcode(siteId, barcode);
    }

    public List<SiteCatalogRecord> getSiteCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("commType") String commType) {
        return microservice.getSiteCatalogByCommType(siteId, commType);
    }

    public List<SiteCatalogRecord> getSiteCatalogByEnterpriseId(@QueryParam("siteId") String siteId, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return microservice.getSiteCatalogByEnterpriseId(siteId, enterpriseProductIdentifier);
    }

    public List<SiteCatalogRecord> getSiteCatalogByProductId(@QueryParam("siteId") String siteId, @QueryParam("productSeqId") Integer productSeqId) {
        return microservice.getSiteCatalogByProductId(siteId, productSeqId);
    }

    public SiteCatalogRecord getSiteCatalogItem(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId) {
        return microservice.getSiteCatalogItem(siteId, itemId);
    }

    public SiteCatalogRecord getSiteCatalogRecord(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier) {
        return microservice.getSiteCatalogRecord(enterpriseItemIdentifier);
    }

    public Integer getSiteCount(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return microservice.getSiteCount(enterpriseProductIdentifier);
    }

    public List<SiteCatalogRecord> getSupplierCatalog(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm) {
        return microservice.getSupplierCatalog(siteId, supplierNm);
    }

    public List<SiteCatalogRecord> getSupplierCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm, @QueryParam("commType") String commType) {
        return microservice.getSupplierCatalogByCommType(siteId, supplierNm, commType);
    }

    public List<SiteCatalogRecord> searchEquipment(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId, @QueryParam("shortItemDesc") String shortItemDesc, @QueryParam("longItemDesc") String longItemDesc, @QueryParam("manufacturerNm") String manufacturerNm, @QueryParam("manufCatNum") String manufCatNum, @QueryParam("deviceText") String deviceText) {
        return microservice.searchEquipment(siteId, itemId, shortItemDesc, longItemDesc, manufacturerNm, manufCatNum, deviceText);
    }

    public List<SiteCatalogRecord> textSearch(@QueryParam("siteId") String siteId, @QueryParam("searchString") String searchString) {
        return microservice.textSearch(siteId, searchString);
    }

    public List<SiteCatalogRecord> textSearchCommType(@QueryParam("siteId") String siteId, @QueryParam("commType") String commType, @QueryParam("searchString") String searchString) {
        return microservice.textSearchCommType(siteId, commType, searchString);
    }

    public Integer updateEnterpriseProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return microservice.updateEnterpriseProductIdentifier(enterpriseItemIdentifier, enterpriseProductIdentifier);
    }

    public Integer updateMmcProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier, @QueryParam("mmcProductIdentifier") Integer mmcProductIdentifier) {
        return microservice.updateMmcProductIdentifier(enterpriseItemIdentifier, mmcProductIdentifier);
    }

    public Integer updateProductSeqId(@QueryParam("oldProductSeqId") Integer oldProductSeqId, @QueryParam("newProductSeqId") Integer newProductSeqId) {
        return microservice.updateProductSeqId(oldProductSeqId, newProductSeqId);
    }

    // Updates the EnterpriseProductIdentifier and the ProductSeqId in the Site SlepCatalog from the ABi Values.")
    public Integer updateSiteCatalogRecordFromABi(@QueryParam("oldEnterpriseProductIdentifier") String oldEnterpriseProductIdentifier,
                                                  @QueryParam("newEnterpriseProductIdentifier") String newEnterpriseProductIdentifier) {
        return microservice.updateSiteCatalogRecordFromABi(oldEnterpriseProductIdentifier, newEnterpriseProductIdentifier);
    }

    public Integer updateEnterpriseProductIdentifierByMfrPartNumberMmcid(String enterpriseProductIdentifier, String manufacturer, String manufacturerCatalogNumber, Integer mmcProductIdentifier) {
        return microservice.updateEnterpriseProductIdentifierByMfrPartNumberMmcid(enterpriseProductIdentifier, manufacturer, manufacturerCatalogNumber, mmcProductIdentifier);
    }

    public List<String> getDistinctManufacturerNames() {
        return microservice.getDistinctManufacturerNames();
    }

    public List<String> getDistinctUnlinkedManufacturerNames() {
        return microservice.getDistinctUnlinkedManufacturerNames();
    }

    public List<SiteCatalogRecord> getRecordsWithoutEnterpriseProductIdentifier(@QueryParam("manufacturerNm") String manufacturerNm,
                                                                                @QueryParam("mmcExists") Boolean mmcExists) throws ApplicationException {
        return microservice.getRecordsWithoutEnterpriseProductIdentifier(manufacturerNm, mmcExists);
    }

    public List<SiteCatalogRecord> getByNDC(@QueryParam("ndc") String ndc) {
        return microservice.getByNDC(ndc);
    }

    public List<SiteCatalogRecord> getByManufacturerNameAndCatalogNumber(@QueryParam("manufacturerNm") String manufacturerNm,
                                                                         @QueryParam("manufCatNum") String manufCatNum) {
        return microservice.getByManufacturerNameAndCatalogNumber(manufacturerNm, manufCatNum);
    }

    public List<SiteCatalogRecord> getByManufacturerCatalogNumber(@QueryParam("manufCatNum") String manufCatNum) {
        return microservice.getByManufacturerCatalogNumber(manufCatNum);
    }

    public List<SiteCatalogRecord> getByEnterpriseProductIdentifier(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return microservice.getByEnterpriseProductIdentifier(enterpriseProductIdentifier);
    }

    public List<SiteCatalogRecord> getByProductSeqId(@QueryParam("productSeqId") Integer productSeqId) {
        return microservice.getByProductSeqId(productSeqId);
    }

    public List<SiteCatalogRecord> getByProductSeqIdList(List<Integer> productSeqIdList) {
        return microservice.getByProductSeqIdList(productSeqIdList);
    }

    public List<SiteCatalogRecord> getByEnterpriseItemIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier) {
        return microservice.getByEnterpriseItemIdentifier(enterpriseItemIdentifier);
    }

    public List<String> getDistinctEnterpriseProductIdentifiersByIds(List<String> idList) {
        return microservice.getDistinctEnterpriseProductIdentifiersByIds(idList);
    }

    public Integer updateEnterpriseProductIdentifiersByIds(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier,
                                                           List<String> idList) {
        Integer retVal = 0;
        if (!StringUtil.isEmptyOrNull(enterpriseProductIdentifier)) {
            // Get from AbiStagingRecord if the record does not exists from AbiCatalog
            AbiCatalogRecord abiCatalogRecord = abiCatalogService.getAbiCatalogOrStagingRecordByEnterpriseProductIdentifier(enterpriseProductIdentifier);
            SiteCatalogUpdate siteCatalogUpdate = new SiteCatalogUpdate();
            siteCatalogUpdate.idList = idList;
            siteCatalogUpdate.abiCatalogRecord = abiCatalogRecord;
            retVal = microservice.updateEnterpriseProductIdentifiersByIds(enterpriseProductIdentifier, siteCatalogUpdate);
        }

        return retVal;
    }

    public SiteCatalogRecord getById(@QueryParam("id") String id) {
        return microservice.getById(id);
    }

    public AbiToProductUpdate removeEnterpriseProductIdentifiersByIds(List<String> idList) {
        return microservice.removeEnterpriseProductIdentifiersByIds(idList);
    }

    public SiteCatalogRecord findByMeNaturalKey(String siteDoDDAC, String itemId, int packQty, String sosTypeCode) {
        return microservice.findByMeNaturalKey(siteDoDDAC, itemId, packQty, sosTypeCode);
    }

    public void updateProductFromAbi(ABiCatalogRecordUpdate recordToUpdate) {
        microservice.updateProductFromAbi(recordToUpdate);
    }

    public void syncProductFromAbi(ABiCatalogRecordUpdate aBiCatalogRecordUpdate) {
        logger.info("ProductService: SyncProductFromAbi  " + aBiCatalogRecordUpdate.syncProduct);

        if (aBiCatalogRecordUpdate.syncProduct) {
            logger.info("ProductService: SyncProductFromAbi  " + aBiCatalogRecordUpdate.abiCatalogRecord.enterpriseProductIdentifier);
            updateProductFromAbi(aBiCatalogRecordUpdate);
            offerService.updateOfferProductData(aBiCatalogRecordUpdate);
        }
    }

    public void updateProduct(Offer offer) {
        microservice.updateProduct(offer.product);
    }

    public SiteCatalogRecord getTewlsRecord(@QueryParam("tlammCatalogSeqId") Integer tlammCatalogSeqId) {
        return microservice.getTewlsRecord(tlammCatalogSeqId);
    }

    public void updateSiteCatalog(SiteCatalogRecord siteCatalogRecord) {
        microservice.updateSiteCatalog(siteCatalogRecord);
    }

    public List<SiteCatalogRecordRef> getSiteCatalogRecordRefsforAbiCatalogRecords(List<ABiCatalogRecordRef> abiCatalogRecordRefs) {
        return microservice.getSiteCatalogRecordRefsforAbiCatalogRecords(abiCatalogRecordRefs);
    }

    public Integer updateEnterpriseProductId(String oldEnterpriseProductIdentifier, String newEnterpriseProductIdentifier) {
        return microservice.updateEnterpriseProductId(oldEnterpriseProductIdentifier, newEnterpriseProductIdentifier);
    }

    public Integer updateEpiFromMmcId(Integer mmcProductIdentifier, String oldEnterpriseProductIdentifier, String newEnterpriseProductIdentifier) {
        return microservice.updateEpiFromMmcId(mmcProductIdentifier, oldEnterpriseProductIdentifier, newEnterpriseProductIdentifier);
    }

    private String convertMilitaryServiceCode(String inCode) {
        // convert codes that might have come over from the legacy system to the standard ones. DA and DN are already correct, so don't need to convert them.
        String convertedCode = inCode;
        if (inCode.equalsIgnoreCase("AF")) {
            convertedCode = "DF";
        } else if (inCode.equalsIgnoreCase("MC")) {
            convertedCode = "DM";
        }
        return convertedCode;
    }

    public DmlssSupplier getDmlssSupplier(String siteDoddac, String sosCd){
        return microservice.getDmlssSupplier(siteDoddac,sosCd);
    }
}
