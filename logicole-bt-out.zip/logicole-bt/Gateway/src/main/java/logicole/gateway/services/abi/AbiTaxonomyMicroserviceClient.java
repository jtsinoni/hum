package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiTaxonomyMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiTaxonomyMicroserviceClient extends MicroserviceClient<IAbiTaxonomyMicroserviceApi> {
    public AbiTaxonomyMicroserviceClient() {
        super(IAbiTaxonomyMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiTaxonomyMicroserviceApi getABiTaxonomyService() {
        return createClient();
    }
}

