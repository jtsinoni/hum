package logicole.gateway.services.asset;

import io.swagger.annotations.Api;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Api(tags = {"AssetDataLoad"})
@ApplicationScoped
@Path("/assetClassification")
public class AssetDataLoadRestApi extends ExternalRestApi<AssetDataLoadService> {

    @GET
    @Path("/getCurrentUser")
    @Produces(MediaType.TEXT_PLAIN)
    public String getCurrentUser() {
        return service.getUserName();
    }

}
