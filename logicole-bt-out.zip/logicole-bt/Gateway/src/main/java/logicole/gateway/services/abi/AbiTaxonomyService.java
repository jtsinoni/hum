package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiTaxonomyMicroserviceApi;
import logicole.common.datamodels.abi.taxonomy.*;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@ApplicationScoped
public class AbiTaxonomyService extends BaseGatewayService<IAbiTaxonomyMicroserviceApi> {

    public AbiTaxonomyService() {
        super("AbiTaxonomy");
    }


    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public List<UnspscSegment> getSegments() {
        return microservice.getSegments();
    }

    public List<UnspscFamily> getFamilies(@QueryParam("segmentId") String segmentId) {
        return microservice.getFamilies(segmentId);
    }

    public List<UnspscClass> getClasses(@QueryParam("familyId") String familyId) {
        return microservice.getClasses(familyId);
    }

    public List<UnspscCommodity> getCommodities(@QueryParam("classId") String classId) {
        return microservice.getCommodities(classId);
    }

    public UnspscSegmentHierarchy getSegmentHierarchy(@QueryParam("segmentId") String segmentId) {
        return microservice.getSegmentHierarchy(segmentId);
    }

    public UnspscLevelDetails getTaxonomyLevelDetails(@QueryParam("level") String level,
                                                      @QueryParam("levelId") String levelId) {
        return microservice.getTaxonomyLevelDetails(level, levelId);
    }

    public UnspscLevelDetails getTaxonomyLevelDetailsByUnspscCode(@QueryParam("unspscCode") Integer unspscCode) {
        return microservice.getTaxonomyLevelDetailsByUnspscCode(unspscCode);
    }

    public List<UnspscRecord> search(@QueryParam("code") String code, @QueryParam("title") String title) {
        return microservice.search(code, title);
    }

    public List<UnspscRecord> getSegmentRecords() {
        return microservice.getSegmentRecords();
    }

    public List<UnspscRecord> getFamilyRecords(@QueryParam("segmentId") String segmentId) {
        return microservice.getFamilyRecords(segmentId);
    }

    public List<UnspscRecord> getClassRecords(@QueryParam("familyId") String familyId) {
        return microservice.getClassRecords(familyId);
    }

    public List<UnspscRecord> getCommodityRecords(@QueryParam("classId") String classId) {
        return microservice.getCommodityRecords(classId);
    }

    public List<String> getDistinctProductNouns() {
        return microservice.getDistinctProductNouns();
    }

    public List<Integer> getUnspscCodesForProductNoun(@QueryParam("productNoun") String productNoun) {
        return microservice.getUnspscCodesForProductNoun(productNoun);
    }

    public List<UnspscRecord> getUnspscRecordsByUnspscCodeList(@QueryParam("unspscCodeList") List<Integer> unspscCodeList) {
        return microservice.getUnspscRecordsByUnspscCodeList(unspscCodeList);
    }
}
