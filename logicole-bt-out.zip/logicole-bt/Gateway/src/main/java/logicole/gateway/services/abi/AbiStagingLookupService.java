package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiStagingLookupMicroserviceApi;
import logicole.common.datamodels.abi.CriticalItemCategoryRef;
import logicole.common.datamodels.abi.PackageUnit;
import logicole.common.datamodels.abi.staging.CommodityClass;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.QueryParam;
import java.util.List;

@ApplicationScoped
public class AbiStagingLookupService extends BaseGatewayService<IAbiStagingLookupMicroserviceApi> {

    public AbiStagingLookupService() {
        super("AbiStaging");
    }

    public List<String> getEnterpriseProductIdentifierTypeList() {
        return microservice.getEnterpriseProductIdentifierTypeList();
    }

    public List<PackageUnit> getPackageUnitList() {
        return microservice.getPackageUnitList();
    }

    public List<String> getProductStatusList() {
        return microservice.getProductStatusList();
    }

    public List<String> getDisposableReusableList() {
        return microservice.getDisposableReusableList();
    }

    public List<String> getSterileNonSterileList() {
        return microservice.getSterileNonSterileList();
    }

    public List<String> getHazardCodeList() {
        return microservice.getHazardCodeList();
    }

    public List<String> getLatexCodeList() {
        return microservice.getLatexCodeList();
    }

    public List<String> getGenderList() {
        return microservice.getGenderList();
    }

    public List<String> getBrandGenericList() {
        return microservice.getBrandGenericList();
    }

    public List<String> getDeaCodeList() {
        return microservice.getDeaCodeList();
    }

    public List<String> getDosageFormList() {
        return microservice.getDosageFormList();
    }

    public List<String> getDrugCategoryCodeList() {
        return microservice.getDrugCategoryCodeList();
    }

    public List<String> getDocumentTypeList() {
        return microservice.getDocumentTypeList();
    }

    public List<String> getCommodityTypeList() {
        return microservice.getCommodityTypeList();
    }

    // Return a list of Commodity Classes for the given Military Service Code.")
    public List<CommodityClass> getCommodityClassList(@QueryParam("militaryServiceCode") String militaryServiceCode) {
        return microservice.getCommodityClassList(militaryServiceCode);
    }
    public List<String> getGudidIdentifierTypeList() {
        return microservice.getGudidIdentifierTypeList();
    }

    public List<String> getNetContentTextList() {
        return microservice.getNetContentTextList();
    }

    public List<String> getManufacturerTypeaheadList() {
        return microservice.getManufacturerTypeaheadList();
    }

    public List<String> getProductNounList() {
        return microservice.getProductNounList();
    }

    public List<String> getProductTypeList() {
        return microservice.getProductTypeList();
    }

    public List<CriticalItemCategoryRef> getCriticalItemCategoryList() {
        return microservice.getCriticalItemCategoryList();
    }
}
