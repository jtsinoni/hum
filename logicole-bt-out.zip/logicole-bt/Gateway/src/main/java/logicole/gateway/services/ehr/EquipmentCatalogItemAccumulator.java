package logicole.gateway.services.ehr;

import logicole.common.datamodels.ehr.equipment.EquipmentCatalogItem;
import logicole.common.datamodels.ehr.equipment.EquipmentItemSiteInfo;

import java.util.*;
import javax.enterprise.context.RequestScoped;

@RequestScoped
public class EquipmentCatalogItemAccumulator {

    private final Map<String, EquipmentCatalogItem> map = new HashMap<>();

    public void accumulate(List<EquipmentCatalogItem> items) {

        for (EquipmentCatalogItem item: items) {
            if (map.containsKey(item.itemID)) {
                EquipmentCatalogItem currentItem = map.get(item.itemID);
                EquipmentItemSiteInfo EquipmentItemSiteInfo = item.siteInfoList.get(0);
                boolean matchAny = currentItem.siteInfoList.contains(EquipmentItemSiteInfo);
                if (!matchAny) {
                    currentItem.siteInfoList.add(EquipmentItemSiteInfo);
                }
            } else {
                map.put(item.itemID, item);
            }
        }
    }

    public Collection<EquipmentCatalogItem> getItems() {
        return map.values();
    }
}
