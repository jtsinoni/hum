package logicole.gateway.services.organization;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.TreeNode;
import logicole.common.datamodels.general.tree.TreeChange;
import logicole.common.datamodels.general.tree.TreeChangeRequest;
import logicole.common.datamodels.general.tree.TreeVersion;
import logicole.common.datamodels.organization.AncestryQuery;
import logicole.common.datamodels.organization.ArchiveOrganization;
import logicole.common.datamodels.organization.BusinessServiceDefinitionRef;
import logicole.common.datamodels.organization.Consumer;
import logicole.common.datamodels.organization.DmlssHost;
import logicole.common.datamodels.organization.MarketInfo;
import logicole.common.datamodels.organization.NodeImportStatus;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationType;
import logicole.common.datamodels.organization.OrganizationTypeRef;
import logicole.common.datamodels.organization.ProviderRef;
import logicole.common.datamodels.organization.ScopeQuery;
import logicole.common.datamodels.organization.ServiceProvider;
import logicole.common.datamodels.organization.ServiceProviderRef;
import logicole.common.datamodels.organization.StandardStructureCode;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.RoleRef;
import logicole.gateway.rest.ExternalRestApi;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@Api(tags = {"Organization"})
@ApplicationScoped
@Path("/organization")
public class OrganizationRestApi extends ExternalRestApi<OrganizationService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/findLogisticsDescendants")
    public List<Organization> findLogisticsDescendants(@QueryParam("orgId") String orgId) {
        return service.findLogisticsDescendants(orgId);
    }

    @GET
    @Path("/getArchiveOrganizations")
    public List<ArchiveOrganization> getArchiveOrganizations() {
        return service.getArchiveOrganizations();
    }

    @GET
    @Path("/getScopedOrganizationIdList")
    public List<String> getScopedOrganizationIdList(@QueryParam("startingOrgId") String startingOrgId) {
        return service.getScopedOrganizationIdList(startingOrgId);
    }

    @POST
    @Path("/getScopeUsingAncestry")
    public List<Organization> getScopeUsingAncestry(AncestryQuery ancestryQuery) {
        return service.getScopeUsingAncestry(ancestryQuery);
    }

    @POST
    @Path("/getOrganizationRefsByIdList")
    public List<OrganizationRef> getOrganizationRefsByIdList(List<String> organizationIds) {
        return service.getOrganizationRefsByIdList(organizationIds);
    }

    @GET
    @Path("/getServiceProvidersAsRef")
    public List<ServiceProviderRef> getServiceProvidersAsRef() { return service.getServiceProvidersAsRef(); }

    @GET
    @Path("/getServiceProviders")
    public List<ServiceProvider> getServiceProviders() {
        return service.getServiceProviders();
    }

    @GET
    @Path("/getServiceProviderById")
    public ServiceProvider getServiceProviderById(@QueryParam("id") String id) {
        return service.getServiceProviderById(id);
    }

    @GET
    @Path("/getAllRolesAsRoleRef")
    public List<RoleRef> getAllRolesAsRoleRef() { return service.getAllRolesAsRoleRef(); }

    @GET
    @Path("/checkDuplicateServiceProvider")
    public Boolean checkDuplicateServiceProvider(@QueryParam("name") String name, @QueryParam("id") String id) {
        return service.checkDuplicateServiceProvider(name, id);
    }

    @POST
    @Path("/saveProviderConsumer")
    public ServiceProvider saveProviderConsumer(ServiceProvider provider) {
        return service.saveProviderConsumer(provider);
    }

    @POST
    @Path("/saveServiceProviderRoles")
    public ServiceProvider saveServiceProviderRoles(ServiceProvider provider) {
        return service.saveServiceProviderRoles(provider);
    }

    @GET
    @Path("/getStandardStructureCodeNode")
    public StandardStructureCode getStandardStructureCodeNode(@QueryParam("type") String type, @QueryParam("code") String code) {
        return service.getStandardStructureCodeNode(type, code);
    }

    @GET
    @Path("/getStandardStructureTypes")
    public List<String> getStandardStructureTypes() {
        return service.getStandardStructureTypes();
    }

    @GET
    @Path("/getOrganizationChildren")
    public List<Organization> getOrganizationChildren(@QueryParam("parentId") String parentId) {
        return service.getOrganizationChildren(parentId);
    }

    @GET
    @Path("/getOrganizationTreeChildren")
    public List<TreeNode<Organization>> getOrganizationTreeChildren(@QueryParam("parentId") String parentId) {
        return service.getOrganizationTreeChildren(parentId);
    }


    @GET
    @Path("/getParentOrganization")
    public Organization getParentOrganization(@QueryParam("organizationId") String organizationId) {
        return service.getParentOrganization(organizationId);
    }

    @GET
    @Path("/getOrganization")
    public Organization getOrganization(@QueryParam("organizationId") String organizationId) {
        return service.getOrganization(organizationId);
    }

    @POST
    @Path("/getOrganizationRoleIds")
    public List<String> getOrganizationRoleIds(List<String> organizationIds) {
        return service.getOrganizationRoleIds(organizationIds);
    }

    @GET
    @Path("/getOrganizationTypes")
    public List<OrganizationType> getOrganizationTypes() {
        return service.getOrganizationTypes();
    }

    @GET
    @Path("/getAllNonRootOrganizationTypes")
    public List<OrganizationType> getAllNonRootOrganizationTypes() {
        return service.getAllNonRootOrganizationTypes();
    }

    @GET
    @Path("/getOrganizationTypeById")
    public OrganizationType getOrganizationTypeById(@QueryParam("organizationTypeId") String organizationTypeId) {
        return service.getOrganizationTypeById(organizationTypeId);
    }

    @GET
    @Path("/getOrganizationTypeRef")
    public OrganizationTypeRef getOrganizationTypeRef(@QueryParam("organizationId") String organizationId) {
        return service.getOrganizationTypeRef(organizationId);
    }

    @POST
    @Path("/getOrganizationsInScope")
    public List<Organization> getOrganizationsInScope(ScopeQuery scopeNode) {
        return service.getOrganizationsInScope(scopeNode);
    }

    @POST
    @Path("/getOrganizationsInScopeByOrganizationTypeName")
    public List<Organization> getOrganizationsInScopeByOrganizationTypeName(ScopeQuery scopeNode) {
        return service.getOrganizationsInScopeByOrganizationTypeName(scopeNode);
    }

    @GET
    @Path("/getOrganizationOrgIdsForParent")
    public List<String> getOrganizationOrgIdsForParent(@QueryParam("startingOrganizationId") String startingOrganizationId) {
        return service.getOrganizationOrgIdsForParent(startingOrganizationId);
    }

    @GET
    @Path("/reSyncOrganizationAncestry")
    public void reSyncOrganizationAncestry() {
        service.reSyncOrganizationAncestry();
    }

    @GET
    @Path("/reSyncOrganizationChildren")
    public void reSyncOrganizationChildren() {
        service.reSyncOrganizationAncestry();
    }

    @GET
    @Path("/getOrganizationAncestryTreeById")
    public TreeNode<Organization> getOrganizationAncestryTreeById(@QueryParam("organizationId") String organizationId,
                                                                  @QueryParam("includeSiblings") boolean includeSiblings) {
        return service.getOrganizationAncestryTreeById(organizationId, includeSiblings);
    }

    @GET
    @Path("/getOrganizationTreeById")
    public TreeNode<Organization> getOrganizationTreeById(@QueryParam("organizationId") String organizationId) {
        return service.getOrganizationTreeById(organizationId);
    }

    @GET
    @Path("/getDescendantOrganizationRefs")
    public List<OrganizationRef> getDescendantOrganizationRefs(@QueryParam("organizationId") String organizationId) {
        return service.getDescendantOrganizationRefs(organizationId);
    }

    @GET
    @Path("/getOrganizationRefById")
    public OrganizationRef getOrganizationRefById(@QueryParam("organizationId") String organizationId) {
        return service.getOrganizationRefById(organizationId);
    }

    @GET
    @Path("/getProvider")
    public ProviderRef getProvider(@QueryParam("startOrgId") String startOrgId, @QueryParam("providerType") String providerType) {
        return service.getProvider(startOrgId, providerType);
    }

    @POST
    @Path("/saveOrgServiceProviders")
    public Organization saveOrgServiceProviders(Organization organization) {
        return service.saveOrgServiceProviders(organization);
    }

    @POST
    @Path("/saveOrganization")
    public Organization saveOrganization(Organization organization) {
        return service.saveOrganization(organization);
    }

    @GET
    @Path("/deleteOrganization")
    public void deleteOrganization(@QueryParam("organizationId") String organizationId) {
        service.deleteOrganization(organizationId);
    }

    @Produces(MediaType.TEXT_PLAIN)
    @GET
    @Path("/refreshOrganizationTree")
    public Boolean refreshOrganizationTree() {
        return service.refreshOrganizationTree();
    }

    @GET
    @Path("/findOrganizationsByIdentifier")
    public List<Organization> findOrganizationsByIdentifier(@QueryParam("searchString") String searchString) {
        return service.findOrganizationsByIdentifier(searchString);
    }

    @GET
    @Path("/getOrganizationTypesReduced")
    public List<OrganizationType> getOrganizationTypesReduced() {
        return service.getOrganizationTypesReduced();
    }

    @GET
    @Path("/getDmlssHostList")
    public List<DmlssHost> getDmlssHostList() {
        return service.getDmlssHostList();
    }

    @POST
    @Path("/createOrganization")
    public Organization createOrganization(@QueryParam("parentId") String parentId, Organization organization) {
        return service.createOrganization("Called from UI", parentId, organization);
    }

    @GET
    @Path("/getAllowedChildOrgTypes")
    public List<OrganizationType> getAllowedChildOrgTypes(@QueryParam("organizationId") String organizationId) {
        return service.getAllowedChildOrgTypes(organizationId);
    }

    @GET
    @Path("/getAncestorOrgOfOrgType")
    public Organization getAncestorOrgOfOrgType(@QueryParam("organizationId") String organizationId, @QueryParam("targetOrgTypeId") String targetOrgTypeId) {
        return service.getAncestorOrgOfOrgType(organizationId, targetOrgTypeId);
    }

    @GET
    @Path("/getOrganizationIdsAtAndBelow")
    public List<String> getOrganizationIdsAtAndBelow(@NotNull @QueryParam("organizationId") String organizationId) {
        return service.getOrganizationIdsAtAndBelow(organizationId);
    }

    @GET
    @Path("/getOrganizationIdsBelow")
    public List<String> getOrganizationIdsBelow(@NotNull @QueryParam("organizationId") String organizationId) {
        return service.getOrganizationIdsBelow(organizationId);
    }

    @GET
    @Path("/isDoDOrganization")
    public boolean isDoDOrganization(@NotNull @QueryParam("organizationId") String organizationId) {
        return service.isDoDOrganization(organizationId);
    }

    @GET
    @Path("/getOrganizationTypesBelow")
    public List<OrganizationType> getOrganizationTypesBelow(@QueryParam("organizationId") String organizationId, @QueryParam("realPropertyTypes") boolean realPropertyTypes) {
        return service.getOrganizationTypesBelow(organizationId, realPropertyTypes);
    }

    @GET
    @Path("/getDmlssHosts")
    public List<DmlssHost> getDmlssHosts() {
        return service.getDmlssHosts();
    }

    @GET
    @Path("/getDmlssHostById")
    public DmlssHost getDmlssHostById(@QueryParam("id") String id) {
        return service.getDmlssHostById(id);
    }

    @GET
    @Path("/getOrgLabelsNotInDmlssHost")
    public List<String> getOrgLabelsNotInDmlssHost() {
        return service.getOrgLabelsNotInDmlssHost();
    }

    @GET
    @Path("/deleteDmlssHost")
    public boolean deleteDmlssHost(@QueryParam("id") String id) {
        service.deleteDmlssHost(id);
        return true;
    }

    @POST
    @Path("/updateDmlssHostLastSyncTime")
    public void updateDmlssHostLastSyncTime(String dodaac, Date siteCatalogLastSyncTime) {
        service.updateDmlssHostLastSyncTime(dodaac, siteCatalogLastSyncTime);
    }

    @POST
    @Path("/saveDmlssHost")
    public DmlssHost saveDmlssHost(DmlssHost dmlssHost) {
        return service.saveDmlssHost(dmlssHost);
    }
    

    @GET
    @Path("/getOrgLabelsRPDisabledInDmlssHost")
    public List<String> getOrgLabelsRPDisabledInDmlssHost() {
        return service.getOrgLabelsRPDisabledInDmlssHost();
    }

    @GET
    @Path("/removeBusinessServiceDefinition")
    public Organization removeBusinessServiceDefinition(@QueryParam("organizationId") String organizationId,
                                                        @QueryParam("businessServiceId")String businessServiceId) {
        return service.removeBusinessServiceDefinition(organizationId, businessServiceId);
    }

    @POST
    @Path("/addBusinessServiceDefinition")
    public Organization addBusinessServiceDefinition(@QueryParam("organizationId") String organizationId,
                                              BusinessServiceDefinitionRef businessService) {
        return service.addBusinessServiceDefinition(organizationId, businessService);
    }

    @POST
    @Path("/addUpdateBusinessServiceDefinitions")
    public Organization addUpdateBusinessServiceDefinitions(@QueryParam("organizationId") String organizationId, List<BusinessServiceDefinitionRef> businessServices) {
        return service.addUpdateBusinessServiceDefinitions(organizationId, businessServices);
    }

    @GET
    @Path("/getCurrentUserScopedOrganizationRefs")
    public List<OrganizationRef> getCurrentUserScopedOrganizationRefs() {
        return service.getCurrentUserScopedOrganizationRefs();
    }

    @POST
    @Path("/addOrganizationConsumer")
    public Organization addOrganizationConsumer(@QueryParam("organizationId") String organizationId, Consumer consumer) {
        return service.addOrganizationConsumer(organizationId, consumer);
    }

    @POST
    @Path("/addUpdateOrganizationMarketInfo")
    public Organization addUpdateOrganizationMarketInfo(@QueryParam("organizationId") String organizationId,
                                                 MarketInfo marketInfo) {
        return service.addUpdateOrganizationMarketInfo(organizationId, marketInfo);
    }

    @GET
    @Path("/saveOrganizationMiscDetails")
    public Organization saveOrganizationMiscDetails(@QueryParam("id") String id, @QueryParam("newStationId") String newStationId, @QueryParam("newFacilitiesEnterpriseRegion") String newFacilitiesEnterpriseRegion) {
        return service.saveOrganizationMiscDetails(id, newStationId, newFacilitiesEnterpriseRegion);
    }

    @POST
    @Path("/uploadNodeImportFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload Node import file",
            notes = "The return value will be the FileManager object")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a Node import file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadNodeImportFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form)
            throws IOException {
        return service.uploadNodeImportFile(form);
    }

    @POST
    @Path("/importNodeFile")
    public NodeImportStatus importNodeFile(@QueryParam("reason") String reason, @QueryParam("parentType") String parentType, Attachment importFile) {
        return service.importNodeFile(importFile, reason, parentType);
    }

    @POST
    @Path("/moveOrganization")
    public TreeChange moveOrganization(@QueryParam("purpose") String purpose, @QueryParam("orgId") String orgId, @QueryParam("newParentId") String newParentId) {
        return service.moveOrganization(purpose, orgId, newParentId);
    }

    @POST
    @Path("/updateOrganizationTree")
    public TreeVersion updateOrganizationTree(@QueryParam("purpose") String purpose, List<TreeChangeRequest> changeRequestsn) {
        return service.updateOrganizationTree(purpose, changeRequestsn);
    }

}
