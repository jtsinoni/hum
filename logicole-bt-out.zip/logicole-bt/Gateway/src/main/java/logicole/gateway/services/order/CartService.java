package logicole.gateway.services.order;

import logicole.apis.order.ICartMicroserviceApi;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.abi.item.ItemSummary;
import logicole.common.datamodels.assemblage.Assemblage;
import logicole.common.datamodels.catalog.Catalog;
import logicole.common.datamodels.catalog.CatalogDTO;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.finance.referencedata.FundingCategory;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.output.AuthorizedNode;
import logicole.common.datamodels.finance.purchasecard.PurchaseCardRef;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.request.EBusinessEventType;
import logicole.common.datamodels.finance.request.FinanceItem;
import logicole.common.datamodels.finance.request.RequestGroup;
import logicole.common.datamodels.general.Address;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.inventory.ReplenishmentRecord;
import logicole.common.datamodels.order.CatalogPurchase;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.buyer.BuyerRef;
import logicole.common.datamodels.order.cart.*;
import logicole.common.datamodels.order.order.OrderDTO;
import logicole.common.datamodels.order.order.OrderInformationRef;
import logicole.common.datamodels.order.order.OrderItem;
import logicole.common.datamodels.order.order.OrderReviewStatus;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.sale.seller.*;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.CurrentUserBtRef;
import logicole.common.datamodels.user.Role;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.util.ObjectMapper;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.assemblage.AssemblageService;
import logicole.gateway.services.catalog.CatalogLookupService;
import logicole.gateway.services.catalog.CatalogService;
import logicole.gateway.services.delivery.DueOutService;
import logicole.gateway.services.finance.FinanceAdminService;
import logicole.gateway.services.finance.PurchaseCardService;
import logicole.gateway.services.finance.validator.FinanceProcessingValidator;
import logicole.gateway.services.inventory.InventoryService;
import logicole.gateway.services.sale.SellerService;
import logicole.gateway.services.user.RoleService;
import logicole.gateway.services.user.UserService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@ApplicationScoped
public class CartService extends BaseGatewayService<ICartMicroserviceApi> {
    public static final String CUSTOMER_NOT_FOUND_EXCEPTION = "No Customer is associated to this profile";
    private static final String CONTRACTING = "contracting";                            // needs to be changed
    private static final String DLA_ELECTRONIC_CATALOG = "DLA electronic catalog";      // needs to be changed
    private static final String DOD_PRIME_VENDOR = "DPV";
    @Inject
    protected BuyerService buyerService;
    @Inject
    protected FinanceAdminService financeAdminService;
    @Inject
    protected FinanceProcessingValidator financeProcessingValidator;
    @Inject
    protected InventoryService inventoryService;
    @Inject
    private ItemService itemService;
    @Inject
    protected SellerService sellerService;
    @Inject
    protected CatalogService catalogService;
    @Inject
    private DueOutService dueOutService;
    @Inject
    private PurchaseCardService purchaseCardService;
    @Inject
    private ObjectMapper mapper;
    @Inject
    private CatalogLookupService catalogLookupService;
    @Inject
    private AssemblageService assemblageService;
    @Inject
    private UserService userService;
    @Inject
    private RoleService roleService;

    public CartService() {
        super("Cart");
    }

    private Buyer getBuyer() {
        return buyerService.getBuyerForNodeId(getCurrentUser().profile.currentNodeRef.getId());
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public CartDTO addCatalogData(CartDTO cartDTO) {
        for (CartSellerItemsDTO cartSellerItemsDTO : cartDTO.sellerGroups) {
            List<String> sellerTypes = cartSellerItemsDTO.items.stream().map(cartItem -> cartItem.catalogPurchase.catalog.sellerRef.sellerType).distinct().collect(Collectors.toList());
            cartSellerItemsDTO.sellerTypeOrderConfiguration = sellerService.getSellerTypeOrderConfiguration(sellerTypes.get(0));
            cartSellerItemsDTO.isNonReimbursable = sellerService.getSellerById(cartSellerItemsDTO.sellerId).isNonReimbursable;
            for (CartItem cartItem : cartSellerItemsDTO.items) {
                if (cartItem.catalogPurchase != null) {
                    if (cartItem.catalogPurchase.catalog.getId() != null) {
                        cartItem.catalogPurchase.catalog = catalogService.getById(cartItem.catalogPurchase.catalog.getId());
                    }
                    if (cartItem.catalogPurchase.catalog != null && !cartItem.catalogPurchase.catalog.itemRef.getId().equals("")) {
                        if (cartItem.catalogPurchase.catalog.itemRef.getId() != null) {
                            Item foundItem = itemService.getItemById(cartItem.catalogPurchase.catalog.itemRef.getId());
                            if (!Objects.isNull(foundItem)) {
                                cartItem.catalogPurchase.item = foundItem;
                            } else {
                                logger.info("No Enterprise Item Record for" + cartItem.catalogPurchase.catalog.itemRef.getId());
                                cartSellerItemsDTO.exceptions.add("No Enterprise Item Record for: " + cartItem.catalogPurchase.catalog.longDescription + ". Remove item from cart.");
                            }
                        }
                    }
                }
            }
        }
        return cartDTO;
    }

    public CartItem addCatalogData(CartItem cartItem) {
        if (!Objects.isNull(cartItem.catalogPurchase.catalog)) {
            if (!Objects.isNull(cartItem.catalogPurchase.catalog.getId())) {
                cartItem.catalogPurchase.catalog = catalogService.getById(cartItem.catalogPurchase.catalog.getId());
            }
            if (!cartItem.catalogPurchase.catalog.itemRef.getId().equals("")) {
                Item foundItem = itemService.getItemById(cartItem.catalogPurchase.catalog.itemRef.getId());
                if (!Objects.isNull(foundItem)) {
                    cartItem.catalogPurchase.item = foundItem;
                } else {
                    logger.info("No Enterprise Item Record for:" + cartItem.catalogPurchase.catalog.itemRef.getId());
                }
            }
        }
        return cartItem;
    }

    public CartItem assignDefaultCodes(CartItem cartItem){
        Buyer buyer = getBuyer();
        cartItem.refundCode = cartItem.isFreeBuyItem ? "N" : null;
        if (buyer.adviceCodeRef != null) {
            cartItem.adviceCodeRef = buyer.adviceCodeRef;
        } else {
            cartItem.adviceCodeRef = getDefaultAdviceCode();
        }
        if (buyer.demandCodeRef != null) {
            cartItem.demandCodeRef = buyer.demandCodeRef;
        } else {
            cartItem.demandCodeRef = getDefaultDemandCode();
        }

        cartItem.signalCodeRef = getDefaultSignalCode();
        cartItem.mediaStatusCodeRef = getDefaultMediaStatusCode();
        cartItem.routingIdentifierCodeRef = getDefaultRoutingIdentifierCode();
        cartItem.priorityCodeRef = getDefaultPriorityCode();
        cartItem.distributionCodeRef = new DistributionCodeRef();
        return cartItem;
    }

    public List<CartSellerItemsDTO> buildCartFunding(List<CartSellerItemsDTO> sellerGroups, Buyer buyer) {
        for (CartSellerItemsDTO sellerGroup : sellerGroups) {
            if (sellerGroup.sellerTypeOrderConfiguration.needCustomerContract) {
                List<String> contractExceptions = buyerService.validateBuyerSellerContract(buyer.getId(), sellerGroup.sellerId);
                if (!Objects.isNull(contractExceptions) && !contractExceptions.isEmpty())
                    sellerGroup.exceptions = contractExceptions;
            }
            //Group the items by fund selected for validation.
            List<CartSellerItemsDTO> sgs = groupByFund(sellerGroup);
            for (CartSellerItemsDTO sg : sgs) {
                List<String> exceptions = validateCartItemFunds(sg, buyer.getId());
                if (sg.exceptions.isEmpty() && exceptions.isEmpty()) {
                    sellerGroup.exceptions.addAll(exceptions);
                    SellerTypeOrderConfiguration sellerTypeOrderConfiguration = sellerService.getSellerTypeOrderConfiguration(sellerGroup.sellerType);
                    if (sellerTypeOrderConfiguration.requirePurchaseCard) {
                        String fundingNodeId = getFundingNodeId(sg);
                        if (Objects.nonNull(fundingNodeId)) {
                            try {
                                List<PurchaseCardRef> purchaseCards = purchaseCardService.getActivePurchaseCardsByFundingNode(fundingNodeId);
                                if (Objects.isNull(purchaseCards) || purchaseCards.isEmpty()) {
                                    FundingNodeRef fundingNodeRef = financeAdminService.getFundingNodeById(fundingNodeId).fundingNodeRef;
                                    sellerGroup.exceptions.add("No purchase cards available for the selected fund: " + fundingNodeRef.name);
                                }
                            } catch (ApplicationException e) {
                                sellerGroup.exceptions.add(e.getMessage());
                            }
                        }
                    }
                } else {
                    sellerGroup.exceptions.addAll(exceptions);
                }
            }
        }
        return sellerGroups;
    }

    public CartDTO buildCartGroups(List<CartItem> cartItems) {
        CartDTO cartDTO = new CartDTO();
        //ToDo: sellerIdentifier below was replaced with sellerName in 3.0.0.  We must replace all seller references with a sellerRef at some point
        //ToDo: for now, assuming sellerName is unique
        List<String> sellerIds = cartItems.stream().map(cartItem -> cartItem.catalogPurchase.catalog.sellerRef.id).distinct().collect(Collectors.toList());
        for (String sellerId : sellerIds) {
            CartSellerItemsDTO sellerItems = new CartSellerItemsDTO();
            Integer sellerStart = 0;
            if (sellerStart == 0) {
                sellerItems.sellerId = sellerId;
                sellerStart++;
            }
            for (CartItem cartItem : cartItems) {
                //ToDo: sellerIdentifier below was replaced with sellerName in 3.0.0.  We must replace all seller references with a sellerRef at some point
                //ToDo: for now, assuming sellerName is unique
                if (cartItem.catalogPurchase.catalog.sellerRef.id.equals(sellerId)) {
                    sellerItems.items.add(cartItem);
                    sellerItems.sellerName = cartItem.catalogPurchase.catalog.sellerRef.sellerName;
                    sellerItems.sellerType = cartItem.catalogPurchase.catalog.sellerRef.sellerType;
                }
            }
            cartDTO.sellerGroups.add(sellerItems);
        }

        return cartDTO;
    }

    public void removeItemsInCart(List<String> cartItemIds) {
        microservice.removeItemsInCart(cartItemIds);
    }

    public CartDTO removeItemFromCart(String cartItemId, String application) {
        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if (Objects.isNull(buyer)) {
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }
        CartDTO cartDTO = microservice.removeItemFromCart(buyer.getId(), cartItemId, application);
        return getCartByBuyerId(application);
    }

    public CartDTO getCartByBuyerId(String application) {
        Buyer buyer = getBuyer();
        if (Objects.isNull(buyer)) {
            return new CartDTO();
        }
        CartDTO cartDTO = microservice.getCartByBuyerId(buyer.getId(), application);

        // get the inventory requested quantity from replenishmentlist
        List<ReplenishmentRecord> replenishmentRecords = inventoryService.getReplenishmentList();

        Integer replenishmentQuantitySum;
        for (int i = 0; i < cartDTO.sellerGroups.size(); i++) {
            CartSellerItemsDTO sellerGroup = cartDTO.sellerGroups.get(i);
            for (CartItem itemInCart : sellerGroup.items) {
                // todo - when locking is ready, make sure the record is not locked
                //  (or not locked by another user, depending on the logic) before updating.  amy 1/7/22
                if (Boolean.TRUE.equals(itemInCart.isReplenishmentItem)) {
                    List<ReplenishmentRecord> matchedCartReplenishmentList = replenishmentRecords.stream().filter(item -> item.catalogRef.catalogItemIdentifier.equals(itemInCart.catalogPurchase.catalog.catalogItemIdentifier)).collect(Collectors.toList());
                    if (matchedCartReplenishmentList.isEmpty()) {
                        if (itemInCart.quantity - itemInCart.quantityRequested > 0) {
                            replenishmentQuantitySum = 0;
                            itemInCart.quantity = itemInCart.quantity - itemInCart.quantityRequested;
                            itemInCart.isReplenishmentItem = false;
                            List<ReplenishmentRecord> removeReplenishmentRecords = itemInCart.replenishmentRecords;
                            itemInCart.replenishmentRecords.removeAll(removeReplenishmentRecords);
                        } else {
                            microservice.removeItemFromCart(buyer.getId(), itemInCart.getId(), application);
                            continue;
                        }
                    } else {
                        replenishmentQuantitySum = matchedCartReplenishmentList.stream().mapToInt(replenishmentItem -> (replenishmentItem).replenishmentLocation.replenishmentQty).sum();
                    }

                    if (!replenishmentQuantitySum.equals(itemInCart.quantityRequested)) {
                        if (itemInCart.quantity.equals(itemInCart.quantityRequested)) {
                            itemInCart.quantity = replenishmentQuantitySum;
                        }
                        itemInCart.quantityRequested = replenishmentQuantitySum;

                        microservice.updateCartItem(itemInCart);
                    }
                }
            }
        }

        addReplenishmentRecordsToCart(replenishmentRecords);

        CartDTO finalCartDTO = microservice.getCartByBuyerId(buyer.getId(), application);

        finalCartDTO.sellerGroups = buildCartFunding(finalCartDTO.sellerGroups, buyer);
        return addCatalogData(finalCartDTO);
    }

    private void addReplenishmentRecordsToCart(List<ReplenishmentRecord> replenishmentRecords) {
        for (ReplenishmentRecord replenishmentRecord : replenishmentRecords) {
            if (!isReplenishmentRecordInCart(replenishmentRecord.replenishmentLocation.itemLocationIdentifier)) {
                // is this catalog-item already represented in the cart but is not-replenishment?
                CartItem cartItem = microservice.getCartItemByBuyerIdAndCatalogId(getBuyer().getId(), replenishmentRecord.catalogRef.getId());
                if (!Objects.isNull(cartItem)) {
                    cartItem.quantity += replenishmentRecord.replenishmentLocation.replenishmentQty;
                    cartItem.quantityRequested = replenishmentRecord.replenishmentLocation.replenishmentQty;
                    cartItem.isReplenishmentItem = true;
                    cartItem.replenishmentRecords.add(replenishmentRecord);

                    microservice.updateCartItem(cartItem);
                } else {
                    cartItem = new CartItem();
                    Catalog catalog = catalogService.getById(replenishmentRecord.catalogRef.getId());
                    if (!Objects.isNull(catalog) && catalog.isActive && !Objects.isNull(catalog.itemRef) && !Objects.isNull(catalog.itemRef.id)) {
                        Item item = itemService.getItemById(catalog.itemRef.getId());
                        if (!Objects.isNull(item)) {
                            cartItem.catalogPurchase = new CatalogPurchase();
                            cartItem.catalogPurchase.catalog = catalog;
                            cartItem.buyerRef = getBuyer().getRef();
                            cartItem.catalogPurchase.item = item;
                            cartItem.cartPrice = catalog.price;
                            cartItem.quantityRequested = replenishmentRecord.replenishmentLocation.replenishmentQty;
                            cartItem.quantity = cartItem.quantityRequested;
                            cartItem.replenishmentRecords.add(replenishmentRecord);
                            cartItem.isReplenishmentItem = true;
                            cartItem.isNonSubmitOrder = false;
                            cartItem.isFreeBuyItem = false;
                            cartItem.addedBy = getCurrentUser().getRef();
                            cartItem = assignDefaultCodes(cartItem);
                            addReplenishmentItemToCart(cartItem);
                        }
                    }
                }
            }
        }
    }

    public CartDTO addCartItemToCart(CartItem cartItem) {
        Buyer buyer = getBuyer();
        if (Objects.isNull(buyer)) {
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }
        CartDTO cartDTO = microservice.addCartItemToCart(buyer.getId(), cartItem);
        return addCatalogData(cartDTO);
    }

    public CartItem updateCartItemFund(String cartItemId, String fundNodeId) {
        CartItem cartItem = microservice.updateCartItemFund(cartItemId, fundNodeId);
        return addCatalogData(cartItem);
    }

    public CartItem updateCartItemIsNonSubmitOrder(String cartItemId, boolean isNonSubmitOrder) {
        return microservice.updateCartItemIsNonSubmitOrder(cartItemId, isNonSubmitOrder);
    }

    public CartItem updateCartItemQuantity(String cartItemId, Integer quantity) {
        CartItem cartItem = microservice.updateCartItemQuantity(cartItemId, quantity);
        return addCatalogData(cartItem);
    }

    public CartItem updateCartItemPrice(String cartItemId, MonetaryValue price) {
        CartItem cartItem = microservice.updateCartItemPrice(cartItemId, price);
        return addCatalogData(cartItem);
    }

    public CartItem updateCartItem(CartItem cartItem) {
        cartItem.refundCode = cartItem.isFreeBuyItem ? "N" : null;
        cartItem = microservice.updateCartItem(cartItem);
        return addCatalogData(cartItem);
    }

    public CartDTO addNewItemToCart(Integer quantity, String assemblageId, Catalog catalog) {
        //check to see if it already exists
        String itemToAddId = "";
        String application = "";
        Buyer buyer = getBuyer();
        List<Catalog> cisList = this.catalogService.doesCatalogRecordExist(catalog);

        if (cisList.size() == 1) {
            itemToAddId = cisList.get(0).getId();
            catalog.setId(itemToAddId);
        }
        if (itemToAddId != "") {
            if (Objects.isNull(buyer)) {
                return new CartDTO();
            }
            if (!StringUtil.isBlankOrNull(assemblageId)) {
                application = "AM";
            }
            List<CartItem> itemsInCart = microservice.getCartItemsByBuyerId(buyer.getId(), application);
            boolean itemMatch = false;
            Integer newQuantity = 0;

            if (itemsInCart != null && itemsInCart.size() > 0) {
                String ciToUpdate = "";
                for (int i = 0; i < itemsInCart.size(); i++) {
                    CartItem ci = itemsInCart.get(i);
                    String ciToCompareId = ci.catalogPurchase.catalog.getId();
                    if (itemToAddId.equals(ciToCompareId) &&
                            !ci.isPassThroughItem) {
                        itemMatch = true;
                        ciToUpdate = ci.getId();
                        newQuantity = ci.quantity + quantity;
                        break;
                    }
                }
                if (itemMatch) {
                    microservice.updateCartItemQuantity(ciToUpdate, newQuantity);
                    return buildCartGroups(itemsInCart);
                }
            }
        }

        CartItem cartItem = new CartItem();
        cartItem.quantityRequested = quantity;
        cartItem.cartPrice = catalog.price;
        cartItem.quantity = quantity;
        CatalogPurchase catalogPurchase = new CatalogPurchase();
        catalogPurchase.catalog = catalog;
        cartItem.catalogPurchase = catalogPurchase;
        cartItem.addedDate = new Date();

        if (!StringUtil.isBlankOrNull(assemblageId)) {
            Assemblage assemblage = assemblageService.getAssemblageById(assemblageId);
            if (assemblage != null) {
                cartItem.catalogPurchase.assemblageRef = assemblage.getRef();
            }
        }

        Seller seller = sellerService.getSellerById(catalog.sellerRef.id);
        catalog.sellerRef = seller.getRef();

        if (Objects.isNull(buyer)) {
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }
        catalog.buyerRef = buyer.getRef();
        String currentNodeId = buyer.nodeRef.id;
        AuthorizedNode authorizedNode;
        try {
            authorizedNode = financeAdminService.getDefaultAuthorizedNode(currentNodeId);
        } catch (ApplicationException e) {
            authorizedNode = null;
        }

        if (authorizedNode != null && authorizedNode.fundingNodeRef != null) {
            //TODO: uncomment once we find out the problem with default funding node
            // cartItem.fundingNodeId = authorizedNode.fundingNodeRef.id;
        }

        if (seller.isNonReimbursable) {
            List <AuthorizedNode> authorizedNodes = financeAdminService.getAuthorizedNodes(this.currentUserBT.getCurrentNodeId());
            if (!authorizedNodes.isEmpty() && authorizedNodes.size() == 1){
                cartItem.fundingNodeId = authorizedNodes.get(0).fundingNodeRef.id;
            }
        }
        cartItem.isReplenishmentItem = false;
        cartItem.isPassThroughItem = false;
        cartItem.isNonSubmitOrder = false;

        if (Objects.nonNull(seller) && seller.isNonReimbursable) {
            cartItem.isFreeBuyItem = true;
        }else {
            cartItem.isFreeBuyItem = false;
        }

        cartItem = assignDefaultCodes(cartItem);

        return microservice.addCartItemToCart(buyer.getId(), cartItem);
    }

    public CartDTO addReplenishmentItemToCart(CartItem cartItem) {
        cartItem.addedDate = new Date();
        Buyer buyer = getBuyer();
        Catalog catalog = cartItem.catalogPurchase.catalog;
        Seller seller = sellerService.getSellerById(catalog.sellerRef.id);

        if (Objects.isNull(buyer)) {
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }
        String currentNodeId = buyerService.getBuyerById(buyer.getId()).organizationRef.id;
        AuthorizedNode authorizedNode = new AuthorizedNode();
        try {
            authorizedNode = financeAdminService.getDefaultAuthorizedNode(currentNodeId);
        } catch (ApplicationException e) {
            authorizedNode = null;
        }

        /* todo Amy 12/20/21 - like non-routine cart items,
            we need to uncomment and work on this when the
            default funding sit is worked out.
        if (authorizedNode != null && authorizedNode.fundingNodeRef != null) {
            cartItem.fundingNodeId = authorizedNode.fundingNodeRef.id;
        }
        String defaultFundingNodeId = financeAdminService.getDefaultAuthorizedNode(currentNodeId).fundingNodeRef.id;
        if (defaultFundingNodeId != null) {
            cartItem.fundingNodeId = defaultFundingNodeId;
        }
         */
        cartItem.isReplenishmentItem = true;
        cartItem.isPassThroughItem = false;
        cartItem.isNonSubmitOrder = false;
        if (Objects.nonNull(seller) && seller.isNonReimbursable) {
            cartItem.isFreeBuyItem = true;
        }
        else {
            cartItem.isFreeBuyItem = false;
        }

        return microservice.addCartItemToCart(buyer.getId(), cartItem);
    }

    public List<OrderDTO> cartCheckout(CartSellerItemsDTO group) throws ValidationException {
        Buyer buyer = getBuyer();
        if (Objects.isNull(buyer)) {
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }
        //Group the items by fund
        List<CartSellerItemsDTO> fundGroups = groupByFund(group);

        //Check funds before checkout
        for (CartSellerItemsDTO fg : fundGroups) {
            if (!validateCartItemFunds(fg, buyer.getId()).isEmpty()) {
                throw new ValidationException("Funds do not pass validation");
            }
        }

        List<CartSellerItemsDTO> suggestedSourceOfSupplyGroups = new ArrayList<>();
        List<CartSellerItemsDTO> commodityTypeGroups = new ArrayList<>();
        //TODO: Other grouping will go here if the funds validation passes
        for (CartSellerItemsDTO fundGroup : fundGroups) {
            //Group the items from SupplyType
            suggestedSourceOfSupplyGroups.addAll(selectGroupBys(fundGroup));
            commodityTypeGroups.addAll(groupByCommodityType(fundGroup));
        }
        List<OrderDTO> orders = new ArrayList<>();

        for (CartSellerItemsDTO fg : commodityTypeGroups) {
            OrderDTO groupedOrder = new OrderDTO();
            if (fg.items.size() > 1) {
                List<CartItem> freeBuyItemsNonSubmit = new ArrayList<>();
                List<CartItem> freeBuyItemsSubmit = new ArrayList<>();
                List<CartItem> nonSubmitOrderItems = new ArrayList<>();
                List<CartItem> electronicSubmitOrderItems = fg.items.stream().filter(cartItem -> Objects.nonNull(cartItem.isNonSubmitOrder) && !cartItem.isNonSubmitOrder && Objects.nonNull(cartItem.isFreeBuyItem) && !cartItem.isFreeBuyItem).collect(Collectors.toList());
                if (Objects.nonNull(fg.sellerTypeOrderConfiguration)) {
                    if (fg.sellerTypeOrderConfiguration.canAllowFreeBuy) {
                        freeBuyItemsSubmit = fg.items.stream().filter(cartItem -> Objects.nonNull(cartItem.isFreeBuyItem) && cartItem.isFreeBuyItem && Objects.nonNull(cartItem.isNonSubmitOrder) && !cartItem.isNonSubmitOrder).collect(Collectors.toList());
                    }
                    if (fg.sellerTypeOrderConfiguration.canDoANonSubmitOrder) {
                        nonSubmitOrderItems = fg.items.stream().filter(cartItem -> Objects.nonNull(cartItem.isNonSubmitOrder) && cartItem.isNonSubmitOrder).collect(Collectors.toList());
                    }
                }

                if (!nonSubmitOrderItems.isEmpty()) {
                    for (CartItem cartItem : nonSubmitOrderItems) {
                        if (cartItem.isFreeBuyItem) {
                            freeBuyItemsNonSubmit.add(cartItem);
                        }
                    }
                    if (!freeBuyItemsNonSubmit.isEmpty()) {
                        fg.items = freeBuyItemsNonSubmit;
                        groupedOrder = createGroupedOrder(fg, buyer);
                        orders.add(groupedOrder);
                        nonSubmitOrderItems.removeAll(freeBuyItemsNonSubmit);
                    }
                }

                if (!freeBuyItemsSubmit.isEmpty()) {
                    fg.items = freeBuyItemsSubmit;
                    groupedOrder = createGroupedOrder(fg, buyer);
                    orders.add(groupedOrder);
                }
                if (!nonSubmitOrderItems.isEmpty()) {
                    fg.items = nonSubmitOrderItems;
                    groupedOrder = createGroupedOrder(fg, buyer);
                    orders.add(groupedOrder);
                }

                if (Objects.nonNull(electronicSubmitOrderItems) && !electronicSubmitOrderItems.isEmpty()) {
                    fg.items = electronicSubmitOrderItems;
                    groupedOrder = createGroupedOrder(fg, buyer);
                    orders.add(groupedOrder);
                }
            } else {
                groupedOrder = createGroupedOrder(fg, buyer);
                orders.add(groupedOrder);
            }
        }
        return orders;
    }

    public OrderDTO createGroupedOrder(CartSellerItemsDTO fg, Buyer buyer) {
        OrderDTO order = new OrderDTO();
        Seller seller = sellerService.getSellerById(fg.sellerId);
        order.buyer = buyer;
        order.seller = seller;
        order.buyerRef = (BuyerRef) buyer.getRef();
        order.sellerRef = (SellerRef) seller.getRef();
        try {
            order.sellerTypeOrderConfiguration = sellerService.getSellerTypeOrderConfiguration(order.sellerRef.sellerType);
        } catch (ApplicationException e) {
            order.sellerTypeOrderConfiguration = new SellerTypeOrderConfiguration();
        }

        BuyerSellerAccount buyerSellerAccount = sellerService.getBuyerSellerAccountBySellerAndBuyerId(order.buyerRef.id, order.sellerRef.id);
        if (Objects.nonNull(buyerSellerAccount) && !StringUtil.isEmptyOrNull(buyerSellerAccount.locationId)) {
            order.buyerSellerLocation = sellerService.getSellerLocationById(buyerSellerAccount.locationId);
        }

        if (order.sellerTypeOrderConfiguration.needCustomerContract) {
            CustomerContract customerContract = sellerService.getCustomerContractById(buyerSellerAccount.contractId);
            order.contractNumber = customerContract.contractNum;
            order.contractExpirationDate = customerContract.contractExpirationDate;
        }

        if (order.sellerTypeOrderConfiguration.hasAccountNumberWithBuyer) {
            OrganizationSellerAccountNumber organizationSellerAccountNumber = sellerService.getOrganizationSellerAccountNumber(order.sellerRef.getId());
            if (Objects.nonNull(organizationSellerAccountNumber)) {
                order.organizationSellerAccountNumber = organizationSellerAccountNumber.accountNumber;
            }
        }

        if (order.sellerTypeOrderConfiguration.hasUserAccountNumber) {
            UserSellerAccount userSellerAccount = sellerService.getUserSellerAccountNumber(order.sellerRef.id);
            if (Objects.nonNull(userSellerAccount)) {
                order.userSellerAccountNumber = userSellerAccount.accountNumber;
            }
        }

        if (order.sellerTypeOrderConfiguration.canAcceptPurchaseCard) {
            String fundingNodeId = getFundingNodeId(fg);
            if (Objects.nonNull(fundingNodeId)) {
                List<PurchaseCardRef> purchaseCards = purchaseCardService.getActivePurchaseCardsByFundingNode(fundingNodeId);
                if (Objects.nonNull(purchaseCards) && !purchaseCards.isEmpty()) {
                    order.purchaseCards = purchaseCards;
                } else {
                    FundingNodeRef fundingNodeRef = financeAdminService.getFundingNodeById(fundingNodeId).fundingNodeRef;
                    if (order.sellerTypeOrderConfiguration.requirePurchaseCard) {
                        order.exceptions.add("No purchase cards available for the selected fund: " + fundingNodeRef.name);
                    }
                }
            }
        }

        if (order.exceptions.isEmpty()) {
            order.isNonSubmitOrder = fg.items.get(0).isNonSubmitOrder;
            for (Address address : buyer.Address) {
                if (address.isPrimary || buyer.Address.size() == 1) {
                    order.shippingAddress = address;
                    break;
                }
            }
            order.shippingAddressList = buyer.Address;
            order.transactionPurposeCodeRef = getTransactionPurposeCode();
            List<OrderItem> orderItems = new ArrayList<>();
            Integer lineNumber = 0;
            for (CartItem cartItem : fg.items) {
                OrderItem orderItem = new OrderItem();
                orderItem.requestedQuantity = cartItem.quantity;
                orderItem.remainingQuantity = cartItem.quantity;
                orderItem.increasedQuantity = 0;
                orderItem.cancelledQuantity = 0;
                orderItem.receivedQuantity = 0;
                orderItem.isNonSubmitOrder = cartItem.isNonSubmitOrder;
                orderItem.isHoldingOrder = cartItem.isHoldingOrder;
                orderItem.isEmergencyOrder = cartItem.isEmergencyOrder;
                orderItem.price = cartItem.cartPrice;
                orderItem.catalogPurchase = cartItem.catalogPurchase;
                orderItem.cartItemId = cartItem.getId();
                orderItem.orderLineNumber = ++lineNumber;
                orderItem.isReplenishmentItem = cartItem.isReplenishmentItem;
                orderItem.isFreeBuyItem = cartItem.isFreeBuyItem;
                orderItem.specialOptions = cartItem.specialOptions;
                orderItem.requiredDeliveryDate = cartItem.requiredDeliveryDate;
                orderItem.supplementalAddress = cartItem.supplementalAddress;
                orderItem.distributionCodeRef = cartItem.distributionCodeRef;
                orderItem.projectCode = cartItem.projectCode;
                orderItem.refundCode = cartItem.refundCode;
                orderItem.adviceCodeRef = cartItem.adviceCodeRef;
                orderItem.demandCodeRef = cartItem.demandCodeRef;
                orderItem.fundingNodeRef = financeAdminService.getFundingNodeById(cartItem.fundingNodeId).fundingNodeRef;
                if (order.fundingNodeRef == null) {
                    order.fundingNodeRef = orderItem.fundingNodeRef;
                }
                orderItem.replenishmentRecords = cartItem.replenishmentRecords;
                orderItem.signalCodeRef = cartItem.signalCodeRef;
                orderItem.mediaStatusCodeRef = cartItem.mediaStatusCodeRef;
                orderItem.routingIdentifierCodeRef = cartItem.routingIdentifierCodeRef;
                if (Objects.nonNull(seller.routingIdentifierCode)) {
                    orderItem.routingIdentifierCode = seller.routingIdentifierCode;
                }
                orderItem.priorityCodeRef = cartItem.priorityCodeRef;
                if (order.seller.reviewSubmittedOrders) {
                    orderItem.orderReviewStatus = OrderReviewStatus.PENDING.displayText;
                }
                orderItems.add(orderItem);
            }
            order.orderItems = orderItems;
        }

        return order;
    }

    public List<FundingNodeRef> getFundingNodes() {
        ArrayList<FundingNodeRef> fundingSelections = new ArrayList<FundingNodeRef>();
        try {
            //Get the list of Authorized Nodes
            List<AuthorizedNode> authorizedNodes = financeAdminService.getAuthorizedNodes(this.currentUserBT.getCurrentNodeId());
            //Only use the fundingNodeRef -- there's some much more data there we don't need and causes the PT to fail
            for (AuthorizedNode authorizedNode : authorizedNodes) {
                fundingSelections.add(authorizedNode.fundingNodeRef);
            }
        } catch (ApplicationException e) {
            logger.info("No funds available");
        }
        return fundingSelections;
    }

    public List<CartSellerItemsDTO> groupByFund(CartSellerItemsDTO sellerGroup) {
        List<CartSellerItemsDTO> sellerGroups = new ArrayList<>();
        List<String> fundingNodeIds = sellerGroup.items.stream().map(cartItem -> cartItem.fundingNodeId).distinct().collect(Collectors.toList());
        for (String fundingNodeId : fundingNodeIds) {
            CartSellerItemsDTO newSellerGroup = new CartSellerItemsDTO();
            newSellerGroup.sellerName = sellerGroup.sellerName;
            newSellerGroup.sellerId = sellerGroup.sellerId;
            newSellerGroup.sellerType = sellerGroup.sellerType;
            newSellerGroup.sellerTypeOrderConfiguration = sellerGroup.sellerTypeOrderConfiguration;
            if (!Objects.isNull(sellerGroup.exceptions) && !sellerGroup.exceptions.isEmpty())
                newSellerGroup.exceptions = sellerGroup.exceptions;
            for (CartItem cartItem : sellerGroup.items) {
                if ((cartItem.fundingNodeId != null && cartItem.fundingNodeId.equals(fundingNodeId)) ||
                        (cartItem.fundingNodeId == null && fundingNodeId == null))
                    newSellerGroup.items.add(cartItem);
            }
            sellerGroups.add(newSellerGroup);
        }
        return sellerGroups;
    }

    public List<CartSellerItemsDTO> groupByCommodityType(CartSellerItemsDTO fundGroup) {
        List<CartSellerItemsDTO> commodityGroups = new ArrayList<>();
        List<String> commodityTypes = fundGroup.items.stream().map(cartItem -> cartItem.catalogPurchase.catalog.commodityCodeRef.commodityType).distinct().collect(Collectors.toList());

        for (String commodityType : commodityTypes) {
            CartSellerItemsDTO newCommodityGroup = new CartSellerItemsDTO();
            newCommodityGroup.sellerName = fundGroup.sellerName;
            newCommodityGroup.sellerId = fundGroup.sellerId;
            newCommodityGroup.sellerType = fundGroup.sellerType;
            newCommodityGroup.sellerTypeOrderConfiguration = fundGroup.sellerTypeOrderConfiguration;
            if (!Objects.isNull(fundGroup.exceptions) && !fundGroup.exceptions.isEmpty())
                newCommodityGroup.exceptions = fundGroup.exceptions;
            for (CartItem cartItem : fundGroup.items) {
                if (cartItem.catalogPurchase.catalog.commodityCodeRef.commodityType == null || cartItem.catalogPurchase.catalog.commodityCodeRef.commodityType.equals(commodityType))
                    newCommodityGroup.items.add(cartItem);
            }
            commodityGroups.add(newCommodityGroup);
        }
        return commodityGroups;
    }

    public List<CartSellerItemsDTO> selectGroupBys(CartSellerItemsDTO fundGroup) {
        List<CartSellerItemsDTO> sellerGroups = new ArrayList<>();

        switch (fundGroup.sellerType) {
            case CONTRACTING:
                // TODO: uncommment when defaultSource is added
               /* List<String> defaultSources = fundGroup.items.stream().map(cartItem -> cartItem.customerItemSourcing.defaultSource).distinct().collect(Collectors.toList());
                for (String source : defaultSources) {
                    CartSellerItemsDTO newSellerGroup = new CartSellerItemsDTO();
                    newSellerGroup.sellerName = fundGroup.sellerName;
                    newSellerGroup.sellerId = fundGroup.sellerId;
                    newSellerGroup.sellerType = fundGroup.sellerType;
                    for (CartItem cartItem : fundGroup.items) {
                        if ((cartItem.customerItemSourcing != null && cartItem.customerItemSourcing.defaultSource != null && cartItem.customerItemSourcing.defaultSource.equals(source)) ||
                                ((cartItem.customerItemSourcing != null && cartItem.customerItemSourcing.defaultSource == null && source == null) ||
                                        (cartItem.customerItemSourcing == null && source == null)
                                )
                        ) {
                            newSellerGroup.items.add(cartItem);
                        }
                    }
                    sellerGroups.add(newSellerGroup);
                }*/
                break;
            case DLA_ELECTRONIC_CATALOG:

                List<String> pricingAgreements = fundGroup.items.stream().map(cartItem -> cartItem.catalogPurchase.catalog.pricingAgreementIdentifier).distinct().collect(Collectors.toList());
                for (String source : pricingAgreements) {
                    CartSellerItemsDTO newSellerGroup = new CartSellerItemsDTO();
                    newSellerGroup.sellerName = fundGroup.sellerName;
                    newSellerGroup.sellerId = fundGroup.sellerId;
                    newSellerGroup.sellerType = fundGroup.sellerType;
                    for (CartItem cartItem : fundGroup.items) {
                        // if ((cartItem.customerItemSourcing != null && cartItem.customerItemSourcing.pricingAgreementIdentifier != null && cartItem.customerItemSourcing.pricingAgreementIdentifier.equals(source)) ||
                        //       ((cartItem.customerItemSourcing != null && cartItem.customerItemSourcing.pricingAgreementIdentifier == null && source == null) ||
                        //             (cartItem.customerItemSourcing == null && source == null)
                        //   )
                        // ) {
                        newSellerGroup.items.add(cartItem);
                        // }
                    }
                    sellerGroups.add(newSellerGroup);
                }
                break;
            case DOD_PRIME_VENDOR:
                /*List<CartSellerItemsDTO> specialHandlingGroup = groupBySpecialHandling(fundGroup);

                List<CartSellerItemsDTO> deliveryTypeGroup = new ArrayList<>();
                for (CartSellerItemsDTO group : specialHandlingGroup){
                    deliveryTypeGroup.addAll( groupByDeliveryType(group));
                }

                List<CartSellerItemsDTO> delayedByDeliveryGroup = new ArrayList<>();
                for (CartSellerItemsDTO group : deliveryTypeGroup){
                    delayedByDeliveryGroup = groupByDelayedDeliveryDates(group);
                }

                for (CartSellerItemsDTO group : delayedByDeliveryGroup){
                    sellerGroups = groupByLinkedDueOuts(group);
                }*/
                // TODO: remove below line which adds fundGroup to sellerGroups and uncomment the code for seller type DOD prime vendor once funding is in place
                sellerGroups.add(fundGroup);
                break;
            default:
                sellerGroups.add(fundGroup);

        }
        return sellerGroups;
    }

    public List<CartSellerItemsDTO> groupBySpecialHandling(CartSellerItemsDTO fundGroup) {
        List<CartSellerItemsDTO> sellerGroups = new ArrayList<>();
        List<String> specialHandlings = fundGroup.items.stream().map(cartItem -> cartItem.specialHandling).distinct().collect(Collectors.toList());
        for (String theSpecialHandling : specialHandlings) {
            CartSellerItemsDTO newSellerGroup = new CartSellerItemsDTO();
            newSellerGroup.sellerName = fundGroup.sellerName;
            newSellerGroup.sellerId = fundGroup.sellerId;
            newSellerGroup.sellerType = fundGroup.sellerType;
            for (CartItem cartItem : fundGroup.items) {
                if ((cartItem.specialHandling != null && cartItem.specialHandling.equals(theSpecialHandling)) ||
                        (cartItem.specialHandling == null && theSpecialHandling == null)
                ) {
                    newSellerGroup.items.add(cartItem);
                }
            }
            sellerGroups.add(newSellerGroup);
        }
        return sellerGroups;
    }

    public List<CartSellerItemsDTO> groupByDeliveryType(CartSellerItemsDTO fundGroup) {
        List<CartSellerItemsDTO> sellerGroups = new ArrayList<>();
        List<String> deliveryTypes = fundGroup.items.stream().map(cartItem -> cartItem.deliveryType).distinct().collect(Collectors.toList());
        for (String type : deliveryTypes) {
            CartSellerItemsDTO newSellerGroup = new CartSellerItemsDTO();
            newSellerGroup.sellerName = fundGroup.sellerName;
            newSellerGroup.sellerId = fundGroup.sellerId;
            newSellerGroup.sellerType = fundGroup.sellerType;
            for (CartItem cartItem : fundGroup.items) {
                if ((cartItem.deliveryType != null && cartItem.deliveryType.equals(type)) ||
                        (cartItem.deliveryType == null && type == null)
                ) {
                    newSellerGroup.items.add(cartItem);
                }
            }
            sellerGroups.add(newSellerGroup);
        }
        return sellerGroups;
    }

    public List<CartSellerItemsDTO> groupByDelayedDeliveryDates(CartSellerItemsDTO fundGroup) {
        List<CartSellerItemsDTO> sellerGroups = new ArrayList<>();

        List<Date> delayedDeliveryDates = fundGroup.items.stream().map(cartItem -> cartItem.delayedDeliveryDate).distinct().collect(Collectors.toList());
        for (Date theDelayedDeliveryDate : delayedDeliveryDates) {
            CartSellerItemsDTO newSellerGroup = new CartSellerItemsDTO();
            newSellerGroup.sellerName = fundGroup.sellerName;
            newSellerGroup.sellerId = fundGroup.sellerId;
            newSellerGroup.sellerType = fundGroup.sellerType;
            for (CartItem cartItem : fundGroup.items) {
                if ((cartItem.delayedDeliveryDate != null && cartItem.delayedDeliveryDate.equals(theDelayedDeliveryDate)) ||
                        (cartItem.delayedDeliveryDate == null && theDelayedDeliveryDate == null)
                ) {
                    newSellerGroup.items.add(cartItem);
                }
            }
            sellerGroups.add(newSellerGroup);
        }
        return sellerGroups;
    }

    public List<CartSellerItemsDTO> groupByLinkedDueOuts(CartSellerItemsDTO fundGroup) {
        List<CartSellerItemsDTO> sellerGroups = new ArrayList<>();

        List<Integer> dueOutQuantities = fundGroup.items.stream().map(cartItem -> cartItem.dueOut.dueOutQuantity).distinct().collect(Collectors.toList());
        for (Integer theDueOutQuantity : dueOutQuantities) {
            CartSellerItemsDTO newSellerGroup = new CartSellerItemsDTO();
            newSellerGroup.sellerName = fundGroup.sellerName;
            newSellerGroup.sellerId = fundGroup.sellerId;
            newSellerGroup.sellerType = fundGroup.sellerType;
            for (CartItem cartItem : fundGroup.items) {
                if ((cartItem.dueOut != null && cartItem.dueOut.dueOutQuantity != null && cartItem.dueOut.dueOutQuantity.equals(theDueOutQuantity)) ||
                        ((cartItem.dueOut != null && cartItem.dueOut.dueOutQuantity == null && theDueOutQuantity == null) ||
                                (cartItem.dueOut == null && theDueOutQuantity == null)
                        )
                ) {
                    newSellerGroup.items.add(cartItem);
                }
            }
            sellerGroups.add(newSellerGroup);
        }
        return sellerGroups;
    }


    //This is to validate the funds
    public List<String> validateCartItemFunds(CartSellerItemsDTO sellerGroup, String buyerId) {
        List<String> errorMessages = new ArrayList<>();
        //Building the finance request
        CommonFinanceRequest financeRequest = new CommonFinanceRequest();
        financeRequest.eventType = EBusinessEventType.NEW_ORDER;
        financeRequest.sourceType = sellerGroup.sellerType;
        financeRequest.requestingOrg = buyerService.getBuyerByBuyerId(buyerId).nodeRef;
        financeRequest.requestGroups = new ArrayList<>();

        RequestGroup requestGroup = new RequestGroup();
        requestGroup.orderInformationRef = new OrderInformationRef();
        boolean hasFund = true;
        if (sellerGroup.items.get(0).fundingNodeId != null) {
            requestGroup.fundingNodeRef = financeAdminService.getFundingNodeById(sellerGroup.items.get(0).fundingNodeId).fundingNodeRef;
        } else {
            hasFund = false;
        }
        BuyerRef buyerRef = buyerService.getBuyerByBuyerId(buyerId).getRef();
        requestGroup.buyerRef = buyerRef;
        requestGroup.currentNodeRef = buyerRef.currentNodeRef;
        requestGroup.items = new ArrayList<>();
        if (sellerGroup.items != null && sellerGroup.items.size() > 0 && sellerGroup.items.get(0).catalogPurchase.catalog != null) {
            for (CartItem cartItem : sellerGroup.items) {
                FinanceItem financeItem = new FinanceItem();
                financeItem.quantity = cartItem.quantity;
                financeItem.itemRef = cartItem.catalogPurchase.catalog.itemRef;
                financeItem.catalog = cartItem.catalogPurchase.catalog;
                financeItem.commodityCodeRef = cartItem.catalogPurchase.catalog.commodityCodeRef;
                financeItem.amount = cartItem.catalogPurchase.catalog.price;
                financeItem.isReimbursable = !cartItem.isFreeBuyItem;
                financeItem.isStocked = false;
                if (!StringUtil.isEmptyOrNull(cartItem.catalogPurchase.catalog.itemRef.enterpriseProductIdentifier)) {
                    String stockedStatus = inventoryService.getItemStockType(buyerRef.currentNodeRef.nodeIdentifier, cartItem.catalogPurchase.catalog.itemRef.enterpriseProductIdentifier);
                    financeItem.isStocked = stockedStatus.equals("Stocked");
                }
                financeItem.isReimbursable = !cartItem.isFreeBuyItem;
                requestGroup.items.add(financeItem);
            }
        }
        //If the group doesn't have a fund selected then don't add it to the finance request
        if (hasFund) {
            financeRequest.requestGroups.add(requestGroup);
            errorMessages = financeProcessingValidator.validateRequest(financeRequest);
        }
        return errorMessages;
    }

    //This is to validate all the items in the cart
    // It only validates the funds right now
    //TODO: more validate will go in this method
    public CartSellerItemsDTO validateCartItems(CartSellerItemsDTO sellerGroup) {
        Buyer buyer = getBuyer();
        if (Objects.isNull(buyer)) {
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }
        CartSellerItemsDTO outGroup = new CartSellerItemsDTO();
        outGroup = sellerGroup;
        //Group the items by fund for validation.
        List<CartSellerItemsDTO> sgs = groupByFund(sellerGroup);
        //Validate the funds
        for (CartSellerItemsDTO sg : sgs) {
            List<String> exceptions = validateCartItemFunds(sg, buyer.getId());
            if (exceptions.size() == 0) {
                outGroup.exceptions = exceptions;
                SellerTypeOrderConfiguration sellerTypeOrderConfiguration = sellerService.getSellerTypeOrderConfiguration(sg.sellerType);
                if (sellerTypeOrderConfiguration.requirePurchaseCard) {
                    String fundingNodeId = getFundingNodeId(sg);
                    if (Objects.nonNull(fundingNodeId)) {
                        List<PurchaseCardRef> purchaseCards = purchaseCardService.getActivePurchaseCardsByFundingNode(fundingNodeId);
                        if (Objects.isNull(purchaseCards) || purchaseCards.isEmpty()) {
                            FundingNodeRef fundingNodeRef = financeAdminService.getFundingNodeById(fundingNodeId).fundingNodeRef;
                            sellerGroup.exceptions.add("No purchase cards available for the selected fund: " + fundingNodeRef.name);
                        }
                    }
                }
            } else {
                outGroup.exceptions.addAll(exceptions);
            }
        }

        return outGroup;
    }

    private AdviceCodeRef getDefaultAdviceCode() {
        List<AdviceCode> adviceCodes = this.getAdviceCodes();
        AdviceCode itemAdviceCode = new AdviceCode();
        if (!Objects.isNull(adviceCodes) && !adviceCodes.isEmpty()) {
            // TODO: This default code needs to come from the Buyer
            itemAdviceCode = adviceCodes.stream().filter(advice -> advice.code.equals("2D")).findAny().orElse(null);
        }
        return itemAdviceCode.getRef();
    }

    private DemandCodeRef getDefaultDemandCode() {
        List<DemandCode> demandCodes = this.getDemandCodes();
        DemandCode itemDemandCode = new DemandCode();
        if (!Objects.isNull(demandCodes) && !demandCodes.isEmpty()) {
            // TODO: This default code needs to come from the Buyer
            itemDemandCode = demandCodes.stream().filter(demand -> demand.code.equals("N")).findAny().orElse(null);
        }
        return itemDemandCode.getRef();
    }

    private SignalCodeRef getDefaultSignalCode() {
        List<SignalCode> signalCodes = this.getSignalCodes();
        SignalCode itemSignalCode = new SignalCode();
        if (!Objects.isNull(signalCodes) && !signalCodes.isEmpty()) {
            itemSignalCode = signalCodes.stream().filter(signal -> signal.code.equals("A")).findAny().orElse(null);
        }

        return itemSignalCode.getRef();
    }

    private MediaStatusCodeRef getDefaultMediaStatusCode() {
        List<MediaStatusCode> mediaStatusCodes = this.getMediaStatusCodes();
        MediaStatusCode mediaStatusCode = new MediaStatusCode();
        if (!Objects.isNull(mediaStatusCodes) && !mediaStatusCodes.isEmpty()) {
            mediaStatusCode = mediaStatusCodes.stream().filter(mediaStatus -> mediaStatus.code.equals("S")).findAny().orElse(null);
        }
        return mediaStatusCode.getRef();
    }

    private RoutingIdentifierCodeRef getDefaultRoutingIdentifierCode() {
        RoutingIdentifierCode routingIdentifierCode = new RoutingIdentifierCode();
        // TODO: the data from the database will be filtered, for now hardcoding the value
        routingIdentifierCode.code = "SMS";
        return routingIdentifierCode.getRef();
    }

    public TransactionPurposeCodeRef getTransactionPurposeCode() {
        // TODO: the data from the database will be filtered, for now hardcoding the value
        TransactionPurposeCode transactionPurposeCode = new TransactionPurposeCode();
        transactionPurposeCode.code = "77";
        return transactionPurposeCode.getRef();
    }

    public PriorityCodeRef getDefaultPriorityCode() {
        // hardcoding the designator value for now
        String designator = "III";
        List<PriorityCode> priorityCodes = this.getPriorityCodesByDesignator(designator);
        PriorityCode priorityCode = new PriorityCode();
        if (!Objects.isNull(priorityCodes) && !priorityCodes.isEmpty()) {
            priorityCode = priorityCodes.stream().filter(priority -> priority.code.equals("13")).findAny().orElse(null);
        }
        return priorityCode.getRef();
    }

    public ItemSummary populateItemSummary(Catalog catalog) {
        ItemSummary itemSummary = new ItemSummary();
        if (Objects.nonNull(catalog.itemRef)) {
            itemSummary = mapper.getObject(ItemSummary.class, catalog.itemRef);
        }
        return itemSummary;
    }

    private String getFundingNodeId(CartSellerItemsDTO group) {
        List<String> fundingNodeIds = group.items.stream().map(item -> item.fundingNodeId).distinct().collect(Collectors.toList());
        String fundingNodeId = null;
        if (Objects.nonNull(fundingNodeIds) && !fundingNodeIds.isEmpty()) {
            fundingNodeId = fundingNodeIds.get(0);
        }
        return fundingNodeId;
    }

    public List<AdviceCode> getAdviceCodes() {
        return microservice.getAdviceCodes();
    }

    public List<DemandCode> getDemandCodes() {
        return microservice.getDemandCodes();
    }

    public List<SignalCode> getSignalCodes() {
        return microservice.getSignalCodes();
    }

    public List<MediaStatusCode> getMediaStatusCodes() {
        return microservice.getMediaStatusCodes();
    }

    public List<PriorityCode> getPriorityCodesByDesignator(String designator) {
        return microservice.getPriorityCodesByDesignator(designator);
    }

    public List<DistributionCode> getDistributionCodes() {
        return microservice.getDistributionCodes();
    }

    public SearchResult<CatalogPurchase> getCatalogPurchaseSearchResults(SearchInput searchInput) {
        SearchResult<CatalogDTO> catalogDTOSearchResults = catalogLookupService.getCatalogSearchResults(searchInput);

        SearchResult<CatalogPurchase> catalogPurchaseSearchResults = new SearchResult<>();
        catalogPurchaseSearchResults.limit = catalogDTOSearchResults.limit;
        catalogPurchaseSearchResults.total = catalogDTOSearchResults.total;
        catalogPurchaseSearchResults.aggregations = catalogDTOSearchResults.aggregations;

        if (Objects.nonNull(catalogDTOSearchResults.results) && !catalogDTOSearchResults.results.isEmpty()) {
            for (CatalogDTO catalogDTO : catalogDTOSearchResults.results) {
                CatalogPurchase catalogPurchase = new CatalogPurchase();
                Item foundItem = itemService.getItemById(catalogDTO.itemRef.getId());
                if (!Objects.isNull(foundItem)) {
                    catalogPurchase.item = foundItem;
                    catalogPurchase.catalog = mapper.getObject(Catalog.class, catalogDTO);
                    catalogPurchaseSearchResults.results.add(catalogPurchase);
                } else {
                    logger.info("No Enterprise Item Record for:" + catalogDTO.itemRef.getId());
                }
            }
        }

        return catalogPurchaseSearchResults;
    }

    public CartDTO saveAssignedUserToCart(String sellerId, CurrentUserBtRef assignedUserRef, String application) {
        Buyer buyer = getBuyer();
        if (Objects.isNull(buyer)) {
            return new CartDTO();
        }
        CartDTO cartDTO = microservice.saveAssignedUserToCart(sellerId, buyer.getId(), assignedUserRef, application);
        cartDTO.sellerGroups = buildCartFunding(cartDTO.sellerGroups, buyer);
        return addCatalogData(cartDTO);
    }

    public SearchResult<CatalogPurchase> getNonCatalogPurchaseSearchResults(SearchInput searchInput) {
        SearchResult<CatalogDTO> catalogDTOSearchResults = catalogLookupService.getNonCatalogPurchaseSearchResults(searchInput);

        SearchResult<CatalogPurchase> catalogPurchaseSearchResults = new SearchResult<>();
        catalogPurchaseSearchResults.limit = catalogDTOSearchResults.limit;
        catalogPurchaseSearchResults.total = catalogDTOSearchResults.total;
        catalogPurchaseSearchResults.aggregations = catalogDTOSearchResults.aggregations;

        if (Objects.nonNull(catalogDTOSearchResults.results) && !catalogDTOSearchResults.results.isEmpty()) {
            for (CatalogDTO catalogDTO : catalogDTOSearchResults.results) {
                CatalogPurchase catalogPurchase = new CatalogPurchase();
                Item foundItem = itemService.getItemById(catalogDTO.itemRef.getId());
                if (!Objects.isNull(foundItem)) {
                    catalogPurchase.item = foundItem;
                } else {
                    logger.info("No Enterprise Item Record for:" + catalogDTO.itemRef.getId());
                }
                catalogPurchase.catalog = mapper.getObject(Catalog.class, catalogDTO);

                catalogPurchaseSearchResults.results.add(catalogPurchase);
            }
        }

        return catalogPurchaseSearchResults;
    }

    public List<CurrentUserBtRef> getAssignableCartUsers() {
        Buyer buyer = getBuyer();
        if (Objects.isNull(buyer)) {
            return new ArrayList<CurrentUserBtRef>();
        }
        List<CurrentUserBtRef> assignableUserRefs = new ArrayList<>();
        List<Role> roles = roleService.getRolesForPermission("611420a030b9d077e95f79dd");
        if (Objects.nonNull(roles) && !roles.isEmpty()) {
            List<String> roleIds = roles.stream().map(Role::getId).collect(Collectors.toList());
            if (!roleIds.isEmpty()) {
                List<UserProfile> assignableUserProfiles = this.userService.getUsersWithRoleRefs(roleIds);
                if (Objects.nonNull(assignableUserProfiles) && !assignableUserProfiles.isEmpty()) {
                    assignableUserProfiles = assignableUserProfiles.stream().filter(userProfile -> userProfile.currentNodeRef.id.equals(buyer.nodeRef.id)).collect(Collectors.toList());
                    for (UserProfile userProfile : assignableUserProfiles) {
                        assignableUserRefs.add(mapper.getObject(CurrentUserBtRef.class, userProfile));
                    }
                }
            }
        }

        return assignableUserRefs;
    }

    public List<CommodityCodeRef> getFundingCommodityCodeRef() {

        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(currentUserBT.getCurrentNodeId());

        List<FundingCategory> fundingCategories = financeAdminService.getCommodityCodesByFinancialSystem(financialSystem.getId());

        List<CommodityCodeRef> commodityCodeRefs = new ArrayList<>();
        for (FundingCategory fundingCategory : fundingCategories) {
            commodityCodeRefs.add(fundingCategory.commodityCodeRef);
        }

        return commodityCodeRefs;
    }

    private boolean isReplenishmentRecordInCart(String itemLocationId) {
        return microservice.isReplenishmentRecordInCart(itemLocationId);
    }

    public void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate) {
       microservice.processDataReferenceUpdate(dataReferenceUpdate);
    }

    public Integer deleteCartItemsForAssemblages(List<String> assemblageIds) {
        return microservice.deleteCartItemsForAssemblages(assemblageIds);
    }
}
