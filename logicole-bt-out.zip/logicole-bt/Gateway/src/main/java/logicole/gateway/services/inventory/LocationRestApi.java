package logicole.gateway.services.inventory;

import io.swagger.annotations.*;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.general.Contact;
import logicole.common.datamodels.general.TreeNode;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.inventory.*;
import logicole.gateway.rest.ExternalRestApi;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.List;


@Api(tags = {"Location"})
@ApplicationScoped
@Path("/location")
public class LocationRestApi extends ExternalRestApi<LocationService>  {


    @GET
    @Path("/getInventorySystems")
    public List<InventorySystem> getInventorySystems() {
        return service.getInventorySystems();
    }

    @GET
    @Path("/getInventorySystemsByStatus")
    public List<InventorySystem> getInventorySystemsByStatus(@QueryParam("status") String status) {
        return service.getInventorySystemsByStatus(status);
    }

    @POST
    @Path("/getInventorySystemsSearchResults")
    public SearchResult<InventorySystem> getInventorySystemsSearchResults(SearchInput searchInput) {
        return service.getInventorySystemsSearchResults(searchInput);
    }

    @GET
    @Path("/getInventorySystemById")
    public InventorySystem getInventorySystemById(@QueryParam("inventorySystemId") String inventorySystemId) {
        return service.getInventorySystemById(inventorySystemId);
    }

    @GET
    @Path("/getInventorySystemByNodeId")
    public InventorySystem getInventorySystemByNodeId(@QueryParam("nodeId") String nodeId) {
        return service.getInventorySystemByNodeId(nodeId);
    }

    @GET
    @Path("/getStorageLocationById")
    public StorageLocation getStorageLocationById(@QueryParam("storageLocationId") String storageLocationId) {
        return service.getStorageLocationById(storageLocationId);
    }

    @GET
    @Path("/getStorageLocationsByNodeId")
    public List<StorageLocation> getStorageLocationsByNodeId(@QueryParam("nodeId") String nodeId) {
        return service.getStorageLocationsByNodeId(nodeId);
    }

    @GET
    @Path("/getStorageLocationRefsByNodeId")
    public List<StorageLocationRef> getStorageLocationRefsByNodeId(@QueryParam("nodeId") String nodeId) {
        return service.getStorageLocationRefsByNodeId(nodeId);
    }

    @GET
    @Path("/getStorageLocationsByParentId")
    public List<StorageLocation> getStorageLocationsByParentId(@QueryParam("parentId") String parentId) {
        return service.getStorageLocationsByParentId(parentId);
    }

    @GET
    @Path("/getStorageLocationRefsByParentId")
    public List<StorageLocationRef> getStorageLocationRefsByParentId(@QueryParam("storageLocationId") String storageLocationId) {
        return service.getStorageLocationRefsByParentId(storageLocationId);
    }

    @GET
    @Path("/getLocationTypes")
    public List<LocationType> getLocationTypes() {
        return service.getLocationTypes();
    }

    @GET
    @Path("/getLocationTypeRefs")
    public List<LocationTypeRef> getLocationTypeRefs() {
        return service.getLocationTypeRefs();
    }


    @POST
    @Path("/lockStorageLocation")
    public StorageLocation lockStorageLocation(@QueryParam("storageLocationId") String storageLocationId) {
        return service.lockStorageLocation(storageLocationId);
    }

    @POST
    @Path("/unlockStorageLocation")
    public StorageLocation unlockStorageLocation(@QueryParam("storageLocationId") String storageLocationId) {
        return service.unlockStorageLocation(storageLocationId);
    }

    @POST
    @Path("/setStorageLocationActive")
    public StorageLocation setStorageLocationActive(@QueryParam("storageLocationId") String storageLocationId) {
        return service.setStorageLocationActive(storageLocationId);
    }

    @POST
    @Path("/setStorageLocationInactive")
    public StorageLocation setStorageLocationInactive(@QueryParam("storageLocationId") String storageLocationId) {
        return service.setStorageLocationInactive(storageLocationId);
    }

    @POST
    @Path("/saveStorageLocation")
    public StorageLocation saveStorageLocation(StorageLocation storageLocation) {
        return service.saveStorageLocation(storageLocation);
    }


    @POST
    @Path("/saveStorageLocationInfo")
    public StorageLocation saveStorageLocationInfo(StorageLocation storageLocation) {
        return service.saveStorageLocationInfo(storageLocation);
    }

    @POST
    @Path("/saveStorageRequirements")
    public StorageLocation saveStorageRequirements(StorageLocation storageLocation) {
        return service.saveStorageRequirements(storageLocation);
    }

    @POST
    @Path("/createInventorySystemRootStorageLocation")
    public StorageLocation createInventorySystemRootStorageLocation(StorageLocation storageLocation) {
        return service.createInventorySystemRootStorageLocation(storageLocation);
    }

    @POST
    @Path("/createStorageLocation")
    public StorageLocation createStorageLocation(StorageLocation storageLocation) {
        return service.createStorageLocation(storageLocation);
    }

    @GET
    @Path("/getInventorySystemsStorageLocationTrees")
    public List<TreeNode<StorageLocation>> getInventorySystemsStorageLocationTrees() {
        return service.getInventorySystemsStorageLocationTrees();
    }

    @GET
    @Path("/getCurrentUserInventoryStorageLocationTree")
    public List<TreeNode<StorageLocation>> getCurrentUserInventoryStorageLocationTree() {
        return service.getCurrentUserInventoryStorageLocationTree();
    }

    @GET
    @Path("/getInventoryStorageLocationTree")
    public List<TreeNode<StorageLocation>> getInventoryStorageLocationTree(@QueryParam("inventorySystemId") String inventorySystemId) {
        return service.getInventoryStorageLocationTree(inventorySystemId);
    }

    @GET
    @Path("/getInventoryTreeChildren")
    public List<TreeNode<StorageLocation>> getInventoryTreeChildren(@QueryParam("parentId") String parentId) {
        return service.getInventoryTreeChildren(parentId);
    }

    @GET
    @Path("/getCurrentUserInventorySystem")
    public InventorySystem getCurrentUserInventorySystem() {
        return service.getCurrentUserInventorySystem();
    }

    @GET
    @Path("/getCurrentUserRootStorageLocation")
    public StorageLocation getCurrentUserRootStorageLocation() {
        return service.getCurrentUserRootStorageLocation();
    }

    @POST
    @Path("/createInventorySystem")
    public InventorySystem createInventorySystem(@QueryParam("createStorageLocations") boolean createStorageLocations, InventorySystem system) {
        return service.createInventorySystem(createStorageLocations, system);
    }

    @POST
    @Path("/updateInventorySystem")
    public InventorySystem updateInventorySystem(InventorySystem system) {
        return service.updateInventorySystem(system);
    }

    @GET
    @Path("/getDescendantInventorySystemRefs")
    public List<InventorySystemRef> getDescendantInventorySystemRefs(@QueryParam("parentNodeId") String parentNodeId) {
        return service.getDescendantInventorySystemRefs(parentNodeId);
    }

    @GET
    @Path("/getParentSystemOpenLocationsByNodeId")
    public List<StorageLocation> getParentSystemOpenLocationsByNodeId(@QueryParam("nodeId") String nodeId) {
        return service.getParentSystemOpenLocationsByNodeId(nodeId);
    }

    @GET
    @Path("/getInventorySystemParent")
    public InventorySystem getInventorySystemParent(@QueryParam("inventorySystemId") String inventorySystemId) {
        return service.getInventorySystemParent(inventorySystemId);
    }

    @GET
    @Path("/hasInventorySystemParent")
    public boolean hasInventorySystemParent(@QueryParam("inventoryNodeId") String inventoryNodeId) {
        return service.hasInventorySystemParent(inventoryNodeId);
    }

    @POST
    @Path("/updateInventorySystemLocationAndLeveling")
    public InventorySystem updateInventorySystemLocationAndLeveling(@QueryParam("id") String id,
                                                                    @QueryParam("defaultLevelingType") String defaultLevelingType,
                                                                    @QueryParam("defaultLevelingMethod") String defaultLevelingMethod,
                                                                    @QueryParam("defaultInventoryDays") Integer defaultInventoryDays,
                                                                    StorageLocationRef defaultLocationRef) {
        return service.updateInventorySystemLocationAndLeveling(id, defaultLevelingType, defaultLevelingMethod, defaultInventoryDays, defaultLocationRef);
    }

    @POST
    @Path("/updateInventorySystemContact")
    public InventorySystem updateInventorySystemContact(@QueryParam("id") String id, Contact contact) {
        return service.updateInventorySystemContact(id, contact);
    }

    @GET
    @Path("/getInventorySystemByCurrentNodeId")
    public InventorySystem getInventorySystemByCurrentNodeId(@QueryParam("currentOrgId") String currentOrgId) {
        return service.getInventorySystemByCurrentNodeId(currentOrgId);
    }

    @POST
    @Path("/saveStorageLocationNote")
    public StorageLocation saveStorageLocationNote(@QueryParam("storageLocationId") String storageLocationId, Note note) {
        return service.saveStorageLocationNote(storageLocationId, note);
    }

    @POST
    @Path("/saveStorageLocationNotes")
    public StorageLocation saveStorageLocationNotes(@QueryParam("storageLocationId") String storageLocationId, List<Note> notes) {
        return service.saveStorageLocationNotes(storageLocationId, notes);
    }

    @POST
    @Path("/uploadStorageLocationAttachment")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload StorageLocation attachment", notes = "The return will be StorageLocation document, including updated attachments array.")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to uploadManaged",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public StorageLocation uploadStorageLocationAttachment(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form,
                                                           @QueryParam("storageLocationId") String storageLocationId,
                                                           @QueryParam("description") String description,
                                                           @QueryParam("section") String section)
            throws IOException {
        return service.uploadStorageLocationAttachment(form, storageLocationId, description, section);
    }

    @POST
    @Path("/removeStorageLocationNote")
    public StorageLocation removeStorageLocationNote(@QueryParam("storageLocationId") String storageLocationId,
                                                     @QueryParam("noteId") String noteId) {
        return service.removeStorageLocationNote(storageLocationId, noteId);
    }

    @POST
    @Path("/removeStorageLocationNotes")
    public StorageLocation removeStorageLocationNotes(@QueryParam("storageLocationId") String storageLocationId,
                                                      List<String> noteIds) {
        return service.removeStorageLocationNotes(storageLocationId, noteIds);
    }

    @POST
    @Path("/removeStorageLocationAttachment")
    public StorageLocation removeStorageLocationAttachment(@QueryParam("storageLocationId") String storageLocationId,
                                                           @QueryParam("fileId") String fileId)
            throws IOException {
        return service.removeStorageLocationAttachment(storageLocationId, fileId);
    }



}
