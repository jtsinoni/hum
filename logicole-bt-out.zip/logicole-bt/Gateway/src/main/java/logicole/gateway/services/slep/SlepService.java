package logicole.gateway.services.slep;

import logicole.apis.slep.ISlepMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.abi.PackageUnit;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.slep.*;
import logicole.common.datamodels.user.*;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.referencedata.PackageUnitService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.user.RoleService;
import logicole.gateway.services.user.UserService;

import java.util.*;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;

@ApplicationScoped
public class SlepService extends BaseGatewayService<ISlepMicroserviceApi> {

    private static final String ROLE_PM_ID = "5b033f872166030c9647f9d1";
    private static final String ROLE_SPM_ID = "5b033eadab7f21646b0bd9dc";
    private static final String ROLE_SR_ID = "5b033e382166030c9647f9ce";
    private static final String ROLE_UM_ID = "5b033dd3a46c8405dabb71fc";
    private static final String ROLE_RO_ID = "5ea84cf17bdb340c49a366d7";
    private static final String ROLE_JS_ID = "5f689ee494b4e33d42eb0e23";    // JMAR System Role

    protected static final String[] ALL_SLEP_ROLES = new String[]{
            ROLE_PM_ID,
            ROLE_RO_ID,
            ROLE_SPM_ID,
            ROLE_SR_ID,
            ROLE_UM_ID,
            ROLE_JS_ID
    };

    protected static final String[] SLEP_ROLES_IN_ORDER = new String[]{
            ROLE_PM_ID,
            ROLE_SPM_ID,
            ROLE_SR_ID,
            ROLE_UM_ID
    };

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    PackageUnitService packageUnitService;

    @Inject
    RoleService roleService;

    @Inject
    UserService userService;

    public SlepService() {
        super("Slep");
    }

    public List<SlepLotNumber> getLotNumberList(boolean includeAction, APIFetchListFilter filter) throws ApplicationException {
        return microservice.getLotNumberList(includeAction, filter);
    }

    public SlepLotNumber getLotNumberDetails(String nsn, String lotNum) throws ApplicationException {
        return microservice.getLotNumberDetails(nsn, lotNum);
    }

    public SlepLotNumber addLotNumber(SlepLotNumber lotNum) throws ApplicationException {
        return microservice.addLotNumber(lotNum);
    }

    public SlepLotNumber editLotNumber(SlepLotNumber lotNum) throws ApplicationException {
        return microservice.editLotNumber(lotNum);
    }

    public void approvalProcessLotNumber(SlepLotNumber lotNum) throws ApplicationException {
        microservice.approvalProcessLotNumber(lotNum);
    }

    public Integer updateLotNumbers(List<SlepLotNumber> lotNumList) throws ApplicationException {
        return microservice.updateLotNumbers(lotNumList);
    }

    public List<SlepLotNumber> getLotNumbersWithCatalog(String catalogId) {
        return microservice.getLotNumbersWithCatalog(catalogId);
    }

    public void updateLotNumberCatalogRef(SlepLotNumber lot) {
        microservice.updateLotNumberCatalogRef(lot);
    }


    public List<SlepLotStatus> getLotNumberStatusList(Boolean isFdaStatus) throws ApplicationException {
        return microservice.getLotNumberStatusList(isFdaStatus);
    }

    public List<String> getServiceAgencyList(Boolean isLogicoleInventory) throws ApplicationException {
        return microservice.getServiceAgencyList(isLogicoleInventory);
    }

    public List<String> getManufacturerList() throws ApplicationException {
        return microservice.getManufacturerList();
    }

    public List<SlepCustomer> getCustomerList(APIFetchListFilter filter) throws ApplicationException {
        return microservice.getCustomerList(filter);
    }

    public List<PackageUnit> getPackageUnitList() throws ApplicationException {
        return packageUnitService.getPackageUnitList();
    }

    public void addManufacturer(String manufacturerName) throws ApplicationException {
        microservice.addManufacturer(manufacturerName);
    }

    public List<SlepProject> getProjectList(@QueryParam("includeAction") boolean includeAction, APIFetchListFilter filter) throws ApplicationException {
        return microservice.getProjectList(includeAction, hasProjectEditPermission(), filter);
    }

    private boolean hasProjectEditPermission() {
        boolean hasEditPermission = false;
        CurrentUser currentUser = this.currentUserBT.getCurrentUser();
        for (RoleRef roleRef : currentUser.profile.roleRefs) {
            if (roleRef.getId().equals(this.ROLE_PM_ID)) {
                hasEditPermission = true;
                break;
            }
        }
        return hasEditPermission;
    }

    public SlepProject getProjectDetails(@QueryParam("projectId") String projectId, APIFetchListFilter projectLotNumfilter) throws ApplicationException {
        return microservice.getProjectDetails(projectId, projectLotNumfilter);
    }

    public List<SlepLotNumber> getAddableLotNumbers4Project() throws ApplicationException {
        return microservice.getAddableLotNumbers4Project();
    }

    public void addProject(SlepProject project) throws ApplicationException {
        microservice.addProject(project);
    }

    public void editProject(SlepProject project) throws ApplicationException {
        microservice.editProject(project);
    }

    public void verifyProject(SlepProject project) throws ApplicationException {
        microservice.verifyProject(project);
    }

    public List<SlepProjectStatus> getProjectStatusList() throws ApplicationException {
        return microservice.getProjectStatusList();
    }

    public Integer getMaxUploadSize() {
        return microservice.getMaxUploadSize();
    }

    public Attachment saveProjectAttachment(String projectId, Attachment attachment) {
        return microservice.saveProjectAttachment(projectId, attachment);
    }

    public boolean removeProjectAttachment(String projectId, String fileId) {
        return microservice.removeProjectAttachment(projectId, fileId);
    }

    public List<String> getProjectDocumentTypes() {
        return microservice.getProjectDocumentTypes();
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }


    /**
     * Inventory APIs
     **/
    public List<SlepInventory> getInventoryList(APIFetchListFilter filter) throws ApplicationException {
        return microservice.getInventoryList(filter);
    }

    public List<InventoryLotNumber> getAddableLotNumbers4Inventory(String dodaacId, String nsn, String lotNumber) throws ApplicationException {
        return microservice.getAddableLotNumbers4Inventory(dodaacId, nsn, lotNumber);
    }

    public Long getAddableLotNumbers4InventoryCount(String dodaacId, String nsn, String lotNumber) throws ApplicationException {
        return microservice.getAddableLotNumbers4InventoryCount(dodaacId, nsn, lotNumber);
    }

    public void editInventory(SlepInventory siteInventory) throws ApplicationException {
        microservice.editInventory(siteInventory);
    }

    public void certifyInventory(@QueryParam("dodaacId") String dodaacId) throws ApplicationException {
        microservice.certifyInventory(dodaacId);
    }


    /**
     * Catalog APIs
     **/
    public List<SlepCatalog> getCatalogList(APIFetchListFilter filter) throws ApplicationException {
        return microservice.getCatalogList(filter);
    }

    public void addCatalog(SlepCatalog catalog) throws ApplicationException {
        // new catalogs must be testable
        catalog.nsnStatus = SlepNsnStatus.ACTIVE;

        validateUnitCode(catalog);

        microservice.addCatalog(catalog);
    }

    public void editCatalog(SlepCatalog catalog) throws ApplicationException {
        validateUnitCode(catalog);

        microservice.editCatalog(catalog);
    }

    private void validateUnitCode(SlepCatalog catalog) throws ApplicationException {
        if (catalog==null) {
            throw new ValidationException("Catalog required");
        }

        if ( StringUtil.isEmptyOrNull(catalog.unitOfIssueCode) ) {

            if ( SlepNsnStatus.INACTIVE.equals(catalog.nsnStatus) ) {
                return;
            }

            throw new ValidationException("Unit of Issue Code required");
        }

        boolean isCodeValid = getPackageUnitList().stream()
                .map(unit->unit.dodPackUnit)
                .anyMatch(catalog.unitOfIssueCode::equals);

        if ( !isCodeValid ) {
            throw new ValidationException("Unit of Issue Code is invalid");
        }
    }


    /** DoDAAC APIs **/
    public List<SlepDodaac> getDodaacList(APIFetchListFilter filter) throws ApplicationException {
        return microservice.getDodaacList(filter);
    }

    public void addDodaac(SlepDodaac dodaac) throws ApplicationException {
        microservice.addDodaac(dodaac);
    }

    public void editDodaac(SlepDodaac dodaac) throws ApplicationException {
        microservice.editDodaac(dodaac);
    }

/***/

    /**
     * User APIs
     **/

    public List<SlepRole> getRoleList() throws ApplicationException {
        List<Role> slepRoles = roleService.getRolesByFunctionalArea("SLEP");
        return microservice.getRoleList(slepRoles);
    }

    public List<UserProfileInfo> getUserList(@QueryParam("parentId") String parentId) throws ApplicationException {
        if (StringUtil.isEmptyOrNull(parentId))
            parentId = currentUserBT.getCurrentUser().profile.getId();

        AppUserProfile parentUser = getAppUserProfile(parentId);
        if (parentUser == null || StringUtil.isEmptyOrNull(parentUser.slepRoleId))
            throw new ApplicationException("invalid user");

        List<String> slepRoleIds = getLowLevelSlepRoleIds(parentUser.slepRoleId);
        if (slepRoleIds == null || slepRoleIds.isEmpty())
            throw new ApplicationException("no privilege to get slep user list");

        List<AppUserProfile> allUsers = new ArrayList<>();
        allUsers.add(parentUser);

        List<AppUserProfile> appUserProfileList = getAppUserProfilesByParentId(parentUser, slepRoleIds);

        allUsers.addAll(appUserProfileList);
        return microservice.getUserList(allUsers);
    }

    public UserProfileInfo getUser(@QueryParam("appUserProfileId") String appUserProfileId) throws ApplicationException {
        if (StringUtil.isEmptyOrNull(appUserProfileId))
            appUserProfileId = currentUserBT.getCurrentUser().profile.getId();

        AppUserProfile appUserProfile = getAppUserProfile(appUserProfileId);
        if (appUserProfile == null || StringUtil.isEmptyOrNull(appUserProfile.slepRoleId))
            throw new ApplicationException("invalid user");

        return microservice.getUser(appUserProfile);
    }

    public Integer updateUser(SlepUserProfile userInfo) throws ApplicationException {
        if (userInfo == null || userInfo.appUserProfileRef == null || StringUtil.isEmptyOrNull(userInfo.appUserProfileRef.id))
            throw new ApplicationException("invalid input");

        AppUserProfile appUserProfile = getAppUserProfile(userInfo.appUserProfileRef.id);
        if (appUserProfile == null || StringUtil.isEmptyOrNull(appUserProfile.slepRoleId))
            throw new ApplicationException("invalid user");
        UserProfileInfo combinedProfile = new UserProfileInfo(appUserProfile, userInfo);

        return microservice.updateUser(combinedProfile);
    }


    private List<String> getLowLevelSlepRoleIds(String roleId) {
        List<String> roleIds = null;

        int i = 0;
        if (roleId.equals(ROLE_RO_ID)) {
            roleIds = new ArrayList<>();
        } else {
            for (i = 0; i < (SLEP_ROLES_IN_ORDER.length - 1); i++) {
                if (SLEP_ROLES_IN_ORDER[i].equals(roleId)) {
                    roleIds = new ArrayList<>();
                    break;
                }
            }
        }

        if (roleIds != null) {
            List<Role> slepRoles = roleService.getRolesByFunctionalArea("SLEP");

            List<String> allRoleIds = slepRoles.stream().map(role -> role.getId()).collect(Collectors.toList());
            for (i += 1; i < SLEP_ROLES_IN_ORDER.length; i++) {
                if (allRoleIds.contains(SLEP_ROLES_IN_ORDER[i]))
                    roleIds.add(SLEP_ROLES_IN_ORDER[i]);
            }
            return roleIds;
        } else
            return Collections.emptyList();

    }

    private List<AppUserProfile> getAppUserProfilesByParentId(AppUserProfile parentUser, List<String> roleIds) {
        List<AppUserProfile> allValidUserList = new ArrayList<>();

        if (ListUtil.isEmpty(roleIds))
            return allValidUserList;

        // qualified user list is based on the user role
        String parentUserID = parentUser.id;

        List<AppUserProfile> allUsers = null;

        allUsers = getUsersWithRoleRefs(roleIds);

        // filter out users not invited by parent user
        if (!ListUtil.isEmpty(allUsers)) {
            for (AppUserProfile user : allUsers) {
                if ( /*parentUserID.equals(user.createdByID) &&*/ !parentUserID.equals(user.id) && !containsUser(allValidUserList, user)) {
                    allValidUserList.add(user);
                }
            }
        }

        return allValidUserList;
    }

    private boolean containsUser(List<AppUserProfile> allValidUserList, AppUserProfile user) {
        if (allValidUserList == null || allValidUserList.isEmpty())
            return false;

        return allValidUserList.stream().anyMatch(item -> user.id.equals(item.id));
    }

    private List<AppUserProfile> getUsersWithRoleRefs(List<String> roleIds) {
        List<AppUserProfile> allUsers = new ArrayList<>();
        List<UserProfile> users;

        users = userService.getUsersWithRoleRefs(roleIds);

        if (users != null && !users.isEmpty()) {
            allUsers.addAll(users.stream().map(userProfile -> convertToAppUserProfile(userProfile)).collect(Collectors.toList()));
        }
        return allUsers;
    }


    private AppUserProfile getAppUserProfile(String id) {
        UserProfile userProfile = userService.getUserProfileById(id);
        if (userProfile == null)
            return null;
        return convertToAppUserProfile(userProfile);
    }

    private static RoleRef getSlepRoleRef(List<RoleRef> roleRefList) {
        List<String> slepRolesInOrder = Arrays.asList(ALL_SLEP_ROLES);
        for (String roleId : slepRolesInOrder) {
            for (RoleRef role : roleRefList) {
                if (roleId.equals(role.id))
                    return role;
            }
        }

        return null;
    }

    public static AppUserProfile convertToAppUserProfile(UserProfile user) {
        if (user == null)
            return null;

        AppUserProfile converted = new AppUserProfile();
        converted.id = user.getId();
        converted.email = user.email;
        converted.firstName = user.firstName;
        converted.lastName = user.lastName;
        converted.lastLoginDate = user.lastLoginDate;
        converted.createdBy = user.createdBy;
        converted.createdDate = user.createdDate;
        converted.createdByID = user.createdById;
        converted.reasonForAccess = user.reasonForAccess;
        converted.phoneNumber = ListUtil.isEmpty(user.phoneNumbers) ? null : user.phoneNumbers.get(0).value;
        RoleRef slepRole = getSlepRoleRef(user.roleRefs);
        if (slepRole != null) {
            converted.slepRoleName = slepRole.name;
            converted.slepRoleId = slepRole.id;
        }

        return converted;
    }


    public List<SlepLotNumberETL> getLotNumbers(APIFetchListFilter filter) throws ApplicationException {
        return microservice.getLotNumbers(filter);
    }

    public List<SlepInventoryETL> getInventories(APIFetchListFilter filter) throws ApplicationException {
        return microservice.getInventories(filter);
    }

    public List<SlepProjectETL> getProjects(APIFetchListFilter filter) throws ApplicationException {
        return microservice.getProjects(filter);
    }

/***/
}
