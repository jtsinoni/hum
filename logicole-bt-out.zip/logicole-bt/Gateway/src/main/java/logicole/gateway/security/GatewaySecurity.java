package logicole.gateway.security;

import logicole.common.general.exception.InvalidCredentialsException;
import logicole.common.general.logging.ILogger;
import logicole.common.general.security.SecurityConstants;
import logicole.common.general.security.token.TokenUtil;
import logicole.common.general.security.token.TokenValidator;
import logicole.gateway.services.user.CurrentUserService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@ApplicationScoped
public class GatewaySecurity {

    private static final String JSON_WEB_TOKEN_NOT_REQUIRED = "Verifying request from {}, therefore JsonWebToken is not required.";

    @Inject
    private HttpServletRequest request;
    @Inject
    private ILogger logger;
    @Inject
    private CurrentUserService currentUserService;
    @Inject
    private TokenValidator tokenValidator;
    @Inject
    private TokenUtil tokenUtil;


    public void verifyRequest() throws IOException {

        String requestUri = request.getRequestURI();
        String dnHeader = request.getHeader(SecurityConstants.DN_HEADER);
        String iasJwt = request.getHeader(SecurityConstants.IAS_JWT);
        String authorizationHeader = request.getHeader(SecurityConstants.AUTHORIZATION);
        String clientIpAddress = request.getHeader(SecurityConstants.CLIENT_IP_ADDRESS_HEADER);

        if (iasJwt != null){
            dnHeader = tokenUtil.getDnFromIasJwt(iasJwt);
        }

        if (dnHeader == null && iasJwt == null) {
            throw new InvalidCredentialsException("PkiDn or IAS JWT not provided.");
        }

        if (requestUri.equals(SecurityConstants.URI_LOGIN)) {
            logger.info(JSON_WEB_TOKEN_NOT_REQUIRED, SecurityConstants.URI_LOGIN);
        } else if (requestUri.equals(SecurityConstants.URI_GET_LOGICOLE_AUTH_TOKEN)) {
            logger.info(JSON_WEB_TOKEN_NOT_REQUIRED, SecurityConstants.URI_GET_LOGICOLE_AUTH_TOKEN);
        } else if (requestUri.equals(SecurityConstants.URI_GET_EHR_LC_AUTH_TOKEN)) {
            logger.info(JSON_WEB_TOKEN_NOT_REQUIRED, SecurityConstants.URI_GET_EHR_LC_AUTH_TOKEN);
        } else if (requestUri.equals(SecurityConstants.URI_GET_MAXIMO_LC_AUTH_TOKEN)) {
            logger.info(JSON_WEB_TOKEN_NOT_REQUIRED, SecurityConstants.URI_GET_MAXIMO_LC_AUTH_TOKEN);
        } else if (requestUri.equals(SecurityConstants.URI_REACHBACK_FROM_DMLSS)) {
            logger.info(JSON_WEB_TOKEN_NOT_REQUIRED, SecurityConstants.URI_REACHBACK_FROM_DMLSS);
        } else if (requestUri.equals(SecurityConstants.URI_GET_SSO_SAP_TEWLS_AUTH_TOKEN)) {
            logger.info(JSON_WEB_TOKEN_NOT_REQUIRED, SecurityConstants.URI_GET_SSO_SAP_TEWLS_AUTH_TOKEN);
        } else if (requestUri.equals(SecurityConstants.URI_GET_SSO_SAP_TEWLS_URL)) {
            logger.info(JSON_WEB_TOKEN_NOT_REQUIRED, SecurityConstants.URI_GET_SSO_SAP_TEWLS_URL);
        }
        else if (SecurityConstants.USER_REQUEST_ENDPOINT_URIS.contains(requestUri) ||
                SecurityConstants.INVITATION_ENDPOINT_URIS.contains(requestUri) ||
                SecurityConstants.PKI_DN_RENEW_ENDPOINT_URIS.contains(requestUri)) {
            logger.info(JSON_WEB_TOKEN_NOT_REQUIRED, requestUri);
        } else if (!tokenValidator.authorizationHeaderIsJwt(authorizationHeader)) {
            throw new InvalidCredentialsException(
                    String.format("%s header not found or is not a JsonWebToken: %s.",
                            SecurityConstants.AUTHORIZATION, authorizationHeader));
        }

        currentUserService.setCurrentUserForRequest(requestUri, dnHeader, authorizationHeader, clientIpAddress);
    }
}
