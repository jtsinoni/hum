package logicole.gateway.services.finance;

import logicole.apis.finance.IPurchaseCardMicroserviceApi;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.finance.purchasecard.PurchaseCard;
import logicole.common.datamodels.finance.purchasecard.PurchaseCardRef;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.datamodels.user.UserProfileRef;
import logicole.common.datamodels.workflow.WorkflowStepSummary;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.finance.validator.PurchaseCardValidator;
import logicole.gateway.services.finance.workflow.EPurchaseCardWorkflowStepName;
import logicole.gateway.services.finance.workflow.PurchaseCardAcceptanceWorkflowService;
import logicole.gateway.services.user.UserService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@ApplicationScoped
public class PurchaseCardService extends BaseGatewayService<IPurchaseCardMicroserviceApi> {

    public PurchaseCardService() {
        super("PurchaseCard");
    }

    @Inject
    PurchaseCardAcceptanceWorkflowService purchaseCardAcceptanceWorkflow;
    @Inject
    UserService userService;
    @Inject
    PurchaseCardValidator purchaseCardValidator;
    @Inject
    FinanceAdminService financeAdminService;

    public static final String APPROVING_OFFICIAL_ROLE = "ApprovingOfficialRole";
    private static final String CARDHOLDER_ROLE = "CardholderRole";
    private static final String AGENCY_PROGRAM_COORDINATOR = "AgencyProgramCoordinatorRole";

    public PurchaseCard createPurchaseCard(PurchaseCard purchaseCard) {
        purchaseCardValidator.validatePurchaseCard(purchaseCard);

        PurchaseCard returnValue =  microservice.createPurchaseCard(purchaseCard);
        purchaseCardAcceptanceWorkflow.create(returnValue);
        return returnValue;
    }

    public PurchaseCard updatePurchaseCard(PurchaseCard purchaseCard) {
        purchaseCardValidator.validatePurchaseCard(purchaseCard);
        if (!verifyApprovingOfficialHasValidCardCount(purchaseCard)) {
            throw new ApplicationException("Approving Official cannot be designated to more than 7 Active cards; ");
        }
        PurchaseCard returnValue =  microservice.updatePurchaseCard(purchaseCard);
        // TODO: Should there be an update in the Workflow?
//        purchaseCardAcceptanceWorkflow.update(returnValue);
        return returnValue;
    }

    public PurchaseCard getPurchaseCardById(String id) {
        PurchaseCard purchaseCard = microservice.getPurchaseCardById(id);
        // If in Verification the Card Holder should not see the cardNumber
        if (EPurchaseCardWorkflowStepName.VERIFICATION.getJsonValue().equals(purchaseCard.workflowState.currentStep.name)) {
            purchaseCard.cardNumber = null;
            purchaseCard.confirmCardNumber = null;
        }
        return purchaseCard;
    }

    public PurchaseCard getPurchaseCardById(String id, boolean checkStepName) {
        if (checkStepName) {
            return getPurchaseCardById(id);
        } else {
            return microservice.getPurchaseCardById(id);
        }
    }

    public List<PurchaseCard> getPurchaseCardsByRef(UserProfileRef userProfileRef) {
        return microservice.getPurchaseCardsByRef(userProfileRef);
    }
    public  List<PurchaseCardRef> getActivePurchaseCardsByFundingNode(String fundingNodeId) {
        return microservice.getActivePurchaseCardsByFundingNode(fundingNodeId);
    }

    public  List<PurchaseCard> getPurchaseCardsByOrg(OrganizationRef organizationRef) {
        return microservice.getPurchaseCardsByOrg(organizationRef);
    }

    public List<PurchaseCard> getPurchaseCardsBySearchText(String searchText, String userProfileId) {
        return microservice.getPurchaseCardsBySearchText(searchText, userProfileId);
    }

    public PurchaseCard validate(PurchaseCard purchaseCard) {
        PurchaseCard validatedPurchaseCard = purchaseCardAcceptanceWorkflow.validate(purchaseCard);
        ++validatedPurchaseCard.cardValidationAttempts;
        // TODO: After validate(...) cardNumber & confirmCardNumber get nullified in validatedPurchaseCard, need to investigate why
        validatedPurchaseCard.cardNumber = purchaseCard.cardNumber;
        validatedPurchaseCard.confirmCardNumber = purchaseCard.confirmCardNumber;
        return microservice.updatePurchaseCard(validatedPurchaseCard);
    }

    public PurchaseCard cancel(PurchaseCard purchaseCard) {
        return purchaseCardAcceptanceWorkflow.cancel(purchaseCard);
    }

    public PurchaseCard verify(PurchaseCard purchaseCard) {
        PurchaseCard validatedPurchaseCard = microservice.getPurchaseCardById(purchaseCard.getId());
        // Following verification attempts are zero based, i.e. on the third failed attempt fail PurchaseCard
        if (validatedPurchaseCard.cardVerificationAttempts > 1) {
            // Reset back to 0, this may occur if the AO/APC needs to re-validate when the card holder attempted multiple times to verify their card
            PurchaseCard failedPurchaseCard = fail(purchaseCard);
            failedPurchaseCard.cardVerificationAttempts = 0;
            return microservice.updatePurchaseCard(failedPurchaseCard);
        }

        PurchaseCard verifiedPurchaseCard = purchaseCardAcceptanceWorkflow.verify(purchaseCard);
        ++verifiedPurchaseCard.cardVerificationAttempts;
        verifiedPurchaseCard.isActive = true;
        return microservice.updatePurchaseCard(verifiedPurchaseCard);
    }

    public PurchaseCard reject(PurchaseCard purchaseCard) {
        return purchaseCardAcceptanceWorkflow.reject(purchaseCard);
    }

    public PurchaseCard reset(PurchaseCard purchaseCard) {
        return purchaseCardAcceptanceWorkflow.reset(purchaseCard);
    }

    public PurchaseCard fail(PurchaseCard purchaseCard) {
        return purchaseCardAcceptanceWorkflow.fail(purchaseCard);
    }

    public void delete(PurchaseCard purchaseCard) {
        microservice.delete(purchaseCard.getId());
    }

    public List<WorkflowStepSummary> buildWorkflowStepSummary(PurchaseCard purchaseCard) {
        PurchaseCard persisted = microservice.getPurchaseCardById(purchaseCard.getId());
        return purchaseCardAcceptanceWorkflow.buildWorkflowStepSummary(persisted);
    }

    public List<String> getProfilesForApprovingOfficial(UserProfileRef approvingOfficialProfileRef) {
        UserProfile profile = userService.getUserProfileById(approvingOfficialProfileRef.id);
        String pkiDn = profile.pkiDn;
        List<UserProfile> approvingOfficialProfiles = userService.getUserByPkiDn(pkiDn);
        List<String> refs = new ArrayList<>();
        approvingOfficialProfiles.stream().forEach(approvingOfficial -> refs.add(approvingOfficial.getId()));
        return refs;
    }

    public String getConfigurationValue(String valueName) {
        return  microservice.getConfigurationValue(valueName);
    }

    public List<UserProfileRef> getApprovingOfficials(UserProfileRef userProfileRef) {
        String roleId = getConfigurationValue(APPROVING_OFFICIAL_ROLE);
        UserProfile profile = userService.getUserProfileById(userProfileRef.id);
        String pkiDn = profile.pkiDn;
        List<String> pkidns = getAgencyProgramCoordinatorPkidns();
        pkidns.add(pkiDn);
        List<UserProfile> approvingOfficials = userService.getUsersWithRoleRefs(Arrays.asList(roleId), pkidns);
        List<UserProfileRef> refs = new ArrayList<>();
        approvingOfficials.stream().forEach(approvingOfficial -> refs.add(approvingOfficial.getRef()));
        return refs;
    }

    public List<UserProfileRef> getApprovedCardholderProfiles() {
        String cardholderRoleId = microservice.getConfigurationValue(CARDHOLDER_ROLE);
        String currentUserPkiDn = currentUserBT.getpkiDn();
        List<UserProfile> profiles = userService.findActiveProfilesWithRoleRef(cardholderRoleId, Arrays.asList(currentUserPkiDn));
        List<UserProfileRef> refs = new ArrayList<>();
        profiles.stream().forEach(profile -> refs.add(profile.getRef()));
        return refs;
    }

    private List<String> getAgencyProgramCoordinatorPkidns() {
        String agencyProgramCoordinatoryRoleId = microservice.getConfigurationValue(AGENCY_PROGRAM_COORDINATOR);
        List<UserProfile> profiles = userService.findActiveProfilesWithRoleRef(agencyProgramCoordinatoryRoleId, new ArrayList<>());
        List<String> pkidns = new ArrayList<>();
        profiles.stream().forEach(profile -> pkidns.add(profile.pkiDn));
        return pkidns;
    }

    public List<String> getPurchaseCardTypes() {
        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(currentUserBT.getCurrentNodeId());
        return financialSystem.purchaseCardTypes;
    }

    public List<String> getPurchaseCardSubTypes() {
        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(currentUserBT.getCurrentNodeId());
        return financialSystem.purchaseCardSubTypes;
    }

    public List<String> getPurchaseCardFundingSourceTypes() {
        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(currentUserBT.getCurrentNodeId());
        return financialSystem.purchaseCardFundingSourceTypes;
    }

    public boolean verifyApprovingOfficialHasValidCardCount(PurchaseCard purchaseCard) {
        List<String> approvingOfficialProfileIds = getProfilesForApprovingOfficial(purchaseCard.approvingOfficial);
        return microservice.verifyApprovingOfficialHasValidCardCount(approvingOfficialProfileIds, purchaseCard.getId());
    }

    public List<PurchaseCard> getActiveCardsForApprovingOfficial(String pkiDn) {
        //List<UserProfile> profiles = userService.getActiveUserProfiles(pkiDn);
        //List<String> profileIds = new ArrayList<>();
        //profiles.stream().forEach(profile -> profileIds.add(profile.getId()));

        return microservice.getActiveCardsForApprovingOfficial(pkiDn);
    }
}

