package logicole.gateway.services.organization;

import logicole.apis.organization.IOrganizationMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Configuration;
import logicole.common.datamodels.dmlss.EhrSiteCustomer;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.TreeNode;
import logicole.common.datamodels.general.search.SearchCriterion;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.tree.TreeChange;
import logicole.common.datamodels.general.tree.TreeChangeRequest;
import logicole.common.datamodels.general.tree.TreeVersion;
import logicole.common.datamodels.inventory.EStockOwnership;
import logicole.common.datamodels.inventory.ESystemType;
import logicole.common.datamodels.inventory.InventorySystem;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.buyer.BuyerDTO;
import logicole.common.datamodels.organization.AncestryQuery;
import logicole.common.datamodels.organization.ArchiveOrganization;
import logicole.common.datamodels.organization.BusinessServiceDefinitionRef;
import logicole.common.datamodels.organization.Consumer;
import logicole.common.datamodels.organization.DmlssHost;
import logicole.common.datamodels.organization.MarketInfo;
import logicole.common.datamodels.organization.NodeImportStatus;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationType;
import logicole.common.datamodels.organization.OrganizationTypeRef;
import logicole.common.datamodels.organization.ProviderRef;
import logicole.common.datamodels.organization.ScopeNodeTypeQuery;
import logicole.common.datamodels.organization.ScopeQuery;
import logicole.common.datamodels.organization.ServiceProvider;
import logicole.common.datamodels.organization.ServiceProviderRef;
import logicole.common.datamodels.organization.StandardStructureCode;
import logicole.common.datamodels.sale.seller.Seller;
import logicole.common.datamodels.sale.seller.SellerType;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.Role;
import logicole.common.datamodels.user.RoleRef;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.inventory.LocationService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.order.OrderService;
import logicole.gateway.services.sale.SellerService;
import logicole.gateway.services.user.RoleService;
import org.apache.commons.io.IOUtils;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.ClientErrorException;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


@ApplicationScoped
public class OrganizationService extends BaseGatewayService<IOrganizationMicroserviceApi> {
    @Inject
    RoleService roleService;
    @Inject
    BuyerService buyerService;
    @Inject
    OrderService orderService;
    @Inject
    SellerService sellerService;
    @Inject
    LocationService locationService;
    @Inject
    private MultiPartFormUtil multiPartFormUtil;
    @Inject
    private FileManagerAdminService fileManagerAdminService;

    public OrganizationService() {
        super("Organization");
    }

    @Override
    protected void addInitializationRoutines() {
        // The two commented lines below are for example
//        addInitializationRoutine("5fc851c9-5816-44f4-bb37-c6e728bfba81", this::IR_AddSomePermission);
//        addInitializationRoutine("5fc851c9-5816-44f4-bb37-c6e728bfba84", microservice::executeInitializationRoutine);
    }

    // The commented method below is for example
//    private InitializationRoutineResult IR_AddSomePermission(InitializationRoutineRef initializationRoutineRef) {
//    }

    public void updateOrgRefs(OrganizationRef organizationRef) {
        microservice.updateOrgRefs(organizationRef);
    }

    public List<Configuration> getAllConfigurations() {
        return microservice.getAllConfigurations();
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public List<ArchiveOrganization> getArchiveOrganizations() {
        return microservice.getArchiveOrganizations();
    }

    public ArchiveOrganization getArchiveOrganizationByIdentifier(String identifier) {
        return microservice.getArchiveOrganizationByIdentifier(identifier);
    }

    public List<ServiceProviderRef> getServiceProvidersAsRef() {
        return microservice.getServiceProvidersAsRef();
    }

    public List<ServiceProvider> getServiceProviders() {
        return microservice.getServiceProviders();
    }

    public ServiceProvider getServiceProviderById(String id) {
        return microservice.getServiceProviderById(id);
    }

    public Boolean checkDuplicateServiceProvider(String name, String id) {
        ServiceProvider serviceProvider = microservice.getServiceProviderByName(name);
        return (serviceProvider != null && !id.equals(serviceProvider.getId()));
    }

    public ServiceProvider saveProviderConsumer(ServiceProvider provider) {
        provider.updatedBy = getCurrentUser().profile.getFullName();
        return microservice.saveProviderConsumer(provider);
    }

    public ServiceProvider saveServiceProviderRoles(ServiceProvider provider) {
        provider.updatedBy = getCurrentUser().profile.getFullName();
        return microservice.saveServiceProviderRoles(provider);
    }

    public List<OrganizationRef> determineOrganizationAccess(String nodeTypeId, List<OrganizationRef> scopeNodeRefs) {
        List<OrganizationRef> returnList = new ArrayList<>();

        AncestryQuery ancestryQuery = new AncestryQuery();
        ancestryQuery.organizationTypeId = nodeTypeId;
        ancestryQuery.scopeOrganizationIds.addAll(scopeNodeRefs.stream().map(OrganizationRef::getId).collect(Collectors.toList()));

        List<Organization> accessToNodes = microservice.getScopeUsingAncestry(ancestryQuery);

        // TODO: This is very inefficient, ObjectMapper list conversion was not working though
        for (Organization node : accessToNodes) {
            OrganizationRef ref = node.getRef();
            if (!returnList.contains(ref)) {
                returnList.add(ref);
            }
        }
        return returnList;
    }

    public StandardStructureCode getStandardStructureCodeNode(String type, String code) {
        return microservice.getStandardStructureCodeNode(type, code);
    }

    public List<String> getStandardStructureTypes() {
        return microservice.getStandardStructureTypes();
    }

    public TreeNode<Organization> getOrganizationAncestryTreeById(String organizationId, boolean includeSiblings) {
        return microservice.getOrganizationAncestryTreeById(organizationId, includeSiblings);
    }

    public TreeNode<Organization> getOrganizationTreeById(String organizationId) {
        return microservice.getOrganizationTreeById(organizationId);
    }

    public List<OrganizationRef> getDescendantOrganizationRefs(String organizationId) {
        return microservice.getDescendantOrganizationRefs(organizationId);
    }

    public List<Organization> getOrganizationChildren(String parentId) {
        return microservice.getOrganizationChildren(parentId);
    }

    public List<TreeNode<Organization>> getOrganizationTreeChildren(String parentId) {
        return microservice.getOrganizationTreeChildren(parentId);
    }

    public Organization getParentOrganization(String organizationId) {
        return microservice.getParentOrganization(organizationId);
    }

    public Organization getOrganization(String organizationId) {
        return microservice.getOrganization(organizationId);
    }

    public Organization getOrganizationByOrganizationIdentifier(String organizationIdentifier) {
        return microservice.getOrganizationByOrganizationIdentifier(organizationIdentifier);
    }


    public List<String> getOrganizationRoleIds(List<String> organizationIds) {
        return microservice.getOrganizationRoleIds(organizationIds);
    }

    public List<OrganizationType> getOrganizationTypes() {
        return microservice.getOrganizationTypes();
    }

    public List<OrganizationType> getAllNonRootOrganizationTypes() {
        return microservice.getAllNonRootOrganizationTypes();
    }

    public OrganizationType getOrganizationTypeById(String organizationTypeId) {
        return microservice.getOrganizationTypeById(organizationTypeId);
    }

    public OrganizationTypeRef getOrganizationTypeRef(String organizationId) {
        return microservice.getOrganizationTypeRef(organizationId);
    }

    public List<Organization> getOrganizationsInScope(ScopeQuery scopeNode) {
        return microservice.getOrganizationsInScope(scopeNode);
    }

    public List<String> getOrganizationIdsByScopeAndNodeTypes(ScopeNodeTypeQuery scopeNodeTypeQuery) {
        return microservice.getOrganizationIdsByScopeAndNodeTypes(scopeNodeTypeQuery);
    }

    public List<Organization> getOrganizationsInScopeByOrganizationTypeName(ScopeQuery scopeNode) {
        return microservice.getOrganizationsInScopeByOrganizationTypeName(scopeNode);
    }

    public List<String> getOrganizationOrgIdsForParent(String startingOrganizationId) {
        return microservice.getOrganizationOrgIdsForParent(startingOrganizationId);
    }

    public OrganizationTypeRef getOrganizationTypeRefByName(String typeName) {
        return microservice.getOrganizationTypeRefByName(typeName);
    }

    public void reSyncOrganizationAncestry() {
        microservice.reSyncOrganizationAncestry();
    }

    public OrganizationRef getOrganizationRefById(String organizationId) {
        return microservice.getOrganizationRefById(organizationId);
    }

    public ProviderRef getProvider(String startOrgId, String providerType) {
        if (StringUtil.isEmptyOrNull(startOrgId)) {
            throw new ApplicationException("An Organization selection is required.");
        }

        if (StringUtil.isEmptyOrNull(providerType)) {
            throw new ApplicationException("A Provider selection is required.");
        }

        return microservice.getProvider(startOrgId, providerType);
    }

    public Organization saveOrgServiceProviders(Organization organization) {
        return microservice.saveOrgServiceProviders(organization);
    }

    public Organization saveOrganization(Organization organization) {
        Organization dbOrg = microservice.getOrganization(organization.getId());
        dbOrg.setName(organization.getName());
        dbOrg.nodeIdentifier = organization.nodeIdentifier;
        dbOrg.consumers.clear();
        dbOrg.consumers.addAll(organization.consumers);
        dbOrg.serviceProviderRefs.clear();
        dbOrg.serviceProviderRefs.addAll(organization.serviceProviderRefs);

        String errorMsgNoScope = "A consumer must have a scope.";
        String errorMsgNoProviderRef = "A consumer must have provider.";
        if (dbOrg.consumers != null && !dbOrg.consumers.isEmpty()) {
            dbOrg.consumers.forEach(consumer -> {
                if (Objects.isNull(consumer.scope)) {
                    throw new ApplicationException(errorMsgNoScope);
                }
                if (Objects.isNull(consumer.providerRef)) {
                    throw new ApplicationException(errorMsgNoProviderRef);
                }
            });
        }
        boolean duplicateChildIdentifiers = microservice.doesNodeIdentifierExistUnderParentOrganization(dbOrg.getId(),
                dbOrg.getParentId(), dbOrg.nodeIdentifier);
        if (duplicateChildIdentifiers && !StringUtil.isEmptyOrNull(organization.nodeIdentifier)) {
            throw new ValidationException("Child organizations cannot have the same identifier");
        }
        Organization updatedOrganization = microservice.saveOrganization(dbOrg);

        this.addOrganizationOptions(updatedOrganization);

        return updatedOrganization;
    }

    private boolean effectiveBusinessServicesUpdateNeeded(Organization organization) {
        boolean updateEffectiveServices = false;
        if (Objects.nonNull(organization.businessServices) && !organization.businessServices.isEmpty()) {
            Organization persistedOrganization = microservice.getOrganization(organization.getId());
            // if the business services are changed - update the effective business services
            if (Objects.isNull(persistedOrganization.businessServices) || persistedOrganization.businessServices.isEmpty()) {
                updateEffectiveServices = true;
            } else {
                List<BusinessServiceDefinitionRef> refs = persistedOrganization.businessServices.stream()
                        .filter(two -> organization.businessServices.stream()
                                .anyMatch(one -> one.getId().equalsIgnoreCase(two.getId()))).collect(Collectors.toList());
                if (refs.size() != organization.businessServices.size()) {
                    updateEffectiveServices = true;
                }
            }
        }
        return updateEffectiveServices;
    }

    private void addOrganizationOptions(Organization organization) {
        //  if (this.isDoDOrganization(organization.getId())) {  // Not sure why this was here. Commented 2/18/22
        List<ServiceProviderRef> serviceProviderRefs = organization.serviceProviderRefs;
        for (ServiceProviderRef serviceProviderRef : serviceProviderRefs) {
            switch (serviceProviderRef.name) {
                case "Customer":
                    assignBuyerToOrganization(organization);
                    break;
                case "Inventory":
                    assignInventorySystemToOrganization(organization);
                    break;
                case "Supplier":
                    assignSellerToOrganization(organization);
                    break;
                default:
                    // do nothing
                    break;
            }
        }

        //     }

    }

    private void assignBuyerToOrganization(Organization organization) {
        Buyer buyer = buyerService.getBuyerForNodeId(organization.getId());
        if (Objects.isNull(buyer)) {
            BuyerDTO buyerDTO = new BuyerDTO();
            buyerDTO.name = organization.getName() + '-' + organization.nodeIdentifier;
            buyerDTO.description = organization.getName() + '-' + organization.nodeIdentifier;
            buyerDTO.organizationRef = organization.getRef();
            buyerDTO.managedByNodeRef = getAncestorOrgOfOrgType(buyerDTO.organizationRef.id, OrganizationConstants.SITE_ORG_TYPE_ID).getRef();
            buyerService.saveBuyer(buyerDTO);
            orderService.createInternalReferenceConfig(buyerDTO);
        }
    }

    private void assignInventorySystemToOrganization(Organization organization) {
        String orgId = organization.getId();
        // TODO find the ancestor node and system that provides location service and remove Site type
        Organization parentOrg = this.getAncestorOrgOfOrgType(orgId, OrganizationConstants.SITE_ORG_TYPE_ID);
        if (Objects.isNull(parentOrg)) {
            throw new ApplicationException("A parent organization available for inventory location services cannot be found");

        }
        InventorySystem parentSystem = locationService.getInventorySystemByCurrentNodeId(parentOrg.getId());
        if (Objects.isNull(parentSystem)) {
            // create the parent and storage locations
            InventorySystem parentInventorySystem = new InventorySystem();
            parentInventorySystem.name = parentOrg.getName() + '-' + parentOrg.nodeIdentifier;
            parentInventorySystem.description = parentOrg.getName() + '-' + parentOrg.nodeIdentifier;
            parentInventorySystem.nodeRef = parentOrg.getRef();
            parentInventorySystem.systemType = ESystemType.STORAGE;
            parentSystem = locationService.createInventorySystem(true, parentInventorySystem);
        }


        InventorySystem inventorySystemExists = locationService.getInventorySystemByCurrentNodeId(orgId);
        // get the parent inventory system (site)
        if (Objects.isNull(inventorySystemExists) && !Objects.isNull(parentSystem)) {
            boolean isLogOrg = this.isLogOrganization(organization);
            InventorySystem inventorySystem = new InventorySystem();
            inventorySystem.name = organization.getName() + '-' + organization.nodeIdentifier;
            inventorySystem.description = organization.getName() + '-' + organization.nodeIdentifier;
            inventorySystem.nodeRef = organization.getRef();
            inventorySystem.systemType = isLogOrg ? ESystemType.LOG : ESystemType.CUSTOMER;
            inventorySystem.materialOwnershipType = isLogOrg ? EStockOwnership.LOGISTICS : EStockOwnership.CUSTOMER;
            inventorySystem.defaultLocationRef = parentSystem.defaultLocationRef;
            locationService.createInventorySystem(false, inventorySystem);
        }
    }

    private void assignSellerToOrganization(Organization organization) {
        Seller seller = sellerService.getSellerForOrganizationIdentifier(organization.getId());
        if (Objects.isNull(seller)) {
            // Need to differentiate LOG and CAI here.
            SellerType sellerType;
            sellerType = sellerService.getSellerTypeByType("LOG");
            Seller seller1 = new Seller();
            seller1.sellerName = organization.getName() + '-' + organization.nodeIdentifier;
            seller1.sellerTypeRef = sellerType.getRef();
            seller1.isExternal = false;
            seller1.organizationIdentifier = organization.getId();
            sellerService.saveSeller(seller1);
        }
    }


    // TODO remove when services are available to define a LOG organization
    private boolean isLogOrganization(Organization organization) {
        return StringUtil.doesStringContain(organization.getName(), "LOG", true);
    }


    public void deleteOrganization(String organizationId) {
        // TODO send a message to queue before removing then call delete from MDB on response(s)
        if (this.sendRemoveOrgMessageStub(organizationId)) {
            microservice.deleteOrganization("Called from UI", organizationId);
        }
    }

    private boolean sendRemoveOrgMessageStub(String organizationId) {
//      Maybe something like this:
//      create new Organization sync Wrapper
//      syncWrapper.action = OrganizationAction.DELETE;
//      syncWrapper.organizationRef = organization.getRef();
//      String transferObject = jsonUtil.serialize(syncWrapper);
//      jmsClient.sendRequest(transferObject, "removeOrgQueue");

        return true;

    }


    public Boolean refreshOrganizationTree() {
        return microservice.refreshOrganizationTree();
    }

    public List<Organization> findLogisticsDescendants(String orgId) {
        return microservice.findLogisticsDescendants(orgId);
    }

    public List<Organization> findOrganizationsByIdentifier(String searchString) {
        return microservice.findOrganizationsByIdentifier(searchString);
    }

    public String getOrganizationHierarchyAsString(String organizationId, String delimiter) {
        return microservice.getOrganizationHierarchyAsString(organizationId, delimiter);
    }

    public List<Organization> getScopeUsingAncestry(AncestryQuery ancestryQuery) {
        return microservice.getScopeUsingAncestry(ancestryQuery);
    }

    public List<OrganizationRef> getOrganizationRefsByIdList(List<String> organizationIds) {
        return microservice.getOrganizationRefsByIdList(organizationIds);
    }

    public List<String> getScopedOrganizationIdList(String startingOrganizationId) {
        return microservice.getScopedOrganizationIdList(startingOrganizationId);
    }

    public List<OrganizationType> findLowerNodeTypes(String organizationId) {
        return microservice.findLowerNodeTypes(organizationId);
    }

    public List<OrganizationType> getOrganizationTypesReduced() {
        return microservice.getOrganizationTypesReduced();
    }

    public List<DmlssHost> getDmlssHostList() {
        return microservice.getDmlssHostList();
    }

    public Organization createOrganization(String purpose, String parentId, Organization organization) {
        String errorMsgNoParent = "An organization must have a parent.";
        String errorNoAllowedChild = "There are no sub-organizations allowed here.";
        String errorOrganizationNameRequired = "Organizations must have a name.";

        if (StringUtil.isEmptyOrNull(parentId)) {
            // a parent organization is required, otherwise, we'll be spawning a new root node
            // and there is no provision for that at this time.
            throw new ApplicationException(errorMsgNoParent);
        }

        if (organization.getOrganizationTypeRef().getId() == null) {
            throw new ApplicationException(errorNoAllowedChild);
        }

        if (StringUtil.isEmptyOrNull(organization.getOrganizationIdentifier()) &&
                (organization.getOrganizationTypeRef().name.equalsIgnoreCase(OrganizationType.SITE_TYPE_NAME) ||
                        organization.getOrganizationTypeRef().name.equalsIgnoreCase(OrganizationType.DEPARTMENT_TYPE_NAME) ||
                        organization.getOrganizationTypeRef().name.equalsIgnoreCase(OrganizationType.CUSTOMER_TYPE_NAME))) {
            organization.nodeIdentifier = "TEMP";
        }

        if (StringUtil.isEmptyOrNull(organization.getName())) {
            throw new ApplicationException(errorOrganizationNameRequired);
        }

        boolean duplicateChildIdentifiers = microservice.doesNodeIdentifierExistUnderParentOrganization(null, parentId, organization.nodeIdentifier);
        if (duplicateChildIdentifiers && !StringUtil.isEmptyOrNull(organization.nodeIdentifier)) {
            throw new ValidationException("Child organizations cannot have the same identifier");
        }

        return microservice.createOrganization(purpose, parentId, organization);
    }

    public boolean areAllChildren(String parentId, List<String> possibleChildrenIds) {
        Organization org = microservice.getOrganization(parentId);

        boolean found = true;
        for (String possibleChildId : possibleChildrenIds) {
            if (!org.getChildIds().contains(possibleChildId)) {
                found = false;
                break;
            }
        }
        return found;
    }

    public DmlssHost getDmlssHostByDodaac(String dodaac) {
        return microservice.getDmlssHostByDodaac(dodaac);
    }

    public List<ServiceProvider> getServiceProvidersByRole(String roleId) {
        return microservice.getServiceProvidersByRole(roleId);
    }

    public List<OrganizationType> getAllowedChildOrgTypes(String organizationId) {
        return microservice.getAllowedChildOrgTypes(organizationId);
    }

    public Organization getAncestorOrgOfOrgType(String organizationId, String targetOrgTypeId) {
        return microservice.getAncestorOrgOfOrgType(organizationId, targetOrgTypeId);
    }

    public List<String> getOrganizationIdsAtAndBelow(String organizationId) {
        return microservice.getOrganizationIdsAtAndBelow(organizationId);
    }

    public List<String> getOrganizationIdsBelow(String organizationId) {
        return microservice.getOrganizationIdsBelow(organizationId);
    }

    public boolean isDoDOrganization(@NotNull String organizationId) {
        return microservice.isDoDOrganization(organizationId);
    }

    public List<RoleRef> getAllRolesAsRoleRef() {
        List<Role> allRoles = roleService.getAllRoles();
        List<RoleRef> allRoleRefs = new ArrayList<>();
        for (Role role : allRoles) {
            RoleRef roleRef = role.getRef();
            allRoleRefs.add(roleRef);
        }
        return allRoleRefs;
    }

    public void addEhrDmlssCustomers(List<EhrSiteCustomer> customers) {
        microservice.addUpdateDmlssCustomers(customers);
    }

    public List<EhrSiteCustomer> getCustomerOrgs() {
        return microservice.getCustomerOrgs();
    }

    public EhrSiteCustomer saveCustomerOrg(EhrSiteCustomer ehrSiteCustomer) {
        return microservice.saveCustomerOrg(ehrSiteCustomer);
    }

    public List<DmlssHost> getDmlssHosts() {
        return microservice.getDmlssHosts();
    }

    public DmlssHost getDmlssHostById(String id) {
        return microservice.getDmlssHostById(id);
    }

    public List<String> getOrgLabelsNotInDmlssHost() {
        return microservice.getOrgLabelsNotInDmlssHost();
    }

    public List<String> getOrganizationIdsByMilServiceIdAndType(String milServiceId, String type) {
        return microservice.getOrganizationIdsByMilServiceIdAndType(milServiceId, type);
    }

    public void deleteDmlssHost(String id) {
        microservice.deleteDmlssHost(id);
    }

    public void updateDmlssHostLastSyncTime(String dodaac, Date siteCatalogLastSyncTime) {
        microservice.updateDmlssHostLastSyncTime(dodaac, siteCatalogLastSyncTime);
    }

    public DmlssHost saveDmlssHost(DmlssHost dmlssHost) {
        return microservice.saveDmlssHost(dmlssHost);
    }

    public Boolean isSiteAndCustomerOrgIdValid(String dodaac, String customerOrgId) {
        return microservice.isSiteAndCustomerValid(dodaac, customerOrgId);
    }

    public List<EhrSiteCustomer> getEhrSiteCustomers(String type) {
        return microservice.getEhrSiteCustomers(type);
    }

    public EhrSiteCustomer findBySiteCustomerOrgId(String siteOrgId, String customerOrgId) {
        return microservice.findBySiteCustomerOrgId(siteOrgId, customerOrgId);
    }

    public void updateLastEquipmentDate(EhrSiteCustomer customer, Date updateDate) {
        microservice.updateLastEquipmentDate(customer, updateDate);
    }

    public void updateLastItemCatalogDate(EhrSiteCustomer siteCustomer, Date updateDate) {
        microservice.updateLastItemCatalogDate(siteCustomer, updateDate);
    }

    public List<EhrSiteCustomer> getItemMasterEnabledCustomerOrgs() {
        return microservice.getItemMasterEnabledCustomerOrgs();

    }

    public EhrSiteCustomer resetItemCatalogSyncDate(String id) {
        return microservice.resetItemCatalogSyncDate(id);
    }

    public EhrSiteCustomer resetEquipmentCatalogSyncDate(String id) {
        return microservice.resetEquipmentCatalogSyncDate(id);
    }

    public List<String> getNodeIdentifiersByScopeAndOrganizationType(String scopeNodeId, String organizationType) {
        return microservice.getNodeIdentifiersByScopeAndOrganizationType(scopeNodeId, organizationType);
    }

    public List<Organization> getOrganizationsByAncestry(String ancestry) {
        return microservice.getOrganizationsByAncestry(ancestry);
    }

    public List<String> getAllOrganizationIdentifiersAtOrBelow(String organizationId) {
        return microservice.getAllOrganizationIdentifiersAtOrBelow(organizationId);
    }

    public List<OrganizationType> getOrganizationTypesBelow(String organizationId, boolean realPropertyTypes) {
        return microservice.getOrganizationTypesBelow(organizationId, realPropertyTypes);
    }

    public Configuration addUpdateConfiguration(Configuration configuration) {
        return microservice.addUpdateConfiguration(configuration);
    }

    public Organization findByDmlssKey(String dmlssKey) {
        return microservice.findByDmlssKey(dmlssKey);
    }

    public Organization findByParentIdAndNodeIdentifier(String parentId, String nodeIdentifier) {
        return microservice.findByParentIdAndNodeIdentifier(parentId, nodeIdentifier);
    }

    public List<Organization> findByNodeTypeIdAndParentId(String nodeTypeId, String parentId) {
        return microservice.findByNodeTypeIdAndParentId(nodeTypeId, parentId);
    }

    public boolean hasRPFuncEnabled(List<OrganizationRef> orgRefs) {
        boolean isEnabled = false;
        if (!ListUtil.isEmpty(orgRefs)) {
            for (OrganizationRef orgRef : orgRefs) {
                if (!StringUtil.isEmptyOrNull(orgRef.nodeIdentifier)) {
                    DmlssHost dmlssHost = this.getDmlssHostByDodaac(orgRef.nodeIdentifier);
                    if (null == dmlssHost) {
                        isEnabled = true;
                    } else {
                        isEnabled = dmlssHost.isRPFuncEnabled;
                    }
                } else {
                    isEnabled = true;  // if nodeIdentifier doesn't have value, the node doesn't belong to dmlss
                }
                if (isEnabled) break;
            }
        }

        return isEnabled;
    }

    public boolean isNodeRPFuncEnabled(String nodeId) {
        OrganizationRef orgRef = getOrganizationRefById(nodeId);
        if (orgRef != null) {
            return hasRPFuncEnabled(Arrays.asList(orgRef));
        }

        return false;

    }

    public void setRPFuncFilterInSearch(SearchInput searchInput) {
        List<String> nodeIdentifiers = getOrgLabelsRPDisabledInDmlssHost();
        if (ListUtil.isEmpty(nodeIdentifiers)) {
            return;
        }

        if (searchInput == null) {
            searchInput = new SearchInput();
        }

        if (searchInput.searchCriteria == null) {
            searchInput.searchCriteria = new ArrayList<>();
        }

        SearchCriterion searchCriterion = new SearchCriterion();
        searchCriterion.propName = "nodeIdentifier";
        searchCriterion.method = SearchCriterion.SEARCH_METHOD_NOT_IN;
        searchCriterion.propValues = nodeIdentifiers.toArray();

        searchInput.searchCriteria.add(searchCriterion);
    }

    public List<String> getOrgLabelsRPDisabledInDmlssHost() {
        return microservice.getOrgLabelsRPDisabledInDmlssHost();
    }

    public List<OrganizationRef> getOrganizationRefByAgencyAndType(String targetTypeName) {
        return microservice.getOrganizationRefByAgencyAndType(targetTypeName, currentUserBT.getCurrentUser().profile.currentNodeRef.ancestry);
    }

    public List<OrganizationRef> getOrganizationRefByAgencyAndType(String targetTypeName, String ancestry) {
        return microservice.getOrganizationRefByAgencyAndType(targetTypeName, ancestry);
    }

    public Organization removeBusinessServiceDefinition(String organizationId, String businessServiceId) {
        return microservice.removeBusinessServiceDefinition(organizationId, businessServiceId);
    }

    Organization addBusinessServiceDefinition(String organizationId,
                                              BusinessServiceDefinitionRef businessService) {
        return microservice.addBusinessServiceDefinition(organizationId, businessService);
    }

    public Organization addUpdateBusinessServiceDefinitions(String organizationId, List<BusinessServiceDefinitionRef> businessServices) {
        return microservice.addUpdateBusinessServiceDefinitions(organizationId, businessServices);
    }

    public int updateEffectiveBusinessServiceDefinitions(String ancestorNodeId) {
        return microservice.updateEffectiveBusinessServiceDefinitions(ancestorNodeId);
    }

    public List<Organization> getOrganizationsWithBusinessServiceDefinition(String businessServiceDefinitionId) {
        return microservice.getOrganizationsWithBusinessServiceDefinition(businessServiceDefinitionId);
    }

    public boolean consumerHasProviderRef(String providerId) {
        return microservice.consumerHasProviderRef(providerId);
    }


    public boolean isRootOrDevOrganization(String nodeId) {
        return microservice.isRootOrDevOrganization(nodeId);
    }

    public List<Organization> getAllOrganizationsByNodeTypeIds(List<String> nodeTypeIds) {
        return microservice.getAllOrganizationsByNodeTypeIds(nodeTypeIds);
    }

    public List<OrganizationRef> getCurrentUserScopedOrganizationRefs() {
        String orgId = getCurrentUser().getRef().organizationRef.id;
        return microservice.getCurrentUserScopedOrganizationRefs(orgId);
    }

    public Organization addOrganizationConsumer(String organizationId, Consumer consumer) {
        Organization org = microservice.getOrganization(organizationId);
        if (Objects.isNull(org)) {
            throw new ApplicationException("Organization Not Found");
        } else if (microservice.consumerExistsAtOrganization(organizationId, consumer)) {
            throw new ApplicationException("Consumer already exists at organization");
        }
        return microservice.addOrganizationConsumer(organizationId, consumer);

    }

    public Organization addUpdateOrganizationMarketInfo(String organizationId,
                                                        MarketInfo marketInfo) {
        return microservice.addUpdateOrganizationMarketInfo(organizationId, marketInfo);
    }

    public FileManager uploadNodeImportFile(MultipartFormDataInput form) throws IOException {
        byte[] content;

        InputPart inputPart = multiPartFormUtil.getInputPart(form, "file");
        String uploadedFileName = multiPartFormUtil.getFileName(inputPart.getHeaders());

        InputStream inputStream = inputPart.getBody(InputStream.class, null);
        content = IOUtils.toByteArray(inputStream);

        if (!contentIsNodeImportSpreadsheet(content)) {
            throw new ApplicationException("File is not a valid Node Import (*.xlsx) File.");
        }

        Integer maxUploadSize = microservice.getMaxNodeImportAttachmentSize();
        if (content.length > maxUploadSize) {
            throw new ApplicationException("File size exceeds max size of " + maxUploadSize + " bytes");
        } else if (content.length <= 0) {
            throw new ApplicationException("File size is invalid. Make sure the file contains data.");
        }

        return fileManagerAdminService.uploadManaged(content, uploadedFileName);
    }

    protected boolean contentIsNodeImportSpreadsheet(byte[] content) {
        boolean isValidWorksheet = false;
        try {
            XSSFWorkbook workbook = openWorkbookFromByteArray(content);
            isValidWorksheet = true;
            workbook.close();
        } catch (IOException e) {
            isValidWorksheet = false;
        }
        return isValidWorksheet;
    }

    protected XSSFWorkbook openWorkbookFromByteArray(byte[] content) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(content);
        // This is used to avoid a zip bomb error
        ZipSecureFile.setMinInflateRatio(0);
        XSSFWorkbook workbook = new XSSFWorkbook(bais);
        return workbook;
    }

    public NodeImportStatus importNodeFile(Attachment nodeImportRequest, String purpose, String parentNodeTypeName) {
        File importFile = null;
        try {
            String tempDirectory = System.getProperty("java.io.tmpdir");

            byte[] fileContents = fileManagerAdminService
                    .getFileContentsAsPrimitiveByte(nodeImportRequest.fileRef.fileId);
            importFile = writeTempImportFile(nodeImportRequest.fileRef.uploadedFileName, tempDirectory, fileContents);

            return microservice.processImportFile(importFile.getAbsolutePath(), purpose, parentNodeTypeName, nodeImportRequest);
        } catch (ApplicationException | ClientErrorException | IOException ex) {
            String message = "ERROR in processImportRequest: " + ex.getMessage();
            logger.error("ERROR in processImportRequest");
            logger.error(ex);
            throw new ApplicationException(message, ex);
        }
    }

    protected File writeTempImportFile(String uploadedFileName, String tempDirectory, byte[] fileContents)
            throws IOException {

        uploadedFileName = uploadedFileName.replace("/", "-").replace("\\", "-");
        File file = File.createTempFile(uploadedFileName + ".", ".tmp", new File(tempDirectory));

        try (OutputStream outputStream = new FileOutputStream(file)) {
            outputStream.write(fileContents);
            outputStream.flush();
        }
        return file;
    }

    public Organization getOrganizationByTypeRefIdAndOrgName(String typeRefId, String name) {
        return microservice.getOrganizationByTypeRefIdAndOrgName(typeRefId, name);
    }

    public List<OrganizationRef> getOrganizationRefByTypeAndAncestryId(String targetTypeName, String ancestry) {
        return microservice.getOrganizationRefByTypeAndAncestryId(targetTypeName, ancestry);
    }

    public DmlssHost getDmlssHostByNodeId(String nodeId) {
        return microservice.getDmlssHostByNodeId(nodeId);
    }

    public Organization saveOrganizationMiscDetails(@NotNull String id, String newStationId, String newFacilitiesEnterpriseRegion) {

        if(StringUtil.isEmptyOrNull(newStationId)){
            newStationId = "";
        }

        if(StringUtil.isEmptyOrNull(newFacilitiesEnterpriseRegion)){
            newFacilitiesEnterpriseRegion = "";
        }

        return microservice.saveOrganizationMiscDetails(id, newStationId, newFacilitiesEnterpriseRegion);
    }

    public TreeChange moveOrganization(String purpose, String orgId, String newParentId) {
        return microservice.moveOrganization(purpose, orgId, newParentId);
    }

    public TreeVersion updateOrganizationTree(String purpose, List<TreeChangeRequest> changeRequests) {
        return microservice.updateOrganizationTree(purpose, changeRequests);
    }
}
