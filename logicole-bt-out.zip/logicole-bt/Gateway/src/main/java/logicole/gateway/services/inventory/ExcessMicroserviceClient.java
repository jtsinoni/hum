package logicole.gateway.services.inventory;

import logicole.apis.inventory.IExcessMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class ExcessMicroserviceClient extends MicroserviceClient<IExcessMicroserviceApi> {
    public ExcessMicroserviceClient() {
        super(IExcessMicroserviceApi.class, "logicole-inventory");
    }

    @Produces
    public IExcessMicroserviceApi getIExcessMicroserviceApi() {
        return createClient();
    }
}
