package logicole.gateway.services.spacemanagement;

import logicole.apis.space.ICOBieBackgroundRequestMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class COBieBackgroundRequestMicroserviceClient extends MicroserviceClient<ICOBieBackgroundRequestMicroserviceApi> {
    public COBieBackgroundRequestMicroserviceClient(){
        super(ICOBieBackgroundRequestMicroserviceApi.class, "logicole-space-management");
    }

    @Produces
    public ICOBieBackgroundRequestMicroserviceApi getMicroserviceApi() {
        return createClient();
    }
}
