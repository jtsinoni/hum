package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiCatalogMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiCatalogMicroserviceClient extends MicroserviceClient<IAbiCatalogMicroserviceApi> {
    public AbiCatalogMicroserviceClient() {
        super(IAbiCatalogMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiCatalogMicroserviceApi getABiCollectionService() {
        return createClient();
    }
}

