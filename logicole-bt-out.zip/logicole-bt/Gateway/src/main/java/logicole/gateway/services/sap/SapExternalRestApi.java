package logicole.gateway.services.sap;

import io.swagger.annotations.Api;
import logicole.common.datamodels.communications.ehr.HttpEndpointLogRecord;
import logicole.common.datamodels.communications.httpincomingwrapper.HttpIncomingWrapper;
import logicole.common.datamodels.communications.ordering.OrderObject;
import logicole.common.datamodels.communications.response.LogicoleQuickResponse;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.common.restserver.http.RequestUtil;
import logicole.gateway.rest.ExternalRestApi;
import logicole.gateway.services.communications.IncomingTrafficService;
import logicole.gateway.services.ehr.IRestLogger;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.Date;

@Api(tags = {"SapExternal"})
@ApplicationScoped
@Path("/sap/external")
public class SapExternalRestApi extends ExternalRestApi<SapExternalService> implements IRestLogger {
    @Inject
    private JSONUtil jsonUtil;
    @Inject
    private RequestUtil requestUtil;
    @Inject
    private IncomingTrafficService incomingTrafficService;

    @POST
    @Path("/acceptSapOrderObject")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public LogicoleQuickResponse acceptSapOrderObject(OrderObject orderObject) {
        return service.translateSapOrderObject(orderObject);
    }

    @POST
    @Path("/acceptDataFromSap")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public LogicoleQuickResponse acceptDataFromSap(HttpIncomingWrapper dataWrapper) {
        return service.acceptDataFromSap(dataWrapper);
    }

    @AroundInvoke
    public Object aroundRestMethods(InvocationContext ctx) {

        Object result = null;

        IRestLogger restLogger = getLogger();
        HttpEndpointLogRecord logRecord = new HttpEndpointLogRecord();

        try {
            restLogger.preCall(logRecord, ctx);

            result = ctx.proceed();

            restLogger.postCall(logRecord, result);

        } catch (Exception exception) {
            // FORTIFY NOTE: ctx.proceed() causes compile error
            // if java.lang.Exception is not caught here
            restLogger.exception(logRecord, exception);
            throw new ApplicationException(exception);

        } finally {
            restLogger.wrapUp(logRecord);
        }

        return result;
    }

    @Override
    public void preCall(HttpEndpointLogRecord logRecord, InvocationContext ctx) throws IOException {
        logRecord.requestUrl = (requestUtil.getUrl().toString());
        logRecord.pkiDn = service.getCurrentUser().profile.pkiDn;
        logRecord.actionDate = new Date();
        Object[] params = ctx.getParameters();

        if ((params != null) && (params.length > 0)) {
            Object request = ctx.getParameters()[0];
            String requestString = jsonUtil.serialize(request);
            logRecord.request = requestString;
            logRecord.requestSize = requestString.length();
        }
    }

    @Override
    public void postCall(HttpEndpointLogRecord logRecord, Object result) throws IOException {
        String response = jsonUtil.serialize(result);
        logRecord.httpResponseCode = 200;

        if (response != null) {
            logRecord.response = response;
            logRecord.responseSize = response.length();
        }
    }

    @Override
    public void exception(HttpEndpointLogRecord logRecord, Exception exception) {
        logRecord.errorMessage = StringUtil.getExceptionText(exception);
        logRecord.httpResponseCode = 500;
    }

    @Override
    public void wrapUp(HttpEndpointLogRecord logRecord) {
        incomingTrafficService.insertIncomingTrafficRecord(logRecord);
    }

    public IRestLogger getLogger() {
        return this;
    }

}
