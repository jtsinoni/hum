package logicole.gateway.services.slep;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import logicole.apis.slep.ISlepMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;
import logicole.gateway.rest.TokenHeaderRequestFilter;

@ApplicationScoped
public class SlepMicroserviceClient extends MicroserviceClient<ISlepMicroserviceApi>{

	@Inject
	private SlepHeaderRequestFilter slepFilter;
	 
	public SlepMicroserviceClient() {
        super(ISlepMicroserviceApi.class, "logicole-slep");
    }

	@Produces
    public ISlepMicroserviceApi getISlepMicroserviceApi() {
        return createClient();
    }
	
    protected ResteasyWebTarget buildTarget() {
    	ResteasyWebTarget target = super.buildTarget();
        target.register(slepFilter);
        return target;
    }
	
}
