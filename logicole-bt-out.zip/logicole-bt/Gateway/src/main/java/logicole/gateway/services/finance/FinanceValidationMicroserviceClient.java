package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceValidationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class FinanceValidationMicroserviceClient extends MicroserviceClient<IFinanceValidationMicroserviceApi> {
    public FinanceValidationMicroserviceClient(){
        super(IFinanceValidationMicroserviceApi.class, "logicole-finance");
    }

    @Produces
    public IFinanceValidationMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
