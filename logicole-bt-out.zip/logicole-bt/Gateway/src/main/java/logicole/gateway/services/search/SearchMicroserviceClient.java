package logicole.gateway.services.search;

import logicole.apis.search.ISearchMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class SearchMicroserviceClient extends MicroserviceClient<ISearchMicroserviceApi> {
    public SearchMicroserviceClient() {
        super(ISearchMicroserviceApi.class, "logicole-search");
    }

    @Produces
    public ISearchMicroserviceApi getISearchMicroserviceApi() {
        return createClient();
    }

}
