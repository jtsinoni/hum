package logicole.gateway.services.order;

import io.swagger.annotations.Api;
import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.FundingNodeChild;
import logicole.common.datamodels.finance.ProcessingBalance;
import logicole.common.datamodels.finance.output.AuthorizedNode;
import logicole.common.datamodels.general.Address;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.buyer.BuyerDTO;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountDTO;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountSaveAttemptResponse;
import logicole.common.datamodels.sale.seller.CustomerContractNumberForPrimeVendorResponse;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.FundingNodeValidationException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Buyer"})
@ApplicationScoped
@Path("/buyer")
public class BuyerRestApi extends ExternalRestApi<BuyerService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getBuyerAuthorizedNodes")
    public List<AuthorizedNode> getBuyerAuthorizedNodes(@QueryParam("id") String buyerId) { return service.getBuyerAuthorizedNodes(buyerId);
    }

    @GET
    @Path("/getMyBuyerList")
    public List<BuyerDTO> getMyBuyerList() {
        return service.getMyBuyerList();
    }

    @GET
    @Path("/getBuyerById")
    public BuyerDTO getBuyerById(@QueryParam("id") String buyerId) {
        return service.getBuyerById(buyerId);
    }

    @POST
    @Path("/saveBuyer")
    public BuyerDTO saveBuyer(BuyerDTO buyerDTO) {
        return service.saveBuyer(buyerDTO);
    }

    @GET
    @Path("/deleteBuyer")
    public BuyerDTO deleteBuyer(@QueryParam("id") String buyerId) {
        return service.deleteBuyer(buyerId);
    }

    @GET
    @Path("/getBuyersForNode")
    public List<Buyer> getBuyersForNode(@QueryParam("nodeId") String nodeId) {
        return service.getBuyersForNode(nodeId);
    }

    @GET
    @Path("/getBuyerSellerAccountList")
    public List<BuyerSellerAccountDTO> getBuyerSellerAccountList() {
        return service.getBuyerSellerAccountList();
    }

    @GET
    @Path("/getBuyerSellerAccountListForOrganization")
    public List<BuyerSellerAccountDTO> getBuyerSellerAccountListForOrganization(@QueryParam("organizationId") String organizationId) {
        return service.getBuyerSellerAccountListForOrganization(organizationId);
    }

    @POST
    @Path("/saveBuyerSellerAccount")
    public BuyerSellerAccountDTO saveBuyerSellerAccount(BuyerSellerAccountDTO buyerSellerAccount) {
        return service.saveBuyerSellerAccount(buyerSellerAccount);
    }

    @POST
    @Path("/deleteBuyerSellerAccount")
    public List<BuyerSellerAccountDTO> deleteBuyerSellerAccount(BuyerSellerAccountDTO buyerSellerAccount) {
        return service.deleteBuyerSellerAccount(buyerSellerAccount);
    }
    @POST
    @Path("/checkOkToSaveBuyerSellerAccount")
    public BuyerSellerAccountSaveAttemptResponse getOkToSaveBuyerSellerAccount(BuyerSellerAccountDTO buyerSellerAccount) {
        return service.checkOkToSaveBuyerSellerAccount(buyerSellerAccount);
    }

    @POST
    @Path("/getPrimeVendorCustomerContractByBuyerIdAndSellerId")
    public CustomerContractNumberForPrimeVendorResponse getPrimeVendorCustomerContractByBuyerIdAndSellerId(@QueryParam("buyerId") String buyerId, @QueryParam("sellerId") String sellerId) {
        return service.getPrimeVendorCustomerContractByBuyerIdAndSellerId(buyerId, sellerId);
    }

    @POST
    @Path("/saveBuyersShippingAddress")
    public Buyer saveBuyersShippingAddress(Address address){
        return service.saveBuyersShippingAddress(address);
    }


    @GET
    @Path("/getBuyerForOrganization")
    public BuyerDTO getBuyerForOrganization(@QueryParam("organizationId") String organizationId) {
        return service.getBuyerForOrganization(organizationId);
    }

    @GET
    @Path("/getFundingNodesByOrgAndBuyer")
    public List<FundingNode> getFundingNodesByOrgAndBuyer(@QueryParam("orgId") String orgId, @QueryParam("buyerId") String buyerId) {
        return service.getFundingNodesByOrgAndBuyer(orgId, buyerId);
    }

    @POST
    @Path("/createFundingNodeChild")
    public ProcessingBalance createFundingNodeChild(@QueryParam("id") String id, FundingNodeChild node)
            throws FundingNodeValidationException {
        return service.createFundingNodeChild(id, node);
    }
}

