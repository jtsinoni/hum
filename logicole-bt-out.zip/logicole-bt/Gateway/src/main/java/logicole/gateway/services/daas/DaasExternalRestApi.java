package logicole.gateway.services.daas;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import logicole.common.datamodels.communications.ehr.HttpEndpointLogRecord;
import logicole.common.datamodels.communications.httpincomingwrapper.HttpIncomingWrapper;
import logicole.common.datamodels.communications.pricelookup.InboundTranslationResponse;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.common.restserver.http.RequestUtil;
import logicole.gateway.rest.ExternalRestApi;
import logicole.gateway.services.communications.IncomingTrafficService;
import logicole.gateway.services.ehr.IRestLogger;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.Date;

@Api(tags = {"DaasExternal"})
@ApplicationScoped
@Path("/daas/external")
public class DaasExternalRestApi extends ExternalRestApi<DaasExternalService> implements IRestLogger {
    @Inject
    private JSONUtil jsonUtil;
    @Inject
    private RequestUtil requestUtil;
    @Inject
    private IncomingTrafficService incomingTrafficService;

    @POST
    @Path("/acceptDataFromDaas")
    @ApiOperation(value = "Verify data from DAAS. Valid data will be queued to be translated.")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
    @Produces(MediaType.TEXT_PLAIN)
    public Response acceptDataFromDaas(HttpIncomingWrapper daasData) {
        String validationResult = service.acceptDataFromDaas(daasData);
        Response.ResponseBuilder response;

        if (StringUtil.isEmptyOrNull(validationResult) || StringUtil.safeToUppercase(validationResult).contains("REJECTED")) {
            response = Response.status(Response.Status.UNSUPPORTED_MEDIA_TYPE).entity(validationResult);
        } else {
            response = Response.ok().type(MediaType.TEXT_PLAIN_TYPE).entity(validationResult);
        }

        return response.build();
    }

    @POST
    @Path("/sendData")
    @ApiOperation(value = "Used to accept data from the PT testing page and process it into LogiCole.")
    @Consumes({MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
    @Produces(MediaType.APPLICATION_JSON)
    public Response sendData(HttpIncomingWrapper daasData) {
        InboundTranslationResponse validationResult = service.sendData(daasData);
        Response.ResponseBuilder response;

        response = Response.ok().type(MediaType.APPLICATION_JSON).entity(validationResult);

        return response.build();
    }

    @POST
    @Path("/acceptEdi")
    @ApiOperation(value = "Verify an EDI document. Valid EDI documents will be queued to be translated.")
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.TEXT_PLAIN)
    public Response acceptDaasEdi(String ediData) {
        String validationResult = service.acceptDaasEdi(ediData);
        Response.ResponseBuilder response;

        if (StringUtil.isEmptyOrNull(validationResult) || StringUtil.safeToUppercase(validationResult).contains("REJECTED")) {
            response = Response.status(Response.Status.UNSUPPORTED_MEDIA_TYPE).entity(validationResult);
        } else {
            response = Response.ok().type(MediaType.TEXT_PLAIN_TYPE).entity(validationResult);
        }

        return response.build();
    }


    @AroundInvoke
    public Object aroundRestMethods(InvocationContext ctx) {

        Object result = null;

        IRestLogger restLogger = getLogger();
        HttpEndpointLogRecord logRecord = new HttpEndpointLogRecord();

        try {
            restLogger.preCall(logRecord, ctx);

            result = ctx.proceed();

            restLogger.postCall(logRecord, result);

        } catch (Exception exception) {
            // FORTIFY NOTE: ctx.proceed() causes compile error
            // if java.lang.Exception is not caught here
            restLogger.exception(logRecord, exception);
            throw new ApplicationException(exception);

        } finally {
            restLogger.wrapUp(logRecord);
        }

        return result;
    }

    @Override
    public void preCall(HttpEndpointLogRecord logRecord, InvocationContext ctx) throws IOException {
        String requestString;
        logRecord.requestUrl = (requestUtil.getUrl().toString());
        logRecord.pkiDn = service.getCurrentUser().profile.pkiDn;
        logRecord.actionDate = new Date();
        Object[] params = ctx.getParameters();

        if ((params != null) && (params.length > 0)) {
            Object request = ctx.getParameters()[0];

            if (request instanceof HttpIncomingWrapper) {
                requestString = jsonUtil.serialize(request);
            } else {
                requestString = request.toString();
            }

            logRecord.request = requestString;
            logRecord.requestSize = requestString.length();
        }
    }

    @Override
    public void postCall(HttpEndpointLogRecord logRecord, Object result) throws IOException {
        String response = null;

        if (result instanceof Response) {
            response = ((Response) result).getEntity().toString();
            logRecord.httpResponseCode = ((Response) result).getStatus();
        } else {
            response = result.toString();
            logRecord.httpResponseCode = 200;
        }

        if (response != null) {
            logRecord.response = response;
            logRecord.responseSize = response.length();
        }
    }

    @Override
    public void exception(HttpEndpointLogRecord logRecord, Exception exception) {
        logRecord.errorMessage = StringUtil.getExceptionText(exception);
        logRecord.httpResponseCode = 500;
    }

    @Override
    public void wrapUp(HttpEndpointLogRecord logRecord) {
        incomingTrafficService.insertIncomingTrafficRecord(logRecord);
    }

    public IRestLogger getLogger() {
        return this;
    }

}
