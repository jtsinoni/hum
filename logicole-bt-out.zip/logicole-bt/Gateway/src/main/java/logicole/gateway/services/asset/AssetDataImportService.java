package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetDataImportMicroserviceApi;
import logicole.common.crossservice.util.PersistedEntityUtil;
import logicole.common.datamodels.DataUploadObject;
import logicole.common.datamodels.asset.maintenance.procedure.AuthoritativeProcedure;
import logicole.common.datamodels.filemanager.CommonUploadedFile;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.notification.ApplicationNotification;
import logicole.common.datamodels.notification.ENotificationType;
import logicole.common.datamodels.system.ApplicationNotificationWrapper;
import logicole.common.datamodels.system.AuthoritativeSourceRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.constants.StringConstants;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.jms.JmsClient;
import logicole.common.general.util.DateUtil;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.system.NotificationService;
import logicole.gateway.services.system.SystemService;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

@ApplicationScoped
public class AssetDataImportService extends BaseGatewayService<IAssetDataImportMicroserviceApi> {

    @Inject
    private JmsClient jmsClient;

    @Inject
    private JSONUtil jsonUtil;

    @Inject
    private PersistedEntityUtil persistedEntityUtil;

    @Inject
    private NotificationAccumulator notificationAccumulator;

    @Inject
    protected AssetMaintenanceProcedureService assetMaintenanceProcedureService;

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    NotificationService notificationService;

    @Inject
    SystemService systemService;

    public AssetDataImportService() {
        super("Asset");
    }

    private Integer maxUploadSize;

    private static final String[] AUTHORITATIVE_DATA_PROPERTIES = {"procedureIdentifier", "serviceSpecificMaint", "frequency",
            "facilitySystem", "facilitySubsystem", "assemblyCategory", "nomenclature", "estimatedLaborHours", "tasks",
            "safetyPrecautions", "toolsAndMateriel", "agencyName", "accreditationParagraph",
            "accreditationReference", "procedureType", "maintDriverAgency", "maintDriver", "maintDriverPara", "occupancyType",
            "specialtyShop", "ipiCandidate", "ipiNotes"};

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public List<AuthoritativeSourceRef> getAllAuthoritativeSourceRefs() {
        return systemService.getAllAuthoritativeSourceRefs();
    }

    public boolean isAuthoritativeFileType(String fileType) {
        boolean retVal = false;
        List<AuthoritativeSourceRef> authoritativeSourceRefs = getAllAuthoritativeSourceRefs();
        for (AuthoritativeSourceRef authoritativeSourceRef : authoritativeSourceRefs) {
            if (authoritativeSourceRef.code.equalsIgnoreCase(fileType.trim())) {
                retVal = true;
                break;
            }
        }
        return retVal;
    }

    public String importFile(String fileType, MultipartFormDataInput form) throws IOException {
        Integer maxUploadSize = getMaxUploadSize();
        if (StringUtil.isEmptyOrNull(fileType) ||
                fileType.equals(StringConstants.UNDEFINED)) {
            throw new ApplicationException(
                    String.format("No valid file type defined. Entered value %s not valid.", fileType));
        }
        FileManager fileDetails = fileManagerAdminService.uploadManaged(form, maxUploadSize);
        String fileId = fileDetails.getId();
        DataUploadObject data = new DataUploadObject();
        data.fileType = fileType;
        data.data = fileId;
        UserProfile pro = this.getCurrentUser().profile;
        data.submitter = pro;
        data.usersToNotify.add(pro);

        String loadObject = jsonUtil.serialize(data);

        String returnMessage;
        if (isAuthoritativeFileType(fileType)) {
            jmsClient.sendTextMessageToQueue(loadObject, "AssetDataImport_Request", "AuthoritativeProcedure", null);
            returnMessage = "File was successfully uploaded - " + fileType;
        } else {
            returnMessage = "Non-authoritative file type - " + fileType + ": File not uploaded";
        }

        return returnMessage;
    }

    public Integer getMaxUploadSize() {
        if (maxUploadSize == null) {
            maxUploadSize = fileManagerAdminService.getMaxPostSize();
        }
        return maxUploadSize;
    }

    public List<ApplicationNotification> processAuthoritativeMaintenanceProcedures(String authoritativeSourceCode, DataUploadObject dataUploadObject)
            throws IOException, NoSuchFieldException, IllegalAccessException {

        AuthoritativeSourceRef authoritativeSourceRef = systemService.getAuthoritativeSourceRefByCode(authoritativeSourceCode);
        if (authoritativeSourceRef == null) {
            throw new ApplicationException(
                    String.format(
                            "Unable to find authoritativeSourceRef corresponding to code %s", authoritativeSourceCode));
        }

        CommonUploadedFile commonUploadedFile = fileManagerAdminService.download(dataUploadObject.data);

        try (FileInputStream fileInputStream = new FileInputStream(commonUploadedFile.getFile())) {
            byte[] fileByteData = new byte[fileInputStream.available()];
            int bytesRead = fileInputStream.read(fileByteData);

            if (bytesRead == -1) {
                throw new IOException("An error ocurred reading the file input stream.");
            }

            String fileData = new String(fileByteData);

            String[] tokens = fileData.split("\\n");

            for (int i = 1; i < tokens.length; i++) {
                String token = tokens[i];
                AuthoritativeProcedure authoritativeProcedure = new AuthoritativeProcedure();
                authoritativeProcedure.authoritativeSourceRef = authoritativeSourceRef;
                String[] nvPairs = token.split("\\|");
                jsonUtil.moveDataToObject(nvPairs, authoritativeProcedure, AUTHORITATIVE_DATA_PROPERTIES, AuthoritativeProcedure.class, false);
                try {
                    List<String> errors = assetMaintenanceProcedureService.migrateAuthoritativeProcedure(authoritativeProcedure);
                    notificationAccumulator.addErrors(errors);
                } catch (ApplicationException e) {
                    String msg = String.format("Procedure load %s failed - %s.  ", authoritativeProcedure.procedureIdentifier, e.getMessage());
                    notificationAccumulator.addError(msg);
                }
            }
        }

        if (notificationAccumulator.hasErrors()) {
            UserProfile pro = dataUploadObject.submitter;
            List<UserProfile> usersToNotify = new ArrayList<>();
            usersToNotify.add(pro);
            sendNotification(dataUploadObject.usersToNotify, pro, ENotificationType.ASSET_STAGING_LOAD_COMPLETE,
                    new Date(), notificationAccumulator.getTotalErrorCount(), buildNotificationData(dataUploadObject.submitter, dataUploadObject.fileType));
        }
        return notificationAccumulator.getNotifications();
    }

    private Map<String, String> buildNotificationData(UserProfile profile, String fileType) {

        Map<String, String> map = new HashMap<>();
        map.put("FILE_TYPE", fileType);
        map.put("USER_NAME", profile.getFullName());

        map.put("CREATED_DATE", DateUtil.getFriendlyDateString(new Date()));
        return map;
    }

    private void sendNotification(List<UserProfile> usersToNotify, UserProfile submitter, ENotificationType ntype, Date opStartTime,
                                  int errorCount, Map<String, String> notificationData) throws IOException {

        ApplicationNotificationWrapper wrapper = new ApplicationNotificationWrapper();
        wrapper.usersToNotify.addAll(usersToNotify);
        wrapper.notificationType = ntype;
        wrapper.errorCount = errorCount;
        wrapper.opStartTime = opStartTime;
        wrapper.messageData = notificationData;
        wrapper.submitterProfile = submitter;

        wrapper.emailAddresses = notificationService.findEmailAddressesToNotify(usersToNotify);
        wrapper.applicationNotificationIds = persistedEntityUtil.getIds(usersToNotify);

        wrapper = microservice.getAssetNotifications(wrapper);

        notificationService.sendEmail(wrapper.emailMessage);
        notificationService.createNotification(wrapper.notification);
    }

}
