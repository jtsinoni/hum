package logicole.gateway.services.search;

import logicole.apis.search.ISearchMicroserviceApi;
import logicole.common.datamodels.search.DmlesSearchResponse;
import logicole.common.datamodels.search.request.DmlesSearchRequest;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import java.io.IOException;

@ApplicationScoped
public class SearchService extends BaseGatewayService<ISearchMicroserviceApi> {

    public SearchService() {
        super("Search");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public String getSearchResults(DmlesSearchRequest dmlesSearchRequest) throws IOException, ApplicationException {
        return microservice.getSearchResults(dmlesSearchRequest);
    }

    public DmlesSearchResponse getSearchResponse(DmlesSearchRequest dmlesSearchRequest) throws IOException, ApplicationException {
        return microservice.getSearchResponse(dmlesSearchRequest);
    }

}
