package logicole.gateway.services.receipt;

import logicole.apis.receipt.IDueInMicroserviceApi;
import logicole.apis.receipt.IReceiptMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class DueInMicroserviceClient extends MicroserviceClient<IDueInMicroserviceApi> {
    public DueInMicroserviceClient(){
        super(IDueInMicroserviceApi.class, "logicole-receipt");
    }

    @Produces
    public IDueInMicroserviceApi getIDueInMicroserviceApi() {
        return createClient();
    }

}
