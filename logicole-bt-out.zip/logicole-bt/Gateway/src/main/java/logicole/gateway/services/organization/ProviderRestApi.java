package logicole.gateway.services.organization;

import io.swagger.annotations.Api;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.Provider;
import logicole.common.datamodels.organization.ProviderRef;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Provider"})
@ApplicationScoped
@Path("/provider")
public class ProviderRestApi extends ExternalRestApi<ProviderService> {

    @GET
    @Path("/findProviderById")
    public Provider findProviderById(@QueryParam("id") String id) {
        return service.findProviderById(id);
    }

    @GET
    @Path("/getProviderData")
    public <T> T getProviderData(@QueryParam("startNode") String startNode, @QueryParam("providerType") String providerType) {
        return service.getProviderData(startNode, providerType);
    }

    @GET
    @Path("/getAllProviders")
    public List<Provider> getAllProviders() {
        return service.getAllProviders();
    }

    @GET
    @Path("/getResponsibleOrganizationRef")
    public OrganizationRef getResponsibleOrganizationRef(@QueryParam("startOrgId") String startOrgId, @QueryParam("providerType") String providerType) {
        return service.getResponsibleOrganizationRef(startOrgId, providerType);
    }

    @GET
    @Path("/getFinancialServiceProviders")
    public List<Provider> getFinancialServiceProviders() {
        return service.getFinancialServiceProviders();
    }

    @POST
    @Path("/saveProvider")
    public Provider saveProvider(Provider provider) {
        return service.saveProvider(provider);
    }

    @POST
    @Path("/deleteProvider")
    public void deleteProvider(String providerId) {
        service.deleteProvider(providerId);
    }

    @GET
    @Path("/getProviderTypes")
    public List<ProviderType> getProviderTypes() {
        return service.getProviderTypes();
    }

    @GET
    @Path("/getProviderRefsByType")
    public List<ProviderRef> getProviderRefsByType(@QueryParam("providerType") String providerType) {
        return service.getProviderRefsByType(providerType);
    }
}
