package logicole.gateway.services.ehr;

import logicole.common.datamodels.communications.ehr.HttpEndpointLogRecord;

import java.io.IOException;
import javax.interceptor.InvocationContext;

public interface IRestLogger {
    void preCall(HttpEndpointLogRecord logRecord, InvocationContext ctx) throws IOException;

    void postCall(HttpEndpointLogRecord logRecord, Object result) throws IOException;

    void exception(HttpEndpointLogRecord logRecord, Exception exception);

    void wrapUp(HttpEndpointLogRecord logRecord);
}
