package logicole.gateway.services.order;

import logicole.apis.order.IBuyerMicroserviceApi;
import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.FundingNodeChild;
import logicole.common.datamodels.finance.ProcessingBalance;
import logicole.common.datamodels.finance.output.AuthorizedNode;
import logicole.common.datamodels.general.Address;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.buyer.BuyerDTO;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.sale.seller.BuyerSellerAccount;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountDTO;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountSaveAttemptResponse;
import logicole.common.datamodels.sale.seller.CustomerContract;
import logicole.common.datamodels.sale.seller.CustomerContractDTO;
import logicole.common.datamodels.sale.seller.CustomerContractNumberForPrimeVendorResponse;
import logicole.common.datamodels.sale.seller.Seller;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.finance.FinanceAdminService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.sale.SellerService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static logicole.common.general.util.DateUtil.localDateFromDate;


@ApplicationScoped
public class BuyerService extends BaseGatewayService<IBuyerMicroserviceApi> {
    @Inject
    protected BuyerService buyerService;

    @Inject
    protected FinanceAdminService financeAdminService;

    @Inject
    private OrganizationService organizationNodeService;

    @Inject
    protected SellerService sellerService;

    public BuyerService() {
        super("Buyer");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }


    public List<BuyerDTO> getMyBuyerList() {
        List<Buyer> buyers = microservice.getMyBuyerList();
        List<BuyerDTO> buyerDtos = new ArrayList<>();
        for (Buyer buyer : buyers) {
            BuyerDTO buyerDTO = getBuyerDTOFromBuyer(buyer);
            buyerDtos.add(buyerDTO);
        }
        return buyerDtos;
    }

    public Buyer getBuyerByBuyerId(String id){
        return  microservice.getBuyerById(id);
    }

    public List<AuthorizedNode> getBuyerAuthorizedNodes(String buyerId) { return financeAdminService.getAuthorizedNodes(buyerId); }

    public BuyerDTO getBuyerById(String id) {
        Buyer buyer = microservice.getBuyerById(id);
        return getBuyerDTOFromBuyer(buyer);
    }

    public BuyerDTO saveBuyer(BuyerDTO buyerDTO) {

        if (buyerDTO.managedByNodeRef == null || StringUtil.isEmptyOrNull(buyerDTO.managedByNodeRef.id)) {
            Organization siteOrg = organizationNodeService.getAncestorOrgOfOrgType(buyerDTO.organizationRef.id, OrganizationConstants.SITE_ORG_TYPE_ID);
            buyerDTO.managedByNodeRef = siteOrg.getRef();
        }

        Buyer buyer = this.getBuyerFromDTO(buyerDTO);
        Buyer savedBuyer = microservice.saveBuyer(buyer);
        return getBuyerDTOFromBuyer(savedBuyer);
    }

    public BuyerDTO deleteBuyer(String id) {
        Buyer deletedBuyer = microservice.deleteBuyer(id);
        return getBuyerDTOFromBuyer(deletedBuyer);
    }

    private Buyer getBuyerFromDTO(BuyerDTO buyerDTO) {
        Buyer buyer = new Buyer();
        buyer.setId(buyerDTO.id);
        buyer.name = buyerDTO.name;
        buyer.description = buyerDTO.description;
        buyer.isAutoReceipts = buyerDTO.isAutoReceipts;
        buyer.isVerifyOrders = buyerDTO.isVerifyOrders;
        buyer.isIssueIndicator = buyerDTO.isIssueIndicator;
        buyer.isRetired = buyerDTO.isRetired;
        buyer.drugEnforcementData = buyerDTO.drugEnforcementData;
        buyer.acceptedDocumentType = buyerDTO.acceptedDocumentType;
        buyer.maxOrderLimit = buyerDTO.maxOrderLimit;
        buyer.nodeRef = buyerDTO.organizationRef;
        buyer.managedByNodeRef = buyerDTO.managedByNodeRef;
        buyer.Address = buyerDTO.Address;
        buyer.Contact = buyerDTO.Contact;
        buyer.costCenter = buyerDTO.costCenter;
        buyer.adviceCodeRef = buyerDTO.adviceCodeRef;
        buyer.demandCodeRef = buyerDTO.demandCodeRef;
        return buyer;
    }

    private BuyerDTO getBuyerDTOFromBuyer(Buyer buyer) {
        BuyerDTO buyerDTO = new BuyerDTO(buyer);
        Organization organization = organizationNodeService.getOrganization(buyer.nodeRef.id);
        if (organization != null && !Objects.isNull(organization.milServiceId) && organization.milServiceId.equalsIgnoreCase("DA")) {
            buyerDTO.isCostCenterRequired = true;
        }
        if (organization != null) {
            buyerDTO.level = organization.getOrganizationTypeRef().name;
        }
        buyerDTO.hierarchy = organizationNodeService.getOrganizationHierarchyAsString(buyer.nodeRef.id, " / ");
        return buyerDTO;
    }

    public Buyer getBuyerForNodeId(String nodeId) {
        return microservice.getBuyerForNodeId(nodeId);
    }

    public List<Buyer> getBuyersForNode(String nodeId) {
        List<String> nodes = organizationNodeService.getOrganizationIdsBelow(nodeId);
        return microservice.getBuyersForOrganizationIds(nodes);
    }

    public List<BuyerSellerAccountDTO> getBuyerSellerAccountList() {
        return getBuyerSellerAccountListForOrganization(currentUserBT.getCurrentNodeId());
    }

    public List<BuyerSellerAccountDTO> getBuyerSellerAccountListForOrganization(String organizationId) {
        List<BuyerSellerAccountDTO> accounts = new ArrayList<>();
        Buyer buyer = getBuyerForNodeId(organizationId);
        accounts = sellerService.getBuyerSellerAccountListByBuyerId(buyer.getId());
        for (BuyerSellerAccountDTO account : accounts) {
            account.organization = buyer.nodeRef.name;
            account.organizationId = buyer.nodeRef.id;
        }
        return accounts;
    }

    public  BuyerSellerAccountDTO saveBuyerSellerAccount(BuyerSellerAccountDTO buyerAccount) {
        BuyerSellerAccountDTO savedAccount = sellerService.saveBuyerSellerAccount(buyerAccount);
        savedAccount.organization = buyerAccount.organization;
        savedAccount.organizationId = buyerAccount.organizationId;

        return savedAccount;
    }

    public List<BuyerSellerAccountDTO> deleteBuyerSellerAccount(BuyerSellerAccountDTO buyerAccount) {
        return sellerService.deleteBuyerSellerAccount(buyerAccount);
    }

    public BuyerSellerAccountSaveAttemptResponse checkOkToSaveBuyerSellerAccount(BuyerSellerAccountDTO buyerAccount) {
        Buyer buyer = buyerService.getBuyerByBuyerId(buyerAccount.buyerId);
        Seller seller = sellerService.getSellerById(buyerAccount.sellerId);
        BuyerSellerAccount bsAccount = sellerService.getBuyerSellerAccountBySellerAndBuyerId(buyer.getId(), seller.getId());
        if (bsAccount != null) {
            throw new ApplicationException("Account already exists for this Buyer/Supplier.");
        }
        return checkPrimeVendorContract(buyer, seller);
    }

    public CustomerContractNumberForPrimeVendorResponse getPrimeVendorCustomerContractByBuyerIdAndSellerId(String buyerId, String sellerId) {
        Buyer buyer = buyerService.getBuyerByBuyerId(buyerId);
        Seller seller = sellerService.getSellerById(sellerId);
        return this.getPrimeVendorContract(buyer, seller);
    }

    private BuyerSellerAccountSaveAttemptResponse checkPrimeVendorContract(Buyer buyer, Seller seller) {
        BuyerSellerAccountSaveAttemptResponse response = new BuyerSellerAccountSaveAttemptResponse(false, null, null, seller);
        if (seller.sellerTypeOrderConfiguration.needCustomerContract) {
            List<CustomerContract> customerContracts =
                    sellerService.getCustomerContractListForPrimeVendorSeller(seller.primeVendorCd, buyer.managedByNodeRef.nodeIdentifier, buyer.nodeRef.nodeIdentifier);
            if (customerContracts == null || customerContracts.isEmpty()) {
                throw new ApplicationException("No contract was found for this Supplier");
            } else {
                Date currentDate = new Date();
                for (CustomerContract contract : customerContracts) {
                    CustomerContractDTO customerToReturn = new CustomerContractDTO(contract);
                    if (!currentDate.before(customerToReturn.customerOrderEffectiveDate) && !currentDate.after(customerToReturn.customerOrderExpirationDate)) {
                        response.okToSave = true;
                        response.customerContract = customerToReturn;
                        break;
                    }
                }
                if (response.customerContract == null) {
                    throw new ApplicationException("No valid contract was found for this Supplier.");
                }
            }
        } else {
            response.okToSave = true;
        }
        return response;
    }

    private CustomerContractNumberForPrimeVendorResponse getPrimeVendorContract(Buyer buyer, Seller seller) {
        CustomerContractNumberForPrimeVendorResponse response = new CustomerContractNumberForPrimeVendorResponse();
        if (seller.sellerTypeRef.sellerType.equals("DPV")) {
            BuyerSellerAccountSaveAttemptResponse bsResponse = checkPrimeVendorContract(buyer, seller);
            response.isValid = bsResponse.okToSave;
            response.customerContractNumber = (response.isValid ? bsResponse.customerContract.contractNumber : null);
        } else {
            response.isValid = false;
            throw new ApplicationException("The Supplier provided is not a Prime Vendor, no contract exists for it.");
        }
        return response;
    }

    public List<Buyer> getBuyersForManagedByNodeIdentifier(String nodeIdentifier){
        return microservice.getBuyersForManagedByNodeIdentifier(nodeIdentifier);
    }

    public List<String> validateBuyerSellerContract(String buyerId, String sellerId){
        List<String> errorMessages = new ArrayList<>();
        BuyerSellerAccount buyerSellerAccount = sellerService.getBuyerSellerAccountBySellerAndBuyerId(buyerId, sellerId);
        if(!Objects.isNull(buyerSellerAccount) && !Objects.isNull(buyerSellerAccount.contractId)){
            CustomerContract contract = sellerService.getCustomerContractById(buyerSellerAccount.contractId);
            if(Objects.isNull(contract)){
                errorMessages.add("No contract is available for this Supplier.");
            }else{
                LocalDate contractExpiryDate = localDateFromDate(contract.contractExpirationDate);
                LocalDate today = LocalDate.now();
                if(contractExpiryDate.isBefore(today))
                    errorMessages.add("No active contract is available for this Supplier.");
            }
        }else{
            errorMessages.add("No contract is available for this Supplier.");
        }
        return errorMessages;
    }

    public Buyer saveBuyersShippingAddress(Address address){
        return microservice.saveBuyersShippingAddress(address);
    }


    public BuyerDTO getBuyerForOrganization(String organizationId) {
        Buyer buyer = microservice.getBuyerForNodeId(organizationId);
        BuyerDTO buyerDTO = null;
        if (buyer != null) {
            buyerDTO = getBuyerDTOFromBuyer(buyer);
        }
        return buyerDTO;
    }

    public List<FundingNode> getFundingNodesByOrgAndBuyer(String orgId, String buyerId) {
        Buyer buyer = microservice.getBuyerById(buyerId);
        Organization organization = organizationNodeService.getOrganization(orgId);
        return financeAdminService.getFundingNodesByOrgAndCostCenter(organization.getParentId(), buyer.costCenter);
    }

    public ProcessingBalance createFundingNodeChild(String id, FundingNodeChild child) {
        return financeAdminService.createFundingNodeChild(id, child);
    }

    public void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate) {
        microservice.processDataReferenceUpdate(dataReferenceUpdate);
    }
}
