package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiDeltaMicroserviceApi;
import logicole.common.datamodels.abi.AbiCatalogBase;
import logicole.common.datamodels.abi.CriticalItemCategoryRef;
import logicole.common.datamodels.abi.delta.*;
import logicole.common.general.exception.ObjectNotFoundException;
import logicole.common.general.util.DateUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.product.ProductService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.util.List;

@ApplicationScoped
public class AbiDeltaService extends BaseGatewayService<IAbiDeltaMicroserviceApi> {

    @Inject
    private DateUtil dateUtil;

    @Inject
    ProductService productService;

    public AbiDeltaService() {
        super("AbiDelta");
    }

    public DeltaUpdateInformation getDeltaUpdateInformation(@QueryParam("deltaRecordId") String deltaRecordId) {
        return microservice.getDeltaUpdateInformation(deltaRecordId);
    }

    public DeltaRecord updateRecord(DeltaRecord updatedRecord) throws ObjectNotFoundException {
        return microservice.updateRecord(updatedRecord);
    }

    public boolean insertStagingRecord(DeltaRecord deltaRecord) {
        return microservice.insertStagingRecord(deltaRecord);
    }

    public boolean updateStagingRecord(@QueryParam("stagingRecordId") String stagingRecordId, DeltaRecord updatedRecord) {
        return microservice.updateStagingRecord(stagingRecordId, updatedRecord);
    }

    public boolean discardDeltaRecord(@QueryParam("deltaRecordId") String deltaRecordId) {
        return microservice.discardDeltaRecord(deltaRecordId);
    }

    public DeltaRecordCounts getDeltaRecordCounts() {
        return microservice.getDeltaRecordCounts();
    }

    public List<DeltaRecord> searchRecords(
            @QueryParam("filterData") String filterData) {
        return microservice.searchDeltaRecords(filterData);
    }

    public List<DeltaRequestStatus> getDeltaRequestStatusList() {
        return microservice.getDeltaRequestStatusList();
    }

    public Integer deleteDeltaRequest(@QueryParam("deltaRequestId") String deltaRequestId) {
        return microservice.deleteDeltaRequest(deltaRequestId);
    }

    public Long deletePriorDeltaRequests(@QueryParam("olderThanDays") Integer olderThanDays) {
        return microservice.deletePriorDeltaRequests(olderThanDays);
    }

    public DeltaRequestResponse autoMoveDeltaToStaging() {
        return microservice.autoMoveDeltaToStaging();
    }

    public void processDeltaRequest(DeltaRequest deltaRequest) {
        DeltaQueueBuilder deltaQueueBuilder = new DeltaQueueBuilder();
        deltaQueueBuilder.deltaRequest = deltaRequest;
        if (null != deltaRequest) {
            String requestId = deltaRequest.requestId;
            String deltaRecordId = deltaRequest.deltaRecordId;

            if (microservice.queueRecordAlreadyExists(requestId, deltaRecordId)) {
                return;
            }
            //create request record
            deltaQueueBuilder.requestRecord = createQueueRecord(requestId, deltaRecordId);

            //get the delta staging record
            deltaQueueBuilder.deltaStagingRecord = microservice.getDeltaStagingRecord(deltaQueueBuilder.requestRecord.deltaRecordId);

            // Populate siteCount and inUseIndicator
            populateSiteCountUseIndicator(deltaQueueBuilder);

            //check to see if we need to update a changed enterprise product identifier
            String initialEnterpriseProductIdentifier = deltaQueueBuilder.deltaStagingRecord.enterpriseProductIdentifier;
            updateSiteCatalogIfEntProdIdChanged(initialEnterpriseProductIdentifier, deltaQueueBuilder.deltaStagingRecord);

            microservice.processMoveToStagingDeltaRequest(deltaQueueBuilder);
        } else {
            logger.error("Request is empty for processDeltaRequest");
        }
    }

    private void updateSiteCatalogIfEntProdIdChanged(String initialEnterpriseProductIdentifier,
                                                     AbiCatalogBase recordToUpdate) {
        if ((!StringUtil.isEmptyOrNull(initialEnterpriseProductIdentifier)) && (recordToUpdate != null)) {
            String updatedEnterpriseProductIdentifier = recordToUpdate.enterpriseProductIdentifier;
            if (!StringUtil.isEmptyOrNull(updatedEnterpriseProductIdentifier) &&
                    (!initialEnterpriseProductIdentifier.equals(updatedEnterpriseProductIdentifier))) {
                productService.updateEnterpriseProductIdentifier(initialEnterpriseProductIdentifier,
                        updatedEnterpriseProductIdentifier);
            }
        }
    }

    private void populateSiteCountUseIndicator(DeltaQueueBuilder deltaQueueBuilder) {
        String enterpriseProductIdentifier = deltaQueueBuilder.deltaStagingRecord.enterpriseProductIdentifier;
        if (enterpriseProductIdentifier != null) {

            Integer siteCount = productService.getSiteCount(enterpriseProductIdentifier);

            deltaQueueBuilder.deltaStagingRecord.siteCount = siteCount;
            if (siteCount > 0) {
                deltaQueueBuilder.deltaStagingRecord.inUseIndicator = "Y";
            } else {
                deltaQueueBuilder.deltaStagingRecord.inUseIndicator = "N";
            }
        }
    }

    private DeltaRequestQueueRecord createQueueRecord(String requestId, String deltaRecordId) {
        DeltaRequestQueueRecord requestRecord = new DeltaRequestQueueRecord();

        // 1. Put record in queue - status queued
        requestRecord.deltaRecordId = deltaRecordId;
        requestRecord.requestDate = dateUtil.getCurrentUTCDate();
        requestRecord.requestType = DeltaRequestType.MOVE_TO_STAGING;
        requestRecord.status = DeltaRequestStatusType.QUEUED;
        requestRecord.requestId = requestId;
        requestRecord = microservice.createQueueRecord(requestRecord);
        return requestRecord;
    }

    public Long getPriorDeltaRequestCount(@QueryParam("olderThanDays") Integer olderThanDays) {
        return microservice.getPriorDeltaRequestCount(olderThanDays);
    }

    public void updateCriticalItemCategoryRefs(CriticalItemCategoryRef ref) {
        microservice.updateCriticalItemCategoryRefs(ref);
    }

    public DeltaRecord applyFormatting(DeltaRecord updatedRecord) {
        return (DeltaRecord) microservice.applyFormatting(updatedRecord);
    }

}
