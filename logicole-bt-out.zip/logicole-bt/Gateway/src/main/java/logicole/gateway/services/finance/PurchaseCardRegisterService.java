package logicole.gateway.services.finance;

import logicole.apis.finance.IPurchaseCardRegisterMicroserviceApi;
import logicole.common.datamodels.finance.purchasecard.PurchaseCardRef;
import logicole.common.datamodels.finance.purchasecard.PurchaseCardRegister;
import logicole.common.datamodels.finance.purchasecard.ReconciliationHistory;
import logicole.common.datamodels.finance.purchasecard.ReconciliationPeriod;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.finance.validator.PurchaseCardValidator;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@ApplicationScoped
public class PurchaseCardRegisterService extends BaseGatewayService<IPurchaseCardRegisterMicroserviceApi> {

    public PurchaseCardRegisterService() {
        super("PurchaseCard");
    }

    @Inject
    PurchaseCardValidator purchaseCardValidator;

    public PurchaseCardRegister createPurchaseCardRegister(PurchaseCardRegister purchaseCardRegister) {
        purchaseCardValidator.validatePurchaseCardRegister(purchaseCardRegister);
        return microservice.createPurchaseCardRegister(purchaseCardRegister);
    }

    public PurchaseCardRegister getPurchaseCardRegisterById(String id) {
        return microservice.getPurchaseCardRegisterById(id);
    }

    public List<PurchaseCardRegister> getPurchaseCardRegisterByRef(PurchaseCardRef purchaseCardRef) {
        return microservice.getPurchaseCardRegisterByRef(purchaseCardRef);
    }

    public ReconciliationPeriod getCurrentReconciliationPeriod(String purchaseCardId) {
        return microservice.getCurrentReconciliationPeriod(purchaseCardId);
    }

    public List<ReconciliationPeriod> getReconciliationPeriods(String purchaseCardId) {
        return microservice.getReconciliationPeriods(purchaseCardId);
    }

    public List<PurchaseCardRegister> getUnreconciledRegister(String purchaseCardId) {
        return microservice.getUnreconciledRegister(purchaseCardId);
    }

    public PurchaseCardRegister reconcile(String registerId, String amount) {
        return microservice.reconcile(registerId, amount);
    }

    public ReconciliationHistory voidReconciliationHistory(String reconciliationHistoryId) {
        return microservice.voidReconciliationHistory(reconciliationHistoryId);
    }

    public PurchaseCardRegister disputeRegister(String registerId, String amount) {
        return microservice.disputeRegister(registerId, amount);
    }

    public ReconciliationPeriod updateStatementTotal(String reconciliationPeriodId, String amount) {
        return microservice.updateStatementTotal(reconciliationPeriodId, amount);
    }

    public List<ReconciliationHistory> getReconciliationHistories(String purchaseCardRegisterId) {
        return microservice.getReconciliationHistories(purchaseCardRegisterId);
    }

    public List<PurchaseCardRegister> getRegisterForPeriod(String purchaseCardId, String periodId) {
        return microservice.getRegisterForPeriod(purchaseCardId, periodId);
    }
}

