package logicole.gateway.services.slep;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.*;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.abi.PackageUnit;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.slep.APIFetchListFilter;
import logicole.common.datamodels.slep.SlepCatalog;
import logicole.common.datamodels.slep.SlepCustomer;
import logicole.common.datamodels.slep.SlepDodaac;
import logicole.common.datamodels.slep.SlepInventory;
import logicole.common.datamodels.slep.SlepInventoryETL;
import logicole.common.datamodels.slep.InventoryLotNumber;
import logicole.common.datamodels.slep.SlepLotNumber;
import logicole.common.datamodels.slep.SlepLotNumberETL;
import logicole.common.datamodels.slep.SlepLotStatus;
import logicole.common.datamodels.slep.SlepProject;
import logicole.common.datamodels.slep.SlepProjectETL;
import logicole.common.datamodels.slep.SlepProjectStatus;
import logicole.common.datamodels.slep.SlepRole;
import logicole.common.datamodels.slep.SlepUserProfile;
import logicole.common.datamodels.slep.UserProfileInfo;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

@Api(tags = {"Slep"})
@ApplicationScoped
@Path("/slep")
@Consumes(MediaType.APPLICATION_JSON)
public class SlepRestApi extends ExternalRestApi<SlepService> {

	@Inject
	private MultiPartFormUtil uploadUtil;

	/** Lot Number APIs **/

	@POST
	@Path("/lotNumber/getLotNumberList")
	public List<SlepLotNumber> getLotNumberList(@QueryParam("includeAction") boolean includeAction, APIFetchListFilter filter) throws ApplicationException {
		
		return service.getLotNumberList(includeAction, filter);
	}
	
	@GET
	@Path("/lotNumber/getLotNumberDetails")
	public SlepLotNumber getLotNumberDetails(@QueryParam("nsn") String nsn, @QueryParam("lotNum") String lotNum) throws ApplicationException {
		
		return service.getLotNumberDetails(nsn, lotNum);
	}
	
		
	@POST
	@Path("/lotNumber/addLotNumber")
	public SlepLotNumber addLotNumber(SlepLotNumber lotNum) throws ApplicationException {
		
		return service.addLotNumber(lotNum);
	}
	
	@POST
	@Path("/lotNumber/editLotNumber")
	public SlepLotNumber editLotNumber(SlepLotNumber lotNum) throws ApplicationException {
		
		return service.editLotNumber(lotNum);
	}
	
	@POST
	@Path("/lotNumber/approvalProcessLotNumber")
	public void approvalProcessLotNumber(SlepLotNumber lotNum) throws ApplicationException {

		service.approvalProcessLotNumber(lotNum);
	}
	
	@POST
	@Path("/lotNumber/updateLotNumbers")
	public Integer updateLotNumbers(List<SlepLotNumber> lotNumList) throws ApplicationException {
		return service.updateLotNumbers(lotNumList);
	}
/***/
	
	/** Common APIs **/
	@GET
	@Path("/common/getLotNumberStatusList")
	public List<SlepLotStatus> getLotNumberStatusList(@QueryParam("isFdaStatus") Boolean isFdaStatus) throws ApplicationException {
		
		return service.getLotNumberStatusList(isFdaStatus);
	}
	
	@GET
	@Path("/common/getManufacturerList")
	public List<String> getManufacturerList() throws ApplicationException {
		
		return service.getManufacturerList();
	}
	
	@POST
	@Path("/common/addManufacturer")
	public void addManufacturer(String manufacturerName) throws ApplicationException {
		
		service.addManufacturer(manufacturerName);
	}
	
	@POST
	@Path("/common/getCustomerList")
	public List<SlepCustomer> getCustomerList(APIFetchListFilter filter) throws ApplicationException {
	    
	    return service.getCustomerList(filter);
	}
	
	@GET
	@Path("/common/getPackageUnitList")
	public List<PackageUnit> getPackageUnitList() throws ApplicationException {
	    
	    return service.getPackageUnitList();
	}
	
/***/
	
	/** Project APIs **/
	@POST
	@Path("/project/getProjectList")
	public List<SlepProject> getProjectList(@QueryParam("includeAction") boolean includeAction, APIFetchListFilter filter) throws ApplicationException {

		return service.getProjectList(includeAction, filter);
	}
	
	@POST
	@Path("/project/getProjectDetails")
	public SlepProject getProjectDetails(@QueryParam("projectId") String projectId, APIFetchListFilter projectLotNumfilter) throws ApplicationException {

		return service.getProjectDetails(projectId, projectLotNumfilter);
	}
	
	@POST
	@Path("/project/getAddableLotNumbers")
	public List<SlepLotNumber> getAddableLotNumbers4Project() throws ApplicationException {

		return service.getAddableLotNumbers4Project();
	}
	
	@POST
	@Path("/project/addProject")
	public void addProject(SlepProject project) throws ApplicationException {

		service.addProject(project);
	}
	
	@POST
	@Path("/project/editProject")
	public void editProject(SlepProject project) throws ApplicationException {

		service.editProject(project);
	}
	
	@POST
	@Path("/project/verifyProject")
	public void verifyProject(SlepProject project) throws ApplicationException {

		service.verifyProject(project);
	}
	
	@GET
	@Path("/project/getProjectStatusList")
	public List<SlepProjectStatus> getProjectStatusList() throws ApplicationException {
		
		return service.getProjectStatusList();
	}

	@GET
	@Path("/project/getMaxUploadSize")
	public Integer getMaxUploadSize() {
		return service.getMaxUploadSize();
	}

	@POST
	@Path("/project/saveProjectAttachment")
	public Attachment saveProjectAttachment(@QueryParam("projectId") String projectId, Attachment attachment) {
		return service.saveProjectAttachment(projectId, attachment);
	}

	@GET
	@Path("/project/removeProjectAttachment")
	public boolean removeProjectAttachment(@QueryParam("projectId") String projectId, @QueryParam("fileId") String fileId) {
		return service.removeProjectAttachment(projectId, fileId);
	}

	@GET
	@Path("/project/getProjectDocumentTypes")
	public List<String> getProjectDocumentTypes() {
		return service.getProjectDocumentTypes();
	}

	@POST
	@Path("/uploadFile")
	@PartType("form")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Upload a file")
	@ApiImplicitParams(
			{
					@ApiImplicitParam(value = "Select a file to upload",
							dataType = "java.io.File", name = "file",
							paramType = "formData", required = true)
			})
	public FileManager uploadFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
		byte[] content;

		InputPart inputPart = uploadUtil.getInputPart(form, "file");
		String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

		try {
			InputStream inputStream = inputPart.getBody(InputStream.class, null);
			content = IOUtils.toByteArray(inputStream);
		} catch (IOException ioe) {
			throw new ApplicationException("Unable to upload file " + uploadedFileName);
		}

		Integer maxUploadSize = service.getMaxUploadSize();
		if (content.length > maxUploadSize) {
			throw new ApplicationException(
					"File size exceeds max size of " + maxUploadSize + " bytes");
		}

		return service.uploadFile(content, uploadedFileName);
	}
	
/***/
	

	/** inventory APIs **/
	@POST
	@Path("/inventory/getInventoryList")
	public List<SlepInventory> getInventoryList(APIFetchListFilter filter) throws ApplicationException {
		return service.getInventoryList(filter);
	}
	
	@POST
	@Path("/inventory/getAddableLotNumbers")
	public List<InventoryLotNumber> getAddableLotNumbersForInventory(@QueryParam("dodaacId") String dodaacId, @QueryParam("nsn") String nsn, @QueryParam("lotNumber") String lotNumber, APIFetchListFilter filter) throws ApplicationException {
		return service.getAddableLotNumbers4Inventory(dodaacId, nsn, lotNumber);
	}
	@POST
	@Path("/inventory/getAddableLotNumbersCount")
	public Long getAddableLotNumbersForInventoryCount(@QueryParam("dodaacId") String dodaacId, @QueryParam("nsn") String nsn, @QueryParam("lotNumber") String lotNumber, APIFetchListFilter filter) throws ApplicationException {
		return service.getAddableLotNumbers4InventoryCount(dodaacId, nsn, lotNumber);
	}
	
	@POST
	@Path("/inventory/editInventory")
	public void editInventory(SlepInventory siteInventory) throws ApplicationException {
		service.editInventory(siteInventory);
	}
	
	@POST
	@Path("/inventory/certifyInventory")
	public void certifyInventory(@QueryParam("dodaacId") String dodaacId) throws ApplicationException {
		service.certifyInventory(dodaacId);
	}

/***/
	
    /** catalog APIs **/
    @POST
    @Path("/catalog/getCatalogList")
    public List<SlepCatalog> getCatalogList(APIFetchListFilter filter) throws ApplicationException {
        
        return service.getCatalogList(filter);
    }
    
    @POST
    @Path("/catalog/addCatalog")
    public void addCatalog(SlepCatalog catalog) throws ApplicationException {
        service.addCatalog(catalog);
    }
    
    @POST
    @Path("/catalog/editCatalog")
    public void editCatalog(SlepCatalog catalog) throws ApplicationException {
        service.editCatalog(catalog);
    }
	
/***/
    
    /** DoDAAC APIs **/
    @POST
    @Path("/dodaac/getDodaacList")
    public List<SlepDodaac> getDodaacList(APIFetchListFilter filter) throws ApplicationException {
        return service.getDodaacList(filter);
    }
    
    @POST
    @Path("/dodaac/addDodaac")
    public void addCatalog(SlepDodaac dodaac) throws ApplicationException {
        service.addDodaac(dodaac);
    }
    
    @POST
    @Path("/dodaac/editDodaac")
    public void editCatalog(SlepDodaac dodaac) throws ApplicationException {
        service.editDodaac(dodaac);
    }
    
    @GET
    @Path("/dodaac/getServiceAgencyList")
    public List<String> getServiceAgencyList(@QueryParam("isLogicoleInventory") Boolean isLogicoleInventory) throws ApplicationException {
        
        return service.getServiceAgencyList(isLogicoleInventory);
    }
    
/***/
	
	/** User APIs **/
	@GET
	@Path("/user/getUserList")
	public List<UserProfileInfo> getUserList(@QueryParam("parentId") String parentId) throws ApplicationException {
		return service.getUserList(parentId);
	}
	
	@GET
	@Path("/user/getRoleList")
	public List<SlepRole> getRoleList() throws ApplicationException {
		return service.getRoleList();
	}

	@GET
	@Path("/user/getUser")
	public UserProfileInfo getUser(@QueryParam("appUserProfileId") String appUserProfileId) throws ApplicationException {
		return service.getUser(appUserProfileId);
	}
	
	@POST
	@Path("/user/updateUser")
	public Integer updateUser(SlepUserProfile userInfo) throws ApplicationException {
		return service.updateUser(userInfo);
	}
	
/***/
	
	/** ETL APIs **/
	@POST
	@Path("/etl/getLotNumbers")
	public List<SlepLotNumberETL> getLotNumbers(APIFetchListFilter filter) throws ApplicationException {
		return service.getLotNumbers(filter);
	}
	
	@POST
	@Path("/etl/getInventories")
	public List<SlepInventoryETL> getInventories(APIFetchListFilter filter) throws ApplicationException {
		return service.getInventories(filter);
	}
	
	@POST
	@Path("/etl/getProjects")
	public List<SlepProjectETL> getProjects(APIFetchListFilter filter) throws ApplicationException {
		return service.getProjects(filter);
	}
	
	/***/
}
