package logicole.gateway.services.inventory;

import io.swagger.annotations.Api;
import logicole.common.datamodels.inventory.Shipment;
import logicole.common.datamodels.inventory.Shipper;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Transportation"})
@ApplicationScoped
@Path("/transportation")
public class TransportationRestApi extends ExternalRestApi<TransportationService> {

    @GET
    @Path("/getShipments")
    public List<Shipment> getShipments() {
        return service.getShipments();
    }

    @GET
    @Path("/getShipmentById")
    public Shipment getShipmentById(@QueryParam("shipmentId") String shipmentId) {
        return service.getShipmentById(shipmentId);
    }

    @GET
    @Path("/getInShipments")
    public List<Shipment> getInShipments() {
        return service.getInShipments();
    }

    @GET
    @Path("/getOutShipments")
    public List<Shipment> getOutShipments() {
        return service.getOutShipments();
    }

    @GET
    @Path("/getShippers")
    public List<Shipper> getShippers() {
        return service.getShippers();
    }

    @GET
    @Path("/getShipperById")
    public Shipper getShipperById(@QueryParam("shipperId") String shipperId) {
        return service.getShipperById(shipperId);
    }

    @GET
    @Path("/getShipperByName")
    public Shipper getShipperByName(@QueryParam("name") String shipperName) {
        return service.getShipperByName(shipperName);
    }



}
