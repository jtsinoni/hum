package logicole.gateway.services.sale;

import io.swagger.annotations.Api;
import logicole.common.datamodels.delivery.DueOut;
import logicole.common.datamodels.inventory.PickList;
import logicole.common.datamodels.inventory.PickRequest;
import logicole.common.datamodels.order.order.OrderDTO;
import logicole.common.datamodels.sale.fulfillment.Fulfillment;
import logicole.common.datamodels.sale.fulfillment.ManualFulfillmentDTO;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Fulfillment"})
@ApplicationScoped
@Path("/fulfillment")
public class FulfillmentRestApi extends ExternalRestApi<FulfillmentService> {


    @POST
    @Path("/acceptOrder")
    public void acceptOrder(OrderDTO order) {
        service.acceptOrder(order);
    }

    @GET
    @Path("/getFulfillmentActivity")
    public List<Fulfillment> getFulfillmentActivity(@QueryParam("inventoryOwnerId") String inventoryOwnerId) {
        return service.getFulfillmentActivity(inventoryOwnerId);
    }

    @GET
    @Path("/getManualFulfillmentList")
    public List<ManualFulfillmentDTO> getManualFulfillmentList(@QueryParam("inventoryOwnerId") String inventoryOwnerId) {
        return service.getManualFulfillmentList(inventoryOwnerId);
    }

    @POST
    @Path("/processFulfillment")
    public DueOut processfulfillment(@QueryParam("dueOutId") String dueOutId, @QueryParam("quantity") Integer quantity, @QueryParam("backOrderqty") Integer backOrderqty,
                                     @QueryParam("isBackOrderRelease") Boolean isBackOrderRelease) {
        return service.processFulfillment(dueOutId, quantity, backOrderqty, isBackOrderRelease);
    }

    @POST
    @Path("/processManualFulfillment")
    public ManualFulfillmentDTO processManualFulfillment(ManualFulfillmentDTO manualFulfillmentDTO) {
        return service.processManualFulfillment(manualFulfillmentDTO);
    }

    @POST
    @Path("/processAllManualFulfillment")
    public List<ManualFulfillmentDTO> processAllManualFulfillment(List<ManualFulfillmentDTO> manualFulfillmentDTOs) {
        return service.processAllManualFulfillment(manualFulfillmentDTOs);
    }

    @POST
    @Path("/generatePicklist")
    public List<PickList> generatePicklist(List<PickRequest> pickRequests) throws ApplicationException {
        return service.generatePicklist(pickRequests);
    }

    @POST
    @Path("/cancelPickRequest")
    public List<PickRequest> cancelPickRequest(List<PickRequest> pickRequests) {
        return service.cancelPickRequest(pickRequests);
    }

    @POST
    @Path("/confirmPicklist")
    public PickList confirmPicklist(PickList pickList) {
        return service.confirmPicklist(pickList);
    }

    @GET
    @Path("/getPickRequestsByInventorySystemId")
    public List<PickRequest> getPickRequestsByInventorySystemId(@QueryParam("inventorySystemId") String inventorySystemId) {
        return service.getPickRequestsByInventorySystemId(inventorySystemId);
    }

    @GET
    @Path("/getPickListById")
    public PickList getPickListById(@QueryParam("pickListId") String pickListId) {
        return service.getPickListById(pickListId);
    }

    @GET
    @Path("/getPickListReportDataById")
    public PickList getPickListReportDataById(@QueryParam("pickListId") String pickListId) {
        return service.getPickListReportDataById(pickListId);
    }

    @GET
    @Path("/getPickListsByInventorySystemId")
    public List<PickList> getPickListsByInventorySystemId(@QueryParam("inventorySystemId") String inventorySystemId) {
        return service.getPickListsByInventorySystemId(inventorySystemId);
    }

    @GET
    @Path("/getConfirmedPickListsByInventorySystemId")
    public List<PickList> getConfirmedPickListsByInventorySystemId(@QueryParam("inventorySystemId") String inventorySystemId) {
        return service.getConfirmedPickListsByInventorySystemId(inventorySystemId);
    }

    @POST
    @Path("/rejectSelectedFulfillment")
    public List<ManualFulfillmentDTO> rejectSelectedFulfillment(List<ManualFulfillmentDTO> manualFulfillmentDTOs) {
        return service.rejectSelectedFulfillment(manualFulfillmentDTOs);
    }

    @POST
    @Path("/rejectFulfillment")
    public ManualFulfillmentDTO rejectFulfillment(ManualFulfillmentDTO manualFulfillmentDTO) {
        return service.rejectFulfillment(manualFulfillmentDTO);
    }

    @GET
    @Path("/processBackOrderRelease")
    public boolean processBackOrderRelease() {
        return service.processBackOrderRelease();
    }
}
