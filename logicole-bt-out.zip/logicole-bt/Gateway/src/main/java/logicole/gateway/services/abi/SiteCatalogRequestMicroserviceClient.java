package logicole.gateway.services.abi;

import logicole.apis.abi.ISiteCatalogRequestMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class SiteCatalogRequestMicroserviceClient extends MicroserviceClient<ISiteCatalogRequestMicroserviceApi> {
    public SiteCatalogRequestMicroserviceClient() {
        super(ISiteCatalogRequestMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public ISiteCatalogRequestMicroserviceApi getSiteCatalogService() {
        return createClient();
    }
}

