package logicole.gateway.services.organization;

import logicole.apis.organization.IOrganizationTreeStructureMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;


@ApplicationScoped
public class OrganizationTreeStructureMicroserviceClient extends MicroserviceClient<IOrganizationTreeStructureMicroserviceApi> {

    public OrganizationTreeStructureMicroserviceClient() {
        super(IOrganizationTreeStructureMicroserviceApi.class, "logicole-organization");
    }

    @Produces
    public IOrganizationTreeStructureMicroserviceApi getIOrganizationTreeStructureMicroserviceApi() {
        return createClient();
    }
}
