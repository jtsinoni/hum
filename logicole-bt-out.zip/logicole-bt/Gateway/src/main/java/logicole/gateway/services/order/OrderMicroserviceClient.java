package logicole.gateway.services.order;

import logicole.gateway.rest.MicroserviceClient;
import logicole.apis.order.IOrderMicroserviceApi;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class OrderMicroserviceClient extends MicroserviceClient<IOrderMicroserviceApi> {
    public OrderMicroserviceClient(){
        super(IOrderMicroserviceApi.class, "logicole-order");
    }

    @Produces
    public IOrderMicroserviceApi getIOrderMicroserviceApi() {
        return createClient();
    }

}
