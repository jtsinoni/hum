package logicole.gateway.services.user;

import io.swagger.annotations.Api;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.Element;
import logicole.common.datamodels.user.Endpoint;
import logicole.common.datamodels.user.FunctionalArea;
import logicole.common.datamodels.user.Permission;
import logicole.common.datamodels.user.BiReport;
import logicole.common.datamodels.user.State;
import logicole.common.general.exception.ObjectNotFoundException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.io.IOException;
import java.util.List;

@Api(tags = {"Permission"})
@ApplicationScoped
@Path("/permission")
public class PermissionRestApi extends ExternalRestApi<PermissionService> {

    // Permissions
    @GET
    @Path("/getFullPermissions")
    public List<Permission> getFullPermissions() {
        return service.getFullPermissions();
    }

    @GET
    @Path("/getPermissionById")
    public Permission getPermissionById(@QueryParam("id") String id) {
        return service.getPermissionById(id);
    }

    @GET
    @Path("/deletePermissionById")
    public Boolean deletePermissionById(@QueryParam("id") String id) {
        return service.deletePermissionById(id);
    }

    @GET
    @Path("/getRoleNamesRelatedToPermission")
    public List<String> getRoleNamesRelatedToPermission(@QueryParam("permId") String permId) {
        return service.getRoleNamesRelatedToPermission(permId);
    }

    @POST
    @Path("/createPermission")
    public Permission createPermission(Permission permission) {
        return service.createPermission(permission);
    }

    @POST
    @Path("/savePermissionEndpoints")
    public Permission savePermissionEndpoints(Permission permission) throws ObjectNotFoundException {
        return service.savePermissionEndpoints(permission);
    }

    @POST
    @Path("/savePermissionStates")
    public Permission savePermissionStates(Permission permission) throws ObjectNotFoundException {
        return service.savePermissionStates(permission);
    }

    @POST
    @Path("/savePermissionElements")
    public Permission savePermissionElements(Permission permission) throws ObjectNotFoundException {
        return service.savePermissionElements(permission);
    }

    @POST
    @Path("/savePermissionReports")
    public Permission savePermissionReports(Permission permission) throws ObjectNotFoundException {
        return service.savePermissionReports(permission);
    }

    @POST
    @Path("/savePermission")
    public Permission savePermission(Permission permission) {
        return service.savePermission(permission);
    }

    @GET
    @Path("/getPermNamesByElement")
    public List<String> getPermissionNamesByElement(@QueryParam("elementName") String elementName) {
        return service.getPermissionNamesByElement(elementName);
    }

    @GET
    @Path("/getPermNamesByEndpoint")
    public List<String> getPermissionNamesByEndpoint(@QueryParam("endpointName") String endpointName) {
        return service.getPermissionNamesByEndpoint(endpointName);
    }

    @GET
    @Path("/getPermNamesByState")
    public List<String> getPermissionNamesByState(@QueryParam("stateName") String stateName) {
        return service.getPermissionNamesByState(stateName);
    }

    @GET
    @Path("/getPermNamesByReport")
    public List<String> getPermissionNamesByReport(@QueryParam("reportName") String reportName) {
        return service.getPermissionNamesByReport(reportName);
    }

    // Elements
    @GET
    @Path("/getAllElements")
    public List<Element> getAllElements() {
        return service.getAllElements();
    }

    @GET
    @Path("/doesElementExistByName")
    public Boolean doesElementExistByName(@QueryParam("elementName") String elementName) {
        return service.doesElementExistByName(elementName);
    }

    @POST
    @Path("/saveElement")
    public Element saveElement(Element element) {
        return service.saveElement(element);
    }

    @POST
    @Path("/createElement")
    public Element createElement(Element element) {
        return service.createElement(element);
    }

    @GET
    @Path("/deleteElement")
    public Boolean deleteElement(@NotNull @QueryParam("id") String id) {
        return service.deleteElement(id);
    }

    // Endpoints
    @GET
    @Path("/getAllEndpoints")
    public List<Endpoint> getAllEndpoints() {
        return service.getAllEndpoints();
    }

    @GET
    @Path("/getAllEndpointsNotCached")
    public List<Endpoint> getAllEndpointsNotCached() {
        return service.getAllEndpointsNotCached();
    }

    @GET
    @Path("/doesEndpointExistByBusinessMethod")
    public Boolean doesEndpointExistByBusinessMethod(@QueryParam("businessMethod") String businessMethod) {
        return service.doesEndpointExistByBusinessMethod(businessMethod);
    }

    @POST
    @Path("/createEndpoint")
    public Endpoint createEndpoint(Endpoint endpoint) throws IOException {
        return service.createEndpoint(endpoint);
    }

    @POST
    @Path("/saveEndpoint")
    public Endpoint saveEndpoint(Endpoint endpoint) throws IOException {
        return service.saveEndpoint(endpoint);
    }

    @GET
    @Path("/deleteEndpoint")
    public Boolean deleteEndpoint(@NotNull @QueryParam("id") String id) {
        return service.deleteEndpoint(id);
    }

    @GET
    @Path("/refreshEndpointCache")
    public void refreshEndpointCache() {
        service.refreshEndpointCache();
    }


    // States
    @GET
    @Path("/getAllStates")
    public List<State> getAllStates() {
        return service.getAllStates();
    }

    @GET
    @Path("/doesStateExistByName")
    public Boolean doesStateExistByName(@QueryParam("stateName") String stateName) {
        return service.doesStateExistByName(stateName);
    }

    @POST
    @Path("/saveState")
    public State saveState(State state) {
        return service.saveState(state);
    }

    @POST
    @Path("/createState")
    public State createState(State state) throws ObjectNotFoundException {
        return service.createState(state);
    }

    @GET
    @Path("/deleteState")
    public Boolean deleteState(@NotNull @QueryParam("id") String id) {
        return service.deleteState(id);
    }

    // Reports
    @GET
    @Path("/getAllReports")
    public List<BiReport> getAllReports() {
        return service.getAllReports();
    }

    @GET
    @Path("/doesReportExistByName")
    public Boolean doesReportExistByName(@QueryParam("reportName") String reportName) {
        return service.doesReportExistByName(reportName);
    }

    @POST
    @Path("/saveReport")
    public BiReport saveReport(BiReport biReport) {
        return service.saveReport(biReport);
    }

    @POST
    @Path("/createReport")
    public BiReport createReport(BiReport biReport) {
        return service.createReport(biReport);
    }

    @GET
    @Path("/deleteReport")
    public Boolean deleteReport(@NotNull @QueryParam("id") String id) {
        return service.deleteReport(id);
    }

    @GET
    @Path("/getReportsByReportId")
    public List<BiReport> getReportsByReportId(@QueryParam("id") String reportId){
        return service.getReportsByReportId(reportId);
    }

    // Role
    @GET
    @Path("/getRoleFunctionalAreaConfigs")
    public List<FunctionalArea> getRoleFunctionalAreaConfigs() {
        return service.getRoleFunctionalAreaConfigs();
    }

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getPermission")
    public Permission getPermission(@QueryParam("permissionId") String permissionId) {
        return service.getPermission(permissionId);
    }

    @GET
    @Path("/deletePermission")
    public Boolean deletePermission(@NotNull @QueryParam("id") String id) {
        return service.deletePermission(id);
    }

    @POST
    @Path("addReportFeatureFlag")
    public BiReport addReportFeatureFlag(BiReport report) {
        return service.addReportFeatureFlag(report);
    }

    @POST
    @Path("removeReportFeatureFlag")
    public BiReport removeReportFeatureFlag(BiReport report) {
        return service.removeReportFeatureFlag(report);
    }
}
