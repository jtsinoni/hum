package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceAdminMicroserviceApi;
import logicole.common.datamodels.assemblage.AssemblageFinanceData;
import logicole.common.datamodels.finance.AuthorizedOrg;
import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.FundingNodeBalance;
import logicole.common.datamodels.finance.FundingNodeChild;
import logicole.common.datamodels.finance.FundingNodeConfig;
import logicole.common.datamodels.finance.FundingNodeConfigChild;
import logicole.common.datamodels.finance.FundingNodeDTO;
import logicole.common.datamodels.finance.FundingSourceContinuation;
import logicole.common.datamodels.finance.FundingSourceFieldConfig;
import logicole.common.datamodels.finance.ProcessingBalance;
import logicole.common.datamodels.finance.fundingsource.EFundingSourceFieldName;
import logicole.common.datamodels.finance.fundingsource.EFundingSourceSubType;
import logicole.common.datamodels.finance.fundingsource.EFundingSourceType;
import logicole.common.datamodels.finance.fundingsource.FundingSource;
import logicole.common.datamodels.finance.fundingsource.FundingSourceRef;
import logicole.common.datamodels.finance.fundingsource.FundingSourceWrapper;
import logicole.common.datamodels.finance.output.AuthorizedNode;
import logicole.common.datamodels.finance.referencedata.CommodityCode;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.finance.referencedata.FunctionalArea;
import logicole.common.datamodels.finance.referencedata.FundCode;
import logicole.common.datamodels.finance.referencedata.FundingCategory;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationType;
import logicole.common.datamodels.organization.ScopeQuery;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FundingNodeValidationException;
import logicole.common.general.exception.FundingSourceValidationException;
import logicole.common.general.util.ListUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.organization.EProviderType;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.organization.ProviderService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@ApplicationScoped
public class FinanceAdminService extends BaseGatewayService<IFinanceAdminMicroserviceApi> {
    @Inject
    protected BuyerService buyerService;
    @Inject
    protected FinanceValidationService financeValidationService;
    @Inject
    protected OrganizationService organizationService;
    @Inject
    protected ProviderService providerService;

    public FinanceAdminService() {
        super("FinanceAdmin");
    }

    public String getCurrentFiscalYear() {
        return microservice.getCurrentFiscalYear();
    }

    public List<FundingSourceContinuation> getFundingSourceContinuations() { return microservice.getFundingSourceContinuations(); }

    public List<FundingSourceFieldConfig> getFinancialSystemFieldConfigListByType(String financialSystemId, String fieldType) {
        return microservice.getFinancialSystemFieldConfigListByType(financialSystemId, fieldType);
    }

    public List<FundingSourceFieldConfig> getFinancialSystemFieldConfigList(String financialSystemId) {
        return microservice.getFinancialSystemFieldConfigList(financialSystemId);
    }

    public FinancialSystem getFinancialSystemById(String financialSystemId) {
        return microservice.getFinancialSystemById(financialSystemId);
    }

    public FinancialSystem getFinancialSystemByNodeId(String nodeId) {
        FinancialSystem financialSystem = providerService.getProviderData(nodeId, EProviderType.FINANCE_SYSTEM_CONFIG_PROVIDER.value);
        if (financialSystem == null) {
            throw new ApplicationException("No financial system found for your organization");
        }
        return financialSystem;
    }

    public List<String> getSubAllocationHoldersBySiteFundCode(String siteNodeId, String mainAccountCode,
                                                              String fiscalYear, Integer duration, String fundCode) {
        FinancialSystem financialSystem = getFinancialSystemByNodeId(siteNodeId);
        Organization siteNode = organizationService.getOrganization(siteNodeId);
        return microservice.getSubAllocationHoldersBySiteFundCode(siteNode.nodeIdentifier, financialSystem.name, mainAccountCode,
                fiscalYear, duration, fundCode);
    }

    public List<FundCode> getFundCodesByFinancialSystem(String financialSystemId) {
        return microservice.getFundCodesByFinancialSystem(financialSystemId);
    }


    public List<FunctionalArea> getFunctionalAreasByFinancialSystem(String financialSystemId) {
        return microservice.getFunctionalAreasByFinancialSystem(financialSystemId);
    }

    public List<String> getFundCodesBySiteMac(String siteNodeId, String mainAccountCode, String fiscalYear, Integer duration)  {
        FinancialSystem financialSystem = getFinancialSystemByNodeId(siteNodeId);
        Organization siteNode = organizationService.getOrganization(siteNodeId);
        return microservice.getFundCodesBySiteMac(siteNode.nodeIdentifier, financialSystem.name, mainAccountCode, fiscalYear, duration);
    }

    public List<String> getMainAccountCodesBySite(String siteNodeId)  {
        FinancialSystem financialSystem = getFinancialSystemByNodeId(siteNodeId);
        Organization siteNode = organizationService.getOrganization(siteNodeId);
        return microservice.getMainAccountCodesBySite(siteNode.nodeIdentifier, financialSystem.name);
    }

    public List<FundingCategory> getCommodityCodesByFinancialSystem(String financialSystemId) {
        return microservice.getCommodityCodesByFinancialSystem(financialSystemId);
    }

    public List<CommodityCode> getCommodityByFinancialSystemType(String financialSystemId, String commodityType) {
        return microservice.getCommodityByFinancialSystemType(financialSystemId, commodityType);
    }

    public List<CommodityCodeRef> getCommodityCodeRefsByTransportation(String financialSystemId) {

        // If financialSystemId = null, then get financialSystemId based off organizationNodeId
        if (financialSystemId == null) {
            CurrentUser currentUser = currentUserBT.getCurrentUser();
            String organizationNodeId = currentUser.profile.currentNodeRef.getId();

            FinancialSystem financialSystem = this.getFinancialSystemByNodeId(organizationNodeId);
            financialSystemId = financialSystem.getId();
        }

        return microservice.getCommodityCodeRefsByTransportation(financialSystemId);
    }


    public FundingSourceContinuation clearFundingSourceContinuation(FundingSourceContinuation fundingSourceContinuation) {
        return microservice.clearFundingSourceContinuation(fundingSourceContinuation);
    }

    public FundingSourceContinuation createFundingSourceContinuation(String type, FundingSourceContinuation fundingSourceContinuation) {
        return microservice.createFundingSourceContinuation(type, fundingSourceContinuation);
    }

    public FundingSourceContinuation extendFundingSourceContinuation(String type, String priorFundingSourceContinuationId,
                                                                     FundingSourceContinuation fundingSourceContinuation) {
        return microservice.extendFundingSourceContinuation(type, priorFundingSourceContinuationId, fundingSourceContinuation);
    }

    public FundingSourceContinuation getActiveFundingSourceContinuation() {
        return microservice.getActiveFundingSourceContinuation();
    }

    public FundingSourceContinuation updateFundingSourceContinuation(FundingSourceContinuation fundingSourceContinuation) {
        return microservice.updateFundingSourceContinuation(fundingSourceContinuation);
    }

    public List<String> getMainAccountTypesBySiteMac(String siteNodeId, String mainAccountCode) {
        FinancialSystem financialSystem = getFinancialSystemByNodeId(siteNodeId);
        Organization siteNode = organizationService.getOrganization(siteNodeId);
        return microservice.getMainAccountTypesBySiteMac(siteNode.nodeIdentifier, financialSystem.name, mainAccountCode);
    }

    public List<Integer> getDurationsBySiteMac(String siteNodeId, String mainAccountCode) {
        FinancialSystem financialSystem = getFinancialSystemByNodeId(siteNodeId);
        Organization siteNode = organizationService.getOrganization(siteNodeId);
        return microservice.getDurationsBySiteMac(siteNode.nodeIdentifier, financialSystem.name, mainAccountCode);
    }

    public FundingSource createFundingSource(FundingSourceWrapper wrapper) {
        FundingSource fundingSource = wrapper.fundingSource;
        List<String> errorMessages = financeValidationService.validateFundingSource(fundingSource);

        if (errorMessages.size() > 0) {
            errorMessages.add(0, "Funding Source errors");
            throw new FundingSourceValidationException(String.join(", ", errorMessages));
        }

        FundingNodeConfig fundingNodeConfig = microservice.getFundingNodeConfigByType(
                fundingSource.financialSystemRef.id,
                fundingSource.type,
                fundingSource.subType
        );

        wrapper.fundingSource = fundingSource;

        List<FundingNodeConfigChild> fundingNodeConfigChildren = fundingNodeConfig.children.get(0).children;
        boolean hasAutoGenerate = fundingNodeConfigChildren.stream().anyMatch(child -> child.autoGenerate);

        if (hasAutoGenerate) {
            if (EFundingSourceSubType.MEMORANDUM.equals(fundingSource.subType)) {
                wrapper.buyer = providerService.getResponsibleOrganizationRef(fundingSource.owningOrg.id,
                        EProviderType.FM_ORGANIZATION_REFERENCE_PROVIDER.toString());
                if (wrapper.buyer == null) {
                    throw new ApplicationException("Facilities responsible organization not found to automatically generate Expense Center");
                }
            } else {
                wrapper.buyer = getLogBuyer(fundingSource.owningOrg.id);
                if (wrapper.buyer == null) {
                    throw new ApplicationException("Log buyer not found to automatically generate Expense Center");
                }
            }
        }

        return microservice.createFundingSource(wrapper);
    }

    public FundingSource updateFundingSource(FundingSourceWrapper wrapper) {
        return microservice.updateFundingSource(wrapper);
    }

    public FundingSourceWrapper getNewFundingSource(String siteNodeId, EFundingSourceType type, EFundingSourceSubType subType) {
        FinancialSystem financialSystem = getFinancialSystemByNodeId(siteNodeId);
        FundingSourceWrapper wrapper = microservice.getNewFundingSource(financialSystem.getId(), type, subType);
        Organization siteNode = organizationService.getOrganization(siteNodeId);
        wrapper.fundingSource.owningOrg = siteNode.getRef();

        if (getFundingNodeConfigByType(financialSystem.getId(), type, subType).useStationIdForAgencyAccounting) {
            wrapper.fundingSource.sloa.agencyAccountingId = siteNode.stationIdentifier;
        } else {
            wrapper.fundingSource.sloa.agencyAccountingId = siteNode.getOrganizationIdentifier();
        }

        return wrapper;
    }

    public List<String> getAllFundingSourceFiscalYears() {
        List<String> allNodeIds = getCurrentOrganizationIds();
        return microservice.getAllFundingSourceFiscalYears(allNodeIds);
    }

    public List<FundingSource> getAllFundingSources(String fiscalYear) {
        return microservice.getAllFundingSources(fiscalYear);
    }

    private List<Organization> getCurrentSiteOrganizations() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        String currentNodeId = currentUser.profile.currentNodeRef.getId();
        ScopeQuery scopeQuery = new ScopeQuery();
        scopeQuery.nodeTypeName = OrganizationType.SITE_TYPE_NAME;
        List<String> scopeList = new ArrayList<>();
        scopeList.add(currentNodeId);
        scopeQuery.scopeList = scopeList;
        return organizationService.getOrganizationsInScopeByOrganizationTypeName(scopeQuery);
    }

    private List<String> getCurrentOrganizationIds() {
        List<Organization> allNodes = getCurrentSiteOrganizations();
        return allNodes.stream().map(Organization::getId).collect(Collectors.toList());
    }

    public List<FundingNode> getFundingNodesByFundingSource(String id) {
        return microservice.getFundingNodesByFundingSource(id);
    }

    public FundingNode updateBuyer(String id, AuthorizedOrg buyer) {
        return microservice.updateBuyer(id, buyer);
    }

    public FundingSourceWrapper getFundingSourceById(String id) {
        return microservice.getFundingSourceById(id);
    }

    public FundingSource retireFundingSource(String id) {
        return microservice.retireFundingSource(id);
    }

    public FundingSource unRetireFundingSource(String id) {
        return microservice.unRetireFundingSource(id);
    }

    public FundingSource expireFundingSource(String id) {
        return microservice.expireFundingSource(id);
    }

    public ProcessingBalance getFundingNodeById(String id) {
        return microservice.getFundingNodeById(id);
    }

    public ProcessingBalance retireFund(FundingNode node) {
        return microservice.retireFund(node);
    }

    public ProcessingBalance unretireFund(FundingNode node) {
        return microservice.unretireFund(node);
    }

    public ProcessingBalance updateFundingNode(FundingNode node) {
        return microservice.updateFundingNode(node);
    }

    public ProcessingBalance getParentProcessingBalance(String childId) {
        return microservice.getParentProcessingBalance(childId);
    }

    public List<ProcessingBalance> getFundingNodeChildren(String id) {
        return microservice.getFundingNodeChildren(id);
    }

    public List<ProcessingBalance> getFundingNodesByBuyer(String id) {
        return microservice.getFundingNodesByBuyer(id);
    }

    public List<FundingNodeConfig> getAllowCreateFundingNodeConfigs() {
        FinancialSystem financialSystem = getFinancialSystemByNodeId(currentUserBT.getCurrentNodeId());
        return microservice.getAllowCreateFundingNodeConfigs(financialSystem.getId());
    }

    public FundingNodeConfig getFundingNodeConfigByType(String financialSystemId, EFundingSourceType type, EFundingSourceSubType subType) {
        return microservice.getFundingNodeConfigByType(financialSystemId, type, subType);
    }

    public List<String> getSubTypesByFinancialSystems() {
        List<String> financialSystems = new ArrayList<>();
        List<Organization> allNodes = getCurrentSiteOrganizations();
        for (Organization org : allNodes) {
            FinancialSystem financialSystem = getFinancialSystemByNodeId(org.getId());
            if (financialSystem != null && !financialSystems.contains(financialSystem.name)) {
                financialSystems.add(financialSystem.name);
            }
        }
        return microservice.getSubTypesByFinancialSystems(financialSystems);
    }

    public ProcessingBalance createFundingNodeChild(String id, FundingNodeChild child) {
        FundingNode parent = microservice.getFundingNodeOnly(id);
        // If not a funded program, use the Project funding source
        if (parent.fundingSourceRefs.size() == 1) {
            child.fundingSourceRef = parent.fundingSourceRefs.get(0);
        }
        child.retiredDate = parent.retiredDate;
        child.expiredDate = parent.expiredDate;
        child.closedDate = parent.closedDate;

        validateFundingNode(id, child);
        return microservice.createFundingNodeChild(id, child);
    }

    private void validateFundingNode(String id, FundingNodeChild child) {
        ProcessingBalance processingBalance = microservice.getFundingNodeById(id);
        if (ListUtil.isEmpty(processingBalance.fundingNode.fundingSourceRefs)) {
            throw new ApplicationException(String.format("Funding Node - %s does not have a related Funding Source", processingBalance.fundingNode.name));
        }
        String fundingSourceId = processingBalance.fundingNode.fundingSourceRefs.size() > 1
                ? child.fundingSourceRef.id : processingBalance.fundingNode.fundingSourceRefs.get(0).id;
        FundingSourceWrapper wrapper = microservice.getFundingSourceById(fundingSourceId);
        FundingSource fundingSource = wrapper.fundingSource;

        List<String> childIds = new ArrayList<>();
        for (AuthorizedOrg authorizedOrg : child.authorizedOrgs) {
            childIds.add(authorizedOrg.nodeRef.id);
        }

        if (!organizationService.areAllChildren(fundingSource.owningOrg.id, childIds)) {
            if (EFundingSourceSubType.MEMORANDUM.equals(fundingSource.subType) &&
                childIds.size() == 1 &&
                    fundingSource.owningOrg.id.equals(childIds.get(0))
            ) {// OK
            } else {
                throw new FundingNodeValidationException("Buyer is not a parent of the FundingSource's organization");
            }
        }
        validateWbsCostCenter(fundingSource, child);
        validateAssemblageExpenseCanter(child);
    }

    void validateWbsCostCenter(FundingSource fundingSource, FundingNodeChild child) {
        if (EFundingSourceSubType.WBS.equals(fundingSource.subType)) {
            String responsibleCostCenter = fundingSource.getFinancialSystemField(EFundingSourceFieldName.RESPONSIBLE_COST_CENTER.displayText);
            String requestingCostCenter = fundingSource.sloa.costCenter;

            boolean fundingSourceCostCentersMatch = (responsibleCostCenter != null && requestingCostCenter != null
                && responsibleCostCenter.equals(requestingCostCenter));
            if (!fundingSourceCostCentersMatch) {
                for (AuthorizedOrg aorg : child.authorizedOrgs) {
                    if (requestingCostCenter != null && !requestingCostCenter.equals(aorg.costCenter)) {
                        throw new ApplicationException("WBS cost center must equal Buyer cost center");
                    }
                }
            }
        }
    }

    void validateAssemblageExpenseCanter(FundingNodeChild child) {
        if (child.usage != null && child.usage.contains("Assemblage")) {
            if (!(child.usage.contains("Pharmacy") && child.usage.contains("Non-Pharmacy"))) {
                throw new ApplicationException("A fund with an Assemblage usage must also have Pharmacy and Non-Pharmacy usages");
            }
        }
    }

    public ProcessingBalance updateFundingNodeChild(String id, FundingNodeChild node) {
        validateFundingNode(id, node);
        return microservice.updateFundingNodeChild(id, node);
    }

    public FundingNode addChildToFundingNode(String id, FundingNodeChild node) {
        return microservice.addChildToFundingNode(id, node);
    }

    public List<String> getAllFundingNodeFiscalYears() {
        List<String> nodes = getCurrentOrganizationIds();
        return microservice.getAllFundingNodeFiscalYears(nodes);
    }

    public List<FundingNode> getAllFundingNodes(String fiscalYear) {
        return microservice.getAllFundingNodes(fiscalYear);
    }

    public FundingNode removeBuyerFromFund(String fundParentId, String buyerId) {
        return microservice.removeBuyerFromFund(fundParentId, buyerId);
    }

    public List<AuthorizedNode> getAuthorizedNodes(String organizationNodeId) {
        return microservice.getAuthorizedNodes(organizationNodeId);
    }

    public List<AuthorizedNode> getAuthorizedNodes(String organizationNodeId, String financialSystemId, CommodityCodeRef commodityCodeRef) {
        // if organizationNodeId = null, try to get it from the user's currentNodeRef
        if (organizationNodeId == null) {
            CurrentUser currentUser = currentUserBT.getCurrentUser();
            organizationNodeId = currentUser.profile.currentNodeRef.getId();
        }

        // If financialSystemId = null, then get financialSystemId based off organizationNodeId
        if (financialSystemId == null) {
            FinancialSystem financialSystem = this.getFinancialSystemByNodeId(organizationNodeId);
            financialSystemId = financialSystem.getId();
        }

        if (commodityCodeRef == null) {
            throw new ApplicationException("CommodityCodeRef was not supplied.");
        }

        return microservice.getAuthorizedNodes(organizationNodeId, financialSystemId, commodityCodeRef);
    }

    public AuthorizedNode getDefaultAuthorizedNode(String organizationNodeId) {
        return microservice.getDefaultAuthorizedNode(organizationNodeId);
    }

    public FundingNode setDefaultFund(String orgId, String fundingChildId, String resetFlag) {
        return microservice.setDefaultFund(orgId, fundingChildId, resetFlag);
    }

    public List<Organization> getAvailableSiteNodes() {
        return getCurrentSiteOrganizations();
    }

    public List<FundingNode> getFundingOrgsForCurrentNodeId(String parentNodeId) {
         ProcessingBalance processingBalance = microservice.getFundingNodeById(parentNodeId);
        FundingNode parentNode = processingBalance.fundingNode;

        List<FundingNode> nodes;
        if (ListUtil.isEmpty(parentNode.fundingSourceRefs)) {
            throw new ApplicationException(String.format("Funding Node - %s does not have a related Funding Source", parentNode.name));
        }

        if (EFundingSourceSubType.MEMORANDUM.equals(parentNode.fundingSourceRefs.get(0).subType)) {
            nodes = getNodesForMemorandum(parentNode);
        } else {
            nodes = getNodesForBuyers(parentNode);
        }
        return nodes;
    }

    public List<FundingNode> getFundingNodesByOrgAndCostCenter(String orgId, String costCenter) {
        return microservice.getFundingNodesByOrgAndCostCenter(orgId, costCenter);
    }

    public List<FundingNode> getFundingNodesByOrgId(String orgId) {
        return microservice.getFundingNodesByOrgId(orgId);
    }

    List<FundingNode> getNodesForMemorandum(FundingNode parentNode) {
        List<FundingNode> nodes = microservice.getNewChildFundingNodes(parentNode.getId(), 1);

        FundingNode node = nodes.get(0);
        if (ListUtil.isEmpty(node.fundingSourceRefs)) {
            throw new ApplicationException(String.format("Funding Node - %s does not have a related Funding Source", node.name));
        }
        FundingSourceRef fundingSourceRef = parentNode.fundingSourceRefs.get(0);
        AuthorizedOrg authorizedOrg = new AuthorizedOrg(fundingSourceRef.owningOrg, fundingSourceRef.sloa.costCenter);
        node.authorizedOrgs.add(authorizedOrg);
        return nodes;
    }

    List<FundingNode> getNodesForBuyers(FundingNode parentNode) {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        String currentNodeId = currentUser.profile.currentNodeRef.id;

        List<Buyer> buyers = buyerService.getBuyersForNode(currentNodeId);
        List<Buyer> filteredBuyers = buyers;

        List<FundingNode> nodes = microservice.getNewChildFundingNodes(parentNode.getId(), filteredBuyers.size());
        for (int i = 0; i < filteredBuyers.size(); i++) {
            List<AuthorizedOrg> authorizedOrgs = new ArrayList<>();
            nodes.get(i).authorizedOrgs = authorizedOrgs;
            Buyer buyer = filteredBuyers.get(i);
            AuthorizedOrg authorizedOrg = new AuthorizedOrg(buyer.nodeRef, buyer.costCenter);
            authorizedOrgs.add(authorizedOrg);
        }
        return nodes;
    }

    List<Buyer> filterBuyers(List<Buyer> buyers, List<String> filteredOrgs) {
        List<Buyer> list = new ArrayList<>();
        for (Buyer buyer : buyers) {
            String id = buyer.nodeRef.id;
            if (filteredOrgs.contains(id)) {
                list.add(buyer);
            }
        }
        return list;
    }

    List<String> getBuyerOrgList(List<Buyer> buyers) {
        List<String> buyerOrgs = new ArrayList<>();
        for (Buyer buyer : buyers) {
            buyerOrgs.add(buyer.nodeRef.id);
        }
        return buyerOrgs;
    }

    public ProcessingBalance getNewParentNode(String fundingSourceId) {
        return microservice.getNewParentNode(fundingSourceId);
    }

    public boolean checkFundingSourceIsDuplicate(FundingSource fundingSource) {
        return microservice.checkFundingSourceIsDuplicate(fundingSource);
    }

    public List<FundingNodeDTO> getMemorandumFunds(String organizationNodeId) {
        return microservice.getMemorandumFunds(organizationNodeId);
    }

    public OrganizationRef getLogBuyer(String orgId) {
        OrganizationRef logBuyerRef = null;

        List<Buyer> buyers = buyerService.getBuyersForNode(orgId);
        if (CollectionUtils.isNotEmpty(buyers)) {
            logBuyerRef = buyers.stream().filter(buyer -> StringUtils.containsIgnoreCase(buyer.nodeRef.name, "LOG"))
                    .map(buyer -> buyer.nodeRef).findFirst().orElse(null);
        }

        return logBuyerRef;
    }

    public List<AssemblageFinanceData> getAssemblageFinanceData(String buyerOrganizationId, boolean isLog) {
        return microservice.getAssemblageFinanceData(buyerOrganizationId, isLog);
    }

    public List<FundingNodeBalance> getBalancesByChildId(List<String> fundingNodeChildIds) {
        return microservice.getBalancesByChildId(fundingNodeChildIds);
    }

}
