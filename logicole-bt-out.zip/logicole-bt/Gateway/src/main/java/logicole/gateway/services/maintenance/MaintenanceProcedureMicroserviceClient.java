package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.IMaintenanceProcedureMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class MaintenanceProcedureMicroserviceClient extends MicroserviceClient<IMaintenanceProcedureMicroserviceApi> {

    public MaintenanceProcedureMicroserviceClient() {
        super(IMaintenanceProcedureMicroserviceApi.class, "logicole-maintenance");
    }

    @Produces
    public IMaintenanceProcedureMicroserviceApi getIMaintenanceProcedureMicroserviceApi() {
        return createClient();
    }

}
