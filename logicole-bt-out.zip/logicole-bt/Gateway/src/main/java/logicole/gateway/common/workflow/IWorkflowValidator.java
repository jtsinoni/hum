package logicole.gateway.common.workflow;

import logicole.common.datamodels.workflow.WorkflowState;
import logicole.common.servers.business.RequestWorkflowData;

public interface IWorkflowValidator<T> {

    void validate(WorkflowState workflowState, T workflowItem);

    default void validate(WorkflowState workflowState, T workflowItem, RequestWorkflowData requestWorkflowData) {
        this.validate(workflowState, workflowItem);
    }

}
