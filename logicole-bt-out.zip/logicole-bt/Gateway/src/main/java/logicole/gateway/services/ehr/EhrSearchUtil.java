package logicole.gateway.services.ehr;

import logicole.common.datamodels.ehr.product.EhrSearchCriteria;
import logicole.common.datamodels.search.filter.FilterElement;
import logicole.common.datamodels.search.filter.RequestFilter;
import logicole.common.datamodels.search.request.ESearchOperator;
import logicole.common.general.util.string.StringUtil;

import java.util.ArrayList;
import java.util.List;

public class EhrSearchUtil {
    public static String buildEhrSearchString(EhrSearchCriteria ehrSearchCriteria) {
        StringBuilder searchString = new StringBuilder();
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.description)) {
            searchString.append(ehrSearchCriteria.description + " ");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.enterpriseProductIdentifier)) {
            searchString.append(ehrSearchCriteria.enterpriseProductIdentifier + " ");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.ecn)) {
            searchString.append(ehrSearchCriteria.ecn + " ");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.itemId)) {
            searchString.append(ehrSearchCriteria.itemId + " ");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.packageUnit)) {
            searchString.append(ehrSearchCriteria.packageUnit + " ");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.modelNumber)) {
            searchString.append(ehrSearchCriteria.modelNumber + " ");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.manufacturer)) {
            searchString.append(ehrSearchCriteria.manufacturer + " ");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.manufacturerCatalogNumber)) {
            searchString.append(ehrSearchCriteria.manufacturerCatalogNumber + " ");
        }
        if (ehrSearchCriteria.unspscCode != null) {
            searchString.append(ehrSearchCriteria.unspscCode.toString() + " ");
        }
        return searchString.toString().trim();
    }

    public static List<String> buildAbiSearchFields(EhrSearchCriteria ehrSearchCriteria) {
        List<String> searchFields = new ArrayList<>();
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.description)) {
            searchFields.add("longItemDescription");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.enterpriseProductIdentifier)) {
            searchFields.add("enterpriseProductIdentifier");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.manufacturer)) {
            searchFields.add("manufacturer");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.manufacturerCatalogNumber)) {
            searchFields.add("manufacturerCatalogNumber");
        }
        if (ehrSearchCriteria.unspscCode != null) {
            searchFields.add("unspscCode");
        }
        return searchFields;
    }

    public static List<RequestFilter> buildEhrEquipmentFilters(EhrSearchCriteria ehrSearchCriteria) {
        List<RequestFilter> filters = new ArrayList<>();
        if (ehrSearchCriteria.isEhrEnabled != null) {
            RequestFilter requestFilter = new RequestFilter();
            requestFilter.operator = ESearchOperator.OR.operatorString;
            requestFilter.fieldValues = new ArrayList<>();
            FilterElement filterElement = new FilterElement();
            filterElement.field = "isEhrEnabled";
            filterElement.value = ehrSearchCriteria.isEhrEnabled ? "true" : "false";
            requestFilter.fieldValues.add(filterElement);
            filters.add(requestFilter);
        }

        // Add Site Org Id
        RequestFilter siteOrgFilter = new RequestFilter();
        siteOrgFilter.operator = ESearchOperator.OR.operatorString;
        siteOrgFilter.fieldValues = new ArrayList<>();
        FilterElement siteOrgElement = new FilterElement();
        siteOrgElement.field = "siteDodaac";
        siteOrgElement.value = ehrSearchCriteria.siteOrgId;
        siteOrgFilter.fieldValues.add(siteOrgElement);
        filters.add(siteOrgFilter);

        // Add Customer Org Id
        RequestFilter customerOrgFilter = new RequestFilter();
        customerOrgFilter.operator = ESearchOperator.OR.operatorString;
        customerOrgFilter.fieldValues = new ArrayList<>();
        FilterElement customerOrgElement = new FilterElement();
        customerOrgElement.field = "orgID";
        customerOrgElement.value = ehrSearchCriteria.customerOrgId;
        customerOrgFilter.fieldValues.add(customerOrgElement);
        filters.add(customerOrgFilter);

        return filters;
    }

    public static List<String> buildEquipmentSearchFields(EhrSearchCriteria ehrSearchCriteria) {
        List<String> searchFields = new ArrayList<>();
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.description)) {
            searchFields.add("product.longItemDescription");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.itemId)) {
            searchFields.add("itemId");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.manufacturer)) {
            searchFields.add("product.manufacturer");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.modelNumber)) {
            searchFields.add("product.commonModel");
        }
        if (!StringUtil.isEmptyOrNull(ehrSearchCriteria.ecn)) {
            // searchFields.add("meEcnId");
            // Field is not indexed, do not over ride anything
            searchFields = new ArrayList<>();
        }
        return searchFields;
    }
}
