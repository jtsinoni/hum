package logicole.gateway.services.finance;

import io.swagger.annotations.Api;
import logicole.common.datamodels.finance.ECommodityCodeUsageType;
import logicole.common.datamodels.finance.RefDataList;
import logicole.common.datamodels.finance.referencedata.AccountingClassificationRef;
import logicole.common.datamodels.finance.referencedata.CommodityCode;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.referencedata.CostCenterRef;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"financeReferenceData"})
@ApplicationScoped
@Path("/financeReferenceData")
public class FinanceReferenceDataRestApi extends ExternalRestApi<FinanceReferenceDataService> {

    @GET
    @Path("/getRefDataListByCollectionName")
    public RefDataList getRefDataListByCollectionName(@QueryParam("name") String name) {
        return service.getRefDataListByCollectionName(name);
    }

    @GET
    @Path("/getRefDataListByModule")
    public List<RefDataList> getRefDataListByModule(@QueryParam("module") String module) {
        return service.getRefDataListByModule(module);
    }

    @GET
    @Path("/getRefDataDetail")
    public List<Object> getRefDataDetail(@QueryParam("collectionName") String collectionName, @QueryParam("fundingSourceSubType") String fundingSourceSubType) {
        return service.getRefDataDetail(collectionName, fundingSourceSubType);
    }
    @POST
    @Path("/createReferenceData")
    public Object createReferenceData(@QueryParam("collectionName") String collectionName, Object referenceData) {
        return service.createReferenceData(collectionName, referenceData);
    }

    @POST
    @Path("/updateReferenceData")
    public Object updateReferenceData(@QueryParam("collectionName") String collectionName, Object referenceData) {
        return service.updateReferenceData(collectionName, referenceData);
    }

    @GET
    @Path("/deleteReferenceData")
    public boolean deleteReferenceData(@QueryParam("collectionName") String collectionName, @QueryParam("id") String id) {
        return service.deleteReferenceData(collectionName, id);
    }


    @GET
    @Path("/getCommodityClassByName")
    public List<CommodityCode> getByCommodityClassName(@QueryParam("financialSystemId") String financialSystemId,
                                                       @QueryParam("commodityClassName") String commodityClassName) {
        return service.getCommodityCodesByName(financialSystemId, commodityClassName);
    }

    @GET
    @Path("/getFullCommodityCodesByUsage")
    public List<CommodityCode> getFullCommodityCodesByUsage(@QueryParam("commodityUsageType") String commodityUsageType) {
        return service.getFullCommodityCodesByUsage(ECommodityCodeUsageType.valueOf(commodityUsageType.toUpperCase()));
    }

    @GET
    @Path("/getCommodityCodesByUsage")
    public List<CommodityCodeRef> getCommodityCodesByUsage(@QueryParam("commodityUsageType") String commodityUsageType) {
        return service.getCommodityCodesByUsage(ECommodityCodeUsageType.valueOf(commodityUsageType.toUpperCase()));
    }

    @GET
    @Path("/getCommodityCodesBySystemAndUsage")
    public List<CommodityCodeRef> getCommodityCodesBySystemAndUsage(@QueryParam("financialSystemId") String financialSystemId,
                                                                    @QueryParam("commodityUsageType") String commodityUsageType) {
        return service.getCommodityCodesBySystemAndUsage(financialSystemId, ECommodityCodeUsageType.valueOf(commodityUsageType.toUpperCase()));
    }

    @GET
    @Path("/getCommodityCodeById")
    public CommodityCodeRef getCommodityCodeById(@QueryParam("commodityCodeId") String commodityCodeId) {
        return service.getCommodityCodeById(commodityCodeId);
    }

    @GET
    @Path("/getCostCentersFromTemplate")
    public List<CostCenterRef> getCostCentersFromTemplate(@QueryParam("financialSystemId") String financialSystemId,
                                                          @QueryParam("fundIdentificationCode") String fundIdentificationCode,
                                                          @QueryParam("fiscalYear") String fiscalYear,
                                                          @QueryParam("accountingClassificationCode") String acctClassCode) {
        return service.getCostCentersFromTemplate(financialSystemId, fundIdentificationCode, fiscalYear, acctClassCode);
    }

    @GET
    @Path("/getAccountingClassificationsFromTemplate")
    public List<AccountingClassificationRef> getAccountingClassificationsFromTemplate(@QueryParam("financialSystemId") String financialSystemId,
                                                                          @QueryParam("fundIdentificationCode") String fundIdentificationCode,
                                                                          @QueryParam("fiscalYear") String fiscalYear) {
        return service.getAccountingClassificationsFromTemplate(financialSystemId, fundIdentificationCode, fiscalYear);
    }
}
