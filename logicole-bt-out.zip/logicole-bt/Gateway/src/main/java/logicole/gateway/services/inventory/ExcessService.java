package logicole.gateway.services.inventory;

import logicole.apis.inventory.IExcessMicroserviceApi;
import logicole.common.datamodels.inventory.Excess;
import logicole.common.datamodels.inventory.ExcessRequest;
import logicole.common.datamodels.inventory.InventorySystem;
import logicole.common.datamodels.inventory.PotentialExcess;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.organization.OrganizationService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class ExcessService extends BaseGatewayService<IExcessMicroserviceApi> {

    @Inject
    OrganizationService organizationService;

    @Inject
    LocationService locationService;


    public ExcessService() {
        super("Excess");
    }


    public Excess getExcessDetailById(String excessId) {
        return microservice.getExcessDetailById(excessId);
    }

    public List<Excess> getExcessReportsByOrgId(String reportingOrganizationId) {
        return microservice.getExcessReportsByOrgId(reportingOrganizationId);
    }

    public List<Excess> getExcessRequestsByOrgId(String requestingOrganizationId) {
        return microservice.getExcessRequestsByOrgId(requestingOrganizationId);
    }

    public List<Excess> getAllActiveExcessReports() {
        return microservice.getAllActiveExcessReports();
    }

    public List<Excess> getAllExcessRequests() {
        return microservice.getAllExcessRequests();
    }

    public List<Excess> getExcessDelinquentLogBayRequests() {
        return microservice.getExcessDelinquentLogBayRequests();
    }

    public List<Excess> getExcessLogBayHistory() {
        return microservice.getExcessLogBayHistory();
    }

    public List<Excess> getExcessLogBayShippingStatus() {
        return microservice.getExcessLogBayShippingStatus();
    }

    public List<PotentialExcess> getPotentialExcessByOrgId(String orgId) {
        return microservice.getPotentialExcessByOrgId(orgId);
    }

    public List<Excess> getMyExcessReportsWithActiveRequests() {
        return microservice.getMyExcessReportsWithActiveRequests(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
    }

    public List<Excess> getActiveExcessRequestsFromCustomers() {
        String siteOrganizationId = null;
        List<Excess> excessList = new ArrayList<>();    //  Will remain empty if we start above "Site".
        Organization organization = organizationService.getOrganization(currentUserBT.getCurrentNodeId());
        if (organization.nodeTypeRef.name.equals("Site")) {
            siteOrganizationId = organization.getId();
        } else if (organization.nodeTypeRef.name.equals("Customer")) {
            organization = organizationService.getOrganization(organization.getParentId());
            if (organization.nodeTypeRef.name.equals("Department")) {
                organization = organizationService.getOrganization(organization.getParentId());
                if (organization.nodeTypeRef.name.equals("Site")) {
                    siteOrganizationId = organization.getId();
                }
            }
        }
        if (!StringUtil.isEmptyOrNull(siteOrganizationId)) {
            excessList = microservice.getActiveExcessRequestsFromCustomers(siteOrganizationId);
        }
        return excessList;  //  May be empty!
    }

    Excess acceptExcessRequestFromCustomer(Excess excess,
                                           Integer reportIndex,
                                           Integer requestIndex) {
        return microservice.acceptExcessRequestFromCustomer(excess, reportIndex, requestIndex);
    }

    Excess rejectExcessRequestFromCustomer(Excess excess,
                                           Integer reportIndex,
                                           Integer requestIndex) {
        return microservice.rejectExcessRequestFromCustomer(excess, reportIndex, requestIndex);
    }

    public List<Excess> searchExcessItems(String searchString,
                                          Boolean hasQuantityAvailable,
                                          Boolean isActive) {
        String requestorsOrganizationId = currentUserBT.getCurrentNodeId();
        Organization organization = organizationService.getOrganization(requestorsOrganizationId);
        String requestorsMilSvcId = null;
        if (organization != null) {
            requestorsMilSvcId = organization.milServiceId;
        } else {
            throw new ApplicationException("Unable to get organization for id " + requestorsOrganizationId + ".");
        }
        return microservice.searchExcessItems(searchString, hasQuantityAvailable, isActive, requestorsOrganizationId, requestorsMilSvcId);
    }

    public Excess cancelExcessRequest(String excessId) {
        return microservice.cancelExcessRequest(excessId);
    }

    public Excess requestExcess(Excess excess,
                                Integer qtyRequested,
                                String requestingOrganizationId) {
        OrganizationRef requestingOrgRef = organizationService.getOrganizationRefById(requestingOrganizationId);
        Organization organization = organizationService.getOrganization(requestingOrgRef.id);
        ExcessRequest excessRequest = new ExcessRequest();
        excessRequest.requestedQty = qtyRequested;
        excessRequest.requestingOrgRef = requestingOrgRef;
        excessRequest.isRequestForLog = (organization.nodeTypeRef.name.equals("Site"));     //  TODO:  Fix this once they decide how we tell Log
        excess.excessRequests.add(excessRequest);
        return microservice.requestExcess(excess);
    }

    public Excess reportExcess(PotentialExcess potentialExcess) {
        InventorySystem inventorySystem = locationService.getInventorySystemById(potentialExcess.inventorySystemRef.id);
        Organization organization = organizationService.getOrganization(inventorySystem.nodeRef.id);
        String serviceId = organization.milServiceId;
        return microservice.reportExcess(potentialExcess, serviceId);
    }

    public Excess adjustExcessQty(Excess excess) {
        return microservice.adjustExcessQty(excess);
    }

    public Excess returnToDRMO(Excess excess) {
        return microservice.returnToDRMO(excess);
    }

}
