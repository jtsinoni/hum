package logicole.gateway.services.organization;

import logicole.apis.organization.IOrganizationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class OrganizationMicroserviceClient extends MicroserviceClient<IOrganizationMicroserviceApi> {
    public OrganizationMicroserviceClient() {
        super(IOrganizationMicroserviceApi.class, "logicole-organization");
    }

    @Produces
    public IOrganizationMicroserviceApi getIOrganizationMicroserviceApi() {
        return createClient();
    }

}
