package logicole.gateway.common;

import logicole.common.crossservice.mdb.BaseMDB;
import logicole.common.datamodels.DataUploadObject;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.notification.EmailMessage;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.constants.JmsConstants;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.EDateFormat;
import logicole.common.general.util.JSONUtil;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.system.NotificationService;
import logicole.gateway.services.user.UserService;

import javax.inject.Inject;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.TextMessage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public abstract class FileProcessorMDB extends BaseMDB {

    @Inject
    private FileManagerAdminService fileManagerAdminService;
    @Inject
    private JMSContext jmsContext;
    @Inject
    private JSONUtil jsonUtil;
    @Inject
    private UserService userService;
    @Inject
    private NotificationService notificationService;


    public void sendToQueue(String type, Message message, String queueName) throws ApplicationException {

        TextMessage textMessage = (TextMessage) message;
        String fileId = null;
        try {
            fileId = textMessage.getText();
        } catch (JMSException e) {
            throw new ApplicationException("Unable to convert message into TextMessage object: " + e.getMessage());
        }

        try {
            byte[] fileContents = fileManagerAdminService.getFileContentsAsPrimitiveByte(fileId);
            FileManager fileInfo = fileManagerAdminService.getFileInfo(fileId);
            UserProfile user = userService.getUserProfileById(fileInfo.uploadedBy);
            String input = new String(fileContents);
            BufferedReader inputReader = new BufferedReader(new StringReader(input));
            String inputLine = null;

            while ((inputLine = inputReader.readLine()) != null && inputLine.length() > 0) {
                try {
                    DataUploadObject uploadObject = new DataUploadObject();
                    uploadObject.fileType = type;
                    uploadObject.data = inputLine;
                    uploadObject.count = 1;

                    String serializedData = jsonUtil.serialize(uploadObject);
                    Queue queue = jmsContext.createQueue(queueName);
                    Message textMessage2 = jmsContext.createTextMessage(serializedData);
                    JMSProducer jmsProducer = jmsContext.createProducer();
                    jmsProducer.setJMSType(JmsConstants.JMS_TYPE_DATA_IMPORT);
                    logger.info("STARTING - record upload: " + uploadObject.count);
                    jmsProducer.send(queue, textMessage2);
                } catch (IOException ioe) {
                    sendEmail(false,fileInfo.uploadedFileName, user);
                    throw new ApplicationException(
                            "Was not able to extract file from request: " + ioe.getMessage());
                }
            }
            inputReader.close();
            fileManagerAdminService.removeFile(fileId);
            sendEmail(true,fileInfo.uploadedFileName, user);

        } catch (Exception e) {
            throw new ApplicationException("Exception occurred processing file: " + e.getMessage());
        }
    }

    public List<String> sendToQueueDmisIds(String type, Message message, String queueName) throws ApplicationException {
        List<String> dmisIds = new ArrayList<>();
        TextMessage textMessage = (TextMessage) message;
        String fileId = null;
        try {
            fileId = textMessage.getText();
        } catch (JMSException e) {
            throw new ApplicationException("Unable to convert message into TextMessage object: " + e.getMessage());
        }

        try {
            byte[] fileContents = fileManagerAdminService.getFileContentsAsPrimitiveByte(fileId);
            FileManager fileInfo = fileManagerAdminService.getFileInfo(fileId);
            UserProfile user = userService.getUserProfileById(fileInfo.uploadedBy);
            String input = new String(fileContents);
            BufferedReader inputReader = new BufferedReader(new StringReader(input));
            String inputLine = null;

            while ((inputLine = inputReader.readLine()) != null && inputLine.length() > 0) {
                try {
                    DataUploadObject uploadObject = new DataUploadObject();
                    uploadObject.fileType = type;
                    uploadObject.data = inputLine;
                    String[] tokens = uploadObject.data.split("\\|");
                    dmisIds.add(tokens[0]);
                    uploadObject.count = 1;

                    String serializedData = jsonUtil.serialize(uploadObject);
                    Queue queue = jmsContext.createQueue(queueName);
                    Message textMessage2 = jmsContext.createTextMessage(serializedData);
                    JMSProducer jmsProducer = jmsContext.createProducer();
                    jmsProducer.setJMSType(JmsConstants.JMS_TYPE_DATA_IMPORT);
                    logger.info("STARTING - record upload: " + uploadObject.count);
                    jmsProducer.send(queue, textMessage2);
                } catch (IOException ioe) {
                    sendEmail(false,fileInfo.uploadedFileName, user);
                    throw new ApplicationException(
                            "Was not able to extract file from request: " + ioe.getMessage());
                }
            }
            inputReader.close();
            fileManagerAdminService.removeFile(fileId);
            sendEmail(true,fileInfo.uploadedFileName, user);
            return dmisIds;

        } catch (Exception e) {
            throw new ApplicationException("Exception occurred processing file: " + e.getMessage());
        }
    }

    public void sendEmail(boolean success, String uploadedFileName, UserProfile user) throws ApplicationException{
        EmailMessage emailMessage = new EmailMessage();
        String emailBodyString = "";
        EDateFormat dateFormat = EDateFormat.FRIENDLY;
        try {
            if (success) {
                emailMessage.subject = "LogiCole - Data Upload - Success";
            } else {
                emailMessage.subject = "LogiCole - Data Upload - Fail";
            }
            emailBodyString = fileManagerAdminService.getEmailBodyString(success);
            emailBodyString = emailBodyString.replaceAll("@NAME", user.firstName);
            emailBodyString = emailBodyString.replaceAll("@UPLOAD_DATE", dateFormat.format(new Date()));
            emailBodyString = emailBodyString.replaceAll("@FILE_NAME", uploadedFileName);

            emailMessage.bcc.addAll(new ArrayList<String>(Arrays.asList(user.email)));

            emailMessage.body = emailBodyString;
        } catch (Exception e) {
            throw new ApplicationException("Could not load email template");
        }
        notificationService.sendEmail(emailMessage);
    }

    // Override this method in subclasses
    public void processRecord(Message message) throws ApplicationException {

    }
}
