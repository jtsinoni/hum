package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiSearchMicroserviceApi;
import logicole.common.datamodels.abi.BarcodeInformation;
import logicole.common.datamodels.abi.SiteEquipment;
import logicole.common.datamodels.abi.staging.AbiCatalogRecord;
import logicole.common.datamodels.abi.staging.SearchAbiInput;
import logicole.common.datamodels.search.request.DmlesSearchRequest;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.product.ProductService;
import logicole.gateway.services.equipment.EquipmentRecordService;
import logicole.gateway.services.search.SearchService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;

@ApplicationScoped
public class AbiSearchService extends BaseGatewayService<IAbiSearchMicroserviceApi> {

    @Inject
    SearchService serviceSearch;

    @Inject
    AbiCatalogService abiCatalogService;

    @Inject
    EquipmentRecordService equipmentRecordService;

    public AbiSearchService() {
        super("AbiRecord");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public String getAbiRecordESResults(SearchAbiInput searchAbiInput) throws IOException, ApplicationException {
        DmlesSearchRequest searchRequest = microservice.buildAbiSearchRequest(searchAbiInput);
        return serviceSearch.getSearchResults(searchRequest);
    }

    public String parseBarcodeSearchString(String barcodeString) throws ApplicationException {
        return microservice.parseBarcodeSearchString(barcodeString);
    }

    public BarcodeInformation parseBarcodeString(@QueryParam("barcodeString") String barcodeString) throws ApplicationException {
        return microservice.parseBarcodeString(barcodeString);
    }

    public List<String> getCommodityTypes() {
        return microservice.getCommodityTypes();
    }

    public List<String> getProductNouns() {
        return microservice.getProductNouns();
    }

    public List<String> getProductTypes() {
        return microservice.getProductTypes();
    }

    public List<String> getUnspscSegments() {
        return microservice.getUnspscSegments();
    }

    public List<SiteEquipment> getEquipmentByEnterpriseId(String enterpriseProductIdentifier) {
        List<SiteEquipment> siteEquipmentList = new ArrayList<>();

        final AbiCatalogRecord abiCatalogRecord = abiCatalogService.getAbiCatalogRecordByEnterpriseProductIdentifier(enterpriseProductIdentifier);
        if (abiCatalogRecord.ecriGuid == null){
            return siteEquipmentList;
    }

        siteEquipmentList = equipmentRecordService.getSiteEquipmentByEcriGuid(abiCatalogRecord.ecriGuid);

        return siteEquipmentList;
    }

    public DmlesSearchRequest buildAbiSearchRequest(SearchAbiInput searchAbiInput) {
        return microservice.buildAbiSearchRequest(searchAbiInput);
    }
}
