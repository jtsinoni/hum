package logicole.gateway.services.user;

import io.swagger.annotations.Api;
import logicole.common.datamodels.Configuration;
import logicole.common.datamodels.user.*;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.UserNotFoundException;
import logicole.gateway.rest.ExternalRestApi;

import java.util.Date;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Api(tags = {"User"})
@ApplicationScoped
@Path("/user")
public class UserRestApi extends ExternalRestApi<UserService> {

    @GET
    @Path("/logIn")
    public LoginCredential logIn() {
        LoginCredential loginCredential = service.logIn();


        return loginCredential;
    }

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/cleanUpDevProfiles")
    public Boolean cleanUpDevProfiles() {
        return service.cleanUpDevProfiles();
    }

    @GET
    @Path("/getUserProfileById")
    public UserProfile getUserProfileById(@QueryParam("id") String id) {
        return service.getUserProfileById(id);
    }

    @GET
    @Path("/getBackupUserProfileById")
    public UserProfile getBackupUserProfileById(@QueryParam("id") String id) {
        return service.getBackupUserProfileById(id);
    }

    @GET
    @Path("/getUsersCurrentProfile")
    public CurrentUser getUsersCurrentProfile(@QueryParam("pkiDn") String pkiDn) {
        return service.getCurrentUserByPkiDn(pkiDn);
    }

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path(("/getCntActiveUserProfiles"))
    public String getCntActiveUserProfiles(@QueryParam("pkiDn") String pkiDn) {
        return service.getCntActiveUserProfiles(pkiDn);
    }

    @GET
    @Path("/getActiveUserProfiles")
    public List<UserProfile> getActiveUserProfiles() {
        return service.getActiveUserProfiles();
    }

    @GET
    @Path("/getCurrentProfileRoleRefs")
    public List<RoleRef> getCurrentProfileRoleRefs() {
        return service.getCurrentProfileRoleRefs();
    }

    @GET
    @Path("/getCurrentProfileAssignableRoleRefs")
    public List<RoleRef> getCurrentProfileAssignableRoleRefs() {
        return service.getCurrentProfileAssignableRoleRefs();
    }

    @GET
    @Path("/getUserProfilesByPkiDn")
    public List<UserProfile> getUserProfilesByPkiDn(@QueryParam("pkiDn") String pkiDn) {
        return service.getUserProfilesByPkiDn(pkiDn);
    }

    @GET
    @Path("/logOut")
    public Boolean logOut() {
        return service.logOut();
    }

    @GET
    @Path("/setCurrentProfile")
    public CurrentUser setCurrentProfile(@QueryParam("id") String id) throws ApplicationException {
        return service.setCurrentProfile(id);
    }

    @GET
    @Path("/setCurrentOrganizationRef")
    public CurrentUser setCurrentOrganizationRef(@QueryParam("id") String id) {
        return service.setCurrentOrganizationRef(id);
    }

    @GET
    @Path("/getPendingUserProfiles")
    public List<UserProfile> getPendingUserProfiles() {
        return service.getPendingUserProfiles();
    }

    @GET
    @Path("/getApprovedUserProfiles")
    public List<UserProfile> getApprovedUserProfiles(@QueryParam("userStatus") String userStatus,
                                                     @QueryParam("managedByOption") String managedByOption) throws ApplicationException {
        return service.getApprovedUserProfiles(userStatus, managedByOption);
    }

    @POST
    @Path("/addProfile")
    public UserProfile addProfile(UserProfile userProfile) throws ApplicationException {
        return service.addProfile(userProfile);
    }


    @GET
    @Path("/deleteUserProfile")
    public UserProfile deleteUserProfile(@QueryParam("userProfileId") String userProfileId, @QueryParam("reason") String reason) {
        return service.deleteUserProfile(userProfileId, reason);
    }

    @GET
    @Path("/renewUserProfile")
    public UserProfile renewUserProfile(@QueryParam("userProfileId") String userProfileId,
                                        @QueryParam("newExpirationDate") Date newExpirationDate) throws ApplicationException {
        return service.renewUserProfile(userProfileId, newExpirationDate);
    }

    @GET
    @Path("/getCurrentProfile")
    public CurrentUser getCurrentProfile() {
        return service.getCurrentProfile();
    }

    @GET
    @Path("/getProfilesByEmail")
    public List<UserProfile> getProfilesByEmail(@QueryParam("email") String email) {
        return service.getProfilesByEmail(email);
    }

    @GET
    @Path("/getUserProfile")
    public UserProfile getUserProfile() {
        return service.getUserProfile();
    }

    @GET
    @Path("/lockUserProfile")
    public UserProfile lockUserProfile(@QueryParam("userProfileId") String userProfileId) {
        return service.lockUserProfile(userProfileId);
    }

    @GET
    @Path("/unlockUserProfile")
    public UserProfile unlockUserProfile(@QueryParam("userProfileId") String userProfileId) {
        return service.unlockUserProfile(userProfileId);
    }

    @POST
    @Path("/updateProfileByAdmin")
    public UserProfile updateProfileByAdmin(AdminProfileUpdate profile) {
        return service.updateProfileByAdmin(profile);
    }

    @GET
    @Path("/isOwnProfileEditingAllowed")
    public boolean isOwnProfileEditingAllowed() {
        return service.isOwnProfileEditingAllowed();
    }

    @POST
    @Path("/saveUserPermissions")
    public UserProfile saveUserPermissions(UserProfile userProfile) {
        return service.saveUserPermissions(userProfile);
    }

    @POST
    @Path("/saveUserRoles")
    public UserProfile saveUserRoles(UserProfile userProfile) {
        return service.saveUserRoles(userProfile);
    }

    @POST
    @Path("/saveUserAssignableRoles")
    public UserProfile saveUserAssignableRoles(UserProfile userProfile) {
        return service.saveUserAssignableRoles(userProfile);
    }

    @GET
    @Path("/getRoleIdsWithAssignableRoles")
    public List<String> getRoleIdsWithAssignableRoles() {
        return service.getRoleIdsWithAssignableRoles();
    }

    @GET
    @Path("/suspendUserProfile")
    public UserProfile suspendUserProfile(@QueryParam("userProfileId") String userProfileId,
                                          @QueryParam("startDate") Date startDate, @QueryParam("endDate") Date endDate) {
        return service.suspendUserProfile(userProfileId, startDate, endDate);
    }

    @POST
    @Path("/updatePkiDnForUser")
    public UserProfile updatePkiDnForUser(String updateId) throws ApplicationException {
        return service.updatePkiDnForUser(updateId);
    }

    @POST
    @Path("/updateProfileAccess")
    public UserProfile updateProfileAccess(UserProfile userProfile) throws ApplicationException, UserNotFoundException {
        return service.updateProfileAccess(userProfile);
    }

    @POST
    @Path("/updateMyProfileInfo")
    public UserProfile updateMyProfileInfo(MyProfileUpdate profile) {
        return service.updateMyProfileInfo(profile);
    }

    @GET
    @Path("/getUserByPkiDn")
    public List<UserProfile> getUserByPkiDn(@QueryParam("pkiDn") String pkiDn) {
        return service.getUserByPkiDn(pkiDn);
    }

    @GET
    @Path("/requestPkiDnUpdate")
    public UserProfile requestPkiDnUpdate(@QueryParam("userEmail") String userEmail) throws ApplicationException {
        return service.requestPkiDnUpdate(userEmail);
    }

    @POST
    @Path("/updateUserProfilePKIDN")
    public UserProfile updateUserProfilePKIDN(UserProfile userProfile) {
        return service.updateUserProfilePKIDN(userProfile);
    }

    @POST
    @Path("/cancelPkiDnUpdate")
    public UserProfile cancelPkiDnUpdate(String updateId) throws ApplicationException {
        return service.cancelPkiDnUpdate(updateId);
    }

    @GET
    @Path("/getCurrentUserProfileByUpdateId")
    public UserProfile getCurrentUserProfileByUpdateId(@QueryParam("updateId") String updateId) throws ApplicationException {
        return service.getCurrentUserProfileByUpdateId(updateId);
    }

    @GET
    @Path("/getUserDashboardStats")
    public UserDashboardInfo getUserDashboardStats(@QueryParam("managedBy") String managedBy) {
        return service.getUserDashboardStats(managedBy);
    }

    @POST
    @Path("/getUsersWithRoleRefs")
    public List<UserProfile> getUsersWithRoleRefs(List<String> roleIds) {
        return service.getUsersWithRoleRefs(roleIds);
    }

    @GET
    @Path("/getUsersAtNodeWithRole")
    public List<UserProfile> getUsersAtNodeWithRole(@QueryParam("nodeId") String nodeId, @QueryParam("roleId") String roleId) {
        return service.getUsersAtNodeWithRole(nodeId, roleId);
    }

    @GET
    @Path("/clearCurrentUserFromCache")
    public void clearCurrentUserFromCache() {
        service.clearCurrentUserFromCache();
    }

    @GET
    @Path("/getAllConfigurations")
    public List<Configuration> getAllConfigurations() {
        return service.getAllConfigurations();
    }

    @POST
    @Path("/addUpdateConfiguration")
    public Configuration addUpdateConfiguration(Configuration configuration) {
        return service.addUpdateConfiguration(configuration);
    }

    @GET
    @Path("/getConfiguration")
    public Configuration getConfiguration(@QueryParam("id") String id) {
        return service.getConfiguration(id);
    }

    @GET
    @Path("/getConfigurationByName")
    public Configuration getConfigurationByName(@QueryParam("name") String name) {
        return service.getConfigurationByName(name);
    }

    @GET
    @Path("/getUserExpirationWarningMessage")
    public List<String> getUserExpirationWarningMessage() {
        return service.getUserExpirationWarningMessage();
    }

    @GET
    @Path("/cleanupAssignableRoles")
    public AssignableRolesCleanupResponseWrapper cleanupAssignableRoles(@QueryParam("isRunBackup") boolean isRunBackup) {
        return service.cleanupAssignableRoles(isRunBackup);
    }

    @GET
    @Path("/revertAppUserProfileCollection")
    public boolean revertAppUserProfileCollection() {
        return service.revertAppUserProfileCollection();
    }

    @GET
    @Path("/updateFMUserOrganizations")
    public void updateFMUserOrganizations(@QueryParam("makeBackup") boolean makeBackup) {
        service.updateFMUserOrganizations(makeBackup, false);
    }

    @GET
    @Path("/updateFMSiteUserOrganizations")
    public void updateFMSiteUserOrganizations(@QueryParam("makeBackup") boolean makeBackup) {
        service.updateFMUserOrganizations(makeBackup, true);
    }


    @GET
    @Path("/getFMUserOrganizationConversions")
    public List<FMUserOrganizationConversionResponse> getFMUserOrganizationConversions() {
        return service.getFMUserOrganizationConversions();
    }

    @GET
    @Path("/clearConversionResults")
    public Boolean clearConversionResults() {
        return service.clearConversionResults();
    }

    @GET
    @Path("/clearUserBackup")
    public Boolean clearUserBackup() {
        return service.clearUserBackup();
    }

}
