package logicole.gateway.services.maintenance;

import io.swagger.annotations.Api;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.maintenance.team.MaintenanceTeam;
import logicole.common.datamodels.maintenance.team.MaintenanceTeamRef;
import logicole.common.datamodels.maintenance.technician.EEmployeeType;
import logicole.common.datamodels.maintenance.technician.JobClass;
import logicole.common.datamodels.maintenance.technician.JobClassRef;
import logicole.common.datamodels.maintenance.technician.MasterTrainingRecord;
import logicole.common.datamodels.maintenance.technician.Technician;
import logicole.common.datamodels.maintenance.technician.TechnicianTeamAssignment;
import logicole.common.datamodels.user.UserProfile;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Technician"})
@ApplicationScoped
@Path("/technician")
public class TechnicianRestApi extends ExternalRestApi<TechnicianService> {

    @GET
    @Path("/findById")
    public Technician findById(@NotNull @QueryParam("id") String id) {
        return service.findById(id);
    }

    @POST
    @Path("/createTechnician")
    public Technician createTechnician(@NotNull Technician technician) {
        return service.createTechnician(technician);
    }

    @GET
    @Path("/getEmployeeTypes")
    public List<EEmployeeType> getEmployeeTypes() {
        return service.getEmployeeTypes();
    }

    @GET
    @Path("/getJobClassRefs")
    public List<JobClassRef> getJobClassRefs() {
        return service.getJobClassRefs();
    }

    @GET
    @Path("/getPotentialTechnicianUserProfiles")
    public List<UserProfile> getPotentialTechnicianUserProfiles() {
        return service.getPotentialTechnicianUserProfiles();
    }

    @POST
    @Path("/getTechnicianSearchResults")
    public SearchResult<Technician> getTechnicianSearchResults(@NotNull SearchInput searchInput) {
        return service.getTechnicianSearchResults(searchInput);
    }

    @POST
    @Path("/updateTechnician")
    public Technician updateTechnician(@NotNull Technician technician) {
        return service.updateTechnician(technician);
    }

    @POST
    @Path("/addNote")
    public Technician addNote(@NotNull @QueryParam("id") String id, @NotNull Note note) {
        return service.addNote(id, note);
    }

    @POST
    @Path("/saveNote")
    public Technician saveNote(@NotNull @QueryParam("id") String id, @NotNull Note note) {
        return service.saveNote(id, note);
    }

    @POST
    @Path("/removeNote")
    public Technician removeNote(@NotNull @QueryParam("id") String id, @NotNull Note note) {
        return service.removeNote(id, note);
    }

    @GET
    @Path("/getMaintenanceTeams")
    public List<MaintenanceTeam> getMaintenanceTeams() {
        return service.getMaintenanceTeams();
    }

    @POST
    @Path("/updateJobClass")
    public JobClass updateJobClass(@NotNull @QueryParam("id") String id, @NotNull @QueryParam("code") String code) {
        return service.updateJobClass(id, code);
    }

    @GET
    @Path("/getMasterTrainingRecords")
    public List<MasterTrainingRecord> getMasterTrainingRecords() {
        return service.getMasterTrainingRecords();
    }

    @POST
    @Path("/createMasterTrainingRecord")
    public MasterTrainingRecord createMasterTrainingRecord(@NotNull MasterTrainingRecord masterTrainingRecord) {
        return service.createMasterTrainingRecord(masterTrainingRecord);
    }

    @POST
    @Path("/updateMasterTrainingRecord")
    public MasterTrainingRecord updateMasterTrainingRecord(@NotNull MasterTrainingRecord masterTrainingRecord) {
        return service.updateMasterTrainingRecord(masterTrainingRecord);
    }

    @GET
    @Path("/deleteMasterTrainingRecordById")
    public boolean deleteMasterTrainingRecordById(@NotNull @QueryParam("id") String id) {
        return service.deleteMasterTrainingRecordById(id);
    }

    @GET
    @Path("/getAvailableTeamsForAssignment")
    public List<MaintenanceTeam> getAvailableTeamsForAssignment(@NotNull @QueryParam("id") String id) {
        return service.getAvailableTeamsForAssignment(id);
    }

    @GET
    @Path("/getTechnicianTeamAssignments")
    public List<TechnicianTeamAssignment> getTechnicianTeamAssignments(@NotNull @QueryParam("id") String id) {
        return service.getTechnicianTeamAssignments(id);
    }

    @POST
    @Path("/addTechnicianTeamAssignment")
    public TechnicianTeamAssignment addTechnicianTeamAssignment(@NotNull @QueryParam("id") String id, @NotNull @QueryParam("isPrimary") Boolean isPrimary, @NotNull MaintenanceTeamRef maintenanceTeamRef) {
        return service.addTechnicianTeamAssignment(id, isPrimary, maintenanceTeamRef);
    }

    @POST
    @Path("/updateTechnicianTeamAssignment")
    public TechnicianTeamAssignment updateTechnicianTeamAssignment(@NotNull @QueryParam("id") String id, @NotNull TechnicianTeamAssignment technicianTeamAssignment) {
        return service.updateTechnicianTeamAssignment(id, technicianTeamAssignment);
    }

    @POST
    @Path("/removeTechnicianTeamAssignment")
    public void removeTechnicianTeamAssignment(@NotNull @QueryParam("id") String id, @NotNull TechnicianTeamAssignment technicianTeamAssignment) {
        service.removeTechnicianTeamAssignment(id, technicianTeamAssignment);
    }
}
