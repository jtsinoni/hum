package logicole.gateway.services.system;

import logicole.apis.system.ITagMicroserviceApi;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.datamodels.system.EBusinessArea;
import logicole.common.datamodels.system.Tag;
import logicole.common.datamodels.system.TagRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static logicole.common.datamodels.organization.OrganizationConstants.DEV_ORG_ID;

@ApplicationScoped
public class TagService extends BaseGatewayService<ITagMicroserviceApi> {

    private static final int MAX_TAG_CHARS = 140;

    public TagService() {
        super("Tag");
    }

    private List<String> getCurrentUserNodes() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return Arrays.asList(currentUser.profile.currentNodeRef.ancestry.substring(1).split(","));
    }

    private boolean isDevOrRootUser() {
        boolean isRootUser = false;

        String currentNodeId = currentUserBT.getCurrentNodeId();
        if(currentNodeId.equals(DEV_ORG_ID) || currentNodeId.equals(OrganizationConstants.ROOT_ORG_ID)){
            isRootUser = true;
        }

        return isRootUser;
    }

    public Tag getTagByName(String name, String businessArea) {
        EBusinessArea eBusinessArea = EBusinessArea.fromString(businessArea);
        return microservice.getTagByName(name, eBusinessArea.name());
    }

    public List<TagRef> getTagRefsForBusinessArea(EBusinessArea eBusinessArea) {
        if (isDevOrRootUser()) {
            return microservice.getTagRefsForBusinessArea(eBusinessArea.name());
        } else {
            List<String> nodeIds = getCurrentUserNodes();
            return microservice.getTagRefsForBusinessAreaByNodes(eBusinessArea.name(), nodeIds);
        }
    }

    public Tag addTag(Tag tag) {
        if (tag.tagManagedByNodeRef == null || StringUtil.isEmptyOrNull(tag.tagManagedByNodeRef.id)) {
            CurrentUser currentUser = currentUserBT.getCurrentUser();
            tag.tagManagedByNodeRef = currentUser.profile.currentNodeRef;
        }
        return microservice.addTag(tag);
    }

    public Tag updateTag(Tag tag) {
        return microservice.updateTag(tag);
    }

    public Tag getTagById(String tagId) {
        return microservice.getTagById(tagId);
    }

    public List<Tag> getAllTags(@NotNull @QueryParam("businessArea") String businessArea) {
        EBusinessArea eBusinessArea = EBusinessArea.fromString(businessArea);
        if (isDevOrRootUser()) {
            return microservice.getAllTags(eBusinessArea.name());
        } else {
            List<String> nodeIds = getCurrentUserNodes();
            return microservice.getAllTagsByNodes(eBusinessArea.name(), nodeIds);
        }
    }

    public List<Tag> getTagSearchResults(String searchString) {
        if (isDevOrRootUser()) {
            return microservice.getTagSearchResults(searchString);
        } else {
            List<String> nodeIds = getCurrentUserNodes();
            return microservice.getTagSearchResultsByNodes(searchString, nodeIds);
        }
    }

    public void deleteTag(Tag tag) {
        microservice.deleteTag(tag);
    }

    public List<TagRef> verifyAndAddTags(List<TagRef> tagRefs, EBusinessArea eBusinessArea) {
        List<TagRef> returnTagRefs = new ArrayList<>();

        if (tagRefs != null && tagRefs.size() > 0) {
            List<Tag> tagsToAdd = new ArrayList<>();
            for (TagRef tagRef : tagRefs) {
                if (StringUtil.isEmptyOrNull(tagRef.name)) {
                    throw new ApplicationException("Tag cannot be empty");
                }

                tagRef.name = tagRef.name.trim();
                if (MAX_TAG_CHARS < tagRef.name.length()) {
                    String issue = "Tag " + tagRef.name + " is larger than " + MAX_TAG_CHARS + " characters.";
                    throw new ApplicationException(issue);
                }

                // Special character check?

                // Identify and collect new tags
                if (StringUtil.isEmptyOrNull(tagRef.id)) {
                    Tag newTag = new Tag();
                    newTag.name = tagRef.name.trim();
                    newTag.businessArea = eBusinessArea;
                    CurrentUser currentUser = currentUserBT.getCurrentUser();
                    newTag.tagManagedByNodeRef = currentUser.profile.currentNodeRef;

                    tagsToAdd.add(newTag);
                }
            }

            // Clear out tags without an id, the new tags
            List<TagRef> existingTagRefs = tagRefs.stream()
                    .filter(ref -> ref.id != null && !ref.id.equals(""))
                    .collect(Collectors.toList());

            // Verify and save new tags in dmlesSystem > tags
            tagsToAdd = microservice.verifyAndAddTags(tagsToAdd);

            // Convert new tags to tag refs
            List<TagRef> newTagRefs = tagsToAdd.stream().map(Tag::getRef).collect(Collectors.toList());

            // Re-add to main object
            returnTagRefs.addAll(existingTagRefs);
            returnTagRefs.addAll(newTagRefs);
        }

        return returnTagRefs;
    }

    public List<String> getBusinessAreas() {
        return EBusinessArea.getDisplayTextList();
    }

    public boolean determineIfRootUser() {
        return isDevOrRootUser();
    }
}
