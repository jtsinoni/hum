package logicole.gateway.services.product;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.staging.CommodityClass;
import logicole.common.datamodels.product.*;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Api(tags = {"Product"})
@ApplicationScoped
@Path("/product")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ProductRestApi extends ExternalRestApi<ProductService> {

    @GET
    @Path("/getCommodityClassList")
    public List<CommodityClass> getCommodityClassList(@QueryParam("militaryServiceCode") String militaryServiceCode){
        return service.getCommodityClassList(militaryServiceCode);
    }

    @GET
    @Path("/getCommodityClassListForCustomer")
    public List<CommodityClass> getCommodityClassListForCustomer(@QueryParam("customerId") String customerId){
        return service.getCommodityClassListForCustomer(customerId);
    }

    @GET
    @Path("/getCustomerCatalog")
    public List<SiteCatalogRecord> getCustomerCatalog(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId){
        return service.getCustomerCatalog(siteId, customerId);
    }

    @GET
    @Path("/getCustomerCatalogByCommType")
    public List<SiteCatalogRecord> getCustomerCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("customerId") String customerId, @QueryParam("commType") String commType){
        return service.getCustomerCatalogByCommType(siteId, customerId, commType);
    }

    @GET
    @Path("/getEnterpriseProductIdentifier")
    @Produces(MediaType.TEXT_PLAIN)
    public String getEnterpriseProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier){
        return service.getEnterpriseProductIdentifier(enterpriseItemIdentifier);
    }

    @GET
    @Path("/getEquipmentByItemId")
    public List<SiteCatalogRecord> getEquipmentByItemId(@QueryParam("siteId") String siteId, @QueryParam("partialItemId") String partialItemId){
        return service.getEquipmentByItemId(siteId, partialItemId);
    }

    @GET
    @Path("/getEquipmentItemIdList")
    public List<ItemId> getEquipmentItemIdList(@QueryParam("siteId") String siteId, @QueryParam("partialItemId") String partialItemId){
        return service.getEquipmentItemIdList(siteId, partialItemId);
    }

    @GET
    @Path("/getMedicalSupplyProductSeqIdInfo")
    public List<ProductSeqIdInfo> getMedicalSupplyProductSeqIdInfo(){
        return service.getMedicalSupplyProductSeqIdInfo();
    }

    @GET
    @Path("/getMmcItems")
    public MmcSearchResult getMmcItems(@QueryParam("customerId") String customerId,
                                       @QueryParam("manufacturerName") String manufacturerName,
                                       @QueryParam("manufacturerCatalogNumber") String manufacturerCatalogNumber,
                                       @QueryParam("itemNumber") String itemNumber,
                                       @QueryParam("ndc") String ndc,
                                       @QueryParam("itemDescription") String itemDescription,
                                       @QueryParam("pvon") String pvon,
                                       @QueryParam("ecatItemId") Integer ecatItemId,
                                       @QueryParam("genericSequenceNum") String genericSequenceNum,
                                       @QueryParam("slProductCd") String slProductCd) {
        return service.getMmcItems(customerId, manufacturerName, manufacturerCatalogNumber, itemNumber, ndc, itemDescription, pvon, ecatItemId, genericSequenceNum, slProductCd);
    }

    @GET
    @Path("/getMmcItem")
    public MmcItem getMmcItem(@QueryParam("customerId") String customerId, @QueryParam("productSeqId") Integer productSeqId) {
        return service.getMmcItem(customerId, productSeqId);
    }

    @GET
    @Path("/getNdcList")
    public List<String> getNdcList(){
        return service.getNdcList();
    }

    @GET
    @Path("/getProductSeqIdList")
    public List<Integer> getProductSeqIdList(){
        return service.getProductSeqIdList();
    }

    @GET
    @Path("/getSiteCatalog")
    public List<SiteCatalogRecord> getSiteCatalog(@QueryParam("siteId") String siteId){
        return service.getSiteCatalog(siteId);
    }

    @GET
    @Path("/getSiteCatalogByBarcode")
    public List<SiteCatalogRecord> getSiteCatalogByBarcode(@QueryParam("siteId") String siteId, @QueryParam("barcodes") String barcode){
        return service.getSiteCatalogByBarcode(siteId, barcode);
    }

    @GET
    @Path("/getSiteCatalogByCommType")
    public List<SiteCatalogRecord> getSiteCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("commType") String commType){
        return service.getSiteCatalogByCommType(siteId, commType);
    }

    @GET
    @Path("/getSiteCatalogByEnterpriseId")
    public List<SiteCatalogRecord> getSiteCatalogByEnterpriseId(@QueryParam("siteId") String siteId, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.getSiteCatalogByEnterpriseId(siteId, enterpriseProductIdentifier);
    }

    @GET
    @Path("/getSiteCatalogByProductId")
    public List<SiteCatalogRecord> getSiteCatalogByProductId(@QueryParam("siteId") String siteId, @QueryParam("productSeqId") Integer productSeqId){
        return service.getSiteCatalogByProductId(siteId, productSeqId);
    }

    @GET
    @Path("/getSiteCatalogItem")
    public SiteCatalogRecord getSiteCatalogItem(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId){
        return service.getSiteCatalogItem(siteId, itemId);
    }

    @GET
    @Path("/getSiteCatalogRecord")
    public SiteCatalogRecord getSiteCatalogRecord(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier){
        return service.getSiteCatalogRecord(enterpriseItemIdentifier);
    }

    @GET
    @Path("/getSiteCount")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer getSiteCount(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier){
        return service.getSiteCount(enterpriseProductIdentifier);
    }

    @GET
    @Path("/getSupplierCatalog")
    public List<SiteCatalogRecord> getSupplierCatalog(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm){
        return service.getSupplierCatalog(siteId, supplierNm);
    }

    @GET
    @Path("/getSupplierCatalogByCommType")
    public List<SiteCatalogRecord> getSupplierCatalogByCommType(@QueryParam("siteId") String siteId, @QueryParam("supplierNm") String supplierNm, @QueryParam("commType") String commType){
        return service.getSupplierCatalogByCommType(siteId, supplierNm, commType);
    }

    @GET
    @Path("/searchEquipment")
    public List<SiteCatalogRecord> searchEquipment(@QueryParam("siteId") String siteId, @QueryParam("itemId") String itemId, @QueryParam("shortItemDesc") String shortItemDesc, @QueryParam("longItemDesc") String longItemDesc, @QueryParam("manufacturerNm") String manufacturerNm, @QueryParam("manufCatNum") String manufCatNum, @QueryParam("deviceText") String deviceText){
        return service.searchEquipment(siteId, itemId, shortItemDesc, longItemDesc, manufacturerNm, manufCatNum, deviceText);
    }

    @GET
    @Path("/textSearch")
    public List<SiteCatalogRecord> textSearch(@QueryParam("siteId") String siteId, @QueryParam("searchString") String searchString){
        return service.textSearch(siteId, searchString);
    }

    @GET
    @Path("/textSearchCommType")
    public List<SiteCatalogRecord> textSearchCommType(@QueryParam("siteId") String siteId, @QueryParam("commType") String commType, @QueryParam("searchString") String searchString){
        return service.textSearchCommType(siteId, commType, searchString);
    }

    @PUT
    @Path("/updateEnterpriseProductIdentifier")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer updateEnterpriseProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier){
        return service.updateEnterpriseProductIdentifier(enterpriseItemIdentifier, enterpriseProductIdentifier);
    }

    @PUT
    @Path("/updateMmcProductIdentifier")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer updateMmcProductIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier, @QueryParam("mmcProductIdentifier") Integer mmcProductIdentifier){
        return service.updateMmcProductIdentifier(enterpriseItemIdentifier, mmcProductIdentifier);
    }

    @PUT
    @Path("/updateProductSeqId")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer updateProductSeqId(@QueryParam("oldProductSeqId") Integer oldProductSeqId, @QueryParam("newProductSeqId") Integer newProductSeqId){
        return service.updateProductSeqId(oldProductSeqId, newProductSeqId);
    }

    @PUT
    @Path("/updateSiteCatalogRecordFromABi")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer updateSiteCatalogRecordFromABi(@QueryParam("oldEnterpriseProductIdentifier") String oldEnterpriseProductIdentifier,
                                                  @QueryParam("newEnterpriseProductIdentifier") String newEnterpriseProductIdentifier) {
        return service.updateSiteCatalogRecordFromABi(oldEnterpriseProductIdentifier, newEnterpriseProductIdentifier);
    }

    @GET
    @Path("/getDistinctManufacturerNames")
    public List<String> getDistinctManufacturerNames() {
        return service.getDistinctManufacturerNames();
    }

    @GET
    @Path("/getRecordsWithoutEnterpriseProductIdentifier")
    public List<SiteCatalogRecord> getRecordsWithoutEnterpriseProductIdentifier(@QueryParam("manufacturerNm") String manufacturerNm,
                                                                                @QueryParam("mmcExists") Boolean mmcExists) throws ApplicationException {
        return service.getRecordsWithoutEnterpriseProductIdentifier(manufacturerNm, mmcExists);
    }
    @GET
    @Path("/getDistinctUnlinkedManufacturerNames")
    public List<String>  getDistinctUnlinkedManufacturerNames() {
        return service.getDistinctUnlinkedManufacturerNames();
    }

}
