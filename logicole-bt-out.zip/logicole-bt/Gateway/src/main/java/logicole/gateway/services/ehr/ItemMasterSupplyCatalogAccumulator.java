package logicole.gateway.services.ehr;

import logicole.common.datamodels.ehr.equipment.ItemMasterSupplyCatalogItem;
import logicole.common.datamodels.ehr.equipment.EItemMasterSupplyCatalogType;
import logicole.common.datamodels.ehr.equipment.EItemMasterSupplyItemDeltaType;
import logicole.common.datamodels.ehr.equipment.ItemMasterSupplyItemSiteInfo;
import logicole.gateway.services.product.OfferService;

import java.util.*;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

@RequestScoped
public class ItemMasterSupplyCatalogAccumulator {

    @Inject
    private OfferService offerService;

    private final Map<String, ItemMasterSupplyCatalogItem> map = new HashMap<>();

    public void accumulate(List<ItemMasterSupplyCatalogItem> items, Date afterDate, EItemMasterSupplyCatalogType catType) {
        for (ItemMasterSupplyCatalogItem item : items) {
            if (map.containsKey(item.itemId)) {
                ItemMasterSupplyCatalogItem mapItem = map.get(item.itemId);
                ItemMasterSupplyItemSiteInfo itemSiteInfo = item.siteInfoList.get(0);
                boolean matchAny = mapItem.siteInfoList.contains(itemSiteInfo);
                if (!matchAny) {
                    mapItem.siteInfoList.add(itemSiteInfo);
                }
            } else {

                if (catType == EItemMasterSupplyCatalogType.ITEM_DELTA) {
                    item.deltaType = offerService.getProductEHRDeltaType(afterDate, item.itemId);
                } else {
                    item.deltaType = null;
                }
                map.put(item.itemId, item);
            }
        }
    }

    public Collection<ItemMasterSupplyCatalogItem> getItems() {
        return map.values();
    }
}
