package logicole.gateway.services.asset;

import logicole.apis.asset.ICustodianMicroserviceApi;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.asset.management.Custodian;
import logicole.common.datamodels.asset.management.CustomerCustodian;
import logicole.common.datamodels.asset.management.ECustodianType;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationTypeRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.datamodels.user.UserProfileRef;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.validation.CustodianValidator;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.user.UserService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@ApplicationScoped
public class CustodianService extends BaseGatewayService<ICustodianMicroserviceApi> {

    private static final String CUSTODIAN_ROLE_ID = "613a1983da0a0130f77c2e2f";

    @Inject
    MedicalEquipmentService medicalEquipmentService;
    @Inject
    OrganizationService organizationService;
    @Inject
    UserService userService;
    @Inject
    CustodianValidator custodianValidator;

    public CustodianService() {
        super("Custodian");
    }

    public boolean doesCustomerHaveAccountableEquipment(String id) {
        return medicalEquipmentService.doesCustomerHaveAccountableEquipment(id);
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public List<CustomerCustodian> getCustomerCustodiansBySite() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        String siteId = currentUser.profile.currentNodeRef.id;
        List<Custodian> custodians = microservice.getCustodiansBySiteId(siteId);
        List<OrganizationRef> customerRefs = this.getCustomersBySiteId(siteId);
        List<CustomerCustodian> customerCustodians = new ArrayList<>();
        for (OrganizationRef customerRef : customerRefs) {
            Custodian custodian = this.findCustodianForCustomer(customerRef.id, custodians);
            if (custodian.managedByNodeRef == null || StringUtil.isEmptyOrNull(custodian.managedByNodeRef.name)) {
                custodian.managedByNodeRef = new OrganizationRef();
                custodian.managedByNodeRef.name = currentUser.profile.currentNodeRef.name;
            }
            customerCustodians.add(new CustomerCustodian(customerRef, custodian));
        }
        return customerCustodians;
    }

    public List<Custodian> getCustodiansBySite() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        String siteId = currentUser.profile.currentNodeRef.id;
        return microservice.getCustodiansBySiteId(siteId);
    }

    private Custodian findCustodianForCustomer(String customerRefId, List<Custodian> custodians) {
        return custodians.stream()
                .filter(custodian -> custodian.customerRef.id.equals(customerRefId))
                .findFirst()
                .orElse(new Custodian());
    }

    public List<OrganizationRef> getCustomersBySiteId(String siteId) {
        OrganizationTypeRef nodeTypeRef = organizationService.getOrganizationTypeRefByName("Customer");
        if (nodeTypeRef != null && nodeTypeRef.id != null) {
            List<Organization> customers = organizationService.findByNodeTypeIdAndParentId(nodeTypeRef.id, siteId);
            return customers.stream().map(Organization::getRef).collect(Collectors.toList());
        } else {
            return Collections.emptyList();
        }
    }

    public Custodian createCustodian(Custodian custodian) {
        custodian.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        custodian.custodianType = ECustodianType.CUSTODIAN;
        custodianValidator.validate(custodian, currentUserBT.getCurrentNodeId());
        return microservice.createCustodian(custodian);
    }

    public List<UserProfile> getPotentialCustodianUserProfiles() {
        String nodeId = currentUserBT.getCurrentNodeId();
        List<UserProfile> userProfiles = userService.getUsersAtNodeWithRole(nodeId, CUSTODIAN_ROLE_ID);

        Comparator<UserProfile> byLastName = Comparator.comparing(user->user.lastName);
        return userProfiles.stream().sorted(byLastName)
                .collect(Collectors.toList());
    }

    public List<OrganizationRef> getCustomersWithoutCustodianAtOrg() {
        List<OrganizationRef> customers = medicalEquipmentService.getEquipmentCustomers();
        List<Custodian> custodians = getCustodiansBySite();

        Comparator<OrganizationRef> byName = Comparator.comparing(org->org.name);
        // Filter out Customers that already have a Custodian assigned
        return customers.stream()
                .filter(customer -> custodians.stream()
                        .noneMatch(custodian -> custodian.customerRef.getId().equals(customer.getId())))
                .sorted(byName)
                .collect(Collectors.toList());
    }

    public Custodian getCustodianByOrgAndCustomer(String customerId, String currentNodeRefId, ECustodianType custodianType) {
        return microservice.getCustodianByOrgAndCustomer(customerId, currentNodeRefId, custodianType);
    }

    public Custodian getCustodianRecordById(String id) {
        return microservice.getCustodianRecordById(id);
    }

    public Custodian saveCustodianInformation(Custodian custodian) {
        custodianValidator.validate(custodian, currentUserBT.getCurrentNodeId());
        return microservice.saveCustodianInformation(custodian);
    }

    public Custodian saveInventoryInformation(String id, Date nextInventoryDate) {
        Custodian custodian = getCustodianRecordById(id);
        custodianValidator.validate(custodian, currentUserBT.getCurrentNodeId());
        return microservice.saveInventoryInformation(id, nextInventoryDate);
    }

    public Custodian removeCustodianNote(String id, Note note) {
        return microservice.removeCustodianNote(id, note);
    }

    public Custodian saveCustodianNote(String id, Note note) {
        return microservice.saveCustodianNote(id, note);
    }

    public int updateUserProfileRefs(UserProfileRef userProfileRef) {
        return microservice.updateUserProfileRefs(userProfileRef);
    }

    public int updateManagedByNodeRefs(OrganizationRef organizationRef) {
        return microservice.updateManagedByNodeRefs(organizationRef);
    }

    public int updateCustomerRefs(OrganizationRef organizationRef) {
        return microservice.updateCustomerRefs(organizationRef);
    }

    public boolean removeCustodian(String id) {
        Custodian custodian = getCustodianRecordById(id);
        custodianValidator.validateCanEdit(custodian, currentUserBT.getCurrentNodeId());
        return microservice.removeCustodian(id);
    }

    public boolean removeSubcustodian(String id) {
        return microservice.removeSubcustodian(id);
    }

    public boolean checkIfSubcustodianAssignedToCustomer(String id) {
        return microservice.checkIfSubcustodianAssignedToCustomer(id);
    }

    public Custodian createSubcustodian(String custodianId, Custodian subcustodian) {
        Custodian custodian = getCustodianRecordById(custodianId);
        subcustodian.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        subcustodian.customerRef = custodian.customerRef;
        subcustodian.custodianType = ECustodianType.SUBCUSTODIAN;

        custodianValidator.validateSubcustodian(subcustodian, currentUserBT.getCurrentNodeId());
        return microservice.createCustodian(subcustodian);
    }

    public Custodian saveSubcustodian(Custodian subcustodian) {
        custodianValidator.validateSubcustodian(subcustodian, currentUserBT.getCurrentNodeId());
        return microservice.saveSubcustodian(subcustodian);
    }

    public boolean removeAllSubcustodiansAtCustomer(String id) {
        return microservice.removeAllSubcustodiansAtCustomer(id);
    }

    public List<Custodian> getSubCustodiansByCustomerId(String customerId) {
        Organization customer = organizationService.getOrganization(customerId);
        if (!customer.getAncestry().contains(currentUserBT.getCurrentUser().profile.currentNodeRef.getId())) {
            throw new ApplicationException("No permission for this operation");
        }

        return microservice.getSubCustodiansByCustomerId(customerId);
    }

    public List<Asset> getAssignedEquipmentForSubcustodian(String subcustodianId) {
        return microservice.getAssignedEquipmentForSubcustodian(subcustodianId);
    }

    public List<Asset> getAssignableEquipmentByCustomerId(String customerId) {
        return microservice.getAssignableEquipmentByCustomerId(customerId);
    }

    public List<Asset> saveAssignedEquipmentForSubcustodian(List<String> ids, String subcustodianId) {
        return microservice.saveAssignedEquipmentForSubcustodian(ids, subcustodianId);
    }

}
