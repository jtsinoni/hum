package logicole.gateway.services.assemblage;

import logicole.apis.assemblage.IAssemblageMicroserviceApi;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.abi.item.ItemPackaging;
import logicole.common.datamodels.abi.item.ItemRef;
import logicole.common.datamodels.assemblage.Assemblage;
import logicole.common.datamodels.assemblage.AssemblageBusinessEvent;
import logicole.common.datamodels.assemblage.AssemblageBusinessEventInfo;
import logicole.common.datamodels.assemblage.AssemblageDashboardInfo;
import logicole.common.datamodels.assemblage.AssemblageFinanceData;
import logicole.common.datamodels.assemblage.AssemblageInfo;
import logicole.common.datamodels.assemblage.AssemblageItem;
import logicole.common.datamodels.assemblage.AssemblageItemRef;
import logicole.common.datamodels.assemblage.AssemblageRef;
import logicole.common.datamodels.assemblage.AuthoritativeAssemblage;
import logicole.common.datamodels.assemblage.AuthoritativeAssemblageProduct;
import logicole.common.datamodels.assemblage.AuthoritativeAssemblageProductRef;
import logicole.common.datamodels.assemblage.AuthoritativeAssemblageRef;
import logicole.common.datamodels.assemblage.CommingledRef;
import logicole.common.datamodels.assemblage.CriticalRef;
import logicole.common.datamodels.assemblage.DeferredRef;
import logicole.common.datamodels.catalog.Catalog;
import logicole.common.datamodels.catalog.CatalogRef;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.FundingNodeBalance;
import logicole.common.datamodels.finance.output.AuthorizedNode;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.inventory.InventoryRecord;
import logicole.common.datamodels.order.CatalogPurchase;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.buyer.BuyerRef;
import logicole.common.datamodels.order.order.OrderInformation;
import logicole.common.datamodels.order.order.OrderItem;
import logicole.common.datamodels.order.order.OrderItemRef;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.AbiSearchService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.assemblage.logging.AMLogger;
import logicole.gateway.services.catalog.CatalogService;
import logicole.gateway.services.finance.FinanceAdminService;
import logicole.gateway.services.inventory.InventoryService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.order.CartService;
import logicole.gateway.services.order.OrderService;
import logicole.gateway.services.organization.OrganizationService;
import org.bson.types.ObjectId;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@ApplicationScoped
public class AssemblageService extends BaseGatewayService<IAssemblageMicroserviceApi> {
    private static final String ELASTIC_MESSAGE = "Elastic search is not supported now";

    private static final String TYPE_STANDARD = "Standard";
    private static final String TYPE_NON_STANDARD = "Non-Standard";
    private static final String PRICE = "price";
    private static final String ON_HAND = "onHand";
    private static final String SHORTAGE = "shortage";
    private static final String INDEX = "index";

    @Inject
    CatalogService catalogService;

    @Inject
    OrganizationService organizationService;

    @Inject
    BuyerService buyerService;

    @Inject
    AbiSearchService abiSearchService;

    @Inject
    private ItemService itemService;

    @Inject
    private OrderService orderService;

    @Inject
    private InventoryService inventoryService;

    @Inject
    private FinanceAdminService financeAdminService;

    @Inject
    private CartService cartService;

    @Inject
    AMLogger amLogger;

    public AssemblageService() {
        super("Assemblage");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public String getCurrentUserOrgMilServiceId() {
        return organizationService.getOrganization(getCurrentUser().profile.currentNodeRef.id).milServiceId;
    }

    public Assemblage getAssemblageById(String id) {
        return microservice.getAssemblageById(id);
    }

    public List<AssemblageItem> getItemsByAssemblageId(String id) {
        return microservice.getItemsByAssemblageId(id);
    }

    public float getAssemblageTotalCost(String id) {
        return microservice.getAssemblageTotalCost(id);
    }

    public SearchResult<Assemblage> getAssemblageSearchResults(SearchInput searchInput, boolean scannerInput, String customerId) {
        if (ESearchEngine.ELASTIC.equals(microservice.getAssemblageSearchEngine())) {
            throw new ApplicationException(ELASTIC_MESSAGE);
        } else {
            SearchResult<Assemblage> searchResult = new SearchResult<>();
            if (scannerInput) {

                searchInput.searchText = StringUtil.isBlankOrNull(searchInput.searchText) ? "" : abiSearchService.parseBarcodeSearchString(searchInput.searchText);

                ItemPackaging itemPackaging = itemService.getItemByBarcode(searchInput.searchText);
                if (Objects.nonNull(itemPackaging.itemRef)) {
                    List<AssemblageItem> items = microservice.getAssemblageItemsByItemId(itemPackaging.itemRef.id);
                    for (AssemblageItem item : items) {
                        searchResult.results.add(microservice.getAssemblageById(item.assemblageRef.id));
                    }
                }
            } else {
                searchResult = microservice.getAssemblageSearchResults(
                    searchInput,
                    customerId,
                    getCurrentUser().profile.currentNodeRef.name,
                    getCurrentUser().profile.currentNodeRef.ancestry);
            }
            return searchResult;
        }
    }

    public AssemblageDashboardInfo getAssemblageDashboardStats() {
        return microservice.getAssemblageDashboardStats(
                getCurrentUser().profile.currentNodeRef.name,
                getCurrentUser().profile.currentNodeRef.ancestry);
    }

    public AssemblageItem getAssemblageItemById(String id) {
        AssemblageItem assemblageItem = microservice.getAssemblageItemById(id);
        setAssemblageItemCatalogInfo(assemblageItem);
        setAssemblageItemDueIns(List.of(assemblageItem));
        return assemblageItem;
    }

    public List<AuthoritativeAssemblageProduct> getAuthoritativeAssemblageProductsById(String id) {
        return microservice.getAuthoritativeAssemblageProductsById(id);
    }

    public List<AuthoritativeAssemblageProduct> getAuthoritativeAssemblageProductsByProductIdentifier(String productIdentifier) {
        return microservice.getAuthoritativeAssemblageProductsByProductIdentifier(productIdentifier);
    }

    public List<AuthoritativeAssemblage> getAuthoritativeAssemblagesByKeyFields(List<AuthoritativeAssemblage> assemblagesToSearchFor) {
        return microservice.getAuthoritativeAssemblagesByKeyFields(assemblagesToSearchFor);
    }

    public List<Assemblage> getAssemblages(String identifier, String increment, String subAssemblage) {
        return microservice.getAssemblages(identifier, increment, subAssemblage);
    }

    public List<AuthoritativeAssemblage> getAuthoritativeAssemblageByIdentifierAndIncrement(String identifier, String increment) {
        return microservice.getAuthoritativeAssemblageByIdentifierAndIncrement(identifier, increment);
    }

    public SearchResult<AuthoritativeAssemblage> getAuthoritativeAssemblageSearchResults(SearchInput searchInput) {
        if (ESearchEngine.ELASTIC.equals(microservice.getAuthoritativeAssemblageSearchEngine())) {
            throw new ApplicationException(ELASTIC_MESSAGE);
        } else {
            OrganizationRef currentNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.getAuthoritativeAssemblageSearchResults(searchInput, currentNodeRef.id, currentNodeRef.ancestry);
        }
    }

    public SearchResult<AuthoritativeAssemblage> getAuthoritativeAssemblageSearchResultsForAssemblageCreate(SearchInput searchInput) {
        if (ESearchEngine.ELASTIC.equals(microservice.getAuthoritativeAssemblageSearchEngine())) {
            throw new ApplicationException(ELASTIC_MESSAGE);
        } else {
            return microservice.getAuthoritativeAssemblageSearchResultsForAssemblageCreate(searchInput, "", "");
        }
    }

    public SearchResult<Assemblage> getAssemblageFundSearchResults(SearchInput searchInput) {
        if (ESearchEngine.ELASTIC.equals(microservice.getAuthoritativeAssemblageSearchEngine())) {
            throw new ApplicationException(ELASTIC_MESSAGE);
        } else {
            return microservice.getAssemblageFundSearchResults(
                    searchInput,
                    getCurrentUser().profile.currentNodeRef.name,
                    getCurrentUser().profile.currentNodeRef.ancestry);
        }
    }

    public Assemblage addAssemblage(@NotNull AssemblageInfo assemblageInfo) {
        Assemblage assemblage = assemblageInfo.assemblage;
        if (assemblage.managedByNodeRef == null || StringUtil.isEmptyOrNull(assemblage.managedByNodeRef.id)) {
            assemblage.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        }

        if (TYPE_NON_STANDARD.equals(assemblage.type)) {
            assemblage = saveAssemblages(assemblage, assemblageInfo.buildControlNumbers, assemblageInfo.assemblageLocations, assemblageInfo.assemblageItems);
        } else {
            for (AuthoritativeAssemblage authoritativeAssemblage : assemblageInfo.subAssemblages) {
                assemblage.subAssemblage = authoritativeAssemblage.subAssemblage;
                assemblage.description = authoritativeAssemblage.description;
                assemblage.authoritativeAssemblageRef = new AuthoritativeAssemblageRef(authoritativeAssemblage.getId());
                assemblage = saveAssemblages(assemblage, assemblageInfo.buildControlNumbers, assemblageInfo.assemblageLocations, assemblageInfo.assemblageItems);
            }
        }
        return assemblage;
    }

    private Assemblage saveAssemblages(Assemblage assemblage, List<String> buildControlNumbers, List<String> assemblageLocations, List<AssemblageItem> items) {
        Assemblage insertedAssemblage = new Assemblage();
        int lastInstance = microservice.getLastInstanceForIdentifierIncrementSubAssemblage(assemblage.identifier, assemblage.increment, assemblage.subAssemblage);
        int i = 1;
        List<AuthoritativeAssemblageProduct> products = microservice.getAuthoritativeAssemblageProductsById(assemblage.authoritativeAssemblageRef.id);
        if (items.isEmpty()) {
            products.forEach(product -> items.add(buildAssemblageItemForProduct(assemblage, product)));
        }

        for (String buildControlNumber : buildControlNumbers) {
            assemblage.buildControlNumber = buildControlNumber;
            assemblage.warehouseLocation = assemblageLocations.get(i - 1);
            assemblage.instance = String.valueOf(lastInstance + i++);
            insertedAssemblage = microservice.addAssemblage(assemblage);

            if (!items.isEmpty()) {
                AssemblageRef ref = insertedAssemblage.getRef();
                // TODO: remove the location information
                items.forEach(item -> {
                    item.assemblageRef = ref;
                    item._id = new ObjectId();
                    item.primeItemRef = new AssemblageItemRef();
                    item.endItemRef = new ArrayList<>();
                    item.supportItemRef = new ArrayList<>();
                });
                addAssemblageItems(items);
            }
        }
        return insertedAssemblage;
    }

    public void deleteAssemblageById(String assemblageId) {
        microservice.deleteAssemblageById(assemblageId);
    }

    public Assemblage updateAssemblage(@NotNull AssemblageInfo assemblageInfo) {
        Assemblage assemblage = assemblageInfo.assemblage;
        if (assemblageInfo.regenerateInstance) {
            assemblage.instance = String.valueOf
                    (microservice.getLastInstanceForIdentifierIncrementSubAssemblage(assemblage.identifier, assemblage.increment, assemblage.subAssemblage) + 1);
        }

        Assemblage currentAssemblage = microservice.getAssemblageById(assemblage.getId());
        logChanges(currentAssemblage, assemblage);

        return microservice.updateAssemblage(assemblage);
    }

    public AuthoritativeAssemblage updateAuthoritativeAssemblage(@NotNull AssemblageInfo assemblageInfo) {
        return microservice.updateAuthoritativeAssemblage(assemblageInfo.authoritativeAssemblage);
    }

    public void updateAssemblages(List<Assemblage> assemblagesToUpdate) {

        for (Assemblage assemblage : assemblagesToUpdate) {
            Assemblage currentAssemblage = microservice.getAssemblageById(assemblage.getId());
            logChanges(currentAssemblage, assemblage);
            microservice.updateAssemblage(assemblage);
        }
    }

    public AssemblageItem addAssemblageItem(@NotNull AssemblageItem assemblageItem) {
        return microservice.addAssemblageItem(assemblageItem);
    }

    public AssemblageItem updateAssemblageItem(@NotNull AssemblageItem assemblageItem) {
        return microservice.updateAssemblageItem(assemblageItem);
    }

    public void saveEndItems(@NotNull List<AssemblageItem> assemblageItems) {
        microservice.saveEndItems(assemblageItems);
    }

    public List<AssemblageItem> getCurrentEndItems(String id) {
        return microservice.getCurrentEndItems(id);
    }

    public void saveSupportItems(@NotNull List<AssemblageItem> assemblageItems) {
        microservice.saveSupportItems(assemblageItems);
    }

    public List<AssemblageItem> getCurrentSupportItems(String id) {
        return microservice.getCurrentSupportItems(id);
    }

    public int addAssemblageItems(@NotNull List<AssemblageItem> assemblageItems) {
        return microservice.addAssemblageItems(assemblageItems);
    }

    public List<AssemblageItem> getAssemblageItems(Assemblage assemblage, String itemIdentifier) {

        List<AssemblageItem> assemblageItems = new ArrayList<>();

        if (TYPE_NON_STANDARD.equals(assemblage.type)) {

            assemblageItems.add(buildAssemblageItem(assemblage, itemIdentifier));

        } else if (TYPE_STANDARD.equals(assemblage.type)) {

            List<AuthoritativeAssemblageProduct> authoritativeAssemblageProducts = microservice.getProductsByAuthAssemblageRefIdAndProductId(assemblage.authoritativeAssemblageRef.id, itemIdentifier);
            authoritativeAssemblageProducts.forEach(authoritativeAssemblageProduct -> assemblageItems.add(buildAssemblageItemForProduct(assemblage, authoritativeAssemblageProduct)));
        }

        return assemblageItems;
    }

    private AssemblageItem buildAssemblageItem(Assemblage assemblage, String itemIdentifier) {
        String buyerId = "";

        AssemblageItem assemblageItem = new AssemblageItem();
        assemblageItem.authoritativeAssemblageProductRef = new AuthoritativeAssemblageProductRef();

        if (assemblage != null) {
            buyerId = assemblage.customerNodeRef.id;

            assemblageItem.assemblageRef = assemblage.getRef();
        }

        buildItem(buyerId, assemblageItem, itemIdentifier);

        return assemblageItem;
    }

    private AssemblageItem buildAssemblageItemForProduct(Assemblage assemblage, AuthoritativeAssemblageProduct product) {
        String itemIdentifier = "";
        String buyerId = "";

        AssemblageItem assemblageItem = new AssemblageItem();

        if (product != null) {

            itemIdentifier = product.productIdentifier;

            assemblageItem.authoritativeAssemblageProductRef = product.getRef();
            assemblageItem.associatedSupportItemsOfEquipmentType = product.associatedSupportItemsOfEquipmentType;
            assemblageItem.medicalUnitAssemblageGroupCode = product.medicalUnitAssemblageGroupCode;
            assemblageItem.criticalRef = product.criticalRef;
            assemblageItem.criticalQuantity = product.criticalQuantity;

            if (assemblageItem.criticalRef != null && assemblageItem.criticalRef.criticalCode != null) {
                assemblageItem.isCritical = assemblageItem.criticalRef.criticalCode.length() > 0;
            }
        }

        if (assemblage != null) {

            buyerId = assemblage.customerNodeRef.id;

            assemblageItem.assemblageRef = assemblage.getRef();
        }

        buildItem(buyerId, assemblageItem, itemIdentifier);

        return assemblageItem;
    }

    public void buildItem(String buyerId, AssemblageItem assemblageItem, String itemIdentifier) {

        List<Catalog> catalogs = catalogService.getRecordsByCustomerItemIdentifier(buyerId, itemIdentifier);

        if (assemblageItem.authoritativeAssemblageProductRef == null) {
            assemblageItem.authoritativeAssemblageProductRef = new AuthoritativeAssemblageProductRef();
        }

        if (!catalogs.isEmpty()) {

            List<Catalog> preferredPurchaseSourcing = catalogs.stream().filter(sourcing -> sourcing.isPreferredSource).collect(Collectors.toList());

            if (!preferredPurchaseSourcing.isEmpty()) {
                assemblageItem.itemRef = preferredPurchaseSourcing.get(0).itemRef;
                assemblageItem.catalogRef = preferredPurchaseSourcing.get(0).getRef();
                assemblageItem.commodityCodeRef = preferredPurchaseSourcing.get(0).commodityCodeRef;
            } else {
                assemblageItem.itemRef = catalogs.get(0).itemRef;
                assemblageItem.catalogRef = catalogs.get(0).getRef();
                assemblageItem.commodityCodeRef = catalogs.get(0).commodityCodeRef;
            }

            assemblageItem.isCommingled = false;
        }
        // TODO - Temporary until we determine logic for if item is not found with Customer Item Identifier. This is just so the item id still shows on the view.
        else {
            assemblageItem.itemRef = new ItemRef();
            assemblageItem.catalogRef = new CatalogRef();
            assemblageItem.commodityCodeRef = new CommodityCodeRef();
            assemblageItem.catalogRef.catalogItemIdentifier = itemIdentifier;
        }
    }

    public List<AssemblageItem> getByEnterpriseProductIdOrDescription(String nodeId, String searchText) {
        AssemblageItem assemblageItem;

        List<AssemblageItem> assemblageItems = new ArrayList<>();

        List<Catalog> catalogList = catalogService.getRecordsByCustomerItemIdentifierOrDescription(nodeId, searchText);

        for (Catalog catalog : catalogList) {

            if (catalog.isPreferredSource) {
                assemblageItem = new AssemblageItem();
                assemblageItem.itemRef = catalog.itemRef;
                assemblageItem.catalogRef = catalog.getRef();
                assemblageItem.commodityCodeRef = catalog.commodityCodeRef;
                assemblageItem.assemblageRef = new AssemblageRef();
                assemblageItem.authoritativeAssemblageProductRef = new AuthoritativeAssemblageProductRef();
                assemblageItem.criticalRef = new CriticalRef();
                assemblageItem.deferredRef = new DeferredRef();
                assemblageItem.commingledRef = new CommingledRef();
                setAssemblageItemCatalogInfo(assemblageItem);
                assemblageItems.add(assemblageItem);
            }
        }

        return assemblageItems;
    }

    public List<AssemblageItem> getAncestryRecordsByCustomerItemIdentifierOrDescription(String nodeId, String searchText) {
        AssemblageItem assemblageItem;

        List<AssemblageItem> assemblageItems = new ArrayList<>();

        List<Catalog> catalogList = catalogService.getAncestryRecordsByCustomerItemIdentifierOrDescription(nodeId, searchText);

        for (Catalog catalog : catalogList) {

            if (catalog.isPreferredSource) {
                assemblageItem = new AssemblageItem();
                assemblageItem.itemRef = catalog.itemRef;
                assemblageItem.commodityCodeRef = catalog.commodityCodeRef;
                assemblageItem.catalogRef = catalog.getRef();
                assemblageItem.assemblageRef = new AssemblageRef();
                assemblageItem.authoritativeAssemblageProductRef = new AuthoritativeAssemblageProductRef();
                assemblageItem.criticalRef = new CriticalRef();
                assemblageItem.deferredRef = new DeferredRef();
                assemblageItem.commingledRef = new CommingledRef();
                assemblageItems.add(assemblageItem);
            }
        }

        return assemblageItems;
    }

    public List<BuyerRef> getCustomersForCurrentUserSite(String customerType) {
        List<BuyerRef> buyerRefList = new ArrayList<>();
        List<Buyer> buyers = buyerService.getBuyersForManagedByNodeIdentifier(getCurrentUser().profile.currentNodeRef.nodeIdentifier);

        for (Buyer buyer : buyers) {
            if (!StringUtil.isBlankOrNull(customerType)) {
                // TODO - Temporary until we determine logic for retrieving only LOG Customer or Customer.
                if ((customerType.equals("LOG") && buyer.nodeRef.nodeIdentifier.equals(getCurrentUser().profile.currentNodeRef.nodeIdentifier) && StringUtil.doesStringContain(buyer.nodeRef.name, "LOG", true)) ||
                        customerType.equals("Customer") && !buyer.nodeRef.nodeIdentifier.equals(getCurrentUser().profile.currentNodeRef.nodeIdentifier)) {
                    buyerRefList.add(buyer.getRef());
                }
            } else {
                buyerRefList.add(buyer.getRef());
            }


        }
        return buyerRefList;
    }

    public List<AuthorizedNode> getBuyerAuthorizedNodes(String buyerId) {
        return buyerService.getBuyerAuthorizedNodes(buyerId);
    }

    public int getNewAuthoritativeAssemblageIndicatorDays() {
        return microservice.getNewAuthoritativeAssemblageIndicatorDays();
    }

    public String getItemCountByAssemblageId(String id) {
        return microservice.getItemCountByAssemblageId(id);
    }

    public String getCriticalItemCountByAssemblageId(String id) {
        return microservice.getCriticalItemCountByAssemblageId(id);
    }

    public void updateInventoryCycle(@NotNull Assemblage assemblage) {
        microservice.updateInventoryCycle(assemblage);
    }

    public int getSubAssemblageCount(String identifier, String increment, String instance) {

        List<Assemblage> assemblages = microservice.getSubAssemblages(identifier, increment, instance);

        if (assemblages == null || assemblages.isEmpty()) {
            return 0;
        }

        return assemblages.size();
    }

    private void logChanges(Assemblage currentAssemblage, Assemblage updatedAssemblage) {
        if (updatedAssemblage != null && currentAssemblage != null) {
            amLogger.logAssemblageChange(updatedAssemblage, "Build Control Number", currentAssemblage.buildControlNumber, updatedAssemblage.buildControlNumber, currentUserBT);
            amLogger.logAssemblageChange(updatedAssemblage, "Assemblage Location", currentAssemblage.warehouseLocation, updatedAssemblage.warehouseLocation, currentUserBT);
            amLogger.logAssemblageChange(updatedAssemblage, "Operational Status", currentAssemblage.operationalStatus, updatedAssemblage.operationalStatus, currentUserBT);
            amLogger.logAssemblageChange(updatedAssemblage, "Stock Number", currentAssemblage.stockNumber, updatedAssemblage.stockNumber, currentUserBT);
            amLogger.logAssemblageChange(updatedAssemblage, "Project Code", currentAssemblage.projectCode, updatedAssemblage.projectCode, currentUserBT);
            amLogger.logAssemblageChange(updatedAssemblage, "Transportation Organizational Identification", currentAssemblage.transOrgId, updatedAssemblage.transOrgId, currentUserBT);
            if (updatedAssemblage.equipmentReportingCodeRef != null && currentAssemblage.equipmentReportingCodeRef != null) {
                amLogger.logAssemblageChange(updatedAssemblage, "Equipment Readiness Code",
                        currentAssemblage.equipmentReportingCodeRef.code,
                        updatedAssemblage.equipmentReportingCodeRef.code, currentUserBT);
            }
            amLogger.logAssemblageChange(updatedAssemblage, "Report To JMAR", currentAssemblage.reportToJmar, updatedAssemblage.reportToJmar, currentUserBT);
            amLogger.logAssemblageFundChange(currentAssemblage, updatedAssemblage, "Fund Number", currentAssemblage.expenseCenter.name, updatedAssemblage.expenseCenter.name, currentUserBT);
        }
    }

    public void savePrimeSubItems(@NotNull List<AssemblageItem> assemblageItems) {
        microservice.savePrimeSubItems(assemblageItems);
    }

    public List<AssemblageItem> getAssemblageItemsByPrimeItemId(String id) {
        return microservice.getAssemblageItemsByPrimeItemId(id);
    }

    public List<AssemblageItem> getItemsAvailableForPrimeSub(String id) {
        return microservice.getItemsAvailableForPrimeSub(id);
    }

    public AssemblageItem updateOnHandQuantity(String assemblageId, String itemId, Integer onHandQuantity) {
        return microservice.updateOnHandQuantity(assemblageId, itemId, onHandQuantity);
    }

    @Override
    public void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate) {
        inventoryService.processDataReferenceUpdate(dataReferenceUpdate);
    }

    public List<AssemblageFinanceData> getAssemblageFinanceData(String organizationId, boolean isLog) {
        return financeAdminService.getAssemblageFinanceData(organizationId, isLog);
    }

    public SearchResult<CatalogPurchase> getAssemblageReplenishmentItems(String assemblageId, boolean showDeferredItems, boolean showCriticalItems, boolean showDatedOnlyItems, int critical, int nonCritical, Double targetAmount) {
        List<AssemblageItem> assemblageItems = microservice.getItemsByAssemblageId(assemblageId);

        setAssemblageItemDueIns(assemblageItems);

        return getCatalogInformationForAssemblage(assemblageItems, showDeferredItems, showCriticalItems, showDatedOnlyItems, critical, nonCritical, targetAmount);
    }

    public SearchResult<CatalogPurchase> getAssemblageReplenishmentItemsByExpirationDate(String assemblageId, boolean includeShortages, Date expirationDateStart, Date expirationDateEnd) {
        SearchResult<CatalogPurchase> shortageSearchResults;
        SearchResult<CatalogPurchase> expirationSearchResults;

        List<InventoryRecord> inventoryRecords = inventoryService.getInventoryRecordsForAssemblageByExpirationDate(assemblageId, expirationDateStart, expirationDateEnd);

        List<String> assemblageItemIds = new ArrayList<>();
        inventoryRecords.forEach(item -> assemblageItemIds.add(item.assemblageItemRef.id));
        List<AssemblageItem> expiringItems = microservice.getItemsByAssemblageItemIds(assemblageItemIds);

        expirationSearchResults = getCatalogInformationForExpirationItems(expiringItems, inventoryRecords);

        if(includeShortages) {
            shortageSearchResults = getAssemblageReplenishmentItems(assemblageId, false, false, false, 0, 0, 0.00);

            for(CatalogPurchase catalogPurchase : shortageSearchResults.results) {
                Optional<CatalogPurchase> matchingExpirationResult = expirationSearchResults.results.stream().filter(expireCatalogPurchase -> expireCatalogPurchase.item.getId().equals(catalogPurchase.item.getId())).findFirst();

                if(matchingExpirationResult.isPresent()) {
                    CatalogPurchase expireItemToProcess = matchingExpirationResult.get();
                    expireItemToProcess.orderQuantity = expireItemToProcess.orderQuantity + catalogPurchase.orderQuantity;
                }  else {
                    expirationSearchResults.results.add(catalogPurchase);
                }
            }
        }

        return expirationSearchResults;
    }

    private SearchResult<CatalogPurchase> getCatalogInformationForExpirationItems (List<AssemblageItem> assemblageItems, List<InventoryRecord> inventoryExpiredRecords) {
        SearchResult<CatalogPurchase> catalogPurchaseSearchResults = new SearchResult<>();
        if (!assemblageItems.isEmpty()) {
            catalogPurchaseSearchResults = catalogService.getCatalogSearchResultsForAssemblage(assemblageItems);

            catalogPurchaseSearchResults = this.calculateExpiredCatalogOrderQuantities(catalogPurchaseSearchResults, inventoryExpiredRecords);

            catalogPurchaseSearchResults.results = catalogPurchaseSearchResults.results.stream().filter(itemsAllowed -> Optional.ofNullable(itemsAllowed.orderQuantity).orElse(0) > 0).collect(Collectors.toList());
        }

        return catalogPurchaseSearchResults;
    }

    private SearchResult<CatalogPurchase> getCatalogInformationForAssemblage (List<AssemblageItem> assemblageItems, boolean showDeferredItems, boolean showCriticalItems, boolean showDatedOnlyItems, int critical, int nonCritical, Double targetAmount) {
        SearchResult<CatalogPurchase> catalogPurchaseSearchResults = new SearchResult<>();
        List<AssemblageItem> replenishmentItems = assemblageItems.stream().filter(item -> item.catalogRef != null && item.catalogRef.id != null && item.onHandQuantity != null && item.minimumQuantityAllowance != null && (item.onHandQuantity < item.minimumQuantityAllowance)).collect(Collectors.toList());
        if (!replenishmentItems.isEmpty()) {
            if (showDatedOnlyItems) {
                List<String> itemIds = new ArrayList<>();
                replenishmentItems.forEach(item -> itemIds.add(item.itemRef.id));
                List<Item> expiringItems = itemService.getItemsWithExpirationDate(itemIds);
                replenishmentItems.removeIf(replenishmentItem -> expiringItems.stream().noneMatch(expireingItem -> expireingItem._id.toString().equals(replenishmentItem.itemRef.id)));
            }
            if (!replenishmentItems.isEmpty()) {
                catalogPurchaseSearchResults = catalogService.getCatalogSearchResultsForAssemblage(replenishmentItems);
                if (showDeferredItems) {
                    catalogPurchaseSearchResults = this.calculateDeferredCatalogOrderQuantities(catalogPurchaseSearchResults, replenishmentItems);
                } else if (showCriticalItems) {
                    catalogPurchaseSearchResults = this.calculateCriticalCatalogOrderQuantities(catalogPurchaseSearchResults, replenishmentItems);
                } else {
                    catalogPurchaseSearchResults = this.calculateCatalogOrderQuantities(catalogPurchaseSearchResults, assemblageItems, replenishmentItems, critical, nonCritical, targetAmount);
                }
                catalogPurchaseSearchResults.results = catalogPurchaseSearchResults.results.stream().filter(itemsAllowed -> Optional.ofNullable(itemsAllowed.orderQuantity).orElse(0) > 0).collect(Collectors.toList());
            }
        }
        return catalogPurchaseSearchResults;
    }

    public SearchResult<CatalogPurchase> calculateCatalogOrderQuantities(SearchResult<CatalogPurchase> catalogPurchaseSearchResults, List<AssemblageItem> assemblageItems, List<AssemblageItem> replenishmentItems, int critical, int nonCritical, Double targetAmount) {

        Optional<AssemblageItem> itemOptional;
        AssemblageItem assemblageItemToProcess;
        List<Map<String,Object>> criticalItems = new ArrayList<>();
        List<Map<String,Object>> nonCriticalItems = new ArrayList<>();
        int count =0;

        for (CatalogPurchase catalogPurchase : catalogPurchaseSearchResults.results) {
            int subTotalOnHand = 0;

            itemOptional = replenishmentItems.stream().filter(assemblageItem -> assemblageItem.itemRef.getId().equals(catalogPurchase.item.getId())).findFirst();

            if (itemOptional.isPresent()) {
                assemblageItemToProcess = itemOptional.get();
                String assemblageId = assemblageItemToProcess.getId();

                if (assemblageItems.stream().anyMatch(primeItem -> primeItem.primeItemRef != null && Optional.ofNullable(primeItem.primeItemRef.id).orElse("").equals(assemblageId))) {
                    List<AssemblageItem> substituteItems = assemblageItems.stream().filter(substituteItem -> substituteItem.primeItemRef != null && Optional.ofNullable(substituteItem.primeItemRef.id).orElse("").equals(assemblageId)).collect(Collectors.toList());

                    for (AssemblageItem substituteItem : substituteItems) {
                        subTotalOnHand = subTotalOnHand + (int)Math.floor(substituteItem.onHandQuantity * ((double)substituteItem.primeRatio / (double)substituteItem.subRatio));
                    }
                }
                int onHandValue = assemblageItemToProcess.onHandQuantity + assemblageItemToProcess.dueInQuantity + Optional.ofNullable(assemblageItemToProcess.deferredQuantity).orElse(0) + Optional.ofNullable(assemblageItemToProcess.commingledQuantity).orElse(0) + subTotalOnHand;
                if (critical > 0 && nonCritical == 0) {
                    if (assemblageItemToProcess.criticalQuantity != null && assemblageItemToProcess.criticalQuantity > 0) {
                        catalogPurchase.orderQuantity = (int)Math.ceil((assemblageItemToProcess.criticalQuantity - onHandValue) * ((float) critical /100));
                    } else {
                        catalogPurchase.orderQuantity = 0;
                    }
                } else if (nonCritical > 0 && critical == 100) {
                    if (assemblageItemToProcess.criticalQuantity != null && assemblageItemToProcess.criticalQuantity > 0) {
                        catalogPurchase.orderQuantity = assemblageItemToProcess.criticalQuantity - onHandValue;
                    } else {
                        catalogPurchase.orderQuantity = (int)Math.ceil((assemblageItemToProcess.minimumQuantityAllowance - onHandValue) * ((float) nonCritical /100));
                    }
                } else if (targetAmount > 0) {
                    catalogPurchase.orderQuantity = 0;
                    Map<String, Object> map = new HashMap<>();
                    map.put(ON_HAND, onHandValue);
                    map.put(PRICE, catalogPurchase.catalog.price.getDoubleVal());
                    map.put(INDEX, count);
                    if (assemblageItemToProcess.criticalQuantity != null && assemblageItemToProcess.criticalQuantity > 0) {
                        map.put(SHORTAGE, assemblageItemToProcess.criticalQuantity - onHandValue);
                        criticalItems.add(map);
                    } else {
                        map.put(SHORTAGE, assemblageItemToProcess.minimumQuantityAllowance - onHandValue);
                        nonCriticalItems.add(map);
                    }
                } else {
                    catalogPurchase.orderQuantity = assemblageItemToProcess.minimumQuantityAllowance - onHandValue;
                }
            }
            count++;
        }

        if (targetAmount != 0) {
            double totalOrderedAmount = 0.00;
            criticalItems.sort(Comparator.comparingDouble(myMap -> (Double)myMap.get(PRICE)));
            totalOrderedAmount = updateCatalogPurchases(catalogPurchaseSearchResults.results, criticalItems.stream().filter(item -> (Integer)item.get(ON_HAND) == 0).collect(Collectors.toList()), totalOrderedAmount, targetAmount);
            totalOrderedAmount = updateCatalogPurchases(catalogPurchaseSearchResults.results, criticalItems.stream().filter(item -> (Integer)item.get(ON_HAND) > 0).collect(Collectors.toList()), totalOrderedAmount, targetAmount);
            nonCriticalItems.sort(Comparator.comparingDouble(myMap -> (Double)myMap.get(PRICE)));
            totalOrderedAmount = updateCatalogPurchases(catalogPurchaseSearchResults.results, nonCriticalItems.stream().filter(item -> (Integer)item.get(ON_HAND) == 0).collect(Collectors.toList()), totalOrderedAmount, targetAmount);
            updateCatalogPurchases(catalogPurchaseSearchResults.results, nonCriticalItems.stream().filter(item -> (Integer)item.get(ON_HAND) > 0).collect(Collectors.toList()), totalOrderedAmount, targetAmount);
        }
        return catalogPurchaseSearchResults;
    }

    private double updateCatalogPurchases(List<CatalogPurchase> catalogPurchases, List<Map<String,Object>> items, double totalOrderedAmount, double targetAmount) {
        Object[] results;
        do {
            results = updateCatalogPurchaseOrderQuantity(catalogPurchases, items, totalOrderedAmount, targetAmount);
            totalOrderedAmount = (Double)results[0];
        } while ((Boolean)results[1]);
        return (Double)results[0];
    }

    private Object[] updateCatalogPurchaseOrderQuantity(List<CatalogPurchase> catalogPurchases, List<Map<String,Object>> items, double totalOrderedAmount, double targetAmount) {
        boolean incrementedOrder = false;
        for (Map<String,Object> item : items) {
            CatalogPurchase catalogPurchase = catalogPurchases.get((Integer)item.get(INDEX));
            if (catalogPurchase.orderQuantity < (Integer) item.get(SHORTAGE) && (catalogPurchase.catalog.price.getDoubleVal() + totalOrderedAmount) <= targetAmount) {
                catalogPurchase.orderQuantity++;
                totalOrderedAmount += catalogPurchase.catalog.price.getDoubleVal();
                incrementedOrder = true;
            }
        }
        return new Object[]{totalOrderedAmount, incrementedOrder};
    }

    public SearchResult<CatalogPurchase> calculateExpiredCatalogOrderQuantities(SearchResult<CatalogPurchase> catalogPurchaseSearchResults, List<InventoryRecord> inventoryExpiredRecords) {
        for (CatalogPurchase catalogPurchase : catalogPurchaseSearchResults.results) {

              List<InventoryRecord> inventoryRecordsForThisItem = inventoryExpiredRecords.stream().filter(inventoryRecord -> inventoryRecord.itemRef.getId().equals(catalogPurchase.item.getId())).collect(Collectors.toList());

              if(!inventoryRecordsForThisItem.isEmpty()) {
                  catalogPurchase.orderQuantity = inventoryRecordsForThisItem.get(0).itemLocations.stream().filter(location ->
                          location.itemStorage.get(0).onHandQty > 0 ).mapToInt(location -> location.itemStorage.get(0).onHandQty).sum();
              }
        }

        return catalogPurchaseSearchResults;
    }

    public SearchResult<CatalogPurchase> calculateDeferredCatalogOrderQuantities(SearchResult<CatalogPurchase> catalogPurchaseSearchResults, List<AssemblageItem> replenishmentItems) {
        for (CatalogPurchase catalogPurchase : catalogPurchaseSearchResults.results) {
            Optional<AssemblageItem> itemOptional = replenishmentItems.stream().filter(assemblageItem -> assemblageItem.itemRef.getId().equals(catalogPurchase.item.getId())).findFirst();

            itemOptional.ifPresent(assemblageItem -> catalogPurchase.orderQuantity = assemblageItem.deferredQuantity);
        }

        return catalogPurchaseSearchResults;
    }

    public SearchResult<CatalogPurchase> calculateCriticalCatalogOrderQuantities(SearchResult<CatalogPurchase> catalogPurchaseSearchResults, List<AssemblageItem> replenishmentItems) {
        for (CatalogPurchase catalogPurchase : catalogPurchaseSearchResults.results) {
            Optional<AssemblageItem> itemOptional = replenishmentItems.stream().filter(assemblageItem -> assemblageItem.criticalQuantity != null && assemblageItem.criticalQuantity > assemblageItem.onHandQuantity && assemblageItem.itemRef.getId().equals(catalogPurchase.item.getId())).findFirst();

            itemOptional.ifPresent(assemblageItem -> catalogPurchase.orderQuantity = assemblageItem.criticalQuantity - assemblageItem.onHandQuantity - assemblageItem.dueInQuantity);
        }

        return catalogPurchaseSearchResults;
    }

    public List<FundingNodeBalance> getLogOwnedFundBalances(String directId, String salesId) {
        List<String> fundingNodeChildIds = new ArrayList<>();
        fundingNodeChildIds.add(directId);
        fundingNodeChildIds.add(salesId);

        return financeAdminService.getBalancesByChildId(fundingNodeChildIds);
    }

    public List<FundingNodeBalance> getCustomerOwnedFundBalances(String id) {
        List<String> fundingNodeChildIds = new ArrayList<>();
        fundingNodeChildIds.add(id);

        return financeAdminService.getBalancesByChildId(fundingNodeChildIds);
    }

    public Double getMaxFundingAvailableBalance(String directId, String salesId, String expenseCenter) {
        Double availableBalance = 0.00;
        List<FundingNodeBalance> fundingNodeBalances = !expenseCenter.isBlank() ? financeAdminService.getBalancesByChildId(List.of(expenseCenter)) :
                financeAdminService.getBalancesByChildId(List.of(directId, salesId));
        for (FundingNodeBalance fundingNodeBalance : fundingNodeBalances) {
            if (fundingNodeBalance.balances.availableBalance.getDoubleVal() > availableBalance) {
                availableBalance = fundingNodeBalance.balances.availableBalance.getDoubleVal();
            }
        }
        return availableBalance;
    }

    public AssemblageBusinessEvent saveBusinessEventHistory(AssemblageBusinessEventInfo assemblageBusinessEventInfo) {
        return microservice.saveBusinessEventHistory(assemblageBusinessEventInfo);
    }

    public void saveBusinessEventsHistory(List<AssemblageBusinessEventInfo>assemblageBusinessEventInfo) {
        microservice.saveBusinessEventsHistory(assemblageBusinessEventInfo);
    }

    public List<InventoryRecord> getAssemblageItemsByItemIdForInternalTransfer(String id, String assemblageId) {
        List<InventoryRecord> inventoryRecords = inventoryService.getInventoryRecordsForTransferableAssemblageItems(id);
        if (!inventoryRecords.isEmpty()) {
            inventoryRecords.removeIf(i -> i.assemblageRef.id.equals(assemblageId) ||
                    i.itemLocations.stream().filter(l -> l.itemStorage.get(0).stratificationRef.name.equals("Assemblage Serviceable")).mapToInt
                            (q -> q.itemStorage.get(0).onHandQty).sum() <= (i.assemblageItemRef.minimumQuantityAllowance == null ? 0 : i.assemblageItemRef.minimumQuantityAllowance));
        }
        return inventoryRecords;
    }

    public void setAssemblageItemDueIns(List<AssemblageItem> assemblageItems) {
        for(AssemblageItem assemblageItem: assemblageItems) {
            List<OrderItem> orderItems = orderService.getOrderItemsByAssemblageAndItemId(assemblageItem.assemblageRef.id, assemblageItem.itemRef.id);
            int dueInQuantity = 0;
            if(!orderItems.isEmpty()) {
                dueInQuantity = orderItems.stream().filter(order -> order.remainingQuantity > 0).mapToInt(order -> order.remainingQuantity).sum();
            }
            assemblageItem.dueInQuantity = dueInQuantity;
        }
    }

    public List<AssemblageItem> getAssemblageItemByAssemblageIdAndCustomerItemIdAndEnterpriseProductId(String assemblageId, String customerItemId, String enterpriseProductId) {
        return microservice.getAssemblageItemByAssemblageIdAndCustomerItemIdAndEnterpriseProductId(assemblageId, customerItemId, enterpriseProductId);
    }

    private void setAssemblageItemCatalogInfo(AssemblageItem assemblageItem) {
        Item item = itemService.getItemById(assemblageItem.itemRef.getId());
        if (item != null) {
            assemblageItem.expirationType = Boolean.TRUE.equals(item.hasExpirationDate) && Boolean.TRUE.equals(item.isExtendableExpirationDate) ? "Dated - Extendable" :
                    Boolean.TRUE.equals(item.hasExpirationDate) && (item.isExtendableExpirationDate == null || Boolean.FALSE.equals(item.isExtendableExpirationDate)) ? "Dated - Non Extendable" : "Not Deteriorative";
        }
    }

    public void deleteAssemblageItem(@NotNull AssemblageItem assemblageItem) {
        microservice.deleteAssemblageItem(assemblageItem);
    }

    public Organization getParentOrganization(String organizationId) {
        return organizationService.getParentOrganization(organizationId);
    }

    public void deleteAssemblages(@NotNull List<Assemblage> assemblages) {
        List<String> orderInformationIds = new ArrayList<>();
        List<String> assemblageIds = assemblages.stream().map(Assemblage::getId).collect(Collectors.toList());

        inventoryService.deleteInventoryRecordsForAssemblages(assemblageIds);
        // TODO: update the on hand qty for items inventory after delete
        cartService.deleteCartItemsForAssemblages(assemblageIds);
        orderService.deleteOrderItemsForAssemblages(assemblageIds);
        for (Assemblage assemblage : assemblages) {
            List<OrderItem> orderItems = orderService.getOrderItemsByAssemblageId(assemblage.getId());
            for (OrderItem orderItem : orderItems) {
                if(orderItem.remainingQuantity == 0) {
                    orderInformationIds.add(orderItem.orderInformationRef.id);
                }
            }
        }
        if (orderInformationIds.size() > 0) {
            for (String orderInformationId : orderInformationIds) {
                OrderInformation orderInformation = orderService.getOrderInformationById(orderInformationId);
                for (OrderItemRef orderItemRef: orderInformation.orderItemRefs) {
                    if (orderItemRef.remainingQuantity == 0) {
                        orderService.removeOrderItemRef(orderItemRef);
                    }
                }
                if (orderService.getOrderInformationById(orderInformationId).orderItemRefs == null ||
                        orderService.getOrderInformationById(orderInformationId).orderItemRefs.size() == 0) {
                    orderService.deleteOrderInformationById(orderInformationId);
                }
            }
        }
        microservice.deleteAssemblages(assemblages);
    }

}
