package logicole.gateway.services.finance;

import io.swagger.annotations.Api;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.finance.purchasecard.OrderSummary;
import logicole.common.datamodels.finance.purchasecard.PurchaseCardRef;
import logicole.common.datamodels.finance.purchasecard.PurchaseCardRegister;
import logicole.common.datamodels.finance.purchasecard.ReconciliationHistory;
import logicole.common.datamodels.finance.purchasecard.ReconciliationPeriod;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"purchaseCardRegister"})
@ApplicationScoped
@Path("/purchaseCardRegister")
public class PurchaseCardRegisterRestApi extends ExternalRestApi<PurchaseCardRegisterService> {

    @POST
    @Path("/createPurchaseCardRegister")
    public PurchaseCardRegister createPurchaseCardRegister(PurchaseCardRegister purchaseCardRegister) {
        return service.createPurchaseCardRegister(purchaseCardRegister);
    }

    @GET
    @Path("/getPurchaseCardRegisterById")
    public PurchaseCardRegister getPurchaseCardRegisterById(@QueryParam("id") String id) {
        return service.getPurchaseCardRegisterById(id);
    }

    @POST
    @Path("/getPurchaseCardRegisterByRef")
    public List<PurchaseCardRegister> getPurchaseCardRegisterByRef(PurchaseCardRef purchaseCardRef) {
        return service.getPurchaseCardRegisterByRef(purchaseCardRef);
    }

    @GET
    @Path("/getCurrentReconciliationPeriod")
    public ReconciliationPeriod getCurrentReconciliationPeriod(@QueryParam("purchaseCardId") String purchaseCardId) {
        return service.getCurrentReconciliationPeriod(purchaseCardId);
    }

    @GET
    @Path("/getReconciliationPeriods")
    public List<ReconciliationPeriod> getReconciliationPeriods(@QueryParam("purchaseCardId") String purchaseCardId) {
        return service.getReconciliationPeriods(purchaseCardId);
    }

    @GET
    @Path("/getUnreconciledRegister")
    public List<PurchaseCardRegister> getUnreconciledRegister(@QueryParam("purchaseCardId") String purchaseCardId) {
        return service.getUnreconciledRegister(purchaseCardId);
    }

    @GET
    @Path("/reconcile")
    public PurchaseCardRegister reconcile(@QueryParam("registerId") String registerId, @QueryParam("amount") String amount) {
        return service.reconcile(registerId, amount);
    }

    @GET
    @Path("/voidReconciliationHistory")
    public ReconciliationHistory voidReconciliationHistory(@QueryParam("reconciliationHistoryId") String reconciliationHistoryId) {
        return service.voidReconciliationHistory(reconciliationHistoryId);
    }

    @GET
    @Path("/disputeRegister")
    public PurchaseCardRegister disputeRegister(@QueryParam("registerId") String registerId, @QueryParam("amount") String amount) {
        return service.disputeRegister(registerId, amount);
    }

    @GET
    @Path("/updateStatementTotal")
    public ReconciliationPeriod updateStatementTotal(@QueryParam("reconciliationPeriodId") String reconciliationPeriodId,
                                                     @QueryParam("amount") String amount) {
        return service.updateStatementTotal(reconciliationPeriodId, amount);
    }

    @GET
    @Path("/getOrderSummary")
    public OrderSummary getOrderSummary(@QueryParam("orderId") String orderId) {
        OrderSummary orderSummary = new OrderSummary();
        orderSummary.orderStatus = "Closed";
        orderSummary.orderTotal = new MonetaryValue();
        return orderSummary;
        //TODO: this needs to query the database
    }

    @GET
    @Path("/getReconciliationHistories")
    public List<ReconciliationHistory> getReconciliationHistories(@QueryParam("purchaseCardRegisterId") String purchaseCardRegisterId) {
        return service.getReconciliationHistories(purchaseCardRegisterId);
    }

    @GET
    @Path("/getRegisterForPeriod")
    public List<PurchaseCardRegister> getRegisterForPeriod(@QueryParam("purchaseCardId") String purchaseCardId, @QueryParam("periodId") String periodId) {
        return service.getRegisterForPeriod(purchaseCardId, periodId);
    }

}
