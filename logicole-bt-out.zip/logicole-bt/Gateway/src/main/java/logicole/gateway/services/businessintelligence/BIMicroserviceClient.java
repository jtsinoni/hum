package logicole.gateway.services.businessintelligence;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

import logicole.apis.businessintelligence.IBusinessIntelligenceMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

@ApplicationScoped
public class BIMicroserviceClient extends MicroserviceClient<IBusinessIntelligenceMicroserviceApi>{

	public BIMicroserviceClient() {
        super(IBusinessIntelligenceMicroserviceApi.class, "logicole-businessintelligence");
    }

	@Produces
    public IBusinessIntelligenceMicroserviceApi getIBIMicroserviceApi() {
        return createClient();
    }

}
