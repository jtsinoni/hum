package logicole.gateway.services.search;

import io.swagger.annotations.Api;
import logicole.common.datamodels.search.request.DmlesSearchRequest;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import java.io.IOException;

@Api(tags = {"Search"})
@ApplicationScoped
@Path("/search")
public class SearchRestApi extends ExternalRestApi<SearchService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @POST
    @Path("/getSearchResults")
    public String getSearchResults(DmlesSearchRequest dmlesSearchRequest) throws IOException, ApplicationException {
        return service.getSearchResults(dmlesSearchRequest);
    }
}
