package logicole.gateway.services.assemblage;

import io.swagger.annotations.Api;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Api(tags = {"AuthoritativeAssemblageSync"})
@ApplicationScoped
@Path("/authoritativeAssemblageSync")
public class AuthoritativeAssemblageSyncRestApi extends ExternalRestApi<AuthoritativeAssemblageSyncService> {

    @GET
    @Path("/syncAuthoritativeAssemblages")
    public void syncAuthoritativeAssemblages() {
        service.syncAuthoritativeAssemblages();
    }
}
