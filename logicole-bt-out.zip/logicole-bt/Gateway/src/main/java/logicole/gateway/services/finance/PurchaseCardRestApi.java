package logicole.gateway.services.finance;

import io.swagger.annotations.Api;
import logicole.common.datamodels.finance.purchasecard.PurchaseCard;
import logicole.common.datamodels.finance.purchasecard.PurchaseCardRef;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.user.UserProfileRef;
import logicole.common.datamodels.workflow.WorkflowStepSummary;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"purchaseCard"})
@ApplicationScoped
@Path("/purchaseCard")
public class PurchaseCardRestApi extends ExternalRestApi<PurchaseCardService> {

    @POST
    @Path("/createPurchaseCard")
    public PurchaseCard createPurchaseCard(PurchaseCard purchaseCard) {
        return service.createPurchaseCard(purchaseCard);
    }

    @POST
    @Path("/updatePurchaseCard")
    public PurchaseCard updatePurchaseCard(PurchaseCard purchaseCard) {
        return service.updatePurchaseCard(purchaseCard);
    }

    @GET
    @Path("/getPurchaseCardById")
    public PurchaseCard getPurchaseCardById(@QueryParam("id") String id) {
        return service.getPurchaseCardById(id);
    }

    @POST
    @Path("/getPurchaseCardsByRef")
    public List<PurchaseCard> getPurchaseCardsByRef(UserProfileRef userProfileRef) {
        return service.getPurchaseCardsByRef(userProfileRef);
    }

    @POST
    @Path("/getPurchaseCardsByOrg")
    public List<PurchaseCard> getPurchaseCardsByOrg(OrganizationRef organizationRef) {
        return service.getPurchaseCardsByOrg(organizationRef);
    }

    @GET
    @Path("/getPurchaseCardsBySearchText")
    public List<PurchaseCard> getPurchaseCardsBySearchText(@QueryParam("searchText") String searchText, @QueryParam("userProfileId") String userProfileId) {
        return service.getPurchaseCardsBySearchText(searchText, userProfileId);
    }

    @GET
    @Path("/getActivePurchaseCardsByFundingNode")
    public List<PurchaseCardRef> getActivePurchaseCardsByFundingNode(@QueryParam("fundingNodeId") String fundingNodeId) {
        return service.getActivePurchaseCardsByFundingNode(fundingNodeId);
    }

    @POST
    @Path("/validate")
    public PurchaseCard validate(PurchaseCard purchaseCard) {
        return service.validate(purchaseCard);
    }

    @POST
    @Path("/cancel")
    public PurchaseCard cancel(PurchaseCard purchaseCard) {
        return service.cancel(purchaseCard);
    }

    @POST
    @Path("/verify")
    public PurchaseCard verify(PurchaseCard purchaseCard) {
        return service.verify(purchaseCard);
    }

    @POST
    @Path("/reject")
    public PurchaseCard reject(PurchaseCard purchaseCard) {
        return service.reject(purchaseCard);
    }

    @POST
    @Path("/reset")
    public PurchaseCard reset(PurchaseCard purchaseCard) {
        return service.reset(purchaseCard);
    }

    @POST
    @Path("/delete")
    public PurchaseCard delete(PurchaseCard purchaseCard) {
        service.delete(purchaseCard);
        return purchaseCard;
    }
    @POST
    @Path("/buildWorkflowStepSummary")
    public List<WorkflowStepSummary> buildWorkflowStepSummary(PurchaseCard purchaseCard) {
        return service.buildWorkflowStepSummary(purchaseCard);
    }

    @POST
    @Path("/getApprovingOfficials")
    public List<UserProfileRef> getApprovingOfficials(UserProfileRef userProfileRef) {
        return service.getApprovingOfficials(userProfileRef);
    }
    @GET
    @Path("/getApprovedCardholderProfiles")
    public List<UserProfileRef> getApprovedCardholderProfiles() {
        return service.getApprovedCardholderProfiles();
    }

    @GET
    @Path("/getPurchaseCardTypes")
    public List<String> getPurchaseCardTypes() {
        return service.getPurchaseCardTypes();
    }

    @GET
    @Path("/getPurchaseCardSubTypes")
    public List<String> getPurchaseCardSubTypes() {
        return service.getPurchaseCardSubTypes();
    }

    @GET
    @Path("/getPurchaseCardFundingSourceTypes")
    public List<String> getPurchaseCardFundingSourceTypes() {
        return service.getPurchaseCardFundingSourceTypes();
    }

}
