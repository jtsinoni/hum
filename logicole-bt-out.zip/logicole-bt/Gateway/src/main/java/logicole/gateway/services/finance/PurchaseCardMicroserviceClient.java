package logicole.gateway.services.finance;

import logicole.apis.finance.IPurchaseCardMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class PurchaseCardMicroserviceClient extends MicroserviceClient<IPurchaseCardMicroserviceApi> {
    public PurchaseCardMicroserviceClient(){
        super(IPurchaseCardMicroserviceApi.class, "logicole-finance");
    }

    @Produces
    public IPurchaseCardMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
