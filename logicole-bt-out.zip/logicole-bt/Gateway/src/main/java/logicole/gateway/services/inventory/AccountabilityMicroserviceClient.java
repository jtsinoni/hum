package logicole.gateway.services.inventory;

import logicole.apis.inventory.IAccountabilityMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AccountabilityMicroserviceClient extends MicroserviceClient<IAccountabilityMicroserviceApi> {
    public AccountabilityMicroserviceClient() {
        super(IAccountabilityMicroserviceApi.class, "logicole-inventory");
    }

    @Produces
    public IAccountabilityMicroserviceApi getIAccountabilityMicroserviceApi() {
        return createClient();
    }
}
