package logicole.gateway.services.filemanager;

import logicole.apis.filemanager.IFileManagerAdminMicroserviceApi;
import logicole.common.datamodels.Configuration;
import logicole.common.datamodels.filemanager.CommonUploadedFile;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.filemanager.FileRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.user.UserService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.BadRequestException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;


@ApplicationScoped
public class FileManagerAdminService extends BaseGatewayService<IFileManagerAdminMicroserviceApi> {

    private static final Integer MAX_BULK_FILE_REMOVE_COUNT = 1000;

    @Inject
    private UserService userService;

    @Inject
    private MultiPartFormUtil uploadUtil;

    public FileManagerAdminService() {
        super("FileManagerAdmin");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public FileManager uploadManaged(MultipartFormDataInput form, Integer maxUploadSize) throws ApplicationException {
        InputStream inputStream;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            verifyFileName(uploadedFileName);
        } catch (BadRequestException e) {
            throw new ApplicationException("Was not able to verify file for managed file upload: " + uploadedFileName);
        }

        try {
            inputStream = inputPart.getBody(InputStream.class, null);
        } catch (IOException ioe) {
            throw new ApplicationException("Was not able to extract file from request " + uploadedFileName);
        }

        return microservice.uploadManaged(uploadedFileName, getCurrentUser().profile.currentNodeRef.getId(), inputStream);
    }

    public FileManager uploadManaged(byte[] fileContent, String uploadedFileName) throws ApplicationException {
        try {
            verifyFileName(uploadedFileName);
        } catch (BadRequestException e) {
            throw new ApplicationException("Was not able to verify file for managed file upload: " + uploadedFileName);
        }
        return microservice.uploadManaged(uploadedFileName, getCurrentUser().profile.currentNodeRef.getId(), fileContent);
    }

    public FileManager uploadManagedWithCustomValues(byte[] fileContent,
                                                     String uploadedFileName,
                                                     String uploadedByUserId,
                                                     Date uploadedDateTime) throws ApplicationException {
        try {
            verifyFileName(uploadedFileName);
        } catch (BadRequestException e) {
            throw new ApplicationException("Was not able to verify file for managed file upload: " + uploadedFileName);
        }
        return microservice.uploadManagedWithCustomValues(
                uploadedFileName,
                getCurrentUser().profile.currentNodeRef.getId(),
                uploadedByUserId,
                uploadedDateTime,
                fileContent);
    }

    public FileManager uploadUnmanaged(String relativeFilePath, String fileName, MultipartFormDataInput form) throws ApplicationException {
        InputStream inputStream;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = ((fileName != null) && !fileName.equals("")) ? fileName : uploadUtil.getFileName(inputPart.getHeaders());

        try {
            verifyFileName(uploadedFileName);
        } catch (BadRequestException e) {
            throw new ApplicationException("Was not able to verify file for unmanaged file upload: " + uploadedFileName);
        }

        try {
            inputStream = inputPart.getBody(InputStream.class, null);
        } catch (IOException ioe) {
            logger.info("Issue processing incoming file", ioe);
            throw new ApplicationException("Was not able to extract file from request " + uploadedFileName);
        }

        return microservice.uploadUnmanaged(relativeFilePath,
                uploadedFileName,
                getCurrentUser().profile.currentNodeRef.getId(),
                inputStream);
    }

    public FileManager updateUnmanaged(String relativeFilePath, String fileName, String data) throws ApplicationException {
        InputStream byteStream = new ByteArrayInputStream(data.getBytes(StandardCharsets.UTF_8));

        return microservice.updateUnmanaged(relativeFilePath,
                fileName,
                getCurrentUser().profile.currentNodeRef.getId(),
                byteStream);
    }

    public FileManager createUnmanagedFile(String relativeFilePath, String fileName, String data) throws ApplicationException {
        InputStream byteStream = new ByteArrayInputStream(data.getBytes(StandardCharsets.UTF_8));

        return microservice.uploadUnmanaged(relativeFilePath,
                fileName,
                getCurrentUser().profile.currentNodeRef.getId(),
                byteStream);
    }

    public FileManager copyUnmanaged(String srcRelativeFilePath, String fileName, String tgtRelativeFilePath) throws ApplicationException {

        return microservice.copyUnmanaged(srcRelativeFilePath,
                fileName,
                getCurrentUser().profile.currentNodeRef.getId(),
                tgtRelativeFilePath);
    }

    public FileManager uploadUnmanagedFileWithName(String nfsShareFileName, String relativeFilePath, String fileName) {
        return microservice.uploadUnmanagedFileWithName(nfsShareFileName, relativeFilePath, fileName, getCurrentUser().profile.currentNodeRef.getId());
    }

    public FileManager uploadUnmanagedFile(String nfsShareFileName, String relativeFilePath) throws ApplicationException {
        return microservice.uploadUnmanagedFile(nfsShareFileName, relativeFilePath, getCurrentUser().profile.currentNodeRef.getId());
    }

    public CommonUploadedFile download(String fileId) throws ApplicationException {
        return microservice.download(fileId);
    }

    public String getUnmanagedFileType(String relativeFilePath) throws ApplicationException {
        return microservice.getUnmanagedFileType(relativeFilePath);
    }

    public Byte[] getFileContents(String fileId) throws IOException, ApplicationException {
        return microservice.getFileContents(fileId);
    }

    public String getEmailBodyString(boolean success) throws ApplicationException {
        return microservice.getEmailBodyString(success);
    }

    public Byte[] getUnmanagedFileContents(String relativePath) throws IOException, ApplicationException {
        return microservice.getUnmanagedFileContents(relativePath);
    }

    public byte[] getFileContentsAsPrimitiveByte(String fileId) throws IOException, ApplicationException {
        return microservice.getFileContentsAsPrimitiveByte(fileId);
    }

    public Boolean removeFile(String fileId) throws IOException, ApplicationException {
        return microservice.removeFile(fileId);
    }

    public Boolean removeFileUnmanaged(String fileId) throws IOException, ApplicationException {
        return microservice.removeFileUnmanaged(fileId);
    }

    public CommonUploadedFile base64Download(String fileId) throws IOException, ApplicationException {
        return microservice.base64Download(fileId);
    }

    public FileManager getFileInfo(String fileId) {
        return microservice.getFileInfo(fileId);
    }

    public FileManager getUnmanagedFileInfo(String relativePath, String uploadedFileName) throws ApplicationException {
        return microservice.getUnmanagedFileInfo(relativePath, uploadedFileName);
    }

    public List<FileManager> getRelatedUnmanagedFileInfo(String relativePath) throws ApplicationException {
        return microservice.getRelatedUnmanagedFileInfo(relativePath);
    }

    public Integer getMaxPostSize() throws ApplicationException {
        return microservice.getMaxPostSize();
    }

    public List<String> getForbiddenFileExtensions() throws ApplicationException {
        return microservice.getForbiddenFileExtensions();
    }

    private void verifyFileName(String filename) throws ApplicationException {
        List<String> forbiddenList = getForbiddenFileExtensions();

        String extension = '.' + FilenameUtils.getExtension(filename);
        if (forbiddenList.contains(extension)) {
            throw new BadRequestException("Invalid file type");
        }
    }

    public List<Configuration> getAllConfigurations() {
        return microservice.getAllConfigurations();
    }

    public Configuration addUpdateConfiguration(Configuration configuration) {
        return microservice.addUpdateConfiguration(configuration);
    }

    public Configuration getConfiguration(String id) {
        return microservice.getConfiguration(id);
    }

    public Configuration getConfigurationByName(String name) {
        return microservice.getConfigurationByName(name);
    }

    public Integer removeFilesManaged(List<String> fileIds) throws ApplicationException, IOException {
        if (CollectionUtils.isEmpty(fileIds)) {
            throw new ApplicationException("At least one file id is required");
        }
        if (fileIds.size() > MAX_BULK_FILE_REMOVE_COUNT) {
            throw new ApplicationException(String.format("a maximum of %d file ids are allowed", MAX_BULK_FILE_REMOVE_COUNT));
        }

        return microservice.removeFilesManaged(fileIds);
    }

    public Integer removeFilesManagedByNodeAndDate(String nodeId, Date startDate, Date endDate, List<String> userProfileIds) throws ApplicationException, IOException {
        if (nodeId == null || nodeId.isEmpty() || nodeId.isBlank()) {
            throw new ApplicationException("nodeId is required");
        }
        if (startDate == null) {
            throw new ApplicationException("startDate is required");
        }
        if (endDate != null && endDate.compareTo(startDate) <= 0) {
            throw new ApplicationException("endDate must be after startDate");
        }

        return microservice.removeFilesManagedByNodeAndDate(nodeId, startDate, endDate, userProfileIds);
    }

    public FileRef getFileRefById(String fileId) {
        FileRef fileRef = microservice.getFileRefById(fileId);
        if (fileRef != null) {
            if (!StringUtil.isEmptyOrNull(fileRef.uploadedBy)) {
                UserProfile userProfile = userService.getUserProfileById(fileRef.uploadedBy);
                if (userProfile != null) {
                    fileRef.uploadedByName = userProfile.lastName + ", " + userProfile.firstName;
                }
            }
        }
        return fileRef;
    }

    public List<FileRef> getFileRefsByIds(List<String> fileIds) {
        List<FileRef> fileRefs = microservice.getFileRefsByIds(fileIds);
        fileRefs.forEach(fileRef -> {
            if (!StringUtil.isEmptyOrNull(fileRef.uploadedBy)) {
                UserProfile userProfile = userService.getUserProfileById(fileRef.uploadedBy);
                if (userProfile != null) {
                    fileRef.uploadedByName = userProfile.lastName + ", " + userProfile.firstName;
                }
            }
        });
        return fileRefs;
    }

}
