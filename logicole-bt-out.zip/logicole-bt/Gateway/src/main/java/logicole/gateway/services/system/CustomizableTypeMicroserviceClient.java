package logicole.gateway.services.system;

import logicole.apis.system.ICustomizableTypeMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class CustomizableTypeMicroserviceClient extends MicroserviceClient<ICustomizableTypeMicroserviceApi> {
    public CustomizableTypeMicroserviceClient() {
        super(ICustomizableTypeMicroserviceApi.class, "logicole-system");
    }
    
    @Produces
    public ICustomizableTypeMicroserviceApi getICustomizableTypeMicroserviceApi() {
        return createClient();
    }
    
}
