package logicole.gateway.services.catalog;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import logicole.common.datamodels.abi.item.SuggestedItemDTO;
import logicole.common.datamodels.catalog.*;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.finance.referencedata.CommodityCode;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountDTO;
import logicole.common.datamodels.sale.seller.SellerRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Api(tags = {"Catalog"})
@ApplicationScoped
@Path("/catalog")
public class CatalogRestApi extends ExternalRestApi<CatalogService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getById")
    public Catalog getById(@QueryParam("id") String id) {
        return service.getById(id);
    }

    @GET
    @Path("/getByEnterpriseProductIdentifier")
    public List<Catalog> getByEnterpriseProductIdentifier(@QueryParam("buyerId") String buyerId, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        // return service.getByEnterpriseProductIdentifier(buyerId, enterpriseProductIdentifier);
        return null;
    }

    @GET
    @Path("/getPreferredSourceByEnterpriseProductIdentifier")
    public List<Catalog> getPreferredSourcesByEnterpriseProductIdentifier(@QueryParam("buyerId") String buyerId, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.getPreferredSourcesByEnterpriseProductIdentifier(buyerId, enterpriseProductIdentifier);
    }

    @GET
    @Path("/getByBuyerId")
    public List<Catalog> getByBuyerId(@QueryParam("buyerId") String buyerId) {
        // return service.getByEnterpriseProductIdentifier(buyerId, enterpriseProductIdentifier);
        return null;
    }

    @POST
    @Path("/addCatalogRecord")
    @ApiOperation(value = "Insert new Catalog record")
    public CatalogAddResult addCatalogRecord(CatalogAddRequest catalogAddRequest) {
        return service.addCatalogRecord(catalogAddRequest);
    }

    @POST
    @Path("/updateCatalogRecord")
    public Catalog updateCatalogRecord(Catalog catalog) {
        return service.updateCatalogRecord(catalog);
    }

    @POST
    @Path("/addItemToCatalog")
    @ApiOperation(value = "Update Existing Catalog Record")
    public Catalog addItemToCatalog(@QueryParam("id") String id, Item newItem) {
        return service.addItemToCatalog(id, newItem);
    }

    @POST
    @Path("/addEntireCatalog")
    public List<Catalog> addEntireCatalog(List<Catalog> catalog) {
        return service.saveEntireCatalog(catalog);
    }

    @POST
    @Path("/getCatalogSearchResults")
    public SearchResult<CatalogDTO> getCatalogSearchResults(SearchInput searchInput) {
        return service.getCatalogSearchResults(searchInput);
    }

    @POST
    @Path("/getScopedCatalogSearchResults")
    public SearchResult<CatalogDTO> getScopedCatalogSearchResults(@QueryParam("scope") String scope, SearchInput searchInput ) {
        return service.getScopedCatalogSearchResults(scope, searchInput);
    }

    @POST
    @Path("/getNonCatalogPurchaseSearchResults")
    public SearchResult<CatalogDTO> getNonCatalogPurchaseSearchResults(SearchInput searchInput) {
        return service.getNonCatalogPurchaseSearchResults(searchInput);
    }

    @POST
    @Path("/getOrderCatalogIds")
    public List<String> getOrderCatalogIds(List<String> nonCatalogPurchaseIds) {
        return service.getOrderCatalogIds(nonCatalogPurchaseIds);
    }

    @GET
    @Path("/applyCasingAndSubstitutionRules")
    @Produces(MediaType.TEXT_PLAIN)
    public String applyCasingAndSubstitutionRules(@QueryParam("text") String text) {
        return service.applyCasingAndSubstitutionRules(text);
    }

    @POST
    @Path("/updateLocalItemInformation")
    public CatalogUpdateResult updateLocalItemInformation(CatalogUpdateRequest catalogUpdateRequest) {
        return service.updateLocalItemInformation(catalogUpdateRequest);
    }

    @GET
    @Path("/getCatalogWithItemById")
    public CatalogItem getCatalogWithItemById(@QueryParam("id") String id) {
        return service.getCatalogWithItemById(id);
    }

    @GET
    @Path("/getCatalogItemCommodityCodeList")
    public List<CommodityCode> getCatalogItemCommodityCodeList() {
        return service.getCatalogItemCommodityCodeList();
    }

    @POST
    @Path("/getCatalogCommodityResults")
    public List<Catalog> getCatalogCommodityResults(String searchText) {
        return service.getCatalogCommodityResults(searchText);
    }

    @POST
    @Path("/getCatalogProductGroupResults")
    public List<Catalog> getCatalogProductGroupResults(String searchText) {
        return service.getCatalogProductGroupResults(searchText);
    }

    @POST
    @Path("/getCatalogProductSubstituteGroupResults")
    public List<Catalog> getCatalogProductSubstituteGroupResults(String searchText) {
        return service.getCatalogProductSubstituteGroupResults(searchText);
    }

    @GET
    @Path("/findExistingCatalogItems")
    public List<SuggestedItemDTO> findExistingCatalogItems(@QueryParam("manufacturerName") String manufacturerName, @QueryParam("manufacturerCatalogNumber") String manufacturerCatalogNumber, @QueryParam("ndc") String ndc) {
        return service.findExistingCatalogItems(manufacturerName, manufacturerCatalogNumber, ndc);

    }

    @GET
    @Path("/getCatalogSourcing")
    public CatalogSourcing getCatalogSourcing(@QueryParam("catalogItemIdentifier") String catalogItemIdentifier){
        return service.getCatalogSourcing(catalogItemIdentifier);
    }

    @GET
    @Path("/getAuthorizedSellersForCurrentNode")
    public List<BuyerSellerAccountDTO> getAuthorizedSellersForCurrentNode(){
        return service.getAuthorizedSellersForCurrentNode();
    }

    @POST
    @Path("/getSellerRefFromBuyerSellerAccount")
    public SellerRef getSellerRefFromBuyerSellerAccount(BuyerSellerAccountDTO buyerSellerAccount) {
        return service.getSellerRefFromBuyerSellerAccount(buyerSellerAccount);
    }

    @POST
    @Path("/addCatalogSourcingRecord")
    @ApiOperation(value = "Insert new Catalog Sourcing record")
    public Catalog addCatalogSourcingRecord(Catalog catalogSourcingRecord) {
        return service.addCatalogSourcingRecord(catalogSourcingRecord);
    }

    @GET
    @Path("/getSearchLimit")
    public Integer getSearchLimit() {
        return service.getSearchLimit();
    }

}