package logicole.gateway.services.user;

import logicole.apis.user.IInvitationMicroserviceApi;
import logicole.common.cache.CurrentUserCache;
import logicole.common.datamodels.notification.EmailMessage;
import logicole.common.datamodels.user.AdminProfileUpdate;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.EUserStatus;
import logicole.common.datamodels.user.GroupInvitation;
import logicole.common.datamodels.user.GroupInvitationProfileTableData;
import logicole.common.datamodels.user.InvitationDashboardInfo;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.datamodels.user.UserProfileWrapper;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.system.NotificationService;
import logicole.gateway.services.system.SystemFeatureFlagService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class InvitationService extends BaseGatewayService<IInvitationMicroserviceApi> {

    @Inject
    private CurrentUserCache currentUserCache;

    @Inject
    NotificationService notificationService;

    @Inject
    SystemFeatureFlagService systemFeatureFlagService;

    @Inject
    UserService userService;

    public InvitationService() {
        super("User");
    }

    public UserProfile acceptGroupInvitation(UserProfile userProfile) throws ApplicationException {
        userService.updateUserProfileNodeRefs(userProfile);
        UserProfile persistedProfile = microservice.acceptGroupInvitation(userProfile);
        userService.sendBusinessIntelligenceRoleAddedEmail(persistedProfile, null);
        return persistedProfile;
    }

    public UserProfile acceptInvitationByPendingUser(UserProfile userProfile) throws ApplicationException {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        if (null != currentUser) {
            if (userProfile.pkiDn.equals(currentUser.profile.pkiDn)) {
                userService.updateUserProfileNodeRefs(userProfile);
                userProfile = microservice.acceptInvitationByPendingUser(userProfile);
                currentUserCache.remove(currentUser.profile.pkiDn);
                userService.sendBusinessIntelligenceRoleAddedEmail(userProfile, null);
            } else {
                throw new ApplicationException("The current user cannot accept the invitation at this time");
            }
        }
        return userProfile;
    }

    public UserProfile approveInvitationByManager(UserProfile userProfile) {
        userService.updateUserProfileNodeRefs(userProfile);
        UserProfile persistedProfile = microservice.approveInvitationByManager(userProfile);
        userService.sendBusinessIntelligenceRoleAddedEmail(persistedProfile, null);
        return persistedProfile;
    }

    public GroupInvitation createInvitation(GroupInvitation groupInvitation) {
        return microservice.createInvitation(groupInvitation);
    }

    public UserProfile denyGroupInvitationByManager(@QueryParam("userProfileId") String userProfileId, @QueryParam("reason") String reason) throws ApplicationException {
        return microservice.denyGroupInvitationByManager(userProfileId, reason);
    }

    public boolean denyGroupInvitationByUser(String userProfileId) {
        return microservice.denyGroupInvitationByUser(userProfileId);
    }

    public UserProfile denySingleInvitationByAdmin(@QueryParam("invitationId") String invitationId, @QueryParam("reason") String reason) throws ApplicationException {
        return microservice.denySingleInvitationByAdmin(invitationId, reason);
    }

    public boolean denySingleInvitationByUser(String invitationId) {
        return microservice.denySingleInvitationByUser(invitationId);
    }

    public List<GroupInvitation> getAllGroupInvitations() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();

        List<GroupInvitation> groupInvitationList = microservice.getAllGroupInvitations(currentUser.profile.currentNodeRef);

        List<GroupInvitation> newGroupInvitationList = new ArrayList<>();
        for (GroupInvitation groupInvitation : groupInvitationList) {
            groupInvitation.pendingCount = microservice.getGroupInvitationCounts(groupInvitation.getId(), EUserStatus.PENDING);
            groupInvitation.activeCount = microservice.getGroupInvitationCounts(groupInvitation.getId(), EUserStatus.ACTIVE);
            groupInvitation.deniedCount = microservice.getGroupInvitationCounts(groupInvitation.getId(), EUserStatus.CANCELLED);
            newGroupInvitationList.add(groupInvitation);
        }

        return newGroupInvitationList;
    }

    public GroupInvitation getGroupInvitation(String invitationId) {
        return microservice.getGroupInvitation(invitationId);
    }

    public String getGroupInvitationUrl(String invitationId) throws ApplicationException {
        return microservice.getGroupInvitationUrl(invitationId);
    }

    public List<GroupInvitationProfileTableData> getProfilesByGroupInvitationId(String groupInvitationId) {
        return microservice.getProfilesByGroupInvitationId(groupInvitationId);
    }

    public UserProfile getProfileByInvitationId(String invitationId) {
        UserProfile userProfile = microservice.getProfileByInvitationId(invitationId);
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        userProfile.pkiDn = currentUser.profile.pkiDn;
        userProfile = userService.updateUserProfilePKIDN(userProfile);
        userProfile = userService.updateUserProfileBusinessIntelligenceId(userProfile);

        return userProfile;
    }

    public UserProfile resendInvitation(String invitationId) throws ApplicationException {
        UserProfileWrapper wrapper = microservice.resendInvitation(invitationId);
        notificationService.sendEmails(wrapper.messages);
        return wrapper.profile;
    }

    public GroupInvitation updateGroupInvitation(GroupInvitation groupInvitation) throws ApplicationException {
        boolean isUserRequestFeatureFlagActive = systemFeatureFlagService.checkIfUserRequestFeatureFlagIsActive();
        return microservice.updateGroupInvitation(isUserRequestFeatureFlagActive, groupInvitation);
    }

    public GroupInvitation saveGroupInvitationAssignableRoles(GroupInvitation groupInvitation) {
        return microservice.saveGroupInvitationAssignableRoles(groupInvitation);
    }

    public UserProfile updateProfileInvitationByAdmin(AdminProfileUpdate profile) {
        return microservice.updateProfileInvitationByAdmin(profile);
    }

    public UserProfile getProfileByGroupInvitationId(String groupInvitationId) throws ApplicationException {
        return microservice.getProfileByGroupInvitationId(groupInvitationId);
    }

    public Boolean sendUserInvitationDecisionEmail(String userProfileId, boolean isSingleInvite) throws ApplicationException {
        EmailMessage message = microservice.sendUserInvitationDecisionEmail(userProfileId, isSingleInvite);
        notificationService.sendEmail(message);
        return true;
    }

    public Boolean sendActivatedByManagerEmail(@QueryParam("userProfileId") String userProfileId) throws ApplicationException {
        EmailMessage message = microservice.sendActivatedByManagerEmail(userProfileId);
        notificationService.sendEmail(message);
        return Boolean.TRUE;
    }

    public Boolean sendManagerDeniedEmail(@QueryParam("userProfileId") String userProfileId) throws ApplicationException {
        EmailMessage message = microservice.sendManagerDeniedEmail(userProfileId);
        notificationService.sendEmail(message);
        return Boolean.TRUE;
    }

    public Boolean sendManagerApprovedEmail(@QueryParam("userProfileId") String userProfileId) throws ApplicationException {
        EmailMessage message = microservice.sendManagerApprovedEmail(userProfileId);
        notificationService.sendEmail(message);
        return Boolean.TRUE;
    }

    public InvitationDashboardInfo getInvitationDashboardStats() throws ApplicationException {
//        throw new ApplicationException("This is a test");
//        throw new ApplicationException("WARN:This is a test");
        return microservice.getInvitationDashboardStats();
    }

    public List<GroupInvitation> getGroupInvitationsForNodeId(String id) {
        return microservice.getGroupInvitationsForNodeId(id);
    }

}
