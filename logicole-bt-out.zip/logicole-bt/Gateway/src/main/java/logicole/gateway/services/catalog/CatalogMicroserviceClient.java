package logicole.gateway.services.catalog;

import logicole.apis.catalog.ICatalogMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class CatalogMicroserviceClient extends MicroserviceClient<ICatalogMicroserviceApi> {
    public CatalogMicroserviceClient(){
        super(ICatalogMicroserviceApi.class, "logicole-catalog");
    }

    @Produces
    public ICatalogMicroserviceApi getICatalogMicroserviceApi() {
        return createClient();
    }

}
