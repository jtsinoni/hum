package logicole.gateway.services.finance;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.finance.request.RequestGroup;
import logicole.common.datamodels.organization.OrganizationRef;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonFinanceRequestFromApi {
    public String eventType;
    public String sourceType;
    public List<RequestGroup> requestGroups;
    public OrganizationRef requestingOrg;
    public FinancialSystem financialSystem;
}
