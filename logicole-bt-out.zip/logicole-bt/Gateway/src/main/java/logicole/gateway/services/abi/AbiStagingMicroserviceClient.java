package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiStagingMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiStagingMicroserviceClient extends MicroserviceClient<IAbiStagingMicroserviceApi> {
    public AbiStagingMicroserviceClient() {
        super(IAbiStagingMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiStagingMicroserviceApi getABiStagingService() {
        return createClient();
    }
}

