package logicole.gateway.services.organization;

import logicole.apis.organization.IOrganizationTreeStructureMicroserviceApi;
import logicole.common.datamodels.organization.OrganizationTreeStructure;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class OrganizationTreeStructureService extends BaseGatewayService<IOrganizationTreeStructureMicroserviceApi> {
    public OrganizationTreeStructureService() {
        super("OrganizationTreeStructure");
    }

    public List<OrganizationTreeStructure> getOrganizationTreeStructures(String orgId) {
        return microservice.getOrganizationTreeStructures(orgId);
    }

    public OrganizationTreeStructure getOrganizationTreeStructure(String orgTreeStructureId) {
        return microservice.getOrganizationTreeStructure(orgTreeStructureId);
    }

    public OrganizationTreeStructure createOrganizationTreeStructure(OrganizationTreeStructure organizationTreeStructure) {
        return microservice.createOrganizationTreeStructure(organizationTreeStructure);
    }

    public OrganizationTreeStructure updateOrganizationTreeStructure(OrganizationTreeStructure organizationTreeStructure) {
        return microservice.updateOrganizationTreeStructure(organizationTreeStructure);
    }

    public void deleteOrganizationTreeStructure(String organizationTreeStructureId) {
        microservice.deleteOrganizationTreeStructure(organizationTreeStructureId);
    }

}
