package logicole.gateway.services.assemblage;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import logicole.common.datamodels.assemblage.Assemblage;
import logicole.common.datamodels.assemblage.AssemblageInfo;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

@Api(tags = {"AssemblageShipment"})
@ApplicationScoped
@Path("/assemblageShipment")
public class AssemblageShipmentRestApi extends ExternalRestApi<AssemblageShipmentService> {
    @Inject
    private MultiPartFormUtil uploadUtil;

    @POST
    @Path("/uploadInShipmentFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Import a file", notes = "The return value will be the FileManager")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to import",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadInShipmentFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        byte[] content;

        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            InputStream inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new ApplicationException("Unable to upload file " + uploadedFileName);
        }

        return service.uploadInShipmentFile(content, uploadedFileName);
    }

    @GET
    @Path("/getAssemblagesForInShipmentFile")
    public List<Assemblage> getAssemblagesForInShipmentFile(@QueryParam("fileId") String fileId) throws IOException {
        return service.getAssemblagesForInShipmentFile(fileId);
    }

    @POST
    @Path("/importExternalAssemblages")
    public List<Assemblage> importExternalAssemblages (AssemblageInfo assemblageInfo) throws ParseException, IOException {
        return service.importExternalAssemblages(assemblageInfo);
    }

    @POST
    @Path("/removeInShipmentFiles")
    public void removeInShipmentFiles(ArrayList<String> fileIds) throws ApplicationException, IOException
            {
        service.removeInShipmentFiles(fileIds);
    }

    @POST
    @Path("/outshipAssemblages")
    public byte[] outshipAssemblages (AssemblageInfo assemblageInfo) throws IOException {
        return service.outShipAssemblages(assemblageInfo);
    }
}
