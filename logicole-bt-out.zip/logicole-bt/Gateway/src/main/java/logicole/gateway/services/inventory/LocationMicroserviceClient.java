package logicole.gateway.services.inventory;

import logicole.apis.inventory.ILocationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class LocationMicroserviceClient  extends MicroserviceClient<ILocationMicroserviceApi> {
    public LocationMicroserviceClient() {
        super(ILocationMicroserviceApi.class, "logicole-inventory");
    }

    @Produces
    public ILocationMicroserviceApi getILocationMicroserviceApi() {
        return createClient();
    }
}
