package logicole.gateway.services.report;

import logicole.apis.report.IReportMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class ReportMicroserviceClient extends MicroserviceClient<IReportMicroserviceApi> {
    public ReportMicroserviceClient() {
        super(IReportMicroserviceApi.class, "logicole-report");
    }

    @Produces
    public IReportMicroserviceApi getReportService() {
        return createClient();
    }
}

