package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.IMaintenanceProcedureMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.catalog.Catalog;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.maintenance.plan.EMaintenanceIntervalType;
import logicole.common.datamodels.maintenance.plan.MaintenancePlan;
import logicole.common.datamodels.maintenance.plan.MaintenancePlanRef;
import logicole.common.datamodels.maintenance.procedure.CalibrationTask;
import logicole.common.datamodels.maintenance.procedure.CatalogedPart;
import logicole.common.datamodels.maintenance.procedure.CloneMaintenanceProcedure;
import logicole.common.datamodels.maintenance.procedure.ETaskType;
import logicole.common.datamodels.maintenance.procedure.GenericPart;
import logicole.common.datamodels.maintenance.procedure.MaintenanceProcedure;
import logicole.common.datamodels.maintenance.procedure.MaintenanceProcedureCatalogedPart;
import logicole.common.datamodels.maintenance.procedure.MaintenanceProcedureGenericPart;
import logicole.common.datamodels.maintenance.procedure.MaintenanceProcedureMiscellaneousSupply;
import logicole.common.datamodels.maintenance.procedure.MaintenanceProcedureTestEquipmentSpecialTool;
import logicole.common.datamodels.maintenance.procedure.MedicalEquipmentMaintenanceProcedureSummary;
import logicole.common.datamodels.maintenance.procedure.MiscellaneousSupply;
import logicole.common.datamodels.maintenance.procedure.SpecialCharacter;
import logicole.common.datamodels.maintenance.procedure.Task;
import logicole.common.datamodels.maintenance.procedure.TestEquipmentSpecialTool;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.security.SecurityConstants;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.common.UnauthorizedException;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.catalog.CatalogService;
import logicole.gateway.services.filemanager.FileManagerAdminService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@ApplicationScoped
public class MaintenanceProcedureService extends BaseGatewayService<IMaintenanceProcedureMicroserviceApi> {

    private static final String NULL_NODE_LEVEL = "Current User Node Type level must not be null";
    private static final String NO_MAINTENANCE_PROCEDURE_FOUND = "No Maintenance Procedure found with id of %s";
    private static final String CANNOT_EDIT_MAINTENANCE_PROCEDURE = "Cannot edit Maintenance Procedure";
    private static final Integer AGENCY_LEVEL = 100;

    @Inject
    private MaintenancePlanService maintenancePlanService;
    @Inject
    private CatalogService catalogService;
    @Inject
    private ItemService itemService;
    @Inject
    private FileManagerAdminService fileManagerAdminService;

    public MaintenanceProcedureService() {
        super("MaintenanceProcedure");
    }

    private void validateAllowedToEditMaintenanceProcedure(String id) {
        MaintenanceProcedure maintenanceProcedure = microservice.findById(id);
        if (maintenanceProcedure == null) {
            throw new ApplicationException(String.format(NO_MAINTENANCE_PROCEDURE_FOUND, id));
        }
        validateAllowedToEditMaintenanceProcedure(maintenanceProcedure);
    }

    public MaintenanceProcedure cloneById(String id) {
        MaintenanceProcedure existingMaintenanceProcedure = microservice.findById(id);
        CloneMaintenanceProcedure maintenanceProcedure = new CloneMaintenanceProcedure();
        maintenanceProcedure.id = id;
        maintenanceProcedure.currentUserNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        maintenanceProcedure.isProcedureAgencyLevel = existingMaintenanceProcedure.isAgencyLevel;
        return microservice.clone(maintenanceProcedure);
    }

    private void validateAllowedToEditMaintenanceProcedure(MaintenanceProcedure maintenanceProcedure) {
        if (!isAllowedToEditMaintenanceProcedure(maintenanceProcedure)) {
            throw new ApplicationException(CANNOT_EDIT_MAINTENANCE_PROCEDURE);
        }
    }

    private boolean isAllowedToEditMaintenanceProcedure(MaintenanceProcedure maintenanceProcedure) {
        return isMDBUser() || currentUserBT.getCurrentNodeId().equals(maintenanceProcedure.managedByNodeRef.id);
    }

    public MaintenanceProcedure createMaintenanceProcedureDraft(MaintenanceProcedure maintenanceProcedure) {
        maintenanceProcedure.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        maintenanceProcedure.isAgencyLevel = AGENCY_LEVEL.equals(getLevel());
        return microservice.createMaintenanceProcedureDraft(maintenanceProcedure);
    }

    private Integer getLevel() {
        Integer level = currentUserBT.getCurrentUser().profile.nodeTypeRef.level;
        if (level == null) {
            throw new ValidationException(NULL_NODE_LEVEL);
        }
        return level;
    }

    public MaintenanceProcedure finalizeMaintenanceProcedureDraft(String id) {
        validateAllowedToEditMaintenanceProcedure(id);
        MaintenanceProcedure maintenanceProcedure = microservice.finalizeMaintenanceProcedureDraft(id);
        maintenancePlanService.updateMaintenanceProcedureReferences(maintenanceProcedure);
        return maintenanceProcedure;
    }

    public MaintenanceProcedure inactivateMaintenanceProcedure(String id) {
        return microservice.inactivateMaintenanceProcedure(id, currentUserBT.getCurrentNodeId());
    }

    public MaintenanceProcedure createDraftFromId(String id) {
        return microservice.createDraftFromId(id);
    }

    public MaintenanceProcedure findById(String id) {
        MaintenanceProcedure maintenanceProcedure = microservice.findById(id);
        if (null == maintenanceProcedure) {
            throw new ApplicationException(String.format(NO_MAINTENANCE_PROCEDURE_FOUND, id));
        }
        validateMaintenanceProcedureUserAccess(maintenanceProcedure);
        return maintenanceProcedure;
    }

    private void validateMaintenanceProcedureUserAccess(@NotNull MaintenanceProcedure maintenanceProcedure) {
        boolean orgAccessAllowed;
        if (AGENCY_LEVEL.equals(getLevel())) {
            orgAccessAllowed = maintenanceProcedure.managedByNodeRef.ancestry.contains(currentUserBT.getCurrentNodeId());
        } else {
            orgAccessAllowed = currentUserBT.getCurrentUser().profile.currentNodeRef.ancestry.contains(maintenanceProcedure.managedByNodeRef.id);
        }

        if (!isMDBUser() && !orgAccessAllowed) {
            throw new UnauthorizedException("Unauthorized access");
        }
    }

    private boolean isMDBUser() {
        return Objects.equals(currentUserBT.getCurrentUser().profile.pkiDn, SecurityConstants.MDB_SPECIAL_USER_PROFILE_KEY);
    }

    public MaintenanceProcedure saveMaintenanceProcedureHeaderInformation(MaintenanceProcedure maintenanceProcedure) {
        validateAllowedToEditMaintenanceProcedure(maintenanceProcedure.getId());
        return microservice.saveMaintenanceProcedureHeaderInformation(maintenanceProcedure);
    }

    public SearchResult<MaintenanceProcedure> getMaintenanceProcedureSearchResults(SearchInput searchInput) {
        String ancestry = currentUserBT.getCurrentUser().profile.currentNodeRef.ancestry;
        return microservice.getMaintenanceProcedureSearchResults(searchInput, ancestry, getLevel());
    }

    public MaintenanceProcedure updateGeneralInformation(MaintenanceProcedure maintenanceProcedure) {
        validateAllowedToEditMaintenanceProcedure(maintenanceProcedure.getId());
        return microservice.updateGeneralInformation(maintenanceProcedure);
    }

    public List<MaintenancePlan> getMaintenancePlansForMaintenanceProcedure(String id) {
        return maintenancePlanService.getMaintenancePlansForMaintenanceProcedure(id);
    }

    public MaintenanceProcedure deleteById(String id) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.deleteById(id);
    }

    public List<GenericPart> getGenericParts() {
        return microservice.getGenericParts();
    }

    public GenericPart addGenericPart(GenericPart genericPart) {
        genericPart.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.addGenericPart(genericPart);
    }

    public GenericPart updateGenericPart(GenericPart genericPart) {
        return microservice.updateGenericPart(genericPart);
    }

    public boolean deleteGenericPart(@NotNull @QueryParam("id") String id) {
        return microservice.deleteGenericPart(id);
    }

    public MaintenanceProcedure addMaintenanceProcedureGenericPart(String id, MaintenanceProcedureGenericPart genericPart) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.addMaintenanceProcedureGenericPart(id, genericPart);
    }

    public MaintenanceProcedure updateMaintenanceProcedureGenericPart(String id, MaintenanceProcedureGenericPart genericPart) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.updateMaintenanceProcedureGenericPart(id, genericPart);
    }

    public MaintenanceProcedure deleteMaintenanceProcedureGenericPart(String id, MaintenanceProcedureGenericPart genericPart) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.deleteMaintenanceProcedureGenericPart(id, genericPart);
    }

    public MaintenanceProcedure newMaintenanceProcedureGenericPart(String id, int quantity, String maintenanceIntervalType, GenericPart genericPart) {
        validateAllowedToEditMaintenanceProcedure(id);
        GenericPart persistedGenericPart = addGenericPart(genericPart);
        MaintenanceProcedureGenericPart maintenanceProcedureGenericPart = new MaintenanceProcedureGenericPart();
        maintenanceProcedureGenericPart.genericPartRef = persistedGenericPart.getRef();
        maintenanceProcedureGenericPart.quantity = quantity;
        Optional<EMaintenanceIntervalType> eMaintenanceIntervalType = Arrays.stream(EMaintenanceIntervalType.values()).filter(type -> type.getJsonValue().equalsIgnoreCase(maintenanceIntervalType)).findFirst();
        maintenanceProcedureGenericPart.maintenanceIntervalType = eMaintenanceIntervalType.orElseThrow();
        return microservice.addMaintenanceProcedureGenericPart(id, maintenanceProcedureGenericPart);
    }

    public List<CatalogedPart> getCatalogParts() {
        String managedByNodeId = currentUserBT.getCurrentNodeId();
        List<CatalogedPart> catalogedParts = new ArrayList<>();
        List<Catalog> catalogs = catalogService.getMedicalEquipmentRepairParts(managedByNodeId);

        for (Catalog catalog : catalogs) {
            Item item = getItemForCatalog(catalog);
            if (item != null) {
                CatalogedPart catalogedPart = new CatalogedPart();
                catalogedPart.id = catalog.getId();
                catalogedPart.description = catalog.shortDescription;
                catalogedPart.itemId = item.getId();
                catalogedPart.manufacturer = item.manufacturer;
                catalogedPart.manufacturerCatalogNumber = item.manufacturerCatalogNumber;
                catalogedParts.add(catalogedPart);
            }
        }
        return catalogedParts;
    }

    public MaintenanceProcedure addMaintenanceProcedureCatalogPart(String id, MaintenanceProcedureCatalogedPart mpCatalogPart) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.addMaintenanceProcedureCatalogPart(id, mpCatalogPart);
    }

    public MaintenanceProcedure updateMaintenanceProcedureCatalogPart(String id, MaintenanceProcedureCatalogedPart mpCatalogPart) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.updateMaintenanceProcedureCatalogPart(id, mpCatalogPart);
    }

    public MaintenanceProcedure deleteMaintenanceProcedureCatalogPart(String id, MaintenanceProcedureCatalogedPart mpCatalogPart) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.deleteMaintenanceProcedureCatalogPart(id, mpCatalogPart);
    }

    private Item getItemForCatalog(Catalog catalog) {
        Item item = null;
        if (catalog.itemRef != null && !StringUtil.isBlankOrNull(catalog.itemRef.getId())) {
            item = itemService.getItemById(catalog.itemRef.getId());
        }
        return item;
    }

    public List<EMaintenanceIntervalType> getMaintenanceIntervalTypes() {
        return List.of(EMaintenanceIntervalType.values());
    }

    public List<TestEquipmentSpecialTool> getTestEquipmentSpecialTools() {
        return microservice.getTestEquipmentSpecialTools();
    }

    public TestEquipmentSpecialTool createTestEquipmentSpecialTool(TestEquipmentSpecialTool testEquipmentSpecialTool) {
        testEquipmentSpecialTool.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.createTestEquipmentSpecialTool(testEquipmentSpecialTool);
    }

    public TestEquipmentSpecialTool updateTestEquipmentSpecialTool(TestEquipmentSpecialTool testEquipmentSpecialTool) {
        return microservice.updateTestEquipmentSpecialTool(testEquipmentSpecialTool);
    }

    public void deleteTestEquipmentSpecialToolById(String id) {
        microservice.deleteTestEquipmentSpecialToolById(id);
    }

    public List<MiscellaneousSupply> getMiscellaneousSupplies() {
        return microservice.getMiscellaneousSupplies();
    }

    public MiscellaneousSupply addMiscellaneousSupply(MiscellaneousSupply miscellaneousSupply) {
        miscellaneousSupply.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.addMiscellaneousSupply(miscellaneousSupply);
    }

    public MiscellaneousSupply updateMiscellaneousSupply(MiscellaneousSupply miscellaneousSupply) {
        return microservice.updateMiscellaneousSupply(miscellaneousSupply);
    }

    public boolean deleteMiscellaneousSupply(@NotNull @QueryParam("id") String id) {
        return microservice.deleteMiscellaneousSupply(id);
    }

    public List<SpecialCharacter> getSpecialCharacters() {
        return microservice.getSpecialCharacters();
    }

    public SearchResult<MaintenanceProcedure> getSiteMaintenanceProcedures(SearchInput searchInput) {
        String currentNodeAncestry = currentUserBT.getCurrentUser().profile.currentNodeRef.ancestry;
        return microservice.getSiteMaintenanceProcedures(searchInput, currentNodeAncestry, getLevel());
    }

    public MaintenanceProcedure copyTasks(String id, String type, List<Task> tasks) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.copyTasks(id, type, tasks);
    }

    public MaintenanceProcedure copyCalibrationTasks(String id, String type, List<CalibrationTask> calibrationTasks) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.copyCalibrationTasks(id, type, calibrationTasks);
    }

    public List<String> getTaskTypeOptions() {
        return ETaskType.getDisplayTextList();
    }

    public MaintenanceProcedure addPreventiveMaintenanceTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.addPreventiveMaintenanceTask(id, task);
    }

    public MaintenanceProcedure updatePreventiveMaintenanceTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.updatePreventiveMaintenanceTask(id, task);
    }

    public MaintenanceProcedure deletePreventiveMaintenanceTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.deletePreventiveMaintenanceTask(id, task);
    }

    public MaintenanceProcedure addMaintenanceProcedureTestEquipmentSpecialTool(String id, MaintenanceProcedureTestEquipmentSpecialTool testEquipmentSpecialTool) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.addMaintenanceProcedureTestEquipmentSpecialTool(id, testEquipmentSpecialTool);
    }

    public MaintenanceProcedure updateMaintenanceProcedureTestEquipmentSpecialTool(String id, MaintenanceProcedureTestEquipmentSpecialTool testEquipmentSpecialTool) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.updateMaintenanceProcedureTestEquipmentSpecialTool(id, testEquipmentSpecialTool);
    }

    public MaintenanceProcedure deleteMaintenanceProcedureTestEquipmentSpecialTool(String id, MaintenanceProcedureTestEquipmentSpecialTool testEquipmentSpecialTool) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.deleteMaintenanceProcedureTestEquipmentSpecialTool(id, testEquipmentSpecialTool);
    }

    public MaintenanceProcedure createMaintenanceProcedureTestEquipmentSpecialTool(String id, MaintenanceProcedureTestEquipmentSpecialTool testEquipmentSpecialTool) {
        validateAllowedToEditMaintenanceProcedure(id);
        if (testEquipmentSpecialTool != null && testEquipmentSpecialTool.testEquipmentSpecialToolRef != null) {
            testEquipmentSpecialTool.testEquipmentSpecialToolRef.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        }

        return microservice.createMaintenanceProcedureTestEquipmentSpecialTool(id, testEquipmentSpecialTool);
    }

    public MaintenanceProcedure addMaintenanceProcedureMiscellaneousSupply(String id, MaintenanceProcedureMiscellaneousSupply miscellaneousSupply) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.addMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply);
    }

    public MaintenanceProcedure updateMaintenanceProcedureMiscellaneousSupply(String id, MaintenanceProcedureMiscellaneousSupply miscellaneousSupply) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.updateMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply);
    }

    public MaintenanceProcedure deleteMaintenanceProcedureMiscellaneousSupply(String id, MaintenanceProcedureMiscellaneousSupply miscellaneousSupply) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.deleteMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply);
    }

    public MaintenanceProcedure createMaintenanceProcedureMiscellaneousSupply(String id, MaintenanceProcedureMiscellaneousSupply miscellaneousSupply) {
        validateAllowedToEditMaintenanceProcedure(id);
        if (miscellaneousSupply != null && miscellaneousSupply.miscellaneousSupplyRef != null) {
            miscellaneousSupply.miscellaneousSupplyRef.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        }

        return microservice.createMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply);
    }

    public List<MedicalEquipmentMaintenanceProcedureSummary> getMedicalEquipmentMaintenanceProcedureSummaries() {
        String nodeId = currentUserBT.getCurrentUser().profile.currentNodeRef.getId();
        return microservice.getMedicalEquipmentMaintenanceProcedureSummaries(nodeId);
    }

    public List<MedicalEquipmentMaintenanceProcedureSummary> getAgencyMedicalEquipmentMaintenanceProcedureSummaries() {
        String nodeId = currentUserBT.getCurrentUser().profile.currentNodeRef.getId();
        return microservice.getAgencyMedicalEquipmentMaintenanceProcedureSummaries(nodeId);
    }

    public MaintenanceProcedure associateMaintenancePlan(String id, MaintenancePlanRef maintenancePlanRef) {
        return microservice.associateMaintenancePlan(id, maintenancePlanRef);
    }

    public MaintenanceProcedure unassociateMaintenancePlan(String id, MaintenancePlanRef maintenancePlanRef) {
        return microservice.unassociateMaintenancePlan(id, maintenancePlanRef);
    }

    public MaintenanceProcedure addCalibrationTask(String id, CalibrationTask calibrationTask) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.addCalibrationTask(id, calibrationTask);
    }

    public MaintenanceProcedure updateCalibrationTask(String id, CalibrationTask calibrationTask) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.updateCalibrationTask(id, calibrationTask);
    }

    public MaintenanceProcedure deleteCalibrationTask(String id, CalibrationTask calibrationTask) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.deleteCalibrationTask(id, calibrationTask);
    }

    public MaintenanceProcedure addInspectionTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.addInspectionTask(id, task);
    }

    public MaintenanceProcedure updateInspectionTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.updateInspectionTask(id, task);
    }

    public MaintenanceProcedure deleteInspectionTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.deleteInspectionTask(id, task);
    }

    public MaintenanceProcedure addScheduledPartsReplacementTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.addScheduledPartsReplacementTask(id, task);
    }

    public MaintenanceProcedure updateScheduledPartsReplacementTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.updateScheduledPartsReplacementTask(id, task);
    }

    public MaintenanceProcedure deleteScheduledPartsReplacementTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.deleteScheduledPartsReplacementTask(id, task);
    }

    public MaintenanceProcedure addAcceptanceInspectionTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.addAcceptanceInspectionTask(id, task);
    }

    public MaintenanceProcedure updateAcceptanceInspectionTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.updateAcceptanceInspectionTask(id, task);
    }

    public MaintenanceProcedure deleteAcceptanceInspectionTask(String id, Task task) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.deleteAcceptanceInspectionTask(id, task);
    }

    public MaintenanceProcedure addAcceptanceCalibrationTask(String id, CalibrationTask calibrationTask) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.addAcceptanceCalibrationTask(id, calibrationTask);
    }

    public MaintenanceProcedure updateAcceptanceCalibrationTask(String id, CalibrationTask calibrationTask) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.updateAcceptanceCalibrationTask(id, calibrationTask);
    }

    public MaintenanceProcedure deleteAcceptanceCalibrationTask(String id, CalibrationTask calibrationTask) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.deleteAcceptanceCalibrationTask(id, calibrationTask);
    }

    public MaintenanceProcedure promoteMaintenanceProcedureToAgencyLevel(String id) {
        CloneMaintenanceProcedure cloneMaintenanceProcedure = new CloneMaintenanceProcedure();
        cloneMaintenanceProcedure.id = id;
        cloneMaintenanceProcedure.isProcedureAgencyLevel = false;
        cloneMaintenanceProcedure.currentUserNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        cloneMaintenanceProcedure.userLevel = getLevel();
        return microservice.clone(cloneMaintenanceProcedure);
    }

    public Integer getMaxUploadSize() {
        return microservice.getMaxUploadSize();
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }

    public List<Attachment> addAttachment(String id, Attachment attachment) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.addAttachment(id, attachment);
    }

    public List<Attachment> saveAttachment(String id, Attachment attachment) {
        validateAllowedToEditMaintenanceProcedure(id);
        return microservice.saveAttachment(id, attachment);
    }

    public List<Attachment> removeAttachment(String id, String fileId) throws IOException {
        validateAllowedToEditMaintenanceProcedure(id);

        try {
            fileManagerAdminService.removeFile(fileId);
        } catch (FatalProcessingException | ApplicationException e) {
            throw new ApplicationException("Was not able to remove the file");
        }

        return microservice.removeAttachment(id, fileId);
    }
}
