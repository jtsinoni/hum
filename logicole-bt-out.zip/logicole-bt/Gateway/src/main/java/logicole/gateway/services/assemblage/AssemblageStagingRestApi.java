package logicole.gateway.services.assemblage;

import io.swagger.annotations.Api;
import logicole.common.datamodels.assemblage.AuthoritativeAssemblage;
import logicole.common.datamodels.assemblage.AuthoritativeAssemblageInfo;
import logicole.common.datamodels.assemblage.AuthoritativeAssemblageProduct;
import logicole.common.datamodels.assemblage.MoveStageAuthoritativeAssemblageResponse;
import logicole.common.datamodels.assemblage.postgres.NsnProductDetail;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.workflow.WorkflowStepSummary;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.lang3.StringUtils;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.io.IOException;
import java.util.List;

@Api(tags = {"AssemblageStaging"})
@ApplicationScoped
@Path("/assemblageStaging")
public class AssemblageStagingRestApi extends ExternalRestApi<AssemblageStagingService> {

    @POST
    @Path("/saveAuthoritativeAssemblageToStage")
    public AuthoritativeAssemblage saveAuthoritativeAssemblageToStage(AuthoritativeAssemblageInfo authoritativeAssemblageInfo){
        AuthoritativeAssemblage savedAssemblage = service.saveAuthoritativeAssemblageToStage(authoritativeAssemblageInfo);

        if(savedAssemblage.workflowState == null || savedAssemblage.workflowState.currentStep == null || StringUtils.isEmpty(savedAssemblage.workflowState.currentStep.name))
        {
            savedAssemblage = service.create(savedAssemblage);
        }
        else
        {
            savedAssemblage = service.edit(savedAssemblage);
        }

        return savedAssemblage;
    }

    @GET
    @Path("/getAuthoritativeAssemblageProductsInStageByIdIn")
    public List<AuthoritativeAssemblageProduct> getAuthoritativeAssemblageProductsInStageByIdIn(@QueryParam("id") String id) {
        return service.getAuthoritativeAssemblageProductsInStageByIdIn(id);
    }

    @POST
    @Path("/getAuthoritativeAssemblageStagingSearchResults")
    public SearchResult<AuthoritativeAssemblage> getAuthoritativeAssemblageStagingSearchResults(SearchInput searchInput) {
        return service.getAuthoritativeAssemblageStagingSearchResults(searchInput);
    }

    @POST
    @Path("/sendForApproval")
    public AuthoritativeAssemblage sendForApproval(AuthoritativeAssemblageInfo authoritativeAssemblageInfo) {
        AuthoritativeAssemblage savedAssemblage = service.saveAuthoritativeAssemblageToStage(authoritativeAssemblageInfo);

        return service.sendForApproval(savedAssemblage);
    }

    @POST
    @Path("/recall")
    public AuthoritativeAssemblage recall(AuthoritativeAssemblage authoritativeAssemblage) {
        return service.recall(authoritativeAssemblage);
    }

    @POST
    @Path("/approve")
    public AuthoritativeAssemblage approve(AuthoritativeAssemblage authoritativeAssemblage) {
        return service.approve(authoritativeAssemblage);
    }

    @POST
    @Path("/reject")
    public AuthoritativeAssemblage reject(AuthoritativeAssemblage authoritativeAssemblage) {
        return service.reject(authoritativeAssemblage);
    }

    @POST
    @Path("/publish")
    public AuthoritativeAssemblage publish(AuthoritativeAssemblage authoritativeAssemblage) {
        return service.publish(authoritativeAssemblage);
    }

    @POST
    @Path("buildWorkflowStepSummary")
    public List<WorkflowStepSummary> buildWorkflowStepSummary(AuthoritativeAssemblage authoritativeAssemblage) {
        return service.buildWorkflowStepSummary(authoritativeAssemblage);
    }

    @POST
    @Path("/moveStagingAuthoritativeAssemblagesToProduction")
    public MoveStageAuthoritativeAssemblageResponse moveStagingAuthoritativeAssemblagesToProduction(List<String> idList) {
        return service.moveStagingAuthoritativeAssemblagesToProduction(idList);
    }

    @GET
    @Path("/moveApprovedStagingAuthoritativeAssemblagesToProduction")
    public MoveStageAuthoritativeAssemblageResponse moveApprovedStagingAuthoritativeAssemblagesToProduction() {
        return service.moveApprovedStagingAuthoritativeAssemblagesToProduction();
    }

    @POST
    @Path("/buildJmarFiles")
    public byte[] buildJmarFiles (List<String> idsThatWereMoved) throws IOException {
        return service.buildJmarFiles(idsThatWereMoved);
    }

    @POST
    @Path("/getAuthoritativeAssemblagesByKeyFields")
    public List<AuthoritativeAssemblage> getAuthoritativeAssemblagesByKeyFields(List<String> idList)
    {
        return service.getAuthoritativeAssemblagesByKeyFields(idList);
    }

    @GET
    @Path("/getAssemblageProductSearchItems")
    public SearchResult<NsnProductDetail> getAssemblageProductSearchItems(@QueryParam("nsn")String nsn) {
        return service.getAssemblageProductSearchItems(nsn);
    }
}