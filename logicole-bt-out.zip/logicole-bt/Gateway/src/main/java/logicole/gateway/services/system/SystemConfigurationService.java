package logicole.gateway.services.system;

import logicole.apis.system.ISystemConfigurationMicroserviceApi;
import logicole.common.datamodels.Configuration;
import logicole.common.datamodels.ConfigurationCollection;
import logicole.common.datamodels.ConfigurationGroup;
import logicole.common.general.configuration.ConfigurationManager;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.AbiConfigurationService;
import logicole.gateway.services.businessintelligence.BIService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.user.UserService;
import logicole.gateway.services.workorder.WorkOrderService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class SystemConfigurationService extends BaseGatewayService<ISystemConfigurationMicroserviceApi> {

    @Inject
    ConfigurationManager configurationManager;

    @Inject
    AbiConfigurationService abiConfigurationService;

    @Inject
    BIService biService;

    @Inject
    WorkOrderService workOrderService;

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    SystemService systemService;

    @Inject
    UserService userService;

    @Inject
    OrganizationService organizationService;

    private static final String ABI = "enterpriseCatalog";
    private static final String BUSINESS_INTELLIGENCE = "businessIntelligence";
    private static final String WORK_ORDER = "workOrder";
    private static final String FILE_MANAGER = "dmlesFilemanager";
    private static final String USER = "dmlesUser";
    private static final String SYSTEM = "dmlesSystem";
    private static final String ORGANIZATION = "dmlesOrganization";
    private static final String COLLECTION_NOT_FOUND = "Configuration collection not found";

    public SystemConfigurationService() {
        super("SystemConfiguration");
    }

    public ConfigurationCollection getAllConfigurations() {
        ConfigurationCollection configurationCollection = new ConfigurationCollection();
        configurationCollection.title = "Micro Service Configurations";
        configurationCollection.configurationGroupList = new ArrayList<>();

        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "Abi Configurations", ABI, abiConfigurationService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "Business Intelligence Configurations", BUSINESS_INTELLIGENCE, biService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "File Manager Configurations", FILE_MANAGER, fileManagerAdminService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "Organization Configurations", ORGANIZATION, organizationService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "System Configurations", SYSTEM, systemService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "User Configurations", USER, userService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "Work Order Configurations", WORK_ORDER, workOrderService.getAllConfigurations()));

        configurationCollection.fileConfigurationList = new ArrayList<>();
        configurationCollection.fileConfigurationList.addAll(configurationManager.getAll());

        return configurationCollection;
    }

    public ConfigurationCollection getMicroServiceConfigurations() {
        ConfigurationCollection configurationCollection = new ConfigurationCollection();
        configurationCollection.title = "Micro Service Configurations";
        configurationCollection.configurationGroupList = new ArrayList<>();

        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "Abi Configurations", ABI, abiConfigurationService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "Business Intelligence Configurations", BUSINESS_INTELLIGENCE, biService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "File Manager Configurations", FILE_MANAGER, fileManagerAdminService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "Organization Configurations", ORGANIZATION, organizationService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "System Configurations", SYSTEM, systemService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "User Configurations", USER, userService.getAllConfigurations()));
        configurationCollection.configurationGroupList.add(this.createConfigurationGroup(
                "Work Order Configurations", WORK_ORDER, workOrderService.getAllConfigurations()));

        return configurationCollection;
    }

    public ConfigurationCollection getServerConfigurations() {
        ConfigurationCollection configurationCollection = new ConfigurationCollection();

        configurationCollection.fileConfigurationList = new ArrayList<>();
        configurationCollection.fileConfigurationList.addAll(configurationManager.getAll());

        return configurationCollection;
    }

    private ConfigurationGroup createConfigurationGroup(String name, String owner, List<Configuration> groupConfigurations) {
        ConfigurationGroup configurationGroup = new ConfigurationGroup();
        configurationGroup.groupName = name;
        configurationGroup.owner = owner;
        if (configurationGroup.groupConfigurations == null) {
            configurationGroup.groupConfigurations = new ArrayList<>();
        }
        configurationGroup.groupConfigurations.addAll(groupConfigurations);
        return configurationGroup;
    }

    public Configuration addUpdateConfiguration(Configuration configuration) {
        Configuration savedConfiguration = null;
        switch (configuration.owner) {
            case ABI:
                savedConfiguration = abiConfigurationService.addUpdateConfiguration(configuration);
                break;
            case BUSINESS_INTELLIGENCE:
                savedConfiguration = biService.addUpdateConfiguration(configuration);
                break;
            case WORK_ORDER:
                savedConfiguration = workOrderService.addUpdateConfiguration(configuration);
                break;
            case FILE_MANAGER:
                savedConfiguration = fileManagerAdminService.addUpdateConfiguration(configuration);
                break;
            case ORGANIZATION:
                savedConfiguration = organizationService.addUpdateConfiguration(configuration);
                break;
            case USER:
                savedConfiguration = userService.addUpdateConfiguration(configuration);
                break;
            case SYSTEM:
                savedConfiguration = systemService.addUpdateConfiguration(configuration);
                break;
            default:
                this.logger.error(COLLECTION_NOT_FOUND);
                break;
        }

        return savedConfiguration;
    }

    public Configuration getConfiguration(String id, String owner) {
        Configuration savedConfiguration = null;
        switch (owner) {
            case ABI:
                savedConfiguration = abiConfigurationService.getConfiguration(id);
                break;
            case WORK_ORDER:
                savedConfiguration = workOrderService.getConfiguration(id);
                break;
            case FILE_MANAGER:
                savedConfiguration = fileManagerAdminService.getConfiguration(id);
                break;
            case USER:
                savedConfiguration = userService.getConfiguration(id);
                break;
            case SYSTEM:
                savedConfiguration = systemService.getConfiguration(id);
                break;
            default:
                this.logger.error(COLLECTION_NOT_FOUND);
                break;
        }

        return savedConfiguration;
    }

    public Configuration getConfigurationByName(String name, String owner) {
        Configuration savedConfiguration = null;
        switch (owner) {
            case ABI:
                savedConfiguration = abiConfigurationService.getConfigurationByName(name);
                break;
            case BUSINESS_INTELLIGENCE:
                savedConfiguration = biService.getConfigurationByName(name);
                break;
            case WORK_ORDER:
                savedConfiguration = workOrderService.getConfigurationByName(name);
                break;
            case FILE_MANAGER:
                savedConfiguration = fileManagerAdminService.getConfigurationByName(name);
                break;
            case USER:
                savedConfiguration = userService.getConfigurationByName(name);
                break;
            case SYSTEM:
                savedConfiguration = systemService.getConfigurationByName(name);
            default:
                this.logger.error(COLLECTION_NOT_FOUND);
                break;
        }

        return savedConfiguration;
    }

}
