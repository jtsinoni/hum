package logicole.gateway.services.abi;

import logicole.apis.abi.ISiteCatalogRequestMicroserviceApi;
import logicole.common.datamodels.abi.SiteCatalogRequest;
import logicole.common.datamodels.abi.delta.DeltaRequestStatusType;
import logicole.common.datamodels.abi.staging.AbiCatalogStaging;
import logicole.common.datamodels.product.SiteCatalogRecord;
import logicole.common.general.util.NumberUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.product.OfferService;
import logicole.gateway.services.product.ProductService;
import org.apache.commons.lang3.StringUtils;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.Objects;

@ApplicationScoped
public class SiteCatalogRequestService extends BaseGatewayService<ISiteCatalogRequestMicroserviceApi> {
    @Inject
    AbiStagingService abiStagingService;

    @Inject
    AbiToSiteRecordLinkService abiToSiteRecordLinkService;

    @Inject
    OfferService offerService;

    @Inject
    OrganizationService organizationService;

    @Inject
    ProductService productService;



    public SiteCatalogRequestService() {
        super("Abi");
    }

    // This method is invoked by the Site Catalog Request Queue Message Driven Bean
    public void processRequest(SiteCatalogRequest siteCatalogRequest) {
        String result;
        switch (siteCatalogRequest.getRequestType()) {
            case "PROCESS_SITE_COUNT":
                result = processSiteCatalogRequest(siteCatalogRequest);
                logger.info("PROCESS_SITE_COUNT result = " + result);
                break;
            case "UPDATE_LAST_SYNC_TIME":
                result = processSiteCatalogComplete(siteCatalogRequest);
                logger.info("UPDATE_LAST_SYNC_TIME result = " + result);
                break;
            default:
                break;
        }
    }

    private String processSiteCatalogRequest(SiteCatalogRequest requestRecord) {
        String requestId = requestRecord.getRequestId();
        String enterpriseItemIdentifier = requestRecord.getEnterpriseItemIdentifier();
        String tlammCatalogSeqId = requestRecord.getTlammCatalogSeqId();
        String deleteInd = requestRecord.getDeleteInd();

        try {
            // Sequence matters, see line comments
            // No need to call verifyMMCProductIdentifier
            Integer mmcProductIdentifier = verifyMmcProductIdentifier(enterpriseItemIdentifier); // Needs to be before verifyEnterpriseProductIdentifier
            String enterpriseProductIdentifier = verifyEnterpriseProductIdentifier(enterpriseItemIdentifier, mmcProductIdentifier); // Needs to be before updateSiteCount
            if (tlammCatalogSeqId != null ) {
                if (!tlammCatalogSeqId.isEmpty() && "Y".equalsIgnoreCase(deleteInd)) {
                    Integer id = NumberUtil.tryParseInteger(tlammCatalogSeqId, -1);
                    processTlamm(id, deleteInd, enterpriseProductIdentifier);
                    logger.info("processTlamm delete completed. requestId = " + requestId + ", tlammCatalogSeqId = " + tlammCatalogSeqId);
                }
            }
            if (enterpriseProductIdentifier != null) {
                Integer siteCount = updateSiteCount(enterpriseProductIdentifier);
                logger.info("processSiteCountRequest completed. requestId=" + requestId + ", enterpriseItemIdentifier=" + enterpriseItemIdentifier + ", siteCount=" + siteCount.toString());
            }
            Integer updatedCount = processEhr(enterpriseItemIdentifier, enterpriseProductIdentifier);
            logger.info("updateEhrData completed. requestId = " + requestId + ", enterpriseItemIdentifier = " + enterpriseItemIdentifier, ", updatedCount = " + updatedCount.toString());
            return DeltaRequestStatusType.POST_PROCESSING_COMPLETE;
        } catch (Exception ex) {
            logger.error("processSiteCountRequest Exception: requestId=" + requestId + ", enterpriseItemIdentifier=" + enterpriseItemIdentifier + ", message = " + ex.getMessage());
            return DeltaRequestStatusType.POST_PROCESSING_ERROR;
        }
    }

    private Integer processEhr(@NotNull String enterpriseItemIdentifier, String enterpriseProductIdentifier) {
        SiteCatalogRecord siteCatalogRecord = productService.getSiteCatalogRecord(enterpriseItemIdentifier);
        // This is required because of update and get happen in different mongo db.
        if (enterpriseProductIdentifier != null) {
            if (!StringUtils.equals(siteCatalogRecord.enterpriseProductIdentifier, enterpriseProductIdentifier)) {
                siteCatalogRecord.enterpriseProductIdentifier = enterpriseProductIdentifier;
            }
        }
        return offerService.syncOffers(siteCatalogRecord);
    }

    private void processTlamm(@NotNull Integer tlammCatalogSeqId, String deleteInd, String enterpriseProductIdentifier) {
        SiteCatalogRecord siteCatalogRecord = productService.getTewlsRecord(tlammCatalogSeqId);

        if (siteCatalogRecord != null) {
            if (enterpriseProductIdentifier != null) {
                if (!StringUtils.equals(siteCatalogRecord.enterpriseProductIdentifier, enterpriseProductIdentifier)) {
                    siteCatalogRecord.enterpriseProductIdentifier = enterpriseProductIdentifier;
                }
            }

            if (!Objects.equals(siteCatalogRecord.deleteInd, deleteInd)) {
                siteCatalogRecord.deleteInd = deleteInd;
                productService.updateSiteCatalog(siteCatalogRecord);
            }
        }
    }

    private String verifyEnterpriseProductIdentifier(@NotNull String enterpriseItemIdentifier, Integer mmcProductIdentifier) {
        String enterpriseProductIdentifier = null;
        SiteCatalogRecord siteCatalogRecord = productService.getSiteCatalogRecord(enterpriseItemIdentifier);
        if (siteCatalogRecord == null) {
            return enterpriseProductIdentifier;
        }
        String siteEnterpriseProductIdentifier = siteCatalogRecord.enterpriseProductIdentifier;
        if (mmcProductIdentifier != null) {
            AbiCatalogStaging abiMmcRecord = microservice.getByMmcProductIdentifier(mmcProductIdentifier);
            if (abiMmcRecord != null) {
                enterpriseProductIdentifier = abiMmcRecord.enterpriseProductIdentifier;
            }
        }
        if (enterpriseProductIdentifier == null && siteEnterpriseProductIdentifier == null) {
            if (siteCatalogRecord.ndc != null) {
                AbiCatalogStaging abiNdcRecord = microservice.getScriptProStagingRecord(siteCatalogRecord.ndc);
                if (abiNdcRecord != null) {
                    enterpriseProductIdentifier = abiNdcRecord.enterpriseProductIdentifier;
                }
            }
        }
        if (enterpriseProductIdentifier != null) {
            if (!StringUtils.equals(siteEnterpriseProductIdentifier, enterpriseProductIdentifier))
                productService.updateEnterpriseProductIdentifier(enterpriseItemIdentifier, enterpriseProductIdentifier);
        }


        if (enterpriseProductIdentifier == null) {
            enterpriseProductIdentifier = siteEnterpriseProductIdentifier;
        }
        return enterpriseProductIdentifier;
    }

    private Integer verifyMmcProductIdentifier(@NotNull String enterpriseItemIdentifier) {
        Integer mmcProductIdentifier = null;
        SiteCatalogRecord siteCatalogRecord = productService.getSiteCatalogRecord(enterpriseItemIdentifier);
        if (siteCatalogRecord == null) {
            return mmcProductIdentifier;
        }
        Integer siteMmcProductIdentifier = siteCatalogRecord.productSeqId;
        if (siteMmcProductIdentifier != null) {
            // See if it has been mapped to another value. Returns given value if mapping not found.
            mmcProductIdentifier = microservice.getNewMmcProductIdentifier(siteMmcProductIdentifier);
        }

        return mmcProductIdentifier;
    }

    public Integer updateSiteCount(@NotNull String enterpriseProductIdentifier) {

        Integer newSiteCount;
        String inUseIndicator = "N";
        if (enterpriseProductIdentifier != null) {
            newSiteCount = productService.getSiteCount(enterpriseProductIdentifier);
        } else {
            return 0; // item not linked to ABi so nothing to update
        }
        AbiCatalogStaging stagingRecord = microservice.getByEnterpriseProductIdentifier(enterpriseProductIdentifier);
        if (stagingRecord == null) return 0; // Invalid enterpriseProductIdentifier
        Integer siteCount = stagingRecord.siteCount;
        if (!Objects.equals(newSiteCount, siteCount)) {
            stagingRecord.siteCount = newSiteCount;
            if (newSiteCount > 0) inUseIndicator = "Y";
            stagingRecord.inUseIndicator = inUseIndicator;
            abiStagingService.updateRecord(stagingRecord);
            abiToSiteRecordLinkService.updateSiteCountForEnterpriseProductIdentifier(enterpriseProductIdentifier, newSiteCount);
        }
        return newSiteCount;
    }

    private String processSiteCatalogComplete(SiteCatalogRequest requestRecord) {
        String dodaac = requestRecord.getDodaac();
        Date siteCatalogLastSyncTime = requestRecord.getSiteCatalogLastSyncTime();
        try {
            organizationService.updateDmlssHostLastSyncTime(dodaac, siteCatalogLastSyncTime);
            logger.info("processSiteCatalogComplete completed. dodaac=" + dodaac + ", siteCatalogLastSyncTime=" + siteCatalogLastSyncTime);
            return DeltaRequestStatusType.POST_PROCESSING_COMPLETE;
        } catch (Exception ex) {
            logger.error("processSiteCatalogComplete Exception: dodaac=" + dodaac + ", siteCatalogLastSyncTime=" + siteCatalogLastSyncTime + ", message = " + ex.getMessage());
            return DeltaRequestStatusType.POST_PROCESSING_ERROR;
        }
    }

}
