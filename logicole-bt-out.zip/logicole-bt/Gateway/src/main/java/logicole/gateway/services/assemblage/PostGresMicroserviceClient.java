package logicole.gateway.services.assemblage;

import logicole.apis.assemblage.IPostGresMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class PostGresMicroserviceClient extends MicroserviceClient<IPostGresMicroserviceApi> {

    public PostGresMicroserviceClient(){
        super(IPostGresMicroserviceApi.class, "logicole-assemblage");
    }

    @Produces
    public IPostGresMicroserviceApi getIPostGresMicroserviceApi() {
        return createClient();
    }
}
