package logicole.gateway.services.sap;

import logicole.common.datamodels.communications.EdiConstants;
import logicole.common.datamodels.communications.httpincomingwrapper.HttpIncomingWrapper;
import logicole.common.datamodels.communications.ordering.OrderObject;
import logicole.common.datamodels.communications.response.LogicoleQuickResponse;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.remote.IDefaultRemoteApi;
import logicole.gateway.services.communications.CommunicationsSubmitRequestService;
import logicole.gateway.services.communications.CommunicationsTranslationService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.IOException;

@ApplicationScoped
public class SapExternalService extends BaseGatewayService<IDefaultRemoteApi> {
    @Inject
    CommunicationsSubmitRequestService communicationsSubmitRequestService;
    @Inject
    private CommunicationsTranslationService communicationsTranslationService;
    @Inject
    private JSONUtil jsonUtil;

    public SapExternalService() { super("Sap"); }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public LogicoleQuickResponse translateSapOrderObject(OrderObject orderObject) {
        HttpIncomingWrapper sapWrapper = new HttpIncomingWrapper();

        try {
            sapWrapper.payload = jsonUtil.serialize(orderObject);
        } catch (IOException e) {
            LogicoleQuickResponse quickResponse = new LogicoleQuickResponse();
            quickResponse.controlNumber = Integer.toString(orderObject.controlNumber);
            quickResponse.statusDetails = String.format("Unable to serialize provide Order Object - %s", e.getMessage());
            quickResponse.translationResult = "Unable to attempt translation because the provided Order Object is invalid.";
            return quickResponse;
        }

        return communicationsTranslationService.translateSapOrderObject(sapWrapper);
    }

    public LogicoleQuickResponse acceptDataFromSap(HttpIncomingWrapper sapData) {
        sapData.forSap = true;
        LogicoleQuickResponse quickResponse = new LogicoleQuickResponse();
        final String interfaceSystem = StringUtil.safeToUppercase(sapData.interfaceSystem.toString());
        final String rejectMessage = "This interface system (%s - %s) is not supported yet. The data was rejected by LogiCole.";

        switch (interfaceSystem) {
            case "EDI":
                if (sapData.interfaceTransaction.startsWith(EdiConstants.DOCUMENT_TYPE_511)
                        || sapData.interfaceTransaction.startsWith(EdiConstants.DOCUMENT_TYPE_850)
                        || sapData.interfaceTransaction.startsWith(EdiConstants.DOCUMENT_TYPE_860)
                        || sapData.interfaceTransaction.startsWith(EdiConstants.DOCUMENT_TYPE_869)) {
                    quickResponse = communicationsTranslationService.translateSapOrderObject(sapData);
                } else {
                    quickResponse.statusDetails = String.format(rejectMessage, interfaceSystem, sapData.interfaceTransaction);
                    quickResponse.controlNumber = sapData.trackingId;
                }
                break;
            case "ECAT":
                quickResponse = communicationsTranslationService.translateSapOrderObject(sapData);
                quickResponse.controlNumber = sapData.trackingId;
                break;
            case "GFEBS":
                quickResponse.statusDetails = communicationsSubmitRequestService.submitExternalGfebsForAcceptance(sapData);
                quickResponse.controlNumber = sapData.trackingId;

                // TODO: somewhere after validating the GFEBS XML we need to queue the XML to be transmitted to DAAS
                //       Kafka is not in play yet.
                break;
            default:
                quickResponse.statusDetails = String.format(rejectMessage, interfaceSystem, sapData.interfaceTransaction);
                quickResponse.controlNumber = sapData.trackingId;
        }

        return quickResponse;
    }
}
