package logicole.gateway.services.system;

import logicole.apis.system.ISystemMicroserviceApi;
import logicole.common.datamodels.Configuration;
import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.HealthCheckResult.EHealthStatus;
import logicole.common.datamodels.VersionInformation;
import logicole.common.datamodels.equipment.request.EquipmentRequest;
import logicole.common.datamodels.equipment.request.SiteNerCustomer;
import logicole.common.datamodels.equipment.workflow.process.WorkflowProcessing;
import logicole.common.datamodels.notification.EmailMessage;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.system.*;
import logicole.common.datamodels.system.frequency.Frequency;
import logicole.common.datamodels.system.frequency.FrequencyRef;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.AbiCatalogService;
import logicole.gateway.services.assemblage.AssemblageService;
import logicole.gateway.services.asset.AssetService;
import logicole.gateway.services.businessintelligence.BIService;
import logicole.gateway.services.catalog.CatalogLookupService;
import logicole.gateway.services.catalog.CatalogService;
import logicole.gateway.services.catalog.EnterpriseSourcingService;
import logicole.gateway.services.communications.CommunicationsAdminService;
import logicole.gateway.services.communications.DmlssCommunicationsService;
import logicole.gateway.services.communications.SsoSapTewlsService;
import logicole.gateway.services.dmlss.DmlssService;
import logicole.gateway.services.equipment.EquipmentRecordService;
import logicole.gateway.services.equipment.EquipmentRequestService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.finance.FinanceAdminService;
import logicole.gateway.services.help.HelpService;
import logicole.gateway.services.inventory.InventoryService;
import logicole.gateway.services.order.OrderService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.product.ProductService;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.realpropertyproject.ProjectService;
import logicole.gateway.services.realpropertyproject.RequirementService;
import logicole.gateway.services.realpropertysection.SectionService;
import logicole.gateway.services.receipt.ReceiptService;
import logicole.gateway.services.report.ReportService;
import logicole.gateway.services.search.SearchService;
import logicole.gateway.services.slep.SlepService;
import logicole.gateway.services.spacemanagement.SpaceManagementService;
import logicole.gateway.services.system.recurringfunctions.RecurringFunctionService;
import logicole.gateway.services.user.UserService;
import logicole.gateway.services.workorder.WorkOrderService;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.mail.MessagingException;

import com.fasterxml.jackson.annotation.JsonValue;

import java.io.IOException;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@ApplicationScoped
public class SystemService extends BaseGatewayService<ISystemMicroserviceApi> {

    private static final String NOT_FOUND = "Not Found";
    private static final String FAILED = "Failed";
    private final Map<EServiceName, BaseGatewayService> businessEventServiceMap = new HashMap<>(25);
    @Inject
    AbiCatalogService abiCatalogService;
    @Inject
    AssemblageService assemblageService;
    @Inject
    AssetService assetService;
    @Inject
    BIService biService;
    @Inject
    CommunicationsAdminService communicationsAdminService;
    @Inject
    CatalogService catalogService;
    @Inject
    DmlssCommunicationsService dmlssCommunicationsService;
    @Inject
    DmlssService dmlssService;
    @Inject
    EquipmentRecordService equipmentRecordService;
    @Inject
    EquipmentRequestService equipmentRequestService;
    @Inject
    FacilityService facilityService;
    @Inject
    FileManagerAdminService fileManagerAdminService;
    @Inject
    FinanceAdminService financeAdminService;
    @Inject
    HelpService helpService;
    @Inject
    InventoryService inventoryService;
    @Inject
    EnterpriseSourcingService itemSourcingService;
    @Inject
    NotificationService notificationService;
    @Inject
    OrderService orderService;
    @Inject
    OrganizationService organizationService;
    @Inject
    ProductService productService;
    @Inject
    ReceiptService receiptService;
    @Inject
    ReportService reportService;
    @Inject
    RequirementService requirementService;
    @Inject
    ProjectService projectService;
    @Inject
    SearchService searchService;
    @Inject
    SectionService sectionService;
    @Inject
    SlepService slepService;
    @Inject
    SpaceManagementService spaceManagementService;
    @Inject
    UserService userService;
    @Inject
    WorkOrderService workOrderService;
    @Inject
    CatalogLookupService catalogLookupService;
    @Inject
    RecurringFunctionService recurringFunctionService;
    @Inject
    SsoSapTewlsService ssoSapTewlsService;
    private Integer maxUploadSize;

    private List<BaseGatewayService> primaryServices = new ArrayList<>();

    public SystemService() {
        super("System");
    }

    @PostConstruct
    private void postConstruct() {
        primaryServices.add(abiCatalogService);
        primaryServices.add(assemblageService);
        primaryServices.add(assetService);
        primaryServices.add(biService);
        primaryServices.add(communicationsAdminService);
        primaryServices.add(dmlssService);
        primaryServices.add(equipmentRequestService);
        primaryServices.add(fileManagerAdminService);
        primaryServices.add(financeAdminService);
        primaryServices.add(helpService);
        primaryServices.add(organizationService);
        primaryServices.add(productService);
        primaryServices.add(facilityService);
        primaryServices.add(requirementService);
        primaryServices.add(projectService);
        primaryServices.add(sectionService);
        primaryServices.add(receiptService);
        primaryServices.add(reportService);
        primaryServices.add(searchService);
        primaryServices.add(slepService);
        primaryServices.add(spaceManagementService);
        primaryServices.add(this);
        primaryServices.add(userService);
        primaryServices.add(workOrderService);
        primaryServices.add(catalogService);
        primaryServices.add(ssoSapTewlsService);
        primaryServices.add(inventoryService);
        buildServiceMap();
    }

    @Override
    protected void onInitialized() {
        super.onInitialized();
        initializeSystem();
    }

    void buildServiceMap() {
        businessEventServiceMap.put(EServiceName.FINANCE, financeAdminService);
        businessEventServiceMap.put(EServiceName.ORDER, orderService);
        businessEventServiceMap.put(EServiceName.RECEIVING, receiptService);
        businessEventServiceMap.put(EServiceName.WORKORDER, workOrderService);
        businessEventServiceMap.put(EServiceName.REALPROPERTY_PROJECT, projectService);
        businessEventServiceMap.put(EServiceName.REALPROPERTY_REQUIREMENT, requirementService);
    }

    public HealthCheckResult getHealthCheck() {
        EHealthStatus overallStatus = EHealthStatus.Good;

        HealthCheckResult result = new HealthCheckResult("LogiCole", "Application", EHealthStatus.Good, EHealthStatus.Good);
        for (BaseGatewayService gatewayService : primaryServices) {

            HealthCheckResult gatewayHealthCheck = gatewayService.checkHealth();
            if (gatewayHealthCheck.overallResult == EHealthStatus.Failed) {
                overallStatus = EHealthStatus.Failed;
            }
            result.nestedHealthChecks.add(gatewayHealthCheck);
        }

        if (overallStatus == EHealthStatus.Failed) {
            result.overallResult = EHealthStatus.Failed;
        }

        return result;
    }

    public NewIdValue getNextUniqueId(EUniqueIdType uniqueIdType) {
        return microservice.getNextUniqueId(uniqueIdType);
    }

    public List<VersionInformation> getAllSystemVersionInformation() throws IOException {
        List<VersionInformation> versionInformationList = new ArrayList<>();

        for (BaseGatewayService service : primaryServices) {
            VersionInformation versionInformation = service.getMicroserviceVersionInformation();

            if (versionInformation == null) {

                versionInformation = new VersionInformation();
                versionInformation.name = service.getName();
                versionInformation.logicoleVersion = NOT_FOUND;
                versionInformation.buildDate = NOT_FOUND;

                versionInformationList.add(versionInformation);
            } else {

                if (StringUtil.isEmptyOrNull(versionInformation.buildDate)) {
                    versionInformation.buildDate = NOT_FOUND;
                }

                if (StringUtil.isEmptyOrNull(versionInformation.logicoleVersion)) {
                    versionInformation.logicoleVersion = NOT_FOUND;
                }

                versionInformationList.add(versionInformation);
            }
        }

        return versionInformationList;
    }

    public VersionInformation getDatabaseVersionInformation() {
        return microservice.getDatabaseVersionInformation();
    }

    public Boolean updateEnumCollections() {
//        spaceService.syncEnumData();
        microservice.updateEnumCollections();
        return true;
    }

    public EmailResponse getResponseByEmailId(String emailId) {
        String response;
        EmailResponse emailResponse = new EmailResponse();
        EmailMessage emailMessage = new EmailMessage();
        try {
            emailMessage = microservice.getTestEmailMessage(emailId);

            notificationService.sendEmailWithResponse(emailMessage);
            response = "Email Sent Successfully";
        } catch (Exception e) {
            response = e.getMessage();
        }

        emailResponse.emailMessage = emailMessage;
        emailResponse.response = response;

        return emailResponse;
    }

    public List<InitializationRoutineRun> initializeSystem() {
        return executeNewInitializationRoutines();
    }

    public List<InitializationRoutineRun> executeNewInitializationRoutines() {
        List<InitializationRoutineRun> results = new ArrayList<>();

        final Map<String, InitializationRoutine> existingInitializationRoutines = microservice.getInitializationRoutines();
        final List<InitializationRoutine> newInitializationRoutines = getNewInitializationRoutines();

        List<InitializationRoutine> finalInitializationRoutines = new ArrayList<>();

        newInitializationRoutines.forEach(newInitialzationRoutine -> {
            InitializationRoutineRef newInitializationRoutineRef = newInitialzationRoutine.getRef();
            InitializationRoutineRun run = new InitializationRoutineRun(newInitializationRoutineRef);
            InitializationRoutine existingInitializationRoutine = existingInitializationRoutines.get(newInitializationRoutineRef.identifier);
            InitializationRoutine finalInitializationRoutine = newInitialzationRoutine;

            if (existingInitializationRoutine != null) {
                finalInitializationRoutine = existingInitializationRoutine;
                if (existingInitializationRoutine.currentStatus == InitializationRoutineResult.EStatus.Completed) {
                    run.run.result.status = InitializationRoutineResult.EStatus.PreviouslyRun;

                } else {
                    run.run.result = executeSystemInitializationRoutine(newInitialzationRoutine);
                }
            } else {
                run.run.result = executeSystemInitializationRoutine(newInitialzationRoutine);
            }

            run.run.endDate = new Date();

            if (InitializationRoutineResult.EStatus.PreviouslyRun != run.run.result.status) {
                finalInitializationRoutine.runHistory.add(run.run);
                finalInitializationRoutine.currentStatus = run.run.result.status;

                finalInitializationRoutines.add(finalInitializationRoutine);
            }

            results.add(run);
        });

        microservice.recordInitializationResults(finalInitializationRoutines);
        return results;
    }

    private InitializationRoutineResult executeSystemInitializationRoutine(InitializationRoutine initializationRoutine) {
        InitializationRoutineResult result = new InitializationRoutineResult();
        try {
            result = initializationRoutine.function.apply(initializationRoutine.getRef());
        } catch (Exception e) {
            result.exception = e.toString();
            result.status = InitializationRoutineResult.EStatus.Failed;
        }

        return result;
    }

    public List<InitializationRoutine> getNewInitializationRoutines() {
        List<InitializationRoutine> newInitializationRoutines = new ArrayList<InitializationRoutine>();
        // The below commented line is for example
        //newInitializationRoutines.add(new InitializationRoutine("5fc851c9-5816-44f4-bb37-c6e728bfba81", "Test A", "This is test A", organizationService::executeInitializationRoutine));

        newInitializationRoutines.add(new InitializationRoutine("e558cdd2-0a85-483c-aad1-19d15f59c210", "addCategoryCodeRef to Facility records", "Adds a field of type CategoryCodeRef to the existing Facility records",
                facilityService::createCategoryCodeRefObjects));

        newInitializationRoutines.add(new InitializationRoutine("075d71e5-e292-4835-b90f-165bcf42d128"
                , "create DmlssFunctions"
                , "Creates database entries for dmlssFunctions and adds DmlssFunctions to DmlssServers"
                , dmlssService::createDmlssFunctions));

        newInitializationRoutines.add(new InitializationRoutine("fe60fd96-7b78-460f-8734-1da1dc10afcb"
                , "add businessIntelligenceId to AppUserProfile records"
                , "Adds the businessIntelligenceId field to the existing AppUserProfile records"
                , userService::createBusinessIntelligenceIds));

        return newInitializationRoutines;
    }

    public EquipmentRequest sendEquipmentRequestToDMLSSById(String objId) {
        return equipmentRequestService.sendEquipmentRequestToDMLSSById(objId);
    }

    public EquipmentRequest sendEquipmentRequestToDMLSSByReqNum(String reqNum) {
        return equipmentRequestService.sendEquipmentRequestToDMLSSByReqNum(reqNum);
    }

    public EquipmentRequest getEquipmentRequestByReqNum(String reqNum) {
        return equipmentRequestService.getEquipmentRequestByReqNum(reqNum);
    }

    public EquipmentRequest getEquipmentRequestById(String objId) {
        return equipmentRequestService.getEquipmentRequestById(objId);
    }

    public Long getSiteEquipmentRecordByMeId(String siteDoDAAC, String meId) {
        return equipmentRecordService.getSiteEquipmentRecordByMeId(siteDoDAAC, meId);
    }

    public Long getSiteEquipmentRecordByItemId(String siteDoDAAC, String itemId) {
        return equipmentRecordService.getSiteEquipmentRecordByItemId(siteDoDAAC, itemId);
    }

    public Long getSiteEquipmentRecordAfterDate(String siteDoDAAC, Date modifiedDate) {
        return equipmentRecordService.getSiteEquipmentRecordAfterDate(siteDoDAAC, modifiedDate);
    }   

    public Boolean reloadWorkflowStateRules() {
        return equipmentRequestService.reloadWorkflowStateRules();
    }

    public WorkflowProcessing getWorkflowProcessById(String id) {
        return equipmentRequestService.getWorkflowProcessById(id);
    }

    public List<String> syncEquipmentRecordCounts() {
        return equipmentRecordService.syncEquipmentRecordCounts();
    }

    public Integer getMaxUploadSize() {
        if (null == maxUploadSize) {
            maxUploadSize = fileManagerAdminService.getMaxPostSize();
        }
        return maxUploadSize;
    }

    public String processUploadedEquipmentRecordFile(byte[] fileContent, String uploadedFileName) {
        return equipmentRecordService.processUploadedEquipmentRecordFile(fileContent, uploadedFileName);
    }

    List<Configuration> getAllConfigurations() {
        return microservice.getAllConfigurations();
    }

    public Configuration addUpdateConfiguration(Configuration configuration) {
        return microservice.addUpdateConfiguration(configuration);
    }

    public Configuration getConfiguration(String id) {
        return microservice.getConfiguration(id);
    }

    public Configuration getConfigurationByName(String name) {
        return microservice.getConfigurationByName(name);
    }

    public List<EquipmentRequest> getDmlssSiteNerCustomer(String siteDodaac) throws MessagingException, ValidationException {
        List<SiteNerCustomer> siteNerCustomerList = dmlssCommunicationsService.getDmlssSiteNerCustomer(siteDodaac);
        return equipmentRequestService.updateSiteNerCustomer(siteNerCustomerList);
    }

    public Frequency addFrequency(Frequency frequency) {
        Frequency foundFrequency = microservice.getFrequencyByName(frequency.name);
        if (foundFrequency == null) {
            frequency.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.addFrequency(frequency);
        } else {
            throw new ApplicationException("Frequency already exists");
        }
    }

    public Frequency updateFrequency(Frequency frequency) {
        Frequency foundFrequency = microservice.getFrequencyById(frequency.getId());
        if (foundFrequency == null) {
            throw new ApplicationException("Frequency does not exist");
        } else {
            if (!foundFrequency.name.equalsIgnoreCase(frequency.name) && microservice.getFrequencyByName(frequency.name) != null) {
                throw new ApplicationException("Frequency already exists");
            } else {
                return microservice.updateFrequency(frequency);
            }
        }
    }

    public void deleteFrequency(Frequency frequency) {
        microservice.deleteFrequency(frequency);
    }

    public void deleteFrequencyById(String frequencyId) {
        microservice.deleteFrequencyById(frequencyId);
    }

    public void loadFrequency(Frequency frequency) {
        microservice.loadFrequency(frequency);
    }

    public List<FrequencyRef> getAllFrequencyRefs() {
        return microservice.getAllFrequencyRefs();
    }

    public Frequency getFrequencyByName(String frequency) {
        return microservice.getFrequencyByName(frequency);
    }

    public List<AuthoritativeSource> getAllAuthoritativeSources() {
        return microservice.getAllAuthoritativeSources();
    }

    public List<AuthoritativeSourceRef> getAllAuthoritativeSourceRefs() {
        return microservice.getAllAuthoritativeSourceRefs();
    }

    public AuthoritativeSource getAuthoritativeSourceById(String id) {
        return microservice.getAuthoritativeSourceById(id);
    }

    public AuthoritativeSourceRef getAuthoritativeSourceRefById(String id) {
        return microservice.getAuthoritativeSourceRefById(id);
    }

    public AuthoritativeSource getAuthoritativeSourceByCode(String code) {
        return microservice.getAuthoritativeSourceByCode(code);
    }

    public AuthoritativeSourceRef getAuthoritativeSourceRefByCode(String code) {
        return microservice.getAuthoritativeSourceRefByCode(code);
    }

    public AuthoritativeSource updateAuthoritativeSourceName(String id, String name) {
        return microservice.updateAuthoritativeSourceName(id, name);
    }

    public void loadAuthoritativeSource(AuthoritativeSource authoritativeSource) {
        microservice.loadAuthoritativeSource(authoritativeSource);
    }

    public AuthoritativeSource addDataCategoryToAuthoritativeSource(String id, String dataCategory) {
        return microservice.addDataCategoryToAuthoritativeSource(id, dataCategory);
    }

    public AuthoritativeSource removeDataCategoryFromAuthoritativeSource(String id, String dataCategory) {
        return microservice.removeDataCategoryFromAuthoritativeSource(id, dataCategory);
    }

    public AuthoritativeSource updateAuthoritativeSourceScopeNodeRefs(String id, List<OrganizationRef> scopeNodeRefs) {
        return microservice.updateAuthoritativeSourceScopeNodeRefs(id, scopeNodeRefs);
    }

    public void deleteAuthoritativeSource(String id) {
        microservice.deleteAuthoritativeSource(id);
    }

    public BaseGatewayService getBusinessEventService(EServiceName serviceName) {
        return businessEventServiceMap.get(serviceName);
    }

    public List<String> getBusinessEventHistoryServices() {
        List<String> list = new ArrayList<>();
        for (EServiceName serviceName : EServiceName.values()) {
            list.add(serviceName.displayText);
        }
        Collections.sort(list);
        return list;
    }

    public enum EServiceName {
        FINANCE("Finance"),
        ORDER("Order"),
        RECEIVING("Receiving"),
    	WORKORDER("Work Order"),
    	REALPROPERTY_PROJECT("Real Property Project"),
    	REALPROPERTY_REQUIREMENT("Real Property Requirement");

        public final String displayText;

        public static final Map<String, EServiceName> MAP = Stream.of(EServiceName.values()).collect(Collectors.toMap(EServiceName::getDisplayText, Function.identity()));

        EServiceName(String displayText) {
            this.displayText = displayText;
        }
        
    	@JsonValue
        public String getDisplayText() {
        	return displayText;
        }
    }

}
