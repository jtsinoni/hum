package logicole.gateway.services.spacemanagement;

import io.swagger.annotations.Api;
import logicole.common.datamodels.space.lookupdata.DepartmentFill;
import logicole.common.datamodels.space.lookupdata.FloorPlanLayer;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"DrawingManagement"})
@ApplicationScoped
@Path("/drawinglookup")
public class DrawingLookupRestApi extends ExternalRestApi<DrawingLookupService> {

    // DepartmentFill methods
    @GET
    @Path("/getDepartmentFills")
    public List<DepartmentFill> getDepartmentFills() {
        return service.getDepartmentFills();
    }

    @POST
    @Path("/updateDepartmentFill")
    public DepartmentFill updateDepartmentFill(DepartmentFill departmentFill) {
        return service.updateDepartmentFill(departmentFill);
    }

    // FloorPlanLayer methods
    @GET
    @Path("/getFloorPlanLayers")
    public List<FloorPlanLayer> getFloorPlanLayers() {
        return service.getFloorPlanLayers();
    }

    @GET
    @Path("/getFloorPlanLayerById")
    public FloorPlanLayer getFloorPlanLayerById(@QueryParam("floorPlanLayerId") String floorPlanLayerId) {
        return service.getFloorPlanLayerById(floorPlanLayerId);
    }

    @POST
    @Path("/createFloorPlanLayer")
    public FloorPlanLayer createFloorPlanLayer(FloorPlanLayer floorPlanLayer) {
        return service.createFloorPlanLayer(floorPlanLayer);
    }

    @POST
    @Path("/updateFloorPlanLayer")
    public FloorPlanLayer updateFloorPlanLayer(FloorPlanLayer floorPlanLayer) {
        return service.updateFloorPlanLayer(floorPlanLayer);
    }

    @GET
    @Path("/deleteFloorPlanLayer")
    public boolean deleteFloorPlanLayer(@QueryParam("floorPlanLayerId") String floorPlanLayerId) {
        return service.deleteFloorPlanLayer(floorPlanLayerId);
    }
}
