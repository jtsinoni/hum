package logicole.gateway.services.asset;

import io.swagger.annotations.Api;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.asset.classification.Accountability;
import logicole.common.datamodels.asset.classification.AssemblyCategory;
import logicole.common.datamodels.asset.classification.ClassificationRequestDashboardInfo;
import logicole.common.datamodels.asset.classification.Consultant;
import logicole.common.datamodels.asset.classification.FacilitySubsystem;
import logicole.common.datamodels.asset.classification.FacilitySystem;
import logicole.common.datamodels.asset.classification.FederalSupplyClassRef;
import logicole.common.datamodels.asset.classification.Manufacturer;
import logicole.common.datamodels.asset.classification.ManufacturerContact;
import logicole.common.datamodels.asset.classification.ManufacturerRef;
import logicole.common.datamodels.asset.classification.ManufacturerRequest;
import logicole.common.datamodels.asset.classification.Modality;
import logicole.common.datamodels.asset.classification.ModalityRef;
import logicole.common.datamodels.asset.classification.ModalityDTO;
import logicole.common.datamodels.asset.classification.Nomenclature;
import logicole.common.datamodels.asset.classification.NomenclatureClassNameRef;
import logicole.common.datamodels.asset.classification.NomenclatureRef;
import logicole.common.datamodels.asset.classification.NomenclatureRequest;
import logicole.common.datamodels.asset.classification.RiskLevel;
import logicole.common.datamodels.asset.classification.Specialty;
import logicole.common.datamodels.asset.classification.Vendor;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.user.UserProfile;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"AssetClassification"})
@ApplicationScoped
@Path("/assetClassification")
public class AssetClassificationRestApi extends ExternalRestApi<AssetClassificationService> {

    @GET
    @Path("/getFacilitySystemById")
    public FacilitySystem getFacilitySystemById(@QueryParam("id") String id) {
        return service.getFacilitySystemById(id);
    }

    @GET
    @Path("/getAllActiveFacilitySystems")
    public List<FacilitySystem> getAllActiveFacilitySystems() {
        return service.getAllActiveFacilitySystems();
    }

    @GET
    @Path("/getFacilitySubsystemById")
    public FacilitySubsystem getFacilitySubsystemById(@QueryParam("id") String id) {
        return service.getFacilitySubsystemById(id);
    }

    @GET
    @Path("/getFacilitySubsystemForFacilitySystem")
    public List<FacilitySubsystem> getFacilitySubsystemForFacilitySystem(@QueryParam("facilitySystemCode") String facilitySystemCode) {
        return service.getFacilitySubsystemForFacilitySystem(facilitySystemCode);
    }

    @GET
    @Path("/getAssemblyCategoriesForFacilitySubsystem")
    public List<AssemblyCategory> getAssemblyCategoriesForFacilitySubsystem(@QueryParam("facilitySubsystemCode") String facilitySubsystemCode) {
        return service.getAssemblyCategoriesForFacilitySubsystem(facilitySubsystemCode);
    }

    @POST
    @Path("/getConsultantSearchResults")
    public SearchResult<Consultant> getConsultantSearchResults(SearchInput searchInput) {
        return service.getConsultantSearchResults(searchInput);
    }

    @GET
    @Path("/getItemsByDeviceCode")
    public List<Item> getItemsByDeviceCode(@QueryParam("deviceCode") String deviceCode) {
        return service.getItemsByDeviceCode(deviceCode);
    }

    @GET
    @Path("/getRealPropertyEquipmentNomenclatures")
    public List<Nomenclature> getRealPropertyEquipmentNomenclatures() {
        return service.getRealPropertyEquipmentNomenclatures();
    }

    @GET
    @Path("/getMedicalEquipmentNomenclatures")
    public List<Nomenclature> getMedicalEquipmentNomenclatures() {
        return service.getMedicalEquipmentNomenclatures();
    }

    @POST
    @Path("/getModalitySearchResults")
    public SearchResult<Modality> getModalitySearchResults(SearchInput searchInput) {
        return service.getModalitySearchResults(searchInput);
    }

    @GET
    @Path("/getModalityRefByNomenclatureId")
    public ModalityRef getModalityRefByNomenclatureId(@QueryParam("nomenclatureId") String nomenclatureId) {
        return service.getModalityRefByNomenclatureId(nomenclatureId);
    }

    @GET
    @Path("/getModalityRefsByAgency")
    public List<ModalityRef> getModalityRefsByAgency() {
        return service.getModalityRefsByAgency();
    }

    @GET
    @Path("/getNomenclaturesForAssemblyCategory")
    public List<Nomenclature> getNomenclaturesForAssemblyCategory(@QueryParam("assemblyCategoryId") String assemblyCategoryId) {
        return service.getNomenclaturesForAssemblyCategory(assemblyCategoryId);
    }

    @GET
    @Path("/getNomenclaturesByCode")
    public List<Nomenclature> getNomenclaturesByCode(@QueryParam("code") String code) {
        return service.getNomenclaturesByCode(code);
    }

    @GET
    @Path("/getNomenclatureById")
    public Nomenclature getNomenclatureById(@QueryParam("id") String id) {
        return service.getNomenclatureById(id);
    }

    @POST
    @Path("/updateNomenclature")
    public Nomenclature updateNomenclature(Nomenclature nomenclature) {
        return service.updateNomenclature(nomenclature);
    }

    @POST
    @Path("/getNomenclatureSearchResults")
    public SearchResult<Nomenclature> getNomenclatureSearchResults(SearchInput searchInput) {
        return service.getNomenclatureSearchResults(searchInput);
    }

    @GET
    @Path("/getNomenclatureRequestById")
    public NomenclatureRequest getNomenclatureRequestById(@QueryParam("id") String id) {
        return service.getNomenclatureRequestById(id);
    }

    @POST
    @Path("/removeManufacturerRequestNote")
    public ManufacturerRequest removeManufacturerRequestNote(@QueryParam("id") String id, Note note) {
        return service.removeManufacturerRequestNote(id, note);
    }

    @POST
    @Path("/removeNomenclatureRequestNote")
    public NomenclatureRequest removeNomenclatureRequestNote(@QueryParam("id") String id, Note note) {
        return service.removeNomenclatureRequestNote(id, note);
    }

    @POST
    @Path("/saveManufacturerRequestNote")
    public ManufacturerRequest saveManufacturerRequestNote(@QueryParam("id") String id, Note note) {
        return service.saveManufacturerRequestNote(id, note);
    }

    @POST
    @Path("/saveNomenclatureRequestNote")
    public NomenclatureRequest saveNomenclatureRequestNote(@QueryParam("id") String id, Note note) {
        return service.saveNomenclatureRequestNote(id, note);
    }

    @GET
    @Path("/getAllHistoricalManufacturerRequests")
    public List<ManufacturerRequest> getAllHistoricalManufacturerRequests(@QueryParam("activeFilter") String activeFilter) {
        return service.getAllHistoricalManufacturerRequests(activeFilter);
    }

    @GET
    @Path("/getAllHistoricalNomenclatureRequests")
    public List<NomenclatureRequest> getAllHistoricalNomenclatureRequests(@QueryParam("activeFilter") String activeFilter) {
        return service.getAllHistoricalNomenclatureRequests(activeFilter);
    }

    @GET
    @Path("/getAllOutstandingManufacturerRequests")
    public List<ManufacturerRequest> getAllOutstandingManufacturerRequests(@QueryParam("activeFilter") String activeFilter, @QueryParam("type") String type) {
        return service.getAllOutstandingManufacturerRequests(activeFilter, type);
    }

    @GET
    @Path("/getAllOutstandingNomenclatureRequests")
    public List<NomenclatureRequest> getAllOutstandingNomenclatureRequests(@QueryParam("activeFilter") String activeFilter, @QueryParam("type") String type) {
        return service.getAllOutstandingNomenclatureRequests(activeFilter, type);
    }

    @POST
    @Path("/updateNomenclatureRequest")
    public NomenclatureRequest updateNomenclatureRequest(NomenclatureRequest nomenclatureRequest) {
        return service.updateNomenclatureRequest(nomenclatureRequest);
    }

    @GET
    @Path("/acceptNomenclatureRequest")
    public Nomenclature acceptNomenclatureRequest(@QueryParam("id") String id) {
        return service.acceptNomenclatureRequest(id);
    }

    @POST
    @Path("/loadNomenclature")
    public void loadNomenclature(Nomenclature nomenclature) {
        service.loadNomenclature(nomenclature);
    }

    @GET
    @Path("/cancelManufacturerRequest")
    public ManufacturerRequest cancelManufacturerRequest(@QueryParam("id") String id, @QueryParam("reason") String reason) {
        return service.cancelManufacturerRequest(id, reason);
    }

    @GET
    @Path("/cancelNomenclatureRequest")
    public NomenclatureRequest cancelNomenclatureRequest(@QueryParam("id") String id, @QueryParam("reason") String reason) {
        return service.cancelNomenclatureRequest(id, reason);
    }

    @GET
    @Path("/deleteNomenclature")
    public void deleteNomenclature(@NotNull @QueryParam("nomenclatureId") String nomenclatureId) {
        service.deleteNomenclature(nomenclatureId);
    }

    @GET
    @Path("/rejectManufacturerRequest")
    public ManufacturerRequest rejectManufacturerRequest(@QueryParam("id") String id, @QueryParam("reason") String reason) {
        return service.rejectManufacturerRequest(id, reason);
    }

    @GET
    @Path("/rejectNomenclatureRequest")
    public NomenclatureRequest rejectNomenclatureRequest(@QueryParam("id") String id, @QueryParam("reason") String reason) {
        return service.rejectNomenclatureRequest(id, reason);
    }

    @GET
    @Path("/getManufacturerRefsExcludingCurrentRecord")
    public List<ManufacturerRef> getManufacturerRefsExcludingCurrentRecord(@NotNull @QueryParam("id") String id) {
        return service.getManufacturerRefsExcludingCurrentRecord(id);
    }

    @GET
    @Path("/getAllManufacturerRefs")
    public List<ManufacturerRef> getAllManufacturerRefs() {
        return service.getAllManufacturerRefs();
    }

    @GET
    @Path("/getManufacturerById")
    public Manufacturer getManufacturerById(@QueryParam("id") String id) {
        return service.getManufacturerById(id);
    }

    @GET
    @Path("/getManufacturerByManufacturerCode")
    public Manufacturer getManufacturerByManufacturerCode(@QueryParam("manufacturerCode") String manufacturerCode) {
        return service.getManufacturerByManufacturerCode(manufacturerCode);
    }

    @GET
    @Path("/getManufacturerByCageCode")
    public Manufacturer getManufacturerByCageCode(@QueryParam("cageCode") String cageCode) {
        return service.getManufacturerByCageCode(cageCode);
    }

    @GET
    @Path("/getManufacturerByDunsCode")
    public Manufacturer getManufacturerByDunsCode(@QueryParam("dunsCode") String dunsCode) {
        return service.getManufacturerByDunsCode(dunsCode);
    }

    @POST
    @Path("/getManufacturerSearchResults")
    public SearchResult<Manufacturer> getManufacturerSearchResults(SearchInput searchInput) {
        return service.getManufacturerSearchResults(searchInput);
    }

    @POST
    @Path("/updateManufacturer")
    public Manufacturer updateManufacturer(Manufacturer manufacturer) {
        return service.updateManufacturer(manufacturer);
    }

    @POST
    @Path("/createManufacturer")
    public Manufacturer createManufacturer(Manufacturer manufacturer) {
        return service.createManufacturer(manufacturer);
    }

    @GET
    @Path("/getManufacturerByNames")
    public Manufacturer getManufacturerByNames(@QueryParam("name") String name, @QueryParam("id") String id) {
        return service.getManufacturerByNames(name, id);
    }

    @GET
    @Path("/getManufacturerRequestById")
    public ManufacturerRequest getManufacturerRequestById(@QueryParam("id") String id) {
        return service.getManufacturerRequestById(id);
    }

    @POST
    @Path("/updateManufacturerRequest")
    public ManufacturerRequest updateManufacturerRequest(ManufacturerRequest manufacturerRequest) {
        return service.updateManufacturerRequest(manufacturerRequest);
    }

    @GET
    @Path("/acceptManufacturerRequest")
    public Manufacturer acceptManufacturerRequest(@QueryParam("id") String id) {
        return service.acceptManufacturerRequest(id);
    }

    @GET
    @Path("/getAllSpecialtyRecords")
    public List<Specialty> getAllSpecialtyRecords() {
        return service.getAllSpecialtyRecords();
    }

    @GET
    @Path("/getAllRiskLevelRecords")
    public List<RiskLevel> getAllRiskLevelRecords() {
        return service.getAllRiskLevelRecords();
    }

    @GET
    @Path("/getAllAccountabilityRecords")
    public List<Accountability> getAllAccountabilityRecords() {
        return service.getAllAccountabilityRecords();
    }

    @GET
    @Path("/getVendorList")
    public List<Vendor> getVendorList() {
        return service.getVendorList();
    }

    @POST
    @Path("/updateFacilitySystem")
    public FacilitySystem updateFacilitySystem(FacilitySystem facilitySystem) {
        return service.updateFacilitySystem(facilitySystem);
    }

    @POST
    @Path("/updateFacilitySubsystem")
    public FacilitySubsystem updateFacilitySubsystem(FacilitySubsystem facilitySubsystem) {
        return service.updateFacilitySubsystem(facilitySubsystem);
    }

    @GET
    @Path("/getClassificationRequestDashboardStats")
    public ClassificationRequestDashboardInfo getClassificationRequestDashboardStats() {
        return service.getClassificationRequestDashboardStats();
    }

    @GET
    @Path("/reworkNomenclatureRequest")
    public NomenclatureRequest reworkNomenclatureRequest(@QueryParam("id") String id, @QueryParam("reason") String reason) {
        return service.reworkNomenclatureRequest(id, reason);
    }

    @GET
    @Path("/reworkManufacturerRequest")
    public ManufacturerRequest reworkManufacturerRequest(@QueryParam("id") String id, @QueryParam("reason") String reason) {
        return service.reworkManufacturerRequest(id, reason);
    }

    @POST
    @Path("/submitManufacturerRequestForReview")
    public ManufacturerRequest submitManufacturerRequestForReview(ManufacturerRequest manufacturerRequest) {
        return service.submitManufacturerRequestForReview(manufacturerRequest);
    }

    @POST
    @Path("/submitNomenclatureRequestForReview")
    public NomenclatureRequest submitNomenclatureRequestForReview(NomenclatureRequest nomenclatureRequest) {
        return service.submitNomenclatureRequestForReview(nomenclatureRequest);
    }

    @GET
    @Path("/saveManufacturerRequestComment")
    public ManufacturerRequest saveManufacturerRequestComment(@QueryParam("id") String id,
                                                              @QueryParam("serviceOrgId") String serviceOrgId,
                                                              @QueryParam("comment") String comment) {
        return service.saveManufacturerRequestComment(id, serviceOrgId, comment);
    }

    @GET
    @Path("/deleteManufacturerRequestComment")
    public ManufacturerRequest deleteManufacturerRequestComment(@QueryParam("id") String id,
                                                                @QueryParam("serviceOrgId") String serviceOrgId,
                                                                @QueryParam("commentId") String commentId) {
        return service.deleteManufacturerRequestComment(id, serviceOrgId, commentId);
    }

    @GET
    @Path("/saveNomenclatureRequestComment")
    public NomenclatureRequest saveNomenclatureRequestComment(@QueryParam("id") String id,
                                                              @QueryParam("serviceOrgId") String serviceOrgId,
                                                              @QueryParam("comment") String comment) {
        return service.saveNomenclatureRequestComment(id, serviceOrgId, comment);
    }

    @GET
    @Path("/deleteNomenclatureRequestComment")
    public NomenclatureRequest deleteNomenclatureRequestComment(@QueryParam("id") String id,
                                                                @QueryParam("serviceOrgId") String serviceOrgId,
                                                                @QueryParam("commentId") String commentId) {
        return service.deleteNomenclatureRequestComment(id, serviceOrgId, commentId);
    }

    @POST
    @Path("/createNomenclature")
    public Nomenclature createNomenclature(Nomenclature nomenclature) {
        return service.createNomenclature(nomenclature);
    }

    @GET
    @Path("/getFederalSupplyClass")
    public List<FederalSupplyClassRef> getFederalSupplyClass() {
        return service.getFederalSupplyClass();
    }

    @GET
    @Path("/getNomenclatureClassNames")
    public List<NomenclatureClassNameRef> getNomenclatureClassNames() {
        return service.getNomenclatureClassNames();
    }

    @GET
    @Path("/setNomenclatureIsActive")
    public Nomenclature setNomenclatureIsActive(@QueryParam("id") String id, @QueryParam("isActive") boolean isActive) {
        return service.setNomenclatureIsActive(id, isActive);
    }

    @GET
    @Path("/setManufacturerIsActive")
    public Manufacturer setManufacturerIsActive(@QueryParam("id") String id, @QueryParam("isActive") boolean isActive) {
        return service.setManufacturerIsActive(id, isActive);
    }

    @POST
    @Path("/saveManufacturerContact")
    public ManufacturerContact saveManufacturerContact(ManufacturerContact contact) {
        return service.saveManufacturerContact(contact);
    }

    @GET
    @Path("/getManufacturerContacts")
    public List<ManufacturerContact> getManufacturerContacts(@QueryParam("manufacturerId") String manufacturerId) {
        return service.getManufacturerContacts(manufacturerId);
    }

    @GET
    @Path("/removeManufacturerContact")
    public boolean removeManufacturerContact(@QueryParam("manufacturerContactId") String manufacturerContactId) {
        return service.removeManufacturerContact(manufacturerContactId);
    }

    @POST
    @Path("/saveManufacturerContactNote")
    public ManufacturerContact saveManufacturerContactNote(@QueryParam("id") String id, Note note) {
        return service.saveManufacturerContactNote(id, note);
    }

    @POST
    @Path("/removeManufacturerContactNote")
    public ManufacturerContact removeManufacturerContactNote(@QueryParam("id") String id, Note note) {
        return service.removeManufacturerContactNote(id, note);
    }

    @GET
    @Path("/getManufacturerContactTypes")
    public List<String> getManufacturerContactTypes() {
        return service.getManufacturerContactTypes();
    }

    @GET
    @Path("/getModalityById")
    public Modality getModalityById(@QueryParam("id") String id) {
        return service.getModalityById(id);
    }

    @POST
    @Path("/createModality")
    public Modality createModality(ModalityDTO modalityDTO) {
        return service.createModality(modalityDTO);
    }

    @POST
    @Path("/saveModality")
    public Modality saveModality(ModalityDTO modalityDTO) {
        return service.saveModality(modalityDTO);
    }

    @GET
    @Path("/getNomenclaturesWithoutModality")
    public List<Nomenclature> getNomenclaturesWithoutModality() {
        return service.getNomenclaturesWithoutModality();
    }

    @GET
    @Path("/getNomenclaturesByModality")
    public List<Nomenclature> getNomenclaturesByModality(@QueryParam("modalityId") String modalityId) {
        return service.getNomenclaturesByModality(modalityId);
    }

    @GET
    @Path("/getNomenclatureCountByModalityId")
    public int getNomenclatureCountByModalityId(@QueryParam("modalityId") String modalityId) {
        return service.getNomenclatureCountByModalityId(modalityId);
    }

    @GET
    @Path("/setModalityIsActive")
    public Modality setModalityIsActive(@QueryParam("id") String id, @QueryParam("isActive") boolean isActive) {
        return service.setModalityIsActive(id, isActive);
    }

    @GET
    @Path("/getActiveConsultantsByModality")
    public List<Consultant> getActiveConsultantsByModality(@QueryParam("modalityId") String modalityId) {
        return service.getActiveConsultantsByModality(modalityId);
    }

    @GET
    @Path("/getAllActiveConsultantsByOrg")
    public List<Consultant> getAllActiveConsultantsByOrg() {
        return service.getAllActiveConsultantsByOrg();
    }

    @GET
    @Path("/getConsultantById")
    public Consultant getConsultantById(@QueryParam("id") String id) {
        return service.getConsultantById(id);
    }

    @GET
    @Path("/getPotentialConsultantUserProfiles")
    public List<UserProfile> getPotentialConsultantUserProfiles() {
        return service.getPotentialConsultantUserProfiles();
    }

    @POST
    @Path("/createConsultant")
    public Consultant createConsultant(Consultant consultant) {
        return service.createConsultant(consultant);
    }

    @POST
    @Path("/saveConsultant")
    public Consultant saveConsultant(Consultant consultant) {
        return service.saveConsultant(consultant);
    }

    @GET
    @Path("/setConsultantIsActive")
    public Consultant setConsultantIsActive(@QueryParam("id") String id, @QueryParam("isActive") boolean isActive) {
        return service.setConsultantIsActive(id, isActive);
    }
}
