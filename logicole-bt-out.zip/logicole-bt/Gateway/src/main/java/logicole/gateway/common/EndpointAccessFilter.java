package logicole.gateway.common;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.history.ApplicationHistory;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.RoleRef;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.logging.ILogger;
import logicole.common.general.util.string.StringUtil;
import logicole.common.servers.history.IAccessChecker;
import logicole.gateway.services.user.UserService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@ApplicationScoped
public class EndpointAccessFilter implements IAccessChecker {

    private static final String LOG_ONLY = "LogOnly";

    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private ILogger logger;
    @Inject
    private UserService userService;

    public void checkAccess(ApplicationHistory history) {
        String businessMethodName = history.actionName;

        if (currentUserBT.isAlreadySecure()) {
            return;
        }

        CurrentUser cUser = currentUserBT.getCurrentUser();
        if (cUser == null || cUser.profile == null || cUser.profile.pkiDn == null) {
            return;
        }

        if (
                ( currentUserBT.getCurrentNodeId() != null && currentUserBT.getCurrentNodeId().equalsIgnoreCase("5a0b41773eb8774c5d2328cc"))
                        && (
                        (businessMethodName.equalsIgnoreCase("SystemService.getEquipmentRequestByReqNum"))
                                || (businessMethodName.equalsIgnoreCase("SystemService.sendEquipmentRequestToDMLSSByReqNum"))
                                || (businessMethodName.equalsIgnoreCase("SystemService.getEquipmentRequestById"))
                                || (businessMethodName.equalsIgnoreCase("SystemService.sendEquipmentRequestToDMLSSById"))
                                || (businessMethodName.equalsIgnoreCase("SystemService.syncEquipmentRecordCounts"))
                )
        ) {
            return;
        }

        List<String> endpoints = cUser.effectiveEndpoints;

        boolean endpointFound = false;

        for (String endpoint : endpoints) {
            if (endpoint != null && endpoint.equalsIgnoreCase(businessMethodName)) {
                endpointFound = true;
                currentUserBT.setAlreadySecure(true);
                break;
            }
        }

        if (!endpointFound) {

            String permissionsCheck = userService.getConfigurationByName("permissionCheck").value;
            UserProfile profile = cUser.profile;

            String associatedRoles = stringifyRoles(profile.roleRefs);

            if (LOG_ONLY.equalsIgnoreCase(permissionsCheck)) {
                this.logger.warn(String.format("Endpoint Access Filter: Endpoint permission missing: profileId=%s name=%s %s, called method %s, User: %s, %s, %s",
                        profile.getId(), profile.firstName, profile.lastName, history.actionName, profile.profileName, profile.getId(), associatedRoles));
            } else {
                throw new UnauthorizedException("You are not authorized to perform the requested action", new ApplicationException(
                        history.actionName.contains(".") ?
                                String.format("Endpoint permission missing: %s, User: %s, %s, %s", history.actionName, profile.profileName, profile.getId(), associatedRoles)
                                : String.format("Endpoint permission missing: %s.%s, User: %s, %s, %s", history.application, history.actionName, profile.profileName, profile.getId(), associatedRoles)));
            }
        }
    }

    private String stringifyRoles(List<RoleRef> roleRefs){
        String associatedRoles = "";
        for (RoleRef r : roleRefs){
            associatedRoles += r.name + ",";
        }
        if (!StringUtil.isEmptyOrNull(associatedRoles)){
            associatedRoles = associatedRoles.substring(0, associatedRoles.length() - 1);
        }
        return associatedRoles;
    }

}
