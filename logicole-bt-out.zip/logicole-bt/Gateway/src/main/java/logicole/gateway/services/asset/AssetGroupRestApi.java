package logicole.gateway.services.asset;

import io.swagger.annotations.Api;
import logicole.common.datamodels.asset.management.AssetGroup;
import logicole.common.datamodels.asset.management.AssetGroupRef;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"AssetGroup"})
@ApplicationScoped
@Path("/assetGroup")
public class AssetGroupRestApi extends ExternalRestApi<AssetGroupService> {

    @Inject
    private AssetScheduleService assetScheduleService;

    @GET
    @Path("getMedicalEquipmentAssetGroupRefs")
    public List<AssetGroupRef> getMedicalEquipmentAssetGroupRefs() {
        return service.getMedicalEquipmentAssetGroupRefs();
    }

    @GET
    @Path("getRealPropertyEquipmentAssetGroupRefs")
    public List<AssetGroupRef> getRealPropertyEquipmentAssetGroupRefs(@QueryParam("nomenclatureId") String nomenclatureId,
                                                                      @QueryParam("facilityId") String facilityId) {
        return service.getRealPropertyEquipmentAssetGroupRefs(nomenclatureId, facilityId);
    }

    @GET
    @Path("getAssetGroupById")
    public AssetGroup getAssetGroupById(@QueryParam("assetGroupId") String assetGroupId) {
        return service.getAssetGroupById(assetGroupId);
    }

    @GET
    @Path("getAssetGroupRefById")
    public AssetGroupRef getAssetGroupRefById(@QueryParam("assetGroupId") String assetGroupId) {
        return service.getAssetGroupRefById(assetGroupId);
    }

    @POST
    @Path("getAssetGroupSearchResults")
    public SearchResult<AssetGroup> getAssetGroupSearchResults(SearchInput searchInput) {
        return service.getAssetGroupSearchResults(searchInput);
    }

    @POST
    @Path("/saveAssetGroup")
    public AssetGroup saveAssetGroup(AssetGroup assetGroup) {
        return service.saveAssetGroup(assetGroup);
    }

    @GET
    @Path("/deleteAssetGroupById")
    public void deleteAssetGroupById(@QueryParam("assetGroupId") String assetGroupId) {
        service.deleteAssetGroupById(assetGroupId);
    }

    @GET
    @Path("/getAssetScheduleCountByGroupId")
    public int getAssetScheduleCountByGroupId(@QueryParam("assetGroupId") String assetGroupId) {
        return assetScheduleService.getSchedulesByAssetId(assetGroupId).size();
    }

    @POST
    @Path("/addAssetsToAssetGroup")
    public AssetGroup addAssetsToAssetGroup(@QueryParam("assetGroupId") String assetGroupId, List<String> assetIdList) {
        service.addAssetsToAssetGroup(assetGroupId, assetIdList);
        AssetGroup assetGroup = getAssetGroupById(assetGroupId);
        assetScheduleService.updateAssetGroupSchedules(assetGroup);
        return assetGroup;
    }

    @POST
    @Path("/removeAssetsFromAssetGroup")
    public AssetGroup removeAssetsFromAssetGroup(@QueryParam("assetGroupId") String assetGroupId, List<String> assetIdList) {
        service.removeAssetsFromAssetGroup(assetGroupId, assetIdList);
        AssetGroup assetGroup = getAssetGroupById(assetGroupId);
        assetScheduleService.updateAssetGroupSchedules(assetGroup);
        return assetGroup;
    }
}
