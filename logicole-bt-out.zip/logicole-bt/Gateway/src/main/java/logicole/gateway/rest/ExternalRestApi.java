package logicole.gateway.rest;

import io.swagger.annotations.Api;
import logicole.common.general.constants.ExceptionConstants;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.InvalidCredentialsException;
import logicole.common.general.exception.InvalidFileTypeException;
import logicole.common.general.exception.NotFoundException;
import logicole.common.general.exception.EUserExceptionMessages;
import logicole.common.general.exception.UserNotFoundException;
import logicole.common.general.logging.ILogger;
import logicole.common.restserver.CorsFilter;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.common.UnauthorizedException;
import logicole.gateway.security.GatewaySecurity;
import org.jboss.resteasy.util.HttpResponseCodes;

import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.ClientErrorException;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import java.lang.reflect.Method;

@Api
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public abstract class ExternalRestApi<T extends BaseGatewayService> {

    @Inject
    protected T service;
    @Inject
    protected GatewaySecurity gatewaySecurity;
    @Context
    private HttpServletResponse response;
    @Inject
    private CorsFilter corsFilter;
    @Inject
    private ILogger logger;

    @AroundInvoke
    public Object aroundLogic(InvocationContext ctx) throws Exception {
        Object retVal = null;
        Method method = ctx.getMethod();
        try {
            gatewaySecurity.verifyRequest();
            logger.info("Starting method {}", method);
            retVal = ctx.proceed();
        } catch (UserNotFoundException userEx) {
            logger.info(ExceptionConstants.GENERIC_ERROR_MSG, userEx);
            corsFilter.addCorsToResponseHeader(response);
            String msg = addDelimiter(userEx.getMessage());
            response.sendError(HttpResponseCodes.SC_UNAUTHORIZED, msg);
        } catch (UnauthorizedException unAuth) {
            logger.info(ExceptionConstants.GENERIC_ERROR_MSG, unAuth);
            corsFilter.addCorsToResponseHeader(response);
            String innerMessage = "";
            if (unAuth.getCause() != null) {
                innerMessage = unAuth.getCause().getMessage();
            }
            String outerMessage = unAuth.getMessage();
            String msg = addDelimiter(String.format("%s %s", outerMessage, innerMessage));
            response.sendError(ExceptionConstants.UNAUTHORIZED_ENDPOINT_EXCEPTION, msg);
        } catch (ApplicationException appEx) {
            logger.info(ExceptionConstants.GENERIC_ERROR_MSG, appEx);
            corsFilter.addCorsToResponseHeader(response);
            String msg = addDelimiter(appEx.getMessage());
            response.sendError(ExceptionConstants.APP_EXCEPTION, msg);
        } catch (InvalidCredentialsException invalidCredsEx) {
            logger.info(ExceptionConstants.GENERIC_ERROR_MSG, invalidCredsEx);
            corsFilter.addCorsToResponseHeader(response);
            String msg = addDelimiter(invalidCredsEx.getMessage());
            response.sendError(ExceptionConstants.INVALID_CREDENTIALS_EXCEPTION, msg);
        } catch (ClientErrorException clientErrorException) {
            logger.info("Client Error Exception", clientErrorException);
            String msg = addDelimiter(EUserExceptionMessages.GENERIC.toString());

            if (null != clientErrorException.getResponse().getMetadata() &&
                    clientErrorException.getResponse().getMetadata().
                            containsKey(ExceptionConstants.CUSTOM_ERROR_MSG_HEADER_KEY)) {
                MultivaluedMap<String, Object> metaMap = clientErrorException.getResponse().getMetadata();
                String customErrMsg = metaMap.get(ExceptionConstants.CUSTOM_ERROR_MSG_HEADER_KEY).toString();
                msg = removeResponseHeaderBrackets(customErrMsg);
                msg = addDelimiter(msg);
            }

            corsFilter.addCorsToResponseHeader(response);
            response.sendError(ExceptionConstants.APP_EXCEPTION, msg);
        } catch (NotFoundException ex) {
            logger.info(ExceptionConstants.GENERIC_ERROR_MSG, ex);
            corsFilter.addCorsToResponseHeader(response);
            String msg = addDelimiter(ex.getMessage());
            response.sendError(HttpResponseCodes.SC_NOT_FOUND, msg);
        } catch (InvalidFileTypeException ex) {
            logger.info(ExceptionConstants.GENERIC_ERROR_MSG, ex);
            corsFilter.addCorsToResponseHeader(response);
            String msg = addDelimiter(ex.getMessage());
            response.sendError(HttpResponseCodes.SC_BAD_REQUEST, msg);
        } catch (Exception ex) {
            logger.info(ExceptionConstants.GENERIC_ERROR_MSG, ex);
            corsFilter.addCorsToResponseHeader(response);
            String msg = addDelimiter(EUserExceptionMessages.GENERIC.toString());
            response.sendError(HttpResponseCodes.SC_INTERNAL_SERVER_ERROR, msg);
        }finally{
            logger.info("Finishing method {}", method);
        }
    
        return retVal;
    }

    private String addDelimiter(String msg) {
        return ExceptionConstants.ERROR_MSG_DELIMITER + msg + ExceptionConstants.ERROR_MSG_DELIMITER;
    }

    private String removeResponseHeaderBrackets(String headerValue) {
        String filteredValue = headerValue.replace("[", "");
        filteredValue = filteredValue.replace("]", "");
        return filteredValue;
    }

}
