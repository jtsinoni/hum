package logicole.gateway.services.system;

import io.swagger.annotations.Api;
import logicole.common.datamodels.featureflag.FeatureFlag;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"SystemFeatureFlag"})
@ApplicationScoped
@Path("/systemFeatureFlag")
public class SystemFeatureFlagRestApi extends ExternalRestApi<SystemFeatureFlagService> {

    @GET
    @Path("/getAllFeatureFlags")
    public List<FeatureFlag> getAllFeatureFlags() {
        return service.getAllFeatureFlags();
    }

    @GET
    @Path("/getActiveFeatureFlags")
    public List<FeatureFlag> getActiveFeatureFlags() {
        return service.getActiveFeatureFlags();
    }

    @GET
    @Path("/getFeatureFlagById")
    public FeatureFlag getFeatureFlagById(@QueryParam("id") String id) {
        return service.getFeatureFlagById(id);
    }

    @GET
    @Path("/isFeatureFlagActive")
    public Boolean isFeatureFlagActive(@QueryParam("name") String name) {
        return service.isFeatureFlagActive(name);
    }

    @POST
    @Path("/createFeatureFlag")
    public FeatureFlag createFeatureFlag(FeatureFlag featureFlag) {
        return service.createFeatureFlag(featureFlag);
    }

    @POST
    @Path("/deleteFeatureFlag")
    public void deleteFeatureFlag(FeatureFlag featureFlag) {
        service.deleteFeatureFlag(featureFlag);
    }

    @POST
    @Path("/updateFeatureFlag")
    public FeatureFlag updateFeatureFlag(FeatureFlag featureFlag) {
        return service.updateFeatureFlag(featureFlag);
    }

    @POST
    @Path("/updateIncludeOrganizations")
    public FeatureFlag updateIncludeOrganizations(FeatureFlag featureFlag) throws ApplicationException {
        return service.updateIncludeOrganizations(featureFlag);
    }

    @POST
    @Path("/updateExcludeOrganizations")
    public FeatureFlag updateExcludeOrganizations(FeatureFlag featureFlag) throws ApplicationException {
        return service.updateExcludeOrganizations(featureFlag);
    }

}
