package logicole.gateway.services.system;

import io.swagger.annotations.Api;
import logicole.common.datamodels.notification.ApplicationNotification;
import logicole.gateway.rest.ExternalRestApi;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Api(tags = {"Notification"})
@ApplicationScoped
@Path("/notification")
public class NotificationRestApi extends ExternalRestApi<NotificationService> {

    @POST
    @Path("/createNotification")
    public void createNotification(ApplicationNotification notification) {
        service.createNotification(notification);
    }

    @GET
    @Path("/getUnreadNotifications")
    public List<ApplicationNotification> getUnreadNotifications() {
        return service.getUnreadNotifications();
    }

    @GET
    @Path("/getAllNotifications")
    public List<ApplicationNotification> getAllNotifications() {
        return service.getAllNotifications();
    }

    @GET
    @Path("/getUnreadNotificationCount")
    @Produces(MediaType.TEXT_PLAIN)
    public Long getUnreadNotificationCount() {
        return service.getUnreadNotificationCount();
    }

    @GET
    @Path("/markNotificationAsRead")
    public List<ApplicationNotification> markNotificationAsRead(@QueryParam("id") String notificationId) {
        return service.markNotificationAsRead(notificationId);
    }

}
