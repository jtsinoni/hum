package logicole.gateway.rest;

import logicole.common.general.configuration.ConfigurationManager;
import logicole.common.general.logging.ILogger;
import logicole.common.restserver.LogiColeJacksonJsonProvider;
import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.net.MalformedURLException;

public abstract class MicroserviceClient<T extends Object> {

    @Inject
    private ConfigurationManager configurationManager;
    @Inject
    private TokenHeaderRequestFilter requestFilter;
    @Inject
    private MicroserviceClientResponseFilter responseFilter;
    @Inject
    private ILogger logger;

    protected String businessApiUrl;

    protected final Class<T> classType;
    private final String serviceName;

    @Inject
    public MicroserviceClient(Class<T> classType, String serviceName) {
        this.classType = classType;
        this.serviceName = serviceName;
    }

    @PostConstruct
    public void postConstruct() {
        businessApiUrl = configurationManager.getDmlesAppHost();
    }

    public T createClient() {
        ResteasyWebTarget target = buildTarget();
        target.register(requestFilter);
        target.register(responseFilter);

        T client = target.proxy(classType);

        try {
            String verifiedUrl = target.getUri().toURL().toString();
        } catch (MalformedURLException e) {
            logger.error(String.format("The URL is malformed - %s", e.getMessage()));
        }

        return client;
    }

    protected ResteasyWebTarget buildTarget() {
        ResteasyClientBuilder resteasyClientBuilder = new ResteasyClientBuilder();
        resteasyClientBuilder.connectionPoolSize(50);
        ResteasyClient resteasyClient = resteasyClientBuilder.register(LogiColeJacksonJsonProvider.class).build();

        String url = getUrl();

        ResteasyWebTarget target = resteasyClient.target(url);

        return target;
    }

    private String getUrl() {
        String url = businessApiUrl.trim();
        if (url != null && !url.endsWith("/")) {
            url += "/";
        }
        return url + serviceName;
    }
}
