package logicole.gateway.services.filemanager;

import logicole.apis.filemanager.IFileManagerAdminMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class FileManagerAdminMicroserviceClient extends MicroserviceClient<IFileManagerAdminMicroserviceApi> {
    public FileManagerAdminMicroserviceClient() {
        super(IFileManagerAdminMicroserviceApi.class, "logicole-filemanager");
    }

    @Produces
    public IFileManagerAdminMicroserviceApi getFilemanagerAdminMicroserviceApi() {
        return createClient();
    }
}
