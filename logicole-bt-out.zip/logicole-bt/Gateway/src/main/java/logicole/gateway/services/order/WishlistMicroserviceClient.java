package logicole.gateway.services.order;

import logicole.apis.order.IWishlistMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class WishlistMicroserviceClient extends MicroserviceClient<IWishlistMicroserviceApi> {
    public WishlistMicroserviceClient(){
        super(IWishlistMicroserviceApi.class, "logicole-order");
    }

    @Produces
    public IWishlistMicroserviceApi getIWishlistMicroserviceApi() {
        return createClient();
    }

}
