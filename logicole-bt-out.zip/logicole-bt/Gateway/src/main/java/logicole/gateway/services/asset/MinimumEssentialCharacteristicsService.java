package logicole.gateway.services.asset;

import logicole.apis.asset.IMinimumEssentialCharacteristicsMicroserviceApi;
import logicole.common.datamodels.asset.lookup.MilitaryStandard1691Summary;
import logicole.common.datamodels.asset.minimumessentialcharacteristics.MinimumEssentialCharacteristics;
import logicole.common.datamodels.equipment.request.Device;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.equipment.EquipmentRequestService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.util.List;

@ApplicationScoped
public class MinimumEssentialCharacteristicsService extends BaseGatewayService<IMinimumEssentialCharacteristicsMicroserviceApi> {

    public MinimumEssentialCharacteristicsService() {
        super("Asset");
    }

    @Inject
    AssetLookupService assetLookupService;
    @Inject
    private EquipmentRequestService equipmentRequestService;

    public List<MinimumEssentialCharacteristics> getAllMinimumEssentialCharacteristics() {
        UserProfile currentUser = currentUserBT.getCurrentUser().profile;
        return microservice.getAllMinimumEssentialCharacteristics(currentUser.currentNodeRef);
    }

    public MinimumEssentialCharacteristics getMinimumEssentialCharacteristicById(String id) {
        return microservice.getMinimumEssentialCharacteristicById(id);
    }

    public MinimumEssentialCharacteristics addMinimumEssentialCharacteristic(MinimumEssentialCharacteristics mec) {
        UserProfile currentUser = currentUserBT.getCurrentUser().profile;
        MinimumEssentialCharacteristics foundMec = microservice.getMinimumEssentialCharacteristicByJsn(mec.jsn, currentUser.currentNodeRef);
        if (foundMec == null) {
            mec.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.addMinimumEssentialCharacteristic(mec);
        } else {
            throw new ApplicationException("Minimum Essential Characteristic record already exists.");
        }
    }

    public MinimumEssentialCharacteristics updateMinimumEssentialCharacteristic(MinimumEssentialCharacteristics mec) {
        if (!mec.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.currentNodeRef.getId())) {
            throw new ApplicationException("No privileges to update the Minimum Essential Characteristic record.");
        } else {
            MinimumEssentialCharacteristics foundMec = microservice.getMinimumEssentialCharacteristicById(mec.getId());
            if (foundMec == null) {
                throw new ApplicationException("Minimum Essential Characteristic does not exist");
            } else {
                UserProfile currentUser = currentUserBT.getCurrentUser().profile;
                if (!(foundMec.jsn.equalsIgnoreCase(mec.jsn))
                        && microservice.getMinimumEssentialCharacteristicByJsn(mec.jsn, currentUser.currentNodeRef) != null) {
                    throw new ApplicationException("Minimum Essential Characteristic record already exists.");
                } else {
                    return microservice.updateMinimumEssentialCharacteristic(mec);
                }
            }
        }
    }

    public void deleteMinimumEssentialCharacteristic(String mecId) {
        MinimumEssentialCharacteristics foundMec = microservice.getMinimumEssentialCharacteristicById(mecId);
        if (foundMec == null) {
            throw new ApplicationException("Minimum Essential Characteristic does not exist");
        } else {
            if (!foundMec.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.currentNodeRef.getId())) {
                throw new ApplicationException("No privileges to delete the Minimum Essential Characteristic record.");
            }
        }
        microservice.deleteMinimumEssentialCharacteristic(mecId);
    }

    public boolean checkIfMecRefExistsInActiveEquipmentRequests(@QueryParam("mecId") String mecId) {
        return equipmentRequestService.checkIfMecRefExistsInActiveEquipmentRequests(mecId);
    }

    public List<Device> getAllDeviceCodes() {
        return equipmentRequestService.getAllDeviceCodes();
    }

    public List<MinimumEssentialCharacteristics> getMinimumEssentialCharacteristicsByDeviceCode(String deviceCode) {
        UserProfile currentUser = currentUserBT.getCurrentUser().profile;
        return microservice.getMinimumEssentialCharacteristicsByDeviceCode(deviceCode, currentUser.currentNodeRef);
    }

    public List<MilitaryStandard1691Summary> getAllMilitaryStandard1691() {
        return assetLookupService.getAllMilitaryStandard1691();
    }
}
