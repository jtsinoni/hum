package logicole.gateway.services.asset;

import logicole.apis.asset.ICustodianMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class CustodianMicroserviceClient extends MicroserviceClient<ICustodianMicroserviceApi> {
    public CustodianMicroserviceClient() {
        super(ICustodianMicroserviceApi.class, "logicole-asset");
    }

    @Produces
    public ICustodianMicroserviceApi getICustodianMicroserviceApi() {
        return createClient();
    }
}
