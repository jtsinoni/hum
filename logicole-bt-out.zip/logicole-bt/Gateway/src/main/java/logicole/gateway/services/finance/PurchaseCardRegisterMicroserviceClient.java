package logicole.gateway.services.finance;

import logicole.apis.finance.IPurchaseCardRegisterMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class PurchaseCardRegisterMicroserviceClient extends MicroserviceClient<IPurchaseCardRegisterMicroserviceApi> {
    public PurchaseCardRegisterMicroserviceClient(){
        super(IPurchaseCardRegisterMicroserviceApi.class, "logicole-finance");
    }

    @Produces
    public IPurchaseCardRegisterMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
