package logicole.gateway.services.catalog;


import logicole.apis.catalog.ICatalogNotesMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class CatalogNotesMicroserviceClient extends MicroserviceClient<ICatalogNotesMicroserviceApi> {
    public CatalogNotesMicroserviceClient() {
        super(ICatalogNotesMicroserviceApi.class, "logicole-catalog");
    }

    @Produces
    public ICatalogNotesMicroserviceApi getICatalogNotesMicroserviceApi(){
        return createClient();
    }
}
