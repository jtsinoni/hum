package logicole.gateway.services.inventory;

import logicole.apis.inventory.IAuditMicroserviceApi;
import logicole.common.datamodels.inventory.Audit.AuditStatus;
import logicole.common.datamodels.inventory.Audit.AuditType;
import logicole.common.datamodels.inventory.Audit.InventoryAudit;
import logicole.common.datamodels.inventory.Audit.InventoryAuditCount;
import logicole.common.datamodels.notification.ENotificationType;
import logicole.common.datamodels.notification.EmailMessage;
import logicole.common.datamodels.product.Offer;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.system.NotificationService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@ApplicationScoped
public class AuditService extends BaseGatewayService<IAuditMicroserviceApi> {

    @Inject
    protected NotificationService notificationService;

    public AuditService() {
        super("Audit");
    }

    public List<InventoryAudit> getInventoryAuditsByInventorySystemId(String inventorySystemId) {
        return microservice.getInventoryAuditsByInventorySystemId(inventorySystemId);
    }

    public List<InventoryAuditCount> getCountListByAudit(String auditId) {
        return microservice.getCountListByAudit(auditId);
    }

    public List<InventoryAuditCount> getResearchListByAudit(String auditId) {
        return microservice.getResearchListByAudit(auditId);
    }

    public InventoryAudit getInventoryAuditById(String inventoryAuditId) {
        return microservice.getInventoryAuditById(inventoryAuditId);
    }

    public List<InventoryAuditCount> getCountListByStorageLocation(String auditId, String storageLocationId) {
        return microservice.getCountListByStorageLocation(auditId, storageLocationId);
    }

    public List<InventoryAuditCount> getResearchListByStorageLocation(String auditId, String storageLocationId) {
        return microservice.getResearchListByStorageLocation(auditId, storageLocationId);
    }

    public List<InventoryAuditCount> getFinalizeListByAudit(String auditId) {
        return microservice.getFinalizeListByAudit(auditId);
    }

    public List<AuditType> getAuditTypes() {
        return microservice.getAuditTypes();
    }

    public List<AuditStatus> getAuditStatusList() {
        return microservice.getAuditStatusList();
    }

    public InventoryAudit createSchedule(InventoryAudit inventoryAudit) {
        InventoryAudit audit = microservice.createSchedule(inventoryAudit);
        EmailMessage message = microservice.getEmailNotification(ENotificationType.AUDIT_SCHEDULED, audit);
        notificationService.sendEmail(message);
        return audit;
    }

    public InventoryAudit cancelSchedule(InventoryAudit inventoryAudit) {
        return microservice.cancelSchedule(inventoryAudit);
    }

    public InventoryAudit beginInventory(InventoryAudit inventoryAudit) {
        return microservice.beginInventory(inventoryAudit);
    }

    public InventoryAudit beginInventoryFromLocationManagement(InventoryAudit inventoryAudit) {
        return microservice.beginInventoryFromLocationManagement(inventoryAudit);
    }

    public InventoryAudit completeAudit(InventoryAudit inventoryAudit) {
        InventoryAudit audit = microservice.completeAudit(inventoryAudit);
        EmailMessage message = microservice.getEmailNotification(ENotificationType.AUDIT_COMPLETED, audit);
        notificationService.sendEmail(message);
        return audit;
    }

    public InventoryAudit saveAuditNotificationContacts(InventoryAudit inventoryAudit) {
        return microservice.saveAuditNotificationContacts(inventoryAudit);
    }

    public InventoryAudit saveAuditPOCInfo(InventoryAudit inventoryAudit) {
        return microservice.saveAuditPOCInfo(inventoryAudit);
    }

    public InventoryAudit saveAuditScheduleInfo(InventoryAudit inventoryAudit) {
        return microservice.saveAuditScheduleInfo(inventoryAudit);
    }

    public InventoryAudit saveAuditScopeInfo(InventoryAudit inventoryAudit) {
        return microservice.saveAuditScopeInfo(inventoryAudit);
    }

    public List<InventoryAuditCount> saveCountListByAudit(String auditId, List<InventoryAuditCount> inventoryAuditCount) {
        return microservice.saveCountListByAudit(auditId, inventoryAuditCount);
    }

    public List<InventoryAuditCount> saveResearchListByAudit(String auditId, List<InventoryAuditCount> inventoryAuditCount) {
        return microservice.saveResearchListByAudit(auditId, inventoryAuditCount);
    }

    public InventoryAudit submitResearchListByAudit(String auditId, List<InventoryAuditCount> inventoryAuditCount) {
        return microservice.submitResearchListByAudit(auditId, inventoryAuditCount);
    }

    public List<InventoryAuditCount> addItemToCountList(String auditId, Offer offer) {
        return microservice.addItemToCountList(auditId, offer);
    }

    public void deleteAuditCount(InventoryAuditCount inventoryAuditCount) {
        microservice.deleteAuditCount(inventoryAuditCount);
    }

    public List<InventoryAuditCount> transferAuditCount(InventoryAuditCount inventoryAuditCount) {
        return microservice.transferAuditCount(inventoryAuditCount);
    }



}
