package logicole.gateway.services.system;

import io.swagger.annotations.Api;
import logicole.common.datamodels.general.customizabletype.CustomizableType;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import java.util.List;

@Api(tags = {"CustomizableType"})
@ApplicationScoped
@Path("/customizableType")
public class CustomizableTypeRestApi extends ExternalRestApi<CustomizableTypeService> {
    @GET
    @Path("/getCustomizableTypes")
    public List<CustomizableType> getCustomizableTypes() {
        return service.getCustomizableTypes();
    }
}
