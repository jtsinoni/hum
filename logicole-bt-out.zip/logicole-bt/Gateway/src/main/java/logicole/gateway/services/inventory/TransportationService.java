package logicole.gateway.services.inventory;

import logicole.apis.inventory.ITransportationMicroserviceApi;
import logicole.common.datamodels.inventory.Shipment;
import logicole.common.datamodels.inventory.Shipper;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class TransportationService  extends BaseGatewayService<ITransportationMicroserviceApi> {

    public TransportationService() {
        super("Transportation");
    }

    public List<Shipment> getShipments() {
        return microservice.getShipments();
    }

    public Shipment getShipmentById(String shipmentId) {
        return microservice.getShipmentById(shipmentId);
    }

    public List<Shipment> getInShipments() {
        return microservice.getInShipments();
    }

    public List<Shipment> getOutShipments() {
        return microservice.getOutShipments();
    }

    public List<Shipper> getShippers() {
        return microservice.getShippers();
    }

    public Shipper getShipperById(String shipperId) {
        return microservice.getShipperById(shipperId);
    }

    public Shipper getShipperByName(String shipperName) {

        if(StringUtil.isEmptyOrNull(shipperName)){
            throw new ApplicationException("Shipper Name is required");
        }

        return microservice.getShipperByName(shipperName);
    }


}
