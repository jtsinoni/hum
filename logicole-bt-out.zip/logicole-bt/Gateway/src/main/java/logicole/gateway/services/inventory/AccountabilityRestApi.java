package logicole.gateway.services.inventory;

import io.swagger.annotations.Api;
import logicole.common.datamodels.inventory.*;
import logicole.common.datamodels.inventory.Return.InventoryReturn;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Accountability"})
@ApplicationScoped
@Path("/accountability")
public class AccountabilityRestApi extends ExternalRestApi<AccountabilityService> {

    @GET
    @Path("/getGainTypes")
    public List<GainType> getGainTypes() {
        return service.getGainTypes();
    }

    @POST
    @Path("/recordGain")
    public Integer recordGain(AccountabilityRecord accountabilityRecord) {
        return service.recordGain(accountabilityRecord);
    }

    @GET
    @Path("/getAccountabilityLogsByItemLocationId")
    public List<AccountabilityLog> getAccountabilityLogsByItemLocationId(@QueryParam("itemLocationId") String itemLocationId) {
        return service.getAccountabilityLogsByItemLocationId(itemLocationId);
    }

    @GET
    @Path("/getLossTypes")
    public List<LossType> getLossTypes() {
        return service.getLossTypes();
    }

    @POST
    @Path("/recordLoss")
    public Integer recordLoss(AccountabilityRecord accountabilityRecord) {
        return service.recordLoss(accountabilityRecord);
    }


    @POST
    @Path("/recordCommercialReturn")
    public InventoryReturn recordCommercialReturn(AccountabilityRecord accountabilityRecord) {
        return service.recordCommercialReturn(accountabilityRecord);
    }

    @GET
    @Path("/getDestructionMethods")
    public List<DestructionMethod> getDestructionMethods() {
        return service.getDestructionMethods();
    }

    @POST
    @Path("/recordDestruction")
    public Integer recordDestruction(AccountabilityRecord accountabilityRecord) {
        return service.recordDestruction(accountabilityRecord);
    }

    @POST
    @Path("/transferQuantity")
    public InventoryRecord transferQuantity(AccountabilityRecord accountabilityRecord) {
        return service.transferQuantity(accountabilityRecord);
    }

    @POST
    @Path("/recordCustomerReturn")
    public Integer recordCustomerReturn(AccountabilityRecord accountabilityRecord) {
        return service.recordCustomerReturn(accountabilityRecord);
    }

    @POST
    @Path("/saveAccountabilityLog")
    public AccountabilityLog saveAccountabilityLog(AccountabilityLog accountabilityLog) {
        return service.saveAccountabilityLog(accountabilityLog);
    }

    @POST
    @Path("/saveAccountabilityLogs")
    public List<AccountabilityLog> saveAccountabilityLog(List<AccountabilityLog> accountabilityLogs) {
        return service.saveAccountabilityLogs(accountabilityLogs);
    }

    @GET
    @Path("/getCustomerList")
    public List<OrganizationRef> getCustomerList(@QueryParam("nodeId") String nodeId) {
        return service.getCustomerList(nodeId);
    }

    @POST
    @Path("/issueNonRoutine")
    public Integer issueNonRoutine(AccountabilityRecord accountabilityRecord) {
        return service.issueNonRoutine(accountabilityRecord);
    }

}
