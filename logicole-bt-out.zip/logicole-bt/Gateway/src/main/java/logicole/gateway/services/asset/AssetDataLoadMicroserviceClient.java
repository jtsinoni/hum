package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetDataLoadMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AssetDataLoadMicroserviceClient extends MicroserviceClient<IAssetDataLoadMicroserviceApi> {
    public AssetDataLoadMicroserviceClient() {
        super(IAssetDataLoadMicroserviceApi.class, "logicole-asset");
    }

    @Produces
    public IAssetDataLoadMicroserviceApi getIAssetMicroserviceApi() {
        return createClient();
    }
}
