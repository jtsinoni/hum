package logicole.gateway.services.workorder;

import logicole.apis.workorder.ICoreWorkOrderMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class CoreWorkOrderMicroserviceClient extends MicroserviceClient<ICoreWorkOrderMicroserviceApi> {
    public CoreWorkOrderMicroserviceClient() {
        super(ICoreWorkOrderMicroserviceApi.class, "logicole-workorder");
    }

    @Produces
    public ICoreWorkOrderMicroserviceApi getICoreWorkOrderMicroserviceApi() {
        return createClient();
    }
}
