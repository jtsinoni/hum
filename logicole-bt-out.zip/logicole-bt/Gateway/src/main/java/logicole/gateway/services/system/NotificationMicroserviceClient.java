package logicole.gateway.services.system;

import logicole.apis.system.IApplicationNotificationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class NotificationMicroserviceClient extends MicroserviceClient<IApplicationNotificationMicroserviceApi> {
    public NotificationMicroserviceClient() {
        super(IApplicationNotificationMicroserviceApi.class, "logicole-system");
    }

    @Produces
    public IApplicationNotificationMicroserviceApi getIApplicationNotificationMicroserviceApi() {
        return createClient();
    }

}
