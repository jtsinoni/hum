package logicole.gateway.services.system;

import io.swagger.annotations.*;
import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.VersionInformation;
import logicole.common.datamodels.equipment.request.EquipmentRequest;
import logicole.common.datamodels.equipment.workflow.process.WorkflowProcessing;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.system.*;
import logicole.common.datamodels.system.frequency.Frequency;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

@Api(tags = {"System"})
@ApplicationScoped
@Path("/system")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class SystemRestApi extends ExternalRestApi<SystemService> {

    @Inject
    private MultiPartFormUtil uploadUtil;

    @GET
    @Path("/getHealthCheck")
    public HealthCheckResult getHealthCheck() {
        return service.getHealthCheck();
    }

    @GET
    @Path("/getAllSystemVersionInformation")
    public List<VersionInformation> getAllSystemVersionInformation() throws IOException {
        return service.getAllSystemVersionInformation();
    }

    @GET
    @Path("/getDatabaseVersionInformation")
    public VersionInformation getDatabaseVersionInformation() {
        return service.getDatabaseVersionInformation();
    }

    @GET
    @Path("/updateEnumCollections")
    public Boolean updateEnumCollections() {
        return service.updateEnumCollections();
    }

    @GET
    @Path("/getResponseByEmailId")
    public EmailResponse getResponseByEmailId(@QueryParam("emailId") String emailId) {
        return service.getResponseByEmailId(emailId);
    }

    @GET
    @Path("/initializeSystem")
    public List<InitializationRoutineRun> initializeSystem() {
        return service.initializeSystem();
    }

    @GET
    @Path("/sendEquipmentRequestToDMLSSById")
    public EquipmentRequest sendEquipmentRequestToDMLSSById(@QueryParam("objId") String objId) {
        return service.sendEquipmentRequestToDMLSSById(objId);
    }

    @GET
    @Path("/sendEquipmentRequestToDMLSSByReqNum")
    public EquipmentRequest sendEquipmentRequestToDMLSSByReqNum(@QueryParam("reqNum") String reqNum) {
        return service.sendEquipmentRequestToDMLSSByReqNum(reqNum);
    }

    @GET
    @Path("/getEquipmentRequestById")
    public EquipmentRequest getEquipmentRequestById(@QueryParam("objId") String objId) {
        return service.getEquipmentRequestById(objId);
    }

    @GET
    @Path("/getEquipmentRequestByReqNum")
    public EquipmentRequest getEquipmentRequestByReqNum(@QueryParam("reqNum") String reqNum) {
        return service.getEquipmentRequestByReqNum(reqNum);
    }

    @GET
    @Path("/getSiteEquipmentRecordByMeId")
    public Long getSiteEquipmentRecordByMeId(@QueryParam("siteDoDAAC") String siteDoDAAC, @QueryParam("meId") String meId) {
        return service.getSiteEquipmentRecordByMeId(siteDoDAAC, meId);
    }

    @GET
    @Path("/getSiteEquipmentRecordByItemId")
    public Long getSiteEquipmentRecordByItemId(@QueryParam("siteDoDAAC") String siteDoDAAC, @QueryParam("itemId") String itemId) {
        return service.getSiteEquipmentRecordByItemId(siteDoDAAC, itemId);
    }

    @GET
    @Path("/getSiteEquipmentRecordAfterDate")
    public Long getSiteEquipmentRecordAfterDate(@QueryParam("siteDoDAAC") String siteDoDAAC, @QueryParam("modifiedDate") Date modifiedDate) {
        return service.getSiteEquipmentRecordAfterDate(siteDoDAAC, modifiedDate);
    }

    @GET
    @Path("/reloadWorkflowStateRules")
    public Boolean reloadWorkflowStateRules() {
        return service.reloadWorkflowStateRules();
    }

    @GET
    @Path("/getWorkflowProcessById")
    public WorkflowProcessing getWorkflowProcessById(@QueryParam("id") String id) {
        return service.getWorkflowProcessById(id);
    }

    @GET
    @Path("/syncEquipmentRecordCounts")
    public List<String> syncEquipmentRecordCounts() {
        return service.syncEquipmentRecordCounts();
    }

    @POST
    @Path("/processUploadedEquipmentRecordFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.TEXT_PLAIN)
    @ApiOperation(value = "Import a file", notes = "The return value will be the file ID")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to import",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public String processUploadedEquipmentRecordFile(@QueryParam("fileType") String fileType,
                                                     @ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {

        InputStream inputStream;
        byte[] content;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new FatalProcessingException(
                    "Was not able to extract file from request " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxUploadSize();

        if (content.length > maxUploadSize) {
            throw new FatalProcessingException(
                    "Uploaded file size exceeds server max POST Size value  of " + maxUploadSize
                            + " bytes");
        }
        return service.processUploadedEquipmentRecordFile(content, uploadedFileName);
    }

    @GET
    @Path("/getDmlssSiteNerCustomer")
    public List<EquipmentRequest> getDmlssSiteNerCustomer(@QueryParam("siteDodaac") String siteDodaac) throws MessagingException, ValidationException {
        return service.getDmlssSiteNerCustomer(siteDodaac);
    }

    @GET
    @Path("/getAllAuthoritativeSources")
    public List<AuthoritativeSource> getAllAuthoritativeSources() {
        return service.getAllAuthoritativeSources();
    }

    @GET
    @Path("/getAllAuthoritativeSourceRefs")
    public List<AuthoritativeSourceRef> getAllAuthoritativeSourceRefs() {
        return service.getAllAuthoritativeSourceRefs();
    }

    @GET
    @Path("/getAuthoritativeSourceById")
    public AuthoritativeSource getAuthoritativeSourceById(@NotNull @QueryParam("id") String id) {
        return service.getAuthoritativeSourceById(id);
    }

    @GET
    @Path("/getAuthoritativeSourceRefById")
    public AuthoritativeSourceRef getAuthoritativeSourceRefById(@NotNull @QueryParam("id") String id) {
        return service.getAuthoritativeSourceRefById(id);
    }

    @GET
    @Path("/getAuthoritativeSourceByCode")
    public AuthoritativeSource getAuthoritativeSourceByCode(@NotNull @QueryParam("code") String code) {
        return service.getAuthoritativeSourceByCode(code);
    }

    @GET
    @Path("/getAuthoritativeSourceRefByCode")
    public AuthoritativeSourceRef getAuthoritativeSourceRefByCode(@NotNull @QueryParam("code") String code) {
        return service.getAuthoritativeSourceRefByCode(code);
    }

    @GET
    @Path("/updateAuthoritativeSourceName")
    public AuthoritativeSource updateAuthoritativeSourceName(@NotNull @QueryParam("id") String id,
                                                             @NotNull @QueryParam("name") String name) {
        return service.updateAuthoritativeSourceName(id, name);
    }

    @GET
    @Path("/addDataCategoryToAuthoritativeSource")
    public AuthoritativeSource addDataCategoryToAuthoritativeSource(@NotNull @QueryParam("id") String id,
                                                                    @NotNull @QueryParam("dataCategory") String dataCategory) {
        return service.addDataCategoryToAuthoritativeSource(id, dataCategory);
    }

    @GET
    @Path("/removeDataCategoryFromAuthoritativeSource")
    public AuthoritativeSource removeDataCategoryFromAuthoritativeSource(@NotNull @QueryParam("id") String id,
                                                                         @NotNull @QueryParam("dataCategory") String dataCategory) {
        return service.removeDataCategoryFromAuthoritativeSource(id, dataCategory);
    }

    @POST
    @Path("/updateAuthoritativeSourceScopeNodeRefs")
    public AuthoritativeSource updateAuthoritativeSourceScopeNodeRefs(@NotNull @QueryParam("id") String id,
                                                                      List<OrganizationRef> scopeNodeRefs) {
        return service.updateAuthoritativeSourceScopeNodeRefs(id, scopeNodeRefs);
    }

    @GET
    @Path("/deleteAuthoritativeSource")
    public void deleteAuthoritativeSource(@NotNull @QueryParam("id") String id) {
        service.deleteAuthoritativeSource(id);
    }

    @GET
    @Path("/getFrequencyByName")
    public Frequency getFrequencyByName(@NotNull @QueryParam("frequency") String frequency) {
        return service.getFrequencyByName(frequency);
    }

    @POST
    @Path("/loadFrequency")
    public void loadFrequency(Frequency frequency) {
        service.loadFrequency(frequency);
    }

    @GET
    @Path("/deleteFrequencyById")
    public void deleteFrequencyById(@NotNull @QueryParam("frequencyId") String frequencyId) {
        service.deleteFrequencyById(frequencyId);
    }

    @POST
    @Path("/loadAuthoritativeSource")
    public void loadAuthoritativeSources(AuthoritativeSource authoritativeSource) {
        service.loadAuthoritativeSource(authoritativeSource);
    }

    @GET
    @Path("/getBusinessEventHistoryServices")
    public List<String> getBusinessEventHistoryServices() {
        return service.getBusinessEventHistoryServices();
    }


}
