package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceValidationMicroserviceApi;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.fundingsource.FundingSource;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.validation.FinanceValidation;
import logicole.common.datamodels.finance.validation.FinanceValidationGroup;
import logicole.common.datamodels.finance.validation.FinanceValidationResponse;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@ApplicationScoped
public class FinanceValidationService extends BaseGatewayService<IFinanceValidationMicroserviceApi> {

    @Inject
    protected FinanceAdminService financeAdminService;

    public FinanceValidationService(){
        super("FinanceValidation");
    }

    public FinanceValidationGroup findGroupById(String id) {
        return microservice.findGroupById(id);
    }

    public List<FinanceValidationGroup> findAllFinanceValidationGroups() {
        return microservice.findAllFinanceValidationGroups();
    }

    public List<FinanceValidation> findAllFinanceValidation() {
        return microservice.findAllFinanceValidation();
    }

    public FinanceValidationGroup addFinanceValidationToGroup(String groupId, String validationId) {
        return microservice.addFinanceValidationToGroup(groupId, validationId);
    }

    public FinanceValidationGroup removeFinanceValidationToGroup(String groupId, String validationId) {
        return microservice.removeFinanceValidationToGroup(groupId, validationId);
    }

    public FinanceValidationGroup createGroup(FinanceValidationGroup group) {
        return microservice.createGroup(group);
    }

    public FinanceValidation createValidation(FinanceValidation item) {
        return microservice.createValidation(item);
    }

    public List<String> validateRequest(CommonFinanceRequest request) {
        if (request == null || request.requestingOrg == null || request.requestingOrg.id == null) {
            throw new ApplicationException("The request, requesting org or requesting org id is not provided");
        }
        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(request.requestingOrg.id);
        if (financialSystem == null) {
            logger.error("The financial system for organization id was not found - " + request.requestingOrg.id);
            throw new ApplicationException("The financial system for organization was not found - " + request.requestingOrg.name);
        }
        request.financialSystem = financialSystem;
        return microservice.validateRequest(request);
    }

    public List<String> validateFundingSource(FundingSource fundingSource) {
        return microservice.validateFundingSource(fundingSource);
    }

    public FinanceValidationResponse validateAllFundingNodeTargets(FundingNode fundingNode) {
        return microservice.validateAllFundingNodeTargets(fundingNode);
    }
}

