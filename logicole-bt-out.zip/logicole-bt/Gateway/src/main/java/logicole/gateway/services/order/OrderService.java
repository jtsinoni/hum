package logicole.gateway.services.order;

import logicole.apis.order.IOrderMicroserviceApi;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.catalog.Catalog;
import logicole.common.datamodels.communications.ordering.PurchasingStatusWrapper;
import logicole.common.datamodels.delivery.DueOutRef;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.output.AuthorizedNode;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.request.EBusinessEventType;
import logicole.common.datamodels.finance.request.FinanceItem;
import logicole.common.datamodels.finance.request.RequestGroup;
import logicole.common.datamodels.finance.response.CommonFinanceResponse;
import logicole.common.datamodels.general.Address;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchCriterion;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.inventory.ProductAvailableQuantity;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.buyer.BuyerDTO;
import logicole.common.datamodels.order.order.*;
import logicole.common.datamodels.receipt.DueIn;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.sale.seller.BuyerSellerAccount;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountDTO;
import logicole.common.datamodels.sale.seller.CustomerContract;
import logicole.common.datamodels.sale.seller.Seller;
import logicole.common.datamodels.sale.seller.SellerCallNumber;
import logicole.common.datamodels.sale.seller.SellerRef;
import logicole.common.datamodels.sale.seller.SellerTypeOrderConfiguration;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.constants.ExceptionConstants;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FinanceUpdateException;
import logicole.common.general.util.ObjectMapper;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.AssetMaintenanceProcedureRestApi;
import logicole.gateway.services.catalog.CatalogService;
import logicole.gateway.services.communications.CommunicationsSubmitRequestService;
import logicole.gateway.services.delivery.DueOutService;
import logicole.gateway.services.finance.FinanceAdminService;
import logicole.gateway.services.finance.FinanceProcessingService;
import logicole.gateway.services.finance.validator.FinanceProcessingValidator;
import logicole.gateway.services.inventory.InventoryService;
import logicole.gateway.services.receipt.DueInService;
import logicole.gateway.services.sale.SellerService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.ClientErrorException;
import javax.ws.rs.core.MultivaluedMap;
import java.util.*;
import java.util.stream.Collectors;

@ApplicationScoped
public class OrderService extends BaseGatewayService<IOrderMicroserviceApi> {
    public static final String CUSTOMER_NOT_FOUND_EXCEPTION = "No Customer is associated to this profile";

    @Inject
    protected BuyerService buyerService;
    @Inject
    protected CartService cartService;
    @Inject
    private DueInService dueInService;
    @Inject
    protected FinanceProcessingService financeProcessingService;
    @Inject
    protected FinanceProcessingValidator financeProcessingValidator;
    @Inject
    protected FinanceAdminService financeAdminService;
    @Inject
    protected SellerService sellerService;
    @Inject
    private CommunicationsSubmitRequestService communicationsSubmitRequestService;
    @Inject
    private InventoryService inventoryService;
    @Inject
    protected CatalogService catalogService;
    @Inject
    private DueOutService dueOutService;
    @Inject
    private ObjectMapper objectMapper;
    @Inject
    private StringUtil stringUtil;

    public OrderService() {
        super("Order");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    private void setBuyerIdSearchCriteria(String buyerId, SearchInput searchInput) {
        if (StringUtil.isEmptyOrNull(buyerId)) {
            return;
        }

        if (searchInput.searchCriteria == null) {
            searchInput.searchCriteria = new ArrayList<>();
        }

        SearchCriterion searchCriterion = new SearchCriterion();
        searchCriterion.propName = "buyerId";
        List<Object> propValues = new ArrayList<>();
        propValues.add(buyerId);
        searchCriterion.propValues = propValues.toArray();
        searchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
        searchInput.searchCriteria.add(searchCriterion);
    }

    //          DTO message displayed on the screen: successfully sent to communications
    public synchronized List<OrderResponseDTO> addOrder(OrderDTO order) {
        List<OrderResponseDTO> orderResponseDTOS = new ArrayList<>();
        SellerTypeOrderConfiguration sellerTypeOrderConfiguration = new SellerTypeOrderConfiguration();
        try {
            sellerTypeOrderConfiguration = sellerService.getSellerTypeOrderConfiguration(order.sellerRef.sellerType);
            order.sellerTypeOrderConfiguration = sellerTypeOrderConfiguration;
        } catch (ApplicationException e) {
            order.sellerTypeOrderConfiguration = new SellerTypeOrderConfiguration();
        }
        if (sellerTypeOrderConfiguration.canAllowHoldingOrders || sellerTypeOrderConfiguration.canAllowEmergencyOrders) {
            List<OrderDTO> groupedOrders = groupOrderBySpecialOptions(order);
            if (!groupedOrders.isEmpty()) {
                for (OrderDTO groupedOrder : groupedOrders) {
                    boolean processOrder = groupedOrder.seller.reviewSubmittedOrders? false: true;
                    OrderResponseDTO orderResponse = processOrderRequest(groupedOrder, processOrder);
                    orderResponse.order.userSellerAccountNumber = order.userSellerAccountNumber;
                    orderResponseDTOS.add(orderResponse);
                }
            }
        } else {
            boolean processOrder = order.seller.reviewSubmittedOrders? false: true;
            OrderResponseDTO orderResponse = processOrderRequest(order, processOrder);
            orderResponseDTOS.add(orderResponse);
        }
        return orderResponseDTOS;
    }

    private OrderResponseDTO processOrderRequest(OrderDTO order, boolean processOrder) {
        OrderResponseDTO orderResponse = new OrderResponseDTO();
        if (processOrder) {
            order = populateOrderItemDocumentNumber(order);
            CommonFinanceRequest financeRequest = createFinanceRequest(order, EBusinessEventType.NEW_ORDER);
            orderResponse.fundingExceptions = validateOrderFunds(financeRequest); //This doesn't NEED to be done because finance validates before they process anyway, but we do a check first before we start creating callNumbers
            if (orderResponse.fundingExceptions.isEmpty()) {
                if (order.sellerTypeOrderConfiguration.needCustomerContract) {
                    BuyerSellerAccount buyerSellerAccount = sellerService.getBuyerSellerAccountBySellerAndBuyerId(order.buyer.getId(), order.sellerRef.id);
                    CustomerContract customerContract = sellerService.getCustomerContractById(buyerSellerAccount.contractId);
                    order.contractNumber = customerContract.contractNum;
                    order.callNumber = sellerService.getAndAdvanceNextCallNumberForCustomerContract(customerContract.getId());
                }

                // add non-catalog purchase item to cis collection
                order = addNonCatalogPurchaseItems(order);

                if (Objects.isNull(order.shippingAddress.line1)) {
                    for (Address address : order.buyer.Address) {
                        if (address.isPrimary || order.buyer.Address.size() == 1) {
                            order.shippingAddress = address;
                            break;
                        }
                    }
                }

                if ((order.callNumber == null || order.callNumber.isBlank()) && order.sellerTypeOrderConfiguration.assignCallNumberToOrders) {
                    SellerCallNumber sellerCallNumber = sellerService.getCallNumber(order.sellerRef.id);
                    if (Objects.nonNull(sellerCallNumber)) {
                        order.callNumber = sellerCallNumber.nextCallNumber;
                        String nextCallNumber = "";
                        if (sellerCallNumber.nextCallNumber == null || sellerCallNumber.nextCallNumber.equals(order.seller.endingCallNumber)) {
                            nextCallNumber = order.seller.startingCallNumber;
                        } else {
                            nextCallNumber = String.format("%08d", Integer.parseInt(sellerCallNumber.nextCallNumber.substring(0)) + 1);
                        }
                        sellerCallNumber.nextCallNumber = nextCallNumber;
                        sellerService.updateCallNumber(sellerCallNumber);
                    }
                }

                orderResponse.order = microservice.addOrder(true, order);
                List<String> errorMessages = completeOrder(orderResponse.order, financeRequest);
                if (Objects.nonNull(errorMessages) && !errorMessages.isEmpty()) {
                    orderResponse.fundingExceptions = errorMessages;
                } else if (Objects.nonNull(order.isNonSubmitOrder) && !order.isNonSubmitOrder) {
                    try {
                        orderResponse.communicationResponse = communicationsSubmitRequestService.submitPurchaseOrderRequest(order);
                    } catch (ApplicationException exception) {
                        orderResponse.exceptions.add("Order Submission Failed");
                    }
                }
            }
        }
        else {
            List<String> cartItemIds = new ArrayList<>();
            for (OrderItem orderItem: order.orderItems) {
                orderItem.orderReviewStatus = OrderReviewStatus.PENDING.displayText;
                cartItemIds.add(orderItem.cartItemId);
            }
            orderResponse.order = microservice.addOrder(false, order);
            cartService.removeItemsInCart(cartItemIds);
        }
        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if (buyer.Address.size() == 0) {
            order.shippingAddress.isPrimary = true;
            buyerService.saveBuyersShippingAddress(order.shippingAddress);
        }
        return orderResponse;
    }

    private List<String> completeOrder(OrderDTO order, CommonFinanceRequest financeRequest) {
        List<String> errorMessages = new ArrayList<>();
        synchronized (this) {
            try {
                errorMessages = validateAndUpdateOrderFunds(order, financeRequest);
                if (!errorMessages.isEmpty()) {
                    microservice.deleteOrder(order);
                } else {
                    List<OrderItem> orderItemList = order.orderItems;
                    if (!order.seller.reviewSubmittedOrders) {
                        List<String> cartItemIds = orderItemList.stream().map(orderItem -> orderItem.cartItemId).collect(Collectors.toList());
                        cartService.removeItemsInCart(cartItemIds);
                    }
                    // create DueIns
                    createDueIns(order, orderItemList);
                    sellerService.acceptOrder(order);
                }
            } catch (ApplicationException exception) {
                microservice.deleteOrder(order);
            }
        }
        return errorMessages;
    }

    public void createInternalReferenceConfig(BuyerDTO buyerDTO) {
        microservice.createInternalReferenceConfig(buyerDTO);
    }

    private List<String> validateOrderFunds(CommonFinanceRequest financeRequest) {
        return financeProcessingValidator.validateRequest(financeRequest);
    }

    private List<String> validateAndUpdateOrderFunds(OrderDTO order, CommonFinanceRequest financeRequest) {
        List<String> errorMessages = new ArrayList<>();
        financeRequest.requestGroups.get(0).orderInformationRef = order.orderItems.get(0).orderInformationRef;
        try {
            CommonFinanceResponse financeResponse = financeProcessingService.processFinanceRequest(financeRequest);
            if (financeResponse.responseGroups.isEmpty()) {
                errorMessages.add("There was an error with the funding and your order could not be completed at this time");
                logger.error("There was an error with the funding and your order could not be completed at this time");
            }
        } catch (FinanceUpdateException fue) {
            errorMessages.add(fue.getMessage());
            logger.error("The funds for the order could not be updated");
        } catch (ClientErrorException clientErrorException) {
            errorMessages.add("The funds for this order could not be updated: " + getExceptionText(clientErrorException));
            logger.error("The funds for the order could not be updated", clientErrorException);
        } catch (ApplicationException ae) {
            errorMessages.add("There was an error with the funding and your order could not be completed at this time");
            logger.error("There was an error with the funding and your order could not be completed at this time", ae);
        }
        return errorMessages;
    }

    private List<DueIn> createDueIns(OrderDTO order, List<OrderItem> orderItemList) {
        List<DueIn> dueIns = new ArrayList<>();
        for (OrderItem orderItem : orderItemList) {
            List<DueOutRef> linkedDueOutRefs = new ArrayList<>();
            ProductAvailableQuantity productAvailableQuantity = inventoryService.getProductAvailableQuantityForResale(currentUserBT.getCurrentNodeId(), orderItem.catalogPurchase.catalog.itemRef.enterpriseProductIdentifier);
            // update dueoutRefs in duein

            {
                DueIn dueIn = new DueIn(orderItem.catalogPurchase.catalog,
                        orderItem.documentNumber,
                        orderItem.requestedQuantity,
                        orderItem.price,
                        orderItem.fundingNodeRef,
                        orderItem.getId(),
                        orderItem.orderLineNumber,
                        orderItem.orderInformationRef,
                        order.buyerRef,
                        order.sellerRef,
                        orderItem.replenishmentRecords.isEmpty() ? null : orderItem.replenishmentRecords.get(0),
                        orderItem.priorityCodeRef,
                        productAvailableQuantity.onHandQuantity);

                dueIns.add(dueIn);

            }
        }
        List<DueIn> newDueIns = dueInService.addDueIns(dueIns);

        //update dueinRef inside dueout.
        for (DueIn duein : newDueIns) {
            if (duein.replenishmentRecord != null) {
                if (duein.replenishmentRecord.dueOutRefs != null && duein.replenishmentRecord.dueOutRefs.size() > 0) {
                    for (DueOutRef dueOutRef : duein.replenishmentRecord.dueOutRefs) {
                        dueOutService.updateDueInRefByDueOutId(dueOutRef.getId(), duein);
                    }
                }
            }
        }
        return newDueIns;
    }


    private CommonFinanceRequest createFinanceRequest(OrderDTO order, EBusinessEventType eventType) {
        //Building the finance request
        CommonFinanceRequest financeRequest = new CommonFinanceRequest();
        Buyer buyer = buyerService.getBuyerByBuyerId(order.buyerRef.id);
        financeRequest.eventType = eventType;
        financeRequest.sourceType = order.sellerRef.sellerType;
        financeRequest.requestingOrg = buyer.nodeRef;
        financeRequest.requestGroups = new ArrayList<>();

        RequestGroup requestGroup = new RequestGroup();
        requestGroup.fundingNodeRef = order.fundingNodeRef;
        requestGroup.orderInformationRef = new OrderInformationRef();
        requestGroup.buyerRef = buyer.getRef();
        requestGroup.currentNodeRef = buyer.nodeRef;
        requestGroup.purchaseCardRef = order.purchaseCardRef;
        requestGroup.items = new ArrayList<>();
        for (OrderItem orderItem : order.orderItems) {
            FinanceItem financeItem = new FinanceItem();
            financeItem.documentNumber = orderItem.documentNumber;
            financeItem.quantity = orderItem.requestedQuantity;
            financeItem.amount = orderItem.catalogPurchase.catalog.price;
            financeItem.catalog = orderItem.catalogPurchase.catalog;
            financeItem.commodityCodeRef = orderItem.catalogPurchase.catalog.commodityCodeRef;
            financeItem.itemRef = orderItem.catalogPurchase.catalog.itemRef;
            financeItem.catalog.sellerRef = order.sellerRef;
            financeItem.lineNumber = orderItem.orderLineNumber;
            financeItem.fiscalYear = order.fundingNodeRef.fiscalYear;
            financeItem.isStocked = false;
            if (!StringUtil.isEmptyOrNull(orderItem.catalogPurchase.catalog.itemRef.enterpriseProductIdentifier)) {
                String stockedStatus = inventoryService.getItemStockType(order.buyerRef.currentNodeRef.nodeIdentifier, orderItem.catalogPurchase.catalog.itemRef.enterpriseProductIdentifier);
                financeItem.isStocked = stockedStatus.equals("Stocked");
            }
            financeItem.isReimbursable = !orderItem.isFreeBuyItem;
            requestGroup.items.add(financeItem);
        }
        financeRequest.requestGroups.add(requestGroup);

        // Create a RequestGroup for the shipping and transportation cost
        if ( Objects.nonNull(order.shippingHandling) && order.shippingHandling.greaterThanZero()) {
            financeRequest.requestGroups.add(createShippingRequestGroup(order));
        }

        return financeRequest;
    }

    private RequestGroup createShippingRequestGroup(OrderDTO order) {
        RequestGroup requestGroup = new RequestGroup();
        requestGroup.items = new ArrayList<>();
        FinanceItem financeItem = new FinanceItem();
        financeItem.documentNumber = order.buyerRef.currentNodeRef.nodeIdentifier + getInternalReferenceId(order.buyerRef.managedByNodeRef.nodeIdentifier);
        financeItem.quantity = 1;
        financeItem.lineNumber = order.orderItems.size() + 1;
        financeItem.commodityCodeRef = order.shippingCommodityCodeRef;
        financeItem.amount = order.shippingHandling;
        financeItem.fiscalYear = order.shippingFundingNodeRef.fiscalYear;
        requestGroup.fundingNodeRef = order.shippingFundingNodeRef;
        requestGroup.items.add(financeItem);
        return requestGroup;
    }

    private OrderDTO populateOrderItemDocumentNumber(OrderDTO order) {
        if (!Objects.isNull(order) && !Objects.isNull(order.orderItems) && !order.orderItems.isEmpty()) {
            for (OrderItem orderItem : order.orderItems) {
                orderItem.documentNumber = order.buyerRef.currentNodeRef.nodeIdentifier + getInternalReferenceId(order.buyerRef.managedByNodeRef.nodeIdentifier);
                if (order.orderIdentifier == null) {
                    order.orderIdentifier = orderItem.documentNumber;
                }
            }
        }
        return order;
    }

    private OrderDTO addNonCatalogPurchaseItems(OrderDTO order) {
        List<OrderItem> orderItems = order.orderItems;
        for (OrderItem orderItem : orderItems) {
            if (Objects.isNull(orderItem.catalogPurchase.catalog.getId())) {
                orderItem.catalogPurchase.catalog = catalogService.saveCatalogRecord(orderItem.catalogPurchase.catalog);
            }
        }
        return order;
    }

    private List<OrderDTO> groupOrderBySpecialOptions(OrderDTO order) {
        List<OrderDTO> groupedOrders = new ArrayList<>();
        if (Objects.nonNull(order.orderItems) && !order.orderItems.isEmpty()) {
            if (order.sellerTypeOrderConfiguration.canAllowHoldingOrders) {
                List<OrderItem> holdingOrderItems = order.orderItems.stream().filter(orderItem -> Objects.nonNull(orderItem.isHoldingOrder) && orderItem.isHoldingOrder).collect(Collectors.toList());
                if (Objects.nonNull(holdingOrderItems) && !holdingOrderItems.isEmpty()) {
                    order.orderItems.removeAll(holdingOrderItems);
                    for (OrderItem orderItem : holdingOrderItems) {
                        OrderDTO holdingOrder = this.createGroupedOrder(order, Arrays.asList(orderItem));
                        groupedOrders.add(holdingOrder);
                    }
                }
            }
            if (order.sellerTypeOrderConfiguration.canAllowEmergencyOrders) {
                List<OrderItem> emergencyOrderItems = order.orderItems.stream().filter(orderItem -> Objects.nonNull(orderItem.isEmergencyOrder) && orderItem.isEmergencyOrder).collect(Collectors.toList());
                if (Objects.nonNull(emergencyOrderItems) && !emergencyOrderItems.isEmpty()) {
                    order.orderItems.removeAll(emergencyOrderItems);
                    OrderDTO emergencyOrder = this.createGroupedOrder(order, emergencyOrderItems);
                    // marking order as non-submit, may need to revisit to set the value on the UI
                    emergencyOrder.isNonSubmitOrder = false;
                    groupedOrders.add(emergencyOrder);
                }
            }

            if (!order.orderItems.isEmpty()) {
                groupedOrders.add(order);
            }
        }

        return groupedOrders;
    }

    private OrderDTO createGroupedOrder(OrderDTO order, List<OrderItem> orderItems) {
        OrderDTO groupedOrder = new OrderDTO();
        groupedOrder.buyer = order.buyer;
        groupedOrder.buyerRef = order.buyerRef;
        groupedOrder.seller = order.seller;
        groupedOrder.sellerRef = order.sellerRef;
        groupedOrder.isNonSubmitOrder = order.isNonSubmitOrder;
        groupedOrder.isEmergencyOrder = orderItems.get(0).isEmergencyOrder;
        groupedOrder.isHoldingOrder = orderItems.get(0).isHoldingOrder;
        groupedOrder.isCreditOrder = false;
        groupedOrder.fundingNodeRef = order.fundingNodeRef;
        groupedOrder.orderItems = orderItems;
        groupedOrder.sellerTypeOrderConfiguration = order.sellerTypeOrderConfiguration;
        groupedOrder.transactionPurposeCodeRef = order.transactionPurposeCodeRef;
        groupedOrder.shippingAddress = order.shippingAddress;
        groupedOrder.shippingHandling = order.shippingHandling;
        groupedOrder.notes = order.notes;
        return groupedOrder;
    }

    public List<OrderItem> getOrders() {
        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if (Objects.isNull(buyer)) {
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }
        return microservice.getOrdersByBuyerId(buyer.getId());
    }

    // Used by the Distribution Reviewer
    public List<BuyerOrderItems> getOrdersForReviewBySite() {
        List<BuyerOrderItems> buyerGroups = microservice.getOrdersForReviewBySite();
        List<String> sellerIds = new ArrayList<>();
        if(Objects.nonNull(buyerGroups) && !buyerGroups.isEmpty()){
            for (BuyerOrderItems buyerGroup: buyerGroups) {
                List<BuyerSellerAccountDTO> authorizedSuppliers = this.getBuyerSellerAccountListByOrgId(buyerGroup.items.get(0).catalogPurchase.catalog.buyerRef.currentNodeRef.id);
                if (Objects.nonNull(authorizedSuppliers) && !authorizedSuppliers.isEmpty()) {
                    sellerIds = authorizedSuppliers.stream().map(supplier -> supplier.sellerId).distinct().collect(Collectors.toList());
                }
                for (OrderItem orderItem: buyerGroup.items) {
                    List<SellerRef> sellers = new ArrayList<>();
                    List<Catalog> catalogItems = catalogService.getCatalogListByUniqueKey(orderItem.catalogPurchase.catalog.catalogItemIdentifier, orderItem.catalogPurchase.catalog.itemPackaging.packageUnit,
                          buyerGroup.buyerId, sellerIds);
                    if (Objects.nonNull(catalogItems) && !catalogItems.isEmpty()){
                        sellers = catalogItems.stream().map(item -> item.sellerRef).distinct().collect(Collectors.toList());
                    }
                    orderItem.sellers = sellers;
                }
            }
        }
        return buyerGroups;
    }

    public List<OrderItem> getOrdersByItemIds(List<String> itemIds) {
        return microservice.getOrdersByItemIds(itemIds);
    }

    public List<OrderItem> getOrderItemsByAssemblageAndItemId(String assemblageId, String itemId) {
        return microservice.getOrderItemsByAssemblageAndItemId(assemblageId, itemId);
    }

    public List<OrderItem> getOrdersByUserId(String userId) {
        return microservice.getOrdersByUserId(userId);
    }


    public OrderItem receiveOrderLineItem(String orderId, String orderLineItemId, Integer quantity, Boolean IsIssuedtoInventory) {
        return microservice.receiveOrderLineItem(orderId, orderLineItemId, quantity, IsIssuedtoInventory);
    }


    public OrderItem changeQuantityOrderLineItem(String orderId, String orderLineItemId, Integer quantity) {

        OrderItem orderItem = microservice.changeQuantityOrderLineItem(orderId, orderLineItemId, quantity);
        dueInService.changeDueInQuantityByOrderLineId(orderLineItemId, quantity);
        return orderItem;
    }

    public OrderDTO cancelOrder(String id) {
        // TODO: revisit when we have something for transaction management, for now the original order copy will be used
        // in case the fund validation fails
        OrderDTO originalOrder = microservice.getOrderById(id);
        OrderDTO updatedOrder = microservice.cancelOrder(id);
        CommonFinanceRequest financeRequest = createFinanceRequest(updatedOrder, EBusinessEventType.ORDER_ITEMS_UPDATE);
        List<String> exceptions = validateAndUpdateOrderFunds(updatedOrder, financeRequest);
        if (!Objects.isNull(exceptions) && !exceptions.isEmpty()) {
            // if validation fails, update with the original order
            OrderDTO order = microservice.updateOrder(originalOrder);
            order.exceptions.addAll(exceptions);
            return order;
        }
        dueInService.deleteDueInByOrderId(id);
        return updatedOrder;
    }

    public OrderItem updateItemRemainingQuantity(String orderId, String orderLineItemId, Integer quantity) {
        OrderItem originalOrderItem = microservice.getOrderItemById(orderLineItemId);
        OrderItem updatedOrderItem = microservice.updateItemRemainingQuantity(orderId, orderLineItemId, quantity);
        OrderDTO order = microservice.getOrderById(orderId);
        CommonFinanceRequest financeRequest = createFinanceRequest(order, EBusinessEventType.ORDER_ITEMS_UPDATE);
        List<String> exceptions = validateAndUpdateOrderFunds(order, financeRequest);
        if (!Objects.isNull(exceptions) && !exceptions.isEmpty()) {
            // if validation fails, update with the original order item
            OrderItem orderItem = microservice.updateOrderItem(originalOrderItem);
            orderItem.exceptions.addAll(exceptions);
            return orderItem;
        }
        dueInService.updateDueInQuantityByOrderLineId(orderLineItemId, quantity);
        return updatedOrderItem;
    }

    public OrderItem updateItemPrice(String orderId, String orderLineItemId, MonetaryValue price) {
        OrderItem originalOrderItem = microservice.getOrderItemById(orderLineItemId);
        microservice.updateItemPrice(orderId, orderLineItemId, price);
        OrderDTO order = microservice.getOrderById(orderId);
        CommonFinanceRequest financeRequest = createFinanceRequest(order, EBusinessEventType.ORDER_ITEMS_UPDATE);
        List<String> exceptions = validateAndUpdateOrderFunds(order, financeRequest);
        if (!Objects.isNull(exceptions) && !exceptions.isEmpty()) {
            // if validation fails, update with the original order item
            OrderItem orderItem = microservice.updateOrderItem(originalOrderItem);
            orderItem.exceptions.addAll(exceptions);
            return orderItem;
        }
        dueInService.updateDueInPriceByOrderLineId(orderLineItemId, price);
        return microservice.getOrderItemById(orderLineItemId);
    }

    public OrderItem sendItemFollowUp(String orderId, String orderLineItemId) {
        return microservice.sendItemFollowUp(orderId, orderLineItemId);
    }

    public String getInternalReferenceId(String nodeID) {
        return microservice.getInternalReferenceId(nodeID);
    }

    public ExternalOrderConfiguration getExternalOrderConfiguration(String id) {
        return microservice.getExternalOrderConfiguration(id);
    }

    public ExternalOrderConfiguration getExternalOrderConfigurationByOrganizationLabel(String label) {
        return microservice.getExternalOrderConfigurationByOrganizationLabel(label);
    }

    public ExternalVendor getExternalVendorByOrganizationLabelAndVendorCode(String label, String vendorCode) {
        return microservice.getExternalVendorByOrganizationLabelAndVendorCode(label, vendorCode);
    }

    private String getExceptionText(ClientErrorException clientErrorException) {
        String msg = "";
        MultivaluedMap<String, Object> metaMap = clientErrorException.getResponse().getMetadata();
        if (metaMap != null && metaMap.containsKey(ExceptionConstants.CUSTOM_ERROR_MSG_HEADER_KEY)) {
            String customErrMsg = metaMap.get(ExceptionConstants.CUSTOM_ERROR_MSG_HEADER_KEY).toString();
            msg = removeResponseHeaderBrackets(customErrMsg);
            msg = addDelimiter(msg);
        }
        return msg;
    }

    private String addDelimiter(String msg) {
        return ExceptionConstants.ERROR_MSG_DELIMITER + msg + ExceptionConstants.ERROR_MSG_DELIMITER;
    }

    private String removeResponseHeaderBrackets(String headerValue) {
        String filteredValue = headerValue.replace("[", "");
        filteredValue = filteredValue.replace("]", "");
        return filteredValue;
    }

    public OrderItem getOrderItemById(String orderItemId) {
        return microservice.getOrderItemById(orderItemId);
    }

    public OrderInformation getOrderInformationById(String orderId) {
        OrderInformation orderInformation = microservice.getOrderInformationById(orderId);
        orderInformation.sellerTypeOrderConfiguration = sellerService.getSellerTypeOrderConfiguration(orderInformation.seller.sellerTypeRef.sellerType);
        return orderInformation;
    }

    public OrderDTO getOrderById(String orderId) {
        return microservice.getOrderById(orderId);
    }

    public OrderDTO addNoteToOrder(String orderId, Note note) {
        return microservice.addNoteToOrder(orderId, note);
    }

    public OrderDTO removeNoteFromOrder(String orderId, String noteId) {
        return microservice.removeNoteFromOrder(orderId, noteId);
    }

    public OrderInformation updateOrderInformation(OrderInformation orderInformation) {
        return microservice.updateOrderInformation(orderInformation);
    }

    public OrderItem updateOrderItemDetails(OrderItem orderItem) {
        return microservice.updateOrderItemDetails(orderItem);
    }

    public SearchResult<OrderItem> getOrderItemSearchResults(SearchInput searchInput) {
        if (microservice.getOrderItemSearchEngine().equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported at this time.");
        }

        String buyerId = buyerService.getBuyerForNodeId(getCurrentUser().profile.currentNodeRef.id).getId();
        setBuyerIdSearchCriteria(buyerId, searchInput);

        return microservice.getOrderItemSearchResults(searchInput);
    }

    public List<OrderInformation> getDlaGsaOrderList() {
        return microservice.getDlaGsaOrderList();
    }

    public void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate) {
        microservice.processDataReferenceUpdate(dataReferenceUpdate);
    }

    public void ingestOrderItemStatus(PurchasingStatusWrapper purchasingStatusWrapper) {
        List<PurchasingStatus> purchasingStatusList;
        purchasingStatusList = microservice.ingestOrderItemStatus(purchasingStatusWrapper);
        purchaseStatusCodeProcessor(purchasingStatusList);
    }

    public void purchaseStatusCodeProcessor(List<PurchasingStatus> purchasingStatusList ) {
        purchasingStatusList.forEach(orderItemStatus -> {
            OrderItem orderItem = microservice.getOrderItemByDocumentNumber(orderItemStatus.purchasingStatusDTO.documentNumber);
            int quantity = orderItemStatus.purchasingStatusDTO.quantity;
            if (Objects.nonNull(orderItem)) {
                switch (orderItemStatus.purchasingStatusDTO.statusCode) {
                    case "B7":
                        updateItemPrice(orderItem.orderInformationRef.getId(), orderItem.getId(),
                                orderItemStatus.purchasingStatusDTO.packPriceAmount);
                        break;
                    case "BA": // intentional fall-through, BA/BB have same behavior
                    case "BB":
                         orderItem.estimatedReleaseDate = orderItemStatus.purchasingStatusDTO.estimatedShipDate;
                         updateOrderItemDetails(orderItem);
                         break;
                    case "BD":
                        break;
                    case "BJ":
                        updateItemRemainingQuantity(orderItem.orderInformationRef.getId(), orderItem.getId(), quantity);
                        break;
                    case "CA":
                        int newQuantity = orderItem.remainingQuantity - quantity;
                        updateItemRemainingQuantity(orderItem.orderInformationRef.id, orderItem.getId(), newQuantity);
                        break;
                    case "CE":
                        updateItemRemainingQuantity(orderItem.orderInformationRef.id, orderItem.getId(),0);
                        break;
                    case "CJ":
                        updateItemRemainingQuantity(orderItem.orderInformationRef.id, orderItem.getId(),0);
                        break;
                    case "CS":
                        newQuantity = orderItem.remainingQuantity - quantity;
                        updateItemRemainingQuantity(orderItem.orderInformationRef.id, orderItem.getId(), newQuantity);
                        break;
                    case "SS":
                        orderItem.shipDate = orderItemStatus.purchasingStatusDTO.estimatedShipDate;
                        updateOrderItemDetails(orderItem);
                        break;
                    default:
                        logger.info("Not a valid Purchasing Status code to process");
                }
            }
        });
    }

    public void updateLinkedDueOuts(List<DueOutRef> dueOutRefs) {
        for (DueOutRef dueOutRef : dueOutRefs) {
            dueOutService.updateDueoutQuantity(dueOutRef.getId(), dueOutRef.dueOutQuantity);
        }
    }

    public List<CommodityCodeRef> getCommodityCodeRefsByTransportation() {
        return financeAdminService.getCommodityCodeRefsByTransportation(null);
    }

    public List<FundingNodeRef> getFundsByCommodity(CommodityCodeRef commodityCodeRef) {
        ArrayList<FundingNodeRef> fundingSelections = new ArrayList<FundingNodeRef>();
        try {
            //Get the list of Authorized Nodes
            List<AuthorizedNode> authorizedNodes = financeAdminService.getAuthorizedNodes(null, null, commodityCodeRef);
            //Only use the fundingNodeRef -- there's some much more data there we don't need and causes the PT to fail
            for (AuthorizedNode authorizedNode : authorizedNodes) {
               fundingSelections.add(authorizedNode.fundingNodeRef);
            }
        } catch (ApplicationException e) {
            logger.info("No funds available");
        }
        return fundingSelections;
    }

    // Used by the Distribution Reviewer
    public List<BuyerOrderItems> rejectOrderItemRemainingQuantity(String orderItemId){
        microservice.rejectOrderItemRemainingQuantity(orderItemId, OrderReviewStatus.REJECTED.displayText);
        return getOrdersForReviewBySite();

    }

    public OrderItem cancelPendingOrderItem(String orderItemId){
        return microservice.rejectOrderItemRemainingQuantity(orderItemId, OrderReviewStatus.CANCELLED.displayText);
    }

    public List<BuyerSellerAccountDTO> getBuyerSellerAccountListByOrgId(){
        return getBuyerSellerAccountListByOrgId(currentUserBT.getCurrentNodeId());
    }

    public List<BuyerSellerAccountDTO> getBuyerSellerAccountListByOrgId(String orgId){
        List<BuyerSellerAccountDTO> buyerSellerAccountDTOList = buyerService.getBuyerSellerAccountListForOrganization(orgId);
        List<BuyerSellerAccountDTO> filteredList = new ArrayList<>();
        if (Objects.nonNull(buyerSellerAccountDTOList) && !buyerSellerAccountDTOList.isEmpty()) {
            filteredList = buyerSellerAccountDTOList.stream().filter(buyerSellerAccountDTO -> Objects.nonNull(buyerSellerAccountDTO) && buyerSellerAccountDTO.reviewSubmittedOrders).collect(Collectors.toList());
        }
        return filteredList;
    }

    // Used by the Distribution Reviewer
    public List<BuyerOrderItems> approveOrder(BuyerOrderItems buyerGroup){
        List<OrderItem> orderItemsToSubmit = new ArrayList<>();
        Map<String, List<String>> buyerException = new HashMap<>();
        if (Objects.nonNull(buyerGroup.items) && !buyerGroup.items.isEmpty()) {
            for (OrderItem orderItem: buyerGroup.items) {
                int newQuantity = orderItem.requestedQuantity;
                Catalog catalog = orderItem.catalogPurchase.catalog;
                orderItem = microservice.getOrderItemById(orderItem.getId());
                if (orderItem.orderReviewStatus.equals(OrderReviewStatus.PENDING.displayText)) {
                    int originalQuantity = orderItem.requestedQuantity;
                    if(!catalog.sellerRef.id.equals(orderItem.catalogPurchase.catalog.sellerRef.id)){
                        OrderItemHistory orderItemHistory = new OrderItemHistory();
                        orderItemHistory.id = stringUtil.getUUID();
                        orderItemHistory.quantity = orderItem.requestedQuantity;// The quantity of the orderitem;
                        orderItemHistory.userRef =  getCurrentUser().getRef();
                        orderItemHistory.createdDate = new Date();
                        orderItemHistory.reason = "Redirected from " + orderItem.catalogPurchase.catalog.sellerRef.sellerName + " to " + catalog.sellerRef.sellerName;
                        orderItem.histories.add(orderItemHistory);

                        Catalog newCatalog = catalogService.getCatalogByUniqueKey(orderItem.catalogPurchase.catalog.catalogItemIdentifier, catalog.sellerRef.id,
                                orderItem.catalogPurchase.catalog.itemPackaging.packageUnit, orderItem.catalogPurchase.catalog.buyerRef.id);
                        orderItem.catalogPurchase.catalog = newCatalog;
                    }
                    if (newQuantity > originalQuantity) {
                        orderItem.increasedQuantity = newQuantity - originalQuantity;
                        orderItem.remainingQuantity = orderItem.remainingQuantity + orderItem.increasedQuantity;
                    }
                    if (newQuantity < originalQuantity){
                        orderItem.cancelledQuantity = originalQuantity - newQuantity;
                        orderItem.remainingQuantity = orderItem.remainingQuantity - orderItem.cancelledQuantity;
                    }
                    orderItemsToSubmit.add(orderItem);
                }
            }
            List<OrderDTO> groupedOrders = groupedReviewedOrderBySeller(orderItemsToSubmit);
            if (Objects.nonNull(groupedOrders) && !groupedOrders.isEmpty()) {
                for (OrderDTO groupedOrder : groupedOrders) {
                    groupedOrder.sellerTypeOrderConfiguration =  sellerService.getSellerTypeOrderConfiguration(groupedOrder.sellerRef.sellerType);
                    List<Address> shipping = buyerService.getBuyerById(buyerGroup.buyerId).Address;
                    if (!shipping.isEmpty()) {
                        groupedOrder.shippingAddress = shipping.get(0);
                    }
                    OrderResponseDTO orderResponse = processOrderRequest(groupedOrder, true);
                    if (Objects.nonNull(orderResponse) && Objects.nonNull(orderResponse.fundingExceptions) && !orderResponse.fundingExceptions.isEmpty()) {
                        buyerException.put(groupedOrder.buyerRef.id, orderResponse.fundingExceptions);
                    }
                }
            }
        }
        List<BuyerOrderItems> buyerOrderItems = microservice.getOrdersForReviewBySite();
        for (BuyerOrderItems buyerOrderItem: buyerOrderItems) {
            if (buyerException.containsKey(buyerOrderItem.buyerId)) {
                buyerOrderItem.exceptions.addAll(buyerException.get(buyerOrderItem.buyerId));
            }
        }

        return buyerOrderItems;
    }

    private List<OrderDTO> groupedReviewedOrderBySeller(List<OrderItem> orderItemsToSubmit){
        List<String> sellerIds = orderItemsToSubmit.stream().map(item -> item.catalogPurchase.catalog.sellerRef.id).distinct().collect(Collectors.toList());
        List<OrderDTO> groupedOrders = new ArrayList<>();
        for (String sellerId : sellerIds) {
            OrderDTO groupedOrder = new OrderDTO();
            List<OrderItem> orderItems = new ArrayList<>();
            Integer lineNumber = 0;
            for (OrderItem orderItem: orderItemsToSubmit) {
                if (orderItem.catalogPurchase.catalog.sellerRef.id.equals(sellerId)) {
                    orderItem.orderLineNumber = ++lineNumber;
                    orderItem.orderReviewStatus = OrderReviewStatus.SUBMITTED.displayText;
                    orderItems.add(orderItem);
                }
            }
            groupedOrder.orderItems = orderItems;
            Buyer buyer = buyerService.getBuyerByBuyerId(groupedOrder.orderItems.get(0).catalogPurchase.catalog.buyerRef.id);
            groupedOrder.buyer = buyer;
            groupedOrder.buyerRef = buyer.getRef();
            for (Address address : buyer.Address) {
                if (address.isPrimary) {
                    groupedOrder.shippingAddress = address;
                    break;
                }
            }

            Seller seller = sellerService.getSellerById(groupedOrder.orderItems.get(0).catalogPurchase.catalog.sellerRef.id);
            groupedOrder.seller = seller;
            groupedOrder.sellerRef = seller.getRef();
            groupedOrder.sellerTypeOrderConfiguration = seller.sellerTypeOrderConfiguration;
            // TODO: check if we need this for va rrc
            groupedOrder.isNonSubmitOrder = groupedOrder.orderItems.get(0).isNonSubmitOrder;
            //groupedOrder.isEmergencyOrder = groupedOrder.orderItems.get(0).isEmergencyOrder;
            //groupedOrder.isHoldingOrder = groupedOrder.orderItems.get(0).isHoldingOrder;
            groupedOrder.isCreditOrder = false;
            groupedOrder.fundingNodeRef = groupedOrder.orderItems.get(0).fundingNodeRef;
            groupedOrder.transactionPurposeCodeRef = cartService.getTransactionPurposeCode();
            groupedOrder = createGroupedOrder(groupedOrder, orderItems);
            groupedOrders.add(groupedOrder);
        }
        return groupedOrders;
    }

    public Integer deleteOrderItemsForAssemblages(List<String> assemblageIds) {
        return microservice.deleteOrderItemsForAssemblages(assemblageIds);
    }

    public List<OrderItem> getOrderItemsByAssemblageId(String assemblageId) {
        return microservice.getOrderItemsByAssemblageId(assemblageId);
    }

    public void removeOrderItemRef(OrderItemRef orderItemRef) {
        microservice.removeOrderItemRef(orderItemRef);
    }

    public void deleteOrderInformationById(String orderInformationId) {
        microservice.deleteOrderInformationById(orderInformationId);
    }

    public boolean updateReceiptQuantity(List<OrderItem> orderItems) {
        return microservice.updateReceiptQuantity(orderItems);
    }
}
