package logicole.gateway.services.delivery;

import logicole.apis.delivery.IDeliveryMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class DeliveryMicroserviceClient extends MicroserviceClient<IDeliveryMicroserviceApi> {
    public DeliveryMicroserviceClient(){
        super(IDeliveryMicroserviceApi.class, "logicole-delivery");
    }

    @Produces
    public IDeliveryMicroserviceApi getIDeliveryMicroserviceApi() {
        return createClient();
    }

}
