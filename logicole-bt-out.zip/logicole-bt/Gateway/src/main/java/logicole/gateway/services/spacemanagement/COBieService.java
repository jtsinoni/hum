package logicole.gateway.services.spacemanagement;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import logicole.apis.space.ICOBieMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.asset.businesscontact.BusinessContact;
import logicole.common.datamodels.asset.businesscontact.BusinessContactRef;
import logicole.common.datamodels.asset.classification.AssemblyCategory;
import logicole.common.datamodels.asset.classification.FacilitySubsystem;
import logicole.common.datamodels.asset.classification.FacilitySystem;
import logicole.common.datamodels.asset.classification.Nomenclature;
import logicole.common.datamodels.filemanager.CommonUploadedFile;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.space.Space;
import logicole.common.datamodels.space.cobie.COBieExportRequest;
import logicole.common.datamodels.space.cobie.COBieExportStatus;
import logicole.common.datamodels.space.cobie.COBieImportRequest;
import logicole.common.datamodels.space.cobie.COBieImportStatus;
import logicole.common.datamodels.space.cobie.export.AssetCOBieExportData;
import logicole.common.datamodels.space.cobie.export.FacilityCOBieExportData;
import logicole.common.datamodels.space.cobie.export.FloorCOBieExportData;
import logicole.common.datamodels.space.cobie.export.SpaceCOBieExportData;
import logicole.common.datamodels.space.cobie.export.ZoneCOBieExportData;
import logicole.common.datamodels.space.cobie.staging.*;
import logicole.common.datamodels.space.cobie.COBieProcessDataRequest;
import logicole.common.datamodels.space.cobie.staging.COBieAttributeImport;
import logicole.common.datamodels.space.cobie.staging.COBieComponentImport;
import logicole.common.datamodels.space.cobie.staging.COBieContactImport;
import logicole.common.datamodels.space.cobie.staging.COBieContactImportSummary;
import logicole.common.datamodels.space.cobie.staging.COBieEquipmentImport;
import logicole.common.datamodels.space.cobie.staging.COBieFacilityImport;
import logicole.common.datamodels.space.cobie.staging.COBieFileExport;
import logicole.common.datamodels.space.cobie.staging.COBieFileImport;
import logicole.common.datamodels.space.cobie.staging.COBieFloorImport;
import logicole.common.datamodels.space.cobie.staging.COBieFloorImportSummary;
import logicole.common.datamodels.space.cobie.staging.COBieSpaceImport;
import logicole.common.datamodels.space.cobie.staging.COBieSpaceImportSummary;
import logicole.common.datamodels.space.cobie.staging.COBieTypeImport;
import logicole.common.datamodels.space.cobie.staging.COBieZoneImport;
import logicole.common.datamodels.space.cobie.staging.COBieZoneImportSummary;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.AssetClassificationService;
import logicole.gateway.services.asset.AssetService;
import logicole.gateway.services.asset.BusinessContactService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.spacemanagement.cobie.COBieBackgroundRequestService;
import logicole.gateway.services.user.UserService;

@ApplicationScoped
public class COBieService extends BaseGatewayService<ICOBieMicroserviceApi> {
    public static final String PARAMETER_PAIR_DELIMETER = ",";
    public static final String PARAMETER_VALUE_DELIMETER = ":";
    public static final String COBIE_FILE_IMPORT_ID_PARAM = "cobieFileImportId";
    public static final String FILE_MANAGER_ID_PARAM = "fileManagerId";
    public static final String FACILITY_SHEET_NAME = "Facility";
    public static final String NAME_KEY = "Name";

    public static final String PROCESSING = "Record queued for processing.";
    public static final String DELETING = "Record queued for deletion.";

    @Inject
    private MultiPartFormUtil multiPartFormUtil;
    @Inject
    private JMSContext jmsContext;
    @Inject
    private COBieBackgroundRequestService cobieBackgroundRequestService;
    @Inject
    private FileManagerAdminService fileManagerAdminService;
    @Inject
    private FacilityService facilityService;
    @Inject
    private SpaceManagementService spaceManagementService;
    @Inject
    private UserService userService;
    @Inject
    private AssetService assetService;
    @Inject
    private AssetClassificationService assetClassificationService;
    @Inject
    private BusinessContactService businessContactService;
    
    @Inject
    private OrganizationService organizationService;

    public COBieService() {
        super("COBie");
    }

    public FileManager uploadCOBieFile(MultipartFormDataInput form) throws IOException {
        byte[] content;

        InputPart inputPart = multiPartFormUtil.getInputPart(form, "file");
        String uploadedFileName = multiPartFormUtil.getFileName(inputPart.getHeaders());

        InputStream inputStream = inputPart.getBody(InputStream.class, null);
        content = IOUtils.toByteArray(inputStream);

        if (!contentIsCOBieSpreadsheet(content)) {
            throw new ApplicationException("File is not a valid COBie Import (*.xlsx) File.");
        }

        Integer maxUploadSize = getMaxCOBieImportAttachmentSize();
        if (content.length > maxUploadSize) {
            throw new ApplicationException("File size exceeds max size of " + maxUploadSize + " bytes");
        }

        return fileManagerAdminService.uploadManaged(content, uploadedFileName);
    }

    public Response downloadCOBieFile(String fileId) throws IOException {
        CommonUploadedFile commonUploadedFile = fileManagerAdminService.download(fileId);

        Response.ResponseBuilder response;

        if (commonUploadedFile != null) {
            byte[] bytes = FileUtils.readFileToByteArray(commonUploadedFile.getFile());
            String fileType = Files.probeContentType(commonUploadedFile.getFile().toPath());

            response = Response.ok();
            response.header("Content-Disposition", "attachment; filename=" + commonUploadedFile.getUploadedFilename());
            response.header("Content-Length", bytes.length);
            response.header("Content-Encoding", StandardCharsets.UTF_8);
            response.header("Access-Control-Expose-Headers", "Content-Disposition,Content-Type");
            response.header("Content-Type", fileType);

            if (fileType == null || fileType.isEmpty()) {
                response.type(MediaType.APPLICATION_OCTET_STREAM_TYPE);
            }
            response.entity(bytes);
        } else {
            response = Response.status(Response.Status.NOT_FOUND);
        }

        return response.build();
    }

    public COBieImportStatus importCOBieFile(String facilityId, Attachment importFile) {
        Facility facility = facilityService.getFacilityById(facilityId);
        if (!facilityMatchesSpreadsheetFacility(facility, importFile)) {
            try {
                fileManagerAdminService.removeFile(importFile.fileRef.fileId);
            } catch (IOException ex) {
                logger.error("  Could not delete file manager file: fileId=" + importFile.fileRef.fileId
                        + ", uploadedFileName: " + importFile.fileRef.uploadedFileName);
            }
            throw new ApplicationException("Spreadsheet Facility Number does not match the selected facility.");
        }

        COBieImportRequest cobieImportRequest = new COBieImportRequest();
        cobieImportRequest.siteRef = facility.siteRef;
        cobieImportRequest.facilityRef = facility.getRef();
        cobieImportRequest.managedByNodeRef = facility.managedByNodeRef;
        cobieImportRequest.importFile = importFile;
        COBieImportStatus status = microservice.addCOBieImportRequest(cobieImportRequest);

        Queue queue = jmsContext.createQueue(ProcessDrawingUploadMDB.DRAWING_STAGING_SERVICE_BROKER);
        TextMessage textMessage = jmsContext.createTextMessage("cobieFileImportId:" + status.cobieFileImportId);
        JMSProducer jmsProducer = jmsContext.createProducer();
        jmsProducer.setJMSType(ProcessDrawingUploadMDB.JMS_TYPE_COBIE_IMPORT);

        jmsProducer.send(queue, textMessage);
        return status;
    }

    public COBieExportStatus exportCOBieFile(Boolean exportTemplateOnly, String facilityId) throws IOException {
        Facility facility = facilityService.getFacilityById(facilityId);
        COBieExportRequest cobieExportRequest = new COBieExportRequest();
        cobieExportRequest.siteRef = facility.siteRef;
        cobieExportRequest.facilityRef = facility.getRef();
        cobieExportRequest.managedByNodeRef = facility.managedByNodeRef;
        cobieExportRequest.exportTemplateOnly = exportTemplateOnly;
        cobieExportRequest.tempDirectory = System.getProperty("java.io.tmpdir");
        COBieExportStatus status = microservice.addCOBieExportRequest(cobieExportRequest);

        Queue queue = jmsContext.createQueue(ProcessDrawingUploadMDB.DRAWING_STAGING_SERVICE_BROKER);
        TextMessage textMessage = jmsContext.createTextMessage("cobieFileExportId:" + status.cobieFileExportId);
        JMSProducer jmsProducer = jmsContext.createProducer();
        jmsProducer.setJMSType(ProcessDrawingUploadMDB.JMS_TYPE_COBIE_EXPORT);

        jmsProducer.send(queue, textMessage);
        return status;
    }

    public void processCOBieImportRequest(String cobieFileImportId) {
        cobieBackgroundRequestService.addCOBieImportInformationMessage(cobieFileImportId, "Processing Import Request.");
        cobieBackgroundRequestService.processImportRequest(cobieFileImportId);
        cobieBackgroundRequestService.addCOBieImportInformationMessage(cobieFileImportId, "Import Request Completed.");
    }

    public void processCOBieExportRequest(String cobieFileExportId) {
        COBieFileExport cobieFileExport = microservice.getCOBieFileExportById(cobieFileExportId);
        boolean exportTemplateOnly = cobieFileExport.exportTemplateOnly;
        String facilityId = cobieFileExport.facilityRef.id;
        Facility facility = facilityService.getFacilityById(facilityId);
        UserProfile userProfile = userService.getUserProfileById(cobieFileExport.exportedBy);

        COBieFileExportData exportData = microservice.createNewFileExportDataRecord(cobieFileExportId,
                userProfile.email, cobieFileExport._metadata.createdDate);
        String cobieFileExportDataId = exportData.getId();
        String managedByNodeRefId = facility.managedByNodeRef.id;

        setFacilityData(cobieFileExportId, cobieFileExportDataId, facilityId);
        setSpaceCodeData(cobieFileExportId, cobieFileExportDataId);
        setAssetData(cobieFileExportId, cobieFileExportDataId, facilityId);
        setDepartmentNameList(cobieFileExportId, cobieFileExportDataId, managedByNodeRefId);
        setServiceNameList(cobieFileExportId, cobieFileExportDataId, managedByNodeRefId);
        if (!exportTemplateOnly) {
            setSpaceData(cobieFileExportId, cobieFileExportDataId, facilityId);
            setFloorDataList(cobieFileExportId, cobieFileExportDataId, facilityId);
            setZoneDataList(cobieFileExportId, cobieFileExportDataId, facilityId);

            if (!ListUtil.isEmpty(facility.businessContacts)) {
                List<String> contactIds = new ArrayList<>();
                facility.businessContacts.forEach(businessContact -> contactIds.add(businessContact.contactId));
                setBusinessContactList(cobieFileExportId, cobieFileExportDataId, contactIds);
            }
        }

        cobieBackgroundRequestService.addCOBieExportInformationMessage(cobieFileExportId, "Processing Export Request.");
        cobieBackgroundRequestService.processExportRequest(cobieFileExportDataId);
        cobieBackgroundRequestService.addCOBieExportInformationMessage(cobieFileExportId, "Export Request Completed.");
    }

    protected void setBusinessContactList(String cobieFileExportId, String cobieFileExportDataId,
            List<String> contactIds) {
        cobieBackgroundRequestService.addCOBieExportInformationMessage(cobieFileExportId,
                "getting Business Contacts Data.");
        List<BusinessContact> facilityBusinessContactList = businessContactService
                .getBusinessContactsByContactIds(contactIds);
        microservice.setFacilityBusinessContactList(cobieFileExportDataId, facilityBusinessContactList);
    }

    protected void setZoneDataList(String cobieFileExportId, String cobieFileExportDataId, String facilityId) {
        cobieBackgroundRequestService.addCOBieExportInformationMessage(cobieFileExportId, "getting Zone Data.");
        List<ZoneCOBieExportData> zoneDataList = spaceManagementService.getZoneCOBieExportDataByFacilityId(facilityId);
        microservice.setZoneDataList(cobieFileExportDataId, zoneDataList);
    }

    protected void setFloorDataList(String cobieFileExportId, String cobieFileExportDataId, String facilityId) {
        cobieBackgroundRequestService.addCOBieExportInformationMessage(cobieFileExportId, "getting Floor Data.");
        List<FloorCOBieExportData> floorDataList = spaceManagementService
                .getFloorCOBieExportDataByFacilityId(facilityId);
        microservice.setFloorDataList(cobieFileExportDataId, floorDataList);
    }

    protected void setServiceNameList(String cobieFileExportId, String cobieFileExportDataId,
            String managedByNodeRefId) {
        cobieBackgroundRequestService.addCOBieExportInformationMessage(cobieFileExportId, "getting Service List.");
        List<String> serviceNameList = spaceManagementService.getActiveServiceBySite(managedByNodeRefId);
        microservice.setServiceNameList(cobieFileExportDataId, serviceNameList);
    }

    protected void setDepartmentNameList(String cobieFileExportId, String cobieFileExportDataId,
            String managedByNodeRefId) {
        cobieBackgroundRequestService.addCOBieExportInformationMessage(cobieFileExportId, "getting Department List.");
        List<String> departmentNameList = spaceManagementService.getActiveDepartmentsBySite(managedByNodeRefId);
        microservice.setDepartmentNameList(cobieFileExportDataId, departmentNameList);
    }

    protected void setAssetData(String cobieFileExportId, String cobieFileExportDataId, String facilityId) {
        cobieBackgroundRequestService.addCOBieExportInformationMessage(cobieFileExportId, "getting Asset Data.");
        AssetCOBieExportData assetData = assetService.getCOBieExportData(facilityId);
        microservice.setAssetData(cobieFileExportDataId, assetData);
    }

    protected void setSpaceData(String cobieFileExportId, String cobieFileExportDataId, String facilityId) {
        cobieBackgroundRequestService.addCOBieExportInformationMessage(cobieFileExportId, "getting Space Data.");
        List<SpaceCOBieExportData> spaceDataList = spaceManagementService
                .getSpaceCOBieExportDataByFacilityId(facilityId);
        microservice.setSpaceDataList(cobieFileExportDataId, spaceDataList);
    }

    protected void setFacilityData(String cobieFileExportId, String cobieFileExportDataId, String facilityId) {
        cobieBackgroundRequestService.addCOBieExportInformationMessage(cobieFileExportId, "getting Facility Data.");
        FacilityCOBieExportData facilityData = facilityService.getCOBieExportDataByFacilityId(facilityId);
        microservice.setFacilityData(cobieFileExportDataId, facilityData);
    }

    public COBieFileExportData getCOBieFileExportDataById(String cobieFileExportDataId) {
        return microservice.getCOBieFileExportDataById(cobieFileExportDataId);
    }

    public SearchResult<COBieFileImport> getCOBieFileImportSearchResults(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getCOBieSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            organizationService.setRPFuncFilterInSearch(searchInput);
            return microservice.getCOBieFileImportSearchResults(searchInput);
        }
    }

    public SearchResult<COBieFileExport> getCOBieFileExportSearchResults(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getCOBieSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            organizationService.setRPFuncFilterInSearch(searchInput);
            return microservice.getCOBieFileExportSearchResults(searchInput);
        }
    }

    public Boolean deleteCOBieImportFile(String id) {
        return microservice.deleteCOBieImportFile(id);
    }

    public Boolean deleteCOBieExportFile(String id) {
        return microservice.deleteCOBieExportFile(id);
    }

    // Contact
    public List<COBieContactImport> getCOBieContactImportsByFileImportId(String fileImportId) {
        return microservice.getCOBieContactImportsByFileImportId(fileImportId);
    }

    public List<COBieContactImportSummary> getCOBieContactImportSummariesByFileImportId(String fileImportId) {
        return microservice.getCOBieContactImportSummariesByFileImportId(fileImportId);
    }

    public int processCOBieContactImports(List<String> cobieContactImportIds) {
        microservice.updateCOBieContactErrorMessageByIdList(
            createQueuedMessageIdList(cobieContactImportIds, PROCESSING));

        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_PROCESS_COBIE_CONTACTS;
        cobieProcessDataRequest.idList = cobieContactImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieContactImportIds.size());
        return cobieContactImportIds.size();
    }

    public void saveCOBieContactImportSummary(COBieContactImportSummary cobieContactImportSummary) {
        microservice.saveCOBieContactImportSummary(cobieContactImportSummary);
    }

    public void deleteCOBieContactImports(List<String> cobieContactImportIds) {
        microservice.updateCOBieAttributeErrorMessageByIdList(
                createQueuedMessageIdList(cobieContactImportIds, DELETING));
        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_DELETE_COBIE_CONTACTS;
        cobieProcessDataRequest.idList = cobieContactImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieContactImportIds.size());
    }

    public List<String> getBusinessContactTypes() {
        return businessContactService.getBusinessContactTypes();
    }

    // Facility
    public List<COBieFacilityImport> getCOBieFacilityImportsByFileImportId(String fileImportId) {
        return microservice.getCOBieFacilityImportsByFileImportId(fileImportId);
    }

    // Floor
    public List<COBieFloorImport> getCOBieFloorImportsByFileImportId(String fileImportId) {
        return microservice.getCOBieFloorImportsByFileImportId(fileImportId);
    }

    public List<COBieFloorImportSummary> getCOBieFloorImportSummariesByFileImportId(String fileImportId) {
        return microservice.getCOBieFloorImportSummariesByFileImportId(fileImportId);
    }

    public int processCOBieFloorImports(List<String> cobieFloorImportIds) {
        microservice.updateCOBieFloorErrorMessageByIdList(
            createQueuedMessageIdList(cobieFloorImportIds, PROCESSING));

        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_PROCESS_COBIE_FLOORS;
        cobieProcessDataRequest.idList = cobieFloorImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieFloorImportIds.size());
        return cobieFloorImportIds.size();
    }

    public void saveCOBieFloorImportSummary(COBieFloorImportSummary cobieFloorImportSummary) {
        microservice.saveCOBieFloorImportSummary(cobieFloorImportSummary);
    }

    public void deleteCOBieFloorImports(List<String> cobieFloorImportIds) {
        microservice.updateCOBieFloorErrorMessageByIdList(
            createQueuedMessageIdList(cobieFloorImportIds, DELETING));
        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_DELETE_COBIE_FLOORS;
        cobieProcessDataRequest.idList = cobieFloorImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieFloorImportIds.size());
    }

    public void findDuplicateCOBieFloorImportsByFileImportId(String fileImportId) {
        List<COBieFloorImportSummary> cobieFloorImportSummaries = getCOBieFloorImportSummariesByFileImportId(fileImportId);
        List<String> cobieFloorImportIds = new ArrayList<>();
        for (COBieFloorImportSummary cobieFloorImportSummary: cobieFloorImportSummaries){
            cobieFloorImportIds.add(cobieFloorImportSummary.getId());
        }

        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_FIND_DUPLICATE_COBIE_FLOORS;
        cobieProcessDataRequest.idList = cobieFloorImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieFloorImportIds.size());
    }

    // Space
    public List<COBieSpaceImport> getCOBieSpaceImportsByFileImportId(String fileImportId) {
        return microservice.getCOBieSpaceImportsByFileImportId(fileImportId);
    }

    public List<COBieSpaceImportSummary> getCOBieSpaceImportSummariesByFileImportId(String fileImportId) {
        return microservice.getCOBieSpaceImportSummariesByFileImportId(fileImportId);
    }

    public int processCOBieSpaceImports(List<String> cobieSpaceImportIds) {
        microservice.updateCOBieSpaceErrorMessageByIdList(
            createQueuedMessageIdList(cobieSpaceImportIds, PROCESSING));

        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_PROCESS_COBIE_SPACES;
        cobieProcessDataRequest.idList = cobieSpaceImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieSpaceImportIds.size());
        return cobieSpaceImportIds.size();
    }

    public void saveCOBieSpaceImportSummary(COBieSpaceImportSummary cobieSpaceImportSummary) {
        microservice.saveCOBieSpaceImportSummary(cobieSpaceImportSummary);
    }

    public void deleteCOBieSpaceImports(List<String> cobieSpaceImportIds) {
        microservice.updateCOBieSpaceErrorMessageByIdList(
                createQueuedMessageIdList(cobieSpaceImportIds, DELETING));
        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_DELETE_COBIE_SPACES;
        cobieProcessDataRequest.idList = cobieSpaceImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieSpaceImportIds.size());
    }

    public void findDuplicateCOBieSpaceImportsByFileImportId(String fileImportId) {
        List<COBieSpaceImportSummary> cobieSpaceImportSummaries = getCOBieSpaceImportSummariesByFileImportId(fileImportId);
        List<String> cobieSpaceImportIds = new ArrayList<>();
        for (COBieSpaceImportSummary cobieSpaceImportSummary: cobieSpaceImportSummaries){
            cobieSpaceImportIds.add(cobieSpaceImportSummary.getId());
        }

        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_FIND_DUPLICATE_COBIE_SPACES;
        cobieProcessDataRequest.idList = cobieSpaceImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieSpaceImportIds.size());
    }

    // Zone
    public List<COBieZoneImport> getCOBieZoneImportsByFileImportId(String fileImportId) {
        return microservice.getCOBieZoneImportsByFileImportId(fileImportId);
    }

    public List<COBieZoneImportSummary> getCOBieZoneImportSummariesByFileImportId(String fileImportId) {
        return microservice.getCOBieZoneImportSummariesByFileImportId(fileImportId);
    }

    public int processCOBieZoneImports(List<String> cobieZoneImportIds) {
        microservice.updateCOBieZoneErrorMessageByIdList(
            createQueuedMessageIdList(cobieZoneImportIds, PROCESSING));

        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_PROCESS_COBIE_ZONES;
        cobieProcessDataRequest.idList = cobieZoneImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieZoneImportIds.size());
        return cobieZoneImportIds.size();
    }

    public void saveCOBieZoneImportSummary(COBieZoneImportSummary cobieZoneImportSummary) {
        microservice.saveCOBieZoneImportSummary(cobieZoneImportSummary);
    }

    public void deleteCOBieZoneImports(List<String> cobieZoneImportIds) {
        microservice.updateCOBieZoneErrorMessageByIdList(
                createQueuedMessageIdList(cobieZoneImportIds, DELETING));
        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_DELETE_COBIE_ZONES;
        cobieProcessDataRequest.idList = cobieZoneImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieZoneImportIds.size());
    }

    public void findDuplicateCOBieZoneImportsByFileImportId(String fileImportId) {
        List<COBieZoneImportSummary> cobieZoneImportSummaries = getCOBieZoneImportSummariesByFileImportId(fileImportId);
        List<String> cobieZoneImportIds = new ArrayList<>();
        for (COBieZoneImportSummary cobieZoneImportSummary: cobieZoneImportSummaries){
            cobieZoneImportIds.add(cobieZoneImportSummary.getId());
        }

        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_FIND_DUPLICATE_COBIE_ZONES;
        cobieProcessDataRequest.idList = cobieZoneImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieZoneImportIds.size());
    }

    // Type
    public List<COBieTypeImport> getCOBieTypeImportsByFileImportId(String fileImportId) {
        return microservice.getCOBieTypeImportsByFileImportId(fileImportId);
    }

    // Component
    public List<COBieComponentImport> getCOBieComponentImportsByFileImportId(String fileImportId) {
        return microservice.getCOBieComponentImportsByFileImportId(fileImportId);
    }

    // Equipment (Component + Type)
    public List<COBieEquipmentImport> getCOBieEquipmentImportsByFileImportId(String fileImportId) {
        return microservice.getCOBieEquipmentImportsByFileImportId(fileImportId);
    }

    public int processCOBieEquipmentImports(List<COBieEquipmentImportIds> cobieEquipmentImportIds) {
        updateEquipmentErrorMessagesFromList(cobieEquipmentImportIds, PROCESSING);

        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_PROCESS_COBIE_EQUIPMENT;
        cobieProcessDataRequest.cobieEquipmentImportIdsList = cobieEquipmentImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieEquipmentImportIds.size());
        return cobieEquipmentImportIds.size();
    }

    public void saveCOBieEquipmentImport(COBieEquipmentImport cobieEquipmentImport) {
        microservice.saveCOBieEquipmentImport(cobieEquipmentImport, true);
    }

    public void deleteCOBieEquipmentImports(List<COBieEquipmentImportIds> cobieEquipmentImportIds) {
        updateEquipmentErrorMessagesFromList(cobieEquipmentImportIds, PROCESSING);
        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_DELETE_COBIE_EQUIPMENT;
        cobieProcessDataRequest.cobieEquipmentImportIdsList = cobieEquipmentImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieEquipmentImportIds.size());
    }

    public void findDuplicateCOBieEquipmentImportsByFileImportId(String fileImportId) {
        List<COBieEquipmentImport> cobieEquipmentImports = getCOBieEquipmentImportsByFileImportId(fileImportId);
        List<COBieEquipmentImportIds> cobieEquipmentImportIds = new ArrayList<>();
        for (COBieEquipmentImport cobieEquipmentImport: cobieEquipmentImports){
            COBieEquipmentImportIds cobieEquipmentImportId = new COBieEquipmentImportIds();
            cobieEquipmentImportId.cobieComponentImportId = cobieEquipmentImport.componentImport.getId();
            cobieEquipmentImportId.cobieTypeImportId = cobieEquipmentImport.typeImport.getId();
            cobieEquipmentImportIds.add(cobieEquipmentImportId);
        }

        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_FIND_DUPLICATE_COBIE_EQUIPMENT;
        cobieProcessDataRequest.cobieEquipmentImportIdsList = cobieEquipmentImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieEquipmentImportIds.size());
    }

    public List<Space> getRoomsByFacilityId(String facilityId) {
        return spaceManagementService.getRoomsByFacilityId(facilityId);
    }

    public List<BusinessContactRef> getRPEManufacturerNames() {
        return assetService.getRPEManufacturerNames();
    }

    public List<BusinessContactRef> getAllRPEBusinessContacts() {
        return assetService.getAllRPEBusinessContacts();
    }

    public List<BusinessContactRef> getBusinessContactRefs(String isActive) {
        return assetService.getBusinessContactRefs(isActive);
    }

    public List<FacilitySystem> getAllActiveFacilitySystems() {
        return assetClassificationService.getAllActiveFacilitySystems();
    }

    public List<FacilitySubsystem> getFacilitySubsystemForFacilitySystem(String facilitySystemCode) {
        return assetClassificationService.getFacilitySubsystemForFacilitySystem(facilitySystemCode);
    }

    public List<AssemblyCategory> getAssemblyCategoriesForFacilitySubsystem(String facilitySubsystemCode) {
        return assetClassificationService.getAssemblyCategoriesForFacilitySubsystem(facilitySubsystemCode);
    }

    public List<Nomenclature> getNomenclaturesByCode(String code) {
        return assetClassificationService.getNomenclaturesByCode(code);
    }

    // Attribute
    public List<COBieAttributeImport> getCOBieAttributeImportsByFileImportId(String fileImportId) {
        return microservice.getCOBieAttributeImportsByFileImportId(fileImportId);
    }

    public int processCOBieAttributeImports(List<String> cobieAttributeImportIds) {
        microservice.updateCOBieAttributeErrorMessageByIdList(
            createQueuedMessageIdList(cobieAttributeImportIds, PROCESSING));

        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_PROCESS_COBIE_ATTRIBUTES;
        cobieProcessDataRequest.idList = cobieAttributeImportIds;
        cobieProcessDataRequest.capacityUnits = assetService.getCapacityUnits();
        cobieProcessDataRequest.specificationUnits = assetService.getSpecificationUnits();
        submitProcessDataRequest(cobieProcessDataRequest, cobieAttributeImportIds.size());
        return cobieAttributeImportIds.size();
    }

    public void saveCOBieAttributeImport(COBieAttributeImport cobieAttributeImport) {
        microservice.saveCOBieAttributeImport(cobieAttributeImport);
    }

    public void deleteCOBieAttributeImports(List<String> cobieAttributeImportIds) {
        microservice.updateCOBieAttributeErrorMessageByIdList(
                createQueuedMessageIdList(cobieAttributeImportIds, DELETING));
        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_DELETE_COBIE_ATTRIBUTES;
        cobieProcessDataRequest.idList = cobieAttributeImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieAttributeImportIds.size());
    }

    public void findDuplicateCOBieAttributeImportsByFileImportId(String fileImportId) {
        List<COBieAttributeImport> cobieAttributeImports = getCOBieAttributeImportsByFileImportId(fileImportId);
        List<String> cobieAttributeImportIds = new ArrayList<>();
        for (COBieAttributeImport cobieAttributeImport: cobieAttributeImports){
            cobieAttributeImportIds.add(cobieAttributeImport.getId());
        }

        COBieProcessDataRequest cobieProcessDataRequest = new COBieProcessDataRequest();
        cobieProcessDataRequest.processDataType = ProcessDrawingUploadMDB.JMS_TYPE_FIND_DUPLICATE_COBIE_ATTRIBUTES;
        cobieProcessDataRequest.idList = cobieAttributeImportIds;
        submitProcessDataRequest(cobieProcessDataRequest, cobieAttributeImportIds.size());
    }

    public void deleteCOBieFileExportDataRecordById(String cobieFileExportDataId) {
        microservice.deleteCOBieFileExportDataRecordById(cobieFileExportDataId);
    }

    protected boolean contentIsCOBieSpreadsheet(byte[] content) {
        boolean isValidWorksheet = false;
        try {
            XSSFWorkbook workbook = openWorkbookFromByteArray(content);
            isValidWorksheet = true;
            workbook.close();
        } catch (IOException e) {
            isValidWorksheet = false;
        }
        return isValidWorksheet;
    }

    protected XSSFWorkbook openWorkbookFromByteArray(byte[] content) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(content);
        // This is used to avoid a zip bomb error
        ZipSecureFile.setMinInflateRatio(0);
        XSSFWorkbook workbook = new XSSFWorkbook(bais);
        return workbook;
    }

    protected Integer getMaxCOBieImportAttachmentSize() {
        return microservice.getMaxCOBieImportAttachmentSize();
    }

    protected void submitProcessDataRequest(COBieProcessDataRequest cobieProcessDataRequest, int dataListSize) {
        cobieProcessDataRequest.processingStatus = "Queued for Processing.";
        cobieProcessDataRequest.information
                .add("  Processing " + dataListSize + " " + cobieProcessDataRequest.processDataType + " entries.");
        cobieProcessDataRequest = microservice.addCOBieProcessDataRequest(cobieProcessDataRequest);

        Queue queue = jmsContext.createQueue(ProcessDrawingUploadMDB.DRAWING_STAGING_SERVICE_BROKER);
        TextMessage textMessage = jmsContext
                .createTextMessage("cobieProcessDataRequestId:" + cobieProcessDataRequest.getId());
        JMSProducer jmsProducer = jmsContext.createProducer();
        jmsProducer.setJMSType(cobieProcessDataRequest.processDataType);

        jmsProducer.send(queue, textMessage);
    }

    protected boolean facilityMatchesSpreadsheetFacility(Facility facility, Attachment importFile) {
        // get file from File Manager
        String fileId = importFile.fileRef.fileId;
        CommonUploadedFile commonUploadedFile = fileManagerAdminService.download(fileId);
        if (commonUploadedFile != null) {
            XSSFWorkbook workbook = null;
            try {
                byte[] content = FileUtils.readFileToByteArray(commonUploadedFile.getFile());
                workbook = openWorkbookFromByteArray(content);
                XSSFSheet facilitySheet = getFacilitySheet(workbook);
                XSSFRow headerRow = getHeaderRow(facilitySheet);
                XSSFRow dataRow = getDataRow(facilitySheet);
                // find name column
                String spreadsheetFacilityNumber = getFacilityNumberFromSpreadsheetData(headerRow, dataRow);
                String selectedFacilityNumber = facility.facilityNumber;
                if (!spreadsheetFacilityNumber.equalsIgnoreCase(selectedFacilityNumber)) {
                    throw new ApplicationException("This spreadsheet does not contain data for the selected facility number.");
                }
                workbook.close();
                return true;
            } catch (IOException ex) {
                throw new ApplicationException("Could not read spreadsheet '" + importFile.fileRef.uploadedFileName + "'");
            } finally {
                closeWorkbook(commonUploadedFile, workbook);
            }
        }
        return false;
    }

    protected void closeWorkbook(CommonUploadedFile commonUploadedFile, XSSFWorkbook workbook) {
        if (workbook != null) {
            try {
            workbook.close();
            } catch (IOException ex) {
                logger.error("Could not close spreadsheet " + commonUploadedFile.getUploadedFilename() + ".");
                logger.error(ex);
            }
        }
    }

    protected String getFacilityNumberFromSpreadsheetData(XSSFRow headerRow, XSSFRow dataRow) {
        HashMap<String, String> attrVal = buildFacilityDataLookup(headerRow, dataRow);
        if (!attrVal.containsKey(NAME_KEY)) {
            throw new ApplicationException(FACILITY_SHEET_NAME + " sheet does not contain " + NAME_KEY + " column.");
        }
        String facilityNumber = attrVal.get(NAME_KEY);
        if (StringUtil.isEmptyOrNull(facilityNumber)) {
            throw new ApplicationException(
                    FACILITY_SHEET_NAME + " sheet does not contain data for " + NAME_KEY + " column.");
        }
        return facilityNumber;
    }

    protected HashMap<String, String> buildFacilityDataLookup(XSSFRow headerRow, XSSFRow dataRow) {
        Iterator<Cell> cellIterator = headerRow.cellIterator();
        HashMap<String, String> attrVal = new HashMap<>();
        while (cellIterator.hasNext()) {
            Cell cell = cellIterator.next();
            if (cell.getCellType() != CellType.BLANK) {
                String columnName = cell.getStringCellValue();
                int index = cell.getColumnIndex();
                Cell dataCell = dataRow.getCell(index);
                if (dataCell.getCellType() == CellType.STRING) {
                    String dataValue = dataCell.getStringCellValue();
                    attrVal.put(columnName, dataValue);
                }
            }
        }
        return attrVal;
    }

    protected XSSFRow getDataRow(XSSFSheet facilitySheet) {
        XSSFRow dataRow = facilitySheet.getRow(1);
        if (dataRow == null) {
            throw new ApplicationException(FACILITY_SHEET_NAME + " sheet does not have data in row 2.");
        }
        return dataRow;
    }

    protected XSSFRow getHeaderRow(XSSFSheet facilitySheet) {
        XSSFRow headerRow = facilitySheet.getRow(0);
        if (headerRow == null) {
            throw new ApplicationException(FACILITY_SHEET_NAME + " sheet does not have header row in row 1.");
        }
        return headerRow;
    }

    protected XSSFSheet getFacilitySheet(XSSFWorkbook workbook) {
        XSSFSheet facilitySheet = workbook.getSheet(FACILITY_SHEET_NAME);
        if (facilitySheet == null) {
            throw new ApplicationException("Spreadsheet does not have a " + FACILITY_SHEET_NAME + " tab.");
        }
        return facilitySheet;
    }

    protected COBieErrorMessageIdList createQueuedMessageIdList(List<String> idList, String message) {
        COBieErrorMessageIdList cobieErrorMessageIdList = new COBieErrorMessageIdList();
        cobieErrorMessageIdList.processErrorMessage = message;
        cobieErrorMessageIdList.idList = idList;
        return cobieErrorMessageIdList;
    }

    protected void updateEquipmentErrorMessagesFromList(List<COBieEquipmentImportIds> cobieEquipmentImportIds,
            String message) {
        List<String> componentIdList = new ArrayList<>();
        List<String> typeIdList = new ArrayList<>();
        cobieEquipmentImportIds.forEach(idPair -> {
            componentIdList.add(idPair.cobieComponentImportId);
            typeIdList.add(idPair.cobieTypeImportId);
        });
        microservice.updateCOBieComponentErrorMessageByIdList(createQueuedMessageIdList(componentIdList, message));
        microservice.updateCOBieTypeErrorMessageByIdList(createQueuedMessageIdList(typeIdList, message));
    }

    protected void setSpaceCodeData(String cobieFileExportId, String cobieFileExportDataId) {
        cobieBackgroundRequestService.addCOBieExportInformationMessage(cobieFileExportId, "getting Space Code Data.");
        microservice.setSpaceCodeData(cobieFileExportDataId);
    }
}
