package logicole.gateway.services.sso;

import logicole.apis.communications.ISsoSapTewlsMicroserviceApi;
import logicole.gateway.services.communications.SsoSapTewlsService;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class SsoService extends BaseGatewayService<ISsoSapTewlsMicroserviceApi>{

    @Inject
    private SsoSapTewlsService ssoSapTewlsService;

    public SsoService() {
        super("Sso");
    }

    public String getTewlsUrl() {
        return ssoSapTewlsService.getTewlsUrl();
    }

    public String getSapTewlsToken() {
        return ssoSapTewlsService.getSapTewlsToken();
    }
}
