package logicole.gateway.services.finance;

import io.swagger.annotations.Api;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.FundingNodeChild;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.datamigration.CommodityCodeRefMigrationWrapper;
import logicole.common.datamodels.finance.datamigration.FundingNodeChildMigrationWrapper;
import logicole.common.datamodels.finance.datamigration.FundingNodeMigrationWrapper;
import logicole.common.datamodels.finance.datamigration.FundingSourceMigrationWrapper;
import logicole.common.datamodels.finance.fundingsource.FundingSource;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

@Api(tags = {"financeDataMigration"})
@ApplicationScoped
@Path("/financeDataMigration")
public class FinanceDataMigrationRestApi extends ExternalRestApi<FinanceDataMigrationService> {

    @POST
    @Path("/convertFundingNode")
    public FundingNode convertFundingNode(FundingNodeMigrationWrapper fundingNodeMigrationWrapper) {
        return service.convertFundingNode(fundingNodeMigrationWrapper);
    }

    @POST
    @Path("/convertFundingNodeChild")
    public FundingNodeChild convertFundingNodeChild(FundingNodeChildMigrationWrapper childMigrationWrapper) {
        return service.convertFundingNodeChild(childMigrationWrapper);
    }

    @POST
    @Path("/convertFundingSource")
    public FundingSource convertFundingSource(FundingSourceMigrationWrapper fundingSourceMigrationWrapper) {
        return service.convertFundingSource(fundingSourceMigrationWrapper);
    }

    @GET
    @Path("/getExpenseCenterByMigrationId")
    public FundingNodeRef getExpenseCenterByMigrationId(@QueryParam("migrationKey") String migrationKey) {
        return service.getExpenseCenterByMigrationId(migrationKey);
    }

    @GET
    @Path("/getProjectCenterByMigrationId")
    public FundingNodeRef getProjectCenterByMigrationId(@QueryParam("migrationKey") String migrationKey) {
        return service.getProjectCenterByMigrationId(migrationKey);
    }

    @POST
    @Path("/getCommodityCodeRef")
    public CommodityCodeRef getCommodityCodeRef(CommodityCodeRefMigrationWrapper commodityCodeRefMigrationWrapper) {
        return service.getCommodityCodeRef(commodityCodeRefMigrationWrapper);
    }
}
