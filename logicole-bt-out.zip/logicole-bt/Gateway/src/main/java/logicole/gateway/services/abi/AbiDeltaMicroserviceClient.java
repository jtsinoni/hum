package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiDeltaMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiDeltaMicroserviceClient extends MicroserviceClient<IAbiDeltaMicroserviceApi> {
    public AbiDeltaMicroserviceClient() {
        super(IAbiDeltaMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiDeltaMicroserviceApi getABiDeltaService() {
        return createClient();
    }
}

