package logicole.gateway.services.system;

import logicole.apis.system.ISystemConfigurationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class SystemConfigurationMicroserviceClient extends MicroserviceClient<ISystemConfigurationMicroserviceApi> {
    public SystemConfigurationMicroserviceClient(){
        super(ISystemConfigurationMicroserviceApi.class, "logicole-system");
    }

    @Produces
    public ISystemConfigurationMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
