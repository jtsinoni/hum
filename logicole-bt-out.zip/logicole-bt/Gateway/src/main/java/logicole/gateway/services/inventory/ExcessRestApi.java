package logicole.gateway.services.inventory;


import io.swagger.annotations.Api;
import logicole.common.datamodels.inventory.Excess;
import logicole.common.datamodels.inventory.PotentialExcess;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Excess"})
@ApplicationScoped
@Path("/excess")
public class ExcessRestApi extends ExternalRestApi<ExcessService> {

    @GET
    @Path("/getExcessDetailById")
    public Excess getExcessDetailById(@QueryParam("excessId") String excessId) {
        return service.getExcessDetailById(excessId);
    }

    @GET
    @Path("/getExcessReportsByOrgId")
    public List<Excess> getExcessReportsByOrgId(@QueryParam("reportingOrganizationId") String reportingOrganizationId) {
        return service.getExcessReportsByOrgId(reportingOrganizationId);
    }

    @GET
    @Path("/getExcessRequestsByOrgId")
    public List<Excess> getExcessRequestsByOrgId(@QueryParam("requestingOrganizationId") String requestingOrganizationId) {
        return service.getExcessRequestsByOrgId(requestingOrganizationId);
    }

    @GET
    @Path("/getAllActiveExcessReports")
    public List<Excess> getAllActiveExcessReports() {
        return service.getAllActiveExcessReports();
    }

    @GET
    @Path("/getAllExcessRequests")
    public List<Excess> getAllExcessRequests() {
        return service.getAllExcessRequests();
    }

    @POST
    @Path("/cancelExcessRequest")
    public Excess cancelExcessRequest(@QueryParam("excessId") String excessId) {
        return service.cancelExcessRequest(excessId);
    }

    @GET
    @Path("/getExcessDelinquentLogBayRequests")
    public List<Excess> getExcessDelinquentLogBayRequests() {
        return service.getExcessDelinquentLogBayRequests();
    }

    @GET
    @Path("/getExcessLogBayHistory")
    public List<Excess> getLogBayHistory() {
        return service.getExcessLogBayHistory();
    }

    @GET
    @Path("/getExcessLogBayShippingStatus")
    public List<Excess> getExcessLogBayShippingStatus() {
        return service.getExcessLogBayShippingStatus();
    }

    @GET
    @Path("/getPotentialExcessByOrgId")
    public List<PotentialExcess> getPotentialExcessByOrgId(@QueryParam("orgId") String orgId) {
        return service.getPotentialExcessByOrgId(orgId);
    }

    @GET
    @Path("/getMyExcessReportsWithActiveRequests")
    public List<Excess> getMyExcessReportsWithActiveRequests() {
        return service.getMyExcessReportsWithActiveRequests();
    }

    @GET
    @Path("/getActiveExcessRequestsFromCustomers")
    public List<Excess> getActiveExcessRequestsFromCustomers() {
        return service.getActiveExcessRequestsFromCustomers();
    }

    @POST
    @Path("/acceptExcessRequestFromCustomer")
    public Excess acceptExcessRequestFromCustomer(Excess excess,
                                                  @QueryParam("reportIndex") Integer reportIndex,
                                                  @QueryParam("requestIndex") Integer requestIndex) {
        return service.acceptExcessRequestFromCustomer(excess, reportIndex, requestIndex);
    }

    @POST
    @Path("/rejectExcessRequestFromCustomer")
    public Excess rejectExcessRequestFromCustomer(Excess excess,
                                                  @QueryParam("reportIndex") Integer reportIndex,
                                                  @QueryParam("requestIndex") Integer requestIndex) {
        return service.rejectExcessRequestFromCustomer(excess, reportIndex, requestIndex);
    }

    @GET
    @Path("/searchExcessItems")
    public List<Excess> searchExcessItems(@QueryParam("searchString") String searchString,
                                          @QueryParam("hasQuantityAvailable") Boolean hasQuantityAvailable,
                                          @QueryParam("isActive") Boolean isActive) {
        return service.searchExcessItems(searchString, hasQuantityAvailable, isActive);
    }

    @POST
    @Path("/requestExcess")
    public Excess requestExcess(Excess excess,
                                @QueryParam("qtyRequested") Integer qtyRequested,
                                @QueryParam("requestingOrganizationId") String requestingOrganizationId) {
        return service.requestExcess(excess, qtyRequested, requestingOrganizationId);
    }

    @POST
    @Path("/reportExcess")
    public Excess reportExcess(PotentialExcess potentialExcess) {
        return service.reportExcess(potentialExcess);
    }

    @POST
    @Path("/adjustExcessQty")
    public Excess adjustExcessQty(Excess excess) {
        return service.adjustExcessQty(excess);
    }

    @POST
    @Path("/returnToDRMO")
    public Excess returnToDRMO(Excess excess) {
        return service.returnToDRMO(excess);
    }

}
