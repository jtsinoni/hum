package logicole.gateway.services.organization;

import java.util.List;

public interface IOrgProvider {
    Object provide(List<String>parameters);
}
