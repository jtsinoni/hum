package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetGroupMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AssetGroupMicroserviceClient extends MicroserviceClient<IAssetGroupMicroserviceApi> {
    public AssetGroupMicroserviceClient() {
        super(IAssetGroupMicroserviceApi.class, "logicole-asset");
    }
    
    @Produces
    public IAssetGroupMicroserviceApi getIAssetMicroserviceApi() {
        return createClient();
    }
}
