package logicole.gateway.services.catalog;

import logicole.apis.catalog.ICatalogNotesMicroserviceApi;
import logicole.common.datamodels.catalog.CatalogNote;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class CatalogNotesService extends BaseGatewayService<ICatalogNotesMicroserviceApi> {

    public CatalogNotesService() {
        super("Catalog");
    }

    public List<CatalogNote> getNotesByAssociatedRecordId(String associatedRecordId) {
        return microservice.getNotesByAssociatedRecordId(associatedRecordId);
    }

    public CatalogNote addNote(CatalogNote newNote) {
        return microservice.addNote(newNote);
    }

    public Integer deleteNote(CatalogNote newNote) {
        return microservice.deleteNote(newNote);
    }

    public CatalogNote updateNote(CatalogNote newNote) {
        return microservice.updateNote(newNote);
    }

}
