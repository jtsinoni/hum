package logicole.gateway.services.organization;

import logicole.apis.organization.IBusinessServiceDefinitionMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class BusinessServiceDefinitionMicroserviceClient extends MicroserviceClient<IBusinessServiceDefinitionMicroserviceApi> {
    public BusinessServiceDefinitionMicroserviceClient() {
        super(IBusinessServiceDefinitionMicroserviceApi.class, "logicole-organization");
    }

    @Produces
    public IBusinessServiceDefinitionMicroserviceApi getIBusinessServiceDefinitionMicroserviceApi() {
        return createClient();
    }


}
