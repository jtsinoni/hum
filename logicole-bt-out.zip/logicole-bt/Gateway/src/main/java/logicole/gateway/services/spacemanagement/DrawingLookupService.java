package logicole.gateway.services.spacemanagement;

import logicole.apis.space.IDrawingLookupMicroserviceApi;
import logicole.common.datamodels.space.Occupant;
import logicole.common.datamodels.space.lookupdata.DepartmentFill;
import logicole.common.datamodels.space.lookupdata.FloorPlanLayer;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.InstallationService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class DrawingLookupService extends BaseGatewayService<IDrawingLookupMicroserviceApi> {
    @Inject
    InstallationService installationService;

    @Inject
    OrganizationService organizationService;

    @Inject
    SpaceManagementService spaceManagementService;

    public DrawingLookupService() {
        super("Drawing");
    }

    // DepartmentFill methods
    public List<DepartmentFill> getDepartmentFills() {
        List<Occupant> occupants = spaceManagementService.getActiveOccupantsByManagedByNode(currentUserBT.getCurrentNodeId());

        List<DepartmentFill> departmentFills = new ArrayList<>();

        List<String> nodesRPDisabled = organizationService.getOrgLabelsRPDisabledInDmlssHost();
        for (Occupant occupant : occupants) {
        	if( !ListUtil.isEmpty(nodesRPDisabled) && 
        		occupant.managedByNodeRef != null && !StringUtil.isBlankOrNull(occupant.managedByNodeRef.nodeIdentifier) &&
        		nodesRPDisabled.contains(occupant.managedByNodeRef.nodeIdentifier)) {
        		continue;
        	}
        	
            if (occupant.departmentId != null && occupant.siteRef != null) {
                if (departmentFills.stream().noneMatch(object -> object.departmentId.equals(occupant.departmentId))) {
                    DepartmentFill departmentFill = new DepartmentFill();
                    departmentFill.siteRef = occupant.siteRef;
                    departmentFill.departmentId = occupant.departmentId;
                    departmentFill.departmentName = occupant.departmentName;
                    departmentFill.spaceFillColor = occupant.spaceFillColor;
                    departmentFill.spaceFillPattern = occupant.spaceFillPattern;

                    departmentFills.add(departmentFill);
                }
            }
        }

        return departmentFills;
    }

    public DepartmentFill updateDepartmentFill(DepartmentFill departmentFill) {
        List<Occupant> occupants = spaceManagementService.getActiveOccupantsByManagedByNode(currentUserBT.getCurrentNodeId());

        for (Occupant occupant : occupants) {
            if (occupant.departmentId != null && occupant.departmentId.equals(departmentFill.departmentId)) {
                occupant.spaceFillColor = departmentFill.spaceFillColor;
                occupant.spaceFillPattern = departmentFill.spaceFillPattern;

                spaceManagementService.updateOccupant(occupant);
            }
        }

        return departmentFill;
    }

    // FloorPlanLayer methods
    public List<FloorPlanLayer> getFloorPlanLayers() {
        return microservice.getFloorPlanLayers();
    }

    public FloorPlanLayer getFloorPlanLayerById(String floorPlanLayerId) {
        return microservice.getFloorPlanLayerById(floorPlanLayerId);
    }

    public FloorPlanLayer createFloorPlanLayer(FloorPlanLayer floorPlanLayer) {
        FloorPlanLayer foundFloorPlanLayer = microservice.getFloorPlanLayerByName(floorPlanLayer.name);
        if (foundFloorPlanLayer == null) {
            floorPlanLayer.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.createFloorPlanLayer(floorPlanLayer);
        } else {
            throw new ApplicationException("Floor Plan Layer already exists");
        }
    }

    public FloorPlanLayer updateFloorPlanLayer(FloorPlanLayer floorPlanLayer) {
        FloorPlanLayer foundFloorPlanLayer = microservice.getFloorPlanLayerById(floorPlanLayer.getId());
        if (foundFloorPlanLayer == null) {
            throw new ApplicationException("Floor Plan Layer does not exist");
        } else {
            if (!foundFloorPlanLayer.name.equalsIgnoreCase(floorPlanLayer.name) && microservice.getFloorPlanLayerByName(floorPlanLayer.name) != null) {
                throw new ApplicationException("Floor Plan Layer already exists");
            }
            foundFloorPlanLayer.category = floorPlanLayer.category;
            foundFloorPlanLayer.name = floorPlanLayer.name;
            return microservice.updateFloorPlanLayer(foundFloorPlanLayer);
        }
    }

    public boolean deleteFloorPlanLayer(String floorPlanLayerId) {
        FloorPlanLayer foundFloorPlanLayer = microservice.getFloorPlanLayerById(floorPlanLayerId);
        if (foundFloorPlanLayer == null) {
            throw new ApplicationException("Floor Plan Layer does not exist");
        } else {
            return microservice.deleteFloorPlanLayer(floorPlanLayerId);
        }
    }
}

