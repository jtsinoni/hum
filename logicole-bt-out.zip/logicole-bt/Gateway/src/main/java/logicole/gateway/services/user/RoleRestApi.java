package logicole.gateway.services.user;

import io.swagger.annotations.Api;
import logicole.common.datamodels.organization.ScopeQuery;
import logicole.common.datamodels.user.FunctionalArea;
import logicole.common.datamodels.user.GroupInvitation;
import logicole.common.datamodels.user.Role;
import logicole.common.datamodels.user.RoleFunctionalArea;
import logicole.common.datamodels.user.RoleRef;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ObjectNotFoundException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Role"})
@ApplicationScoped
@Path("/role")
public class RoleRestApi extends ExternalRestApi<RoleService> {

    @GET
    @Path("/doesRoleExistByName")
    public Boolean doesRoleExistByName(@QueryParam("roleName") String roleName) {
        return service.doesRoleExistByName(roleName);
    }

    @GET
    @Path("/renameRole")
    public Role renameRole(@QueryParam("roleId") String roleId,
                           @QueryParam("newRoleName") String newRoleName) throws ObjectNotFoundException {
        return service.renameRole(roleId, newRoleName);
    }

    @GET
    @Path("/deleteRoleById")
    public Boolean deleteRoleById(@QueryParam("id") String id) {
        return service.deleteRoleById(id);
    }

    @GET
    @Path("/getAllRoles")
    public List<Role> getAllRoles() {
        return service.getAllRoles();
    }

    @GET
    @Path("/getRole")
    public Role getRole(@QueryParam("roleId") String roleId) throws ObjectNotFoundException {
        return service.getRoleById(roleId);
    }

    @POST
    @Path("/getRoles")
    public List<Role> getRoles(String... roleIds) throws ObjectNotFoundException {
        return service.getRoles(roleIds);
    }

    @GET
    @Path("/getRolesByFunctionalArea")
    public List<Role> getRolesByFunctionalArea(@QueryParam("functionalArea") String functionalArea) {
        return service.getRolesByFunctionalArea(functionalArea);
    }

    @GET
    @Path("/getRolesByNodeType")
    public List<Role> getRolesByNodeType(@QueryParam("nodeTypeQ") String nodeTypeQ) throws ObjectNotFoundException {
        return service.getRolesByNodeType(nodeTypeQ);
    }

    @POST
    @Path("/getProfileRoles")
    public List<Role> getProfileRoles(UserProfile userProfile){
        return service.getProfileRoles(userProfile);
    }

    @POST
    @Path("/getGroupProfileRoles")
    public List<Role> getGroupProfileRoles(GroupInvitation groupInvitation){
        return service.getGroupProfileRoles(groupInvitation);
    }

    @POST
    @Path("/getProfileAssignableRoles")
    public List<Role> getProfileAssignableRoles(UserProfile userProfile){
        return service.getProfileAssignableRoles(userProfile);
    }

    @POST
    @Path("/getGroupProfileAssignableRoles")
    public List<Role> getGroupProfileAssignableRoles(GroupInvitation groupInvitation){
        return service.getGroupProfileAssignableRoles(groupInvitation);
    }

    @POST
    @Path("/getRolesByNodeIds")
    public List<Role> getRolesByNodeIds(ScopeQuery scopeNode) {
        return service.getRolesByNodeIds(scopeNode);
    }

    @POST
    @Path("/createRole")
    public Role createRole(Role role) throws ObjectNotFoundException {
        return service.createRole(role);
    }

    @POST
    @Path("/addRolePermission")
    public Role addRolePermission(@QueryParam("roleId") String roleId,
                                  @QueryParam("permissionId") String permissionId) throws ObjectNotFoundException {
        return service.addRolePermission(roleId, permissionId);
    }

    @POST
    @Path("/removeRolePermission")
    public Role removeRolePermission(@QueryParam("roleId") String roleId,
                                     @QueryParam("permissionName") String permissionId) throws ObjectNotFoundException {
        return service.removeRolePermission(roleId, permissionId);
    }

    @POST
    @Path("/addRole")
    public Role addRole(@QueryParam("roleId") String parentRoleId,
                        @QueryParam("childRoleId") String childRoleId) throws ObjectNotFoundException {
        return service.addRole(childRoleId, childRoleId);
    }

    @GET
    @Path("/getAllPermissions")
    public List<RoleFunctionalArea> getAllPermissions() {
        return service.getAllPermissions();
    }

    @POST
    @Path("/saveRolePermissions")
    public Role saveRolePermissions(Role role) throws ObjectNotFoundException {
        return service.saveRolePermissions(role);
    }

    @GET
    @Path("/activateRole")
    public Role activateRole(@NotNull @QueryParam("roleId") String roleId) throws ObjectNotFoundException {
        return service.activateRole(roleId);
    }

    @GET
    @Path("/deactivateRole")
    public Role deactivateRole(@NotNull @QueryParam("roleId") String roleId) throws ObjectNotFoundException {
        return service.deactivateRole(roleId);
    }

    @POST
    @Path("/toggleRoleEnabled")
    public Role toggleRoleEnabled(String roleId) throws ObjectNotFoundException {
        return service.toggleRoleEnabled(roleId);
    }

    @POST
    @Path("/saveRoleData")
    public Role saveRoleData(Role role) throws ObjectNotFoundException {
        return service.saveRoleData(role);
    }

    @GET
    @Path("/getRoleFunctionalAreaConfigs")
    public List<FunctionalArea> getRoleFunctionalAreaConfigs() {
        return service.getRoleFunctionalAreaConfigs();
    }

    @GET
    @Path("/getRolesForPermission")
    public List<Role> getRolesForPermission(@NotNull @QueryParam("permissionId") String permissionId) {
        return service.getRolesForPermission(permissionId);
    }

    @GET
    @Path("/getAllRoleRefs")
    public List<RoleRef> getAllRoleRefs() {
        return service.getAllRoleRefs();
    }

}
