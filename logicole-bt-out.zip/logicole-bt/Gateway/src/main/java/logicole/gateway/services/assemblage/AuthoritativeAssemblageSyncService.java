package logicole.gateway.services.assemblage;

import logicole.apis.assemblage.IAuthoritativeAssemblageSyncMicroserviceApi;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class AuthoritativeAssemblageSyncService extends BaseGatewayService<IAuthoritativeAssemblageSyncMicroserviceApi> {

    protected AuthoritativeAssemblageSyncService() {
        super("AuthoritativeAssemblageSync");
    }

    public void syncAuthoritativeAssemblages() {
        microservice.syncAuthoritativeAssemblages();
    }
}
