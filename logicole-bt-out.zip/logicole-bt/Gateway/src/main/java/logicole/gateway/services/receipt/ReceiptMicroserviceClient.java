package logicole.gateway.services.receipt;

import logicole.gateway.rest.MicroserviceClient;
import logicole.apis.receipt.IReceiptMicroserviceApi;


import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class ReceiptMicroserviceClient extends MicroserviceClient<IReceiptMicroserviceApi> {
    public ReceiptMicroserviceClient(){
        super(IReceiptMicroserviceApi.class, "logicole-receipt");
    }

    @Produces
    public IReceiptMicroserviceApi getIReceiptMicroserviceApi() {
        return createClient();
    }

}
