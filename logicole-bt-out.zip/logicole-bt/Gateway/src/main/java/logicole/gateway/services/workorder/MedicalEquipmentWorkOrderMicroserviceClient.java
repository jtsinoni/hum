package logicole.gateway.services.workorder;

import logicole.apis.workorder.IMedicalEquipmentWorkOrderMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class MedicalEquipmentWorkOrderMicroserviceClient extends MicroserviceClient<IMedicalEquipmentWorkOrderMicroserviceApi> {
    public MedicalEquipmentWorkOrderMicroserviceClient() {
        super(IMedicalEquipmentWorkOrderMicroserviceApi.class, "logicole-workorder");
    }

    @Produces
    public IMedicalEquipmentWorkOrderMicroserviceApi getIMedicalEquipmentWorkOrderMicroserviceApi() {
        return createClient();
    }
}
