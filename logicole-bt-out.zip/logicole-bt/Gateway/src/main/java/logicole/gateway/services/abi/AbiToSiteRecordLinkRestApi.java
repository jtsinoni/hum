package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.ABiToSiteRecordLinkResult;
import logicole.common.datamodels.product.SiteCatalogRecord;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi/abiToSiteRecordLinkManager")
public class AbiToSiteRecordLinkRestApi extends ExternalRestApi<AbiToSiteRecordLinkService> {

    @GET
    @Path("/getByNdc")
    public List<SiteCatalogRecord> getByNdc(@QueryParam("ndc") String ndc) {
        return service.getByNdc(ndc);
    }

    @GET
    @Path("/getByManufacturerNameAndCatalogNumber")
    public List<SiteCatalogRecord> getByManufacturerNameAndCatalogNumber(@QueryParam("manufacturer") String manufacturerNm,
                                                                         @QueryParam("manufacturerCatalogNumber") String manufCatNum) {
        return service.getByManufacturerNameAndCatalogNumber(manufacturerNm, manufCatNum);
    }

    @GET
    @Path("/getByManufacturerCatalogNumber")
    public List<SiteCatalogRecord> getByManufacturerCatalogNumber(@QueryParam("manufacturerCatalogNumber") String manufCatNum) {
        return service.getByManufacturerCatalogNumber(manufCatNum);
    }

    @GET
    @Path("/getByEnterpriseProductIdentifier")
    public List<SiteCatalogRecord> getByEnterpriseProductIdentifier(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.getByEnterpriseProductIdentifier(enterpriseProductIdentifier);
    }

    @GET
    @Path("/getByMmcProductIdentifier")
    public List<SiteCatalogRecord> getByMmcProductIdentifier(@QueryParam("mmcProductIdentifier") long productSeqId) {
        if ( productSeqId < 0 || productSeqId > 2147483647) {
            return new ArrayList<SiteCatalogRecord>();
        }
        return service.getByProductSeqId((int)productSeqId);

    }

    @GET
    @Path("/getByEnterpriseItemIdentifier")
    public List<SiteCatalogRecord> getByEnterpriseItemIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier) {
        return service.getByEnterpriseItemIdentifier(enterpriseItemIdentifier);

    }

    @POST
    @Path("/updateEnterpriseProductIdentifiersByIds")
    public ABiToSiteRecordLinkResult updateEnterpriseProductIdentifiersByIds(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier,
                                                                             List<String> idList) {
        return service.updateEnterpriseProductIdentifiersByIds(enterpriseProductIdentifier, idList);
    }

    @POST
    @Path("/doesEnterpriseProductIdentifierExist")
    public boolean doesEnterpriseProductIdentifierExist(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.doesEnterpriseProductIdentifierExist(enterpriseProductIdentifier);
    }

    @POST
    @Path("/removeEnterpriseProductIdentifiersByIds")
    public ABiToSiteRecordLinkResult removeEnterpriseProductIdentifiersByIds(List<String> idList) {
        return service.removeEnterpriseProductIdentifiersByIds(idList);
    }

    @GET
    @Path("/findSiteCatalogById")
    public SiteCatalogRecord findSiteCatalogById(@QueryParam("id") String id) {
        return service.findSiteCatalogById(id);
    }

}
