package logicole.gateway.services.asset;

import io.swagger.annotations.Api;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.businesscontact.BusinessContact;
import logicole.common.datamodels.asset.businesscontact.BusinessContactRef;
import logicole.common.datamodels.asset.classification.Nomenclature;
import logicole.common.datamodels.asset.classification.NomenclatureForDropdown;
import logicole.common.datamodels.asset.maintenance.procedure.MaintenanceProcedure;
import logicole.common.datamodels.asset.maintenance.procedure.MaintenanceProcedureRef;
import logicole.common.datamodels.asset.management.AssetGroup;
import logicole.common.datamodels.asset.management.AssetSummary;
import logicole.common.datamodels.asset.schedule.BusinessContactBulkUpdateWrapper;
import logicole.common.datamodels.asset.schedule.FundingSourceBulkUpdateWrapper;
import logicole.common.datamodels.asset.schedule.QualityBulkUpdateWrapper;
import logicole.common.datamodels.asset.schedule.Review;
import logicole.common.datamodels.asset.schedule.Schedule;
import logicole.common.datamodels.asset.schedule.ScheduleSummary;
import logicole.common.datamodels.asset.schedule.bulk.BulkResponse;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.general.BulkUpdateResult;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.realproperty.RealPropertyFundingNodeSummary;
import logicole.common.datamodels.realproperty.Site;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.realproperty.facility.FacilitySummary;
import logicole.common.datamodels.space.RoomSummary;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.datamodels.workorder.WorkOrderSummary;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"AssetSchedule"})
@ApplicationScoped
@Path("/assetSchedule")
public class AssetScheduleRestApi extends ExternalRestApi<AssetScheduleService> {

    @GET
    @Path("/getAllSites")
    public List<Site> getAllSites() {
        return service.getAllSites();
    }

    @GET
    @Path("/getActiveFacilitiesBySiteUid")
    public List<FacilitySummary> getActiveFacilitiesBySiteUid(@NotNull @QueryParam("rpsuid") String rpsuid) {
        return service.getActiveFacilitiesBySiteUid(rpsuid);
    }

    @GET
    @Path("/getFacilityById")
    public Facility getFacilityById(@NotNull @QueryParam("facilityId") String facilityId) {
        return service.getFacilityById(facilityId);
    }

    @GET
    @Path("/getWorkOrderSummariesBySchedule")
    public List<WorkOrderSummary> getWorkOrderSummariesBySchedule(@NotNull @QueryParam("scheduleId") String scheduleId) {
        return service.getWorkOrderSummariesBySchedule(scheduleId);
    }

    @GET
    @Path("/getRoomSummariesByFacilityId")
    public List<RoomSummary> getRoomSummariesByFacilityId(@NotNull @QueryParam("facilityId") String facilityId,
                                                          @NotNull @QueryParam("selectedStatus") String selectedStatus) {
        return service.getRoomSummariesByFacilityId(facilityId, selectedStatus);
    }

    @POST
    @Path("/findSchedules")
    public SearchResult<ScheduleSummary> findSchedules(SearchInput searchInput) {
        return service.findSchedules(searchInput);
    }

    @GET
    @Path("/findScheduleById")
    public Schedule findScheduleById(@NotNull @QueryParam("id") String id) {
        return service.findScheduleById(id);
    }

    @POST
    @Path("/findSchedulesByIds")
    public List<Schedule> findSchedulesByIds(List<String> ids) {
        return service.findSchedulesByIds(ids);
    }

    @POST
    @Path("/saveNewSchedule")
    public Schedule saveNewSchedule(@NotNull Schedule schedule) {
        return service.saveNewSchedule(schedule);
    }

    @POST
    @Path("/updateWorkOrderIsDeferred")
    public void updateWorkOrderIsDeferred(@NotNull @QueryParam("id") String id, @NotNull @QueryParam("isDeferred") boolean isDeferred, String reason) {
        service.updateWorkOrderIsDeferred(id, isDeferred, reason);
    }

    @POST
    @Path("/updateScheduleDetail")
    public Schedule updateScheduleDetail(@NotNull Schedule schedule) {
        return service.updateScheduleDetail(schedule);
    }

    @GET
    @Path("/deleteSchedule")
    public void deleteSchedule(@NotNull @QueryParam("id") String id) {
        service.deleteSchedule(id);
    }

    @GET
    @Path("/getSchedulesByAssetId")
    public List<Schedule> getSchedulesByAssetId(@NotNull @QueryParam("assetId") String assetId) {
        return service.getSchedulesByAssetId(assetId);
    }

    @POST
    @Path("/getSchedulesByAssetIds")
    public List<Schedule> getSchedulesByAssetIds(List<String> assetIds) {
        return service.getSchedulesByAssetIds(assetIds);
    }

    @GET
    @Path("/getProceduresForNomenclature")
    public List<MaintenanceProcedure> getProceduresForNomenclature(@NotNull @QueryParam("id") String id) {
        return service.getProceduresForNomenclature(id);
    }

    @GET
    @Path("/getMaintenanceBusinessContactsBySkill")
    public List<BusinessContact> getMaintenanceBusinessContactsBySkill(
            @QueryParam("skillId") String skillId) {
        return service.getMaintenanceBusinessContactsBySkill(skillId);
    }

    @GET
    @Path("/getBusinessContactRef")
    public BusinessContactRef getBusinessContactRef(@QueryParam("id") String id) {
        return service.getBusinessContactRef(id);
    }

    @GET
    @Path("/getProcedureRefsWithSameNomenclature")
    public List<MaintenanceProcedureRef> getProcedureRefsWithSameNomenclature(
            @NotNull @QueryParam("nomenclatureId") String nomenclatureId) {
        return service.getProcedureRefsWithSameNomenclature(nomenclatureId);
    }

    @POST
    @Path("/addNote")
    public Schedule addNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.addNote(id, note);
    }

    @POST
    @Path("/saveNote")
    public Schedule saveNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.saveNote(id, note);
    }

    @POST
    @Path("/removeNote")
    public Schedule removeNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.removeNote(id, note);
    }

    @GET
    @Path("/getScheduleIdsByMaintenanceProcedureId")
    public List<String> getScheduleIdsByMaintenanceProcedureId(
            @NotNull @QueryParam("maintenanceProcedureId") String maintenanceProcedureId) {
        return service.getScheduleIdsByMaintenanceProcedureId(maintenanceProcedureId);
    }

    @POST
    @Path("/updateMaintenanceProcedureRef")
    public Schedule updateMaintenanceProcedureRef(
            @NotNull @QueryParam("scheduleId") String scheduleId,
            MaintenanceProcedureRef newMaintProcRef) {
        return service.updateMaintenanceProcedureRef(scheduleId, newMaintProcRef);
    }

    @GET
    @Path("/getYearlyAndMonthlySchedulesByAssetAndSkill")
    public List<Schedule> getYearlyAndMonthlySchedulesByAssetAndSkill(
            @NotNull @QueryParam("assetId") String assetId,
            @NotNull @QueryParam("skillId") String skillId,
            @QueryParam("scheduleIdToExclude") String scheduleIdToExclude) {
        return service
                .getYearlyAndMonthlySchedulesByAssetAndSkill(assetId, skillId, scheduleIdToExclude);
    }

    @POST
    @Path("/updateSectionInspectionForWorkOrders")
    public int updateSectionInspectionForWorkOrders(
            @NotNull @QueryParam("workOrderIds") List<String> workOrderIds,
            @QueryParam("isSectionInspection") boolean isSectionInspection) {
        return service.updateSectionInspectionForWorkOrders(workOrderIds, isSectionInspection);
    }

    @GET
    @Path("/getOpenWorkOrderFutureDaysThresholdConfig")
    public Integer getOpenWorkOrderFutureDaysThresholdConfig() {
        return service.getOpenWorkOrderFutureDaysThresholdConfig();
    }

    @GET
    @Path("/openNextScheduledWorkOrder")
    public WorkOrder openNextScheduledWorkOrder(@NotNull @QueryParam("scheduleId") String scheduleId) {
        return service.openNextScheduledWorkOrder(scheduleId);
    }

    @POST
    @Path("/bulkUpdateBusinessContact")
    public BulkResponse bulkUpdateBusinessContact(
            @NotNull BusinessContactBulkUpdateWrapper businessContactBulkUpdateWrapper) {
        return service.bulkUpdateBusinessContact(businessContactBulkUpdateWrapper);
    }

    @POST
    @Path("/bulkUpdateQualityAssurance")
    public Integer bulkUpdateQualityAssurance(
            @NotNull QualityBulkUpdateWrapper qualityBulkUpdateWrapper) {
        return service.bulkUpdateQualityAssurance(qualityBulkUpdateWrapper);
    }

    @POST
    @Path("/bulkUpdateQualityControl")
    public Integer bulkUpdateQualityControl(
            @NotNull QualityBulkUpdateWrapper qualityBulkUpdateWrapper) {
        return service.bulkUpdateQualityControl(qualityBulkUpdateWrapper);
    }

    @POST
    @Path("/bulkUpdateFundingSource")
    public BulkUpdateResult bulkUpdateFundingSource(
            @NotNull FundingSourceBulkUpdateWrapper wrapper) {
        return service.bulkUpdateFundingSource(wrapper);
    }

    @POST
    @Path("/bulkDeleteMaterialFundingSource")
    public BulkUpdateResult bulkDeleteMaterialFundingSource(
            @NotNull FundingSourceBulkUpdateWrapper wrapper) {
        return service.bulkDeleteMaterialFundingSource(wrapper);
    }

    @POST
    @Path("/saveReview")
    public Schedule saveReview(@NotNull @QueryParam("id") String id, Review review) {
        return service.saveReview(id, review);
    }

    @GET
    @Path("/getMaintenanceProcedureRefs")
    public List<MaintenanceProcedureRef> getMaintenanceProcedureRefs() {
        return service.getMaintenanceProcedureRefs();
    }

    @GET
    @Path("getProcedureRefsForNomenclature")
    public List<MaintenanceProcedureRef> getProcedureRefsForNomenclature(@NotNull @QueryParam("nomenclatureId") String nomenclatureId) {
        return service.getProcedureRefsForNomenclature(nomenclatureId);
    }

    @GET
    @Path("getRegulatoryComplianceProcedureRefs")
    public List<MaintenanceProcedureRef> getRegulatoryComplianceProcedureRefs() {
        return service.getRegulatoryComplianceProcedureRefs();
    }

    @GET
    @Path("getNomenclatureById")
    public Nomenclature getNomenclatureById(@NotNull @QueryParam("nomenclatureId") String nomenclatureId) {
        return service.getNomenclatureById(nomenclatureId);
    }

    @GET
    @Path("/getNomenclaturesForDropdown")
    public List<NomenclatureForDropdown> getNomenclaturesForDropdown() {
        return service.getNomenclaturesForDropdown();
    }

    @GET
    @Path("/getAssetSummariesByFacilityId")
    public List<AssetSummary> getAssetSummariesByFacilityId(@NotNull @QueryParam("facilityId") String facilityId) {
        return service.getAssetSummariesByFacilityId(facilityId);
    }

    @GET
    @Path("/getAssetSummariesByFacilityIdAndProcedureId")
    public List<AssetSummary> getAssetSummariesByFacilityIdAndProcedureId(@NotNull @QueryParam("facilityId") String facilityId, @NotNull @QueryParam("procedureId") String procedureId) {
        return service.getAssetSummariesByFacilityIdAndProcedureId(facilityId, procedureId);
    }

    @GET
    @Path("/getAssetGroupsByFacilityId")
    public List<AssetGroup> getAssetGroupsByFacilityId(@NotNull @QueryParam("facilityId") String facilityId) {
        return service.getAssetGroupsByFacilityId(facilityId);
    }

    @GET
    @Path("/getAssetGroupsByFacilityIdAndProcedureId")
    public List<AssetGroup> getAssetGroupsByFacilityIdAndProcedureId(@NotNull @QueryParam("facilityId") String facilityId, @NotNull @QueryParam("procedureId") String procedureId) {
        return service.getAssetGroupsByFacilityIdAndProcedureId(facilityId, procedureId);
    }

    @GET
    @Path("/getAssetSummariesByAssetGroupId")
    public List<AssetSummary> getAssetSummariesByAssetGroupId(@NotNull @QueryParam("assetGroupId") String assetGroupId) {
        return service.getAssetSummariesByAssetGroupId(assetGroupId);
    }

    @GET
    @Path("/getProjectFundingNodeSummaries")
    public List<RealPropertyFundingNodeSummary> getProjectFundingNodeSummaries(@QueryParam("organizationNodeId") String organizationNodeId) {
    	return service.getProjectFundingNodeSummaries(organizationNodeId);
    }

    @GET
    @Path("/getExpenseFundingNodeSummaries")
    public List<RealPropertyFundingNodeSummary> getExpenseFundingNodeSummaries(@QueryParam("projectFundingNodeId") String projectFundingNodeId) {
        return service.getExpenseFundingNodeSummaries(projectFundingNodeId);
    }

    @GET
    @Path("/getCommodityCodeRefs") 
    public List<CommodityCodeRef> getCommodityCodeRefs(@QueryParam("organizationNodeId") String organizationNodeId ) {
    	return service.getCommodityCodeRefs(organizationNodeId);
    }

}
