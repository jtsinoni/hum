package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetClassificationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AssetClassificationMicroserviceClient extends MicroserviceClient<IAssetClassificationMicroserviceApi> {
    public AssetClassificationMicroserviceClient() {
        super(IAssetClassificationMicroserviceApi.class, "logicole-asset");
    }
    
    @Produces
    public IAssetClassificationMicroserviceApi getIAssetMicroserviceApi() {
        return createClient();
    }
}
