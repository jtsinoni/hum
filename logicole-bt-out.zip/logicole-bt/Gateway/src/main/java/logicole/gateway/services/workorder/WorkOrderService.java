package logicole.gateway.services.workorder;

import logicole.apis.workorder.IWorkOrderMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Configuration;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.businesscontact.BusinessContact;
import logicole.common.datamodels.asset.businesscontact.BusinessContactRef;
import logicole.common.datamodels.asset.businesscontact.BusinessContactSearch;
import logicole.common.datamodels.asset.businesscontact.EBusinessContactType;
import logicole.common.datamodels.asset.businesscontact.Personnel;
import logicole.common.datamodels.asset.businesscontact.Services;
import logicole.common.datamodels.asset.businesscontact.Skill;
import logicole.common.datamodels.asset.businesscontact.SkillRef;
import logicole.common.datamodels.asset.maintenance.procedure.MaintenanceProcedure;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceCode;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceCodeRef;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceSubject;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.AssetSummary;
import logicole.common.datamodels.asset.management.EQaQcInspectionMethod;
import logicole.common.datamodels.asset.schedule.Schedule;
import logicole.common.datamodels.communications.TransmitConstants;
import logicole.common.datamodels.communications.maximo.MaximoWorkPerformed;
import logicole.common.datamodels.communications.maximo.MaximoWorkRequest;
import logicole.common.datamodels.communications.response.CommunicationsMaximoResponse;
import logicole.common.datamodels.communications.response.InitialCommunicationsResponse;
import logicole.common.datamodels.communications.transmitproperty.TransmitPropertyRecord;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.filemanager.FileRef;
import logicole.common.datamodels.finance.ECommodityCodeUsageType;
import logicole.common.datamodels.finance.FundingNodeDTO;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.ProcessingBalance;
import logicole.common.datamodels.finance.datamigration.CommodityCodeRefMigrationWrapper;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.request.EBusinessEventType;
import logicole.common.datamodels.finance.request.FinanceItem;
import logicole.common.datamodels.finance.request.FmFinanceItem;
import logicole.common.datamodels.finance.request.RequestGroup;
import logicole.common.datamodels.general.EActiveStatus;
import logicole.common.datamodels.general.customfield.CustomField;
import logicole.common.datamodels.general.customfield.CustomFieldRef;
import logicole.common.datamodels.general.customfield.CustomFieldValue;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.notification.ENotificationType;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.realproperty.DmlssRealPropertyFunding;
import logicole.common.datamodels.realproperty.Installation;
import logicole.common.datamodels.realproperty.RealPropertyFunding;
import logicole.common.datamodels.realproperty.RealPropertyFundingNodeSummary;
import logicole.common.datamodels.realproperty.Site;
import logicole.common.datamodels.realproperty.SiteRef;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.realproperty.facility.FacilityBusinessContact;
import logicole.common.datamodels.realproperty.facility.FacilityRef;
import logicole.common.datamodels.realproperty.facility.FacilitySummary;
import logicole.common.datamodels.realpropertyproject.Requirement;
import logicole.common.datamodels.realpropertyproject.RequirementRef;
import logicole.common.datamodels.realpropertyproject.lookupdata.ERequirementCriticality;
import logicole.common.datamodels.realpropertyproject.project.RealPropertyProject;
import logicole.common.datamodels.realpropertyproject.project.RealPropertyProjectRef;
import logicole.common.datamodels.realpropertyproject.workflow.EProjectWorkflowStepName;
import logicole.common.datamodels.realpropertysection.Section;
import logicole.common.datamodels.realpropertysection.SectionSummary;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.ref.ReferenceObject;
import logicole.common.datamodels.report.ExportFileInfo;
import logicole.common.datamodels.report.ReportContainer;
import logicole.common.datamodels.space.Floor;
import logicole.common.datamodels.space.FloorPlanLegendEntry;
import logicole.common.datamodels.space.GraphicalSearchRecord;
import logicole.common.datamodels.space.Occupant;
import logicole.common.datamodels.space.OccupantRef;
import logicole.common.datamodels.space.RoomMetadata;
import logicole.common.datamodels.space.RoomRelatedRecordCounts;
import logicole.common.datamodels.space.RoomSummary;
import logicole.common.datamodels.space.Space;
import logicole.common.datamodels.space.SpaceRef;
import logicole.common.datamodels.space.Zone;
import logicole.common.datamodels.space.ZoneRef;
import logicole.common.datamodels.space.lookupdata.FloorPlanLayer;
import logicole.common.datamodels.system.ApplicationNotificationWrapper;
import logicole.common.datamodels.system.EBusinessArea;
import logicole.common.datamodels.system.TagRef;
import logicole.common.datamodels.system.frequency.FrequencyRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.EPhoneNumberType;
import logicole.common.datamodels.user.PhoneNumber;
import logicole.common.datamodels.user.RoleRef;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.datamodels.workflow.WorkflowDefinition;
import logicole.common.datamodels.workflow.WorkflowStepSummary;
import logicole.common.datamodels.workorder.ActualCost;
import logicole.common.datamodels.workorder.Assignment;
import logicole.common.datamodels.workorder.AssignmentEstimateResult;
import logicole.common.datamodels.workorder.AssociateWorkOrder;
import logicole.common.datamodels.workorder.ClassificationType;
import logicole.common.datamodels.workorder.ClassificationTypeRef;
import logicole.common.datamodels.workorder.CmmsBusinessContact;
import logicole.common.datamodels.workorder.CmmsConstants;
import logicole.common.datamodels.workorder.CmmsError;
import logicole.common.datamodels.workorder.CmmsErrorSearchCriteria;
import logicole.common.datamodels.workorder.CmmsErrorType;
import logicole.common.datamodels.workorder.CmmsExpenseCenter;
import logicole.common.datamodels.workorder.CmmsExpenseCenterRef;
import logicole.common.datamodels.workorder.Comment;
import logicole.common.datamodels.workorder.CostSummary;
import logicole.common.datamodels.workorder.CostumerComplaintRecordForm;
import logicole.common.datamodels.workorder.DaForm4283Form;
import logicole.common.datamodels.workorder.EAssignmentReason;
import logicole.common.datamodels.workorder.ECmmsActionType;
import logicole.common.datamodels.workorder.EDonatedResource;
import logicole.common.datamodels.workorder.EEnvironmentalImpact;
import logicole.common.datamodels.workorder.EQualitySelectionCriteria;
import logicole.common.datamodels.workorder.ERating;
import logicole.common.datamodels.workorder.ERelatedCause;
import logicole.common.datamodels.workorder.EWorkOrderAppendType;
import logicole.common.datamodels.workorder.EWorkOrderCostType;
import logicole.common.datamodels.workorder.EWorkflowActionName;
import logicole.common.datamodels.workorder.EWorkflowName;
import logicole.common.datamodels.workorder.EWorkflowStepName;
import logicole.common.datamodels.workorder.EnvironmentalImpactSummary;
import logicole.common.datamodels.workorder.FloorRooms;
import logicole.common.datamodels.workorder.Impact;
import logicole.common.datamodels.workorder.ImpactReason;
import logicole.common.datamodels.workorder.ImpactType;
import logicole.common.datamodels.workorder.LaborRateFactor;
import logicole.common.datamodels.workorder.LegacyWorkRequestStatusHistory;
import logicole.common.datamodels.workorder.MaximoEventHistory;
import logicole.common.datamodels.workorder.Navfac9WorkRequestForm;
import logicole.common.datamodels.workorder.NonCatalogPart;
import logicole.common.datamodels.workorder.PartOption;
import logicole.common.datamodels.workorder.PreventativeMaintenanceWorkOrderForm;
import logicole.common.datamodels.workorder.PriorityGroup;
import logicole.common.datamodels.workorder.PriorityGroupRef;
import logicole.common.datamodels.workorder.QualityEvent;
import logicole.common.datamodels.workorder.QualitySelection;
import logicole.common.datamodels.workorder.ServiceRequest;
import logicole.common.datamodels.workorder.ServiceRequestSearchCriteria;
import logicole.common.datamodels.workorder.Severity;
import logicole.common.datamodels.workorder.SeverityRef;
import logicole.common.datamodels.workorder.Standards;
import logicole.common.datamodels.workorder.UnscheduledWorkRequestForm;
import logicole.common.datamodels.workorder.WorkLoadSearchCriteria;
import logicole.common.datamodels.workorder.WorkLoadSummary;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.datamodels.workorder.WorkOrderBusinessEvent;
import logicole.common.datamodels.workorder.WorkOrderDashboardInfo;
import logicole.common.datamodels.workorder.WorkOrderFinanceRequestFundInfo;
import logicole.common.datamodels.workorder.WorkOrderHistory;
import logicole.common.datamodels.workorder.WorkOrderLegacyAssociationResult;
import logicole.common.datamodels.workorder.WorkOrderRef;
import logicole.common.datamodels.workorder.WorkOrderReport;
import logicole.common.datamodels.workorder.WorkOrderRequirementMigrationResult;
import logicole.common.datamodels.workorder.WorkOrderSummary;
import logicole.common.datamodels.workorder.WorkOrderSurvey;
import logicole.common.datamodels.workorder.WorkOrderType;
import logicole.common.datamodels.workorder.bulk.BulkResponse;
import logicole.common.datamodels.workorder.bulk.FailedItem;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.exception.UnauthorizedException;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.security.SecurityConstants;
import logicole.common.general.util.DateUtil;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.common.general.util.string.StringUtil.EIncludeEmpty;
import logicole.common.servers.business.RequestData;
import logicole.common.servers.business.RequestWorkflowData;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.AssetMaintenanceProcedureService;
import logicole.gateway.services.asset.AssetScheduleService;
import logicole.gateway.services.asset.AssetService;
import logicole.gateway.services.asset.BusinessContactService;
import logicole.gateway.services.communications.CommunicationsSubmitRequestService;
import logicole.gateway.services.communications.CommunicationsTransmitService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.finance.FinanceAdminService;
import logicole.gateway.services.finance.FinanceDataMigrationService;
import logicole.gateway.services.finance.FinanceProcessingService;
import logicole.gateway.services.finance.FinanceReferenceDataService;
import logicole.gateway.services.finance.FinanceValidationService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.realproperty.InstallationService;
import logicole.gateway.services.realpropertyproject.ProjectService;
import logicole.gateway.services.realpropertyproject.RequirementService;
import logicole.gateway.services.realpropertysection.SectionService;
import logicole.gateway.services.report.ReportService;
import logicole.gateway.services.spacemanagement.DrawingService;
import logicole.gateway.services.spacemanagement.SpaceManagementService;
import logicole.gateway.services.system.NotificationService;
import logicole.gateway.services.system.TagService;
import logicole.gateway.services.user.UserService;
import logicole.gateway.services.workorder.formbuilder.CustomerComplaintRecordFormBuilder;
import logicole.gateway.services.workorder.formbuilder.DaForm4283FormBuilder;
import logicole.gateway.services.workorder.formbuilder.Navfac9WorkRequestFormBuilder;
import logicole.gateway.services.workorder.formbuilder.PreventativeMaintenanceWorkOrderFormBuilder;
import logicole.gateway.services.workorder.formbuilder.UnscheduledWorkRequestFormBuilder;
import logicole.gateway.services.workorder.formbuilder.WorkLoadSummaryFormBuilder;
import logicole.gateway.services.workorder.validator.CmmsExpenseCenterValidator;
import logicole.gateway.services.workorder.validator.CmmsInboundWorkOrderValidator;
import logicole.gateway.services.workorder.validator.CmmsOutboundWorkOrderValidator;
import logicole.gateway.services.workorder.validator.ServiceRequestDetailValidator;
import logicole.gateway.services.workorder.validator.ServiceRequestLocationValidator;
import logicole.gateway.services.workorder.validator.WorkOrderAssetValidator;
import logicole.gateway.services.workorder.validator.WorkOrderAssignmentEstimateValidator;
import logicole.gateway.services.workorder.validator.WorkOrderAssignmentValidator;
import logicole.gateway.services.workorder.validator.WorkOrderDetailValidator;
import logicole.gateway.services.workorder.validator.WorkOrderLocationValidator;
import logicole.gateway.services.workorder.validator.WorkOrderNonCatalogPartValidator;
import logicole.gateway.services.workorder.validator.WorkOrderQualityValidator;
import logicole.gateway.services.workorder.validator.WorkOrderRequirementLegacyValidator;
import logicole.gateway.services.workorder.validator.WorkOrderSectionValidator;
import logicole.gateway.services.workorder.validator.WorkOrderSpaceValidator;
import logicole.gateway.services.workorder.validator.WorkOrderStandardsValidator;
import logicole.gateway.services.workorder.workflow.WorkflowService;
import logicole.gateway.services.workorder.workflow.util.WorkOrderLegacyWorkflowUtil;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;
import java.io.IOException;
import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@ApplicationScoped
public class WorkOrderService extends BaseGatewayService<IWorkOrderMicroserviceApi> {

    public static final String PRIORITY_GROUP_EMERGENCY = "Emergency";
    public static final String PRIORITY_GROUP_URGENT = "Urgent";
    private static final String PRIORITY_GROUP_ROUTINE = "Routine";
    private static final String ROLE_FINAL_ACCEPTANCE_MANAGER = "5ffcb1a7b08c6a13da02d64f";
    public static final String CLASSIFICATION_TYPE_NAME_RECURRING_WORK = "Recurring Work";
    public static final String CLASSIFICATION_TYPE_NAME_SERVICE_REQUEST = "Service Request";
    private static final String INVALID_ATTACHMENT_MSG = "Attachment is missing or is not valid";
    public static final String MAXIMO_REQUESTER = "CMMS/MAXIMO";
    public static final String MAXIMO_CONTACT_NUMBER = "N/A";
    public static final String NO_WORK_ORDER_FOUND = "No WorkOrder found with id of %s";
    public static final String RQMT = " Rqmt %s";
    public static final String COMMODITYCODE_USAGETYPE = "Facility Management";

    public static final String NAVY_ORG_ID = "58d0581bdf121dce611b7197";
    public static final String ARMY_ORG_ID = "58d0581bdf121dce611b7186";
    public static final String AIR_FORCE_ORG_ID = "58d0581bdf121dce611b7140";
    private static final String COMMODITY_TYPE_LABOR = "Labor";
    private static final String COMMODITY_TYPE_MATERIAL = "Material";
    private static final String COMMODITY_TYPE_PARTS = "Parts";
    private static final String COMMODITY_ORG_NAVY = "Navy";
    private static final String COMMODITY_ORG_ARMY = "Army";
    private static final String COMMODITY_ORG_AIR_FORCE = "AirForce";
    private static final String  COMMODITY_FILTER_CODE = "Code";
    private static final String  COMMODITY_FILTER_TYPE = "Type";
    private static final String  COMMODITY_FILTER_COMMODITYTYPE = "commodityType";
    private static final String  COMMODITY_FILTER_NAME = "Name";
    private static final String  COMMODITY_FILTER_PROP_PREFIX = "MaximoCommodityFilter";

    private static final String  COMMODITY_MATERIAL_EORCODE_PROP = "DmlssRPCommodityMaterialCodes";
    private static final String  COMMODITY_LABOR_EORCODE_PROP = "DmlssRPCommodityLaborCodes";
    private static final String  COMMODITY_PARTS_EORCODE_PROP = "DmlssRPCommodityPartsCodes";
    public static final String FM_COMMODITY_USAGE_TYPE = "Facility Management";


    private HashMap<String, CommodityCodeRef> defaultCommodityCodeRefsForMaximo = new HashMap<>();
    private HashMap<String, String> maximoCommodityFilterProperties;

    @Inject
    private CmmsInboundWorkOrderValidator cmmsInboundWorkOrderValidator;
    @Inject
    private WorkOrderRequirementLegacyValidator workOrderRequirementLegacyValidator;
    @Inject
    private AssetMaintenanceProcedureService assetMaintenanceProcedureService;
    @Inject
    private AssetScheduleService assetScheduleService;
    @Inject
    private AssetService assetService;
    @Inject
    private BusinessContactService businessContactService;
    @Inject
    private CommunicationsTransmitService communicationsTransmitService;
    @Inject
    private FacilityService facilityService;
    @Inject
    private FileManagerAdminService fileManagerAdminService;
    @Inject
    private InstallationService installationService;
    @Inject
    private OrganizationService organizationService;
    @Inject
    private ProjectService projectService;
    @Inject
    private RequirementService requirementService;
    @Inject
    private SectionService sectionService;
    @Inject
    private SpaceManagementService spaceManagementService;
    @Inject
    private DrawingService drawingService;
    @Inject
    private TagService tagService;
    @Inject
    private UserService userService;
    @Inject
    private WorkflowService workflowService;
    @Inject
    private WorkOrderDetailValidator workOrderDetailValidator;
    @Inject
    private WorkOrderLocationValidator workOrderLocationValidator;
    @Inject
    private WorkOrderAssetValidator workOrderAssetValidator;
    @Inject
    private WorkOrderSpaceValidator workOrderSpaceValidator;
    @Inject
    private WorkOrderStandardsValidator workOrderStandardsValidator;
    @Inject
    private WorkOrderAssignmentEstimateValidator workOrderAssignmentEstimateValidator;
    @Inject
    private WorkOrderQualityValidator workOrderQualityValidator;
    @Inject
    private WorkOrderSectionValidator workOrderSectionValidator;
    @Inject
    private CmmsOutboundWorkOrderValidator cmmsOutboundWorkOrderValidator;
    @Inject
    private WorkOrderAssignmentValidator workOrderAssignmentValidator;
    @Inject
    private StringUtil stringUtil;
    @Inject
    private WorkOrderLegacyWorkflowUtil legacyWorkflowUtil;
    @Inject
    private UnscheduledWorkRequestFormBuilder unscheduledWorkRequestFormBuilder;
    @Inject
    private PreventativeMaintenanceWorkOrderFormBuilder preventativeMaintenanceWorkOrderFormBuilder;
    @Inject
    private Navfac9WorkRequestFormBuilder navfac9WorkRequestFormBuilder;
    @Inject
    private CustomerComplaintRecordFormBuilder customerComplaintRecordFormBuilder;
    @Inject
    private DaForm4283FormBuilder daForm4283FormBuilder;
    @Inject
    private CommunicationsSubmitRequestService communicationsSubmitRequestService;
    @Inject
    private WorkLoadSummaryFormBuilder workLoadSummaryFormBuilder;
    @Inject
    private ReportService reportService;
    @Inject
    private ServiceRequestLocationValidator serviceRequestLocationValidator;
    @Inject
    private ServiceRequestDetailValidator serviceRequestDetailValidator;
    @Inject
    private RequestData requestData;
    @Inject
    NotificationService notificationService;

    @Inject
    private FinanceAdminService financeAdminService;
    @Inject
    private FinanceReferenceDataService financeReferenceDataService;

    @Inject
    private FinanceDataMigrationService financeDataMigrationService;
    
    @Inject
    private FinanceProcessingService financeProcessingService;

    @Inject
    private FinanceValidationService financeValidationService;

    private HashMap<String, List<String>> dmlssEorCodes;

    public WorkOrderService() {
        super("WorkOrder");
    }

    public WorkOrder findById(String id) {
        WorkOrder workOrder = microservice.findById(id);
        if (workOrder == null) {
            throw new ApplicationException(String.format(NO_WORK_ORDER_FOUND, id));
        }
        validateWorkOrderUserAccess(workOrder);
        return workOrder;
    }

    private void validateWorkOrderFound(WorkOrder workOrder) {
        if (workOrder == null) {
            throw new ApplicationException("WorkOrder not found");
        }
    }

    private void initializeRequestWorkflowData(Date customDate) {
        this.initializeRequestWorkflowData(customDate, false, true);
    }

    private void initializeRequestWorkflowData(Date customDate,
                                               boolean customDateEqualsCurrentStepEntryDate,
                                               boolean customDateEqualsNextStepEntryDate) {
        if (customDate != null) {
            this.requestData.setRequestWorkflowData(
                    new RequestWorkflowData(customDate, customDateEqualsCurrentStepEntryDate, customDateEqualsNextStepEntryDate)
            );
        }
    }

    private void clearRequestWorkflowData() {
        this.requestData.setRequestWorkflowData(null);
    }

    private void addRequestWorkflowDataCustomInstruction(String customInstruction) {
        if (requestHasCustomDate()) {
            this.requestData.getRequestWorkflowData().addCustomInstruction(customInstruction);
        }
    }

    private boolean requestHasCustomDate() {
        return (this.requestData.hasRequestWorkflowData() && this.requestData.getRequestWorkflowData().getCustomDate() != null);
    }

    private void validateProjectRefPresent(WorkOrder workOrder) {
        if (workOrder.projectRef == null || StringUtil.isBlankOrNull(workOrder.projectRef.getId())) {
            throw new ApplicationException("Project not specified");
        }
    }

    private void validateWorkOrderUserAccess(@NotNull WorkOrder workOrder) {
        if (!isMDBUser() && !workOrder.managedByOrganizationRef.ancestry.contains(currentUserBT.getCurrentNodeId())) {
            throw new UnauthorizedException("Unauthorized access");
        }
    }

    private boolean isMDBUser() {
        return Objects.equals(currentUserBT.getCurrentUser().profile.pkiDn, SecurityConstants.MDB_SPECIAL_USER_PROFILE_KEY);
    }

    public List<WorkOrder> getWorkOrdersByRoomId(String roomId) {
        return microservice.getWorkOrdersByRoomId(roomId);
    }

    public long getWorkOrderCountInSpace(String spaceId, String spaceIdentifier) {
        return microservice.getWorkOrderCountInSpace(spaceId, spaceIdentifier);
    }

    public List<WorkOrderSummary> getWorkOrderSummariesBySchedule(String scheduleId) {
        return microservice.getWorkOrderSummariesBySchedule(scheduleId);
    }

    public List<WorkOrderSummary> getSortedWorkOrderSummariesBySchedule(String scheduleId) {
        List<WorkOrderSummary> workOrderSummaries = getWorkOrderSummariesBySchedule(scheduleId);
        if (!ListUtil.isEmpty(workOrderSummaries)) {
            workOrderSummaries.sort(Comparator.comparing(wo -> wo.estimatedStartDate));
        }
        return workOrderSummaries;
    }

    public void deleteWorkOrdersBySchedule(String scheduleId) {
        microservice.deleteWorkOrdersBySchedule(scheduleId);
    }

    public List<WorkOrder> findByIds(List<String> ids) {
        return microservice.findByIds(ids);
    }

    public PriorityGroup addPriorityGroup(PriorityGroup priorityGroup) {
        PriorityGroup foundPriorityGroup = microservice.getPriorityGroupByName(priorityGroup.name);
        if (foundPriorityGroup == null) {
            priorityGroup.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.addPriorityGroup(priorityGroup);
        } else {
            throw new ApplicationException("Priority Group already exists");
        }
    }

    public PriorityGroup updatePriorityGroup(PriorityGroup priorityGroup) {
        PriorityGroup foundPriorityGroup = microservice.getPriorityGroupById(priorityGroup.getId());
        if (foundPriorityGroup == null) {
            throw new ApplicationException("Assembly Category does not exist");
        } else {
            if (!foundPriorityGroup.name.equalsIgnoreCase(priorityGroup.name) && microservice.getPriorityGroupByName(priorityGroup.name) != null) {
                throw new ApplicationException("Priority Group already exists");
            } else {
                return microservice.updatePriorityGroup(priorityGroup);
            }
        }
    }

    public void deletePriorityGroup(PriorityGroup priorityGroup) {
        microservice.deletePriorityGroup(priorityGroup);
    }

    public List<PriorityGroup> getActivePriorityGroups() {
        return microservice.getActivePriorityGroups();
    }

    public List<PriorityGroup> getActiveServiceRequestPriorityGroups() {
        return microservice.getActiveServiceRequestPriorityGroups();
    }

    public List<PriorityGroup> getHigherPriorityGroups(Integer priority) {
        return microservice.getHigherPriorityGroups(priority);
    }

    public List<PriorityGroup> getLowerPriorityGroups(Integer priority) {
        return microservice.getLowerPriorityGroups(priority);
    }

    public List<Severity> getActiveSeverities() {
        return microservice.getActiveSeverities();
    }

    public List<SeverityRef> getActiveSeverityRefs() {
        return getActiveSeverities().stream().map(Severity::getRef).collect(Collectors.toList());
    }

    public ClassificationType addClassificationType(ClassificationType classificationType) {
        ClassificationType foundClassificationType = microservice.getClassificationTypeByName(classificationType.name);
        if (foundClassificationType == null) {
            classificationType.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.addClassificationType(classificationType);
        } else {
            throw new ApplicationException("Classification Type already exists");
        }
    }

    public ClassificationType updateClassificationType(ClassificationType classificationType) {
        ClassificationType foundClassificationType = microservice.getClassificationTypeById(classificationType.getId());
        if (foundClassificationType == null) {
            throw new ApplicationException("Classification Type does not exist");
        } else {
            if (!foundClassificationType.name.equalsIgnoreCase(classificationType.name) &&
                    microservice.getClassificationTypeByName(classificationType.name) != null) {
                throw new ApplicationException("Classification Type already exists");
            } else {
                return microservice.updateClassificationType(classificationType);
            }
        }
    }

    public void deleteClassificationType(ClassificationType classificationType) {
        microservice.deleteClassificationType(classificationType);
    }

    public List<ClassificationType> getActiveClassificationTypes() {
        return microservice.getActiveClassificationTypes();
    }

    public List<WorkOrder> createWorkOrdersForScheduleReplace(Schedule schedule) {
        return createWorkOrdersForSchedule(schedule, EWorkOrderAppendType.REPLACE_ALL_FUTURE_WORK_ORDERS);
    }

    public List<UnscheduledWorkRequestForm> generateUnscheduledWorkRequestForm(List<String> workOrderIds, boolean isWithActions, boolean isWithEquipment) {
        List<UnscheduledWorkRequestForm> reportData = new ArrayList<>();

        for (String workOrderId : workOrderIds) {
            WorkOrder workOrder = microservice.findById(workOrderId);
            List<Asset> assets = new ArrayList<>();

            if (workOrder.assetRefs != null && !workOrder.assetRefs.isEmpty()) {
                List<String> assetIds = new ArrayList<>();
                workOrder.assetRefs.forEach(assetRef -> assetIds.add(assetRef.id));
                assets = assetService.getAssetsByAssetIds(assetIds);
            }

            List<RoomSummary> rooms = new ArrayList<>();

            if (workOrder.spaceRefs != null && !workOrder.spaceRefs.isEmpty()) {
                List<String> roomIds = new ArrayList<>();
                workOrder.spaceRefs.stream().filter(spaceRef -> spaceRef.id != null).forEach(spaceRef -> roomIds.add(spaceRef.id));

                if (!roomIds.isEmpty()) {
                    rooms = spaceManagementService.getRoomSummariesByIds(roomIds);
                }
            }


            UnscheduledWorkRequestForm report = unscheduledWorkRequestFormBuilder.buildReport(workOrder, assets, rooms, isWithActions, isWithEquipment);

            if (workOrder.siteRef != null && workOrder.siteRef.id != null) {
                report.installation = installationService.getInstallationForSite(workOrder.siteRef.id).name;
            }

            reportData.add(report);
        }

        return reportData;
    }

    public List<PreventativeMaintenanceWorkOrderForm> generatePreventativeMaintenanceWorkRequestForm(WorkOrderReport workOrderReport) {
        List<PreventativeMaintenanceWorkOrderForm> reportData = new ArrayList<>();

        for (String workOrderId : workOrderReport.workOrderIds) {
            WorkOrder workOrder = microservice.findById(workOrderId);
            List<Asset> assets = new ArrayList<>();
            Schedule schedule = null;
            MaintenanceProcedure procedure = null;

            if (workOrder.scheduleRef != null && workOrder.scheduleRef.id != null) {
                schedule = assetScheduleService.findScheduleById(workOrder.scheduleRef.id);
            }

            if (schedule != null && schedule.maintenanceProcedureRef != null && schedule.maintenanceProcedureRef.id != null) {
                procedure = assetMaintenanceProcedureService.findById(schedule.maintenanceProcedureRef.id);
            }

            if (workOrder.assetRefs != null && !workOrder.assetRefs.isEmpty()) {
                List<String> assetIds = new ArrayList<>();
                workOrder.assetRefs.forEach(assetRef -> assetIds.add(assetRef.id));
                assets = assetService.getAssetsByAssetIds(assetIds);
            }

            List<WorkOrder> associateWorkOrders = microservice.getAssociateWorkOrders(workOrderId);
            PreventativeMaintenanceWorkOrderForm report = preventativeMaintenanceWorkOrderFormBuilder.buildReport(workOrder, schedule, procedure, assets, associateWorkOrders, workOrderReport);

            if (workOrder.siteRef != null && workOrder.siteRef.id != null) {
                report.installation = installationService.getInstallationForSite(workOrder.siteRef.id).name;
            }

            reportData.add(report);
        }

        return reportData;
    }

    public List<Navfac9WorkRequestForm> generateNavfac9WorkRequestForm(List<String> workOrderIds) {
        List<Navfac9WorkRequestForm> reportData = new ArrayList<>();

        for (String workOrderId : workOrderIds) {
            WorkOrder workOrder = microservice.findById(workOrderId);
            List<Space> rooms = new ArrayList<>();

            if (workOrder.spaceRefs != null && !workOrder.spaceRefs.isEmpty()) {
                List<String> roomIds = new ArrayList<>();
                workOrder.spaceRefs.stream().filter(spaceRef -> spaceRef.id != null).forEach(spaceRef -> roomIds.add(spaceRef.id));

                if (!roomIds.isEmpty()) {
                    rooms = spaceManagementService.getRoomsByIds(roomIds);
                }
            }

            Navfac9WorkRequestForm report = navfac9WorkRequestFormBuilder.buildReport(workOrder, rooms);

            if (workOrder.siteRef != null && workOrder.siteRef.id != null) {
                report.installation = installationService.getInstallationForSite(workOrder.siteRef.id).name;
            }

            reportData.add(report);
        }

        return reportData;
    }

    public ExportFileInfo generateWorkLoadSummaryForm(List<String> workOrderIds) {
        if (workOrderIds == null || workOrderIds.isEmpty()) {
            throw new ApplicationException("At least one work order is required.");
        }

        List<WorkOrder> workOrders = microservice.findByIds(workOrderIds);
        Installation installation = null;
        populateSiteRefsForWorkOrders(workOrders);

        if (workOrders != null && !workOrders.isEmpty() && workOrders.get(0).siteRef != null
                && workOrders.get(0).siteRef.id != null) {
            installation = installationService.getInstallationForSite(workOrders.get(0).siteRef.id);
        }

        ReportContainer reportContainer = workLoadSummaryFormBuilder.buildReport(workOrders, installation);
        return reportService.generateReport(reportContainer);
    }

    private void populateSiteRefsForWorkOrders(List<WorkOrder> workOrders) {
        if (workOrders != null && !workOrders.isEmpty()) {
            List<String> facilityIds = new ArrayList<>();
            Map<String, List<WorkOrder>> facilityToWorkOrder = createFacilityToWorkOrderMap(workOrders);
            facilityToWorkOrder.entrySet().forEach(entry -> facilityIds.add(entry.getKey()));
            List<Facility> facilities = facilityService.getFacilitiesByIds(facilityIds);

            for (Facility facility : facilities) {
                List<WorkOrder> facilityWorkOrders = facilityToWorkOrder.get(facility.getId());

                if (facilityWorkOrders != null && !facilityWorkOrders.isEmpty()) {
                    for (WorkOrder workOrder : facilityWorkOrders) {
                        workOrder.siteRef = facility.siteRef;
                    }
                }
            }
        }
    }

    private Map<String, List<WorkOrder>> createFacilityToWorkOrderMap(List<WorkOrder> workOrders) {
        Map<String, List<WorkOrder>> facilityToWorkOrder = new HashMap<>();

        for (WorkOrder workOrder : workOrders) {
            String facilityId = workOrder.facilityRef != null ? workOrder.facilityRef.id : null;

            if (facilityId != null) {
                List<WorkOrder> facilityWorkOrders = facilityToWorkOrder.get(facilityId);

                if (facilityWorkOrders == null) {
                    facilityWorkOrders = new ArrayList<>();
                    facilityToWorkOrder.put(workOrder.facilityRef.id, facilityWorkOrders);
                }

                facilityWorkOrders.add(workOrder);
            }
        }

        return facilityToWorkOrder;
    }

    public List<CostumerComplaintRecordForm> generateCustomerComplaintRecordForm(List<String> workOrderIds) {
        List<CostumerComplaintRecordForm> reportData = new ArrayList<>();

        for (String workOrderId : workOrderIds) {
            WorkOrder workOrder = microservice.findById(workOrderId);
            List<Space> rooms = new ArrayList<>();

            if (workOrder.spaceRefs != null && !workOrder.spaceRefs.isEmpty()) {
                List<String> roomIds = new ArrayList<>();
                workOrder.spaceRefs.stream().filter(spaceRef -> spaceRef.id != null).forEach(spaceRef -> roomIds.add(spaceRef.id));

                if (!roomIds.isEmpty()) {
                    rooms = spaceManagementService.getRoomsByIds(roomIds);
                }
            }

            CostumerComplaintRecordForm report = customerComplaintRecordFormBuilder.buildReport(workOrder, rooms);

            if (workOrder.siteRef != null && workOrder.siteRef.id != null) {
                report.installation = installationService.getInstallationForSite(workOrder.siteRef.id).name;
            }

            reportData.add(report);
        }

        return reportData;
    }

    public List<DaForm4283Form> generateDaForm4283Form(List<String> workOrderIds) {
        List<DaForm4283Form> reportData = new ArrayList<>();
        List<WorkOrder> workOrders = microservice.findByIds(workOrderIds);

        for (WorkOrder workOrder : workOrders) {
            Installation installation = null;

            if (workOrder.siteRef != null && workOrder.siteRef.id != null) {
                installation = installationService.getInstallationForSite(workOrder.siteRef.id);
            }

            DaForm4283Form report = daForm4283FormBuilder.buildReport(workOrder, installation);
            reportData.add(report);
        }

        return reportData;
    }

    public List<WorkOrder> generateWorkOrdersForReplace(Schedule schedule) {
        List<WorkOrder> workOrderList =  microservice.generateWorkOrdersForReplace(schedule);
        processEstimatedCostsFinanceRequest(null, workOrderList, WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_ADD, null, true);
        return workOrderList;
    }

    public List<WorkOrder> createWorkOrdersForScheduleAppend(Schedule schedule) {
        return createWorkOrdersForSchedule(schedule, EWorkOrderAppendType.APPEND_TO_EXISTING_FUTURE_WORK_ORDERS);
    }

    private List<WorkOrder> createWorkOrdersForSchedule(Schedule schedule, EWorkOrderAppendType workOrderAppendType) {
        List<WorkOrder> newWorkOrders = generateWorkOrders(schedule, workOrderAppendType);
        newWorkOrders.forEach(workOrder -> {
            workflowService.startAction(workOrder, EWorkflowName.STANDARD_WORK_ORDER.displayText, currentUserBT.getCurrentUser().profile.currentNodeRef);
        });
        if (schedule.maintenanceProcedureRef.frequencyRef.rollupPriority != null) {
            checkForHigherPriorityWorkOrdersAndMark(newWorkOrders, schedule);
            checkForLowerPriorityWorkOrdersToUpdate(newWorkOrders, schedule);
        }

        List<WorkOrder> workOrderList = saveWorkOrders(newWorkOrders);
        return workOrderList;
    }

    private void decommitEstimateCosts(WorkOrder workOrder) {
        financeProcessEstimateCosts(workOrder, false);
    }

    private void financeProcessEstimateCosts(WorkOrder workOrder, boolean isCommit) {
        if ( workOrder == null || ListUtil.isEmpty(workOrder.assignments)) {
            return;
        }

        List<WorkOrderFinanceRequestFundInfo> estimatedFundList = new ArrayList<>();

        for (Assignment assignment : workOrder.assignments) {
            if (assignment != null && assignment.estimatedCosts != null) {
                addFundsToList(assignment.estimatedCosts, estimatedFundList,
                        isCommit? WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_ADD : WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_DECOMMITED, false);
            }
        }

        if (!ListUtil.isEmpty(estimatedFundList)) {
            EBusinessEventType eventType = isCommit? EBusinessEventType.FM_WORK_ORDER_ESTIMATE_INCREASE : EBusinessEventType.FM_WORK_ORDER_ESTIMATE_DECREASE;

            CommonFinanceRequest financeRequest = createFinanceRequest(workOrder, eventType, estimatedFundList);
            if (financeRequest != null) {
                financeProcessingService.processFinanceRequest(financeRequest);
            }

            // record business event history
            recordBusinessEvents(workOrder, null, null, estimatedFundList, isCommit? EBusinessEventType.FM_WORK_ORDER_ESTIMATE_INCREASE : EBusinessEventType.FM_WORK_ORDER_ESTIMATE_DECREASE);
        }
    }

    public void processActualCostFinanceRequest(List<WorkOrder> workOrderList) {
        if (ListUtil.isEmpty(workOrderList)) {
            return;
        }

        for (WorkOrder workOrder : workOrderList) {
            if (workOrder.workflowState == null
                    || (workOrder.workflowState.currentPosition != EWorkflowStepName.CLOSED.position)
                    || ListUtil.isEmpty(workOrder.assignments)) {
                continue;
            }

            EBusinessEventType eventType = null;
            List<CommonFinanceRequest>  financeRequestList = new ArrayList<>();
            List<WorkOrderFinanceRequestFundInfo> decreasedEstimatedFundList = new ArrayList<>();
            List<WorkOrderFinanceRequestFundInfo> increasedActualFundList = new ArrayList<>();

            for (Assignment assignment : workOrder.assignments) {
                if (assignment.estimatedCosts != null) {
                    addFundsToList(assignment.estimatedCosts, decreasedEstimatedFundList,
                            WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_DECOMMITED, false);
                }

                if (!ListUtil.isEmpty(assignment.actualCosts)) {
                    for(ActualCost actualCost : assignment.actualCosts ) {
                        addFundsToList(actualCost.costSummary, increasedActualFundList,
                                WorkOrderBusinessEvent.ACTION_ACTUAL_COST_OBLIGATED, true);
                    }
                }
            }

            if (!ListUtil.isEmpty(decreasedEstimatedFundList)) {
                eventType = EBusinessEventType.FM_WORK_ORDER_ESTIMATE_DECREASE;
                CommonFinanceRequest financeRequest = createFinanceRequest(workOrder, eventType, decreasedEstimatedFundList);
                if (financeRequest != null) {
                    financeRequestList.add(financeRequest);
                }
            }

            if (!ListUtil.isEmpty(increasedActualFundList)) {
                eventType = EBusinessEventType.FM_WORK_ORDER_ACTUAL_INCREASE;
                CommonFinanceRequest financeRequest = createFinanceRequest(workOrder, eventType, increasedActualFundList);
                if (financeRequest != null) {
                    financeRequestList.add(financeRequest);
                }
            }

            for (CommonFinanceRequest financeRequest : financeRequestList) {
                financeProcessingService.processFinanceRequest(financeRequest);
            }

            // record business event history
            recordBusinessEvents(workOrder, increasedActualFundList, EBusinessEventType.FM_WORK_ORDER_ACTUAL_INCREASE, decreasedEstimatedFundList, EBusinessEventType.FM_WORK_ORDER_ESTIMATE_DECREASE);

        }
    }

    public List<String> processEstimatedCostsFinanceRequest(List<WorkOrder> oldWorkOrderList, List<WorkOrder> newWorkOrderList, String eventAction, Assignment assignment, boolean isLastAssignment) {
        List<String> financeMessages = new ArrayList<>();

        if ( WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_REMOVE.equals(eventAction) ) {
            if ( assignment != null ) {
                if ( !ListUtil.isEmpty(newWorkOrderList)) {
                    for (WorkOrder wo : newWorkOrderList) {
                        if (wo.workflowState != null &&
                                (wo.workflowState.currentPosition == EWorkflowStepName.CLOSED.position) &&
                                (wo.workflowState.currentPosition == EWorkflowStepName.SCHEDULED.position)) {
                            continue;
                        }
                        financeMessages.addAll(processWOEstimatedFinanceRequest(wo, null, assignment, eventAction));
                    }
                }
            } else {
                //???
                if ( !ListUtil.isEmpty(oldWorkOrderList)) {
                    for (WorkOrder wo : oldWorkOrderList) {
                        if (wo.workflowState != null &&
                                (wo.workflowState.currentPosition == EWorkflowStepName.CLOSED.position) &&
                                (wo.workflowState.currentPosition == EWorkflowStepName.SCHEDULED.position)) {
                            continue;
                        }
                        if ( !ListUtil.isEmpty(wo.assignments)) {
                            for ( Assignment removedAssign : wo.assignments) {
                                financeMessages.addAll(processWOEstimatedFinanceRequest(wo, null, removedAssign, eventAction));
                            }
                        }
                    }
                }
            }

        } else {
            if ( !ListUtil.isEmpty(newWorkOrderList)) {
                int index = 0;
                for (WorkOrder wo : newWorkOrderList) {
                    if (wo.workflowState != null &&
                            (wo.workflowState.currentPosition == EWorkflowStepName.CLOSED.position) &&
                            (wo.workflowState.currentPosition == EWorkflowStepName.SCHEDULED.position)) {
                        continue;
                    }
                    Assignment newAssignment = assignment;
                    Assignment oldAssignment = null;

                    if ( newAssignment == null && !ListUtil.isEmpty(wo.assignments)) {
                        if ( isLastAssignment ) {
                            newAssignment = wo.assignments.get( wo.assignments.size()-1);
                        } else {
                            newAssignment = wo.assignments.get(0);
                        }
                    }

                    if ( newAssignment != null && newAssignment.estimatedCosts != null) {
                        if ( WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_UPDATE.equals(eventAction) ) {
                            final String assignmentId = newAssignment.assignmentId;
                            oldAssignment = oldWorkOrderList.get(index).assignments.stream().filter(item -> Objects.equals(item.assignmentId, assignmentId)).findFirst().get();
                        }
                        financeMessages.addAll(processWOEstimatedFinanceRequest(wo,  newAssignment, oldAssignment, eventAction));
                    }

                    index++;
                }
            }
        }

        return financeMessages;
    }

    private List<String> processWOEstimatedFinanceRequest(WorkOrder workOrder, Assignment newAssignment, Assignment oldAssignment,  String eventAction ) {
        if ( oldAssignment == null && newAssignment == null )
            return new ArrayList<>();

        List<WorkOrderFinanceRequestFundInfo> increasedFundList = new ArrayList<>();
        List<WorkOrderFinanceRequestFundInfo> decreasedFundList = new ArrayList<>();

        List<String> financeMessages = new ArrayList<>();
        List<CommonFinanceRequest>  financeRequestList = new ArrayList<>();

        CostSummary estimatedCosts;
        if ( WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_REMOVE.equals(eventAction) ) {
            if ( oldAssignment != null && oldAssignment.estimatedCosts != null ) {
                estimatedCosts = oldAssignment.estimatedCosts;
                addFundsToList(estimatedCosts, decreasedFundList, eventAction, false);
            }
        }
        else if ( WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_ADD.equals(eventAction) ) {
            if ( newAssignment != null && newAssignment.estimatedCosts != null ) {
                estimatedCosts = newAssignment.estimatedCosts;
                addFundsToList(estimatedCosts, increasedFundList, eventAction, true);
            }
        }
        else if ( WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_UPDATE.equals(eventAction) ) {
            // Fortify note: leave this as two if statements to avoid redundant null check.
            if ( newAssignment != null && oldAssignment != null) {
                if (newAssignment.estimatedCosts != null && oldAssignment.estimatedCosts != null) {
                    CostSummary newEstimatedCosts = newAssignment.estimatedCosts;
                    CostSummary oldEstimatedCosts = oldAssignment.estimatedCosts;
                    addUpdatedFundsToList(newEstimatedCosts.laborFunding, oldEstimatedCosts.laborFunding, newEstimatedCosts.labor, oldEstimatedCosts.labor, WorkOrderFinanceRequestFundInfo.FUND_TYPE_LABOR, increasedFundList, decreasedFundList);
                    addUpdatedFundsToList(newEstimatedCosts.materialFunding, oldEstimatedCosts.materialFunding, newEstimatedCosts.material, oldEstimatedCosts.material, WorkOrderFinanceRequestFundInfo.FUND_TYPE_MATERIAL, increasedFundList, decreasedFundList);
                    addUpdatedFundsToList(newEstimatedCosts.partsFunding, oldEstimatedCosts.partsFunding, newEstimatedCosts.parts, oldEstimatedCosts.parts, WorkOrderFinanceRequestFundInfo.FUND_TYPE_PARTS, increasedFundList, decreasedFundList);
                }
            }
        }

        if ( !ListUtil.isEmpty(decreasedFundList)) {
            decreasedFundList.forEach(decreasedFund -> {
                CommonFinanceRequest financeRequest = createFinanceRequest(workOrder, EBusinessEventType.FM_WORK_ORDER_ESTIMATE_DECREASE, Collections.singletonList(decreasedFund));
                if ( financeRequest != null ) {
                    financeRequestList.add(financeRequest);
                }
            });
        }

        if ( !ListUtil.isEmpty(increasedFundList)) {
            increasedFundList.forEach(increasedFund -> {
                CommonFinanceRequest financeRequest = createFinanceRequest(workOrder, EBusinessEventType.FM_WORK_ORDER_ESTIMATE_INCREASE, Collections.singletonList(increasedFund));
                if (financeRequest != null) {
                    financeRequestList.add(financeRequest);
                }
            });
    	}
 
    	for( CommonFinanceRequest financeRequest : financeRequestList ) {
    		if ( isCurrentEstimatedFund(financeRequest, (newAssignment != null ? newAssignment : oldAssignment)) ) {
    			financeMessages.addAll(financeValidationService.validateRequest(financeRequest));
    		}
    		financeProcessingService.processFinanceRequest(financeRequest);
    	}
    
        recordBusinessEvents(workOrder, increasedFundList, EBusinessEventType.FM_WORK_ORDER_ESTIMATE_INCREASE, decreasedFundList, EBusinessEventType.FM_WORK_ORDER_ESTIMATE_DECREASE);

        return financeMessages;
    }

    private boolean isCurrentEstimatedFund(CommonFinanceRequest financeRequest, Assignment currentAssignment) {
        if ( currentAssignment == null ||  currentAssignment.estimatedCosts == null ) {
            return false;
        }

        List<String> funds = financeRequest.requestGroups.stream().filter(rg -> rg.fundingNodeRef != null).map(rg -> rg.fundingNodeRef.id).collect(Collectors.toList());
        List<String> currentFundList = new ArrayList<>();

        currentFundList.addAll(getIdsFromFunding(currentAssignment.estimatedCosts.laborFunding));
        currentFundList.addAll(getIdsFromFunding(currentAssignment.estimatedCosts.materialFunding));
        currentFundList.addAll(getIdsFromFunding(currentAssignment.estimatedCosts.partsFunding));

        return funds.stream().anyMatch(currentFundList::contains);
    }

    private List<String> getIdsFromFunding(RealPropertyFunding funding) {
        List<String> ids = new ArrayList<>();
        if (funding != null) {
            if (funding.projectFundingNodeRef != null && !StringUtil.isEmptyOrNull(funding.projectFundingNodeRef.id)) {
                ids.add(funding.projectFundingNodeRef.id);
            }
            if (funding.expenseFundingNodeRef != null && !StringUtil.isEmptyOrNull(funding.expenseFundingNodeRef.id)) {
                ids.add(funding.expenseFundingNodeRef.id);
            }
        }
        return ids;
    }
    
    private void recordBusinessEvents(WorkOrder workOrder, List<WorkOrderFinanceRequestFundInfo> increasedFundList,
                                      EBusinessEventType increasedFundEventType, List<WorkOrderFinanceRequestFundInfo> decreasedFundList,
                                      EBusinessEventType decreasedFundEventType) {
        if ( !ListUtil.isEmpty(decreasedFundList)) {
            recordBusinessEvent(workOrder, decreasedFundList,  decreasedFundEventType);
        }

        if ( !ListUtil.isEmpty(increasedFundList)) {
            recordBusinessEvent(workOrder, increasedFundList,  increasedFundEventType);
        }
    }

    private void recordBusinessEvent(WorkOrder workOrder, List<WorkOrderFinanceRequestFundInfo> fundList, EBusinessEventType eventType) {
        String workOrderId = workOrder.getId();
        WorkOrderRef workOrderRef = workOrder.getRef();

        for (WorkOrderFinanceRequestFundInfo fundInfo : fundList  ) {
            WorkOrderBusinessEvent event = new WorkOrderBusinessEvent();
            event.action = fundInfo.action;
            event.workOrderRef = workOrderRef;
            event.realPropertyProjectFund = fundInfo.fund;
            event.transactionalAmount = fundInfo.transactionalAmount;
            event.fundType = fundInfo.fundType;
            event.woFundingFiscalYear = workOrder.fundingFiscalYear;
            event.woSubject = workOrder.subject;
            event.woLegacyNumber = workOrder.dmlssWorkRequestNumber;
            event.woSiteRef = workOrder.siteRef;
            event.woFacilityRef = workOrder.facilityRef;
            event.woClassificationTypeRef = workOrder.classificationTypeRef;
            event.woRequestDate = workOrder.requestDate;
            if (workOrder.workflowState != null && workOrder.workflowState.currentStep != null
                    && !StringUtil.isEmptyOrNull(workOrder.workflowState.currentStep.name)) {
                event.woWorkflowStepName = workOrder.workflowState.currentStep.name;
            }
            microservice.saveFundUpdateBusinessEvent(workOrderId, eventType.name(), event);
        }
    }

    private CommonFinanceRequest createFinanceRequest(WorkOrder workOrder, EBusinessEventType eventType, List<WorkOrderFinanceRequestFundInfo> fundList) {
        if ( workOrder == null || StringUtil.isEmptyOrNull(workOrder.getId()) || ListUtil.isEmpty(fundList) ) {
            return null;
        }

        //Building the finance request
        CommonFinanceRequest financeRequest = new CommonFinanceRequest();
        financeRequest.eventType = eventType;
        financeRequest.sourceType = "N/A"; //  from FinanceDecision.financeDecisionCriteria.sourceType
        financeRequest.requestingOrg = workOrder.managedByOrganizationRef;
        financeRequest.financialSystem = null;

        financeRequest.requestGroups = new ArrayList<>();

        for ( WorkOrderFinanceRequestFundInfo fundInfo : fundList ) {
            if ( fundInfo.fund != null && fundInfo.fund.expenseFundingNodeRef != null ) {
                financeRequest.requestGroups.add(createRequestGroup(workOrder, fundInfo.fund, fundInfo.transactionalAmount));
            }
        }

        return financeRequest;
    }

    private RequestGroup createRequestGroup(WorkOrder workOrder, RealPropertyFunding rpFunding,  MonetaryValue amount) {
        RequestGroup requestGroup = new RequestGroup();
        // get te fundingNodeRef..
        FundingNodeRef fundingNodeRef = new FundingNodeRef();
        requestGroup.fundingNodeRef = rpFunding.expenseFundingNodeRef;
        requestGroup.currentNodeRef = workOrder.managedByOrganizationRef;
        requestGroup.buyerRef = null;
        requestGroup.orderInformationRef = null;
        requestGroup.purchaseCardRef = null;
        requestGroup.throwExceptionOnError = true;
        requestGroup.overrideFundsAvailabilityCheck = true;

        requestGroup.items = new ArrayList<>();
        FinanceItem financeItem = new FinanceItem();
        financeItem.quantity = 1;
        financeItem.amount = amount;
        financeItem.documentNumber = workOrder.workOrderNumber;
        financeItem.lineNumber = 1;
        financeItem.fiscalYear = workOrder.fundingFiscalYear.trim();
        financeItem.product = null;
        financeItem.item = null;
        financeItem.catalog = null;
        financeItem.isReimbursable = true;
        financeItem.isReversal = false;
        financeItem.isStocked = false;
        financeItem.commodityCodeRef = rpFunding.commodityCodeRef;

        FmFinanceItem fmFinanceItem = new FmFinanceItem();
        fmFinanceItem.projectNumber = "";
        fmFinanceItem.workRequirementNumber = workOrder.workOrderNumber;
        fmFinanceItem.contractNumber = "";
        financeItem.fmFinanceItem = fmFinanceItem;

        requestGroup.items.add(financeItem);


        return requestGroup;
    }

    private void addUpdatedFundsToList(RealPropertyFunding newFunding, RealPropertyFunding oldFunding,
                                       MonetaryValue newCosts, MonetaryValue oldCosts, String fundType, List<WorkOrderFinanceRequestFundInfo> increasedFundList,
                                       List<WorkOrderFinanceRequestFundInfo> decreasedFundList) {
        MonetaryValue deltaValue;
        MonetaryValue zero = new MonetaryValue("0.0");

        if ( newCosts == null ) {
            newCosts = MonetaryValue.ZERO;
        }

        if ( oldCosts == null ) {
            oldCosts = MonetaryValue.ZERO;
        }
        if (isSameFund(newFunding, oldFunding) ) {
            if ( newCosts.compareTo(oldCosts) != 0 ) {
                if ( newCosts.compareTo(oldCosts) > 0 ) {
                    deltaValue = newCosts.subtract(oldCosts);
                    increasedFundList.add(new WorkOrderFinanceRequestFundInfo (newFunding, deltaValue, true,  WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_UPDATE, fundType) );
                } else {
                    deltaValue = oldCosts.subtract(newCosts);
                    decreasedFundList.add(new WorkOrderFinanceRequestFundInfo (newFunding, deltaValue, false,  WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_UPDATE, fundType) );
                }
            }
        } else {
            if ( newCosts.compareTo(zero) > 0 ) {
                increasedFundList.add(new WorkOrderFinanceRequestFundInfo (newFunding, newCosts, true,  WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_UPDATE, fundType) );
            }
            if ( oldCosts.compareTo(zero) > 0 ) {
                decreasedFundList.add(new WorkOrderFinanceRequestFundInfo (oldFunding, oldCosts, false,  WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_UPDATE, fundType) );

            }
        }
    }

    private boolean isSameFund(RealPropertyFunding oneFund, RealPropertyFunding fund) {
        return oneFund != null && fund != null && oneFund.projectFundingNodeRef.equals(fund.projectFundingNodeRef)
                && oneFund.expenseFundingNodeRef.equals(fund.expenseFundingNodeRef)
                && oneFund.commodityCodeRef.equals(fund.commodityCodeRef);
    }

    private void addFundsToList(CostSummary costs, List<WorkOrderFinanceRequestFundInfo> fundList, String eventAction, boolean isIncrease) {
        MonetaryValue zero = new MonetaryValue("0.0");

        if (costs != null && costs.labor != null && costs.labor.compareTo(zero) > 0) {
            fundList.add(new WorkOrderFinanceRequestFundInfo(costs.laborFunding, costs.labor, isIncrease, eventAction, WorkOrderFinanceRequestFundInfo.FUND_TYPE_LABOR));
        }
        if (costs != null && costs.material != null && costs.material.compareTo(zero) > 0) {
            fundList.add(new WorkOrderFinanceRequestFundInfo(costs.materialFunding, costs.material, isIncrease, eventAction, WorkOrderFinanceRequestFundInfo.FUND_TYPE_MATERIAL));
        }
        if (costs != null && costs.parts != null && costs.parts.compareTo(zero) > 0) {
            fundList.add(new WorkOrderFinanceRequestFundInfo(costs.partsFunding, costs.parts, isIncrease, eventAction, WorkOrderFinanceRequestFundInfo.FUND_TYPE_PARTS));
        }
    }

    private List<WorkOrder> generateWorkOrders(Schedule schedule, EWorkOrderAppendType workOrderAppendType) {
        List<WorkOrder> workOrders;
        schedule.managedByOrganizationRef = this.currentUserBT.getCurrentUser().profile.currentNodeRef;

        if (EWorkOrderAppendType.REPLACE_ALL_FUTURE_WORK_ORDERS.equals(workOrderAppendType)) {
            workOrders = microservice.generateWorkOrdersForReplace(schedule);
        } else if (EWorkOrderAppendType.APPEND_TO_EXISTING_FUTURE_WORK_ORDERS.equals(workOrderAppendType)) {
            workOrders = microservice.generateWorkOrdersForAppend(schedule);
        } else {
            throw new ApplicationException("Invalid workOrderAppendType");
        }
        return workOrders;
    }

    protected void checkForHigherPriorityWorkOrdersAndMark(List<WorkOrder> newWorkOrders, Schedule schedule) {
        if (!ListUtil.isEmpty(schedule.assetRefs)) {
            List<WorkOrder> higherPriorityWorkOrders = microservice.getHigherPriorityWorkOrders(schedule);
            newWorkOrders.forEach(newWorkOrder -> newWorkOrder.isRolledUp = isCoveredByHigherPriorityWorkOrder(newWorkOrder, higherPriorityWorkOrders));
        } else {
            newWorkOrders.forEach(newWorkOrder -> newWorkOrder.isRolledUp = false);
        }
    }

    protected boolean isCoveredByHigherPriorityWorkOrder(WorkOrder workOrder, List<WorkOrder> higherPriorityWorkOrders) {
        return higherPriorityWorkOrders.stream()
                .anyMatch(higherPriorityWorkOrder -> workOrder.maintenanceProcedureRef.frequencyRef.rollupPriority != null
                        && DateUtil.isSameMonthAndYear(workOrder.estimatedStartDate, higherPriorityWorkOrder.estimatedStartDate));
    }

    protected void checkForLowerPriorityWorkOrdersToUpdate(List<WorkOrder> newWorkOrders, Schedule schedule) {
        if (!ListUtil.isEmpty(schedule.assetRefs)) {
            List<WorkOrder> lowerPriorityWorkOrdersToUpdate = new ArrayList<>();
            List<WorkOrder> lowerPriorityWorkOrders = microservice.getLowerPriorityWorkOrders(schedule);
            lowerPriorityWorkOrders.forEach(lowerPriorityWorkOrder -> {
                // Not assigning the return value directly to isRolledUp in case it's rolled up from another higher priority work order
                if (!lowerPriorityWorkOrder.isRolledUp && isCoveredByHigherPriorityWorkOrder(lowerPriorityWorkOrder, newWorkOrders)) {
                    lowerPriorityWorkOrder.isRolledUp = true;
                    lowerPriorityWorkOrdersToUpdate.add(lowerPriorityWorkOrder);
                }
            });
            saveWorkOrders(lowerPriorityWorkOrdersToUpdate);
        }
    }

    public List<WorkOrder> saveWorkOrders(List<WorkOrder> workOrders) {
        return microservice.saveWorkOrders(workOrders);
    }

    public WorkOrder saveWorkOrder(WorkOrder workOrder) {
        return microservice.saveWorkOrder(workOrder);
    }

    public void deleteScheduleWorkOrders(Schedule schedule) {
        deleteWorkOrdersBySchedule(schedule.getId());
        if (schedule.maintenanceProcedureRef.frequencyRef.rollupPriority != null) {
            updateWorkOrderRollUpAffectedByScheduleDelete(schedule);
        }
    }

    public void deleteWorkOrders(List<String> ids) {
        microservice.deleteWorkOrders(ids);
    }

    protected void updateWorkOrderRollUpAffectedByScheduleDelete(Schedule scheduleToDelete) {
        if (scheduleToDelete.assetRefs == null || scheduleToDelete.assetRefs.isEmpty()) {
            return;
        }
        List<WorkOrder> relatedWorkOrders = microservice.getRelatedWorkOrders(scheduleToDelete);
        relatedWorkOrders.forEach(workOrder -> {
            if (hasRollupPriority(workOrder)) {
                List<WorkOrder> higherPriorityWorkOrders = getHigherPriorityWorkOrders(workOrder.maintenanceProcedureRef.frequencyRef.rollupPriority, relatedWorkOrders);
                workOrder.isRolledUp = isCoveredByHigherPriorityWorkOrder(workOrder, higherPriorityWorkOrders);
            }
        });
        microservice.saveWorkOrders(relatedWorkOrders);
    }

    private boolean hasRollupPriority(WorkOrder workOrder) {
        return workOrder != null && workOrder.maintenanceProcedureRef != null && workOrder.maintenanceProcedureRef.frequencyRef != null &&
                workOrder.maintenanceProcedureRef.frequencyRef.rollupPriority != null;
    }

    protected List<WorkOrder> getHigherPriorityWorkOrders(int rollupPriority, List<WorkOrder> workOrders) {
        return workOrders.stream().filter(workOrder -> hasRollupPriority(workOrder) && workOrder.maintenanceProcedureRef.frequencyRef.rollupPriority < rollupPriority).collect(Collectors.toList());
    }

    public Integer getMaxUploadSize() {
        return microservice.getMaxUploadSize();
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }

    public FileManager uploadFileWithCustomValues(byte[] fileContent,
                                                  String uploadedFileName,
                                                  String uploadedByUserId,
                                                  Date uploadedDateTime) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManagedWithCustomValues(
                    fileContent,
                    uploadedFileName,
                    uploadedByUserId,
                    uploadedDateTime);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }

    public Attachment saveAttachment(String id, Attachment attachmentToSave) {
        if (attachmentToSave == null ||
                attachmentToSave.fileRef == null ||
                (StringUtil.isBlankOrNull(attachmentToSave.fileRef.id) && StringUtil.isBlankOrNull(attachmentToSave.fileRef.fileId))) {
            throw new ApplicationException(INVALID_ATTACHMENT_MSG);
        }

        String theFileId = (!StringUtil.isBlankOrNull(attachmentToSave.fileRef.id) ? attachmentToSave.fileRef.id : attachmentToSave.fileRef.fileId);

        FileRef theFileRef;
        if (!StringUtil.isBlankOrNull(attachmentToSave.fileRef.filePath)) {
            theFileRef = attachmentToSave.fileRef;
        } else {
            theFileRef = fileManagerAdminService.getFileRefById(theFileId);
            if (theFileRef == null) {
                throw new ApplicationException(INVALID_ATTACHMENT_MSG);
            }
        }

        makeFileIdsConsistent(theFileRef, theFileId);
        attachmentToSave.fileRef = theFileRef;
        validateAllowedToEditWorkOrder(id);
        return microservice.saveAttachment(id, attachmentToSave);
    }

    private void makeFileIdsConsistent(FileRef fileRef, String fileId) {
        fileRef.id = fileId;
        fileRef.fileId = fileId;
    }

    public List<Attachment> removeAttachment(String id, String fileId) throws IOException {
        validateAllowedToEditWorkOrder(id);

        try {
            fileManagerAdminService.removeFile(fileId);
        } catch (FatalProcessingException | ApplicationException e) {
            throw new ApplicationException("Was not able to remove the file");
        }

        return microservice.removeAttachment(id, fileId);
    }

    public void removeAttachments(List<String> fileIds) {
        for (String fileId : fileIds) {
            try {
                fileManagerAdminService.removeFile(fileId);
            } catch (IOException | FatalProcessingException | ApplicationException e) {
                throw new ApplicationException("Was not able to remove the file");
            }
        }
    }

    public WorkOrder addNote(String id, Note note) {
        validateAllowedToCommentAndNote(id);
        return microservice.addNote(id, note);
    }

    public WorkOrder saveNote(String id, Note note) {
        validateAllowedToCommentAndNote(id);
        return microservice.saveNote(id, note);
    }

    public WorkOrder removeNote(String id, Note note) {
        validateAllowedToCommentAndNote(id);
        return microservice.removeNote(id, note);
    }

    public List<Note> getNotes(String id) {
        return microservice.getNotes(id);
    }

    public List<CustomField> getAllCustomFields(@NotNull @QueryParam("customizableTypeId") String customizableTypeId) {
        return microservice.getAllCustomFields(customizableTypeId);
    }

    public List<CustomFieldValue> getAllCustomFieldValues(String id) {
        return microservice.getAllCustomFieldValues(id);
    }

    public CustomField addCustomField(@QueryParam("maxCustomFieldRecords") Integer maxCustomFieldRecords,
                                      @NotNull CustomField customField) {
        return microservice.addCustomField(maxCustomFieldRecords, customField);
    }

    public CustomField updateCustomField(@NotNull CustomField customField) {
        return microservice.updateCustomField(customField);
    }

    public void deleteCustomField(@NotNull CustomField customField) {
        microservice.deleteCustomField(customField);
    }

    public boolean checkIfCustomFieldValuesExist(@NotNull @QueryParam("customFieldId") String customFieldId) {
        return microservice.checkIfCustomFieldValuesExist(customFieldId);
    }

    public boolean checkDuplicateLabel(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                       @QueryParam("label") String label) {
        return microservice.checkDuplicateLabel(customizableTypeId, label);
    }

    public List<CustomFieldValue> saveCustomFieldValues(String id, List<CustomFieldValue> customFieldValues) {
        validateAllowedToEditWorkOrder(id);
        return microservice.saveCustomFieldValues(id, customFieldValues);
    }

    public void updateCustomFieldRefInWorkOrders(CustomFieldRef customFieldRef) {
        microservice.updateCustomFieldRefInWorkOrders(customFieldRef);
    }

    public void removeCustomFieldRefFromWorkOrders(CustomFieldRef customFieldRef) {
        microservice.removeCustomFieldRefFromWorkOrders(customFieldRef);
    }

    public List<TagRef> getWorkOrderTags() {
        return tagService.getTagRefsForBusinessArea(EBusinessArea.WORK_ORDERS);
    }

    public List<TagRef> saveWorkOrderTags(String id, List<TagRef> tagRefList) {
        validateAllowedToEditWorkOrder(id);
        tagRefList = tagService.verifyAndAddTags(tagRefList, EBusinessArea.WORK_ORDERS);
        return microservice.saveWorkOrderTags(id, tagRefList);
    }

    public SearchResult<WorkOrder> getWorkOrders(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getWorkOrderSearchEngine();
        if (ESearchEngine.ELASTIC.equals(searchEngine)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            organizationService.setRPFuncFilterInSearch(searchInput);
            return microservice.getWorkOrderSearchResults(searchInput);
        }
    }

    public List<CmmsErrorType> getCmmsErrorTypes() {
        return microservice.getCmmsErrorTypes();
    }

    public List<CmmsError> getCmmsErrors(CmmsErrorSearchCriteria cmmsErrorSearchCriteria) {
        populateCmmsErrorSiteFilters(cmmsErrorSearchCriteria);
        return microservice.getCmmsErrors(cmmsErrorSearchCriteria);
    }

    private void populateCmmsErrorSiteFilters(CmmsErrorSearchCriteria cmmsErrorSearchCriteria) {
        if (cmmsErrorSearchCriteria.siteId != null) {
            cmmsErrorSearchCriteria.siteIds = new ArrayList<>();
            cmmsErrorSearchCriteria.siteIds.add(cmmsErrorSearchCriteria.siteId);
        } else if (cmmsErrorSearchCriteria.installationId != null) {
            List<Site> sites = installationService.getSitesForInstallation(cmmsErrorSearchCriteria.installationId);
            if (ListUtil.isEmpty(sites)) {
                throw new ApplicationException("This Installation has no associated Sites");
            }
            cmmsErrorSearchCriteria.siteIds = new ArrayList<>();
            sites.forEach(site -> cmmsErrorSearchCriteria.siteIds.add(site.getId()));
        }
    }

    public void deleteCmmsError(String cmmsErrorId) {
        microservice.deleteCmmsError(cmmsErrorId);
    }

    public List<WorkOrder> getWorkOrdersByFacilityIds(List<String> facilityIdList) {
        return microservice.getWorkOrdersByFacilityIds(facilityIdList);
    }

    public List<WorkOrderHistory> getWorkOrderHistoryByAssetId(String assetId,
                                                               Boolean includeScheduled,
                                                               Boolean includeUnscheduled) {
        return microservice.getWorkOrderHistoryByAssetId(assetId, includeScheduled, includeUnscheduled);
    }

    public List<Assignment> getAssignmentsForWorkOrder(String workOrderId) {
        return microservice.getAssignmentsForWorkOrder(workOrderId);
    }

    public int updateWorkOrderIsDeferred(String id, boolean isDeferred) {
        int rtn =  microservice.updateWorkOrderIsDeferred(id, isDeferred);

        WorkOrder workOrder = microservice.findById(id);
        //financeProcessEstimateCosts(workOrder, !isDeferred);
        return rtn;
    }

    public WorkOrder addReplaceLegacyWorkRequestStatusHistories(String workOrderId,
                                                                List<LegacyWorkRequestStatusHistory> statusHistories) {
        return microservice.addReplaceLegacyWorkRequestStatusHistories(workOrderId, statusHistories);
    }

    public WorkOrder buildWorkflowFromLegacyWorkflowHistories(String workOrderId) {
        WorkOrder workOrder = microservice.findById(workOrderId);
        validateWorkOrderFound(workOrder);

        WorkOrderLegacyWorkflowUtil.HistorySummary historySummary =
                legacyWorkflowUtil.validateAndSummarizeHistories(workOrder);

        if (historySummary.isDummyWorkflowNeeded()) {
            try {
                buildDummyWorkflowFromLegacy(historySummary);
            } catch (Exception e) {  // Must be Exception; ApplicationException doesn't bubble up properly from workflow code
                // Perform one retry in case exception was due to DB replica set sync issue
                buildDummyWorkflowFromLegacy(historySummary);
            }

        } else {
            try {
                buildTrueWorkflowFromLegacy(historySummary);
            } catch (ApplicationException e) {
                // Perform one retry in case exception was due to DB replica set sync issue
                buildTrueWorkflowFromLegacy(historySummary);
            }
        }

        return workOrder;
    }

    private void buildDummyWorkflowFromLegacy(WorkOrderLegacyWorkflowUtil.HistorySummary historySummary) {
        String workOrderId = historySummary.getWorkOrderId();

        WorkOrder workOrder = microservice.findById(workOrderId);
        validateWorkOrderFound(workOrder);
        resetWorkflowForMigratedWorkOrder(workOrder);

        handleLegacyStatusHistoryOpen(workOrderId, null, true);

        if (historySummary.isClosed()) {
            handleLegacyStatusHistoryCompleted(workOrderId, null, true);
            handleLegacyStatusHistoryClosed(workOrderId, null, null, true);
        }

        workOrder = reloadWorkOrder(workOrderId);
        legacyWorkflowUtil.addDummyWorkflowComment(workOrder, currentUserBT, historySummary.isClosed());
        saveWorkOrder(workOrder);
    }

    private void buildTrueWorkflowFromLegacy(WorkOrderLegacyWorkflowUtil.HistorySummary historySummary) {
        String workOrderId = historySummary.getWorkOrderId();

        WorkOrder workOrder = microservice.findById(workOrderId);
        validateWorkOrderFound(workOrder);
        resetWorkflowForMigratedWorkOrder(workOrder);

        List<LegacyWorkRequestStatusHistory> histories = historySummary.getValidatedHistories();

        try {
            for (LegacyWorkRequestStatusHistory history : histories) {
                switch (history.statusName) {
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_OPEN:
                        handleLegacyStatusHistoryOpen(workOrderId, history, false);
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_COMPLETED:
                        handleLegacyStatusHistoryCompleted(workOrderId, history, false);
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_CANCELLED:
                        handleLegacyStatusHistoryCancelled(workOrderId, history);
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_ASSIGNED_TO_PROJECT:
                        handleLegacyStatusHistoryAssignedToProject(workOrderId, history);
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_CONVERTED_TO_REQUIREMENT:
                        handleLegacyStatusHistoryConvertedToRequirement(workOrderId, history);
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_AWAITING_QC:
                        // no action needed
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_QC_PASSED:
                        handleLegacyStatusHistoryQCPassed(workOrderId, history);
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_QC_FAILED:
                        handleLegacyStatusHistoryQCFailed(workOrderId, history);
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_AWAITING_QA:
                        handleLegacyStatusHistoryAwaitingQA(workOrderId, histories, history);
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_QA_PASSED:
                        handleLegacyStatusHistoryQAPassed(workOrderId, history);
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_QA_FAILED:
                        handleLegacyStatusHistoryQAFailed(workOrderId, history);
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_REWORK:
                        handleLegacyStatusHistoryRework(workOrderId, histories, history);
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_AWAITING_COR_ACCEPTANCE:
                        // no action needed
                        break;
                    case WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_CLOSED:
                        handleLegacyStatusHistoryClosed(workOrderId, histories, history, false);
                        break;
                    default:
                }
            }
        } catch (Exception e) {
            // Fortify Note: Keeping broad catch exception for Extreme edge cases
            logger.info(
                    "Could not build proper workflow for legacy Work Request {}, encountered Exception: {}, ...Will try to build dummy workflow.",
                    historySummary.getWorkOrderId(), e.getMessage());
            buildDummyWorkflowFromLegacy(historySummary);
        }
    }

    private void resetWorkflowForMigratedWorkOrder(WorkOrder workOrder) {
        // Remove workflowState entirely and remove workflow-related comments
        boolean saveNeeded = false;

        if (workOrder.workflowState != null) {
            workOrder.workflowState = null;
            saveNeeded = true;
        }

        if (!ListUtil.isEmpty(workOrder.comments)) {
            List<Comment> commentsToRemove = new ArrayList<>();
            for (Comment c : workOrder.comments) {
                if (!StringUtil.isBlankOrNull(c.step)
                        ||
                        (!StringUtil.isBlankOrNull(c.text) &&
                                (c.text.equals(WorkOrderLegacyWorkflowUtil.COMMENT_DUMMY_WORKFLOW_CLOSED) ||
                                        c.text.equals(WorkOrderLegacyWorkflowUtil.COMMENT_DUMMY_WORKFLOW_OPEN)))) {
                    commentsToRemove.add(c);
                }
            }
            if (!ListUtil.isEmpty(commentsToRemove)) {
                workOrder.comments.removeAll(commentsToRemove);
                saveNeeded = true;
            }
        }

        if (!ListUtil.isEmpty(workOrder.qualityEvents)) {
            List<QualityEvent> qualityEventsToRemove = new ArrayList<>();
            workOrder.qualityEvents.stream()
                    .filter(q -> !StringUtil.isBlankOrNull(q.stepName))
                    .forEach(qualityEventsToRemove::add);
            if (!ListUtil.isEmpty(qualityEventsToRemove)) {
                workOrder.qualityEvents.removeAll(qualityEventsToRemove);
                saveNeeded = true;
            }
        }

        if (saveNeeded) {
            microservice.updateMigratedWorkOrder(workOrder);
        }
    }

    private void handleLegacyStatusHistoryOpen(String workOrderId,
                                               LegacyWorkRequestStatusHistory history,
                                               boolean dummyWorkflow) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);
        Date changedDate = (dummyWorkflow ? new Date() : history.userChangedDateUTC);
        startUnscheduled(workOrder.getId(), changedDate);
    }

    private void handleLegacyStatusHistoryCancelled(String workOrderId, LegacyWorkRequestStatusHistory history) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);
        sendForReview(workOrder, history.userChangedDateUTC);
        cancel(workOrder, history.userChangedDateUTC);
    }

    private void handleLegacyStatusHistoryCompleted(String workOrderId,
                                                    LegacyWorkRequestStatusHistory history,
                                                    boolean dummyWorkflow) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);
        Date changedDate = (dummyWorkflow ? new Date() : history.userChangedDateUTC);

        if (dummyWorkflow) {
            sendForReview(workOrder, changedDate, true);
            complete(workOrder, changedDate, false, true);
        } else if ((!workOrder.isQualityControlSampled || !workOrder.isQualityAssuranceSampled)
                &&
                history.isCurrentStatus) {
            sendForReview(workOrder, changedDate);
        } else {
            if ((workOrder.isQualityControlSampled && workOrder.isQualityAssuranceSampled)
                    ||
                    !history.isCurrentStatus) {
                sendForReview(workOrder, changedDate);
                complete(workOrder, changedDate, false);
            } else {
                throw new ApplicationException(
                        String.format(
                                "Could not handle %s legacy status for Work Order %s (invalid scenario)",
                                WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_COMPLETED, workOrder.getId()));
            }
        }
    }

    private void handleLegacyStatusHistoryAssignedToProject(String workOrderId, LegacyWorkRequestStatusHistory history) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);
        sendForReview(workOrder, history.userChangedDateUTC);
        assignToProject(workOrder, history.userChangedDateUTC, true);
    }

    private void handleLegacyStatusHistoryConvertedToRequirement(String workOrderId, LegacyWorkRequestStatusHistory history) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);
        sendForReview(workOrder, history.userChangedDateUTC);
        convertToRequirement(workOrder, history.userChangedDateUTC, true);
    }

    private void handleLegacyStatusHistoryQCPassed(String workOrderId, LegacyWorkRequestStatusHistory history) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);
        passQualityControl(workOrder, history.userChangedDateUTC, false);
    }

    private void handleLegacyStatusHistoryQCFailed(String workOrderId, LegacyWorkRequestStatusHistory history) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);
        failQualityControl(workOrder, history.userChangedDateUTC);
    }

    private void handleLegacyStatusHistoryAwaitingQA(String workOrderId,
                                                     List<LegacyWorkRequestStatusHistory> histories,
                                                     LegacyWorkRequestStatusHistory history) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);

        if (!legacyWorkflowUtil.legacyQualityControlHasOccurred(histories, history.statusHistorySerial) &&
                !legacyWorkflowUtil.qualityControlHasBeenMarkedAsNotRequired(workOrder)) {
            legacyWorkflowUtil.clearNewCommentAndQualityEvent(workOrder);
            markQualityControlAsNotRequired(workOrder, history.userChangedDateUTC, false);
        }
    }

    private void handleLegacyStatusHistoryQAPassed(String workOrderId, LegacyWorkRequestStatusHistory history) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);
        passQualityAssurance(workOrder, history.userChangedDateUTC);
    }

    private void handleLegacyStatusHistoryQAFailed(String workOrderId, LegacyWorkRequestStatusHistory history) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);
        failQualityAssurance(workOrder, history.userChangedDateUTC);
    }

    private void handleLegacyStatusHistoryRework(String workOrderId,
                                                 List<LegacyWorkRequestStatusHistory> histories,
                                                 LegacyWorkRequestStatusHistory history) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);

        LegacyWorkRequestStatusHistory prevHistory =
                legacyWorkflowUtil.getPreviousStatusHistory(histories, history.statusHistorySerial);
        String prevStatName = prevHistory.statusName;

        if (prevStatName.equals(WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_AWAITING_COR_ACCEPTANCE)) {
            // If last status was Awaiting COR Acceptance, make sure QC and QA are handled
            if (!legacyWorkflowUtil.legacyQualityControlHasOccurred(histories, history.statusHistorySerial) &&
                    !legacyWorkflowUtil.qualityControlHasBeenMarkedAsNotRequired(workOrder)) {
                markQualityControlAsNotRequired(workOrder, history.userChangedDateUTC, false);
                workOrder = reloadWorkOrder(workOrderId);
            }

            if (!legacyWorkflowUtil.legacyQualityAssuranceHasOccurred(histories, history.statusHistorySerial) &&
                    !legacyWorkflowUtil.qualityAssuranceHasBeenMarkedAsNotRequired(workOrder)) {
                markQualityAssuranceAsNotRequired(workOrder, history.userChangedDateUTC);
                workOrder = reloadWorkOrder(workOrderId);
            }
        }

        if (prevStatName.equals(WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_QA_PASSED) ||
                prevStatName.equals(WorkOrderLegacyWorkflowUtil.LEGACY_STATUS_AWAITING_COR_ACCEPTANCE)) {
            // If last status was QA Passed or Awaiting COR Acceptance, need to Reject!
            reject(workOrder, history.userChangedDateUTC, true);
        }
    }

    private void handleLegacyStatusHistoryClosed(String workOrderId,
                                                 List<LegacyWorkRequestStatusHistory> histories,
                                                 LegacyWorkRequestStatusHistory history,
                                                 boolean dummyWorkflow) {
        WorkOrder workOrder = reloadWorkOrder(workOrderId);
        Date changedDate = (dummyWorkflow ? new Date() : history.userChangedDateUTC);

        if (dummyWorkflow) {
            if (workOrder.isQualityAssuranceRequired) {
                markQualityAssuranceAsNotRequired(workOrder, changedDate);
                workOrder = reloadWorkOrder(workOrderId);
            }
            accept(workOrder, changedDate, true, false);
        } else {
            if (legacyWorkflowUtil.workRequestWasCancelled(histories, history.statusHistorySerial)) {
                // This WorkRequest was cancelled...therefore no action needed before moving to "accept" action
                accept(workOrder, changedDate, true, false);
            } else {
                // handle QC and QA as needed
                if (!legacyWorkflowUtil.legacyQualityControlHasOccurred(histories, history.statusHistorySerial) &&
                        !legacyWorkflowUtil.qualityControlHasBeenMarkedAsNotRequired(workOrder)) {
                    markQualityControlAsNotRequired(workOrder, changedDate, false);
                    workOrder = reloadWorkOrder(workOrderId);
                }

                if (!legacyWorkflowUtil.legacyQualityAssuranceHasOccurred(histories, history.statusHistorySerial) &&
                        !legacyWorkflowUtil.qualityAssuranceHasBeenMarkedAsNotRequired(workOrder)) {
                    markQualityAssuranceAsNotRequired(workOrder, changedDate);
                    workOrder = reloadWorkOrder(workOrderId);
                }
                accept(workOrder, changedDate, true, false);
            }
        }
    }

    private WorkOrder reloadWorkOrder(String workOrderId) {
        WorkOrder workOrder = microservice.findById(workOrderId);
        legacyWorkflowUtil.clearNewCommentAndQualityEvent(workOrder);
        return workOrder;
    }

    public BulkResponse updateWorkOrdersIsDeferred(List<String> ids, boolean isDeferred, String reason) {
        validateBulkUpdateRecordLimit(ids.size());
        BulkResponse bulkResponse = new BulkResponse();
        List<WorkOrder> workOrders = findByIds(ids);
        for (WorkOrder workOrder : workOrders) {
            try {
                workOrder.newComment = new Comment();
                workOrder.newComment.text = reason;

                if (isDeferred) {
                    defer(workOrder);
                } else {
                    unDefer(workOrder);
                }
                bulkResponse.successfulItems.add(workOrder.workOrderNumber);
            } catch (Exception e) {
                // Fortify Note: Keeping broad catch exception to insure the for loop fully processes
                FailedItem failedItem = new FailedItem();
                failedItem.workOrderNumber = workOrder.workOrderNumber;
                failedItem.errorMsg = e.getMessage();
                bulkResponse.failedItems.add(failedItem);
            }
        }
        return bulkResponse;
    }

    public WorkOrder createWorkOrder(WorkOrder workOrder, boolean startWorkflow) {
        workOrderDetailValidator.validate(workOrder);
        workOrderLocationValidator.validate(workOrder);
        workOrderSpaceValidator.validate(workOrder);
        ensureLegacyWorkOrderIsUnique(workOrder);
        if (workOrder.dmlssWorkRequestSerial != null) {
            workOrder.dmlssWorkRequestMigratedDate = new Date();
        }
        setQualityFields(workOrder);
        fixScheduleRefIfNeeded(workOrder);
        workOrder.managedByOrganizationRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        workOrder.createdByRef = currentUserBT.getCurrentUser().profile.getRef();
        WorkOrder newWorkOrder = microservice.createWorkOrder(workOrder);

        try {
            newWorkOrder = fillDmlssRealPropertyFunding(newWorkOrder);
        } catch (Exception e ) {
            logger.warn("failed in populating finance funding information: ", e.getMessage());
        }

        if (startWorkflow) {
            newWorkOrder = workflowService.startAction(newWorkOrder, EWorkflowName.STANDARD_WORK_ORDER.displayText, EWorkflowStepName.IN_PROGRESS.position, currentUserBT.getCurrentUser().profile.managedByNodeRef);
        }

        return newWorkOrder;
    }

    private WorkOrder fillDmlssRealPropertyFunding(WorkOrder workOrder) {
    	if ( ListUtil.isEmpty(workOrder.assignments) )
    		return workOrder;

    	List<DmlssRealPropertyFunding> laborFundings = null;
    	List<DmlssRealPropertyFunding> partsFundings = null;
    	List<DmlssRealPropertyFunding> materialFundings = null;

    	getDmlssEorCodes();

    	WorkOrder updatedWorkOrder = workOrder;
    	for(Assignment assignment : updatedWorkOrder.assignments) {
    		if ( assignment.estimatedCosts != null && !ListUtil.isEmpty(assignment.estimatedCosts.dmlssRealPropertyFundingList)) {
    			laborFundings = new ArrayList<>();
    			partsFundings = new ArrayList<>();
    			materialFundings = new ArrayList<>();

    			categorizeDmlssFundings(assignment.estimatedCosts.dmlssRealPropertyFundingList, laborFundings, partsFundings, materialFundings);
    			populateCategoryFundings(updatedWorkOrder.managedByOrganizationRef.id, assignment.estimatedCosts, laborFundings, COMMODITY_TYPE_LABOR);
    			populateCategoryFundings(updatedWorkOrder.managedByOrganizationRef.id, assignment.estimatedCosts, partsFundings, COMMODITY_TYPE_PARTS);
    			populateCategoryFundings(updatedWorkOrder.managedByOrganizationRef.id, assignment.estimatedCosts, materialFundings, COMMODITY_TYPE_MATERIAL);
    		}

    		if (!ListUtil.isEmpty(assignment.actualCosts)) {
    			List<ActualCost> actualCostList = new ArrayList<>();


    			for (ActualCost actualCost : assignment.actualCosts) {
    				if (actualCost.costType == EWorkOrderCostType.ACTUAL && actualCost.costSummary != null && !ListUtil.isEmpty(actualCost.costSummary.dmlssRealPropertyFundingList)) {
    					laborFundings = new ArrayList<>();
    					partsFundings = new ArrayList<>();
    					materialFundings = new ArrayList<>();

    					categorizeDmlssFundings(actualCost.costSummary.dmlssRealPropertyFundingList, laborFundings, partsFundings, materialFundings);
    					populateCategoryFundings(updatedWorkOrder.managedByOrganizationRef.id, actualCost.costSummary, laborFundings, COMMODITY_TYPE_LABOR);
    					populateCategoryFundings(updatedWorkOrder.managedByOrganizationRef.id, actualCost.costSummary, partsFundings, COMMODITY_TYPE_PARTS);
    					populateCategoryFundings(updatedWorkOrder.managedByOrganizationRef.id, actualCost.costSummary, materialFundings, COMMODITY_TYPE_MATERIAL);

    				}
    			
    				actualCostList.add(actualCost);
    			}

    			if ( !ListUtil.isEmpty(actualCostList) ) {
    				assignment.actualCosts = actualCostList;
    			}
    		}
    	}

    	//for maximo work orders, update cmmsExpensecenterRef.
    	if (updatedWorkOrder.cmmsExpenseCenterRef == null &&
    			!StringUtil.isEmptyOrNull(updatedWorkOrder.dmlssEngineeringFund) &&
    			updatedWorkOrder.managedByOrganizationRef != null ) {
    		CmmsExpenseCenter cmmsExpenseCenter = microservice.getCmmsExpenseCenterIdAndOrg(
    				updatedWorkOrder.dmlssEngineeringFund,
    				updatedWorkOrder.managedByOrganizationRef.id
    				);
    		if (cmmsExpenseCenter != null) {
    			updatedWorkOrder.cmmsExpenseCenterRef = cmmsExpenseCenter.getRef();
    		}
    	}

    	return microservice.updateMigratedWOFundings(updatedWorkOrder);
    }

    private void getDmlssEorCodes() {
        dmlssEorCodes = new HashMap<>();
        List<Configuration> configurations = getAllConfigurations();
        if ( !ListUtil.isEmpty(configurations)) {
            for(Configuration item : configurations) {
                if ( (COMMODITY_MATERIAL_EORCODE_PROP.equals(item.name) ||
                        COMMODITY_LABOR_EORCODE_PROP.equals(item.name) ||
                        COMMODITY_PARTS_EORCODE_PROP.equals(item.name)) &&
                        !StringUtil.isBlankOrNull(item.value) ) {
                    List<String> eorCodes = StringUtil.convertCsvToList(item.value, EIncludeEmpty.No);
                    dmlssEorCodes.put(item.name, eorCodes);
                }
            }
        }

    }

    private void categorizeDmlssFundings(List<DmlssRealPropertyFunding> dmlssRealPropertyFundingList,
                                         List<DmlssRealPropertyFunding> laborFundings, List<DmlssRealPropertyFunding> partsFundings,
                                         List<DmlssRealPropertyFunding> materialFundings) {

        if ( ListUtil.isEmpty(dmlssRealPropertyFundingList)) {
            return;
        }

        for (DmlssRealPropertyFunding dmlssFunding : dmlssRealPropertyFundingList ) {
            String eorCode =  dmlssFunding.eorCode;
            if ( isLaborCategory(eorCode) ) {
                laborFundings.add(dmlssFunding);
            } else if ( isPartsCategory(eorCode)) {
                partsFundings.add(dmlssFunding);
            } else if ( isMaterialCategory(eorCode)) {
                materialFundings.add(dmlssFunding);
            }
        }
    }

    private boolean findEorCode(List<String> eorCodes, String eorCode) {
        if ( ListUtil.isEmpty(eorCodes)) {
            return false;
        } else {
            return eorCodes.stream().anyMatch(eor->eorCode.equals(eor.trim()));
        }
    }

    private boolean isLaborCategory(String eorCode) {
        List<String> eorCodes = dmlssEorCodes.get(COMMODITY_LABOR_EORCODE_PROP);
        return findEorCode(eorCodes, eorCode);
    }

    private boolean isPartsCategory(String eorCode) {
        List<String> eorCodes = dmlssEorCodes.get(COMMODITY_PARTS_EORCODE_PROP);
        return findEorCode(eorCodes, eorCode);
    }

    private boolean isMaterialCategory(String eorCode) {
        List<String> eorCodes = dmlssEorCodes.get(COMMODITY_MATERIAL_EORCODE_PROP);
        return findEorCode(eorCodes, eorCode);
    }

    private void  populateCategoryFundings(String organizationId, CostSummary costSummary, List<DmlssRealPropertyFunding> dmlssFundings, String categoryType) {
        if (ListUtil.isEmpty(dmlssFundings)) {
            return;
        }

        RealPropertyFunding funding;
        if ( COMMODITY_TYPE_LABOR.equals(categoryType) ) {
            if ( costSummary.laborFunding == null ) {
                costSummary.laborFunding = new RealPropertyFunding();
            }
            funding = costSummary.laborFunding;
            costSummary.labor = calculateTotalAmount(dmlssFundings);
        } else if ( COMMODITY_TYPE_PARTS.equals(categoryType) ) {
            if ( costSummary.partsFunding == null ) {
                costSummary.partsFunding = new RealPropertyFunding();
            }
            funding = costSummary.partsFunding;
            costSummary.parts = calculateTotalAmount(dmlssFundings);

        } else if ( COMMODITY_TYPE_MATERIAL.equals(categoryType) ) {
            if ( costSummary.materialFunding == null ) {
                costSummary.materialFunding = new RealPropertyFunding();
            }
            funding = costSummary.materialFunding;
            costSummary.material = calculateTotalAmount(dmlssFundings);
        } else {
            return;
        }

        DmlssRealPropertyFunding dmlssFunding = dmlssFundings.get(0);

        if (dmlssFunding.projectCenterSerial > 0) {
            funding.projectFundingNodeRef = financeDataMigrationService.getProjectCenterByMigrationId(dmlssFunding.siteDodaac + "." +
                    dmlssFunding.projectCenterSerial);

        }
        if (dmlssFunding.expenseCenterSerial > 0) {
            funding.expenseFundingNodeRef = financeDataMigrationService.getExpenseCenterByMigrationId(dmlssFunding.siteDodaac + "." +
                    dmlssFunding.expenseCenterSerial);
        }
        if (dmlssFunding.eorCode != null) {
            CommodityCodeRefMigrationWrapper codeRefMigrationWrapper = new CommodityCodeRefMigrationWrapper();

            CommodityCodeRef migrationCode = new CommodityCodeRef();
            if (dmlssFunding.eorCode == "25EB") {
                migrationCode.code = "6100.2540";
                migrationCode.name = "Contractor Provided Parts";
            } else {
                migrationCode.code = dmlssFunding.eorCode;
                migrationCode.name = dmlssFunding.eorName;
            }
            codeRefMigrationWrapper.commodityCodeRef = migrationCode;

            codeRefMigrationWrapper.commodityUsageType = FM_COMMODITY_USAGE_TYPE;
            codeRefMigrationWrapper.organizationId = organizationId;

            funding.commodityCodeRef = financeDataMigrationService.getCommodityCodeRef(codeRefMigrationWrapper);
        }
    }

    private MonetaryValue calculateTotalAmount(List<DmlssRealPropertyFunding> dmlssFundings) {
        MonetaryValue total = MonetaryValue.ZERO;

        if (!ListUtil.isEmpty(dmlssFundings)) {
            for(DmlssRealPropertyFunding funding : dmlssFundings) {
                if ( funding.amount != null ) {
                    total = total.add(funding.amount );
                }
            }
        }
        return total;
    }

    public List<WorkOrder> getWorkOrdersByRequirementId(String requirementId) {
        return microservice.getWorkOrdersByRequirementId(requirementId);
    }

    private void ensureLegacyWorkOrderIsUnique(WorkOrder workOrder) {
        if (workOrder.dmlssWorkRequestSerial != null && workOrder.facilityRef != null &&
                !StringUtil.isBlankOrNull(workOrder.facilityRef.siteDodaac)) {
            List<WorkOrder> persistedWorkOrders = findBySiteDodaacAndDmlssWorkRequestSerial(
                    workOrder.facilityRef.siteDodaac, workOrder.dmlssWorkRequestSerial);
            if (!ListUtil.isEmpty(persistedWorkOrders)) {
                throw new ApplicationException(String.format("Work Order already exists (siteDodaac %s, dmlssWorkRequestSerial %d)",
                        workOrder.facilityRef.siteDodaac, workOrder.dmlssWorkRequestSerial));
            }
        }
    }

    private void fixScheduleRefIfNeeded(WorkOrder workOrder) {
        if (workOrder.scheduleRef != null &&
                !StringUtil.isBlankOrNull(workOrder.scheduleRef.getId()) &&
                StringUtil.isBlankOrNull(workOrder.scheduleRef.scheduleIdentifier)) {
            workOrder.scheduleRef = assetScheduleService.findScheduleRefById(workOrder.scheduleRef.getId());
        }
    }

    private void setQualityFields(WorkOrder workOrder) {
        if (!ListUtil.isEmpty(workOrder.assetRefs)) {
            List<Asset> assetsByIds = assetService.getAssetsByAssetIds(workOrder.assetRefs.stream().map(AssetRef::getId).collect(Collectors.toList()));

            long assetsWithQualityControlRequired = assetsByIds.stream().map(asset -> asset.additionalInformation)
                    .filter(Objects::nonNull)
                    .filter(additionalInformation -> EQaQcInspectionMethod.AUTOMATIC.equals(additionalInformation.qcInspectionMethod)).count();
            long assetsWithQualityAssuranceRequired = assetsByIds.stream().map(asset -> asset.additionalInformation)
                    .filter(Objects::nonNull)
                    .filter(additionalInformation -> EQaQcInspectionMethod.AUTOMATIC.equals(additionalInformation.qaInspectionMethod)).count();
            if (workOrder.isQualityControlRequired) {
                // if it is already TRUE, do not reset; required for data migration.
            } else {
                workOrder.isQualityControlRequired = assetsWithQualityControlRequired > 0;
                if (workOrder.isQualityControlRequired) {
                    QualitySelection qualitySelection = new QualitySelection();
                    qualitySelection.selectionCriteria = EQualitySelectionCriteria.AUTOMATIC;
                    qualitySelection.selectionDate = new Date();
                    workOrder.qualityControlSelection = qualitySelection;
                }
            }
            if (workOrder.isQualityAssuranceRequired) {
                // if it is already TRUE, do not reset; required for data migration.
            } else {
                workOrder.isQualityAssuranceRequired = assetsWithQualityAssuranceRequired > 0;
                if (workOrder.isQualityAssuranceRequired
                        && workOrder.qualityAssuranceSelection == null) {
                    QualitySelection qualitySelection = new QualitySelection();
                    qualitySelection.selectionCriteria = EQualitySelectionCriteria.AUTOMATIC;
                    qualitySelection.selectionDate = new Date();
                    workOrder.qualityAssuranceSelection = qualitySelection;
                }
            }
        }
    }

    private List<WorkOrder> findBySiteDodaacAndDmlssWorkRequestSerial(String siteDodaac, Integer dmlssWorkRequestSerial) {
        return microservice.findBySiteDodaacAndDmlssWorkRequestSerial(siteDodaac, dmlssWorkRequestSerial);
    }

    private WorkOrder createMaximoWorkOrder(WorkOrder workOrder) {
        setQualityFields(workOrder);
        WorkOrder newWorkOrder = microservice.createWorkOrder(workOrder);
        workflowService.startAction(newWorkOrder, EWorkflowName.STANDARD_WORK_ORDER.displayText, EWorkflowStepName.IN_PROGRESS.position, currentUserBT.getCurrentUser().profile.managedByNodeRef);
        return newWorkOrder;
    }

    public WorkOrder updateWorkOrderDetails(WorkOrder workOrder) {
        validateAllowedToEditWorkOrder(workOrder.getId());
        new WorkOrderDetailValidator().validate(workOrder);
        return microservice.updateWorkOrderDetails(workOrder);
    }

    public WorkOrder updateWorkOrderRequester(WorkOrder workOrder) {
        validateAllowedToEditWorkOrder(workOrder.getId());
        return microservice.updateWorkOrderRequester(workOrder);
    }

    public WorkOrder updateWorkOrderLocation(WorkOrder workOrder) {
        validateAllowedToEditWorkOrder(workOrder.getId());
        workOrderLocationValidator.validateUpdate(workOrder);
        return microservice.updateWorkOrderLocation(workOrder);
    }

    public WorkOrder updateSpaceDetails(WorkOrder workOrder) {
        validateAllowedToEditWorkOrder(workOrder);
        workOrderSpaceValidator.validate(workOrder);
        return microservice.updateSpaceDetails(workOrder);
    }

    public WorkOrder updateZones(WorkOrder workOrder) {
        validateAllowedToEditWorkOrder(workOrder);
        return microservice.updateZones(workOrder);
    }

    public WorkOrder updateSpaces(WorkOrder workOrder) {
        validateAllowedToEditWorkOrder(workOrder);
        workOrderSpaceValidator.validate(workOrder);
        return microservice.updateSpaces(workOrder);
    }

    public WorkOrder updateEstimatedCosts(String workOrderId, CostSummary costSummary) {
        validateAllowedToEditWorkOrder(workOrderId);
        return microservice.updateEstimatedCosts(workOrderId, costSummary);
    }

    public void updateAssignmentEstimatedLaborCost(BusinessContact businessContact) {

        List<WorkOrder> workOrders = microservice.getScheduledWorkOrdersByBusinessContact(businessContact.getId());
        if (workOrders != null && !workOrders.isEmpty()) {

            for (WorkOrder workOrder : workOrders) {
                if (workOrder.assignments != null && !workOrder.assignments.isEmpty()) {

                    for (Assignment assignment : workOrder.assignments) {

                        Services businessContactServices = findServiceInBusinessContactBySkillRef(assignment.skillRef, businessContact);
                        if (businessContactServices == null) {
                            continue;
                        }

                        if (assignment.personnel != null) {
                            Personnel businessContactPersonnel = findPersonnelInBusinessContactServicesByPersonnelId(assignment.personnel.personnelId, businessContactServices);

                            assignment.personnel = businessContactPersonnel;
                        }
                        logger.info("Updating Work Order {}, Assignment {}, for Business Contact {} changes", workOrder.workOrderNumber, assignment.assignmentId, businessContact.name);
                        microservice.saveAssignmentEstimate(workOrder.getId(), assignment);
                    }
                }
            }
        }
    }

    private Services findServiceInBusinessContactBySkillRef(SkillRef skillRef, BusinessContact businessContact) {
        Services s = null;
        if (businessContact.services != null) {
            s = businessContact.services.stream().filter(service -> service.skillRef.getId().equals(skillRef.getId())).findAny().orElse(null);
        }
        return s;
    }

    private Personnel findPersonnelInBusinessContactServicesByPersonnelId(String personnelId, Services businessContactServices) {
        Personnel person = null;
        if (businessContactServices.personnel != null && !businessContactServices.personnel.isEmpty()) {
            person = businessContactServices.personnel.stream().filter(personnel -> personnel.personnelId.equals(personnelId)).findAny().orElse(null);
        }
        return person;
    }

    public WorkOrder addAssignment(String workOrderId, Assignment assignment) {
        validateAllowedToEditWorkOrder(workOrderId);
        BusinessContact businessContact = workOrderAssignmentValidator.validateAndReturnBusinessContact(assignment);
        workOrderAssignmentValidator.validate(assignment, businessContact);
        if (assignment.skillRef.name != null) {
            populateAssignmentDefaultLaborRate(assignment, businessContact);
        }
        fillRealPropertyFunding(assignment.estimatedCosts);
        return microservice.addAssignment(workOrderId, assignment);
        //     processEstimatedCostsFinanceRequest
    }

    private void populateAssignmentDefaultLaborRate(Assignment assignment, BusinessContact businessContact) {
        String assignmentSkillRefId = assignment.skillRef.id;

        for (Services service : businessContact.services) {
            String serviceSkillRefId = service.skillRef.id;
            if (assignmentSkillRefId.equals(serviceSkillRefId)) {
                assignment.defaultLaborRate = service.defaultLaborRate;
                break;
            }
        }
    }

    private void fillRealPropertyFunding(CostSummary costs) {
        if (costs != null) {
            if (costs.laborFunding != null) {
                populateRealPropertyFunding(costs.laborFunding);
            }
            if (costs.materialFunding != null) {
                populateRealPropertyFunding(costs.materialFunding);
            }
            if (costs.partsFunding != null) {
                populateRealPropertyFunding(costs.partsFunding);
            }
        }
    }


    private void fillRealPropertyFunding(CmmsExpenseCenter cmmsExpenseCenter) {
        // Added for DMLSS=>LC Data migration...
        try {
            if (migrateProjectCenterFromDMLSS(cmmsExpenseCenter)) {
                cmmsExpenseCenter.projectFundingNodeRef = financeDataMigrationService.getProjectCenterByMigrationId(
                        cmmsExpenseCenter.dmlssRealPropertyFunding.siteDodaac + "." + cmmsExpenseCenter.dmlssRealPropertyFunding.projectCenterSerial);
            }

            if (migrateExpenseCenterFromDMLSS(cmmsExpenseCenter)) {
                cmmsExpenseCenter.expenseFundingNodeRef = financeDataMigrationService.getExpenseCenterByMigrationId(
                        cmmsExpenseCenter.dmlssRealPropertyFunding.siteDodaac + "." + cmmsExpenseCenter.dmlssRealPropertyFunding.expenseCenterSerial);
            }
        } catch (ApplicationException e) {
            logger.error("An error occurred while migrating the DMLSS Project and Expense Centers:",
                    e.getMessage());
        }
    }

    private boolean migrateProjectCenterFromDMLSS(CmmsExpenseCenter cmmsExpenseCenter) {
        return (cmmsExpenseCenter.projectFundingNodeRef == null || StringUtil.isEmptyOrNull(cmmsExpenseCenter.projectFundingNodeRef.id))
                && (cmmsExpenseCenter.dmlssRealPropertyFunding != null
                && !StringUtil.isEmptyOrNull(cmmsExpenseCenter.dmlssRealPropertyFunding.siteDodaac)
                && cmmsExpenseCenter.dmlssRealPropertyFunding.projectCenterSerial != null);
    }

    private boolean migrateExpenseCenterFromDMLSS(CmmsExpenseCenter cmmsExpenseCenter) {
        return (cmmsExpenseCenter.expenseFundingNodeRef == null || StringUtil.isEmptyOrNull(cmmsExpenseCenter.expenseFundingNodeRef.id))
                && (cmmsExpenseCenter.dmlssRealPropertyFunding != null
                && !StringUtil.isEmptyOrNull(cmmsExpenseCenter.dmlssRealPropertyFunding.siteDodaac)
                && cmmsExpenseCenter.dmlssRealPropertyFunding.expenseCenterSerial != null);
    }

    public void populateRealPropertyFunding(RealPropertyFunding funding) {
        if (funding == null)
            return;

        if (funding.projectFundingNodeRef != null && !StringUtil.isEmptyOrNull(funding.projectFundingNodeRef.id)) {
            ProcessingBalance projectFundingPB = financeAdminService.getFundingNodeById(funding.projectFundingNodeRef.id);
            if (projectFundingPB != null && projectFundingPB.fundingNodeRef != null && projectFundingPB.fundingNodeRef.id.equals(funding.projectFundingNodeRef.id)) {
                funding.projectFundingNodeRef = projectFundingPB.fundingNodeRef;
            }
        }

        if (funding.expenseFundingNodeRef != null && !StringUtil.isEmptyOrNull(funding.expenseFundingNodeRef.id)) {
            ProcessingBalance expenseFundingPB = financeAdminService.getFundingNodeById(funding.expenseFundingNodeRef.id);
            if (expenseFundingPB != null && expenseFundingPB.fundingNodeRef != null && expenseFundingPB.fundingNodeRef.id.equals(funding.expenseFundingNodeRef.id)) {
                funding.expenseFundingNodeRef = expenseFundingPB.fundingNodeRef;
            }
        }

        if (funding.commodityCodeRef != null && !StringUtil.isEmptyOrNull(funding.commodityCodeRef.id)) {
            funding.commodityCodeRef = financeReferenceDataService.getCommodityCodeById(funding.commodityCodeRef.id);
        }
    }

    public WorkOrder saveAssignment(String workOrderId, Assignment assignment) {
        validateAllowedToEditWorkOrder(workOrderId);
        BusinessContact businessContact = workOrderAssignmentValidator.validateAndReturnBusinessContact(assignment);
        workOrderAssignmentValidator.validate(assignment, businessContact);
        if (assignment.skillRef.name != null) {
            populateAssignmentDefaultLaborRate(assignment, businessContact);
        }
        fillRealPropertyFunding(assignment.estimatedCosts);
        return microservice.saveAssignment(workOrderId, assignment);
        //  processEstimatedCostsFinanceRequest
    }

    public WorkOrder removeAssignment(String workOrderId, Assignment assignment) {
        validateAllowedToEditWorkOrder(workOrderId);
        WorkOrder workOrder = microservice.removeAssignment(workOrderId, assignment);
        processEstimatedCostsFinanceRequest(null, Arrays.asList(workOrder),  WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_REMOVE, assignment, false);
        return workOrder;
    }

    public List<Standards> getStandardsForWorkOrder(String workOrderId) {
        List<Standards> standardList = microservice.getStandardsForWorkOrder(workOrderId);
        if (standardList == null || standardList.isEmpty()) {
            WorkOrder workOrder = microservice.findById(workOrderId);
            if (workOrder.maintenanceProcedureRef != null) {
                String maintenanceId = workOrder.maintenanceProcedureRef.getId();
                if (!StringUtil.isEmptyOrNull(maintenanceId)) {
                    MaintenanceProcedure maintenanceProcedure = assetMaintenanceProcedureService.findById(maintenanceId);
                    if (maintenanceProcedure == null) { // should only occur if there is bad data
                        throw new ApplicationException("Maintenance Procedure not found");
                    }
                    if (createStandardFromMaintenanceProcedure(maintenanceProcedure)) {
                        Standards standard = new Standards();
                        standard.regulatoryComplianceCodeRef = new RegulatoryComplianceCodeRef();
                        standard.regulatoryComplianceCodeRef.id = maintenanceProcedure.regulatoryComplianceCodeRef.getId();
                        standard.regulatoryComplianceCodeRef.name = maintenanceProcedure.regulatoryComplianceCodeRef.name;
                        standard.regulatoryComplianceCodeRef.managedByNodeRef = maintenanceProcedure.regulatoryComplianceCodeRef.managedByNodeRef;
                        standard.regulatoryComplianceSubject = maintenanceProcedure.regulatoryComplianceSubject;
                        standard.paragraphNumber = maintenanceProcedure.regulatoryParagraphNumber;
                        standard.paragraphText = maintenanceProcedure.regulatoryParagraphText;
                        microservice.addStandard(workOrderId, standard);
                    }
                }
            }
            return microservice.getStandardsForWorkOrder(workOrderId);
        } else {
            return standardList;
        }
    }

    private boolean createStandardFromMaintenanceProcedure(MaintenanceProcedure maintenanceProcedure) {
        boolean create = false;
        if (!StringUtil.isEmptyOrNull(maintenanceProcedure.regulatoryComplianceSubject)
                || !StringUtil.isEmptyOrNull(maintenanceProcedure.regulatoryParagraphNumber)
                || !StringUtil.isEmptyOrNull(maintenanceProcedure.regulatoryParagraphText)) {
            create = true;
        }
        if (maintenanceProcedure.regulatoryComplianceCodeRef != null) {
            if (!StringUtil.isEmptyOrNull(maintenanceProcedure.regulatoryComplianceCodeRef.getId())
                    && !StringUtil.isEmptyOrNull(maintenanceProcedure.regulatoryComplianceCodeRef.name)) {
                create = true;
            }
        }
        return create;
    }

    public List<RegulatoryComplianceCodeRef> getRegulatoryComplianceCodeRefs() {
        List<RegulatoryComplianceCode> regulatoryComplianceCodes = assetMaintenanceProcedureService.getRegulatoryComplianceCodes();
        List<RegulatoryComplianceCodeRef> returnList = new ArrayList<>();
        for (RegulatoryComplianceCode code : regulatoryComplianceCodes) {
            RegulatoryComplianceCodeRef codeRef = code.getRef();
            returnList.add(codeRef);
        }
        return returnList;
    }

    public List<RegulatoryComplianceSubject> getRegulatoryComplianceSubjects() {
        return assetMaintenanceProcedureService.getRegulatoryComplianceSubjects();
    }

    public WorkOrder addStandard(String workOrderId, Standards standards) {
        validateAllowedToEditWorkOrder(workOrderId);
        workOrderStandardsValidator.validate(standards);
        return microservice.addStandard(workOrderId, standards);
    }

    public WorkOrder saveStandard(String workOrderId, Standards standards) {
        validateAllowedToEditWorkOrder(workOrderId);
        workOrderStandardsValidator.validate(standards);
        return microservice.saveStandard(workOrderId, standards);
    }

    public WorkOrder removeStandard(String workOrderId, Standards standards) {
        validateAllowedToEditWorkOrder(workOrderId);
        return microservice.removeStandard(workOrderId, standards);
    }

    public BulkResponse updateSectionInspectionForWorkOrders(List<String> ids, boolean isSectionInspection) {
        validateBulkUpdateRecordLimit(ids.size());
        List<WorkOrder> workOrders = microservice.findByIds(ids);
        List<Asset> assets = new ArrayList<>();

        if (isSectionInspection) {
            List<String> assetIds = new ArrayList<>();
            workOrders.stream()
                    .filter(workOrder -> workOrder.assetRefs != null && !workOrder.assetRefs.isEmpty())
                    .flatMap(workOrder -> workOrder.assetRefs.stream())
                    .forEach(assetRef -> assetIds.add(assetRef.getId()));

            assets = assetService.getAssetsByAssetIds(assetIds);
        }

        return microservice.updateSectionInspectionForWorkOrders(ids, isSectionInspection, assets);
    }

    public WorkOrder startScheduled(String workorderId) {
        WorkOrder workOrder = microservice.findById(workorderId);

        workflowService.startScheduled(workOrder, currentUserBT.getCurrentUser().profile.managedByNodeRef);
        return workOrder;

    }

    public WorkOrder openScheduled(String workorderId) {
        WorkOrder workOrder = microservice.findById(workorderId);

        if (workOrder == null) {
            throw new ApplicationException(String.format(NO_WORK_ORDER_FOUND, workorderId));
        }

        if (EWorkflowStepName.IN_PROGRESS.position <= workOrder.workflowState.currentStep.workflowStepDefinition.position) {
            throw new ApplicationException("The next scheduled work order has already been opened.");
        }

        workflowService.openScheduled(workOrder, currentUserBT.getCurrentUser());
        return workOrder;

    }

    public List<WorkOrder> getScheduledWithExclusion(String id) {
        return microservice.getScheduledWithExclusion(id);
    }

    public WorkOrder updateEnvironmentalImpacts(String workOrderId,
                                                EnvironmentalImpactSummary environmentalImpactSummary) {
        WorkOrder workOrder = microservice.findById(workOrderId);
        if (workOrder == null) {
            throw new ApplicationException(String.format(NO_WORK_ORDER_FOUND, workOrderId));
        }
        String currentStepName = getWorkflowCurrentStepName(workOrder);
        if (!EWorkflowStepName.IN_PROGRESS.displayText.equals(currentStepName)) {
            throw new ApplicationException(
                    String.format("Cannot update environmentalImpactSummary unless WorkOrder.workflowState.currentStep.name is %s",
                            EWorkflowStepName.IN_PROGRESS.displayText));
        }
        return microservice.updateEnvironmentalImpacts(workOrderId, environmentalImpactSummary);
    }

    public List<AssetSummary> getAssetSummariesByFacilityId(String facilityId, EActiveStatus activeStatus) {
        return assetService.getAssetSummariesByFacilityId(facilityId, false, activeStatus);
    }

    public long getCountByPriorityGroupAndScope(String priorityGroupId, String scopeOrgId) {
        List<String> orgIds = organizationService.getOrganizationIdsAtAndBelow(scopeOrgId);
        List<String> workflowDefinitionNames = new ArrayList<>();
        workflowDefinitionNames.add(EWorkflowName.STANDARD_WORK_ORDER.displayText);
        workflowDefinitionNames.add(EWorkflowName.STANDARD_SERVICE_REQUEST.displayText);
        return microservice.getCountByPriorityGroupAndScope(priorityGroupId, orgIds, workflowDefinitionNames, Collections.singletonList(EWorkflowStepName.CLOSED.position));
    }

    public long getCountByClassificationTypeAndScope(String classificationTypeId, String scopeOrgId) {
        List<String> orgIds = organizationService.getOrganizationIdsAtAndBelow(scopeOrgId);
        List<String> workflowDefinitionNames = new ArrayList<>();
        workflowDefinitionNames.add(EWorkflowName.STANDARD_WORK_ORDER.displayText);
        workflowDefinitionNames.add(EWorkflowName.STANDARD_SERVICE_REQUEST.displayText);
        return microservice.getCountByClassificationTypeAndScope(classificationTypeId, orgIds, workflowDefinitionNames, Collections.singletonList(EWorkflowStepName.CLOSED.position));
    }

    public ImpactReason updateImpactReason(String id, String name) {
        return microservice.updateImpactReason(id, name);
    }

    public void deleteImpactReason(ImpactReason impactReason) {
        microservice.deleteImpactReason(impactReason);
    }

    public ImpactType updateImpactType(String id, String name) {
        return microservice.updateImpactType(id, name);
    }

    public void deleteImpactType(ImpactType impactType) {
        microservice.deleteImpactType(impactType);
    }

    public void processImpactReasonRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processImpactReasonRefUpdate(dataReferenceUpdate);
    }

    public void processImpactTypeRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processImpactTypeRefUpdate(dataReferenceUpdate);
    }

    public List<ImpactType> getImpactTypes() {
        return microservice.getImpactTypes();
    }

    public List<ImpactReason> getImpactReasons() {
        return microservice.getImpactReasons();
    }

    public WorkOrder addImpact(String id, Impact impact) {
        validateAllowedToEditWorkOrder(id);
        return microservice.addImpact(id, impact);
    }

    public WorkOrder saveImpact(String id, Impact impact) {
        validateAllowedToEditWorkOrder(id);
        return microservice.saveImpact(id, impact);
    }

    public WorkOrder removeImpact(String id, Impact impact) {
        validateAllowedToEditWorkOrder(id);
        return microservice.removeImpact(id, impact);
    }

    public void processTagRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processTagRefUpdate(dataReferenceUpdate);
    }

    public WorkOrder addComment(String id, Comment comment) {
        validateAllowedToCommentAndNote(id);
        UserProfile currUserProfile = currentUserBT.getCurrentUser().profile;
        comment.firstName = currUserProfile.firstName;
        comment.lastName = currUserProfile.lastName;
        comment.userId = currUserProfile.getId();
        comment.created = new Date();
        return microservice.addComment(id, comment);
    }

    public WorkOrder addComment(String id, Comment comment, Date customActionDate) {
        validateAllowedToCommentAndNote(id);
        UserProfile currUserProfile = currentUserBT.getCurrentUser().profile;
        comment.firstName = currUserProfile.firstName;
        comment.lastName = currUserProfile.lastName;
        comment.userId = currUserProfile.getId();
        comment.created = customActionDate;
        return microservice.addComment(id, comment);
    }

    public WorkOrder removeComment(String id, Comment comment) {
        validateAllowedToCommentAndNote(id);
        validateAllowedToModifyComment(comment);
        return microservice.removeComment(id, comment);
    }

    public WorkOrder saveComment(String id, Comment comment) {
        validateAllowedToCommentAndNote(id);
        validateAllowedToModifyComment(comment);
        return microservice.saveComment(id, comment);
    }

    public List<Zone> getZonesByFacilityId(String facilityId) {
        return spaceManagementService.getZonesByFacilityId(facilityId);
    }

    public List<ZoneRef> getZoneRefsByFacilityId(String facilityId) {
        List<ZoneRef> zoneRefs = null;
        List<Zone> zones = this.getZonesByFacilityId(facilityId);
        if (!ListUtil.isEmpty(zones)) {
            zoneRefs = new ArrayList<>();
            for (Zone z : zones) {
                zoneRefs.add((ZoneRef) z.getRef());
            }
        }
        return zoneRefs;
    }

    public List<Zone> getZonesByIds(List<String> zoneIds) {
        return this.spaceManagementService.getZonesByIds(zoneIds);
    }

    private String getWorkflowCurrentStepName(WorkOrder workOrder) {
        if (workOrder == null ||
                workOrder.workflowState == null ||
                workOrder.workflowState.currentStep == null ||
                StringUtil.isBlankOrNull(workOrder.workflowState.currentStep.name)) {
            throw new ApplicationException("Unable to determine workflow current step");
        }
        return workOrder.workflowState.currentStep.name;
    }

    public List<FloorRooms> getWorkOrderFacilityFloorsAndRooms(String workOrderId) {
        List<FloorRooms> floorRoomsList;
        WorkOrder workOrder = microservice.findById(workOrderId);
        List<Floor> floors = spaceManagementService.getFloorsByFacilityId(workOrder.facilityRef.id);
        floorRoomsList = floors.stream().map(floor -> buildFloorRooms(workOrder, floor)).collect(Collectors.toList());
        if (!workOrder.spaceRefs.isEmpty()) {
            List<Space> roomsByFacilityId = spaceManagementService.getRoomsByFacilityId(workOrder.facilityRef.id);
            List<Space> roomsAssigned = roomsByFacilityId.stream().filter(room -> workOrder.spaceRefs.stream().anyMatch(spaceRef -> Objects.equals(spaceRef.id, room.getId()))).collect(Collectors.toList());
            floorRoomsList = floorRoomsList.stream().map(floorRooms -> {
                floorRooms.roomNumbers = roomsAssigned.stream()
                        .filter(roomAssigned -> roomAssigned.floorRef != null && Objects.equals(roomAssigned.floorRef.id, floorRooms.floor.getId()))
                        .map(roomAssigned -> roomAssigned.identifier)
                        .collect(Collectors.toList());
                return floorRooms;
            }).filter(floorRooms -> !floorRooms.roomNumbers.isEmpty()).collect(Collectors.toList());
        }

        return floorRoomsList;
    }

    private FloorRooms buildFloorRooms(WorkOrder workOrder, Floor floor) {
        FloorRooms floorRooms = new FloorRooms();
        floorRooms.workOrderId = workOrder.getId();
        floorRooms.facilityId = workOrder.facilityRef.id;
        floorRooms.floor = floor;
        return floorRooms;
    }

    public WorkOrder startUnscheduled(String id) {
        WorkOrder workOrder = microservice.findById(id);
        validateWorkOrderFound(workOrder);
        workflowService.startUnscheduled(workOrder, currentUserBT.getCurrentUser().profile.managedByNodeRef);
        return workOrder;
    }

    public WorkOrder startUnscheduled(String id, Date customStartDate) {
        WorkOrder workOrder = microservice.findById(id);
        validateWorkOrderFound(workOrder);
        initializeRequestWorkflowData(customStartDate);
        workflowService.startUnscheduled(workOrder, currentUserBT.getCurrentUser().profile.managedByNodeRef);
        return workOrder;
    }

    public WorkOrder sendForReview(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workflowService.sendForReview(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.SEND_FOR_REVIEW.displayText);
        return workOrder;
    }

    public WorkOrder sendForReview(WorkOrder workOrderWorkItem, Date customActionDate) {
        return sendForReview(workOrderWorkItem, customActionDate, false);
    }

    public WorkOrder sendForReview(WorkOrder workOrderWorkItem, Date customActionDate, boolean dummyWorkflow) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        if (!dummyWorkflow) {
            initializeRequestWorkflowData(customActionDate);
        }
        workflowService.sendForReview(workOrder, currentUserBT.getCurrentUser());
        return workOrder;
    }

    private void sendServiceRequestEmailNotification(WorkOrder workOrder, String action) {
        if (null != workOrder.createdByRef && !StringUtil.isEmptyOrNull(workOrder.createdByRef.id)) {
            UserProfile messageRecipient = userService.getUserProfileById(workOrder.createdByRef.getId());
            List<UserProfile> usersToNotify = new ArrayList<>();
            usersToNotify.add(messageRecipient);

            if (workOrder.classificationTypeRef != null &&
                    workOrder.classificationTypeRef.name.equalsIgnoreCase(CLASSIFICATION_TYPE_NAME_SERVICE_REQUEST) && !StringUtil.isEmptyOrNull(messageRecipient.email)) {
                Map<String, String> notificationData = new HashMap<>();
                notificationData.put("@NAME", messageRecipient.firstName);
                notificationData.put("@USER_NAME", currentUserBT.getCurrentUser().getRef().fullName);
                notificationData.put("@UPDATED_DATE", DateUtil.getFriendlyDateString(new Date()));
                notificationData.put("@WORK_ORDER_NUM", workOrder.workOrderNumber);
                notificationData.put("@ACTION", action);
                notificationData.put("@STATUS", workOrder.workflowState.currentStep.name);
                notificationData.put("@REASON", (workOrder.newComment != null
                        && StringUtils.isNotBlank(workOrder.newComment.text)) ? workOrder.newComment.text : "");
                sendNotification(usersToNotify, messageRecipient, ENotificationType.WORKORDER_SEND_SERVICE_REQUEST, notificationData);
            }
        }
    }

    private void sendNotification(List<UserProfile> usersToNotify, UserProfile submitter, ENotificationType nType,
                                  Map<String, String> notificationData) {
        ApplicationNotificationWrapper wrapper = new ApplicationNotificationWrapper();
        wrapper.usersToNotify.addAll(usersToNotify);
        wrapper.notificationType = nType;
        wrapper.messageData = notificationData;
        wrapper.submitterProfile = submitter;
        wrapper.emailAddresses = notificationService.findEmailAddressesToNotify(usersToNotify);
        wrapper = microservice.getWorkOrderNotifications(wrapper);
        notificationService.sendEmail(wrapper.emailMessage);
    }

    public WorkOrder complete(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.relatedCause = workOrderWorkItem.relatedCause;
        workOrder.completionDate = workOrderWorkItem.completionDate;
        workflowService.complete(workOrder, currentUserBT.getCurrentUser());

        if (!workOrder.isQualityControlRequired) {
            markQualityControlAsNotRequired(workOrder);
        }

        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.COMPLETE.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder complete(WorkOrder workOrderWorkItem, Date customActionDate) {
        return complete(workOrderWorkItem, customActionDate, true, false);
    }

    public WorkOrder complete(WorkOrder workOrderWorkItem, Date customActionDate, boolean markQcAsNotRequired) {
        return complete(workOrderWorkItem, customActionDate, markQcAsNotRequired, false);
    }

    public WorkOrder complete(WorkOrder workOrderWorkItem,
                              Date customActionDate,
                              boolean markQcAsNotRequired,
                              boolean dummyWorkflow) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        if (!dummyWorkflow) {
            initializeRequestWorkflowData(customActionDate);
        }

        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.relatedCause = workOrderWorkItem.relatedCause;
        workOrder.completionDate = workOrderWorkItem.completionDate;

        workflowService.complete(workOrder, currentUserBT.getCurrentUser());

        if (dummyWorkflow ||
                (markQcAsNotRequired && !workOrder.isQualityControlRequired)) {
            markQualityControlAsNotRequired(workOrder, customActionDate);
        }

        return microservice.findById(workOrder.getId());
    }

    public WorkOrder cancel(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.relatedCause = workOrderWorkItem.relatedCause;
        workOrder.completionDate = workOrderWorkItem.completionDate;
        workflowService.cancel(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.CANCEL.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder cancel(WorkOrder workOrderWorkItem, Date customActionDate) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        initializeRequestWorkflowData(customActionDate);

        if (workOrder.newComment == null) {
            legacyWorkflowUtil.addNewComment(
                    workOrderWorkItem, customActionDate, WorkOrderLegacyWorkflowUtil.COMMENT_LEGACY_CANCELLED);
        }

        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.relatedCause = workOrderWorkItem.relatedCause;
        workOrder.completionDate = workOrderWorkItem.completionDate;

        workflowService.cancel(workOrder, currentUserBT.getCurrentUser());
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder accept(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workflowService.accept(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.ACCEPT.displayText);
        removeWorkOrderRefFromRequirement(workOrder);
        WorkOrder acceptedWO = microservice.findById(workOrder.getId());

        processActualCostFinanceRequest(Arrays.asList(acceptedWO));
        return workOrder;
    }

    public WorkOrder accept(WorkOrder workOrderWorkItem, Date customActionDate, boolean workflowOnly) {
    	return  accept(workOrderWorkItem, customActionDate, workflowOnly, true);
    }

    public WorkOrder accept(WorkOrder workOrderWorkItem, Date customActionDate, boolean workflowOnly, boolean needFinanceTrans) {
        // workflowOnly of TRUE indicates that only the Workflow will be modified; actual Refs not to be created
        // (Primarily for data migration work)
        initializeRequestWorkflowData(customActionDate);

        if (requestHasCustomDate() && workflowOnly) {
            addRequestWorkflowDataCustomInstruction(WorkOrderLegacyWorkflowUtil.DO_NOT_CLOSE_ASSOCIATED_REQUIREMENTS);
        }

        if (workOrderWorkItem.newComment == null) {
            legacyWorkflowUtil.addNewComment(
                    workOrderWorkItem, customActionDate, WorkOrderLegacyWorkflowUtil.COMMENT_LEGACY_ACCEPTED);
        }

        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);

        workOrder.newComment = workOrderWorkItem.newComment;

        workflowService.accept(workOrder, currentUserBT.getCurrentUser());

        if (!workflowOnly) {
            removeWorkOrderRefFromRequirement(workOrder);
        }

        WorkOrder acceptedWO =  microservice.findById(workOrder.getId());

        if ( needFinanceTrans ) {
        	processActualCostFinanceRequest(Arrays.asList(acceptedWO));
        }
        return workOrder;
    }

    private void removeWorkOrderRefFromRequirement(WorkOrder workOrder) {
        if (EWorkflowActionName.CANCEL.displayText.equals(workOrder.closeOutReason)) {
            requirementService.removeAssociatedWorkOrder(workOrder.getId());
        }
    }

    public WorkOrderType updateWorkOrderType(WorkOrderType workOrderType) {
        WorkOrderType foundWorkOrderType = microservice.getWorkOrderTypeById(workOrderType.getId());
        if (foundWorkOrderType == null) {
            throw new ApplicationException("WorkOrder Type does not exist");
        } else {
            if (!foundWorkOrderType.name.equalsIgnoreCase(workOrderType.name) && microservice.getWorkOrderTypeByName(workOrderType.name) != null) {
                throw new ApplicationException("WorkOrder Type already exists");
            } else {
                return microservice.updateWorkOrderType(workOrderType);
            }
        }
    }

    public WorkOrderType createWorkOrderType(WorkOrderType workOrderType) {
        WorkOrderType foundWorkOrderType = microservice.getWorkOrderTypeByName(workOrderType.name);
        if (foundWorkOrderType == null) {
            workOrderType.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.createWorkOrderType(workOrderType);
        } else {
            throw new ApplicationException("WorkOrder Type already exists");
        }
    }

    public boolean deleteWorkOrderType(String id) {
        WorkOrderType foundWorkOrderType = microservice.getWorkOrderTypeById(id);
        if (foundWorkOrderType == null) {
            throw new ApplicationException("WorkOrder Type does not exist");
        } else {
            return microservice.deleteWorkOrderType(id);
        }
    }

    public List<WorkOrderType> getActiveWorkOrderTypes() {
        return microservice.getActiveWorkOrderTypes();
    }

    public WorkOrder addNonCatalogPart(String id, NonCatalogPart nonCatalogPart) {
        validateAllowedToEditWorkOrder(id);
        new WorkOrderNonCatalogPartValidator().validate(nonCatalogPart);
        return microservice.addNonCatalogPart(id, nonCatalogPart);
    }

    public WorkOrder updateNonCatalogPart(String id, NonCatalogPart nonCatalogPart) {
        validateAllowedToEditWorkOrder(id);
        new WorkOrderNonCatalogPartValidator().validate(nonCatalogPart);
        return microservice.updateNonCatalogPart(id, nonCatalogPart);
    }

    public WorkOrder removeNonCatalogPart(String id, NonCatalogPart nonCatalogPart) {
        validateAllowedToEditWorkOrder(id);
        return microservice.removeNonCatalogPart(id, nonCatalogPart);
    }

    public String findDupeNonCatalogPart(String workOrderId, NonCatalogPart nonCatalogPart) {
        return microservice.findDupeNonCatalogPart(workOrderId, nonCatalogPart);
    }

    public List<NonCatalogPart> getNonCatalogParts() {
        return microservice.getNonCatalogParts();
    }

    public List<String> findSourceOptions() {
        List<String> sourceOptions = new ArrayList<>();
        List<String> vendor = new ArrayList<>();
        vendor.add("VENDOR");

        businessContactService.getBusinessContactByType(vendor).forEach(contact -> sourceOptions.add(contact.name));
        microservice.findSourceOptions().forEach(name -> sourceOptions.add(name));

        return sourceOptions;
    }

    public List<PartOption> findPartOptions() {
        return microservice.findPartOptions();
    }

    public List<String> getAvailableCostTypes(String workOrderId) {
        return microservice.getAvailableCostTypes(workOrderId);
    }

    public WorkOrder addActualCost(String workOrderId, String assignmentId, ActualCost actualCost) {
        validateAllowedToEditWorkOrder(workOrderId);
        validateActualCost(workOrderId, assignmentId, actualCost);
        fillRealPropertyFunding(actualCost.costSummary);
        return microservice.addActualCost(workOrderId, assignmentId, actualCost);
    }

    public WorkOrder updateActualCost(String workOrderId, String assignmentId, ActualCost actualCost) {
        validateAllowedToEditWorkOrder(workOrderId);
        validateActualCost(workOrderId, assignmentId, actualCost);
        fillRealPropertyFunding(actualCost.costSummary);
        return microservice.updateActualCost(workOrderId, actualCost);
    }

    private void validateActualCost(String workOrderId, String assignmentId, ActualCost actualCost) {
        List<Assignment> assignmentsForWorkOrder = getAssignmentsForWorkOrder(workOrderId);
        Optional<Assignment> assignmentOptional = assignmentsForWorkOrder.stream().filter(assignment -> Objects.equals(assignment.assignmentId, assignmentId)).findFirst();
        assignmentOptional.ifPresent(assignment -> workOrderAssignmentValidator.validateActualCost(assignment, actualCost));
    }

    public WorkOrder deleteActualCost(String workOrderId, String assignmentId, ActualCost actualCost) {
        validateAllowedToEditWorkOrder(workOrderId);
        return microservice.deleteActualCost(assignmentId, actualCost);
    }

    public WorkOrder prorateCostAndHours(String workOrderId, String assignmentId, String actualCostId) {
        validateAllowedToEditWorkOrder(workOrderId);
        return microservice.prorateCostAndHours(workOrderId, assignmentId, actualCostId);
    }

    public List<ActualCost> getProratedActualCost(String workOrderId, ActualCost actualCost) {
        return microservice.getProratedActualCost(workOrderId, actualCost);
    }

    public void processAssetRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processAssetRefUpdate(dataReferenceUpdate);
    }

    public void processSpaceRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processSpaceRefUpdate(dataReferenceUpdate);
    }

    public void processScheduleRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processScheduleRefUpdate(dataReferenceUpdate);
    }

    public BulkResponse bulkOpenScheduled(List<String> ids) {
        //validateBulkUpdateRecordLimit(ids.size());
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        List<WorkOrder> workOrders = microservice.findByIds(ids);
        BulkResponse bulkResponse = openScheduled(workOrders, currentUser);
        List<WorkOrder> workOrdersOpened = workOrders.stream().filter(workOrder -> bulkResponse.successfulItems.contains(workOrder.workOrderNumber)).collect(Collectors.toList());
        List<String> scheduleIds = new ArrayList<>();
        for (WorkOrder wo : workOrdersOpened) {
            scheduleIds.add(wo.scheduleRef.getId());
        }
        List<Schedule> schedulesForOpenedWorkOrders = assetScheduleService.findSchedulesByIds(scheduleIds);
        generateNewWorkOrdersForSchedules(schedulesForOpenedWorkOrders);
        deleteOldRolledUpWorkOrdersForSchedules(schedulesForOpenedWorkOrders, workOrdersOpened);
        return bulkResponse;
    }

    private BulkResponse openScheduled(List<WorkOrder> workOrders, CurrentUser currentUser) {
        BulkResponse bulkResponse = new BulkResponse();
        workOrders.sort(Comparator.comparing(wo -> wo.estimatedStartDate));  // Sorting essential for call to scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder()
        for (WorkOrder workOrder : workOrders) {
            if (workOrder.scheduleRef != null) {
                Schedule schedule = assetScheduleService.findScheduleById(workOrder.scheduleRef.getId());
                boolean scheduleContainsOlderUnopenedWorkOrders = scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder(schedule, workOrder);
                if (scheduleContainsOlderUnopenedWorkOrders) {
                    FailedItem item = new FailedItem();
                    item.workOrderNumber = workOrder.workOrderNumber;
                    item.errorMsg = String.format("The schedule for work order %s has work order(s) before this one that need to be opened first", item.workOrderNumber);
                    bulkResponse.failedItems.add(item);
                } else if (workOrder.workflowState == null || workOrder.workflowState.currentStep.workflowStepDefinition.position >= EWorkflowStepName.IN_PROGRESS.position) {
                    FailedItem item = new FailedItem();
                    item.workOrderNumber = workOrder.workOrderNumber;
                    item.errorMsg = String.format("The work order has already been opened - %s", item.workOrderNumber);
                    bulkResponse.failedItems.add(item);
                } else {
                    WorkOrder openedWorkOrder = workflowService.openScheduled(workOrder, currentUser);
                    saveWorkOrder(openedWorkOrder);
                    bulkResponse.successfulItems.add(workOrder.workOrderNumber);
                }
            }
        }
        return bulkResponse;
    }

    private void generateNewWorkOrdersForSchedules(List<Schedule> schedules) {
        List<String> scheduleIdsAlreadyProcessed = new ArrayList<>();
        for (Schedule schedule : schedules) {
            String scheduleId = schedule.getId();
            if (!scheduleIdsAlreadyProcessed.contains(scheduleId)) {
                createWorkOrdersForScheduleAppend(schedule);
                scheduleIdsAlreadyProcessed.add(scheduleId);
            }
        }
    }

    private void deleteOldRolledUpWorkOrdersForSchedules(List<Schedule> schedules, List<WorkOrder> workOrders) {
        List<String> assetIds = schedules.stream().filter(schedule -> schedule.assetRefs != null).flatMap(schedule -> schedule.assetRefs.stream()).map(AssetRef::getId).collect(Collectors.toList());
        List<Schedule> schedulesByAssetIds = assetScheduleService.getSchedulesByAssetIds(assetIds);
        Optional<WorkOrder> maxDateWorkOrderOptional = workOrders.stream().max(Comparator.comparing(o -> o.estimatedStartDate));
        if (maxDateWorkOrderOptional.isPresent()) {
            WorkOrder maxDateWorkOrder = maxDateWorkOrderOptional.get();
            List<String> workOrderIdsToDelete = getOldRolledUpWorkOrderIdsForSchedules(schedulesByAssetIds, maxDateWorkOrder);
            deleteWorkOrders(workOrderIdsToDelete);
        }
    }

    private List<String> getOldRolledUpWorkOrderIdsForSchedules(List<Schedule> schedulesByAssetIds, WorkOrder maxDateWorkOrder) {
        return schedulesByAssetIds.stream().flatMap(schedule -> getWorkOrderSummariesBySchedule(schedule.getId()).stream())
                .filter(woSummary -> woSummary.isRolledUp)
                .filter(woSummary -> woSummary.workflowCurrentPosition == EWorkflowStepName.SCHEDULED.position)
                .filter(woSummary -> woSummary.estimatedStartDate.before(maxDateWorkOrder.estimatedStartDate) || woSummary.estimatedStartDate.equals(maxDateWorkOrder.estimatedStartDate))
                .map(WorkOrderSummary::getId)
                .collect(Collectors.toList());
    }

    protected boolean scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder(Schedule schedule, WorkOrder desiredWorkOrder) {
        return getSortedWorkOrderSummariesBySchedule(schedule.getId()).stream().anyMatch(woSummary -> {
            LocalDate woEstimatedStartLocalDate = DateUtil.localDateFromDate(woSummary.estimatedStartDate);
            LocalDate desiredWoEstimatedStartLocalDate = DateUtil.localDateFromDate(desiredWorkOrder.estimatedStartDate);

            return ((woSummary.workflowCurrentStepName == null || woSummary.workflowCurrentPosition <= EWorkflowStepName.SCHEDULED.position) &&
                    woEstimatedStartLocalDate.isBefore(desiredWoEstimatedStartLocalDate));
        });
    }

    public List<String> getEnvironmentalImpactOptions() {
        return EEnvironmentalImpact.getDisplayTextList();
    }

    public List<OccupantRef> getOccupantRefsbySite(String siteId) {
        List<Occupant> activeOccupantsBySite = spaceManagementService
                .getActiveOccupantsBySite(siteId, true);
        return activeOccupantsBySite.stream().map(Occupant::getRef).collect(Collectors.toList());
    }

    public List<RoomSummary> getRoomSummariesByFacilityId(String facilityId) {
        return spaceManagementService.getRoomSummariesByFacilityIds(Collections.singletonList(facilityId));
    }

    public Facility getFacilityById(String facilityId) {
        return facilityService.getFacilityById(facilityId);
    }

    public PriorityGroupRef getPriorityGroupFromRequirementCriticality(ERequirementCriticality eRequirementCriticality) {
        return microservice.getPriorityGroupFromRequirementCriticality(eRequirementCriticality);
    }

    public SeverityRef getSeverityFromRequirementCriticality(ERequirementCriticality eRequirementCriticality) {
        return microservice.getSeverityFromRequirementCriticality(eRequirementCriticality);
    }

    public PriorityGroupRef getDefaultPriorityGroupRef() {
        return microservice.getDefaultPriorityGroupRef();
    }

    public SeverityRef getDefaultSeverityRef() {
        return microservice.getDefaultSeverityRef();
    }

    public ClassificationTypeRef getDefaultClassificationTypeRef() {
        return microservice.getDefaultClassificationTypeRef();
    }

    public WorkOrderRequirementMigrationResult migrateWorkOrderRequirementAssociation(String siteDodaac,
                                                                                      Integer dmlssWorkRequestSerial,
                                                                                      String dmlssRequirementNumber,
                                                                                      Integer dmlssRequirementSerial) {
        workOrderRequirementLegacyValidator.validateRequiredFields(
                siteDodaac, dmlssWorkRequestSerial, dmlssRequirementNumber, dmlssRequirementSerial);

        WorkOrderRequirementLegacyValidator.EScenario eScenario
                = workOrderRequirementLegacyValidator.determineScenario(dmlssRequirementNumber, dmlssRequirementSerial);

        WorkOrder workOrder = getWorkOrderForDataMigrationAssoc(siteDodaac, dmlssWorkRequestSerial);
        Requirement requirement = getRequirementForDataMigrationAssoc(siteDodaac, dmlssRequirementSerial, dmlssRequirementNumber);

        workOrderRequirementLegacyValidator.validateFacilityAgreement(workOrder, requirement);

        List<WorkOrder> otherWorkOrdersAssocWithThisRqmt = getWorkOrdersByRequirementId(requirement.getId()).stream()
                .filter(wo -> !(wo.getId().equals(workOrder.getId())))
                .collect(Collectors.toList());

        List<Requirement> otherRqmtsAssocWithThisWO = requirementService.getRequirementsByWorkOrderId(workOrder.getId()).stream()
                .filter(r -> !(r.getId().equals(requirement.getId())))
                .collect(Collectors.toList());

        WorkOrderRequirementLegacyValidator.EExistingAssociation eExistingAssociation
                = workOrderRequirementLegacyValidator.determinePreExistingAssociation(
                workOrder, requirement, otherWorkOrdersAssocWithThisRqmt, otherRqmtsAssocWithThisWO);

        WorkOrderRequirementMigrationResult migrationResult =
                workOrderRequirementLegacyValidator.initializeMigrationResult(siteDodaac, workOrder, requirement);

        switch (eExistingAssociation) {
            case ASSOCIATION_NONE_FOUND:
                switch (eScenario) {
                    case REQUIREMENT_CONVERTED_TO_WORK_REQUEST:
                        requirementService.saveWorkOrderRef(requirement.getId(), workOrder.getRef());
                        migrationResult.status = WorkOrderRequirementLegacyValidator.STATUS_SUCCESS;
                        migrationResult.msg =
                                WorkOrderRequirementLegacyValidator.EScenario.REQUIREMENT_CONVERTED_TO_WORK_REQUEST.getDisplayText();
                        break;
                    case WORK_REQUEST_CONVERTED_TO_REQUIREMENT:
                        workOrder.requirementRef = (RequirementRef) requirement.getRef();
                        microservice.updateWorkOrderRequirementRef(workOrder);
                        migrationResult.status = WorkOrderRequirementLegacyValidator.STATUS_SUCCESS;
                        migrationResult.msg =
                                WorkOrderRequirementLegacyValidator.EScenario.WORK_REQUEST_CONVERTED_TO_REQUIREMENT.getDisplayText();
                        break;
                    default:
                }
                break;
            case ASSOCIATION_FOUND_BUT_IS_THE_SAME:
                migrationResult.status = WorkOrderRequirementLegacyValidator.STATUS_WARNING;
                migrationResult.msg = eExistingAssociation.getDisplayText();
                break;
            case ASSOCATION_FOUND_AND_IS_DIFFERENT:
                String clearedRecordsInfo =
                        clearWorkOrderRequirementAssociations(workOrder,
                                requirement,
                                otherWorkOrdersAssocWithThisRqmt,
                                otherRqmtsAssocWithThisWO);
                migrationResult.status = WorkOrderRequirementLegacyValidator.STATUS_WARNING;
                migrationResult.msg = String.format("%s %s", eExistingAssociation.getDisplayText(), clearedRecordsInfo);
                break;
            default:  // Should never happen
                throw new ApplicationException(String.format(
                        "Unable to determine if pre-existing association exists between WorkOrder %s and Requirement %s",
                        workOrder.getId(), requirement.getId()));
        }

        return migrationResult;
    }

    private WorkOrder getWorkOrderForDataMigrationAssoc(String siteDodaac, Integer dmlssWorkRequestSerial) {
        List<WorkOrder> workOrders = findBySiteDodaacAndDmlssWorkRequestSerial(siteDodaac, dmlssWorkRequestSerial);

        if (ListUtil.isEmpty(workOrders)) {
            throw new ApplicationException(String.format(
                    "WorkOrder not found (siteDodaac %s, dmlssWorkRequestSerial %d)", siteDodaac, dmlssWorkRequestSerial));
        } else if (workOrders.size() > 1) {
            throw new ApplicationException(String.format(
                    "More than one WorkOrder found (siteDodaac %s, dmlssWorkRequestSerial %d)", siteDodaac, dmlssWorkRequestSerial));
        }

        return workOrders.get(0);
    }

    private Requirement getRequirementForDataMigrationAssoc(String siteDodaac, Integer dmlssRequirementSerial, String dmlssRequirementNumber) {
        Requirement requirement = null;

        if (dmlssRequirementSerial != null) {
            requirement = requirementService.getRequirementBySiteDodaacAndDmlssRequirementSerial(siteDodaac, dmlssRequirementSerial);
        } else if (dmlssRequirementNumber != null) {
            requirement = requirementService.getRequirementBySiteDodaacAndDmlssRequirementNumber(siteDodaac, dmlssRequirementNumber);
        }

        if (requirement == null) {
            throw new ApplicationException(String.format(
                    "Requirement not found (siteDodaac %s, dmlssRequirementSerial %d, dmlssRequirementNumber %s",
                    siteDodaac, dmlssRequirementSerial, dmlssRequirementNumber));
        }

        return requirement;
    }

    private String clearWorkOrderRequirementAssociations(WorkOrder thisWorkOrder,
                                                         Requirement thisRequirement,
                                                         List<WorkOrder> otherWorkOrdersAssocWithThisRqmt,
                                                         List<Requirement> otherRqmtsAssocWithThisWO) {
        StringBuilder clearedBuilder = new StringBuilder("Potentially affected records include: ");

        // Display potentially affected WorkOrders
        clearedBuilder.append(String.format(" WO %s ", thisWorkOrder.getId()));
        for (WorkOrder wo : otherWorkOrdersAssocWithThisRqmt) {
            clearedBuilder.append(String.format(" WO %s", wo.getId()));
        }
        // Display potentially affected Requirements
        clearedBuilder.append(String.format(RQMT, thisRequirement.getId()));
        for (Requirement req : otherRqmtsAssocWithThisWO) {
            clearedBuilder.append(String.format(RQMT, req.getId()));
        }

        clearedBuilder.append(" ... ");

        // Perform actual updates to WorkOrders as needed
        clearedBuilder.append(" Actual updates made: ");
        if (thisWorkOrder.requirementRef != null) {
            thisWorkOrder.requirementRef = null;
            updateWorkOrderRequirementRef(thisWorkOrder);
            clearedBuilder.append(String.format("WO %s", thisWorkOrder.getId()));
        }
        for (WorkOrder wo : otherWorkOrdersAssocWithThisRqmt) {
            if (wo.requirementRef != null) {
                wo.requirementRef = null;
                updateWorkOrderRequirementRef(wo);
                clearedBuilder.append(String.format("WO %s", wo.getId()));
            }
        }
        // Perform actual updates to Requirements as needed
        if (thisRequirement.workOrderRef != null) {
            requirementService.saveWorkOrderRef(thisRequirement.getId(), null);
            clearedBuilder.append(String.format(RQMT, thisRequirement.getId()));
        }
        for (Requirement req : otherRqmtsAssocWithThisWO) {
            if (req.workOrderRef != null) {
                requirementService.saveWorkOrderRef(req.getId(), null);
                clearedBuilder.append(String.format(RQMT, req.getId()));
            }
        }

        // Wrap it up and return result text
        clearedBuilder.append(".");
        return clearedBuilder.toString();
    }

    public WorkOrder createWorkOrderFromRequirement(Requirement requirement, FacilityRef facilityRef) {
        WorkOrder workOrder = new WorkOrder();

        Facility facility = facilityService.getFacilityById(facilityRef.id);
        workOrder.facilityRef = facility.getRef();
        workOrder.siteRef = facility.siteRef;

        workOrder.subject = requirement.title;
        workOrder.description = requirement.description;
        workOrder.requesterName = requirement.requesterName;
        workOrder.requesterContactNumber = requirement.requesterPhoneNumber;
        //if (null == requirement.requestDate) {
        workOrder.requestDate = new Date();
        //} else {
        //    workOrder.requestDate = requirement.requestDate;
        //}
        workOrder.justification = requirement.justification;
        workOrder.spaceRefs = requirement.spaceRefList;
        workOrder.zoneRefs = requirement.zoneRefList;
        workOrder.assetRefs = requirement.assetRefList;
        workOrder.otherLocation = requirement.otherLocation;
        workOrder.classificationTypeRef = getDefaultClassificationTypeRef();
        workOrder.priorityNumber = 9999;

        if (requirement.criticality != null) {
            workOrder.priorityGroupRef = getPriorityGroupFromRequirementCriticality(requirement.criticality);
            workOrder.severityRef = getSeverityFromRequirementCriticality(requirement.criticality);
        } else {
            workOrder.priorityGroupRef = getPriorityGroupFromRequirementCriticality(ERequirementCriticality.MC_NEGLIGIBLE);
        }
        return this.createWorkOrder(workOrder, true);
    }

    public WorkOrder assign(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.assign(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.ASSIGN.displayText);
        return workOrder;
    }

    public WorkOrder sendForApproval(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.sendForApproval(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.SEND_FOR_APPROVAL.displayText);
        return workOrder;
    }

    public WorkOrder approve(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.approve(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.APPROVE.displayText);
        return workOrder;
    }

    public WorkOrder sendForFundsApproval(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.sendForFundsApproval(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.SEND_FOR_FUNDS_APPROVAL.displayText);
        return workOrder;
    }

    public WorkOrder fundsApproved(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.fundsApproved(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.FUNDS_APPROVED.displayText);
        return workOrder;
    }

    public WorkOrder sendForValidation(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.sendForValidation(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.SEND_FOR_VALIDATION.displayText);
        return workOrder;
    }

    public WorkOrder validated(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.validated(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.VALIDATED.displayText);
        return workOrder;
    }

    public WorkOrder defer(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder = workflowService.defer(workOrder, currentUserBT.getCurrentUser());

        return microservice.findById(workOrder.getId());
    }

    public WorkOrder unDefer(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder = workflowService.unDefer(workOrder, currentUserBT.getCurrentUser());

        return microservice.findById(workOrder.getId());
    }

    public WorkOrder convertToRequirement(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.relatedCause = workOrderWorkItem.relatedCause;
        workOrder.completionDate = workOrderWorkItem.completionDate;
        workflowService.convertToRequirement(workOrder, currentUserBT.getCurrentUser());
        workOrder = microservice.updateWorkOrderRequirementRef(workOrder);
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.CONVERT_TO_REQUIREMENT.displayText);

        // de-commit estimate cost
        decommitEstimateCosts(workOrder);

        return workOrder;
    }

    public WorkOrder convertToRequirement(WorkOrder workOrderWorkItem, Date customActionDate, boolean workflowOnly) {
        // workflowOnly of TRUE indicates that only the Workflow will be modified; actual Refs not to be created
        // (Primarily for data migration work)
        initializeRequestWorkflowData(customActionDate);

        if (requestHasCustomDate() && workflowOnly) {
            addRequestWorkflowDataCustomInstruction(WorkOrderLegacyWorkflowUtil.DO_NOT_CREATE_REQUIREMENT_REF);
        }

        if (workOrderWorkItem.newComment == null) {
            legacyWorkflowUtil.addNewComment(
                    workOrderWorkItem, customActionDate, WorkOrderLegacyWorkflowUtil.COMMENT_LEGACY_CONVERTED_TO_REQUIREMENT);
        }

        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);

        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.relatedCause = workOrderWorkItem.relatedCause;
        workOrder.completionDate = workOrderWorkItem.completionDate;

        workOrder = workflowService.convertToRequirement(workOrder, currentUserBT.getCurrentUser());

        if (!workflowOnly) {
            workOrder = microservice.updateWorkOrderRequirementRef(workOrder);
        }

        // de-commit estimate cost
        decommitEstimateCosts(workOrder);

        return workOrder;
    }

    public Requirement getRequirementFromWorkOrderId(String workOrderId) {
        return requirementService.getRequirementFromWorkOrderId(workOrderId);
    }

    public BulkResponse bulkConvertToRequirement(List<String> workOrderIds, String reason) {
        validateBulkUpdateRecordLimit(workOrderIds.size());
        List<WorkOrder> workOrders = microservice.findByIds(workOrderIds);
        BulkResponse bulkResponse = new BulkResponse();
        Comment commentReason = new Comment();
        commentReason.text = reason;

        for (WorkOrder workOrder : workOrders) {
            try {
                workOrder.newComment = commentReason;
                workflowService.convertToRequirement(workOrder, currentUserBT.getCurrentUser());
                workOrder = microservice.updateWorkOrderRequirementRef(workOrder);
                sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.CONVERT_TO_REQUIREMENT.displayText);
                // de-commit estimate cost
                decommitEstimateCosts(workOrder);

                bulkResponse.successfulItems.add(workOrder.requirementRef.requirementNumber);
            } catch (Exception e) {
                // Fortify Note: Keeping broad catch exception to ensure the for loop processes completely
                FailedItem item = new FailedItem();
                item.workOrderNumber = workOrder.workOrderNumber;
                item.errorMsg = e.getMessage();
                bulkResponse.failedItems.add(item);
            }
        }

        return bulkResponse;
    }

    public BulkResponse bulkHoldWorkOrders(List<String> workOrderIds, String reason) {
        validateBulkUpdateRecordLimit(workOrderIds.size());
        List<WorkOrder> workOrders = microservice.findByIds(workOrderIds);
        BulkResponse bulkResponse = new BulkResponse();
        Comment commentReason = new Comment();
        commentReason.text = reason;

        for (WorkOrder workOrder : workOrders) {
            try {
                workOrder.newComment = commentReason;
                workflowService.hold(workOrder, currentUserBT.getCurrentUser());
                bulkResponse.successfulItems.add(workOrder.workOrderNumber);
            } catch (Exception e) {
                // Fortify Note: Keeping broad catch exception to ensure the for loop processes completely.
                FailedItem item = new FailedItem();
                item.workOrderNumber = workOrder.workOrderNumber;
                item.errorMsg = e.getMessage();
                bulkResponse.failedItems.add(item);
            }
        }

        return bulkResponse;
    }

    public BulkResponse bulkResumeWorkOrders(List<String> workOrderIds) {
        validateBulkUpdateRecordLimit(workOrderIds.size());
        List<WorkOrder> workOrders = microservice.findByIds(workOrderIds);
        BulkResponse bulkResponse = new BulkResponse();

        for (WorkOrder workOrder : workOrders) {
            try {
                workflowService.resume(workOrder, currentUserBT.getCurrentUser());
                bulkResponse.successfulItems.add(workOrder.workOrderNumber);
            } catch (Exception e) {
                // Fortify Note: Keeping broad catch exception to ensure for loop completely processes
                FailedItem item = new FailedItem();
                item.workOrderNumber = workOrder.workOrderNumber;
                item.errorMsg = e.getMessage();
                bulkResponse.failedItems.add(item);
            }
        }

        return bulkResponse;
    }

    public WorkOrder assignToProject(WorkOrder workOrderWorkItem) {
        validateProjectRefPresent(workOrderWorkItem);
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);

        if ( isInProgressStep(workOrder) ) {
            workOrder = sendForReview(workOrder);
        }

        workOrder.projectRef = workOrderWorkItem.projectRef;
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.relatedCause = workOrderWorkItem.relatedCause;
        workOrder.completionDate = workOrderWorkItem.completionDate;
        workOrder = workflowService.assignToProject(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.ASSIGN_TO_PROJECT.displayText);

        // de-commit estimate cost
        decommitEstimateCosts(workOrder);

        return microservice.findById(workOrder.getId());
    }

    public WorkOrder assignToProject(WorkOrder workOrderWorkItem, Date customActionDate, boolean workflowOnly) {
        // workflowOnly of TRUE indicates that only the Workflow will be modified; actual Refs not to be created
        // (Primarily for data migration work)
        initializeRequestWorkflowData(customActionDate);

        if (requestHasCustomDate() && workflowOnly) {
            addRequestWorkflowDataCustomInstruction(WorkOrderLegacyWorkflowUtil.DO_NOT_CREATE_PROJECT_REF);
        }

        if (workOrderWorkItem.newComment == null) {
            legacyWorkflowUtil.addNewComment(
                    workOrderWorkItem, customActionDate, WorkOrderLegacyWorkflowUtil.COMMENT_LEGACY_ASSIGNED_TO_PROJECT);
        }

        if (!workflowOnly) {
            validateProjectRefPresent(workOrderWorkItem);
        }

        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);

        if ( isInProgressStep(workOrder) ) {
            workOrder = sendForReview(workOrder, customActionDate);
        }

        if (!workflowOnly) {
            workOrder.projectRef = workOrderWorkItem.projectRef;
        }

        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.relatedCause = workOrderWorkItem.relatedCause;
        workOrder.completionDate = workOrderWorkItem.completionDate;

        workOrder = workflowService.assignToProject(workOrder, currentUserBT.getCurrentUser());

        // de-commit estimate cost
        decommitEstimateCosts(workOrder);

        return microservice.findById(workOrder.getId());
    }

    private boolean isInProgressStep(WorkOrder workOrder) {
        return workOrder.workflowState != null && workOrder.workflowState.currentStep != null
                && StringUtil.safeEquals(EWorkflowStepName.IN_PROGRESS.displayText, workOrder.workflowState.currentStep.name);
    }

    public WorkOrder reject(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workflowService.reject(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.REJECT.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder reject(WorkOrder workOrderWorkItem, Date customActionDate, boolean workflowOnly) {
        initializeRequestWorkflowData(customActionDate);

        if (requestHasCustomDate() && workflowOnly) {
            addRequestWorkflowDataCustomInstruction(WorkOrderLegacyWorkflowUtil.DO_NOT_UNLINK_ASSOCIATED_REQUIREMENTS);
        }

        if (workOrderWorkItem.newComment == null) {
            legacyWorkflowUtil.addNewComment(workOrderWorkItem, customActionDate, WorkOrderLegacyWorkflowUtil.COMMENT_LEGACY_REJECTED);
        }

        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;

        workflowService.reject(workOrder, currentUserBT.getCurrentUser());
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder setAwaitingParts(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workflowService.setAwaitingParts(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.AWAITING_PARTS.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder setPartsReceived(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workflowService.setPartsReceived(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.PARTS_RECEIVED.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder setPartsCancelled(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workflowService.setPartsCancelled(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.PARTS_CANCELLED.displayText);
        return microservice.findById(workOrder.getId());
    }

    public List<Skill> getAllSkills() {
        return assetMaintenanceProcedureService.getAllSkills();
    }

    public BusinessContact getBusinessContact(String businessContactId) {
        return businessContactService.getBusinessContactById(businessContactId);
    }

    public List<BusinessContact> getBusinessContacts() {
        List<String> types = new ArrayList<>();
        types.add(EBusinessContactType.ENVIRONMENTAL_SERVICE_IN_HOUSE.name());
        types.add(EBusinessContactType.ENVIRONMENTAL_SERVICE_OUTSOURCED.name());
        types.add(EBusinessContactType.MAINTENANCE_ACTIVITY_IN_HOUSE.name());
        types.add(EBusinessContactType.MAINTENANCE_ACTIVITY_OUTSOURCED.name());
        types.add(EBusinessContactType.GOVERNMENT_AGENCY.name());
        return businessContactService.getBusinessContactByType(types);
    }

    public BusinessContactRef getBusinessContactRef(String id) {
        BusinessContact businessContact = businessContactService.getBusinessContactById(id);
        if (businessContact != null) {
            return businessContact.getRef();
        } else {
            return null;
        }
    }

    public List<String> getAssignmentReasonOptions() {
        List<String> assignmentReasons = EAssignmentReason.getDisplayTextList();
        // REASON_REQUIRED is for data mapping purposes only
        assignmentReasons.remove(EAssignmentReason.REASON_REQUIRED.getJsonValue());
        Collections.sort(assignmentReasons);
        return assignmentReasons;
    }

    public WorkOrder createDeficiencyWorkOrder(Asset asset) {
        UserProfile profile = currentUserBT.getCurrentUser().profile;
        WorkOrder workOrder = microservice.createDeficiencyWorkOrder(asset, profile.getFullName(), deriveCurrentUserPhoneNumber(profile));
        workflowService.startUnscheduled(workOrder, currentUserBT.getCurrentUser().profile.managedByNodeRef);
        return workOrder;
    }

    private String deriveCurrentUserPhoneNumber(UserProfile profile) {
        String retVal = "Not Available";
        PhoneNumber workPhone = null;
        PhoneNumber mobilePhone = null;
        if (profile.phoneNumbers != null && !profile.phoneNumbers.isEmpty()) {
            for (PhoneNumber phoneNumber : profile.phoneNumbers) {
                if (EPhoneNumberType.WORK.equals(phoneNumber.phoneNumberType)) {
                    workPhone = phoneNumber;
                } else if (EPhoneNumberType.MOBILE.equals(phoneNumber.phoneNumberType)) {
                    mobilePhone = phoneNumber;
                }
            }
        }
        if (workPhone != null) {
            retVal = workPhone.value;
        } else if (mobilePhone != null) {
            retVal = mobilePhone.value;
        }
        return retVal;
    }

    public void processAssetGroupRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processAssetGroupRefUpdate(dataReferenceUpdate);
    }

    public WorkOrder passQualityControl(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;
        workflowService.passQualityControl(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.QUALITY_CONTROL_PASS.displayText);

        if (!workOrder.isQualityAssuranceRequired) {
            markQualityAssuranceAsNotRequired(workOrder);
        }
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder passQualityControl(WorkOrder workOrderWorkItem, Date customActionDate) {
        return passQualityControl(workOrderWorkItem, customActionDate, true);
    }

    public WorkOrder passQualityControl(WorkOrder workOrderWorkItem, Date customActionDate, boolean markQaAsNotRequired) {
        initializeRequestWorkflowData(customActionDate);

        if (workOrderWorkItem.newQualityEvent == null) {
            addRequestWorkflowDataCustomInstruction(WorkOrderLegacyWorkflowUtil.DO_NOT_CREATE_QC_EVENT);
        }

        if (workOrderWorkItem.newComment == null) {
            legacyWorkflowUtil.addNewComment(workOrderWorkItem,
                    customActionDate, WorkOrderLegacyWorkflowUtil.COMMENT_LEGACY_QC_PASSED);
        }

        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;
        workflowService.passQualityControl(workOrder, currentUserBT.getCurrentUser());

        if (markQaAsNotRequired && !workOrder.isQualityAssuranceRequired) {
            markQualityAssuranceAsNotRequired(workOrder, customActionDate);
        }

        return microservice.findById(workOrder.getId());
    }

    public WorkOrder failQualityControl(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;
        workflowService.failQualityControl(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.QUALITY_CONTROL_FAIL.displayText);

        return microservice.findById(workOrder.getId());
    }

    public WorkOrder failQualityControl(WorkOrder workOrderWorkItem, Date customActionDate) {
        initializeRequestWorkflowData(customActionDate);

        if (workOrderWorkItem.newQualityEvent == null) {
            addRequestWorkflowDataCustomInstruction(WorkOrderLegacyWorkflowUtil.DO_NOT_CREATE_QC_EVENT);
        }

        if (workOrderWorkItem.newComment == null) {
            legacyWorkflowUtil.addNewComment(workOrderWorkItem, customActionDate, WorkOrderLegacyWorkflowUtil.COMMENT_LEGACY_QC_FAILED);
        }

        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);

        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;
        workflowService.failQualityControl(workOrder, currentUserBT.getCurrentUser());

        return microservice.findById(workOrder.getId());
    }

    public WorkOrder markQualityControlAsNotPerformed(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;
        workflowService.markQualityControlAsNotPerformed(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.QUALITY_CONTROL_NOT_PERFORMED.displayText);

        if (!workOrder.isQualityAssuranceRequired) {
            markQualityAssuranceAsNotRequired(workOrder);
        }

        return microservice.findById(workOrder.getId());
    }

    public WorkOrder markQualityControlAsNotRequired(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workflowService.markQualityControlAsNotRequired(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.QUALITY_CONTROL_NOT_REQUIRED.displayText);

        if (!workOrder.isQualityAssuranceRequired) {
            workOrder.newQualityEvent = null;
            markQualityAssuranceAsNotRequired(workOrder);
        }

        return microservice.findById(workOrder.getId());
    }

    public WorkOrder markQualityControlAsNotRequired(WorkOrder workOrderWorkItem, Date customActionDate) {
        return markQualityControlAsNotRequired(
                workOrderWorkItem, customActionDate, true);
    }

    public WorkOrder markQualityControlAsNotRequired(WorkOrder workOrderWorkItem,
                                                     Date customActionDate,
                                                     boolean markQaAsNotRequired) {
        initializeRequestWorkflowData(customActionDate);
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;

        workflowService.markQualityControlAsNotRequired(workOrder, currentUserBT.getCurrentUser());

        if (markQaAsNotRequired && !workOrder.isQualityAssuranceRequired) {
            workOrder.newQualityEvent = null;
            markQualityAssuranceAsNotRequired(workOrder, customActionDate);
        }

        return microservice.findById(workOrder.getId());
    }

    public List<WorkOrder> getWorkOrdersByAssetIds(List<String> assetIds) {
        return microservice.getByAssetIds(assetIds);
    }

    public List<String> findIdsByScheduleIdentifier(String scheduleIdentifier) {
        List<String> scheduleIds = assetScheduleService.findIdsByScheduleIdentifier(scheduleIdentifier);
        //handle schedules that may have been deleted
        if (scheduleIds.isEmpty()) {
            throw new ApplicationException("No Schedule found");
        }
        if (scheduleIds.size() > 1) {
            throw new ApplicationException("Two or more schedules exist for Schedule Identifier");
        }
        return scheduleIds;
    }

    public List<WorkflowStepSummary> buildWorkflowStepSummary(WorkOrder workOrder) {
        return workflowService.buildWorkflowStepSummary(workOrder);
    }

    public void updateAssetGroupScheduledWorkOrderAssetRefs(Schedule schedule) {
        List<WorkOrder> oldWorkOrderList = microservice.getWorkOrdersBySchedule(schedule.getId());

        microservice.updateAssetGroupScheduledWorkOrderAssetRefs(schedule);
        List<WorkOrder> newWorkOrderList = microservice.getWorkOrdersBySchedule(schedule.getId());

        processEstimatedCostsFinanceRequest(oldWorkOrderList, null, WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_REMOVE, null, false );
        processEstimatedCostsFinanceRequest(null, newWorkOrderList, WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_ADD, null, true);
    }

    public List<WorkLoadSummary> getWorkLoadSummary(WorkLoadSearchCriteria workLoadSearchCriteria) {
        populateWorkLoadSummarySiteFilters(workLoadSearchCriteria);
        List<WorkLoadSummary> workLoadSummaries = microservice.getWorkLoadSummary(workLoadSearchCriteria);
        return populateAndFilterWorkLoadSummaryOnSite(workLoadSearchCriteria, workLoadSummaries);
    }

    public List<WorkLoadSummary> getWorkLoadSummaryForNextMonth(WorkLoadSearchCriteria workLoadSearchCriteria) {
        populateWorkLoadSummarySiteFilters(workLoadSearchCriteria);
        List<WorkLoadSummary> workLoadSummaries = microservice.getWorkLoadSummaryForNextMonth(workLoadSearchCriteria);
        return populateAndFilterWorkLoadSummaryOnSite(workLoadSearchCriteria, workLoadSummaries);
    }

    private void populateWorkLoadSummarySiteFilters(WorkLoadSearchCriteria workLoadSearchCriteria) {
        if (workLoadSearchCriteria.siteId != null) {
            workLoadSearchCriteria.siteIds = new ArrayList<>();
            workLoadSearchCriteria.siteIds.add(workLoadSearchCriteria.siteId);
        } else if (workLoadSearchCriteria.installationId != null) {
            List<Site> sites = installationService.getSitesForInstallation(workLoadSearchCriteria.installationId);

            if (sites != null && !sites.isEmpty()) {
                workLoadSearchCriteria.siteIds = new ArrayList<>();
                sites.forEach(site -> workLoadSearchCriteria.siteIds.add(site.getId()));
            }
        }
    }

    private List<WorkLoadSummary> populateAndFilterWorkLoadSummaryOnSite(WorkLoadSearchCriteria workLoadSearchCriteria, List<WorkLoadSummary> workLoadSummaries) {
        // TODO - this method should be removed once the WorkOrder.siteRef is populated for a Scheduled work order
        List<WorkLoadSummary> filteredWorkLoadSummaries = workLoadSummaries;
        populateSiteRefsForWorkloadSummaries(filteredWorkLoadSummaries);

        // TODO - This only exists because the siteRef is currently not populated for a Scheduled work order
        if (workLoadSearchCriteria.siteIds != null && !workLoadSearchCriteria.siteIds.isEmpty()
                && workLoadSummaries != null) {
            filteredWorkLoadSummaries = workLoadSummaries.stream()
                    .filter(workLoadSummary -> workLoadSummary.siteRef != null
                            && workLoadSearchCriteria.siteIds.contains(workLoadSummary.siteRef.id))
                    .collect(Collectors.toList());
        }

        return filteredWorkLoadSummaries;
    }

    private void populateSiteRefsForWorkloadSummaries(List<WorkLoadSummary> workLoadSummaries) {
        if (workLoadSummaries != null && !workLoadSummaries.isEmpty()) {
            List<String> facilityIds = new ArrayList<>();
            Map<String, List<WorkLoadSummary>> facilityToWorkLoadSummary = createFacilityToWorkloadSummariesMap(workLoadSummaries);
            facilityToWorkLoadSummary.entrySet().forEach(entry -> facilityIds.add(entry.getKey()));
            List<Facility> facilities = facilityService.getFacilitiesByIds(facilityIds);

            for (Facility facility : facilities) {
                List<WorkLoadSummary> facilityWorkLoadSummary = facilityToWorkLoadSummary.get(facility.getId());

                if (facilityWorkLoadSummary != null && !facilityWorkLoadSummary.isEmpty()) {
                    for (WorkLoadSummary workLoadSummary : facilityWorkLoadSummary) {
                        workLoadSummary.siteRef = facility.siteRef;
                    }
                }
            }
        }
    }

    private Map<String, List<WorkLoadSummary>> createFacilityToWorkloadSummariesMap(List<WorkLoadSummary> workLoadSummaries) {
        Map<String, List<WorkLoadSummary>> facilityToWorkOrder = new HashMap<>();

        for (WorkLoadSummary workLoadSummary : workLoadSummaries) {
            String facilityId = workLoadSummary.facilityRef != null ? workLoadSummary.facilityRef.id : null;

            if (facilityId != null) {
                List<WorkLoadSummary> facilityWorkOrders = facilityToWorkOrder.get(facilityId);

                if (facilityWorkOrders == null) {
                    facilityWorkOrders = new ArrayList<>();
                    facilityToWorkOrder.put(workLoadSummary.facilityRef.id, facilityWorkOrders);
                }

                facilityWorkOrders.add(workLoadSummary);
            }
        }

        return facilityToWorkOrder;
    }

    public List<Site> getAllSites() {
        return installationService.getAllSites();
    }

    public List<Site> getSitesForInstallation(String installationId) {
        return installationService.getSitesForInstallation(installationId);
    }

    public List<FacilitySummary> getActiveFacilitiesBySiteUid(String rpsuid) {
        return facilityService.getActiveFacilitiesBySiteUid(rpsuid, true);
    }

    public List<FacilitySummary> getFacilitiesBySiteId(String siteId) {
        return facilityService.getFacilitiesBySiteId(siteId);
    }

    public List<FrequencyRef> getAllFrequencyRefs() {
        return assetMaintenanceProcedureService.getAllFrequencyRefs();
    }

    public List<BusinessContactSearch> getAllBusinessContacts() {
        return businessContactService.getAllBusinessContactsByStatus("Active");
    }

    public List<Installation> getAllInstallations() {
        return installationService.getAllInstallations(true);
    }

    public WorkOrder passQualityAssurance(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;
        workflowService.passQualityAssurance(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.QUALITY_ASSURANCE_PASS.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder passQualityAssurance(WorkOrder workOrderWorkItem, Date customActionDate) {
        initializeRequestWorkflowData(customActionDate);

        if (workOrderWorkItem.newQualityEvent == null) {
            addRequestWorkflowDataCustomInstruction(WorkOrderLegacyWorkflowUtil.DO_NOT_CREATE_QA_EVENT);
        }

        if (workOrderWorkItem.newComment == null) {
            legacyWorkflowUtil.addNewComment(workOrderWorkItem, customActionDate, WorkOrderLegacyWorkflowUtil.COMMENT_LEGACY_QA_PASSED);
        }

        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;
        workflowService.passQualityAssurance(workOrder, currentUserBT.getCurrentUser());
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder failQualityAssurance(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;
        workflowService.failQualityAssurance(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.QUALITY_ASSURANCE_FAIL.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder failQualityAssurance(WorkOrder workOrderWorkItem, Date customActionDate) {
        initializeRequestWorkflowData(customActionDate);

        if (workOrderWorkItem.newQualityEvent == null) {
            addRequestWorkflowDataCustomInstruction(WorkOrderLegacyWorkflowUtil.DO_NOT_CREATE_QA_EVENT);
        }

        if (workOrderWorkItem.newComment == null) {
            legacyWorkflowUtil.addNewComment(workOrderWorkItem, customActionDate, WorkOrderLegacyWorkflowUtil.COMMENT_LEGACY_QA_FAILED);
        }

        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;

        workflowService.failQualityAssurance(workOrder, currentUserBT.getCurrentUser());
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder markQualityAssuranceAsNotPerformed(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;
        workflowService.markQualityAssuranceAsNotPerformed(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.QUALITY_ASSURANCE_NOT_PERFORMED.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder markQualityAssuranceAsNotRequired(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;
        workflowService.markQualityAssuranceAsNotRequired(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.QUALITY_ASSURANCE_NOT_REQUIRED.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder markQualityAssuranceAsNotRequired(WorkOrder workOrderWorkItem, Date customActionDate) {
        initializeRequestWorkflowData(customActionDate);
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newQualityEvent = workOrderWorkItem.newQualityEvent;
        workflowService.markQualityAssuranceAsNotRequired(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.QUALITY_ASSURANCE_NOT_REQUIRED.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder elevatePriority(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newPriorityGroupRef = workOrderWorkItem.newPriorityGroupRef;
        workflowService.elevatePriority(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.ELEVATE_PRIORITY.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder downgradePriority(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workOrder.newPriorityGroupRef = workOrderWorkItem.newPriorityGroupRef;
        workflowService.downgradePriority(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.DOWNGRADE_PRIORITY.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrderDashboardInfo getWorkOrderDashboardStats() {
        return microservice.getWorkOrderDashboardStats();
    }

    public WorkflowDefinition getWorkflowByName(String name) {
        return workflowService.getWorkflowByName(name);
    }

    public List<AssetSummary> getAssetsByIds(List<AssetRef> assetList) {
        return assetService.getAssetsByIds(assetList);
    }

    public List<RoomSummary> getRoomSummariesByIds(List<String> roomIds) {
        return spaceManagementService.getRoomSummariesByIds(roomIds);
    }

    public List<WorkOrder> getWorkOrdersBySectionId(String sectionId) {
        return microservice.getWorkOrdersBySectionId(sectionId);
    }

    public List<LaborRateFactor> getLaborRateFactors() {
        return microservice.getLaborRateFactors();
    }

    public AssignmentEstimateResult saveAssignmentEstimate(String workOrderId, Assignment assignment) {
        validateAllowedToEditWorkOrder(workOrderId);
        workOrderAssignmentEstimateValidator.validate(assignment);

        AssignmentEstimateResult result = new AssignmentEstimateResult();

        WorkOrder oldWorkOrder = this.findById(workOrderId);
        fillRealPropertyFunding(assignment.estimatedCosts);
        if (assignment.actualCosts != null && !assignment.actualCosts.isEmpty()) {
            List<ActualCost> actualCosts = assignment.actualCosts;
            for (ActualCost actualCost : actualCosts) {
                fillRealPropertyFunding(actualCost.costSummary);
                microservice.updateActualCost(workOrderId, actualCost);
            }
        }
        WorkOrder workOrder = microservice.saveAssignmentEstimate(workOrderId, assignment);

        List<String> financeMessages = new ArrayList<>(processEstimatedCostsFinanceRequest(Collections.singletonList(oldWorkOrder), Collections.singletonList(workOrder),
                WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_UPDATE, assignment, false));

        result.workOrder = workOrder;
        result.financeMessages = financeMessages.stream().distinct().collect(Collectors.toList());

        return result;
    }

    public BulkResponse bulkAcceptWorkOrders(List<String> workOrderIds) {
        validateBulkUpdateRecordLimit(workOrderIds.size());
        List<WorkOrder> workOrders = microservice.findByIds(workOrderIds);
        BulkResponse bulkResponse = new BulkResponse();
        List<WorkOrder> acceptedWorkOrders = new ArrayList<>();
        WorkOrder acceptedWO = null;
        for (WorkOrder workOrder : workOrders) {
            try {
                acceptedWO =  workflowService.accept(workOrder, currentUserBT.getCurrentUser());
                if ( acceptedWO != null ) {
                    acceptedWorkOrders.add(acceptedWO);
                }
                bulkResponse.successfulItems.add(workOrder.workOrderNumber);
            } catch (Exception e) {
                // Fortify Note: Keeping broad catch exception to ensure the for loop processes completely
                FailedItem item = new FailedItem();
                item.workOrderNumber = workOrder.workOrderNumber;
                item.errorMsg = e.getMessage();
                bulkResponse.failedItems.add(item);
            }
        }

        processActualCostFinanceRequest(acceptedWorkOrders);

        return bulkResponse;
    }

    public BulkResponse bulkRejectWorkOrders(List<String> workOrderIds, String reason) {
        validateBulkUpdateRecordLimit(workOrderIds.size());
        List<WorkOrder> workOrders = microservice.findByIds(workOrderIds);
        BulkResponse bulkResponse = new BulkResponse();
        Comment commentReason = new Comment();
        commentReason.text = reason;
        for (WorkOrder workOrder : workOrders) {
            try {
                workOrder.newComment = commentReason;
                workflowService.reject(workOrder, currentUserBT.getCurrentUser());
                bulkResponse.successfulItems.add(workOrder.workOrderNumber);
            } catch (Exception e) {
                // Fortify Note: Keeping broad catch exception to ensure the for loop processes completely.
                FailedItem item = new FailedItem();
                item.workOrderNumber = workOrder.workOrderNumber;
                item.errorMsg = e.getMessage();
                bulkResponse.failedItems.add(item);
            }
        }
        return bulkResponse;
    }

    public WorkOrder saveDonatedResources(String workOrderId, List<String> donatedResources) {
        validateAllowedToEditWorkOrder(workOrderId);
        return microservice.saveDonatedResources(workOrderId, donatedResources);
    }

    public List<String> getDonatedResources() {
        return EDonatedResource.getDisplayTextList();
    }

    public BulkResponse bulkCancel(List<String> ids, String reason) {
        validateBulkUpdateRecordLimit(ids.size());
        List<WorkOrder> workOrders = microservice.findByIds(ids);
        CurrentUser currentUser = this.currentUserBT.getCurrentUser();
        BulkResponse bulkResponse = new BulkResponse();

        Comment commentReason = new Comment();
        commentReason.text = reason;
        for (WorkOrder workOrder : workOrders) {
            if (Objects.equals(workOrder.workflowState.currentStep.name, EWorkflowStepName.REVIEW.displayText)) {
                try {
                    workOrder.newComment = commentReason;
                    workflowService.cancel(workOrder, currentUser);
                    bulkResponse.successfulItems.add(workOrder.workOrderNumber);
                } catch (Exception e) {
                    // Fortify Note: Keeping broad catch exception to ensure the for loop processes completely.
                    FailedItem item = new FailedItem();
                    item.workOrderNumber = workOrder.workOrderNumber;
                    item.errorMsg = e.getMessage();
                    bulkResponse.failedItems.add(item);
                }
            } else {
                FailedItem item = new FailedItem();
                item.workOrderNumber = workOrder.workOrderNumber;
                item.errorMsg = "Work Order not in the Review step";
                bulkResponse.failedItems.add(item);
            }
        }
        return bulkResponse;
    }

    public void updateScheduledWorkOrders(Schedule schedule) {
        List<WorkOrder> oldWorkOrderList = microservice.getWorkOrdersBySchedule(schedule.getId());

        microservice.updateScheduledWorkOrders(schedule);

        List<WorkOrder> newWorkOrderList =   microservice.getWorkOrdersBySchedule(schedule.getId());

        processEstimatedCostsFinanceRequest(oldWorkOrderList, null, WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_REMOVE, null, false );
        processEstimatedCostsFinanceRequest(null, newWorkOrderList, WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_ADD, null, true );
    }

    public void updateBulkScheduledWorkOrders(List<Schedule> schedules) {
        for (Schedule schedule : schedules) {
            updateScheduledWorkOrders(schedule);
        }
    }

    public Section getSectionById(String sectionId) {
        return sectionService.getSectionById(sectionId);
    }

    public List<SectionSummary> getSectionSummariesByIds(List<String> sectionIdList) {
        return sectionService.getSectionSummariesByIds(sectionIdList);
    }

    public List<SectionSummary> getSectionSummariesByFacilityId(String facilityId) {
        return sectionService.getSectionSummariesByFacilityIds(Collections.singletonList(facilityId), "ALL");
    }

    public WorkOrder updateWorkOrderSections(WorkOrder workOrder) {
        WorkOrder persistedWorkOrder = findById(workOrder.getId());
        validateAllowedToEditWorkOrder(persistedWorkOrder);
        List<Section> currentSections = sectionService.getSectionsByIds(persistedWorkOrder.sectionRefs);
        List<AssetRef> currentSectionAssetRefs = currentSections.stream().flatMap(section -> section.assetRefList.stream()).collect(Collectors.toList());
        workOrder.assetRefs.removeAll(currentSectionAssetRefs);
        List<Section> updatedSections = sectionService.getSectionsByIds(workOrder.sectionRefs);
        List<AssetRef> updatedSectionAssetRefs = updatedSections.stream().flatMap(section -> section.assetRefList.stream()).collect(Collectors.toList());
        for (AssetRef updatedSectionAssetRef : updatedSectionAssetRefs) {
            if (!workOrder.assetRefs.contains(updatedSectionAssetRef)) {
                workOrder.assetRefs.add(updatedSectionAssetRef);
            }
        }
        workOrderSectionValidator.validate(workOrder);
        workOrderAssetValidator.validate(workOrder);
        return microservice.updateWorkOrderSections(workOrder);
    }

    public List<WorkOrder> getAssociateWorkOrders(String workOrderId) {
        return microservice.getAssociateWorkOrders(workOrderId);
    }

    public List<WorkOrder> getAssociateAndNonAssociateWorkOrders(String workOrderId) {
        return microservice.getAssociateAndNonAssociateWorkOrders(workOrderId);
    }

    public WorkOrder updateAssociateWorkOrder(WorkOrder workOrder) {
        WorkOrder persistedWorkOrder = findById(workOrder.getId());
        validateAllowedToEditWorkOrder(persistedWorkOrder);
        List<AssociateWorkOrder> currentAssociateWorkOrders = persistedWorkOrder.associateWorkOrders;
        List<AssociateWorkOrder> newAssociateWorkOrders = workOrder.associateWorkOrders;
        String currentWorkOrderNumber = workOrder.workOrderNumber;
        unassociateWorkOrders(currentWorkOrderNumber, currentAssociateWorkOrders, newAssociateWorkOrders);
        associateWorkOrders(currentWorkOrderNumber, currentAssociateWorkOrders, newAssociateWorkOrders);
        return microservice.updateAssociateWorkOrders(workOrder);
    }

    private void unassociateWorkOrders(String currentWorkOrderNumber, List<AssociateWorkOrder> currentAssociateWorkOrders, List<AssociateWorkOrder> newAssociateWorkOrders) {
        List<String> workOrderAssociationsToRemove = new ArrayList<>();
        currentAssociateWorkOrders.forEach(currentAssociateWorkOrder -> {
            boolean workOrderNumberInList = isWorkOrderNumberInList(currentAssociateWorkOrder.workOrderNumber, newAssociateWorkOrders);
            if (!workOrderNumberInList) {
                workOrderAssociationsToRemove.add(currentAssociateWorkOrder.workOrderNumber);
            }
        });
        workOrderAssociationsToRemove.forEach(workOrderNeedingRemoving -> microservice.removeAssociateWorkOrder(workOrderNeedingRemoving, currentWorkOrderNumber));
    }

    public WorkOrderLegacyAssociationResult associateLegacyWorkOrders(String siteDodaac,
                                                                      Integer dmlssWorkRequestSerial,
                                                                      Integer relatedDmlssWorkRequestSerial) {
        WorkOrder workOrder = getWorkOrderForDataMigrationAssoc(siteDodaac, dmlssWorkRequestSerial);
        WorkOrder assocWorkOrder = getWorkOrderForDataMigrationAssoc(siteDodaac, relatedDmlssWorkRequestSerial);
        boolean alreadyAssociated = false;

        AssociateWorkOrder newAssociateWorkOrder = new AssociateWorkOrder();
        newAssociateWorkOrder.workOrderNumber = assocWorkOrder.workOrderNumber;

        if (ListUtil.isEmpty(workOrder.associateWorkOrders)) {
            workOrder.associateWorkOrders = new ArrayList<>();
            workOrder.associateWorkOrders.add(newAssociateWorkOrder);
        } else if (!isWorkOrderNumberInList(newAssociateWorkOrder.workOrderNumber, workOrder.associateWorkOrders)) {
            workOrder.associateWorkOrders.add(newAssociateWorkOrder);
        } else {
            alreadyAssociated = true;
        }

        if (!alreadyAssociated) {
            microservice.updateMigratedWorkOrder(workOrder);
        }

        return buildLegacyAssociationResult(siteDodaac, workOrder, assocWorkOrder, alreadyAssociated);
    }

    private WorkOrderLegacyAssociationResult buildLegacyAssociationResult(String siteDodaac,
                                                                          WorkOrder workOrder,
                                                                          WorkOrder assocWorkOrder,
                                                                          boolean alreadyAssociated) {
        WorkOrderLegacyAssociationResult result = new WorkOrderLegacyAssociationResult();
        result.siteDodaac = siteDodaac;
        result.id = workOrder.getId();
        result.workOrderNumber = workOrder.workOrderNumber;
        result.dmlssWorkRequestSerial = workOrder.dmlssWorkRequestSerial;
        result.dmlssWorkRequestNumber = workOrder.dmlssWorkRequestNumber;
        result.associateWorkOrderId = assocWorkOrder.getId();
        result.associateWorkOrderNumber = assocWorkOrder.workOrderNumber;
        result.associateDmlssWorkRequestSerial = assocWorkOrder.dmlssWorkRequestSerial;
        result.associateDmlssWorkRequestNumber = assocWorkOrder.dmlssWorkRequestNumber;
        if (alreadyAssociated) {
            result.status = "Warning";
            result.msg = "These WorkOrders are already associated (no action taken)";
        } else {
            result.status = "Success";
            result.msg = "OK";
        }
        return result;
    }

    private void associateWorkOrders(String currentWorkOrderNumber, List<AssociateWorkOrder> currentAssociateWorkOrders, List<AssociateWorkOrder> newAssociateWorkOrders) {
        List<String> workOrderAssociationsToAdd = new ArrayList<>();
        newAssociateWorkOrders.forEach(newAssociateWorkOrder -> {
            boolean workOrderNumberInList = isWorkOrderNumberInList(newAssociateWorkOrder.workOrderNumber, currentAssociateWorkOrders);
            if (!workOrderNumberInList) {
                workOrderAssociationsToAdd.add(newAssociateWorkOrder.workOrderNumber);
            }
        });
        workOrderAssociationsToAdd.forEach(workOrderNeedingAssociating -> microservice.addAssociateWorkOrder(workOrderNeedingAssociating, currentWorkOrderNumber));
    }

    private boolean isWorkOrderNumberInList(String workOrderNumber, List<AssociateWorkOrder> associateWorkOrders) {
        return associateWorkOrders.stream().anyMatch(associateWorkOrder -> Objects.equals(associateWorkOrder.workOrderNumber, workOrderNumber));
    }

    public WorkOrder updateWorkOrderAssets(WorkOrder workOrder) {
        validateAllowedToEditWorkOrder(workOrder.getId());
        workOrderAssetValidator.validate(workOrder);
        validateAssetActualCosts(workOrder);
        addAssetSpaceRefs(workOrder);
        workOrderSpaceValidator.validate(workOrder);
        return microservice.updateWorkOrderAssets(workOrder);
    }

    private void validateAssetActualCosts(WorkOrder workOrder) {
        WorkOrder persistedWorkOrder = findById(workOrder.getId());
        List<AssetRef> removedAssetRefs = persistedWorkOrder.assetRefs.stream()
                .filter(removedAssetRef -> workOrder.assetRefs.stream().noneMatch(assetRef -> Objects.equals(assetRef.id, removedAssetRef.id)))
                .collect(Collectors.toList());
        boolean isAssetAssigned = workOrder.assignments.stream().flatMap(assignment -> assignment.actualCosts.stream())
                .map(actualCost -> actualCost.assetRef)
                .filter(Objects::nonNull)
                .anyMatch(actualCostAssetRef -> removedAssetRefs.stream().anyMatch(removedAssetRef -> Objects.equals(removedAssetRef.id, actualCostAssetRef.id)));
        if (isAssetAssigned) {
            throw new ValidationException("Cannot remove Equipment with Actual Costs assigned");
        }
    }

    private void addAssetSpaceRefs(WorkOrder workOrder) {
        if (!ListUtil.isEmpty(workOrder.assetRefs)) {
            List<Asset> assetsByIds = assetService.getAssetsByAssetIds(workOrder.assetRefs.stream().map(AssetRef::getId).collect(Collectors.toList()));
            List<SpaceRef> spaceRefs = assetsByIds.stream()
                    .map(asset -> asset.locationInformation.spaceRef)
                    .filter(Objects::nonNull)
                    .filter(spaceRef -> spaceRef.id != null)
                    .collect(Collectors.toList());
            Set<SpaceRef> spaceRefsToAdd = spaceRefs.stream().filter(spaceRef -> !workOrder.spaceRefs.contains(spaceRef)).collect(Collectors.toSet());

            long assetsWithQualityControlRequired = assetsByIds.stream().map(asset -> asset.additionalInformation)
                    .filter(Objects::nonNull)
                    .filter(additionalInformation -> EQaQcInspectionMethod.AUTOMATIC.equals(additionalInformation.qcInspectionMethod)).count();
            long assetsWithQualityAssuranceRequired = assetsByIds.stream().map(asset -> asset.additionalInformation)
                    .filter(Objects::nonNull)
                    .filter(additionalInformation -> EQaQcInspectionMethod.AUTOMATIC.equals(additionalInformation.qaInspectionMethod)).count();

            workOrder.isQualityControlRequired = assetsWithQualityControlRequired > 0;
            workOrder.isQualityAssuranceRequired = assetsWithQualityAssuranceRequired > 0;
            workOrder.spaceRefs.addAll(spaceRefsToAdd);
        }
    }

    public WorkOrder updateWorkOrderProject(String id, RealPropertyProjectRef projectRef) {
        validateAllowedToEditWorkOrder(id);
        return microservice.updateWorkOrderProject(id, projectRef);
    }

    public List<RealPropertyProject> getProjectsByFacility(String facilityId) {
        List<RealPropertyProject> projectList = projectService.getProjectsByFacilityId(facilityId);
        return projectList.stream()
                .filter(project -> project.isRecordActive)
                .filter(project -> project.workflowState == null || !project.workflowState.currentStep.name.equalsIgnoreCase(EProjectWorkflowStepName.CLOSE.displayText))
                .collect(Collectors.toList());
    }

    public WorkOrder updateQuality(WorkOrder workOrderUpdates) {
        WorkOrder workOrder = microservice.findById(workOrderUpdates.getId());
        validateAllowedToEditWorkOrder(workOrder);
        workOrderQualityValidator.validate(workOrder, workOrderUpdates);
        return microservice.updateQuality(workOrderUpdates);
    }

    public WorkOrder addQualityEvent(String id, QualityEvent qualityEvent) {
        return microservice.addQualityEvent(id, qualityEvent);
    }

    public List<BusinessContact> getAssignedBusinessContacts(String id) {
        WorkOrder workOrder = microservice.findById(id);
        HashMap<String, BusinessContact> otherBusinessContacts = new HashMap<>();
        BusinessContact leadBusinessContact = null;

        if (workOrder != null && workOrder.assignments != null && !workOrder.assignments.isEmpty()) {
            for (Assignment assignment : workOrder.assignments) {
                if (assignment.businessContactRef != null) {
                    BusinessContact businessContact = businessContactService.getBusinessContactById(assignment.businessContactRef.id);
                    if (assignment.isLeadShop) {
                        leadBusinessContact = businessContact;
                    } else {
                        otherBusinessContacts.put(businessContact.getId(), businessContact);
                    }
                }
            }
        }

        return convertBusinessContactsMapToList(leadBusinessContact, otherBusinessContacts);
    }

    private List<BusinessContact> convertBusinessContactsMapToList(BusinessContact leadBusinessContact, Map<String, BusinessContact> otherBusinessContacts) {
        List<BusinessContact> businessContacts = new ArrayList<>();

        if (leadBusinessContact != null) {
            businessContacts.add(leadBusinessContact);
        }

        for (Map.Entry<String, BusinessContact> entry : otherBusinessContacts.entrySet()) {
            String key = entry.getKey();
            BusinessContact bc = entry.getValue();
            if (leadBusinessContact == null || !bc.getId().equalsIgnoreCase(leadBusinessContact.getId())) {
                businessContacts.add(otherBusinessContacts.get(key));
            }
        }

        return businessContacts;
    }

    public List<BusinessContact> getManagedBusinessContactsForQualityAssurance() {
        return (businessContactService.getBusinessContactsForQualityAssurance());
    }

    private void validateBulkUpdateRecordLimit(int recordsToProcessCount) {
        int limit = microservice.getBulkUpdateRecordLimit();
        if (recordsToProcessCount > limit) {
            throw new ApplicationException(String.format("Bulk update operation is limited to %s records", limit));
        }
    }

    public String getParentOrganizationName(String organizationId) {
        Organization org = organizationService.getParentOrganization(organizationId);
        return org.getName();
    }

    public WorkOrder setPreventativeMaintenanceDeferred(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.setPreventativeMaintenanceDeferred(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.PREVENTATIVE_MAINTENANCE_DEFERRED.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder setUnableToLocate(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.setUnableToLocate(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.UNABLE_TO_LOCATE.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder setSendToWorkControl(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.setSendToWorkControl(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.SEND_TO_WORK_CONTROL.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder setSendForScheduling(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.setSendForScheduling(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.SEND_FOR_SCHEDULING.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder setSendForServiceOrder(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.setSendForServiceOrder(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.SEND_FOR_SERVICE_ORDER.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder setSendForContractAgencyApproval(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.setSendForContractAgencyApproval(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.SEND_FOR_CONTRACT_AGENCY_APPROVAL.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder setNoticeToProceed(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.setNoticeToProceed(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.NOTICE_TO_PROCEED.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder setRework(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        validateWorkOrderFound(workOrder);
        workflowService.setRework(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.REWORK.displayText);
        return microservice.findById(workOrder.getId());
    }

    public String getInstallationNameFromSiteId(String siteId) {
        Site site = installationService.getSiteById(siteId);
        return site.installationRef.name;
    }

    public List<WorkOrder> getWorkOrdersForPrioritization(String priorityGroupId, String classificationTypeId, String facilityId) {
        ClassificationType recurringWork = microservice.getClassificationTypeByName(CLASSIFICATION_TYPE_NAME_RECURRING_WORK);
        if (Objects.equals(recurringWork.getId(), classificationTypeId)) {
            throw new ApplicationException(String.format("Invalid Classification Type, \"%s\"", CLASSIFICATION_TYPE_NAME_RECURRING_WORK));
        }
        return microservice.getWorkOrdersForPrioritization(priorityGroupId, classificationTypeId, facilityId);
    }

    public int updateWorkOrderPriorityOrder(List<WorkOrder> workOrders) {
        ClassificationType recurringWork = microservice.getClassificationTypeByName(CLASSIFICATION_TYPE_NAME_RECURRING_WORK);
        boolean anyAreRecurringWork = workOrders.stream().anyMatch(workOrder -> Objects.equals(workOrder.classificationTypeRef.id, recurringWork.getId()));
        if (anyAreRecurringWork) {
            throw new ApplicationException(String.format("Invalid Classification Type, \"%s\"", CLASSIFICATION_TYPE_NAME_RECURRING_WORK));
        }
        int updateCount = 0;
        if (!workOrders.isEmpty()) {
            WorkOrder firstWorkOrder = workOrders.get(0);
            long numberOfWorkOrdersWithMatchingTypes = workOrders.stream().filter(workOrder -> Objects.equals(workOrder.priorityGroupRef.id, firstWorkOrder.priorityGroupRef.id) && Objects.equals(workOrder.classificationTypeRef.id, firstWorkOrder.classificationTypeRef.id)).count();
            if (numberOfWorkOrdersWithMatchingTypes != workOrders.size()) {
                throw new ApplicationException("Invalid priority update request. All Work Orders must share same Priority Group and Classification Type");
            }
            for (int i = 0; i < workOrders.size(); i++) {
                WorkOrder workOrder = workOrders.get(i);
                workOrder.priorityNumber = i + 1;
            }
            updateCount = microservice.updateWorkOrderPriorityOrder(workOrders);
        }
        return updateCount;
    }

    public long getClosedWorkOrderCountByFacilityId(String facilityId) {
        return microservice.getClosedWorkOrderCountByFacilityId(facilityId);
    }

    public long getOpenWorkOrderCountByFacilityId(String facilityId) {
        return microservice.getOpenWorkOrderCountByFacilityId(facilityId);
    }

    public long getActiveWorkOrderCountByAssetId(String assetId) {
        return microservice.getActiveWorkOrderCountByAssetId(assetId);
    }

    public List<String> getRelatedCauses() {
        return ERelatedCause.getFriendlyNames();
    }

    public List<String> getDocumentTypes() {
        return facilityService.getDocumentTypes();
    }

    public WorkOrder saveLeavingReviewStepData(WorkOrder workOrder) {
        return microservice.saveLeavingReviewStepData(workOrder);
    }

    public WorkOrder updateWorkOrderRequirementRef(WorkOrder workOrder) {
        new WorkOrderDetailValidator().validate(workOrder);
        return microservice.updateWorkOrderRequirementRef(workOrder);
    }

    public WorkOrder clearCloseOutReason(WorkOrder workOrder) {
        return microservice.clearCloseOutReason(workOrder);
    }

    public void submitForPossibleRandomQualitySampling(WorkOrder workOrder) {
        Optional<Assignment> leadAssignmentOptional = workOrder.assignments.stream().filter(assignment -> assignment.isLeadShop).findFirst();
        if (leadAssignmentOptional.isPresent()) {
            Assignment assignment = leadAssignmentOptional.get();
            if (assignment.businessContactRef != null && assignment.businessContactRef.getId() != null) { // will likely be null for Maximo WOs
                BusinessContact businessContact = businessContactService.getBusinessContactById(assignment.businessContactRef.getId());
                if (businessContact != null) {
                    Integer qualityControlPercent = businessContact.qualityControlPercent;
                    if (isQualityControlSamplingRequired(workOrder, qualityControlPercent)) {
                        workOrder.isQualityControlSampled = true;
                        if (workOrder.qualityControlSelection == null) {
                            workOrder.qualityControlSelection = new QualitySelection();
                        }
                        workOrder.qualityControlSelection.selectionCriteria = EQualitySelectionCriteria.SAMPLED;
                        workOrder.qualityControlSelection.selectionDate = new Date();
                        workOrder.qualityControlSelection.samplePercent = BigDecimal.valueOf(businessContact.qualityControlPercent).movePointLeft(2).floatValue();
                        if (isQualitySamplingSelected(qualityControlPercent)) {
                            workOrder.isQualityControlRequired = true;
                        }
                    }

                    Integer qualityAssurancePercent = businessContact.qualityAssurancePercent;
                    if (isQualityAssuranceSamplingRequired(workOrder, qualityAssurancePercent)) {
                        if (workOrder.qualityAssuranceSelection == null) {
                            workOrder.qualityAssuranceSelection = new QualitySelection();
                        }
                        workOrder.isQualityAssuranceSampled = true;
                        workOrder.qualityAssuranceSelection.selectionCriteria = EQualitySelectionCriteria.SAMPLED;
                        workOrder.qualityAssuranceSelection.selectionDate = new Date();
                        workOrder.qualityAssuranceSelection.samplePercent = BigDecimal.valueOf(businessContact.qualityAssurancePercent).movePointLeft(2).floatValue();
                        if (isQualitySamplingSelected(qualityAssurancePercent)) {
                            workOrder.isQualityAssuranceRequired = true;
                        }
                    }
                    microservice.saveQualitySelections(workOrder);
                } else {
                    logger.info(
                            String.format(
                                    "Did not submit for random quality sampling because businessContact info was not found for businessContactRef id of %s",
                                    assignment.businessContactRef.getId()));
                }
            } else {
                logger.info("Did not submit for random quality sampling because businessContactRef was not populated");
            }
        }
    }

    protected boolean isQualityControlSamplingRequired(WorkOrder workOrder, Integer qualityControlPercent) {
        return !workOrder.isQualityControlRequired && !workOrder.isQualityControlSampled && qualityControlPercent != null;
    }

    protected boolean isQualityAssuranceSamplingRequired(WorkOrder workOrder, Integer qualityAssurancePercent) {
        return !workOrder.isQualityAssuranceRequired && !workOrder.isQualityAssuranceSampled && qualityAssurancePercent != null;
    }

    private boolean isQualitySamplingSelected(Integer percent) {
        if (percent == 0) {
            return false;
        }

        SecureRandom secureRandom;
        try {
            secureRandom = SecureRandom.getInstanceStrong();
        } catch (NoSuchAlgorithmException nsae) {
            logger.debug("Unable to get strong instance of SecureRandom. Using new SecureRandom()");
            secureRandom = new SecureRandom();
        }

        double random = secureRandom.nextDouble();
        return Math.round(random * 100) <= percent;
    }

    public WorkOrder hold(WorkOrder workOrder) {
        workflowService.hold(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.HOLD.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder resume(WorkOrder workOrder) {
        workflowService.resume(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.RESUME.displayText);
        return microservice.findById(workOrder.getId());
    }

    public boolean checkIfMaximoEnabled() {
        TransmitPropertyRecord transmitPropertyRecord = communicationsTransmitService.getTransmitPropertyRecord();
        return (transmitPropertyRecord != null && BooleanUtils.isTrue(transmitPropertyRecord.maximoEnabled));
    }

    public WorkOrder submitWorkOrderToMaximo(String workOrderId) {
        WorkOrder workOrder = findById(workOrderId);
        validateCanSendToMaximo();
        validateAllowedToEditWorkOrder(workOrder);
        Facility facility = facilityService.getFacilityById(workOrder.facilityRef.getId());
        cmmsOutboundWorkOrderValidator.validate(workOrder, facility);

        InitialCommunicationsResponse initialCommunicationsResponse = communicationsSubmitRequestService.submitMaximoWorkRequestRequest(workOrder);
        logger.info("Work Order {} submitted to External CMMS: {}", workOrder.workOrderNumber, initialCommunicationsResponse.uniqueResponseId);

        addMaximoEventHistory(workOrder, "Outbound", "Sent to External CMMS");
        return microservice.findById(workOrderId);
    }

    private String getCmmsStatus(MaximoWorkRequest maximoWorkRequest, WorkOrder workOrder) {
        String status = maximoWorkRequest.workReqStat;
        if (workOrder.workflowState != null && (workOrder.workflowState.currentPosition == EWorkflowStepName.CLOSED.position
                || workOrder.workflowState.currentPosition == EWorkflowStepName.FINAL_ACCEPTANCE.position)
                || status == null) {
            status = CmmsConstants.MAX_UPDATE;
        }
        return status;
    }

    private ECmmsActionType getCmmsActionType(String status) {
        if (CmmsConstants.MAX_INSERT.equals(status)) {
            return ECmmsActionType.INSERT;
        } else {
            return ECmmsActionType.UPDATE;
        }
    }

    public void processMaximoWorkRequest(MaximoWorkRequest maximoWorkRequest) {
        List<String> processingInfos = new ArrayList<>();
        List<String> processingErrors = new ArrayList<>();
        ECmmsActionType eCmmsActionType = ECmmsActionType.INSERT; // will get updated/set properly
        WorkOrder initialWorkOrder = new WorkOrder();
        WorkOrder workOrder = initialWorkOrder;
        List<WorkOrder> workOrdersWithSameExternalWoId = new ArrayList<>();
        MaximoEventHistory maximoEventHistory = new MaximoEventHistory();
        CmmsBusinessContact cmmsBusinessContact = null;
        SkillRef cmmsDefaultSkill = null;

        try {
            // Note: sequence of operations very important to populate the most possible data before any error occurs,
            // to allow for the more helpful/searchable CmmsError record
            cmmsInboundWorkOrderValidator.validateRequiredFields(maximoWorkRequest, processingErrors);

            Facility facility = facilityService.getFacilityByRpuid(maximoWorkRequest.rpuid);
            if (facility != null && facility.managedByNodeRef != null && !organizationService.isNodeRPFuncEnabled(facility.managedByNodeRef.id)) {
                throw new ApplicationException("Maximo Work Request cannot be processed due to the real property functionality disabled for this site");
            }

            cmmsInboundWorkOrderValidator.validateFacilityAndSetRelatedRefs(maximoWorkRequest, initialWorkOrder, facility, processingErrors);

            String cmmsStatus = getCmmsStatus(maximoWorkRequest, initialWorkOrder);
            eCmmsActionType = getCmmsActionType(cmmsStatus);

            workOrdersWithSameExternalWoId = microservice.getByExternalWorkOrderId(
                    maximoWorkRequest.workOrder, facility.managedByNodeRef.id);
            if (!ListUtil.isEmpty(workOrdersWithSameExternalWoId) && workOrdersWithSameExternalWoId.size() == 1) {
                workOrder = workOrdersWithSameExternalWoId.get(0);
            }
            cmmsInboundWorkOrderValidator.validateWorkOrder(maximoWorkRequest, workOrdersWithSameExternalWoId, processingErrors);

            cmmsInboundWorkOrderValidator.validateSequence(maximoWorkRequest, workOrder, processingErrors);

            cmmsBusinessContact = getCmmsBusinessContact(facility);
            cmmsInboundWorkOrderValidator.validateCmmsBusinessContact(cmmsBusinessContact, processingErrors);

            cmmsDefaultSkill = assetMaintenanceProcedureService.getSkillRefByCode(CmmsConstants.DEFAULT_SKILL_CODE);
            cmmsInboundWorkOrderValidator.validateCmmsDefaultSkill(cmmsDefaultSkill, processingErrors);

            if (eCmmsActionType == ECmmsActionType.INSERT) {
                mapCmmsInsertFields(maximoWorkRequest, processingInfos, processingErrors, workOrder, cmmsBusinessContact, cmmsDefaultSkill);
                workOrder = createMaximoWorkOrder(workOrder);
                workOrder = submitWorkOrderToMaximo(workOrder.getId());
                processCmmsWorkflow(maximoWorkRequest, workOrder, cmmsStatus);

                processEstimatedCostsFinanceRequest(null, Arrays.asList(workOrder), WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_ADD, null, false);
            } else {
                Assignment assignmentForFianceUpdate = mapCmmsUpdateFields(maximoWorkRequest, processingInfos, processingErrors, workOrder, cmmsBusinessContact, cmmsDefaultSkill);
                workOrder = saveWorkOrder(workOrder);
                processCmmsWorkflow(maximoWorkRequest, workOrder, cmmsStatus);

                // may add a new estimated cost or may not
                if ( assignmentForFianceUpdate != null ) {
                    // commenting this out for now, it's keeps adding to the finance transactions even when no changes have been made.
                    // processEstimatedCostsFinanceRequest(null, Arrays.asList(workOrder), WorkOrderBusinessEvent.ACTION_ESTIMATED_COST_ADD, assignmentForFianceUpdate, false);
                }
            }

            maximoEventHistory = addMaximoEventHistory(workOrder,
                    eCmmsActionType.displayText,
                    maximoWorkRequest.workReqStat,
                    maximoWorkRequest,
                    processingInfos);

            if (!ListUtil.isEmpty(processingInfos)) {
                writeCmmsErrorOrInfos(eCmmsActionType, maximoWorkRequest, workOrder, maximoEventHistory, processingInfos, processingErrors);
            }
        } catch (ValidationException ve) {
            if (ListUtil.isEmpty(processingErrors)) {
                processingErrors.add(CmmsConstants.ERROR_OTHER);
            }
            writeCmmsErrorOrInfos(eCmmsActionType, maximoWorkRequest, workOrder, maximoEventHistory, processingInfos, processingErrors);
            logger.error("CMMS ValidationException occurred: ", ve);
        } catch (Exception e) {
            // Fortify Note: Keeping broad catch exception to ensure all potential exceptions are captured and processed.
            if (ListUtil.isEmpty(processingErrors)) {
                processingErrors.add(CmmsConstants.ERROR_OTHER);
            }
            writeCmmsErrorOrInfos(eCmmsActionType, maximoWorkRequest, workOrder, maximoEventHistory, processingInfos, processingErrors);
            logger.error("CMMS Exception occurred: ", e);
        }
    }

    public void setMaximoWorkTransmissionStatus(CommunicationsMaximoResponse communicationsMaximoResponse) {
        if ( !StringUtil.isEmptyOrNull(communicationsMaximoResponse.transmissionStatus)  && !StringUtil.isEmptyOrNull(communicationsMaximoResponse.transmissionStatusDetails)) {
            String workOrderId = communicationsMaximoResponse.workOrderId;
            WorkOrder workOrder = findById(workOrderId);
            if ( TransmitConstants.TRANSMIT_GOOD.equalsIgnoreCase(communicationsMaximoResponse.transmissionStatus)) {
                workOrder.isSentToMaximo = true;
            }
            workOrder = saveWorkOrder(workOrder);
        }
    }

    private void processCmmsWorkflow(MaximoWorkRequest maximoWorkRequest, WorkOrder workOrder, String cmmsStatus) {
        switch (cmmsStatus) {
            case CmmsConstants.MAX_APPR:
                workflowService.approve(workOrder, currentUserBT.getCurrentUser());
                break;
            case CmmsConstants.MAX_ASSIGNED:
                workflowService.assign(workOrder, currentUserBT.getCurrentUser());
                break;
            case CmmsConstants.MAX_CAN:
                updateCmmsWOCompletionDate(maximoWorkRequest, workOrder);
                if (Objects.equals(workOrder.workflowState.currentPosition, EWorkflowStepName.IN_PROGRESS.position)) {
                    workflowService.sendForReview(workOrder, currentUserBT.getCurrentUser());
                }
                workOrder.newComment = new Comment();
                workOrder.newComment.text = "Received MAX_CAN from External CMMS";
                workflowService.cancel(workOrder, currentUserBT.getCurrentUser());
                break;
            case CmmsConstants.MAX_COMP:
            case CmmsConstants.MAX_CLOSE:
                updateCmmsWOCompletionDate(maximoWorkRequest, workOrder);
                // Set Request Workflow data so we can align workflow completion date with WO completion date
                initializeRequestWorkflowData(workOrder.completionDate,
                        true,
                        false);

                if (Objects.equals(workOrder.workflowState.currentPosition, EWorkflowStepName.IN_PROGRESS.position)) {
                    workOrder = workflowService.sendForReview(workOrder, currentUserBT.getCurrentUser());
                }

                if (Objects.equals(workOrder.workflowState.currentPosition, EWorkflowStepName.REVIEW.position)) {
                    workflowService.complete(workOrder, currentUserBT.getCurrentUser());
                    if (!workOrder.isQualityControlRequired) {
                        // Unset Request Workflow data because we do not want custom dates for the QC/QA dates
                        clearRequestWorkflowData();
                        markQualityControlAsNotRequired(workOrder);
                    }
                }
                break;
            default:
                // Do nothing
        }
    }

    private void mapCmmsInsertFields(MaximoWorkRequest maximoWorkRequest, List<String> processingInfos, List<String> processingErrors, WorkOrder workOrder, CmmsBusinessContact cmmsBusinessContact, SkillRef cmmsDefaultSkill) {
        mapCmmsBasicInfo(maximoWorkRequest, workOrder);
        mapCmmsInstallationAndExpenseCenter(
                maximoWorkRequest, workOrder, processingInfos, processingErrors);
        mapCmmsSpaceAndAsset(maximoWorkRequest, workOrder, processingInfos);
        mapCmmsPriorityGroup(maximoWorkRequest, workOrder, processingInfos);
        mapCmmsClassificationType(maximoWorkRequest, workOrder);
        mapCmmsWorkPerformed(
                maximoWorkRequest, workOrder, cmmsBusinessContact, cmmsDefaultSkill, processingInfos, processingErrors);
    }

    private Assignment mapCmmsUpdateFields(MaximoWorkRequest maximoWorkRequest, List<String> processingInfos, List<String> processingErrors, WorkOrder workOrder, CmmsBusinessContact cmmsBusinessContact, SkillRef cmmsDefaultSkill) {
        workOrder.subject = handleStringValue(maximoWorkRequest.subject, CmmsConstants.MAXIMO_UNKNOWN);
        workOrder.description = handleStringValue(maximoWorkRequest.workReqDesc, CmmsConstants.MAXIMO_UNKNOWN);
        workOrder.estimatedCompletionDate = maximoWorkRequest.estCompleteDate;
        workOrder.estimatedStartDate = maximoWorkRequest.estStartDate;
        mapCmmsSpaceAndAsset(maximoWorkRequest, workOrder, processingInfos);
        mapCmmsPriorityGroup(maximoWorkRequest, workOrder, processingInfos);
        mapCmmsClassificationType(maximoWorkRequest, workOrder);
        return mapCmmsWorkPerformed(
                maximoWorkRequest, workOrder, cmmsBusinessContact, cmmsDefaultSkill, processingInfos, processingErrors);
    }

    private CmmsBusinessContact getCmmsBusinessContact(Facility facility) {
        if (facility != null && !ListUtil.isEmpty(facility.businessContacts)) {
            List<FacilityBusinessContact> facilityBusContacts = facility.businessContacts.stream()
                    .filter(fbc -> fbc.facilityOrgFunctionRef != null &&
                            StringUtil.safeEquals(fbc.facilityOrgFunctionRef.description, CmmsConstants.FACILITY_ORG_FUNCTION_RP_MAINTAINER))
                    .collect(Collectors.toList());
            if (!ListUtil.isEmpty(facilityBusContacts)) {
                return getCmmsBusinessContactFromList(facilityBusContacts);
            }
        }
        return null;
    }

    private CmmsBusinessContact getCmmsBusinessContactFromList(List<FacilityBusinessContact> facilityBusContacts) {
        CmmsBusinessContact cmmsBusinessContact = null;
        for (FacilityBusinessContact fbc : facilityBusContacts) {
            BusinessContact businessContact = businessContactService.getBusinessContactByContactId(fbc.contactId);
            cmmsBusinessContact = new CmmsBusinessContact();
            cmmsBusinessContact.businessContact = businessContact;
            /* TODO: Default the correct shop
               if (businessContact != null && !ListUtil.isEmpty(businessContact.contacts)) {
                for (Contact contact : businessContact.contacts) {
                    if (StringUtil.safeEquals(contact.contactId, fbc.contactId) && Boolean.TRUE.equals(contact.isPrimary)) {
                        cmmsBusinessContact = new CmmsBusinessContact();
                        cmmsBusinessContact.businessContact = businessContact;
                        cmmsBusinessContact.contact = contact;
                    }
                }
            }*/
        }
        return cmmsBusinessContact;
    }

    private MaximoEventHistory addMaximoEventHistory(WorkOrder workOrder,
                                                     String process,
                                                     String action,
                                                     MaximoWorkRequest maximoWorkRequest,
                                                     List<String> processingInfos) {
        MaximoEventHistory maximoEventHistory = new MaximoEventHistory();
        maximoEventHistory.process = process;
        maximoEventHistory.action = action;
        maximoEventHistory.date = new Date();
        maximoEventHistory.currentUserBtRef = currentUserBT.getCurrentUser().getRef();
        handleMaximoEventHistoryDetails(maximoWorkRequest, maximoEventHistory, processingInfos);
        microservice.addMaximoEventHistory(workOrder.getId(), maximoEventHistory);
        return maximoEventHistory;
    }

    private MaximoEventHistory addMaximoEventHistory(WorkOrder workOrder, String process, String action) {
        return addMaximoEventHistory(workOrder, process, action, null, null);
    }

    private void handleMaximoEventHistoryDetails(MaximoWorkRequest maximoWorkRequest,
                                                 MaximoEventHistory maximoEventHistory,
                                                 List<String> processingInfos) {
        if (maximoWorkRequest != null && maximoEventHistory != null && !ListUtil.isEmpty(processingInfos)) {
            StringBuilder detailsBuilder = new StringBuilder();
            for (String info : processingInfos) {
                switch (info) {
                    case CmmsConstants.INFO_INVALID_SPACE:
                        if (StringUtil.isBlankOrNull(maximoWorkRequest.localRoomNum)) {
                            detailsBuilder.append("Room was blank; ");
                        } else {
                            detailsBuilder.append(String.format("Room was not found: %s; ", maximoWorkRequest.localRoomNum));
                        }
                        break;
                    case CmmsConstants.INFO_SPACE_UPDATED:
                        detailsBuilder.append(String.format("Room was updated: %s; ", maximoWorkRequest.localRoomNum));
                        break;
                    case CmmsConstants.INFO_INVALID_RPE:
                        if (StringUtil.isBlankOrNull(maximoWorkRequest.rpieIndexNum)) {
                            detailsBuilder.append("RPE was blank; ");
                        } else {
                            detailsBuilder.append(String.format("RPE was not found: %s; ", maximoWorkRequest.rpieIndexNum));
                        }
                        break;
                    case CmmsConstants.INFO_RPE_UPDATED:
                        detailsBuilder.append(String.format("RPE was updated: %s; ", maximoWorkRequest.rpieIndexNum));
                        break;
                    default:
                        break;
                }
            }
            if (detailsBuilder.length() > 0) {
                String detailsString = StringUtil.trimNNCharactersFromEndOfString(detailsBuilder.toString(), 2);
                maximoEventHistory.details = detailsString;
            }
        }
    }

    private void writeCmmsErrorOrInfos(ECmmsActionType eCmmsActionType,
                                       MaximoWorkRequest maximoWorkRequest,
                                       WorkOrder workOrder,
                                       MaximoEventHistory maximoEventHistory,
                                       List<String> processingInfos,
                                       List<String> processingErrors) {
        Date actionDate;
        if (maximoEventHistory != null && maximoEventHistory.date != null) {
            actionDate = maximoEventHistory.date;
        } else {
            actionDate = new Date();
        }

        if (!ListUtil.isEmpty(processingErrors)) {
            CmmsError cmmsError = new CmmsError();
            cmmsError.actionDate = actionDate;
            cmmsError.eCmmsActionType = eCmmsActionType;
            cmmsError.workOrderId = handleStringValue(workOrder.getId());
            cmmsError.workOrderNumber = handleStringValue(workOrder.workOrderNumber);
            cmmsError.externalWorkOrderId = handleStringValue(maximoWorkRequest.workOrder);
            cmmsError.facilityRef = (FacilityRef) handleRefValue(workOrder.facilityRef);
            cmmsError.siteRef = (SiteRef) handleRefValue(workOrder.siteRef);
            cmmsError.managedByOrganizationRef = (OrganizationRef) handleRefValue(workOrder.managedByOrganizationRef);

            CmmsErrorType cmmsErrorType = microservice.getCmmsErrorTypeByKey(processingErrors.get(0));
            if (cmmsErrorType != null) {
                cmmsError.cmmsErrorTypeRef = cmmsErrorType.getRef();
            }
            microservice.createCmmsError(cmmsError);
        } else if (!ListUtil.isEmpty(processingInfos)) {
            for (String info : processingInfos) {
                CmmsError cmmsInfo = new CmmsError();
                cmmsInfo.actionDate = actionDate;
                cmmsInfo.eCmmsActionType = eCmmsActionType;
                cmmsInfo.workOrderId = handleStringValue(workOrder.getId());
                cmmsInfo.workOrderNumber = handleStringValue(workOrder.workOrderNumber);
                cmmsInfo.externalWorkOrderId = handleStringValue(maximoWorkRequest.workOrder);
                cmmsInfo.facilityRef = (FacilityRef) handleRefValue(workOrder.facilityRef);
                cmmsInfo.siteRef = (SiteRef) handleRefValue(workOrder.siteRef);
                cmmsInfo.managedByOrganizationRef = (OrganizationRef) handleRefValue(workOrder.managedByOrganizationRef);

                CmmsErrorType cmmsInfoType = microservice.getCmmsErrorTypeByKey(info);
                if (cmmsInfoType != null) {
                    cmmsInfo.cmmsErrorTypeRef = cmmsInfoType.getRef();
                }
                microservice.createCmmsError(cmmsInfo);
            }
        }
    }

    private ReferenceObject handleRefValue(ReferenceObject refValue) {
        return refValue;
    }

    private String handleStringValue(String value, String defaultValue) {
        if (!StringUtil.isBlankOrNull(value)) {
            return value;
        }
        return defaultValue;
    }

    private String handleStringValue(String value) {
        return handleStringValue(value, null);
    }

    private void mapCmmsInstallationAndExpenseCenter(MaximoWorkRequest maximoWorkRequest,
                                                     WorkOrder workOrder,
                                                     List<String> processingInfos,
                                                     List<String> processingErrors) {
        CmmsExpenseCenter expenseCenter
                = StringUtil.isBlankOrNull(maximoWorkRequest.eorCode) ? null : microservice.getCmmsExpenseCenterByExpenseCenterId(maximoWorkRequest.eorCode);

        if (expenseCenter == null) {
            int fiscalYear = DateUtil.getFiscalYear(DateUtil.localDateFromDate(workOrder.estimatedStartDate));
            expenseCenter = getDefaultCmmsExpenseCenter(maximoWorkRequest.docInfo.source, Integer.toString(fiscalYear));
            cmmsInboundWorkOrderValidator.validateCmmsDefaultExpenseCenter(expenseCenter, processingInfos, processingErrors);
        }
        cmmsInboundWorkOrderValidator.validateCmmsExpenseCenterManagedByOrganization(expenseCenter, maximoWorkRequest.docInfo.source, processingErrors);
        workOrder.cmmsExpenseCenterRef = expenseCenter.getRef();
    }

    private void mapCmmsBasicInfo(MaximoWorkRequest maximoWorkRequest, WorkOrder workOrder) {
        workOrder.isMaximoWO = true;
        workOrder.createdByRef = currentUserBT.getCurrentUser().profile.getRef();
        workOrder.externalWorkOrderId = maximoWorkRequest.workOrder;
        workOrder.subject = handleStringValue(maximoWorkRequest.subject, CmmsConstants.MAXIMO_UNKNOWN);
        workOrder.description = handleStringValue(maximoWorkRequest.workReqDesc, CmmsConstants.MAXIMO_UNKNOWN);
        workOrder.estimatedCompletionDate = maximoWorkRequest.estCompleteDate;
        workOrder.estimatedStartDate = maximoWorkRequest.estStartDate;
        workOrder.requestedCompletionDate = maximoWorkRequest.reqCompleteDate;
        workOrder.requestDate = maximoWorkRequest.requestDate;
        if (StringUtil.isBlankOrNull(maximoWorkRequest.requesterName)) {
            workOrder.requesterName = MAXIMO_REQUESTER;
        } else {
            workOrder.requesterName = maximoWorkRequest.requesterName;
        }
        if (StringUtil.isBlankOrNull(maximoWorkRequest.requesterPhone)) {
            workOrder.requesterContactNumber = MAXIMO_CONTACT_NUMBER;
        } else {
            workOrder.requesterContactNumber = maximoWorkRequest.requesterPhone;
        }
        workOrder.closeOutReason = maximoWorkRequest.closeoutReason;
    }

    private void mapCmmsSpaceAndAsset(MaximoWorkRequest maximoWorkRequest,
                                      WorkOrder workOrder,
                                      List<String> processingInfos) {
        try {
            if (!StringUtil.isBlankOrNull(maximoWorkRequest.localRoomNum)) {
                Space roomByRoomNumber = spaceManagementService.getRoomByRoomNumber(
                        workOrder.facilityRef.getId(), maximoWorkRequest.localRoomNum);
                boolean roomUpdated = false;

                if (workOrder.spaceRefs.stream().noneMatch(spaceRef -> Objects.equals(spaceRef.id, roomByRoomNumber.getId()))) {
                    workOrder.spaceRefs.add(roomByRoomNumber.getRef());
                    roomUpdated = true;
                }
                if (!Objects.equals(maximoWorkRequest.workReqStat, CmmsConstants.MAX_INSERT) && roomUpdated) {
                    processingInfos.add(CmmsConstants.INFO_SPACE_UPDATED);
                }
            }
        } catch (ApplicationException e) {
            maximoWorkRequest.otherWorkLoc =
                    ((!StringUtil.isBlankOrNull(maximoWorkRequest.otherWorkLoc)) ? maximoWorkRequest.otherWorkLoc + ", " : "") + maximoWorkRequest.localRoomNum;
            processingInfos.add(CmmsConstants.INFO_INVALID_SPACE);
            logger.error(String.format("Maximo localRoomNum: %s not found for Facility %s", maximoWorkRequest.localRoomNum, workOrder.facilityRef.getId()), e);
        }

        Asset asset = null;
        if (!StringUtil.isBlankOrNull(maximoWorkRequest.rpieIndexNum)) {
            asset = assetService.getAssetByIdentifier(workOrder.facilityRef.getId(), maximoWorkRequest.rpieIndexNum);
            if (asset != null && asset.locationInformation != null && asset.locationInformation.spaceRef != null) {
                String spaceId = asset.locationInformation.spaceRef.getId();
                if (ListUtil.isEmpty(workOrder.spaceRefs)) {
                    workOrder.spaceRefs = new ArrayList<>();
                    workOrder.spaceRefs.add(asset.locationInformation.spaceRef);
                    if (!Objects.equals(maximoWorkRequest.workReqStat, CmmsConstants.MAX_INSERT)) {
                        processingInfos.add(CmmsConstants.INFO_SPACE_UPDATED);
                    }
                } else {
                    if (workOrder.spaceRefs.stream().noneMatch(spaceRef -> Objects.equals(spaceRef.id, spaceId))) {
                        workOrder.spaceRefs.add(asset.locationInformation.spaceRef);
                        if (!Objects.equals(maximoWorkRequest.workReqStat, CmmsConstants.MAX_INSERT)) {
                            processingInfos.add(CmmsConstants.INFO_SPACE_UPDATED);
                        }
                    }
                }
            } else {
                processingInfos.add(CmmsConstants.INFO_INVALID_RPE);
            }
        }
        cmmsInboundWorkOrderValidator.validateAndSetAssetAndSpace(maximoWorkRequest, workOrder, asset, processingInfos);
    }

    private void mapCmmsPriorityGroup(MaximoWorkRequest maximoWorkRequest, WorkOrder workOrder, List<String> processingInfos) {
        List<PriorityGroup> priorityGroups = getActivePriorityGroups();
        Optional<PriorityGroup> priorityGroupOptional;
        if (maximoWorkRequest.woPriority == null) {
            priorityGroupOptional = priorityGroups.stream().filter(type -> type.name.equalsIgnoreCase(PRIORITY_GROUP_ROUTINE)).findFirst();
            processingInfos.add(CmmsConstants.INFO_DEFAULT_PRIORITY_GROUP);
        } else {
            if (maximoWorkRequest.woPriority >= 5) {
                priorityGroupOptional = priorityGroups.stream().filter(type -> type.name.equalsIgnoreCase(PRIORITY_GROUP_EMERGENCY)).findFirst();
            } else if (maximoWorkRequest.woPriority == 4 || maximoWorkRequest.woPriority == 3) {
                priorityGroupOptional = priorityGroups.stream().filter(type -> type.name.equalsIgnoreCase(PRIORITY_GROUP_URGENT)).findFirst();
            } else {
                priorityGroupOptional = priorityGroups.stream().filter(type -> type.name.equalsIgnoreCase(PRIORITY_GROUP_ROUTINE)).findFirst();
            }
        }

        if (priorityGroupOptional.isPresent()) {
            workOrder.priorityGroupRef = priorityGroupOptional.get().getRef();
        } else {
            workOrder.priorityGroupRef = getDefaultPriorityGroupRef();
            processingInfos.add(CmmsConstants.INFO_DEFAULT_PRIORITY_GROUP);
        }
    }

    private void mapCmmsClassificationType(MaximoWorkRequest maximoWorkRequest, WorkOrder workOrder) {
        List<ClassificationType> classificationTypes = getActiveClassificationTypes();
        Optional<ClassificationType> classificationTypeOptional;
        List<String> recurringTypes = List.of("PM", "RECURRING");
        if (recurringTypes.contains(StringUtil.safeToUppercase(maximoWorkRequest.workType))) {
            classificationTypeOptional = classificationTypes.stream().filter(type -> type.name.equalsIgnoreCase(CLASSIFICATION_TYPE_NAME_RECURRING_WORK)).findFirst();
        } else {
            classificationTypeOptional = classificationTypes.stream().filter(type -> type.name.equalsIgnoreCase(CLASSIFICATION_TYPE_NAME_SERVICE_REQUEST)).findFirst();
        }
        classificationTypeOptional.ifPresent(type -> workOrder.classificationTypeRef = type.getRef());
    }

    private Assignment mapCmmsWorkPerformed(MaximoWorkRequest maximoWorkRequest, WorkOrder workOrder,
                                            CmmsBusinessContact cmmsBusinessContact, SkillRef defaultCmmsSkill,
                                            List<String> processingInfos, List<String> processingErrors) {
        Assignment assignmentForFinanceUpdate = null;

        // Initialize WO Assignments info
        initCmmsWorkPerformedAndAssignments(maximoWorkRequest, workOrder);

        // Set Lead Skill/Shop for the MaximoWorkRequest
        SkillRef candidateWrLeadSkill =
                assetMaintenanceProcedureService.getSkillRefByCodeOrNameIgnoreCase(maximoWorkRequest.leadcraft);
        SkillRef wrLeadSkill = cmmsInboundWorkOrderValidator.getWorkRequestLeadSkill(
                candidateWrLeadSkill, defaultCmmsSkill, cmmsBusinessContact, processingInfos, processingErrors);

        getMaximoCommodityFilterProperties();

        // Handle the List of Work Performed
        if (!ListUtil.isEmpty(maximoWorkRequest.workPerformedList)) {
            try {
                int totalAssignments = 0;
                int assignmentsUsingDefaultSkill = 0;

                for (MaximoWorkPerformed workPerformed : maximoWorkRequest.workPerformedList) {
                    // Determine Assignment Skill/Shop and whether it is the Lead Shop/Skill
                    SkillRef candidateAssignmentSkill
                            = assetMaintenanceProcedureService.getSkillRefByCodeOrNameIgnoreCase(workPerformed.leadcraft);
                    SkillRef assignmentSkill = cmmsInboundWorkOrderValidator.getAssignmentSkill(
                            candidateAssignmentSkill, defaultCmmsSkill, cmmsBusinessContact, processingInfos, processingErrors);

                    if (assignmentSkill.getId().equals(defaultCmmsSkill.getId())) {
                        assignmentsUsingDefaultSkill++;
                        cmmsInboundWorkOrderValidator.checkForOveruseOfDefaultSkill(assignmentsUsingDefaultSkill, processingErrors);
                    }

                    boolean isLeadShop = (assignmentSkill.getId().equals(wrLeadSkill.getId()));

                    // Update CMMS Business Contact Labor Rate for the Assignment
                    setCmmsBusinessContactDefaultLaborRate(cmmsBusinessContact, assignmentSkill);

                    // Determine Asset
                    Asset workPerformedAsset = getCmmsWorkPerformedAsset(workOrder, workPerformed);
                    cmmsInboundWorkOrderValidator.validateWorkPerformedAsset(workOrder, workPerformedAsset, processingInfos);

                    // Determine if this Assignment already exists (i.e. occurred in a previously-processed WorkPerformed))
                    Assignment assignment = null;
                    boolean assignmentAlreadyExists = false;

                    if (!ListUtil.isEmpty(workOrder.assignments)) {
                        for (Assignment existingAssignment : workOrder.assignments) {
                            if (cmmsNewAssignmentMatchesExistingOne(existingAssignment, assignmentSkill, workPerformed, workPerformedAsset)) {
                                assignmentAlreadyExists = true;
                                assignment = existingAssignment;
                                break;
                            }
                        }
                    }

                    if (!assignmentAlreadyExists) {
                        assignment = new Assignment();
                        Assignment assignmentWithEstimatedUpdate = setCmmsAssignmentDetails(
                                maximoWorkRequest, workOrder, assignment, assignmentSkill, cmmsBusinessContact, isLeadShop, totalAssignments);
                        if ( assignmentWithEstimatedUpdate != null ) {
                            assignmentForFinanceUpdate = assignmentWithEstimatedUpdate;
                        }
                        workOrder.assignments.add(assignment);
                        totalAssignments++;
                    }

                    // Set Actual Cost info
                    setCmmsActualCostDetails(workPerformed, workOrder, assignment, workPerformedAsset, assignmentAlreadyExists);
                }

                microservice.calculateEstimatedAndActualTotals(workOrder);
            } catch (Exception e) {
                // Fortify Note: Keeping broad catch exception to ensure the all processing errors are captured.
                if (ListUtil.isEmpty(processingErrors)) {
                    processingErrors.add(CmmsConstants.ERROR_COST_UPDATE_ISSUES);
                }
                throw new ValidationException(String.format("Error occurred with CMMS Work Performed: %s", e));
            }
        }

        return assignmentForFinanceUpdate;
    }

    private boolean cmmsNewAssignmentMatchesExistingOne(Assignment existingAssignment,
                                                        SkillRef newSkill,
                                                        MaximoWorkPerformed newWorkPerformed,
                                                        Asset newAsset) {
        boolean retVal = false;
        if (existingAssignment.skillRef.getId().equals(newSkill.getId()) && !ListUtil.isEmpty(existingAssignment.actualCosts)) {
            ActualCost existingActualCost = existingAssignment.actualCosts.get(0);
            LocalDate existingServiceLocalDate = DateUtil.localDateFromDate(existingActualCost.servicePerformedDate);
            LocalDate newServiceLocalDate = DateUtil.localDateFromDate(newWorkPerformed.performedServiceDate);

            if (existingServiceLocalDate.isEqual(newServiceLocalDate)
                    && cmmsAssetInfoEquivalent(existingActualCost, newAsset)) {
                retVal = true;
            }
        }
        return retVal;
    }

    private boolean cmmsAssetInfoEquivalent(ActualCost existingActCost, Asset newAsset) {
        boolean retVal = false;
        if ((existingActCost.assetRef == null && newAsset == null)
                ||
                existingActCost.assetRef != null && newAsset != null && existingActCost.assetRef.getId().equals(newAsset.getId())) {
            retVal = true;
        }
        return retVal;
    }

    private void initCmmsWorkPerformedAndAssignments(MaximoWorkRequest maximoWorkRequest, WorkOrder workOrder) {
        workOrder.assignments = new ArrayList<>();

        workOrder.actualCostSummary = new CostSummary();
        workOrder.actualCostSummary.total = new MonetaryValue();
        workOrder.actualCostSummary.material = new MonetaryValue();
        workOrder.actualCostSummary.labor = new MonetaryValue();
        workOrder.actualCostSummary.parts = new MonetaryValue();
        workOrder.actualCostSummary.createdDate = new Date();

        workOrder.totalActualLaborHours = 0f;
        workOrder.totalAssignmentsActualCosts = new MonetaryValue();

        workOrder.estimatedCostSummary = new CostSummary();
        workOrder.estimatedCostSummary.createdDate = new Date();
        workOrder.totalEstimatedLaborHours = 0f;
        workOrder.estimatedCostSummary.parts = maximoWorkRequest.estEqCost;
        workOrder.estimatedCostSummary.labor = maximoWorkRequest.estLabCost;
        workOrder.estimatedCostSummary.material = maximoWorkRequest.estMatCost;

        workOrder.estimatedCostSummary.total = new MonetaryValue();
        workOrder.estimatedCostSummary.total = workOrder.estimatedCostSummary.total
                .add(workOrder.estimatedCostSummary.parts).add(workOrder.estimatedCostSummary.labor)
                .add(workOrder.estimatedCostSummary.material);
    }

    private void setCmmsBusinessContactDefaultLaborRate(CmmsBusinessContact cmmsBusinessContact, SkillRef skillRef) {
        if (cmmsBusinessContact != null
                && cmmsBusinessContact.businessContact != null
                && !ListUtil.isEmpty(cmmsBusinessContact.businessContact.services)
                && skillRef != null) {
            for (Services s : cmmsBusinessContact.businessContact.services) {
                if (StringUtil.safeEquals(s.skillRef.getId(), skillRef.getId()) && s.defaultLaborRate != null) {
                    cmmsBusinessContact.defaultLaborRate = s.defaultLaborRate;
                    break;
                }
            }
        }
    }

    private Assignment setCmmsAssignmentDetails(MaximoWorkRequest maximoWorkRequest, WorkOrder workOrder,
                                                Assignment assignment, SkillRef skill,
                                                CmmsBusinessContact cmmsBusinessContact, boolean isLeadShop, int totalAssignments) {
        Assignment assignmentForFinanceUpdate = null;

        assignment.assignmentId = stringUtil.getUUID();
        assignment.skillRef = skill;
        assignment.isLeadShop = isLeadShop;
        assignment.businessContactRef = cmmsBusinessContact.businessContact.getRef();
        assignment.defaultLaborRate = cmmsBusinessContact.defaultLaborRate;
        assignment.assignedDate = workOrder.estimatedStartDate;
        assignment.requiredCompletionDate = maximoWorkRequest.reqCompleteDate;
        assignment.reason = EAssignmentReason.PERFORMANCE_OF_WORK;
        assignment.estimatedCosts = new CostSummary();
        assignment.estimatedCosts.createdDate = new Date();

        Personnel personnel = new Personnel();
        personnel.personnelId = stringUtil.getUUID();
        personnel.contact = cmmsBusinessContact.contact;
        personnel.address = cmmsBusinessContact.businessContact.address;
        personnel.laborRate = cmmsBusinessContact.defaultLaborRate;
        assignment.personnel = personnel;

        if (totalAssignments == 0) {
            // Estimated costs are provided at the overall MaximoWorkRequest level ONLY...therefore, only record them for first Assignment
            assignment.estimatedCosts.parts = maximoWorkRequest.estEqCost;
            assignment.estimatedCosts.labor = maximoWorkRequest.estLabCost;
            assignment.estimatedCosts.material = maximoWorkRequest.estMatCost;
            assignment.estimatedCosts.total = assignment.estimatedCosts.parts.add(assignment.estimatedCosts.labor).add(assignment.estimatedCosts.material);
            populateFundingInfoFromCmmsExpenseCenter(assignment.estimatedCosts, workOrder);
            assignmentForFinanceUpdate = assignment;
        } else {
            assignment.estimatedCosts.parts = new MonetaryValue();
            assignment.estimatedCosts.labor = new MonetaryValue();
            assignment.estimatedCosts.material = new MonetaryValue();
            assignment.estimatedCosts.total = new MonetaryValue();
        }

        return assignmentForFinanceUpdate;
    }

    private void setCmmsActualCostDetails(MaximoWorkPerformed workPerformed, WorkOrder workOrder,
                                          Assignment assignment, Asset asset, boolean assignmentAlreadyExists) {
        ActualCost actualCost;

        if (assignmentAlreadyExists) {
            actualCost = assignment.actualCosts.get(0);
            actualCost.laborHours += workPerformed.hoursSpent;
            actualCost.costSummary.parts = actualCost.costSummary.parts.add(workPerformed.actEqCost);
            actualCost.costSummary.material = actualCost.costSummary.material.add(workPerformed.actMatCost);
            actualCost.costSummary.labor = actualCost.costSummary.labor.add(workPerformed.actLabCost);
            actualCost.costSummary.total = actualCost.costSummary.parts
                    .add(actualCost.costSummary.material)
                    .add(actualCost.costSummary.labor);
            assignment.actualCostSummary = actualCost.costSummary;

            workOrder.totalActualLaborHours += workPerformed.hoursSpent;
            workOrder.actualCostSummary.parts = workOrder.actualCostSummary.parts.add(workPerformed.actEqCost);
            workOrder.actualCostSummary.material = workOrder.actualCostSummary.material.add(workPerformed.actMatCost);
            workOrder.actualCostSummary.labor = workOrder.actualCostSummary.labor.add(workPerformed.actLabCost);

            workOrder.actualCostSummary.total = workOrder.actualCostSummary.total
                    .add(workPerformed.actEqCost)
                    .add(workPerformed.actMatCost)
                    .add(workPerformed.actLabCost);
            workOrder.totalAssignmentsActualCosts = workOrder.actualCostSummary.total;
        } else {
            actualCost = new ActualCost();
            if (asset != null) {
                actualCost.assetRef = asset.getRef();
            }
            actualCost.actualCostId = stringUtil.getUUID();
            actualCost.costType = EWorkOrderCostType.ACTUAL;
            actualCost.laborHours = workPerformed.hoursSpent;
            actualCost.servicePerformedDate = workPerformed.performedServiceDate;
            actualCost.costSummary = new CostSummary();
            actualCost.costSummary.parts = workPerformed.actEqCost;
            actualCost.costSummary.material = workPerformed.actMatCost;
            actualCost.costSummary.labor = workPerformed.actLabCost;
            actualCost.costSummary.createdDate = workPerformed.performedServiceDate;
            actualCost.costSummary.total = workPerformed.actEqCost.add(workPerformed.actMatCost).add(workPerformed.actLabCost);
            populateFundingInfoFromCmmsExpenseCenter(actualCost.costSummary, workOrder);

            assignment.actualCosts.add(actualCost);
            assignment.actualCostSummary = actualCost.costSummary;

            workOrder.totalActualLaborHours += actualCost.laborHours;
            workOrder.actualCostSummary.parts = workOrder.actualCostSummary.parts.add(actualCost.costSummary.parts);
            workOrder.actualCostSummary.material = workOrder.actualCostSummary.material.add(actualCost.costSummary.material);
            workOrder.actualCostSummary.labor = workOrder.actualCostSummary.labor.add(actualCost.costSummary.labor);
            workOrder.actualCostSummary.total = workOrder.actualCostSummary.total.add(actualCost.costSummary.total);
            workOrder.totalAssignmentsActualCosts = workOrder.totalAssignmentsActualCosts.add(actualCost.costSummary.total);
        }
    }

    private void populateFundingInfoFromCmmsExpenseCenter(CostSummary costSummary, WorkOrder workOrder) {
        if (costSummary == null || workOrder == null || workOrder.cmmsExpenseCenterRef == null || StringUtil.isEmptyOrNull(workOrder.cmmsExpenseCenterRef.id)) {
            return;
        }

        String cmmsExpenseCenterId =  workOrder.cmmsExpenseCenterRef.id;
        CmmsExpenseCenter cmmsExpenseCenter = microservice.getCmmsExpenseCenterById(cmmsExpenseCenterId);
        if ( cmmsExpenseCenter == null ) {
            return;
        }

        costSummary.laborFunding = new RealPropertyFunding();
        costSummary.materialFunding = new RealPropertyFunding();
        costSummary.partsFunding = new RealPropertyFunding();

        costSummary.laborFunding.projectFundingNodeRef = cmmsExpenseCenter.projectFundingNodeRef;
        costSummary.materialFunding.projectFundingNodeRef = cmmsExpenseCenter.projectFundingNodeRef;
        costSummary.partsFunding.projectFundingNodeRef = cmmsExpenseCenter.projectFundingNodeRef;

        costSummary.laborFunding.expenseFundingNodeRef = cmmsExpenseCenter.expenseFundingNodeRef;
        costSummary.materialFunding.expenseFundingNodeRef = cmmsExpenseCenter.expenseFundingNodeRef;
        costSummary.partsFunding.expenseFundingNodeRef = cmmsExpenseCenter.expenseFundingNodeRef;

        costSummary.laborFunding.commodityCodeRef = getCommodityCodeRefForMaximo(cmmsExpenseCenter, COMMODITY_TYPE_LABOR);
        costSummary.materialFunding.commodityCodeRef = getCommodityCodeRefForMaximo(cmmsExpenseCenter, COMMODITY_TYPE_MATERIAL);
        costSummary.partsFunding.commodityCodeRef = getCommodityCodeRefForMaximo(cmmsExpenseCenter, COMMODITY_TYPE_PARTS);
    }

    private CommodityCodeRef setCommodityCodeRefForMaximo(CmmsExpenseCenter cmmsExpenseCenter, String commodityType ) {
        List<CommodityCodeRef> orgCommodityCodes = getCommodityCodeRefs(cmmsExpenseCenter.managedByNodeRef.id );
        if ( ListUtil.isEmpty(orgCommodityCodes) )
            return null;

        if ( cmmsExpenseCenter.managedByNodeRef.ancestry.contains(NAVY_ORG_ID) ) {
            String codeValue = getCommodityFilterValue(COMMODITY_ORG_NAVY, commodityType, COMMODITY_FILTER_CODE);
            String typeValue = getCommodityFilterValue(COMMODITY_ORG_NAVY, commodityType, COMMODITY_FILTER_TYPE);
            String commodityTypeValue = getCommodityFilterValue(COMMODITY_ORG_NAVY, commodityType, COMMODITY_FILTER_COMMODITYTYPE);
            for(CommodityCodeRef ref : orgCommodityCodes ) {
                if(ref.code.equals(codeValue) && ref.type.equals(typeValue) && ref.commodityType.equals(commodityTypeValue)) {
                    defaultCommodityCodeRefsForMaximo.put(COMMODITY_ORG_NAVY+commodityType, ref);
                    return ref;
                }
            }
        }
        else if ( cmmsExpenseCenter.managedByNodeRef.ancestry.contains(ARMY_ORG_ID) ) {
            String codeValue = getCommodityFilterValue(COMMODITY_ORG_ARMY, commodityType, COMMODITY_FILTER_CODE);
            String typeValue = getCommodityFilterValue(COMMODITY_ORG_ARMY, commodityType, COMMODITY_FILTER_TYPE);
            String nameValue = getCommodityFilterValue(COMMODITY_ORG_ARMY, commodityType, COMMODITY_FILTER_NAME);
            for(CommodityCodeRef ref : orgCommodityCodes ) {
                if(ref.code.equals(codeValue) && ref.type.equals(typeValue) && ref.name.equals(nameValue)) {
                    defaultCommodityCodeRefsForMaximo.put(COMMODITY_ORG_ARMY+commodityType, ref);
                    return ref;
                }
            }
        }
        else if ( cmmsExpenseCenter.managedByNodeRef.ancestry.contains(AIR_FORCE_ORG_ID) ) {
            String codeValue = getCommodityFilterValue(COMMODITY_ORG_AIR_FORCE, commodityType, COMMODITY_FILTER_CODE);
            String typeValue = getCommodityFilterValue(COMMODITY_ORG_AIR_FORCE, commodityType, COMMODITY_FILTER_TYPE);
            String nameValue = getCommodityFilterValue(COMMODITY_ORG_AIR_FORCE, commodityType, COMMODITY_FILTER_NAME);
            for(CommodityCodeRef ref : orgCommodityCodes ) {
                if(ref.code.equals(codeValue) && ref.type.equals(typeValue) && ref.name.equals(nameValue)) {
                    defaultCommodityCodeRefsForMaximo.put(COMMODITY_ORG_AIR_FORCE+commodityType, ref);
                    return ref;
                }
            }
        }

        return null;
    }

    private CommodityCodeRef getCommodityCodeRefForMaximo(CmmsExpenseCenter cmmsExpenseCenter, String commodityType ) {
        CommodityCodeRef commodityCodeRef = null;
        if ( cmmsExpenseCenter.managedByNodeRef.ancestry.contains(NAVY_ORG_ID)) {
            commodityCodeRef = defaultCommodityCodeRefsForMaximo.get(COMMODITY_ORG_NAVY+commodityType);
        } else if ( cmmsExpenseCenter.managedByNodeRef.ancestry.contains(ARMY_ORG_ID)) {
            commodityCodeRef = defaultCommodityCodeRefsForMaximo.get(COMMODITY_ORG_ARMY+commodityType);

        } else if ( cmmsExpenseCenter.managedByNodeRef.ancestry.contains(AIR_FORCE_ORG_ID)) {
            commodityCodeRef = defaultCommodityCodeRefsForMaximo.get(COMMODITY_ORG_AIR_FORCE+commodityType);
        }

        if ( commodityCodeRef == null ) {
            commodityCodeRef = setCommodityCodeRefForMaximo(cmmsExpenseCenter, commodityType);
        }

        return commodityCodeRef;
    }

    private void getMaximoCommodityFilterProperties() {
        maximoCommodityFilterProperties =  new HashMap<>();
        List<Configuration> configurations = getAllConfigurations();
        if ( !ListUtil.isEmpty(configurations)) {
            configurations = configurations.stream().filter(conf -> conf.name.startsWith(COMMODITY_FILTER_PROP_PREFIX)).collect(Collectors.toList());
            for(Configuration item : configurations) {
                maximoCommodityFilterProperties.put(item.name, item.value);
            }
        }
    }

    private String getCommodityFilterValue(String orgName, String commodityType, String filterName) {
        String propertyName = COMMODITY_FILTER_PROP_PREFIX + orgName + commodityType + filterName;
        return maximoCommodityFilterProperties.get(propertyName);
    }

    private Asset getCmmsWorkPerformedAsset(WorkOrder workOrder, MaximoWorkPerformed workPerformed) {
        Asset asset = null;
        if (workOrder.facilityRef != null && !StringUtil.isBlankOrNull(workPerformed.rpieIndexNum)) {
            asset = assetService.getAssetByIdentifier(workOrder.facilityRef.getId(), workPerformed.rpieIndexNum);
        }
        return asset;
    }

    private void updateCmmsWOCompletionDate(MaximoWorkRequest maximoWorkRequest, WorkOrder workOrder) {
        if (completionDateUpdatedFromCmms(maximoWorkRequest, workOrder)) {
            microservice.updateWorkOrderCompletionDate(workOrder.getId(), workOrder.completionDate);
        }
    }

    protected boolean completionDateUpdatedFromCmms(MaximoWorkRequest maximoWorkRequest, WorkOrder workOrder) {
        // method has protected access to facilitate unit testing
        boolean retVal = false;
        if (CmmsConstants.MAX_CAN.equals(maximoWorkRequest.workReqStat) ||
                CmmsConstants.MAX_COMP.equals(maximoWorkRequest.workReqStat) ||
                CmmsConstants.MAX_CLOSE.equals(maximoWorkRequest.workReqStat)) {
            Date maximoCompDate = getCmmsCompletionDate(maximoWorkRequest);
            if (maximoCompDate != null && !DateUtil.safeDateEquals(maximoCompDate, workOrder.completionDate)) {
                workOrder.completionDate = maximoCompDate;
                return true;
            } else if (maximoCompDate == null && workOrder.completionDate == null) {
                workOrder.completionDate = new Date();
                return true;
            }
        }
        return retVal;
    }

    protected Date getCmmsCompletionDate(MaximoWorkRequest maximoWorkRequest) {
        // method has protected access to facilitate unit testing
        Date retVal = null;
        switch (maximoWorkRequest.workReqStat) {
            case CmmsConstants.MAX_CAN:
            case CmmsConstants.MAX_COMP:
            case CmmsConstants.MAX_CLOSE:
                if (maximoWorkRequest.completionDate != null) {
                    String compTime =
                            (StringUtil.isBlankOrNull(maximoWorkRequest.completionTime) ? "00:00" : maximoWorkRequest.completionTime);
                    retVal = DateUtil.dateFromDateAndTime(maximoWorkRequest.completionDate, compTime);
                }
                break;
            default:
        }
        return retVal;
    }

    public WorkOrder updateWorkOrderEquipmentInspections(WorkOrder workOrder) {
        return microservice.updateWorkOrderEquipmentInspections(workOrder);
    }

    public List<CmmsExpenseCenter> getCmmsExpenseCenters() {
        String userOrgId = currentUserBT.getCurrentUser().profile.currentNodeRef.id;
        List<CmmsExpenseCenter> cmmsExpenseCenters;
        if (OrganizationConstants.isRootOrDevUser(userOrgId)) {
            cmmsExpenseCenters = microservice.getCmmsExpenseCenters();
        } else {
            cmmsExpenseCenters = microservice.getCmmsExpenseCentersByOrganizationId(userOrgId);
        }
        return cmmsExpenseCenters;
    }

    public CmmsExpenseCenter createCmmsExpenseCenter(CmmsExpenseCenter cmmsExpenseCenter) {
        cmmsExpenseCenter.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        validateCmmsExpenseCenterAndChangeDefaultIfNeeded(cmmsExpenseCenter);
        populateCmmsExpenseCenterFunding(cmmsExpenseCenter);
        return microservice.createCmmsExpenseCenter(cmmsExpenseCenter);
    }

    public CmmsExpenseCenter updateCmmsExpenseCenter(CmmsExpenseCenter cmmsExpenseCenter) {
        validateCmmsExpenseCenterAndChangeDefaultIfNeeded(cmmsExpenseCenter);
        populateCmmsExpenseCenterFunding(cmmsExpenseCenter);
        return microservice.updateCmmsExpenseCenter(cmmsExpenseCenter);
    }

    private void populateCmmsExpenseCenterFunding(CmmsExpenseCenter cmmsExpenseCenter) {
        if (cmmsExpenseCenter == null)
            return;

        if (cmmsExpenseCenter.projectFundingNodeRef != null && !StringUtil.isEmptyOrNull(cmmsExpenseCenter.projectFundingNodeRef.id)) {
            ProcessingBalance projectFundingPB = financeAdminService.getFundingNodeById(cmmsExpenseCenter.projectFundingNodeRef.id);
            if (projectFundingPB != null && projectFundingPB.fundingNodeRef != null && projectFundingPB.fundingNodeRef.id.equals(cmmsExpenseCenter.projectFundingNodeRef.id)) {
                cmmsExpenseCenter.projectFundingNodeRef = projectFundingPB.fundingNodeRef;
            }
        }

        if (cmmsExpenseCenter.expenseFundingNodeRef != null && !StringUtil.isEmptyOrNull(cmmsExpenseCenter.expenseFundingNodeRef.id)) {
            ProcessingBalance expenseFundingPB = financeAdminService.getFundingNodeById(cmmsExpenseCenter.expenseFundingNodeRef.id);
            if (expenseFundingPB != null && expenseFundingPB.fundingNodeRef != null && expenseFundingPB.fundingNodeRef.id.equals(cmmsExpenseCenter.expenseFundingNodeRef.id)) {
                cmmsExpenseCenter.expenseFundingNodeRef = expenseFundingPB.fundingNodeRef;
            }
        }

        // Added for DMLSS=>LC Data migration...
        if (migrateProjectCenterFromDMLSS(cmmsExpenseCenter) || migrateExpenseCenterFromDMLSS(cmmsExpenseCenter)) {
            fillRealPropertyFunding(cmmsExpenseCenter);
        }
    }

    private void validateCmmsExpenseCenterAndChangeDefaultIfNeeded(CmmsExpenseCenter cmmsExpenseCenter) {
        CmmsExpenseCenterValidator.validate(cmmsExpenseCenter);
        List<CmmsExpenseCenter> expenseCentersForOrganizationAndFiscalYear =
                microservice.getCmmsExpenseCentersByOrganizationAndFiscalYear(cmmsExpenseCenter.managedByNodeRef.getId(), cmmsExpenseCenter.fiscalYear);
        CmmsExpenseCenterValidator.validateUnique(cmmsExpenseCenter, expenseCentersForOrganizationAndFiscalYear);
        changeDefaultCmmsExpenseCenterIfNeeded(cmmsExpenseCenter, expenseCentersForOrganizationAndFiscalYear);
    }

    private void changeDefaultCmmsExpenseCenterIfNeeded(CmmsExpenseCenter cmmsExpenseCenter, List<CmmsExpenseCenter> expenseCentersForOrganizationAndFiscalYear) {
        Optional<CmmsExpenseCenter> defaultExpenseCenterOptional = expenseCentersForOrganizationAndFiscalYear.stream()
                .filter(expenseCenter -> !Objects.equals(cmmsExpenseCenter.getId(), expenseCenter.getId()))
                .filter(expenseCenter -> expenseCenter.isDefault).findFirst();
        if (defaultExpenseCenterOptional.isPresent()) {
            if (cmmsExpenseCenter.isDefault) {
                CmmsExpenseCenter defaultExpenseCenter = defaultExpenseCenterOptional.get();
                defaultExpenseCenter.isDefault = false;
                microservice.updateCmmsExpenseCenter(defaultExpenseCenter);
            }
        } else {
            cmmsExpenseCenter.isDefault = true;
        }
    }

    public CmmsExpenseCenter getDefaultCmmsExpenseCenter(String maximoSourceDodaac, String fiscalYear) {
        return microservice.getDefaultCmmsExpenseCenter(maximoSourceDodaac, fiscalYear);
    }

    public void deleteCmmsExpenseCenter(String id) {
        CmmsExpenseCenter cmmsExpenseCenter = microservice.getCmmsExpenseCenterById(id);
        if (cmmsExpenseCenter == null) {
            throw new ValidationException("External CMMS Expense Center not found");
        }
        microservice.deleteCmmsExpenseCenter(id);
    }

    public List<CmmsExpenseCenterRef> getAvailableCmmsExpenseCenterRefs(String workOrderId, String fiscalYear) {
        return microservice.getAvailableCmmsExpenseCenterRefs(workOrderId, fiscalYear);
    }

    public WorkOrder saveCmmsExpenseCenter(WorkOrder workOrder) {
        validateAllowedToEditWorkOrder(workOrder.getId());
        return microservice.saveCmmsExpenseCenter(workOrder);
    }

    public List<Configuration> getAllConfigurations() {
        return microservice.getAllConfigurations();
    }

    public Configuration addUpdateConfiguration(Configuration configuration) {
        return microservice.addUpdateConfiguration(configuration);
    }

    public Configuration getConfiguration(String id) {
        return microservice.getConfiguration(id);
    }

    public Configuration getConfigurationByName(String name) {
        return microservice.getConfigurationByName(name);
    }

    public List<FloorPlanLegendEntry> getDrawingLegend(String floorId, String legendType) {
        return drawingService.getDrawingLegend(floorId, legendType);
    }

    public List<FloorPlanLayer> getFloorPlanLayers() {
        return drawingService.getFloorPlanLayers();
    }

    public List<GraphicalSearchRecord> getGraphicalSearchRecordsByRoomIds(List<String> roomIds) {
        return drawingService.getGraphicalSearchRecordsByRoomIds(roomIds);
    }

    public Floor getFloorById(String id) {
        return drawingService.getFloorById(id);
    }

    public RoomMetadata getRoomMetadataByRoomNumber(String facilityId, String identifier) {
        return drawingService.getRoomMetadataByRoomNumber(facilityId, identifier);
    }

    public RoomRelatedRecordCounts getRelatedRecordCountsByRoomNumber(String facilityId, String identifier) {
        return drawingService.getRelatedRecordCountsByRoomNumber(facilityId, identifier);
    }

    public boolean isAllowedToEditWorkOrder(String id) {
        WorkOrder workOrder = microservice.findById(id);
        return isAllowedToEditWorkOrder(workOrder);
    }

    private void validateAllowedToEditWorkOrder(String id) {
        WorkOrder workOrder = microservice.findById(id);
        if (workOrder == null) {
            throw new ApplicationException(String.format("Work Order %s does not exist", id));
        }
        validateAllowedToEditWorkOrder(workOrder);
    }

    private void validateCanSendToMaximo() {
        if (!checkIfMaximoEnabled()) {
            throw new ApplicationException("Cannot send to Maximo.");
        }
    }

    private void validateAllowedToEditWorkOrder(WorkOrder workOrder) {
        if (!isAllowedToEditWorkOrder(workOrder)) {
            throw new ApplicationException("The work order cannot be updated.");
        }
    }

    private boolean isAllowedToEditWorkOrder(WorkOrder workOrder) {
        return (!isWorkOrderReviewed(workOrder) && !"CLOSED".equals(workOrder.dmlssWorkRequestState)) || hasRoleFinalAcceptanceManager();
    }

    private void validateAllowedToCommentAndNote(String id) {
        WorkOrder workOrder = microservice.findById(id);

        if (!isAllowedToCommentAndNote(workOrder)) {
            throw new ApplicationException("The work order cannot be updated.");
        }
    }

    private void validateAllowedToModifyComment(Comment comment) {
        if (comment != null && (Objects.equals(comment.step, EWorkflowStepName.QUALITY_CONTROL.displayText)
                || Objects.equals(comment.step, EWorkflowStepName.QUALITY_ASSURANCE.displayText))) {
            throw new ApplicationException("The work order comment cannot be updated.");
        }
    }

    private boolean isAllowedToCommentAndNote(WorkOrder workOrder) {
        return !isWorkOrderClosed(workOrder) || hasRoleFinalAcceptanceManager();
    }

    private boolean hasRoleFinalAcceptanceManager() {
        boolean hasRoleFinalAcceptanceManager = false;

        CurrentUser currentUser = this.currentUserBT.getCurrentUser();

        for (RoleRef roleRef : currentUser.profile.roleRefs) {
            if (roleRef.getId().equals(ROLE_FINAL_ACCEPTANCE_MANAGER)) {
                hasRoleFinalAcceptanceManager = true;
                break;
            }
        }

        return hasRoleFinalAcceptanceManager;
    }

    private boolean isWorkOrderReviewed(WorkOrder workOrder) {
        return workOrder.workflowState != null
                && workOrder.workflowState.currentStep != null
                && workOrder.workflowState.currentStep.workflowStepDefinition != null
                && (workOrder.workflowState.currentStep.workflowStepDefinition.isEndOfWorkflow
                || EWorkflowStepName.QUALITY_ASSURANCE.displayText.equals(workOrder.workflowState.currentStep.workflowStepDefinition.name)
                || EWorkflowStepName.QUALITY_CONTROL.displayText.equals(workOrder.workflowState.currentStep.workflowStepDefinition.name)
                || EWorkflowStepName.FINAL_ACCEPTANCE.displayText.equals(workOrder.workflowState.currentStep.workflowStepDefinition.name));
    }

    private boolean isWorkOrderClosed(WorkOrder workOrder) {
        return workOrder.workflowState != null
                && workOrder.workflowState.currentStep != null
                && workOrder.workflowState.currentStep.workflowStepDefinition != null
                && workOrder.workflowState.currentStep.workflowStepDefinition.isEndOfWorkflow;
    }

    public WorkOrder approveRequest(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workflowService.approveRequest(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.APPROVE_WORK.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder requestCancel(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workflowService.requestCancel(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.REQUEST_CANCEL.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder approveCancel(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workflowService.approveCancel(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.CANCEL_WORK.displayText);
        return microservice.findById(workOrder.getId());
    }

    public WorkOrder cancelServiceRequest(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workOrder.newComment = workOrderWorkItem.newComment;
        workflowService.cancelServiceRequest(workOrder, currentUserBT.getCurrentUser());
        sendServiceRequestEmailNotification(workOrder, EWorkflowActionName.CANCEL_SERVICE_REQUEST.displayText);
        return microservice.findById(workOrder.getId());
    }

    public List<ServiceRequest> getServiceRequests(ServiceRequestSearchCriteria searchCriteria) {
        return microservice.getServiceRequests(searchCriteria);
    }

    public WorkOrder cloneServiceRequest(String id) {
        WorkOrder workOrder = microservice.cloneServiceRequest(id);
        workOrder.requesterName = currentUserBT.getCurrentUser().profile.firstName + " " +
                currentUserBT.getCurrentUser().profile.lastName;
        List<PhoneNumber> phoneNumbers = currentUserBT.getCurrentUser().profile.phoneNumbers;
        if (phoneNumbers != null && !phoneNumbers.isEmpty()) {
            workOrder.requesterContactNumber = phoneNumbers.get(0).value;
        }
        return workOrder;
    }

    public WorkOrder updateServiceRequestLocation(WorkOrder workOrder) {
        serviceRequestLocationValidator.validate(workOrder);
        return microservice.updateServiceRequestLocation(workOrder);
    }

    public WorkOrder updateServiceRequestDetails(WorkOrder workOrder) {
        serviceRequestDetailValidator.validate(workOrder);
        return microservice.updateServiceRequestDetails(workOrder);
    }

    public WorkOrder createServiceRequest(WorkOrder workOrder) {
        serviceRequestDetailValidator.validate(workOrder);
        serviceRequestLocationValidator.validate(workOrder);
        setQualityFields(workOrder);
        workOrder.createdByRef = currentUserBT.getCurrentUser().profile.getRef();
        workOrder.managedByOrganizationRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        WorkOrder newWorkOrder = microservice.createServiceRequest(workOrder);
        workflowService.startAction(newWorkOrder, EWorkflowName.STANDARD_SERVICE_REQUEST.displayText, EWorkflowStepName.SUBMITTED.position, currentUserBT.getCurrentUser().profile.managedByNodeRef);
        return newWorkOrder;
    }

    public List<String> getSurveyRating() {
        return ERating.getFriendlyNames();
    }

    public WorkOrder updateWorkOrderSurvey(String workOrderId, WorkOrderSurvey survey) {
        validateSurveyHasRatingAndScore(survey);
        return microservice.updateWorkOrderSurvey(workOrderId, survey);
    }

    public WorkOrder addSurveyComment(String id, Comment comment) {
        WorkOrder workOrder = microservice.findById(id);
        validateSurveyHasRatingAndScore(workOrder.workOrderSurvey);
        return microservice.addSurveyComment(id, comment);
    }

    public WorkOrder removeSurveyComment(String id, Comment comment) {
        return microservice.removeSurveyComment(id, comment);
    }

    public WorkOrder saveSurveyComment(String id, Comment comment) {
        WorkOrder workOrder = microservice.findById(id);
        validateSurveyHasRatingAndScore(workOrder.workOrderSurvey);
        return microservice.saveSurveyComment(id, comment);
    }

    private void validateSurveyHasRatingAndScore(@NotNull WorkOrderSurvey survey) {
        if (survey.rating == null && survey.score == null) {
            throw new ApplicationException("The survey must have a rating and score");
        }
    }


    public List<RealPropertyFundingNodeSummary> getProjectFundingNodeSummaries(String organizationNodeId) {
        if (StringUtil.isEmptyOrNull(organizationNodeId)) {
            throw new ApplicationException("Organization node Id must be passed");
        }

        List<RealPropertyFundingNodeSummary> projectNodeSummaries = new ArrayList<>();
        List<FundingNodeDTO> projectNodes = financeAdminService.getMemorandumFunds(organizationNodeId);
        if (!ListUtil.isEmpty(projectNodes)) {
            projectNodeSummaries = projectNodes.stream().map(fundingNodeDTO -> new RealPropertyFundingNodeSummary(fundingNodeDTO.fundingNodeRef)).collect(Collectors.toList());
        }

        return projectNodeSummaries;
    }

    public List<RealPropertyFundingNodeSummary> getExpenseFundingNodeSummaries(String projectFundingNodeId) {
        if (StringUtil.isEmptyOrNull(projectFundingNodeId)) {
            throw new ApplicationException("Project funding node Id must be passed");
        }

        ProcessingBalance projectFundingPB = financeAdminService.getFundingNodeById(projectFundingNodeId);
        List<RealPropertyFundingNodeSummary> expenseNodeSummaries = new ArrayList<>();
        if (projectFundingPB != null && !ListUtil.isEmpty(projectFundingPB.fundingNode.children)) {
            Date now = new Date();
            expenseNodeSummaries = projectFundingPB.fundingNode.children.stream()
                    .filter(child -> child != null &&
                            (child.expiredDate == null || child.expiredDate.after(now))
                            && (child.retiredDate == null || child.retiredDate.after(now))
                            && (child.closedDate == null || child.closedDate.after(now)))
                    .map(child -> new RealPropertyFundingNodeSummary(child.getRef()))
                    .collect(Collectors.toList());
        }

        return expenseNodeSummaries;
    }

    public List<CommodityCodeRef> getCommodityCodeRefs(String organizationNodeId) {
        if (StringUtil.isEmptyOrNull(organizationNodeId)) {
            throw new ApplicationException("Organization node Id must be passed");
        }

        List<CommodityCodeRef> commodityCodeRefs = new ArrayList<>();
        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(organizationNodeId);
        if (financialSystem != null && !StringUtil.isEmptyOrNull(financialSystem.getId())) {
            commodityCodeRefs = financeReferenceDataService.getCommodityCodesBySystemAndUsage(financialSystem.getId(), ECommodityCodeUsageType.FM);

        }

        return commodityCodeRefs;
    }

    private Assignment getAssignment(@NotNull String workOrderId, @NotNull String assignmentId) {
        List<Assignment> assignmentsForWorkOrder = getAssignmentsForWorkOrder(workOrderId);
        Optional<Assignment> assignmentOptional = assignmentsForWorkOrder.stream().filter(assignment -> Objects.equals(assignment.assignmentId, assignmentId)).findFirst();
        return assignmentOptional.isPresent() ? assignmentOptional.get() : null;
    }

    public List<RealPropertyFundingNodeSummary> getActualCostProjectFundingNodeSummaries(@NotNull String workOrderId, @NotNull String assignmentId) {
        List<Assignment> assignmentsForWorkOrder = getAssignmentsForWorkOrder(workOrderId);
        Optional<Assignment> assignmentOptional = assignmentsForWorkOrder.stream().filter(assignment -> Objects.equals(assignment.assignmentId, assignmentId)).findFirst();
        Assignment assignment = assignmentOptional.get();
        if (assignment == null) {
            throw new ApplicationException("The assignment for this work order doesn't exist");
        }

        if (assignment.estimatedCosts == null ||
                (assignment.estimatedCosts.laborFunding == null && assignment.estimatedCosts.materialFunding == null && assignment.estimatedCosts.partsFunding == null)) {
            throw new ApplicationException("There is no any project Funding information for the assignment estimated costs");
        }

        List<RealPropertyFundingNodeSummary> projectNodeSummaries = new ArrayList<>();

        CostSummary costSummary = assignment.estimatedCosts;
        addProjectFundingNode(costSummary.laborFunding, projectNodeSummaries);
        addProjectFundingNode(costSummary.partsFunding, projectNodeSummaries);
        addProjectFundingNode(costSummary.materialFunding, projectNodeSummaries);

        return projectNodeSummaries;

    }

    private void addProjectFundingNode(RealPropertyFunding fundingNode, List<RealPropertyFundingNodeSummary> projectNodeSummaries) {
        if (fundingNode != null && fundingNode.projectFundingNodeRef != null && !StringUtil.isEmptyOrNull(fundingNode.projectFundingNodeRef.id)) {
            RealPropertyFundingNodeSummary projectFundingNode = new RealPropertyFundingNodeSummary(fundingNode.projectFundingNodeRef);
            if (projectNodeSummaries != null && !projectNodeSummaries.contains(projectFundingNode)) {
                projectNodeSummaries.add(projectFundingNode);
            }
        }
    }


    private void addExpenseFundingNode(RealPropertyFunding fundingNode, @NotNull String projectFundingNodeId, List<RealPropertyFundingNodeSummary> expenseNodeSummaries) {
        if (fundingNode != null && fundingNode.projectFundingNodeRef != null && projectFundingNodeId.equals(fundingNode.projectFundingNodeRef.id)) {
            RealPropertyFundingNodeSummary expenseFundingNode = new RealPropertyFundingNodeSummary(fundingNode.expenseFundingNodeRef);
            if (expenseNodeSummaries != null && !expenseNodeSummaries.contains(expenseFundingNode)) {
                expenseNodeSummaries.add(expenseFundingNode);
            }
        }
    }

    public List<RealPropertyFundingNodeSummary> getActualCostExpenseFundingNodeSummaries(@NotNull String workOrderId, @NotNull String assignmentId, @NotNull String projectFundingNodeId) {
        List<Assignment> assignmentsForWorkOrder = getAssignmentsForWorkOrder(workOrderId);
        Optional<Assignment> assignmentOptional = assignmentsForWorkOrder.stream().filter(assignment -> Objects.equals(assignment.assignmentId, assignmentId)).findFirst();
        Assignment assignment = assignmentOptional.get();
        if (assignment == null) {
            throw new ApplicationException("The assignment for this work order doesn't exist");
        }

        if (assignment.estimatedCosts == null ||
                (assignment.estimatedCosts.laborFunding == null && assignment.estimatedCosts.materialFunding == null && assignment.estimatedCosts.partsFunding == null)) {
            throw new ApplicationException("There is no any project Funding information for the assignment estimated costs");
        }

        List<RealPropertyFundingNodeSummary> expenseNodeSummaries = new ArrayList<>();
        CostSummary costSummary = assignment.estimatedCosts;
        addExpenseFundingNode(costSummary.laborFunding, projectFundingNodeId, expenseNodeSummaries);
        addExpenseFundingNode(costSummary.partsFunding, projectFundingNodeId, expenseNodeSummaries);
        addExpenseFundingNode(costSummary.materialFunding, projectFundingNodeId, expenseNodeSummaries);

        return expenseNodeSummaries;
    }
}
