package logicole.gateway.services.user;

import logicole.apis.user.IPermissionMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class PermissionMicroserviceClient extends MicroserviceClient<IPermissionMicroserviceApi> {
    public PermissionMicroserviceClient() {
        super(IPermissionMicroserviceApi.class, "logicole-user");
    }

    @Produces
    public IPermissionMicroserviceApi geIPermissionMicroserviceApi() {
        return createClient();
    }

}
