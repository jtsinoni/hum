package logicole.gateway.services.workorder;

import io.swagger.annotations.Api;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.maintenance.EMaintenanceDomain;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"CoreWorkOrder"})
@ApplicationScoped
@Path("/coreWorkOrder")
public class CoreWorkOrderRestApi extends ExternalRestApi<CoreWorkOrderService> {
    @GET
    @Path("/findById")
    public WorkOrder findById(@QueryParam("id") String id) {
        return service.findById(id);
    }

    @GET
    @Path("/getDomains")
    public List<String> getDomains() {
        return EMaintenanceDomain.getDisplayTextList();
    }

    @GET
    @Path("/getAssociateWorkOrders")
    public List<WorkOrder> getAssociateWorkOrders(@NotNull @QueryParam("workOrderId") String workOrderId) {
        return service.getAssociateWorkOrders(workOrderId);
    }

    @GET
    @Path("/getAssociateAndNonAssociateWorkOrders")
    public List<WorkOrder> getAssociateAndNonAssociateWorkOrders(@NotNull @QueryParam("workOrderId") String workOrderId) {
        return service.getAssociateAndNonAssociateWorkOrders(workOrderId);
    }

    @POST
    @Path("/updateAssociateWorkOrder")
    public WorkOrder updateAssociateWorkOrder(@NotNull WorkOrder workOrder) {
        return service.updateAssociateWorkOrder(workOrder);
    }

    @POST
    @Path("/getWorkOrders")
    public SearchResult<WorkOrder> getWorkOrders(SearchInput searchInput) {
        return service.getWorkOrders(searchInput);
    }
}
