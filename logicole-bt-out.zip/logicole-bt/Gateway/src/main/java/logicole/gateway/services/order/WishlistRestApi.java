package logicole.gateway.services.order;

import io.swagger.annotations.Api;
import logicole.common.datamodels.order.order.Wishlist;
import logicole.common.datamodels.order.order.WishlistItem;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import java.util.List;

@Api(tags = {"Wishlist"})
@ApplicationScoped
@Path("/wishlist")
public class WishlistRestApi extends ExternalRestApi<WishlistService> {

    @POST
    @Path("/addWishlist")
    public void addWishlist(Wishlist wishlist) {
        service.addWishlist(wishlist);
    }

    @POST
    @Path("/addItemToWishlist")
    public Wishlist addItemToWishlist(@QueryParam("listId") String listId,
                                      WishlistItem wishlistItem) {
        return service.addItemToWishlist(listId, wishlistItem);
    }

    @GET
    @Path("/getWishlistByName")
    public Wishlist getWishlistByName(@QueryParam("name") String name,
                                      @QueryParam("buyerIdentifier") String buyerIdentifier,
                                      @QueryParam("userIdentifier") String userIdentifier) {
        return service.getWishlistByName(name, buyerIdentifier, userIdentifier);
    }

    @GET
    @Path("/getWishlistByBuyer")
    public List<Wishlist> getWishlistByBuyer(@QueryParam("buyerIdentifier") String buyerIdentifier) {
        return service.getWishlistByBuyer(buyerIdentifier);
    }

    @GET
    @Path("/getWishLists")
    public List<Wishlist> getWishLists() {
        return service.getWishLists();
    }

    @POST
    @Path("/moveItemToWishlist")
    public Wishlist moveItemToWishlist(@QueryParam("listId") String listId,
                                       @QueryParam("newListId") String newListId,
                                       @QueryParam("customerItemSourcingId") String customerItemSourcingId) {
        return service.moveItemToWishlist(listId, newListId, customerItemSourcingId);
    }

    @POST
    @Path("/removeItemFromWishlist")
    public Wishlist removeItemFromWishlist(@QueryParam("listId") String listId,
                                           @QueryParam("customerItemSourcingId") String customerItemSourcingId) {
        return service.removeItemFromWishlist(listId, customerItemSourcingId);
    }

    @POST
    @Path("/saveWishlist")
    public Wishlist saveWishlist (Wishlist wishlist) {
        return service.saveWishlist(wishlist);
    }

}
