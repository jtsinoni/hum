package logicole.gateway.services.sso;

import io.swagger.annotations.Api;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Api(tags = {"Sso"})
@ApplicationScoped
@Path("/sso")
public class SsoRestApi extends ExternalRestApi<SsoService> {

    @GET
    @Path("/getTewlsUrl")
    @Produces(MediaType.TEXT_PLAIN)
    public String getTewlsUrl() {
        return service.getTewlsUrl();
    }

    @GET
    @Path("/getSapTewlsToken")
    @Produces({MediaType.TEXT_PLAIN})
    public String getSapTewlsToken() {
        return service.getSapTewlsToken();
    }
}
