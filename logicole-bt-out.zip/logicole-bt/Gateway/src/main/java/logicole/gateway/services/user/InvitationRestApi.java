package logicole.gateway.services.user;

import io.swagger.annotations.Api;
import logicole.common.datamodels.user.*;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Api(tags = {"Invitation"})
@ApplicationScoped
@Path("/invitation")
public class InvitationRestApi extends ExternalRestApi<InvitationService> {

    @POST
    @Path("/acceptGroupInvitation")
    public UserProfile acceptGroupInvitation(UserProfile userProfile) throws ApplicationException {
        return service.acceptGroupInvitation(userProfile);
    }

    @POST
    @Path("/acceptInvitationByPendingUser")
    public UserProfile acceptInvitationByPendingUser(UserProfile userProfile) throws ApplicationException {
        return service.acceptInvitationByPendingUser(userProfile);
    }

    @POST
    @Path("/approveInvitationByManager")
    public UserProfile approveInvitationByManager(UserProfile userProfile) {
        return service.approveInvitationByManager(userProfile);
    }

    @POST
    @Path("/createInvitation")
    public GroupInvitation createInvitation(GroupInvitation groupInvitation) throws ApplicationException {
        return service.createInvitation(groupInvitation);
    }

    @GET
    @Path("/denyGroupInvitationByManager")
    public UserProfile denyGroupInvitationByManager(@QueryParam("userProfileId") String userProfileId, @QueryParam("reason") String reason) throws ApplicationException {
        return service.denyGroupInvitationByManager(userProfileId, reason);
    }

    @GET
    @Path("/denyGroupInvitationByUser")
    public boolean denyGroupInvitationByUser(@QueryParam("userProfileId") String userProfileId) {
        return service.denyGroupInvitationByUser(userProfileId);
    }

    @GET
    @Path("/denySingleInvitationByAdmin")
    public UserProfile denySingleInvitationByAdmin(@QueryParam("invitationId") String invitationId, @QueryParam("reason") String reason) throws ApplicationException {
        return service.denySingleInvitationByAdmin(invitationId, reason);
    }

    @GET
    @Path("/denySingleInvitationByUser")
    public boolean denySingleInvitationByUser(@QueryParam("invitationId") String invitationId) {
        return service.denySingleInvitationByUser(invitationId);
    }

    @GET
    @Path("/getAllGroupInvitations")
    public List<GroupInvitation> getAllGroupInvitations() {
        return service.getAllGroupInvitations();
    }

    @GET
    @Path("/getGroupInvitation")
    public GroupInvitation getGroupInvitation(@QueryParam("invitationId") String invitationId) {
        return service.getGroupInvitation(invitationId);
    }

    @Produces(MediaType.TEXT_PLAIN)
    @GET
    @Path("/getGroupInvitationUrl")
    public String getGroupInvitationUrl(@QueryParam("invitationId") String invitationId) throws ApplicationException {
        return service.getGroupInvitationUrl(invitationId);
    }

    @GET
    @Path("/getProfilesByGroupInvitationId")
    public List<GroupInvitationProfileTableData> getProfilesByGroupInvitationId(@QueryParam("groupInvitationId") String groupInvitationId) {
        return service.getProfilesByGroupInvitationId(groupInvitationId);
    }

    @GET
    @Path("getProfileByInvitationId")
    public UserProfile getProfileByInvitationId(@QueryParam("invitationId") String invitationId) throws ApplicationException {
        return service.getProfileByInvitationId(invitationId);
    }

    @GET
    @Path("/resendInvitation")
    public UserProfile resendInvitation(@QueryParam("invitationId") String invitationId) throws ApplicationException {
        return service.resendInvitation(invitationId);
    }

    @POST
    @Path("/updateGroupInvitation")
    public GroupInvitation updateGroupInvitation(GroupInvitation groupInvitation) throws ApplicationException {
        return service.updateGroupInvitation(groupInvitation);
    }

    @POST
    @Path("/saveGroupInvitationAssignableRoles")
    public GroupInvitation saveGroupInvitationAssignableRoles(GroupInvitation groupInvitation) {
        return service.saveGroupInvitationAssignableRoles(groupInvitation);
    }

    @POST
    @Path("/updateProfileInvitationByAdmin")
    public UserProfile updateProfileInvitationByAdmin(AdminProfileUpdate profile) {
        return service.updateProfileInvitationByAdmin(profile);
    }

    @GET
    @Path("/getProfileByGroupInvitationId")
    public UserProfile getProfileByGroupInvitationId(@QueryParam("invitationId") String groupInvitationId) throws ApplicationException {
        return service.getProfileByGroupInvitationId(groupInvitationId);
    }

    @GET
    @Path("/sendUserInvitationDecisionEmail")
    public Boolean sendUserInvitationDecisionEmail(@QueryParam("userProfileId") String userProfileId, @QueryParam("isSingleInvite") boolean isSingleInvite) throws ApplicationException {
        return service.sendUserInvitationDecisionEmail(userProfileId, isSingleInvite);
    }

    @GET
    @Path("/sendActivatedByManagerEmail")
    public Boolean sendActivatedByManagerEmail(@QueryParam("userProfileId") String userProfileId) throws ApplicationException {
        return service.sendActivatedByManagerEmail(userProfileId);
    }

    @GET
    @Path("/sendManagerDeniedEmail")
    public Boolean sendManagerDeniedEmail(@QueryParam("userProfileId") String userProfileId) throws ApplicationException {
        return service.sendManagerDeniedEmail(userProfileId);
    }

    @GET
    @Path("/sendManagerApprovedEmail")
    public Boolean sendManagerApprovedEmail(@QueryParam("userProfileId") String userProfileId) throws ApplicationException {
        return service.sendManagerApprovedEmail(userProfileId);
    }

    @GET
    @Path("/getInvitationDashboardStats")
    public InvitationDashboardInfo getInvitationDashboardStats() throws ApplicationException {

        return service.getInvitationDashboardStats();
    }


}
