package logicole.gateway.services.abi;

import io.swagger.annotations.*;
import logicole.common.datamodels.abi.ABiCatalogRecordRef;
import logicole.common.datamodels.abi.staging.*;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.filemanager.FileRef;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi/staging")
public class AbiStagingRestApi extends ExternalRestApi<AbiStagingService> {

    @Inject
    private MultiPartFormUtil uploadUtil;

    @GET
    @Path("/getStatistics")
    public AbiCatalogStatistics getStatistics() {
        return service.getStatistics();
    }

    @GET
    @Path("/searchRecords")
    public List<AbiCatalogStaging> searchRecords(
            @QueryParam("mode") String mode, @QueryParam("matchOption") String matchOption, @QueryParam("filterData") String filterData) throws ApplicationException {
        return service.searchRecords(mode, matchOption, filterData);
    }

    @POST
    @Path("/validateRecord")
    public FieldValidationStatus validateRecord(AbiCatalogStaging record) {
        return service.validateRecord(record);
    }

    @POST
    @Path("/requestApprovalForRecord")
    public ApprovalRequestResult requestApprovalForRecord(AbiCatalogStaging recordRequestingApproval) {
        return service.requestApprovalForRecord(recordRequestingApproval);
    }

    @POST
    @Path("/approveRecord")
    public ApprovalResult approveRecord(AbiCatalogStaging recordToApprove) {
        return service.approveRecord(recordToApprove);
    }

    @POST
    @Path("/updateRecord")
    public AbiCatalogStaging updateRecord(AbiCatalogStaging updatedRecord) throws ValidationException {
        return service.updateStagingRecord(updatedRecord);
    }

    @GET
    @Path("/markRecordIncomplete")
    public AbiCatalogStaging markRecordIncomplete(@QueryParam("id") String id) {
        return service.markRecordIncomplete(id);
    }

    @POST
    @Path("/deleteRecord")
    public Integer deleteRecord(AbiCatalogStaging recordToDelete) {
        return service.deleteRecord(recordToDelete);
    }

    @GET
    @Path("/getStagingRequests")
    public List<StagingRequestQueueRecord> getStagingRequests(@QueryParam("showSubtasks") Boolean showSubtasks) {
        return service.getStagingRequests(showSubtasks);
    }

    @GET
    @Path("/getDownloadFiles")
    public List<AbiDownloadFile> getDownloadFiles() {
        return service.getDownloadFiles();
    }

    @GET
    @Path("/downloadABiFile")
    public Response downloadABiFile(@QueryParam("id") String id) throws IOException, ApplicationException {
        return service.downloadABiFile(id);
    }

    @GET
    @Path("/generateGHXItemMasterSpreadsheet")
    public StagingRequestResponse generateGHXItemMasterSpreadsheet() {
        return service.generateGHXItemMasterSpreadsheet();
    }

    @GET
    @Path("/generateMmcExceptionReport")
    public StagingRequestResponse generateMmcExceptionReport() {
        return service.generateMmcExceptionReport();
    }

    @GET
    @Path("/applyStagingChangesToProduction")
    public StagingRequestResponse applyStagingChangesToProduction(@QueryParam("startIndex") Integer startIndex,
                                                                  @QueryParam("finalEndIndex") Integer finalEndIndex,
                                                                  @QueryParam("chunkSize") Integer chunkSize) {
        return service.applyStagingChangesToProduction(startIndex, finalEndIndex, chunkSize);
    }

    @GET
    @Path("/updateCommodityTypeAttributes")
    public StagingRequestResponse updateCommodityTypeAttributes() {
        return service.updateCommodityTypeAttributes();
    }

    @GET
    @Path("/updateGenericIdUnspscMapAttributes")
    public StagingRequestResponse updateGenericIdUnspscMapAttributes() {
        return service.updateGenericIdUnspscMapAttributes();
    }

    @GET
    @Path("/updateUnspscCriticalItemCategoryMapAttributes")
    public StagingRequestResponse updateUnspscCriticalItemCategoryMapAttributes() {
        return service.updateUnspscCriticalItemCategoryMapAttributes();
    }

    @GET
    @Path("/applyNsnsToPackagingRecords")
    public StagingRequestResponse applyNsnsToPackagingRecords() {
        return service.applyNsnsToPackagingRecords();
    }

    @GET
    @Path("/updateStagingImplantAttributes")
    public StagingRequestResponse updateStagingImplantAttributes() {
        return service.updateStagingImplantAttributes();
    }

    @GET
    @Path("/generateStagingEditingSpreadsheet")
    public StagingRequestResponse generateStagingEditingSpreadsheet(@QueryParam("mode") String mode,
                                                                    @QueryParam("matchOption") String matchOption,
                                                                    @QueryParam("filterData") String filterData) {
        return service.generateStagingEditingSpreadsheet(mode, matchOption, filterData);
    }

    @GET
    @Path("/generatePackagingWorksheet")
    public StagingRequestResponse generatePackagingWorksheet(@QueryParam("mode") String mode,
                                                             @QueryParam("matchOption") String matchOption,
                                                             @QueryParam("filterData") String filterData) {
        return service.generatePackagingWorksheet(mode, matchOption, filterData);
    }

    @GET
    @Path("/promoteApprovalCandidates")
    public StagingRequestResponse promoteApprovalCandidates(@QueryParam("catalogSource") String catalogSource) {
        return service.promoteApprovalCandidates(catalogSource);
    }

    @GET
    @Path("/applyCasingExceptions")
    public StagingRequestResponse applyCasingExceptions() {
        return service.applyCasingExceptions();
    }
    
    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadFile(
            @ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form)
            throws ApplicationException {
        InputStream inputStream;
        byte[] content;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new FatalProcessingException(
                    "Was not able to extract file from request " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxUploadSize();

        if (content.length > maxUploadSize) {
            throw new FatalProcessingException(
                    "Uploaded file size exceeds server max POST Size value  of " + maxUploadSize
                            + " bytes");
        }

        return service.uploadFile(content, uploadedFileName);
    }

    @GET
    @Path("/getMaxUploadSize")
    public Integer getMaxUploadSize() throws ApplicationException {
        return service.getMaxUploadSize();
    }

    @POST
    @Path("/getRecordsInIdList")
    public List<AbiCatalogStaging> getRecordsInIdList(@QueryParam("searchType") ESearchAndReplaceType searchType,
                                                      List<String> idList) {
        return service.getRecordsInIdList(searchType, idList);
    }

    @GET
    @Path("/searchForWordInStagingRecords")
    public List<AbiCatalogStaging> searchForWordInStagingRecords(@QueryParam("searchType") ESearchAndReplaceType searchType,
                                                                 @QueryParam("searchString") String searchString,
                                                                 @QueryParam("matchEntireAttribute") Boolean matchEntireAttribute) {
        return service.searchForWordInStagingRecords(searchType, searchString, matchEntireAttribute);
    }

    @GET
    @Path("/replaceWordInStagingRecords")
    public List<String> replaceWordInStagingRecords(@QueryParam("searchType") ESearchAndReplaceType searchType,
                                                    @QueryParam("oldString") String oldString,
                                                    @QueryParam("newString") String newString,
                                                    @QueryParam("matchEntireAttribute") Boolean matchEntireAttribute) throws ApplicationException {
        return service.replaceWordInStagingRecords(searchType, oldString, newString, matchEntireAttribute);
    }

    @GET
    @Path("/generateSiteCatalogNoABiRecordWorksheet")
    public StagingRequestResponse generateSiteCatalogNoABiRecordWorksheet(@QueryParam("minimumGroupSize") Integer minimumGroupSize,
                                                                          @QueryParam("minimumOrderSum") Integer minimumOrderSum,
                                                                          @QueryParam("mmcExists") Boolean mmcExists,
                                                                          @QueryParam("manufacturerNameRange") String manufacturerNameRange) {
        return service.generateSiteCatalogNoABiRecordWorksheet(minimumGroupSize, minimumOrderSum, mmcExists, manufacturerNameRange);
    }

    @POST
    @Path("/getFileRefsByIds")
    public List<FileRef> getFileRefsByIds(List<String> fileIds) {
        return service.getFileRefsByIds(fileIds);
    }

    @GET
    @Path("/deleteStagingRequest")
    public boolean deleteStagingRequest(@QueryParam("stagingRequestId") String stagingRequestId) {
        return service.deleteStagingRequest(stagingRequestId);
    }

    @GET
    @Path("/deleteABiFile")
    public Integer deleteABiFile(@QueryParam("id") String id) throws IOException, ApplicationException {
        return service.deleteABiFile(id);
    }

    @GET
    @Path("/getPriorStagingRequestCount")
    public Long getPriorStagingRequestCount(@QueryParam("olderThanDays") Integer olderThanDays) {
        return service.getPriorStagingRequestCount(olderThanDays);
    }

    @GET
    @Path("/deletePriorStagingRequests")
    public Long deletePriorStagingRequests(@QueryParam("olderThanDays") Integer olderThanDays) {
        return service.deletePriorStagingRequests(olderThanDays);
    }

    @GET
    @Path("/getInUseRecordsCount")
    public Long getInUseRecordsCount() {
        return service.getInUseRecordsCount();
    }

    @GET
    @Path("/getAbiStagingCatalogRecordRefListforCriticalItems")
    public List<ABiCatalogRecordRef> getAbiStagingCatalogRecordRefListforCriticalItems(){
        return service.getAbiStagingCatalogRecordRefListforCriticalItems();
    }

    @GET
    @Path("/applyCasingAndSubstitutionRules")
    @Produces(MediaType.TEXT_PLAIN)
    public String applyCasingAndSubstitutionRules(@QueryParam("text") String text) {
        return service.applyCasingAndSubstitutionRules(text);
    }
}
