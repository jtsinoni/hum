package logicole.gateway.services.catalog;

import io.swagger.annotations.Api;
import logicole.common.datamodels.catalog.update.ChangeHistory;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"CatalogChangeHistory"})
@ApplicationScoped
@Path("/catalogChangeHistory")
public class CatalogChangeHistoryRestApi extends ExternalRestApi<CatalogChangeHistoryService> {

    @GET
    @Path("/getRecordCount")
    public Long getRecordCount(@QueryParam("changedRecordId") String changedRecordId) { return service.getRecordCount(changedRecordId); }

    @GET
    @Path("/getHistoryRecords")
    public List<ChangeHistory> getHistoryRecords(@QueryParam("changedRecordId") String changedRecordId,
                                                 @QueryParam("start") Long start,
                                                 @QueryParam("maxRecords") Long maxRecords) {
        return service.getHistoryRecords(changedRecordId, start, maxRecords);
    }

    @GET
    @Path("/getAllHistoryRecords")
    public List<ChangeHistory> getAllHistoryRecords(@QueryParam("changedRecordId") String changedRecordId) {
        return service.getAllHistoryRecords(changedRecordId);
    }

    @POST
    @Path("/addHistory")
    public ChangeHistory addHistory(ChangeHistory newHistoryRecord) {
        return service.addHistory(newHistoryRecord);
    }
}

