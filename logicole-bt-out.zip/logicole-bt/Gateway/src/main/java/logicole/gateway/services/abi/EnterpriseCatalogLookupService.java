package logicole.gateway.services.abi;

import logicole.apis.abi.IEnterpriseCatalogLookupMicroserviceApi;
import logicole.common.datamodels.abi.Business;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;


@ApplicationScoped
public class EnterpriseCatalogLookupService extends BaseGatewayService<IEnterpriseCatalogLookupMicroserviceApi> {

    public EnterpriseCatalogLookupService() {
        super("Abi");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public Business getBusinessByName(String manufacturerName) {
        return microservice.getBusinessByName(manufacturerName);
    }

    public String getProvisionalEPI(String manufacturerName, String manufacturerPartNumber) {
        return microservice.getProvisionalEPI(manufacturerName,manufacturerPartNumber);
    }
}
