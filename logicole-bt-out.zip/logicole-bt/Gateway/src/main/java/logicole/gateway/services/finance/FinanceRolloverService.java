package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceRolloverMicroserviceApi;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class FinanceRolloverService extends BaseGatewayService<IFinanceRolloverMicroserviceApi> {

    public FinanceRolloverService() {
        super("FinanceRollover");
    }

    public void rolloverOrg(String orgId) {

        microservice.rolloverOrg(orgId);
    }
}
