package logicole.gateway.services.catalog;

import logicole.apis.catalog.ICatalogChangeHistoryMicroserviceApi;
import logicole.common.datamodels.catalog.Catalog;
import logicole.common.datamodels.catalog.update.ChangeHistory;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemChangeHistoryService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.*;

@ApplicationScoped
public class CatalogChangeHistoryService extends BaseGatewayService<ICatalogChangeHistoryMicroserviceApi> {

    @Inject
    private CatalogService catalogService;
    @Inject
    private ItemChangeHistoryService itemChangeHistoryService;

    public CatalogChangeHistoryService() {
        super("Catalog");
    }

    public Long getRecordCount(String changedRecordId) {
        return microservice.getRecordCount(changedRecordId);
    }

    public List<ChangeHistory> getHistoryRecords(String changedRecordId,
                                                 Long start,
                                                 Long maxRecords) {
        return microservice.getHistoryRecords(changedRecordId, start, maxRecords);
    }

    public List<ChangeHistory> getAllHistoryRecords(String changedRecordId) {
        Catalog catalog = catalogService.getById(changedRecordId);
        List<ChangeHistory> changeList = new ArrayList();
        if (catalog != null && catalog.itemRef != null && catalog.itemRef.id != null) {
            changeList.addAll(itemChangeHistoryService.getAllHistoryRecords(catalog.itemRef.id));
        }
        changeList.addAll(microservice.getAllHistoryRecords(changedRecordId));

        changeList.sort(Comparator.comparing(changeHistory -> changeHistory._metadata.createdDate));
        Collections.reverse(changeList);
        return changeList;
    }

    public ChangeHistory addHistory(ChangeHistory newHistoryRecord) {
        return microservice.addHistory(newHistoryRecord);
    }
}
