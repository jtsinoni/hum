package logicole.gateway.services.organization;

import io.swagger.annotations.Api;
import logicole.common.datamodels.general.EHDataType;
import logicole.common.datamodels.general.HDataType;
import logicole.common.datamodels.general.HierData;
import logicole.common.datamodels.user.RoleRef;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"OrganizationHierData"})
@ApplicationScoped
@Path("/organizationHierdata")
public class OrganizationHierDataRestApi extends ExternalRestApi<OrganizationHierDataService> {
    @POST
    @Path("/setHierDataRoleRefs")
    public void setHierDataRoleRefs(@QueryParam("nodeId") String nodeId, @QueryParam("dataType") EHDataType dataType, List<RoleRef> roleRefs) {
        service.<RoleRef>setHierDataValue(nodeId, dataType, roleRefs);
    }

    @POST
    @Path("/setHierDataRawValue")
    public void setHierDataRawValue(@QueryParam("nodeId") String nodeId, @QueryParam("dataType") EHDataType dataType, String jsonValue) {
        service.setHierDataRawValue(nodeId, dataType, jsonValue);
    }

    @GET
    @Path("/clearData")
    public void clearData(@QueryParam("nodeId") String nodeId, @QueryParam("dataType") EHDataType dataType) {
        service.clearData(nodeId, dataType);
    }

    @GET
    @Path("/getHierData")
    public HierData getHierData(@QueryParam("nodeId") String nodeId, @QueryParam("dataType") EHDataType dataType) {
        return service.getHierData(nodeId, dataType);
    }

    @GET
    @Path("/getHierDataRawValue")
    public String getHierDataRawValue(@QueryParam("nodeId") String nodeId, @QueryParam("dataType") EHDataType dataType) {
        return service.getHierDataRawValue(nodeId, dataType);
    }

//    @GET
//    @Path("/getHierDataRoleRef")
//    public RoleRef getHierDataRoleRef(@QueryParam("nodeId") String nodeId, @QueryParam("dataType") EHDataType dataType) {
//        return service.<RoleRef>getHierDataValue(nodeId, dataType);
//    }

    @GET
    @Path("/removeHierData")
    public void removeHierData(@QueryParam("nodeId") String nodeId, @QueryParam("dataType") EHDataType dataType) {
        service.removeHierData(nodeId, dataType);
    }

    @GET
    @Path("/getHDataTypes")
    public List<HDataType> getHDataTypes() {
        return service.getHDataTypes();
    }

}
