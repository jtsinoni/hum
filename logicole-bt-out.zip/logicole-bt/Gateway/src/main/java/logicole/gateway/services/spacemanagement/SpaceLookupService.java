package logicole.gateway.services.spacemanagement;

import logicole.apis.space.ILookupMicroserviceApi;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.datamodels.space.lookupdata.*;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.organization.OrganizationService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@ApplicationScoped
public class SpaceLookupService extends BaseGatewayService<ILookupMicroserviceApi> {
    @Inject
    OrganizationService organizationService;

    public SpaceLookupService() {
        super("Lookup");
    }

    public AttributeType getAttributeTypeById(String id) {
        return microservice.getAttributeTypeById(id);
    }

    public List<String> getAttributeTypeList() {
        return microservice.getAttributeTypeList();
    }

    public List<AttributeType> getAttributeTypeByType(String type) {
        return microservice.getAttributeTypeByType(type);
    }

    public List<AttributeType> getAllAttributeType() {
        return microservice.getAllAttributeType();
    }

    public AttributeType createNewAttributeType(AttributeType attributeType) {
        List<AttributeType> listOfAttributeTypes = microservice.getAllAttributeType();
        AttributeType foundingAttributeType = null;
        for(AttributeType at: listOfAttributeTypes) {
            if(at.getId().equals(attributeType.getId())) {
                foundingAttributeType = at;
            }
        }
        if(foundingAttributeType == null) {
            attributeType.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.createNewAttributeType(attributeType);
        } else {
            throw new ApplicationException("Attribute Type already exists");
        }
    }

    public AttributeType saveAttributeType(AttributeType attributeType) {
        AttributeType foundAttributeType = microservice.getAttributeTypeById(attributeType.getId());
        if(foundAttributeType == null) {
            throw new ApplicationException("Attribute type does not exist");
        } else {
            return microservice.saveAttributeType(attributeType);
        }
    }

    public boolean deleteAttributeType(String id) {
        AttributeType foundAttributeType = getAttributeTypeById(id);
        if(foundAttributeType == null) {
            throw new ApplicationException("Attribute Type does not exist");
        } else {
            return microservice.deleteAttributeType(id);
        }
    }

    public CleaningRequirement getCleaningRequirementById(String id) {
        return microservice.getCleaningRequirementById(id);
    }

    public List<CleaningRequirement> getAllCleaningRequirement() {
        return microservice.getAllCleaningRequirement();
    }

    public CleaningRequirement createNewCleaningRequirement(CleaningRequirement cleaningRequirement) {
        CleaningRequirement foundCleaningRequirement = microservice.getCleaningRequirementByCode(cleaningRequirement.code);
        if (foundCleaningRequirement == null) {
            cleaningRequirement.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.createNewCleaningRequirement(cleaningRequirement);
        } else {
            throw new ApplicationException("Cleaning Requirement already exists");
        }
    }

    public CleaningRequirement saveCleaningRequirement(CleaningRequirement cleaningRequirement) {
        CleaningRequirement foundCleaningRequirement = microservice.getCleaningRequirementById(cleaningRequirement.getId());
        if (foundCleaningRequirement == null) {
            throw new ApplicationException("Cleaning Requirement does not exist");
        } else {
            return microservice.saveCleaningRequirement(cleaningRequirement);
        }
    }

    public boolean deleteCleaningRequirement(String id) {
        CleaningRequirement foundCleaningRequirement = microservice.getCleaningRequirementById(id);
        if (foundCleaningRequirement == null) {
            throw new ApplicationException("Cleaning Requirement does not exist");
        } else {
            return microservice.deleteCleaningRequirement(id);
        }
    }

    public HazardType getHazardTypeById(String id) {
        return microservice.getHazardTypeById(id);
    }

    public List<HazardType> getAllHazardType() {
        return microservice.getAllHazardType();
    }

    public HazardType createNewHazardType(HazardType hazardType) {
        HazardType foundHazardType = microservice.getHazardTypeByName(hazardType.name);
        if (foundHazardType == null) {
            hazardType.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.createNewHazardType(hazardType);
        } else {
            throw new ApplicationException("Hazard Type already exists");
        }
    }

    public HazardType saveHazardType(HazardType hazardType) {
        HazardType foundHazardType = microservice.getHazardTypeById(hazardType.getId());
        if (foundHazardType == null) {
            throw new ApplicationException("Hazard Type does not exist");
        } else {
            return microservice.saveHazardType(hazardType);
        }
    }

    public boolean deleteHazardType(String id){
        HazardType foundHazardType = microservice.getHazardTypeById(id);
        if (foundHazardType == null) {
            throw new ApplicationException("Hazard Type does not exist");
        } else {
            return microservice.deleteHazardType(id);
        }
    }

    public List<String> getAllPhoneClass() {
        List<String> phoneClassList = new ArrayList<>();
        for (EPhoneClass phoneClass : EPhoneClass.values()) {
            phoneClassList.add(phoneClass.displayText);
        }
        return phoneClassList;
    }

    public SpaceType getRoomTypeById(String id) {
        return microservice.getRoomTypeById(id);
    }

    public SpaceType getRoomTypeBySubtypeCode(String subtypeCode) {
        return microservice.getRoomTypeBySubtypeCode(subtypeCode);
    }

    public List<SpaceType> getAllRoomType() {
        return microservice.getAllRoomType();
    }

    public SpaceType createNewRoomType(SpaceType spaceType) {
        SpaceType foundSpaceType = microservice.getRoomTypeByName(spaceType.name);
        if (foundSpaceType == null) {
            spaceType.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.createNewRoomType(spaceType);
        } else {
            throw new ApplicationException("Space Type already exists");
        }
    }

    public SpaceType saveRoomType(SpaceType spaceType) {
        SpaceType foundSpaceType = microservice.getRoomTypeById(spaceType.getId());
        if (foundSpaceType == null) {
            throw new ApplicationException("Space Type does not exist");
        } else {
            return microservice.saveRoomType(spaceType);
        }
    }

    public boolean deleteRoomType(String id)  {
        SpaceType foundSpaceType = microservice.getRoomTypeById(id);
        if (foundSpaceType == null) {
            throw new ApplicationException("Space Type does not exist");
        } else {
            return microservice.deleteRoomType(id);
        }
    }

    public List<String> getAllSpaceMeasurementUnits() {
        List<String> measurementUnitList = new ArrayList<>();
        for (EMeasurementUnit measurementUnit : EMeasurementUnit.values()) {
            measurementUnitList.add(measurementUnit.displayText);
        }
        return measurementUnitList;
    }

    public List<String> getAllSpaceFillPatterns() {
        List<String> fillPatternList = new ArrayList<>();
        for (EFillPattern fillPattern : EFillPattern.values()) {
            fillPatternList.add(fillPattern.displayText);
        }
        return fillPatternList;
    }

    public List<ZoneType> getAllZoneType() {
        return microservice.getAllZoneType();
    }

    public ZoneType getZoneTypeById(String id) {
        return microservice.getZoneTypeById(id);
    }

    public ZoneType createNewZoneType(ZoneType zoneType) {
        ZoneType foundZoneType = microservice.getZoneTypeByName(zoneType.name);
        if (foundZoneType == null) {
            zoneType.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.createNewZoneType(zoneType);
        } else {
            throw new ApplicationException("Zone Type already exists");
        }
    }

    public ZoneType saveZoneType(ZoneType zoneType) {
        ZoneType foundZoneType = microservice.getZoneTypeById(zoneType.getId());
        if (foundZoneType == null) {
            throw new ApplicationException("Zone Type does not exist");
        } else {
            return microservice.saveZoneType(zoneType);
        }
    }

    public boolean deleteZoneType(String id) {
        ZoneType foundZoneType = microservice.getZoneTypeById(id);
        if (foundZoneType == null) {
            throw new ApplicationException("Zone Type does not exist");
        } else {
            return microservice.deleteZoneType(id);
        }
    }

    public List<SpaceCode> getSpaceCodes() {
        List<SpaceCode> listOfSpaceCodes = new ArrayList<>();
        List<SpaceType> listOfSpaceTypes = getAllRoomType();

        for(SpaceType st : listOfSpaceTypes) {
            if(st.subtypes != null) {
                for (SpaceCode sc : st.subtypes) {
                   // listOfSpaceCodes.add(sc);
                    Collections.addAll(listOfSpaceCodes, sc);
                }
            }
        }

        return listOfSpaceCodes;
    }



}

