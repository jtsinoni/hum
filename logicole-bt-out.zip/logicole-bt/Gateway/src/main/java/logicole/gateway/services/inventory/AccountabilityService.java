package logicole.gateway.services.inventory;

import logicole.apis.inventory.IAccountabilityMicroserviceApi;
import logicole.common.datamodels.asset.classification.Accountability;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.output.AuthorizedNode;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.request.EBusinessEventType;
import logicole.common.datamodels.finance.request.FinanceItem;
import logicole.common.datamodels.finance.request.RequestGroup;
import logicole.common.datamodels.finance.response.CommonFinanceResponse;
import logicole.common.datamodels.inventory.*;
import logicole.common.datamodels.inventory.Return.InventoryReturn;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.order.OrderService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.finance.FinanceProcessingService;
import logicole.gateway.services.finance.FinanceAdminService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class AccountabilityService extends BaseGatewayService<IAccountabilityMicroserviceApi> {

    @Inject
    private OrderService orderService;

    @Inject
    private BuyerService buyerService;

    @Inject
    private OrganizationService organizationService;

    @Inject
    private FinanceProcessingService financeProcessingService;

    @Inject
    private FinanceAdminService financeAdminService;

    @Inject
    private InventoryService inventoryService;

    @Inject
    private LocationService locationService;

    public AccountabilityService() {
        super("Accountability");
    }

    public List<GainType> getGainTypes() {
        return microservice.getGainTypes();
    }

    public Integer recordGain(AccountabilityRecord accountabilityRecord) {
        return microservice.recordGain(accountabilityRecord);
    }

    public List<AccountabilityLog> getAccountabilityLogsByItemLocationId(String itemLocationId) {
        return microservice.getAccountabilityLogsByItemLocationId(itemLocationId);
    }

    public List<LossType> getLossTypes() {
        return microservice.getLossTypes();
    }

    public Integer recordLoss(AccountabilityRecord accountabilityRecord) {
        return microservice.recordLoss(accountabilityRecord);
    }


    public InventoryReturn recordCommercialReturn(AccountabilityRecord accountabilityRecord) {
        return microservice.recordCommercialReturn(accountabilityRecord);
    }

    public List<DestructionMethod> getDestructionMethods() {
        return microservice.getDestructionMethods();
    }

    public Integer recordDestruction(AccountabilityRecord accountabilityRecord) {
        return microservice.recordDestruction(accountabilityRecord);
    }

    public InventoryRecord transferQuantity(AccountabilityRecord accountabilityRecord) {
        return microservice.transferQuantity(accountabilityRecord);
    }

    public Integer recordCustomerReturn(AccountabilityRecord accountabilityRecord) {
        return microservice.recordCustomerReturn(accountabilityRecord);
    }

    public AccountabilityLog saveAccountabilityLog(AccountabilityLog accountabilityLog) {
        return microservice.saveAccountabilityLog(accountabilityLog);
    }

    public List<AccountabilityLog> saveAccountabilityLogs(List<AccountabilityLog> accountabilityLogs) {
        List<AccountabilityLog> accountabilityLogResults = new ArrayList<>();
        for(AccountabilityLog accountabilityLog : accountabilityLogs) {
            accountabilityLogResults.add(microservice.saveAccountabilityLog(accountabilityLog));
        }

        return accountabilityLogResults;
    }

    private String generateDocumentNumber(String nodeId) {
        String documentNumber = "";
        Buyer buyer = buyerService.getBuyerForNodeId(nodeId);

        if (buyer != null) {
            documentNumber = buyer.nodeRef.nodeIdentifier + orderService.getInternalReferenceId(buyer.managedByNodeRef.nodeIdentifier);
        }

        return documentNumber;
    }

    public List<OrganizationRef> getCustomerList(String nodeId) {
        List<OrganizationRef> customers = new ArrayList<>();
        List<Organization> customerOrgs;
        Organization org = organizationService.getOrganization(nodeId);
        customerOrgs = organizationService.getOrganizationChildren(org.getParentId());
        for (Organization organization : customerOrgs) {
            InventorySystem system = locationService.getInventorySystemByCurrentNodeId(organization.getId());
            if (!organization.getId().equalsIgnoreCase(nodeId) && system != null) {
                customers.add(organization.getRef());
            }
        }

        return customers;
    }

    public Integer issueNonRoutine(AccountabilityRecord accountabilityRecord) {
        Integer val = -1;
        accountabilityRecord.issuingCustomerDocNum = generateDocumentNumber(currentUserBT.getCurrentUser().profile.currentNodeRef.getId());
        accountabilityRecord.receivingCustomerDocNum = generateDocumentNumber(accountabilityRecord.returnCustomerNodeRef.getId());

        /*InventoryRecord issuingCustomerInvRecord = inventoryService.getInventoryRecordById(accountabilityRecord.inventoryRecordId);
        InventoryRecord receivingCustomerRecord = inventoryService.getRecordByOwnerAndProduct(accountabilityRecord.returnCustomerNodeRef.getId(),
                issuingCustomerInvRecord.itemRef.enterpriseProductIdentifier);
        if (receivingCustomerRecord == null) {
            throw new ApplicationException ("Need to create inventory record for receiving customer");
        } */
        AccountabilityRecordDTO accountabilityRecordDTO;
        accountabilityRecordDTO = microservice.issueNonRoutine(accountabilityRecord);

        if (accountabilityRecordDTO != null && accountabilityRecord.freeIssue.equals(Boolean.FALSE)) {
            AuthorizedNode defaultAuthorizedNode = financeAdminService.getDefaultAuthorizedNode(accountabilityRecord.returnCustomerNodeRef.getId());
                CommonFinanceRequest financeRequest = this.createFinanceRequest(accountabilityRecordDTO.receivingCustomerRecord, accountabilityRecord,
                        defaultAuthorizedNode.fundingNodeRef, accountabilityRecord.receivingCustomerDocNum, EBusinessEventType.ISSUE_NON_ROUTINE);
                CommonFinanceResponse financeResponse = financeProcessingService.processFinanceRequest(financeRequest);
                if (financeResponse.responseGroups.isEmpty()) {
                    throw new ApplicationException("There was an error with updating the funding.");
                } else {
                    microservice.saveAccountabilityLog(accountabilityRecordDTO.transferFromAccountabilityLog);

                    microservice.saveAccountabilityLog(accountabilityRecordDTO.transferToAccountabilityLog);
                    List<InventoryRecord> recordList = new ArrayList<>();
                    recordList.add(accountabilityRecordDTO.issuingCustomerRecord);
                    recordList.add(accountabilityRecordDTO.receivingCustomerRecord);
                    inventoryService.updateInventoryRecords(recordList);
                    val = 0;
                }
        } else if (accountabilityRecordDTO != null && accountabilityRecord.freeIssue.equals(Boolean.TRUE)) {
            microservice.saveAccountabilityLog(accountabilityRecordDTO.transferFromAccountabilityLog);

            microservice.saveAccountabilityLog(accountabilityRecordDTO.transferToAccountabilityLog);

            List<InventoryRecord> recordList = new ArrayList<>();
            recordList.add(accountabilityRecordDTO.issuingCustomerRecord);
            recordList.add(accountabilityRecordDTO.receivingCustomerRecord);
            inventoryService.updateInventoryRecords(recordList);
            val = 0;
        }

        return val;
    }

    private CommonFinanceRequest createFinanceRequest(InventoryRecord record, AccountabilityRecord accountabilityRecord,
                                                      FundingNodeRef fundingNodeRef, String receivingCustomerDocNum,
                                                      EBusinessEventType businessEventType) {
        CommonFinanceRequest financeRequest = new CommonFinanceRequest();
        Buyer buyer = buyerService.getBuyerForNodeId(accountabilityRecord.returnCustomerNodeRef.getId());
        financeRequest.eventType = businessEventType;
        financeRequest.sourceType = record.sellerRef.sellerType;
        financeRequest.requestingOrg = buyer.nodeRef;
        financeRequest.requestGroups = new ArrayList<>();

        RequestGroup requestGroup = new RequestGroup();
        requestGroup.fundingNodeRef = fundingNodeRef;
        requestGroup.buyerRef = buyer.getRef();
        requestGroup.currentNodeRef = buyer.nodeRef;
        requestGroup.items = new ArrayList<>();
        requestGroup.throwExceptionOnError = false;

        FinanceItem financeItem = new FinanceItem();
        financeItem.documentNumber = receivingCustomerDocNum;
        financeItem.quantity = accountabilityRecord.issueQuantity;
        financeItem.fiscalYear = fundingNodeRef.fiscalYear;
        financeItem.commodityCodeRef = record.catalogRef.commodityCodeRef;
        // need to figure out how to get this once the finance decision is made available for INR
        //financeItem.lineNumber = 512;
        financeItem.amount = record.movingAverageCost;
        requestGroup.items.add(financeItem);
        financeRequest.requestGroups.add(requestGroup);
        return financeRequest;
    }
}
