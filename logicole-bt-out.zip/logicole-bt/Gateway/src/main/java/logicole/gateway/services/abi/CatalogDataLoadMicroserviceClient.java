package logicole.gateway.services.abi;

import logicole.apis.abi.ICatalogDataLoadMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class CatalogDataLoadMicroserviceClient extends MicroserviceClient<ICatalogDataLoadMicroserviceApi> {
    public CatalogDataLoadMicroserviceClient(){
        super(ICatalogDataLoadMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public ICatalogDataLoadMicroserviceApi getICatalogDataLoadMicroserviceApi() {
        return createClient();
    }

}
