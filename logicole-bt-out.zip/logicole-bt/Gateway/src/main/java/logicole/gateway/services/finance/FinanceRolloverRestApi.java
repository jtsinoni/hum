package logicole.gateway.services.finance;

import io.swagger.annotations.Api;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;

@Api(tags = {"financeRollover"})
@ApplicationScoped
@Path("/financeRollover")
public class FinanceRolloverRestApi extends ExternalRestApi<FinanceRolloverService> {

    @GET
    @Path("/rolloverOrg")
    public void rolloverOrg(@QueryParam("orgId") String orgId) {
        service.rolloverOrg(orgId);
    }


}