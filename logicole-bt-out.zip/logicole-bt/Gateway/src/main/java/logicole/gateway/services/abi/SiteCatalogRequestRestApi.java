package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.SiteCatalogRequest;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi/siteCatalogRequest")
public class SiteCatalogRequestRestApi extends ExternalRestApi<SiteCatalogRequestService> {

    @POST
    @Path("/processRequest")
    public void processRequest(SiteCatalogRequest siteCatalogRequest) {
        service.processRequest(siteCatalogRequest);
    }

}
