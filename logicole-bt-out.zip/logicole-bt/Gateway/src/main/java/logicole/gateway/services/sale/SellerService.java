package logicole.gateway.services.sale;

import logicole.apis.sale.ISellerMicroserviceApi;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.order.OrderDTO;
import logicole.common.datamodels.product.OfferSellerUpdateResponse;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.sale.seller.*;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.product.OfferService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class SellerService extends BaseGatewayService<ISellerMicroserviceApi> {

    @Inject
    protected BuyerService buyerService;

    @Inject
    FulfillmentService fulfillmentService;

    @Inject
    protected OfferService offerService;

    @Inject
    protected SellerService sellerService;

    public SellerService() {
        super("Seller");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public List<Seller> getAllSellers() {
        return microservice.getAllSellers();
    }

    public List<Seller> getSellersForNewAccount(String organizationId) {
        return microservice.getSellersForNewAccount(organizationId);
    }

    public List<Seller> getSellerList(boolean externalIndicator) {
        return microservice.getSellerList(externalIndicator);
    }

    public List<Seller> getSellerListByType(String sellerType) {
        return microservice.getSellerListByType(sellerType);
    }

    public List<Seller> getSellerListByTypes(List<String> sellerTypes) {
        return microservice.getSellerListByTypes(sellerTypes);
    }

    public Seller getSellerById(String id) {
        return microservice.getSellerById(id);
    }

    public List<SellerLocation> getSellerLocationsBySellerId(String sellerId) {
        return microservice.getSellerLocationsBySellerId(sellerId);
    }

    public List<SellerLocation> saveSellerLocation(SellerLocation location) {
        return microservice.saveSellerLocation(location);
    }

    public List<SellerLocation> deleteSellerLocation(String sellerId) {
        return microservice.deleteSellerLocation(sellerId);
    }

    public Seller getSellerByName(String sellerName) {
        return microservice.getSellerByName(sellerName);
    }

    public Seller saveNewSeller(Seller seller) {
        return microservice.saveSeller(seller);
    }

    public Seller saveSeller(Seller seller) {
        Seller retSeller = microservice.saveSeller(seller);
        retSeller.locations = getSellerLocationsBySellerId(seller.getId());
        return retSeller;
    }

    public Seller deleteSeller(String id) {
        return microservice.deleteSeller(id);
    }

    public String getSellerIdByName(String name) {
        return microservice.getSellerIdByName(name);
    }

    public Seller getSellerForOrganizationIdentifier(String organizationId) {
        return microservice.getSellerForOrganizationIdentifier(organizationId);
    }

    public void acceptOrder(OrderDTO order) {

        if(!order.sellerRef.isExternal) {
            fulfillmentService.acceptOrder(order);
        }
    }

    public List<Seller> getInternalSellerList() {
        return microservice.getInternalSellerList();
    }

    public SellerCallNumber getCallNumber(String sellerId) {
        Buyer buyer = buyerService.getBuyerForNodeId(getCurrentUser().profile.currentNodeRef.getId());
        SellerCallNumber sellerCallNumber = new SellerCallNumber();
        if (Objects.nonNull(buyer)) {
            sellerCallNumber = microservice.getCallNumber(buyer.managedByNodeRef.id, sellerId);
            if (Objects.isNull(sellerCallNumber) || Objects.isNull(sellerCallNumber.nextCallNumber)) {
                Seller seller = microservice.getSellerById(sellerId);
                if (Objects.nonNull(seller)) {
                    sellerCallNumber = new SellerCallNumber();
                    sellerCallNumber.nextCallNumber = seller.startingCallNumber;
                    sellerCallNumber.sellerRef = seller.getRef();
                    sellerCallNumber.buyerRef = buyer.getRef();
                }
                sellerCallNumber = microservice.saveSellerCallNumber(sellerCallNumber);
            }
        }
        return sellerCallNumber;
    }

    public void updateCallNumber(SellerCallNumber updatedCallNumber) {
        microservice.updateCallNumber(updatedCallNumber);
    }

    public List<BuyerSellerAccountDTO> getPrimeVendorListByBuyerOrganizationId(String id) {
        List<BuyerSellerAccountDTO> returnList = new ArrayList<>();
        List<BuyerSellerAccountDTO> buyerAccounts = buyerService.getBuyerSellerAccountList();
        for (BuyerSellerAccountDTO buyerAccount : buyerAccounts) {
            Seller seller = sellerService.getSellerById(buyerAccount.sellerId);
            if (seller.sellerTypeRef.sellerType.equals("DPV")) {
                returnList.add(buyerAccount);
            }
        }
        return returnList;
    }

    public OfferSellerUpdateResponse updateSellersAndOffers(String changeToSellerName, List<String> sellerNamesToUpdate) {
        OfferSellerUpdateResponse offerUpdate = new OfferSellerUpdateResponse();
        offerUpdate.numberOffersUpdated = 0;
        Seller sellerChangeTo = microservice.getSellerByName(changeToSellerName);
        if (sellerChangeTo != null) {
            offerUpdate = offerService.updateSellersInOffers(sellerChangeTo.getId(), changeToSellerName, sellerChangeTo.sellerTypeRef.sellerType, sellerNamesToUpdate);
            offerUpdate.numberSellerDeleted = 0;
            offerUpdate.numberBuyerAccountsUpdated = 0;
            offerUpdate.numberBuyerAccountsUpdated = updateSellerInfoInBuyerSellerAccounts(sellerNamesToUpdate, sellerChangeTo);
            for (String sellerName : sellerNamesToUpdate) {
                Seller seller = microservice.getSellerByName(sellerName);
                microservice.deleteSeller(seller.getId());
                offerUpdate.numberSellerDeleted++;
            }
        } else {
            offerUpdate.success = false;
        }
        return offerUpdate;
    }

    private Integer updateSellerInfoInBuyerSellerAccounts(List<String> sellerNamesToUpdate, Seller sellerChangeTo) {
        Integer numberBuyerAccountsUpdated = 0;
        for (String sellerName : sellerNamesToUpdate) {
            Seller sellerToUpdate = microservice.getSellerByName(sellerName);
            List<BuyerSellerAccountDTO> accounts = microservice.getBuyerSellerAccountListBySellerId(sellerToUpdate.getId());
            for (BuyerSellerAccountDTO account : accounts) {
                account.sellerId = sellerChangeTo.getId();
                updateBuyerAccountFlags(account, sellerChangeTo);
                account.customerAccountNumber = null;  // ToDo: the account number is no longer valid because the Seller changed, do we need to notify the user it changed?
                account.customerContract = null;   // ToDo: must find the contract for the new Seller and save it here
                microservice.saveBuyerSellerAccount(account);
                numberBuyerAccountsUpdated++;
            }
        }
        return numberBuyerAccountsUpdated;
    }

    private void updateBuyerAccountFlags(BuyerSellerAccountDTO account, Seller sellerChangeTo) {
        account.hubzoneSmallBusinessIndicator = sellerChangeTo.isHubzoneSmallBusiness;
        account.economicallyDisadvantagedWomanOwnedSmallBusinessIndicator = sellerChangeTo.isEconomicallyDisadvantagedWomanOwnedSmallBusiness;
        account.isPurchaseCardEligible = sellerChangeTo.isPurchaseCardEligible;
        account.smallBusinessIndicator = sellerChangeTo.isSmallBusiness;
        account.womanOwnedSmallBusinessIndicator = sellerChangeTo.isWomanOwnedSmallBusiness;
        account.smallDisadvantagedBusinessIndicator = sellerChangeTo.isSmallDisadvantagedBusiness;
        account.serviceDisabledVeteranOwnedSmallBusinessIndicator = sellerChangeTo.isServiceDisabledVeteranOwnedSmallBusiness;
    }

    public List<CustomerContract> getCustomerContractList() {
        return microservice.getCustomerContractList();
    }

    public CustomerContract getCustomerContractById(String customerContractId) {
        return microservice.getCustomerContractById(customerContractId);
    }

    public List<CustomerContract> getCustomerContractListByOrderingCustomerId(String orderingCustomerId) {
        return microservice.getCustomerContractListByOrderingCustomerId(orderingCustomerId);
    }

    public List<CustomerContract> getCustomerContractListByCustomer(String customerOrganization, String orderingCustomerId) {
        return microservice.getCustomerContractListByCustomer(customerOrganization, orderingCustomerId);
    }

    public BuyerSellerAccount getBuyerSellerAccountById(String id) {
        return microservice.getBuyerSellerAccountById(id);
    }

    public List<BuyerSellerAccountDTO> getBuyerSellerAccountListByBuyerId(String buyerId) {
        return microservice.getBuyerSellerAccountListByBuyerId(buyerId);
    }

    public List<BuyerSellerAccountDTO> getBuyerSellerAccountListBySellerId(String sellerId) {
        List<BuyerSellerAccountDTO> accounts = microservice.getBuyerSellerAccountListBySellerId(sellerId);
        for (BuyerSellerAccountDTO account: accounts) {
            Buyer buyer = buyerService.getBuyerByBuyerId(account.buyerId);
            if (buyer != null) {
                account.organization = buyer.nodeRef.name;
                account.organizationId = buyer.nodeRef.id;
            }
        }
        return accounts;
    }

    public BuyerSellerAccountDTO saveBuyerSellerAccount(BuyerSellerAccountDTO buyerSellerAccount) {
        if (Objects.nonNull(buyerSellerAccount) && Objects.isNull(buyerSellerAccount.buyerId)) {
            Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
            buyerSellerAccount.buyerId = buyer.getId();
        }
        BuyerSellerAccountDTO savedAccount = microservice.saveBuyerSellerAccount(buyerSellerAccount);
        Buyer buyer = buyerService.getBuyerByBuyerId(savedAccount.buyerId);
        savedAccount.organization = buyer.nodeRef.name;
        savedAccount.organizationId = buyer.nodeRef.id;

        return savedAccount;
    }

    public List<BuyerSellerAccountDTO> deleteBuyerSellerAccount(BuyerSellerAccountDTO buyerSellerAccount) {
        return microservice.deleteBuyerSellerAccount(buyerSellerAccount);
    }

    public List<CustomerContract> getCustomerContractListForPrimeVendorSeller(String sellerId, String customer, String orderingCustomer) {
        return microservice.getCustomerContractListForPrimeVendorSeller(sellerId, customer, orderingCustomer);
    }

    public CustomerContractNumberForPrimeVendorResponse getPrimeVendorCustomerContractByBuyerIdAndSellerId(String buyerId, String sellerId) {
        return buyerService.getPrimeVendorCustomerContractByBuyerIdAndSellerId(buyerId, sellerId);
    }
    public String getAndAdvanceNextCallNumberForCustomerContract(String contractId) {
        return microservice.getAndAdvanceNextCallNumberForCustomerContract(contractId);
    }


    public BuyerSellerAccount getBuyerSellerAccountBySellerAndBuyerId(String buyerId, String sellerId) {
        return microservice.getBuyerSellerAccountBySellerAndBuyerId(buyerId, sellerId);
    }

    public List<SellerType> getSellerTypes() {
        return microservice.getSellerTypes();
    }

    public SellerType getSellerTypeByType(String type){
        return microservice.getSellerTypeByType(type);
    }

    public SellerTypeOrderConfiguration getSellerTypeOrderConfiguration(String type){
        return microservice.getSellerTypeOrderConfiguration(type);
    }

    public CustomerContractDTO getCurrentCustomerContract(String custDodaac, String orderingCustId, String sosCd, String contractPriorityCd) {
        CustomerContractDTO customerContractDTO = microservice.getCurrentCustomerContract(custDodaac, orderingCustId, sosCd, contractPriorityCd);
        if (StringUtil.isEmptyOrNull(customerContractDTO.id)) {
            throw new ApplicationException("No current Prime Vendor contract was found for this buyer.");
        } else {
            return customerContractDTO;
        }
    }

    public OrganizationSellerAccountNumber getOrganizationSellerAccountNumber(String sellerId) {
        Buyer buyer = buyerService.getBuyerForNodeId(getCurrentUser().profile.currentNodeRef.getId());
        return microservice.getOrganizationSellerAccountNumber(buyer.managedByNodeRef.id, sellerId);
    }

    public OrganizationSellerAccountNumber saveOrganizationSellerAccountNumber(OrganizationSellerAccountNumber organizationSellerAccountNumber){
        Buyer buyer = buyerService.getBuyerForNodeId(getCurrentUser().profile.currentNodeRef.getId());
        organizationSellerAccountNumber.organizationRef = buyer.managedByNodeRef;
        return microservice.saveOrganizationSellerAccountNumber(organizationSellerAccountNumber);
    }

    public SellerLocation getSellerLocationById (String id) {
        return microservice.getSellerLocationById(id);
    }

    public UserSellerAccount getUserSellerAccountById(String id) {
        return microservice.getUserSellerAccountById(id);
    }

    public UserSellerAccount getUserSellerAccountNumber (String sellerId) {
        String buyerId = buyerService.getBuyerForNodeId(getCurrentUser().profile.currentNodeRef.getId()).getId();
        return microservice.getUserSellerAccountNumber(buyerId, sellerId);
    }

    public UserSellerAccount saveUserSellerAccount(UserSellerAccount userSellerAccount) {
        userSellerAccount.buyerRef = buyerService.getBuyerForNodeId(getCurrentUser().profile.currentNodeRef.getId()).getRef();
        userSellerAccount.userRef = getCurrentUser().getRef();
        return microservice.saveUserSellerAccount(userSellerAccount);
    }

    public void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate) {
        microservice.processDataReferenceUpdate(dataReferenceUpdate);
    }
}
