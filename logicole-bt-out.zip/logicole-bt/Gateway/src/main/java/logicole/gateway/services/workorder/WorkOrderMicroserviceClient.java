package logicole.gateway.services.workorder;

import logicole.apis.workorder.IWorkOrderMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class WorkOrderMicroserviceClient extends MicroserviceClient<IWorkOrderMicroserviceApi> {
    public WorkOrderMicroserviceClient() {
        super(IWorkOrderMicroserviceApi.class, "logicole-workorder");
    }

    @Produces
    public IWorkOrderMicroserviceApi getIWorkOrderMicroserviceApi() {
        return createClient();
    }
}
