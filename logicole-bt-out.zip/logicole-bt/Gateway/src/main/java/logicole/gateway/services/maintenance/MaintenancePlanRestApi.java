package logicole.gateway.services.maintenance;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.item.ItemRef;
import logicole.common.datamodels.asset.classification.Nomenclature;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.maintenance.plan.EMaintenanceIntervalType;
import logicole.common.datamodels.maintenance.plan.EMaintenanceResponsibility;
import logicole.common.datamodels.maintenance.plan.MaintenanceInterval;
import logicole.common.datamodels.maintenance.plan.MaintenancePlan;
import logicole.common.datamodels.maintenance.procedure.MedicalEquipmentMaintenanceProcedureSummary;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"MaintenancePlan"})
@ApplicationScoped
@Path("/maintenancePlan")
public class MaintenancePlanRestApi extends ExternalRestApi<MaintenancePlanService> {

    @GET
    @Path("/findById")
    public MaintenancePlan findById(@NotNull @QueryParam("id") String id) {
        return service.findById(id);
    }

    @POST
    @Path("/createMaintenancePlan")
    public MaintenancePlan createMaintenancePlan(@NotNull MaintenancePlan maintenancePlan) {
        return service.createMaintenancePlan(maintenancePlan);
    }

    @GET
    @Path("/getMedicalEquipmentMaintenanceProcedureSummaries")
    public List<MedicalEquipmentMaintenanceProcedureSummary> getMedicalEquipmentMaintenanceProcedureSummaries() {
        return service.getMedicalEquipmentMaintenanceProcedureSummaries();
    }

    @GET
    @Path("/getAgencyMedicalEquipmentMaintenanceProcedureSummaries")
    public List<MedicalEquipmentMaintenanceProcedureSummary> getAgencyMedicalEquipmentMaintenanceProcedureSummaries() {
        return service.getAgencyMedicalEquipmentMaintenanceProcedureSummaries();
    }

    @POST
    @Path("/updateMaintenancePlanDetail")
    public MaintenancePlan updateMaintenancePlanDetail(@NotNull MaintenancePlan maintenancePlan) {
        return service.updateMaintenancePlanDetail(maintenancePlan);
    }

    @POST
    @Path("updateSiteProcedureForAgencyPlan")
    public MaintenancePlan updateSiteProcedureForAgencyPlan(@NotNull MaintenancePlan maintenancePlan) {
        return service.updateSiteProcedureForAgencyPlan(maintenancePlan);
    }

    @GET
    @Path("/cloneMaintenancePlan")
    public MaintenancePlan cloneMaintenancePlan(@NotNull @QueryParam("id") String id) {
        return service.cloneMaintenancePlan(id);
    }

    @POST
    @Path("/getNomenclatures")
    public SearchResult<Nomenclature> getNomenclatures(@NotNull SearchInput searchInput) {
        return service.getNomenclatures(searchInput);
    }

    @POST
    @Path("/getMaintenancePlanSearchResults")
    public SearchResult<MaintenancePlan> getMaintenancePlanSearchResults(@NotNull SearchInput searchInput) {
        return service.getMaintenancePlanSearchResults(searchInput);
    }

    @POST
    @Path("getMedicalEquipmentAssets")
    public SearchResult<Asset> getMedicalEquipmentAssets(@NotNull SearchInput searchInput) {
        return service.getMedicalEquipmentAssets(searchInput);
    }

    @GET
    @Path("/getMedicalAssetRefsByNomenclatureId")
    public List<AssetRef> getMedicalAssetRefsByNomenclatureId(@QueryParam("nomenclatureId") String nomenclatureId) {
        return service.getMedicalAssetRefsByNomenclatureId(nomenclatureId);
    }

    @GET
    @Path("/getMaintenanceResponsibilities")
    public List<EMaintenanceResponsibility> getMaintenanceResponsibilities() {
        return service.getMaintenanceResponsibilities();
    }

    @GET
    @Path("/getNomenclatureById")
    public Nomenclature getNomenclatureById(@NotNull @QueryParam("nomenclatureId") String nomenclatureId) {
        return service.getNomenclatureById(nomenclatureId);
    }

    @GET
    @Path("/getNomenclatureByCode")
    public Nomenclature getNomenclatureByCode(@NotNull @QueryParam("nomenclatureCode") String nomenclatureCode) {
        return service.getNomenclatureByCode(nomenclatureCode);
    }

    @GET
    @Path("/getMaintenanceIntervalTypes")
    public List<EMaintenanceIntervalType> getMaintenanceIntervalTypes() {
        return service.getMaintenanceIntervalTypes();
    }

    @GET
    @Path("/getMaintenanceIntervals")
    public List<MaintenanceInterval> getMaintenanceIntervals() {
        return service.getMaintenanceIntervals();
    }

    @GET
    @Path("/deleteById")
    public MaintenancePlan deleteById(@NotNull @QueryParam("id") String id) {
        return service.deleteById(id);
    }

    @POST
    @Path("/getItemRefs")
    public SearchResult<ItemRef> getItemRefs(@NotNull SearchInput searchInput) {
        return service.getItemRefs(searchInput);
    }

    @GET
    @Path("/getItemRefForAsset")
    public ItemRef getItemRefForAsset(@QueryParam("assetId") String assetId) {
        return service.getItemRefForAsset(assetId);
    }
}
