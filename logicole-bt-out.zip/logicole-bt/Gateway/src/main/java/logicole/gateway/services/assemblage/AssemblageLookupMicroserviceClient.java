package logicole.gateway.services.assemblage;

import logicole.apis.assemblage.IAssemblageLookupMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AssemblageLookupMicroserviceClient extends MicroserviceClient<IAssemblageLookupMicroserviceApi> {
    public AssemblageLookupMicroserviceClient() {
        super(IAssemblageLookupMicroserviceApi.class, "logicole-assemblage");
    }

    @Produces
    public IAssemblageLookupMicroserviceApi getIAssemblageLookupMicroserviceApi(){
        return createClient();
    }
}
