package logicole.gateway.services.realpropertysection;

import logicole.apis.realpropertysection.ISectionMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class SectionMicroserviceClient extends MicroserviceClient<ISectionMicroserviceApi> {
    public SectionMicroserviceClient(){
        super(ISectionMicroserviceApi.class, "logicole-realproperty-section");
    }

    @Produces
    public ISectionMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
