package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiSearchMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiSearchMicroserviceClient extends MicroserviceClient<IAbiSearchMicroserviceApi> {
    public AbiSearchMicroserviceClient() {
        super(IAbiSearchMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiSearchMicroserviceApi getABiProductionService() {
        return createClient();
    }
}

