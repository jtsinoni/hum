package logicole.gateway.services.realpropertysection;

import logicole.apis.realpropertysection.ISectionMicroserviceApi;
import logicole.common.crossservice.util.PersistedEntityUtil;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.classification.AssemblyCategoryRef;
import logicole.common.datamodels.asset.classification.FacilitySubsystemRef;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.AssetSummary;
import logicole.common.datamodels.asset.schedule.Schedule;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.BulkUpdateResult;
import logicole.common.datamodels.general.FailedItem;
import logicole.common.datamodels.general.customfield.CustomField;
import logicole.common.datamodels.general.customfield.CustomFieldRef;
import logicole.common.datamodels.general.customfield.CustomFieldValue;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.realproperty.Site;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.realproperty.facility.FacilityRef;
import logicole.common.datamodels.realpropertyproject.Requirement;
import logicole.common.datamodels.realpropertyproject.project.RealPropertyProject;
import logicole.common.datamodels.realpropertysection.*;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtype;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeHierarchy;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeRef;
import logicole.common.datamodels.realpropertysection.lookupdata.PaintTypeRef;
import logicole.common.datamodels.space.Floor;
import logicole.common.datamodels.space.FloorRef;
import logicole.common.datamodels.system.EBusinessArea;
import logicole.common.datamodels.system.TagRef;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.common.UnauthorizedException;
import logicole.gateway.services.asset.AssetScheduleService;
import logicole.gateway.services.asset.AssetService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.realproperty.InstallationService;
import logicole.gateway.services.realpropertyproject.ProjectService;
import logicole.gateway.services.realpropertyproject.RequirementService;
import logicole.gateway.services.spacemanagement.SpaceManagementService;
import logicole.gateway.services.system.TagService;
import logicole.gateway.services.workorder.WorkOrderService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@ApplicationScoped
public class SectionService extends BaseGatewayService<ISectionMicroserviceApi> {

    private static final String SECTION_DOES_NOT_EXIST_MESSAGE_STRING = "The Section does not exist.";
    private static final String SECTION_ASSOCIATED_WITH_OPEN_REQUIREMENT = " Requirement(s) which have a status of not Closed";
    private static final String SECTION_ASSOCIATED_WITH_OPEN_WORK_ORDER = " Work Order(s) which have a status of not Closed";
    private static final String SECTION_ASSOCIATED_WITH_OPEN_PROJECT = " Project(s) which have a status of not Closed";
    private static final String SECTION_ASSOCIATED_WITH_ACTIVE_EQUIPMENT = " active RP Equipment Records associated with it";
    private static final String THESE_RECORDS_NEED_TO_BE_CLOSED = ". This record may not be set to Inactive until all associated Requirement(s) " +
            "and/or Project(s) and/or Work order(s) are set to Closed and all active RP Equipment Records are unassociated.";
    private static final String SECTION_NOT_SET_TO_INACTIVE = "Record was not set to Inactive. This Section has ";
    public static final String CLOSED = "Closed";

    @Inject
    AssetScheduleService assetScheduleService;

    @Inject
    AssetService assetService;

    @Inject
    FacilityService facilityService;

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    InstallationService installationService;

    @Inject
    ProjectService projectService;

    @Inject
    RequirementService requirementService;

    @Inject
    SpaceManagementService spaceManagementService;

    @Inject
    TagService tagService;

    @Inject
    WorkOrderService workOrderService;
    
    @Inject
    OrganizationService organizationService;

    @Inject
    PersistedEntityUtil persistedEntityUtil;

    public SectionService() {
        super("Section");
    }

    public Section createSection(Section section) {
        validateSection(section);
        applyDefaultValuesIfMissing(section);
        boolean isSectionNameUnique = isSectionNameUnique(section.facilityRef.id, section.getId(), section.sectionName, section.systemRef.id,
                section.subsystemRef.id, section.assemblyCategoryRef.id, section.componentSubtypeRef.id);
        if (!isSectionNameUnique) {
            throw new ApplicationException("A Section with this name and facility already exists.");
        }

        section.managedByNodeRef = facilityService.getManagedByNodeRef(section.facilityRef);
        return microservice.createSection(section);
    }

    private void applyDefaultValuesIfMissing(Section section) {
        if (Objects.isNull(section.paintTypeRef)) {
            section.paintTypeRef = new PaintTypeRef();
        }
        if (Objects.isNull(section.assetRefList)) {
            section.assetRefList = new ArrayList<>();
        }
        if (Objects.isNull(section.comments)) {
            section.comments = "";
        }
        if (Objects.isNull(section.designLife)) {
            section.designLife = 0;
        }
        if (Objects.isNull(section.designLifeRemaining)) {
            section.designLifeRemaining = 0;
        }
        if (Objects.isNull(section.floorRef)) {
            section.floorRef = new FloorRef();
        }
        if (Objects.isNull(section.installYearEstimatedInd)) {
            section.installYearEstimatedInd = false;
        }
        if (Objects.isNull(section.paintedYear)) {
            section.paintedYear = "";
        }
        if (Objects.isNull(section.renewalYear)) {
            section.renewalYear = "";
        }
        if (Objects.isNull(section.renewalYearEstimatedInd)) {
            section.renewalYearEstimatedInd = false;
        }
        if (Objects.isNull(section.siteDodaac)) {
            section.siteDodaac = section.facilityRef.siteDodaac;
        }
        if (Objects.isNull(section.subsystemConditionIndex)) {
            section.subsystemConditionIndex = 0.0;
        }
        if (Objects.isNull(section.subsystemReplacementCost)) {
            section.subsystemReplacementCost = new MonetaryValue(0.0);
        }
        if (Objects.isNull(section.tagRefList)) {
            section.tagRefList = new ArrayList<>();
        }
    }

    private void validateSection(Section section) {
        List<String> nullFields = new ArrayList<>();
        boolean isValid = true;
        if (Objects.isNull(section.facilityRef)) {
            isValid = false;
            nullFields.add("section.facilityRef");
        }
        if (Objects.isNull(section.sectionName)) {
            isValid = false;
            nullFields.add("section.sectionName");
        }
        if (Objects.isNull(section.systemRef)) {
            isValid = false;
            nullFields.add("section.systemRef");
        }
        if (Objects.isNull(section.subsystemRef)) {
            isValid = false;
            nullFields.add("section.subsystemRef");
        }
        if (Objects.isNull(section.assemblyCategoryRef)) {
            isValid = false;
            nullFields.add("section.assemblyCategoryRef");
        }
        if (Objects.isNull(section.componentSubtypeRef)) {
            isValid = false;
            nullFields.add("section.componentSubtypeRef");
        }
        if (Objects.isNull(section.isLinkedToSMS)) {
            isValid = false;
            nullFields.add("section.isLinkedToSMS");
        }

        // DSE-10445: This code has been added to trace the origin of nulls in 2 Section ref fields
        if ( (section.systemRef == null) ||  (section.subsystemRef == null)) {
            throw new ApplicationException("Invalid systemRef and subsystemRef.");
        }

        if (!isValid) {
            throw new ApplicationException("one or more section fields are NULL: " + String.join(", ", nullFields));
        }
    }

    public Section getSectionById(String id) {
        Section section = microservice.getSectionById(id);
        validateSectionUserAccess(section);
        return section;
    }

    public SearchResult<SectionSummary> getSectionSearchResults(SearchInput searchInput) {
        if (StringUtil.isEmptyOrNull(searchInput.searchText) || searchInput.searchText.trim().length() < 3) {
            throw new ApplicationException("Search criteria must be at least 3 characters");
        }
        return performSectionSearch(searchInput);
    }

    public List<SectionSummary> getSectionReport(SearchInput searchInput) {
        SearchResult<SectionSummary> searchResult = performSectionSearch(searchInput);
        if (!ListUtil.isEmpty(searchResult.results)) {
            return searchResult.results;
        } else {
            return new ArrayList<>();
        }
    }

    private SearchResult<SectionSummary> performSectionSearch(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getSectionSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported at this time.");
        }

        SearchResult<SectionSummary> convertedResult = new SearchResult<>();
        organizationService.setRPFuncFilterInSearch(searchInput);
        SearchResult<SectionSummary> searchResult = microservice.getSectionSearchResults(searchInput);
        convertedResult.aggregations = searchResult.aggregations;

        if (!ListUtil.isEmpty(searchResult.results)) {
            List<SectionSummary> allSectionSummaries = new ArrayList<>();

            for (SectionSummary sectionSummary : searchResult.results) {
                buildCompleteSectionSummary(sectionSummary);
                allSectionSummaries.add(sectionSummary);
            }
            convertedResult.results = allSectionSummaries;
            convertedResult.total = searchResult.total;
            convertedResult.limit = searchResult.limit;
        }
        return convertedResult;
    }

    public Section updateSectionHeader(SectionHeader sectionHeader) {
        Section currentSection;
        if (sectionHeader != null && !sectionHeader.sectionId.isEmpty()) {
            currentSection = microservice.getSectionById(sectionHeader.sectionId);
        } else {
            throw new ApplicationException(SECTION_DOES_NOT_EXIST_MESSAGE_STRING);
        }

        currentSection.sectionName = sectionHeader.sectionName;
        currentSection.facilityRef = sectionHeader.facilityRef;
        currentSection.managedByNodeRef = facilityService.getManagedByNodeRef(sectionHeader.facilityRef);

        checkForDuplicates(currentSection);
        return microservice.updateSectionHeader(sectionHeader);
    }

    private void checkForDuplicates(Section section) {
        if (StringUtil.isEmptyOrNull(section.getId())) {
            // new section, check to see if name/facility already exist
            boolean isSectionNameUnique = isSectionNameUnique(section.facilityRef.id, section.getId(), section.sectionName, section.systemRef.id,
                    section.subsystemRef.id, section.assemblyCategoryRef.id, section.componentSubtypeRef.id);
            if (!isSectionNameUnique) {
                throw new ApplicationException("A Section with this name and facility already exists.");
            }
        } else {
            Section currentSection = microservice.getSectionById(section.getId());
            if (currentSection != null && (!currentSection.sectionName.equalsIgnoreCase(section.sectionName) || !currentSection.facilityRef.id.equalsIgnoreCase(section.facilityRef.id))) {
                int foundSection = microservice.getSectionByNameAndFacility(section.sectionName, section.facilityRef).size();
                if (foundSection > 0) {
                    throw new ApplicationException("A Section with this name and facility already exists.");
                }
            }
        }
    }

    private void buildCompleteSectionSummary(SectionSummary sectionSummary) {
        Facility sectionFacility = facilityService.getFacilityById(sectionSummary.facilityRef.getId());

        if (sectionFacility != null && sectionFacility.siteRef != null) {
            Site sectionSite = installationService.getSiteById(sectionFacility.siteRef.getId());

            if (sectionSite != null) {
                sectionSummary.siteName = sectionSite.name;
            }
        }

        sectionSummary.assemblyCategory = sectionSummary.assemblyCategoryRef.code + " - " + sectionSummary.assemblyCategoryRef.description;
        sectionSummary.facility = sectionSummary.facilityRef.facilityNumber + " - " + sectionSummary.facilityRef.name;
        sectionSummary.subsystem = sectionSummary.subsystemRef.code + " - " + sectionSummary.subsystemRef.description;
        sectionSummary.system = sectionSummary.systemRef.code + " - " + sectionSummary.systemRef.description;
        if (sectionSummary.assetRefList != null) {
            sectionSummary.rpieCount = sectionSummary.assetRefList.size();
        }
    }

    public SectionSummary convertSectionToSectionSummary(Section section) {
        SectionSummary sectionSummary = new SectionSummary();
        sectionSummary.id = section.getId();
        sectionSummary.assemblyCategoryRef = section.assemblyCategoryRef;
        sectionSummary.componentSubtypeRef = section.componentSubtypeRef;
        sectionSummary.facilityRef = section.facilityRef;
        sectionSummary.installYear = section.installYear;
        sectionSummary.isRecordActive = section.isRecordActive;
        sectionSummary.sectionName = section.sectionName;
        sectionSummary.floorRef = section.floorRef;
        sectionSummary.subsystemRef = section.subsystemRef;
        sectionSummary.systemRef = section.systemRef;
        sectionSummary.sectionConditionIndex = section.sectionConditionIndex;
        sectionSummary.assetRefList = section.assetRefList;
        buildCompleteSectionSummary(sectionSummary);

        return sectionSummary;
    }

    private List<SectionSummary> convertSectionsToSectionSummaries(List<Section> sectionList) {
        List<SectionSummary> summaryList = new ArrayList<>();
        for (Section section : sectionList) {
            summaryList.add(convertSectionToSectionSummary(section));
        }
        return summaryList;
    }


    public Boolean deleteSection(String sectionId) {
        Section section = getSectionById(sectionId);
        if (section == null) {
            throw new ApplicationException("Section not found");
        }

        if (section.sectionConditionList != null && section.sectionConditionList.size() > 0) {
            throw new ApplicationException(String.format("The section %s has Conditions associated with it and cannot be deleted. ", section.sectionName));
        }

        if (section.isLinkedToSMS.equals(Boolean.TRUE)) {
            throw new ApplicationException(String.format("The section %s is linked to SMS. Disassociate SMS Link before deleting the section", section.sectionName));
        }
        if (section.assetRefList != null && section.assetRefList.size() > 0) {
            throw new ApplicationException(String.format("The section %s is referenced in Assets. Disassociate all Assets before deleting the section", section.sectionName));
        }
        List<Requirement> requirements = requirementService.getRequirementsBySectionId(sectionId);
        if (!ListUtil.isEmpty(requirements)) {
            throw new ApplicationException(String.format("The section %s is referenced in Requirements. Disassociate all Requirements before deleting the section", section.sectionName));
        }
        List<WorkOrder> workOrders = workOrderService.getWorkOrdersBySectionId(sectionId);
        if (!ListUtil.isEmpty(workOrders)) {
            throw new ApplicationException(String.format("The section %s is referenced in Work Orders. Disassociate all Work Orders before deleting the section", section.sectionName));
        }
        List<RealPropertyProject> realPropertyProjects = getProjectsBySectionId(sectionId);
        if (!ListUtil.isEmpty(realPropertyProjects)) {
            throw new ApplicationException(String.format("The section %s is referenced in Real Property Projects. Disassociate all Projects before deleting the section", section.sectionName));
        }
        return microservice.deleteSection(sectionId);
    }

    public List<Section> getSectionsByIds(List<SectionRef> sectionList) {
        return microservice.getSectionsByIds(sectionList);
    }

    public List<Section> getSectionsByFacilityIds(List<String> facilityIds) {
        return microservice.getSectionsByFacilityIds(facilityIds, "ALL");
    }

    public List<SectionSummary> getSectionSummariesByFacilityIds(List<String> facilityIds, String activeStatus) {
        List<Section> sections = microservice.getSectionsByFacilityIds(facilityIds, "ACTIVE");
        return convertSectionsToSectionSummaries(sections);
    }

    public List<Section> getSectionsByFloorIds(List<String> floorIds) {
        return microservice.getSectionsByFloorIds(floorIds);
    }

    public Attachment saveSectionAttachment(String sectionId, Attachment attachment) {
        return microservice.saveSectionAttachment(sectionId, attachment);
    }

    public boolean removeSectionAttachment(String sectionId, String fileId) {
        return microservice.removeSectionAttachment(sectionId, fileId);
    }

    public Integer getMaxSectionAttachmentSize() {
        return microservice.getMaxSectionAttachmentSize();
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        } catch (BadRequestException e) {
            throw e;
        }

        return uploadedFile;
    }

    public Section updateSectionAudit(SectionAudit sectionAudit) {
        return microservice.updateSectionAudit(sectionAudit);
    }

    public Section updateSectionComments(SectionComments sectionComments) {
        return microservice.updateSectionComments(sectionComments);
    }

    public Section updateSectionData(SectionData sectionData) {
        return microservice.updateSectionData(sectionData);
    }

    public Section saveNote(String id, Note note) {
        return microservice.saveNote(id, note);
    }

    public Section removeNote(String id, String noteId) {
        return microservice.removeNote(id, noteId);
    }

    public Section updateSectionPaintInformation(SectionPaintInformation sectionPaintInformation) {
        return microservice.updateSectionPaintInformation(sectionPaintInformation);
    }

    public List<AssemblyCategoryRef> getAssemblyCategoriesBySectionId(String sectionId) {
        return microservice.getAssemblyCategoriesBySectionId(sectionId);
    }

    public List<FacilitySubsystemRef> getFacilitySubsystemsByFacilitySystemId(
            String facilitySystemId) {
        return microservice.getFacilitySubsystemsByFacilitySystemId(facilitySystemId);
    }

    public List<AssemblyCategoryRef> getAssemblyCategoriesByFacilitySystemIdAndFacilitySubsystemId(
            String facilitySystemId,
            String facilitySubsystemId) {
        return microservice.getAssemblyCategoriesByFacilitySystemIdAndFacilitySubsystemId(facilitySystemId, facilitySubsystemId);
    }

    public List<ComponentSubtypeRef> getComponentSubtypesBySystemHierarchyIds(
            String facilitySystemId,
            String facilitySubsystemId,
            String assemblyCategoryId) {
        return microservice.getComponentSubtypesBySystemHierarchyIds(facilitySystemId, facilitySubsystemId, assemblyCategoryId);
    }

    public List<ComponentSubtypeRef> getComponentSubtypesForSectionAssemblyCategory(String sectionId, AssemblyCategoryRef assemblyCategoryRef) {
        return microservice.getComponentSubtypesForSectionAssemblyCategory(sectionId, assemblyCategoryRef);
    }

    public Section updateSectionSystemInformationAndClassification(SectionSystemInformationAndClassification sectionSystemInformationAndClassification) {
        List<String> assetIdList = new ArrayList<>();

        Section section = getSectionById(sectionSystemInformationAndClassification.sectionId);

        if (sectionSystemInformationAndClassification.assemblyCategoryRef != section.assemblyCategoryRef) {
            if (section.assetRefList != null && !section.assetRefList.isEmpty()) {
                section.assetRefList.forEach(assetRef -> assetIdList.add(assetRef.id));
                assetService.removeSectionRefFromAssets(assetIdList);
            }
        }

        Section sectionUpdated = microservice.updateSectionSystemInformationAndClassification(sectionSystemInformationAndClassification);

        return sectionUpdated;
    }

    public List<AssetSummary> getAssetsById(List<AssetRef> assetList) {
        return assetService.getAssetsByIds(assetList);
    }

    public List<AssetSummary> getRpeAssetsByFacilityId(String facilityId) {
        return assetService.getRpeAssetsByFacilityId(facilityId);
    }

    public List<AssetSummary> getRpeAssetsForSections(String sectionId, String facilityId) {
        return assetService.getRpeAssetsForSections(sectionId, facilityId);
    }


    public void addAssetRefToSection(String id, AssetRef assetRef) {
        microservice.addAssetRefToSection(id, assetRef);
    }

    public void removeAssetRefFromSection(String id, AssetRef assetRef) {
        microservice.removeAssetRefFromSection(id, assetRef);
    }

    public Section updateSectionAssets(String id, List<AssetRef> sectionAssets) {
        List<String> assetIdList = new ArrayList<>();
        List<String> assetIdAddList = new ArrayList<>();
        Section section = getSectionById(id);

        if (section.assetRefList != null && !section.assetRefList.isEmpty()) {
            section.assetRefList.forEach(assetRef -> assetIdList.add(assetRef.id));
            assetService.removeSectionRefFromAssets(assetIdList);
        }

        if (!sectionAssets.isEmpty()) {
            sectionAssets.forEach(assetRef -> assetIdAddList.add(assetRef.id));
            assetService.addSectionRefToAssets(id, assetIdAddList);
        }

        return microservice.updateSectionAssets(id, sectionAssets);
    }

    public List<Floor> getFloorsByFacilityId(String facilityId) {
        return spaceManagementService.getFloorsByFacilityId(facilityId);
    }

    public BulkUpdateResult bulkSetSectionsActive(List<String> sectionIds) {
        BulkUpdateResult result = new BulkUpdateResult();

        BulkUpdateResult spaceSeviceResult = microservice.bulkSetSectionsActive(sectionIds);
        result.succeedItems.addAll(spaceSeviceResult.succeedItems);
        result.failedItems.addAll(spaceSeviceResult.failedItems);

        return result;
    }

    public BulkUpdateResult bulkSetSectionsInactive(List<String> sectionIds) {
        BulkUpdateResult result = new BulkUpdateResult();
        List<String> sectionsToCheck = new ArrayList<>();
        for (String id : sectionIds) {
            FailedItem failedItem = new FailedItem();
            failedItem.id = id;
            List<String> errors = new ArrayList<>();
            boolean isAssociatedToRequirement = checkRequirementForSectionInactive(id);
            if (isAssociatedToRequirement) {
                long openRequirementCount = countOpenRequirementsBySectionId(id);
                errors.add(openRequirementCount + SECTION_ASSOCIATED_WITH_OPEN_REQUIREMENT);
            }
            boolean isAssociatedToWorkOrder = checkWorkOrderForSectionInactive(id);
            if (isAssociatedToWorkOrder) {
                long openWorkOrderCount = countOpenWorkOrdersBySectionId(id);
                errors.add(openWorkOrderCount + SECTION_ASSOCIATED_WITH_OPEN_WORK_ORDER);
            }

            boolean isAssociatedToProject = checkProjectForSectionInactive(id);
            if (isAssociatedToProject) {
                long openProjectCount = countOpenProjectsBySectionId(id);
                errors.add(openProjectCount + SECTION_ASSOCIATED_WITH_OPEN_PROJECT);
            }

            long activeEquipmentCount = countActiveEquipmentBySectionId(id);
            if (activeEquipmentCount > 0) {
                errors.add(activeEquipmentCount + SECTION_ASSOCIATED_WITH_ACTIVE_EQUIPMENT);
            }
            if (!errors.isEmpty()) {
                failedItem.errorMsg = (SECTION_NOT_SET_TO_INACTIVE + String.join("; ", errors) + THESE_RECORDS_NEED_TO_BE_CLOSED);
                result.failedItems.add(failedItem);
            }
            if (activeEquipmentCount == 0 && !isAssociatedToProject && !isAssociatedToRequirement && !isAssociatedToWorkOrder) {
                sectionsToCheck.add(id);
            }
        }
        if (!sectionsToCheck.isEmpty()) {
            BulkUpdateResult spaceServiceResult = microservice.bulkSetSectionsInactive(sectionsToCheck);
            result.succeedItems.addAll(spaceServiceResult.succeedItems);
            result.failedItems.addAll(spaceServiceResult.failedItems);
        }

        return result;
    }

    private boolean checkRequirementForSectionInactive(String id) {
        boolean isAssociated = false;
        List<Requirement> requirements = requirementService.getRequirementsBySectionId(id);
        if (requirements != null && !requirements.isEmpty()) {
            for (Requirement requirement : requirements) {
                if ((null == requirement.workflowState) || (!requirement.workflowState.currentStep.name.equals(CLOSED))) {
                    isAssociated = true;
                    break;
                }
            }
        }
        return isAssociated;
    }

    private boolean checkWorkOrderForSectionInactive(String id) {
        boolean isAssociated = false;
        List<WorkOrder> workOrders = workOrderService.getWorkOrdersBySectionId(id);
        if (workOrders != null && !workOrders.isEmpty()) {
            for (WorkOrder workOrder : workOrders) {
                if ((null == workOrder.workflowState) || (!workOrder.workflowState.currentStep.name.equals(CLOSED))) {
                    isAssociated = true;
                    break;
                }
            }
        }
        return isAssociated;

    }

    private boolean checkProjectForSectionInactive(String id) {
        boolean isAssociated = false;
        List<RealPropertyProject> projects = getProjectsBySectionId(id);
        if (projects != null && !projects.isEmpty()) {
            for (RealPropertyProject project : projects) {
                if ((null == project.workflowState) || (!project.workflowState.currentStep.name.equals(CLOSED))) {
                    isAssociated = true;
                    break;
                }
            }
        }
        return isAssociated;
    }

    private long countOpenRequirementsBySectionId(String id) {
        long count = 0;
        List<Requirement> requirements = requirementService.getRequirementsBySectionId(id);
        if (!ListUtil.isEmpty(requirements)) {
            count = requirements.stream()
                    .filter(requirement -> (null == requirement.workflowState || !requirement.workflowState.currentStep.name.equalsIgnoreCase(CLOSED)))
                    .count();
        }
        return count;
    }

    private long countOpenWorkOrdersBySectionId(String id) {
        long count = 0;
        List<WorkOrder> workOrders = workOrderService.getWorkOrdersBySectionId(id);
        if (!ListUtil.isEmpty(workOrders)) {
            count = workOrders.stream()
                    .filter(workOrder -> (null == workOrder.workflowState || !workOrder.workflowState.currentStep.name.equalsIgnoreCase(CLOSED)))
                    .count();
        }
        return count;
    }

    private long countOpenProjectsBySectionId(String id) {
        long count = 0;
        List<RealPropertyProject> projects = getProjectsBySectionId(id);
        if (!ListUtil.isEmpty(projects)) {
            count = projects.stream()
                    .filter(project -> (null == project.workflowState || !project.workflowState.currentStep.name.equalsIgnoreCase(CLOSED)))
                    .count();
        }
        return count;
    }

    private long countActiveEquipmentBySectionId(String id) {
        long count = 0;
        Section section = getSectionById(id);
        List<AssetSummary> equipments = assetService.getAssetsByIds(section.assetRefList);
        if (!ListUtil.isEmpty(equipments)) {
            count = equipments.stream().filter(equipment -> equipment.isActive.equals(true)).count();
        }
        return count;
    }

    public ComponentSubtypeHierarchy getComponentSubtypeHierarchyByComponentSubtypeId(String componentSubtypeId) {
        return microservice.getComponentSubtypeHierarchyByComponentSubtypeId(componentSubtypeId);
    }

    public ComponentSubtype getComponentSubtypeById(String componentSubtypeId) {
        return microservice.getComponentSubtypeById(componentSubtypeId);
    }

    public List<TagRef> getSectionTags() {
        return tagService.getTagRefsForBusinessArea(EBusinessArea.REAL_PROPERTY_SECTIONS);
    }

    public List<CustomField> getAllCustomFields(@NotNull @QueryParam("customizableTypeId") String customizableTypeId) {
        return microservice.getAllCustomFields(customizableTypeId);
    }

    public List<CustomFieldValue> getAllCustomFieldValues(String id) {
        return microservice.getAllCustomFieldValues(id);
    }

    public CustomField addCustomField(@QueryParam("maxCustomFieldRecords") Integer maxCustomFieldRecords,
                                      @NotNull CustomField customField) {
        return microservice.addCustomField(maxCustomFieldRecords, customField);
    }

    public CustomField updateCustomField(@NotNull CustomField customField) {
        return microservice.updateCustomField(customField);
    }

    public void deleteCustomField(@NotNull CustomField customField) {
        microservice.deleteCustomField(customField);
    }

    public boolean checkIfCustomFieldValuesExist(@NotNull @QueryParam("customFieldId") String customFieldId) {
        return microservice.checkIfCustomFieldValuesExist(customFieldId);
    }

    public boolean checkDuplicateLabel(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                       @QueryParam("label") String label) {
        return microservice.checkDuplicateLabel(customizableTypeId, label);
    }

    public List<CustomFieldValue> saveCustomFieldValues(String id, List<CustomFieldValue> customFieldValues) {
        return microservice.saveCustomFieldValues(id, customFieldValues);
    }

    public List<WorkOrder> getWorkOrdersBySectionId(String SectionId) {
        return workOrderService.getWorkOrdersBySectionId(SectionId);
    }

    public List<Requirement> getRequirementsBySectionId(String SectionId) {
        return requirementService.getRequirementsBySectionId(SectionId, null);
    }


    public List<RealPropertyProject> getProjectsBySectionId(String SectionId) {
        List<RealPropertyProject> realPropertyProjectList = new ArrayList<>();
        List<Requirement> requirementList = requirementService.getRequirementsBySectionId(SectionId, null);
        for (Requirement requirement : requirementList) {
            List<RealPropertyProject> projectList = projectService.getProjectsByRequirement(requirement);
            for (RealPropertyProject realPropertyProject : projectList) {
                realPropertyProjectList.add(realPropertyProject);
            }
        }
        return realPropertyProjectList;
    }

    public Section setSectionActive(String id, Boolean status) {
        List<String> errors = new ArrayList<>();
        if (!status) {
            Section section = getSectionById(id);
            if (section == null) {
                throw new ApplicationException("Section not found");
            }
            int reqCount = 0;
            boolean allReqsClosed = true;
            List<Requirement> requirements = requirementService.getRequirementsBySectionId(id);
            if (requirements != null && !requirements.isEmpty()) {
                for (Requirement requirement : requirements) {
                    if ((null == requirement.workflowState) || (!requirement.workflowState.currentStep.name.equals(CLOSED))) {
                        reqCount++;
                        allReqsClosed = false;
                    }
                }
                if (!allReqsClosed) {
                    errors.add(reqCount + SECTION_ASSOCIATED_WITH_OPEN_REQUIREMENT);
                }
            }

            List<RealPropertyProject> projects = getProjectsBySectionId(id);
            int prjCount = 0;
            boolean allPrjsClosed = true;
            if (projects != null && !projects.isEmpty()) {
                for (RealPropertyProject project : projects) {
                    if ((null == project.workflowState) || (!project.workflowState.currentStep.name.equals(CLOSED))) {
                        prjCount++;
                        allPrjsClosed = false;
                    }
                }
                if (!allPrjsClosed) {
                    errors.add(prjCount + SECTION_ASSOCIATED_WITH_OPEN_PROJECT);
                }
            }

            List<WorkOrder> workOrders = workOrderService.getWorkOrdersBySectionId(id);
            int woCount = 0;
            boolean allWosClosed = true;
            if (workOrders != null && !workOrders.isEmpty()) {
                for (WorkOrder workOrder : workOrders) {
                    if ((null == workOrder.workflowState) || (!workOrder.workflowState.currentStep.name.equals(CLOSED))) {
                        woCount++;
                        allWosClosed = false;
                    }
                }
                if (!allWosClosed) {
                    errors.add(woCount + SECTION_ASSOCIATED_WITH_OPEN_WORK_ORDER);
                }
            }
            long activeEquipmentCount = countActiveEquipmentBySectionId(id);
            if (activeEquipmentCount > 0) {
                errors.add(activeEquipmentCount + SECTION_ASSOCIATED_WITH_ACTIVE_EQUIPMENT);
            }
        }
        if (!errors.isEmpty()) {
            throw new ApplicationException(SECTION_NOT_SET_TO_INACTIVE + String.join("; ", errors) + THESE_RECORDS_NEED_TO_BE_CLOSED);
        }
        return microservice.setSectionActive(id, status);
    }

    public long setSectionsActiveByFacilityIds(List<String> facilityIds) {
        return microservice.setSectionsActiveByFacilityIds(facilityIds);
    }

    public boolean isSectionNameUnique(String facilityId, String sectionId, String sectionName,
                                       String systemId, String subsystemId,
                                       String assemblyCategoryId, String componentSubtypeId) {
        boolean isUnique = true;
        List<Section> sectionsList = getMatchingSections(facilityId, systemId, subsystemId, assemblyCategoryId, componentSubtypeId);

        for (Section section : sectionsList) {
            if (section.sectionName.trim().equalsIgnoreCase(sectionName.trim())) {
                isUnique = false;
                break;
            }
        }
        return isUnique;
    }

    private List<Section> getMatchingSections(String facilityId, String systemId, String subsystemId, String assemblyCategoryId, String componentSubtypeId) {
        return microservice.getMatchingSections(facilityId, systemId, subsystemId, assemblyCategoryId, componentSubtypeId);
    }

    public SectionDashboardInfo getSectionDashboardStats() {
        return microservice.getSectionDashboardStats();
    }

    public Section updateSectionAdditional(SectionAdditional sectionAdditional) {
        sectionAdditional.tagRefList = tagService.verifyAndAddTags(sectionAdditional.tagRefList, EBusinessArea.REAL_PROPERTY_SECTIONS);
        return microservice.updateSectionAdditional(sectionAdditional);
    }

    public List<SectionSummary> getSectionSummariesByIds(List<String> sectionIdList) {
        // Have to create shell SectionRef since get by id method requires refs and not actually ids
        List<SectionRef> sectionRefList = sectionIdList.stream().map(sectionId -> {
            SectionRef sectionRef = new SectionRef();
            sectionRef.id = sectionId;
            return sectionRef;
        }).collect(Collectors.toList());
        List<Section> sections = microservice.getSectionsByIds(sectionRefList);
        return convertSectionsToSectionSummaries(sections);
    }

    public List<Section> getSectionsByAssetIds(List<String> assetIds) {
        return microservice.getSectionsByAssetIds(assetIds);
    }

    public Section updateSectionConditions(String sectionId, List<SectionCondition> sectionConditions) throws ApplicationException {
        return microservice.updateSectionConditions(sectionId, sectionConditions);
    }

    public List<Schedule> getSchedulesByAssetIds(List<String> assetIds) {
        return assetScheduleService.getSchedulesByAssetIds(assetIds);
    }

    public List<AssetSummary> getRpeAssetsByFacilityAndSystem(String sectionId,
                                                              String facilityId,
                                                              String facilitySystemId,
                                                              String facilitySubsystemId,
                                                              String assemblyCategoryId) {

        List<AssetSummary> assetSummaryList = assetService.getRpeAssetsForSections(sectionId, facilityId);
        if (assetSummaryList != null ) {
            assetSummaryList = assetSummaryList.stream().
                    filter (e -> e.facilitySystemRef.id.equals(facilitySystemId)).
                    filter (e -> e.facilitySubsystemRef.id.equals(facilitySubsystemId)).
                    filter (e -> e.assemblyCategoryRef.id.equals(assemblyCategoryId))
                    .collect(Collectors.toList());
        }
        return assetSummaryList;
    }

    public long getSectionStatusCountByFacilityId(String facilityId, Boolean isActive) {
        return microservice.getSectionStatusCountByFacilityId(facilityId, isActive);
    }

    public List<String> getDocumentTypes() {
        return facilityService.getDocumentTypes();
    }

    public long getActiveSectionCountByAssetId(String assetId) {
        return microservice.getActiveSectionCountByAssetId(assetId);
    }

    public void syncFacilityManagedByNodeRef(String facilityId, OrganizationRef managedBy) {
        microservice.syncFacilityManagedByNodeRef(facilityId, managedBy);
    }

    private void validateSectionUserAccess(Section section){
        if (!section.managedByNodeRef.ancestry.contains(currentUserBT.getCurrentNodeId())){
            throw new UnauthorizedException("Unauthorized access");
        }
    }
}
