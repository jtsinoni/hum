package logicole.gateway.services.report;

import io.swagger.annotations.Api;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Api(tags = {"report"})
@ApplicationScoped
@Path("/report")
@Consumes(MediaType.APPLICATION_JSON)
public class ReportRestApi extends ExternalRestApi<ReportService> {

    @GET
    @Path("/test")
    public Boolean test() {
        return service.test();
    }
}
