package logicole.gateway.services.asset;

import logicole.apis.asset.IBusinessContactMicroserviceApi;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.businesscontact.*;
import logicole.common.datamodels.general.Address;
import logicole.common.datamodels.general.BulkUpdateResult;
import logicole.common.datamodels.general.Contact;
import logicole.common.datamodels.general.FailedItem;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.realproperty.facility.FacilityBusinessContact;
import logicole.common.datamodels.realproperty.facility.FacilityBusinessContactDetail;
import logicole.common.datamodels.realpropertyproject.project.ProjectBusinessContact;
import logicole.common.datamodels.space.cobie.staging.COBieContactImportSummary;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.EPhoneNumberType;
import logicole.common.datamodels.user.PhoneNumber;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.realpropertyproject.ProjectService;
import logicole.gateway.services.workorder.WorkOrderService;
import org.apache.commons.collections.CollectionUtils;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static logicole.common.datamodels.organization.OrganizationConstants.DEV_ORG_ID;

@ApplicationScoped
public class BusinessContactService extends BaseGatewayService<IBusinessContactMicroserviceApi> {

    private static final String BUSINESS_CONTACT_DOES_NOT_EXIST_MESSAGE_STRING = "The Business Contact does not exist.";
    private static final String CONTACT_EXISTS_IN_PROJECTS_MESSAGE_STRING = "Name may not be removed as it is the POC for a business contact in projects";
    private static final String CONTACT_EXISTS_IN_FACILITIES_MESSAGE_STRING = "Name may not be removed as it is the POC for a business contact in facilities";

    @Inject
    OrganizationService organizationService;
    @Inject
    WorkOrderService workOrderService;
    @Inject
    AssetScheduleService assetScheduleService;
    @Inject
    ProjectService projectService;
    @Inject
    FacilityService facilityService;


    public BusinessContactService() {
        super("BusinessContact");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public BusinessContact getBusinessContactById(String id) {
        return microservice.getBusinessContactById(id);
    }

    public BusinessContact addMaintenanceActivityOutsourcedToBusinessContact(String id) {
        return microservice.addMaintenanceActivityOutsourcedToBusinessContact(id);
    }

    public List<BusinessContact> getBusinessContacts(String isActive) {
         return microservice.getBusinessContacts(isActive);
    }

    public BusinessContact getBusinessContactByContactId(String contactId) {
        return microservice.getBusinessContactByContactId(contactId);
    }

    public List<BusinessContact> getBusinessContactsByContactIds(List<String> contactIds) {
        return microservice.getBusinessContactsByContactIds(contactIds);
    }

    public List<FacilityBusinessContactDetail> getBusinessContactsByIds(List<FacilityBusinessContact> contacts) {
        return microservice.getBusinessContactsByIds(contacts);
    }

    public List<ProjectBusinessContact> getBusinessContactsByBusinessContactIds(List<ProjectBusinessContact> contacts) {
        return microservice.getBusinessContactsByBusinessContactIds(contacts);
    }

    public BusinessContact createNewBusinessContact(BusinessContact businessContact) {
        businessContact.managedByNodeRef = this.organizationService
                .getOrganizationRefById(this.currentUserBT.getCurrentNodeId());
        businessContact.scopeNodeRefs.add(businessContact.managedByNodeRef);
        return microservice.createNewBusinessContact(businessContact);
    }

    public BusinessContact saveBusinessContact(BusinessContact businessContact) {
        return microservice.saveBusinessContact(businessContact);
    }

    public BusinessContact saveBusinessContactInformation(BusinessContact businessContact) {
        BusinessContact persisted;
        if (businessContact.getId() != null && !businessContact.getId().isEmpty()) {
            persisted = microservice.getBusinessContactById(businessContact.getId());
        } else {
            throw new ApplicationException(BUSINESS_CONTACT_DOES_NOT_EXIST_MESSAGE_STRING);
        }
        if (persisted.isQualityAssuranceOrganization != businessContact.isQualityAssuranceOrganization || !CollectionUtils.isEqualCollection(businessContact.types, persisted.types)) {
            return saveBusinessContactInformationWithContacts(businessContact);
        }

        persisted.name = businessContact.name;
        persisted.types = businessContact.types;
        persisted.isQualityAssuranceOrganization = businessContact.isQualityAssuranceOrganization;
        persisted.qualityAssurancePercent = businessContact.qualityAssurancePercent;
        persisted.qualityControlPercent = businessContact.qualityControlPercent;
        return microservice.saveBusinessContactInformation(persisted);
    }

    public BusinessContact saveBusinessContactInformationWithContacts(BusinessContact businessContact) {
        return microservice.saveBusinessContactInformationWithContacts(businessContact);
    }

    public BusinessContact saveBusinessContactContacts(String id, List<Contact> contacts) {
        List<Contact> contactWithNoName = contacts.stream().filter(c -> !c.isDeleted && c.lastName == "").collect(Collectors.toList());
        if (contactWithNoName != null && contactWithNoName.size() > 0){
            BusinessContact businessContact = microservice.getBusinessContactById(id);
            if (businessContact.contacts != null && businessContact.contacts.size() > 0){
                List<Contact> savedContactWithNoName = businessContact.contacts.stream().filter(c -> !c.isDeleted && c.lastName != "").collect(Collectors.toList());
                if (savedContactWithNoName != null && savedContactWithNoName.size() > 0) {
                    for (Contact contact : contactWithNoName) {
                        for (Contact savedContact : savedContactWithNoName){
                            if (contact.contactId.equals(savedContact.contactId)){
                                if (projectService.isContactInProject(contact.contactId)){
                                    throw new ApplicationException(CONTACT_EXISTS_IN_PROJECTS_MESSAGE_STRING);
                                }
                                if (facilityService.isContactInFacility(contact.contactId)){
                                    throw new ApplicationException(CONTACT_EXISTS_IN_FACILITIES_MESSAGE_STRING);
                                }
                            }
                        }
                    }
                }
            }
        }
        return microservice.saveBusinessContactContacts(id, contacts);
    }

    public BusinessContact saveBusinessContactAddress(String businessContactId, Address address) {
        BusinessContact businessContact;
        if (businessContactId != null && !businessContactId.isEmpty()) {
            businessContact = microservice.getBusinessContactById(businessContactId);
        } else {
            throw new ApplicationException(BUSINESS_CONTACT_DOES_NOT_EXIST_MESSAGE_STRING);
        }

        businessContact.address = address;
        return microservice.saveBusinessContact(businessContact);
    }

    public BusinessContact saveBusinessContactServices(String id, List<Services> services) {
        BusinessContact businessContact = microservice.saveBusinessContactServices(id, services);
        workOrderService.updateAssignmentEstimatedLaborCost(businessContact);
        assetScheduleService.updateScheduleBusinessContact(businessContact);
        return businessContact;
    }

    public void deleteBusinessContact(String id) {
        microservice.deleteBusinessContact(id);
    }

    public List<BusinessContact> getBusinessContactByName(String name) {
        if (StringUtil.isEmptyOrNull(name)) {
            throw new ApplicationException("Name is required");
        }

        CurrentUser currentUser = getCurrentUser();
        List<BusinessContact> businessContacts;

        if (currentUser.profile.currentNodeRef.id.equals(DEV_ORG_ID)) {
            businessContacts = microservice.getBusinessContactByName(name);
        } else {
            businessContacts = microservice.getBusinessContactByNameAndScope(name);
        }
        return businessContacts;
    }

    public List<BusinessContact> findContacts(String searchString, String specificSkill, String specificType,
            List<String> searchFields) {

        FindContactsQuery findContactsQuery = new FindContactsQuery();
        findContactsQuery.searchString = searchString;
        findContactsQuery.specificSkill = specificSkill;
        findContactsQuery.specificTypes.add(specificType);
        findContactsQuery.searchFields = searchFields;

        return microservice.findContacts(findContactsQuery);
    }

    public List<EMenuSelectionFields> getSearchFields(List<String> excludedSearchFields) {
        List<EMenuSelectionFields> returnList = new ArrayList<>();

        for (EMenuSelectionFields selectionField : EMenuSelectionFields.values()) {
            if (!excludedSearchFields.contains(selectionField.label)) {
                returnList.add(selectionField);
            }
        }

        return returnList;
    }

    public List<BusinessContactSearch> getAllBusinessContactsSearch(SearchInput searchInput) {
        if (StringUtil.isEmptyOrNull(searchInput.searchText) || searchInput.searchText.trim().length() < 3) {
            throw new ApplicationException("Search criteria must be at least 3 characters");
        }

        organizationService.setRPFuncFilterInSearch(searchInput);
        SearchResult<BusinessContact> searchResults = microservice.getBusinessContactsBySearch(searchInput);

        List<BusinessContactSearch> businessContactSearches = new ArrayList<>();
        if (searchResults.results != null) {
            for (BusinessContact businessContact : searchResults.results) {
                businessContactSearches.add(convertBusinessContactToBusinessContactSearch(businessContact));
            }
        }
        return businessContactSearches;
    }

    public List<BusinessContactSearch> getAllBusinessContactsByStatus(String selectedStatus) {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        List<BusinessContact> businessContacts;

        if (currentUser.profile.currentNodeRef.id.equals(DEV_ORG_ID)) {
            businessContacts = microservice.getAllBusinessContacts(selectedStatus);
        } else {
            businessContacts = microservice.getAllBusinessContactsByScope(selectedStatus);
        }

        List<BusinessContactSearch> businessContactSearches = new ArrayList<>();
        if (businessContacts != null) {
            for (BusinessContact businessContact : businessContacts) {
                businessContactSearches.add(convertBusinessContactToBusinessContactSearch(businessContact));
            }
        }
        return businessContactSearches;
    }

    private BusinessContactSearch convertBusinessContactToBusinessContactSearch(BusinessContact businessContact) {
        BusinessContactSearch search = new BusinessContactSearch();
        search.allContactNames = new ArrayList<>();
        search.allContactPhoneNumbers = new ArrayList<>();
        search.allContactDivisions = new ArrayList<>();
        Contact primaryContact = getPrimaryContact(businessContact);
        if (businessContact.contacts != null) {
            businessContact.contacts.sort((o1, o2) -> o1.lastName.toUpperCase().compareTo(o2.lastName.toUpperCase()));
        }
        if (primaryContact != null) {
            search.division = getPrimaryContactDivision(primaryContact);
            search.contactName = getPrimaryContactName(primaryContact);
            search.phoneNumber = getPrimaryContactPhoneNumber(primaryContact);
            search.allContactNames.add(search.contactName);
            if (search.phoneNumber != null) {
                search.allContactPhoneNumbers.add(search.phoneNumber.value);
            } else
                search.allContactPhoneNumbers.add("");
            search.allContactDivisions.add(search.division);
        }
        // BusinessContact
        search.id = businessContact.getId();
        search.name = businessContact.name;
        search.types = businessContact.types;
        search.address = getBusinessContactAddress(businessContact);
        search.phoneNumber = getPrimaryContactPhoneNumber(primaryContact);
        search.managedBy = businessContact.managedByNodeRef.name;
        search.isActive = businessContact.isActive;
        for (Contact contact : businessContact.contacts) {
            if (Boolean.FALSE.equals(contact.isPrimary)) {
                if (!contact.isDeleted) {
                    search.allContactNames.add(String.join(" ", contact.firstName, contact.lastName));
                    if (contact.phoneNumbers != null && !contact.phoneNumbers.isEmpty()) {
                        for (PhoneNumber phoneNumber : contact.phoneNumbers) {
                            if (!StringUtil.isEmptyOrNull(phoneNumber.value)){
                                search.allContactPhoneNumbers.add(phoneNumber.value);
                            }
                        }
                    } else {
                        search.allContactPhoneNumbers.add("");
                    }
                    search.allContactDivisions.add(contact.division);
                }
            }
        }

        if (Boolean.TRUE.equals(businessContact.isActive)) {
            search.status = "Active";
        } else {
            search.status = "Inactive";
        }
        return search;
    }

    private Contact getPrimaryContact(BusinessContact businessContact) {
        for (Contact contact : businessContact.contacts) {
            if (!contact.isDeleted) {
                if (Boolean.TRUE.equals(contact.isPrimary)) {
                    return contact;
                }
            }
        }
        return null;
    }

    private String getPrimaryContactName(Contact contact) {
        if (contact != null) {
            return String.join(" ", contact.firstName, contact.lastName);
        }
        return "";
    }

    private String getBusinessContactAddress(BusinessContact businessContact) {
        if (businessContact.address != null) {
            return businessContact.address.getAsSingleLineString();
        }
        return "";
    }

    private PhoneNumber getPrimaryContactPhoneNumber(Contact contact) {
        if (null != contact && contact.phoneNumbers != null && !contact.phoneNumbers.isEmpty()) {
            return contact.phoneNumbers.get(0);
        }
        return null;
    }

    private String getPrimaryContactDivision(Contact contact) {
        if (contact != null) {
            return contact.division;
        }
        return "";
    }

    public List<BusinessContact> getBusinessContactByType(List<String> types) {
        return getBusinessContactsByTypesAndSkill(types, null);
    }

    public List<BusinessContact> getBusinessContactsByTypesAndSkill(List<String> types, String skillId) {
        if (types == null || types.isEmpty()) {
            throw new ApplicationException("Types are required");
        }

        CurrentUser currentUser = currentUserBT.getCurrentUser();
        List<BusinessContact> businessContacts;

        FindContactsQuery query = new FindContactsQuery();
        query.specificTypes = types;
        query.specificSkill = skillId;

        if (currentUser.profile.currentNodeRef.id.equals(DEV_ORG_ID)) {
            businessContacts = microservice.getBusinessContactsByTypesAndSkill(query);
        } else {
            businessContacts = microservice.getBusinessContactByTypeAndScope(query);
        }
        return businessContacts;
    }

    public List<BusinessContact> getBusinessContactBySkill(String skill) {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        List<BusinessContact> businessContacts;
        if (currentUser.profile.currentNodeRef.id.equals(DEV_ORG_ID)) {
            businessContacts = microservice.getBusinessContactBySkill(skill);
        } else {
            businessContacts = microservice.getBusinessContactBySkillScope(skill);
        }

        return businessContacts;
    }

    public List<BusinessContact> getBusinessContactsForQualityAssurance() {
        return microservice.getBusinessContactsForQualityAssurance();
    }

    public BusinessContact setBusinessContactInActive(String id, Boolean status) {
        return microservice.setBusinessContactInActive(id, status);
    }

    public void updateOrgRefsInBusinessContact(OrganizationRef organizationRef) {
        microservice.updateOrgRefsInBusinessContact(organizationRef);
    }

    public BusinessContact saveNote(String id, Note note) {
        return microservice.saveNote(id, note);
    }

    public BusinessContact removeNote(String id, Note note) {
        return microservice.removeNote(id, note);
    }

    public List<String> getBusinessContactTypes() {
        return EBusinessContactType.getDisplayTextList();
    }

    public BusinessContact createCOBieContact(COBieContactImportSummary cobieContactImportSummary) {
        BusinessContact businessContact = buildBusinessContactFromCOBieData(cobieContactImportSummary);
        List<BusinessContact> contacts = microservice.getBusinessContactByName(businessContact.name);
        if (contactAlreadyExists(contacts, businessContact)) {
            microservice.saveBusinessContact(businessContact);
        } else {
            microservice.createNewBusinessContact(businessContact);
        }
        return businessContact;
    }

    public BulkUpdateResult createCOBieContacts(List<COBieContactImportSummary> cobieContactImportSummaries) {
        BulkUpdateResult results = new BulkUpdateResult();

        for (COBieContactImportSummary cobieContactImportSummary : cobieContactImportSummaries) {
            try {
                createCOBieContact(cobieContactImportSummary);
                results.succeedItems.add(cobieContactImportSummary.getId());
            } catch (ApplicationException e) {
                logger.error(e);
                FailedItem failedItem = new FailedItem();
                failedItem.id = cobieContactImportSummary.getId();
                failedItem.errorMsg = e.getMessage();
                results.failedItems.add(failedItem);
            }
        }

        return results;
    }

    private BusinessContact buildBusinessContactFromCOBieData(COBieContactImportSummary cobieContactImportSummary) {
        BusinessContact businessContact = new BusinessContact();

        if (!StringUtil.isEmptyOrNull(cobieContactImportSummary.organizationName)) {
            businessContact.name = cobieContactImportSummary.organizationName;
        } else {
            throw new ApplicationException("Business Name is required.");
        }

        if (cobieContactImportSummary.managedByNodeRef != null) {
            businessContact.managedByNodeRef = cobieContactImportSummary.managedByNodeRef;
            businessContact.scopeNodeRefs.add(businessContact.managedByNodeRef);
        } else {
            throw new ApplicationException("Unknown Managed By Node.");
        }

        updateTypes(cobieContactImportSummary, businessContact);

        businessContact.isActive = true;
        businessContact.isQualityAssuranceOrganization = false;

        updateAddress(cobieContactImportSummary, businessContact);
        updateContact(cobieContactImportSummary, businessContact);

        return businessContact;
    }

    protected void updateTypes(COBieContactImportSummary cobieContactImportSummary, BusinessContact businessContact) {
        businessContact.types = new ArrayList<>();
        for (EBusinessContactType contactType : EBusinessContactType.values()) {
            if (contactType.displayText.equalsIgnoreCase(cobieContactImportSummary.organizationTypeName)) {
                businessContact.types.add(contactType);
            }
        }

        if (businessContact.types.isEmpty()) {
            throw new ApplicationException("Unknown Business Type.");
        }
    }

    protected void updateContact(COBieContactImportSummary cobieContactImportSummary, BusinessContact businessContact) {
        Contact contact = new Contact();

        if (!StringUtil.isEmptyOrNull(cobieContactImportSummary.pocFirstName)) {
            contact.firstName = cobieContactImportSummary.pocFirstName;
        } else {
            throw new ApplicationException("First Name is required.");
        }

        if (!StringUtil.isEmptyOrNull(cobieContactImportSummary.pocLastName)) {
            contact.lastName = cobieContactImportSummary.pocLastName;
        } else {
            throw new ApplicationException("Last Name is required.");
        }
        contact.email = cobieContactImportSummary.orgEmail != null ? cobieContactImportSummary.orgEmail : "";
        contact.division = cobieContactImportSummary.division != null ? cobieContactImportSummary.division : "";
        contact.isPrimary = true;

        contact.phoneNumbers = new ArrayList<>();
        PhoneNumber phoneNumber = new PhoneNumber();
        phoneNumber.value = cobieContactImportSummary.phoneNumber != null ? cobieContactImportSummary.phoneNumber : "";
        phoneNumber.phoneNumberType = EPhoneNumberType.WORK;
        contact.phoneNumbers.add(phoneNumber);
        PhoneNumber faxNumber = new PhoneNumber();
        faxNumber.value = cobieContactImportSummary.faxNumber != null ? cobieContactImportSummary.faxNumber : "";
        faxNumber.phoneNumberType = EPhoneNumberType.FAX;
        contact.phoneNumbers.add(faxNumber);

        businessContact.contacts = new ArrayList<>();
        businessContact.contacts.add(contact);
    }

    protected void updateAddress(COBieContactImportSummary cobieContactImportSummary, BusinessContact businessContact) {
        businessContact.address = new Address();
        businessContact.address.city = cobieContactImportSummary.city != null ? cobieContactImportSummary.city : "";
        businessContact.address.country = cobieContactImportSummary.country != null ? cobieContactImportSummary.country
                : "";
        businessContact.address.line1 = cobieContactImportSummary.streetAddressLine1 != null
                ? cobieContactImportSummary.streetAddressLine1
                : "";
        businessContact.address.line2 = cobieContactImportSummary.streetAddressLine2 != null
                ? cobieContactImportSummary.streetAddressLine2
                : "";
        businessContact.address.state = cobieContactImportSummary.state != null ? cobieContactImportSummary.state : "";
        businessContact.address.zip = cobieContactImportSummary.zipCode != null ? cobieContactImportSummary.zipCode
                : "";
    }

    protected boolean contactAlreadyExists(List<BusinessContact> contacts, BusinessContact contact) {
        boolean alreadyExists = false;
        if ((!contacts.isEmpty()) && (!Objects.isNull(contact.name)) &&
            (!Objects.isNull(contact.managedByNodeRef)) &&
            (!Objects.isNull(contact.managedByNodeRef.name))) {
            for (BusinessContact existingContact : contacts) {
                if ((!Objects.isNull(existingContact.managedByNodeRef)) &&
                    (!Objects.isNull(existingContact.managedByNodeRef.name)) &&
                    (contact.name.equalsIgnoreCase(existingContact.name)) && 
                    (contact.managedByNodeRef.name.equalsIgnoreCase(existingContact.managedByNodeRef.name))) {
                    contact._id = existingContact._id;
                    contact.contacts = mergeContacts(existingContact.contacts, contact.contacts);
                    contact.types = mergeTypes(existingContact.types, contact.types);
                    alreadyExists = true;
                    break;
                }
            }
        }
        return alreadyExists;
    }

    protected List<Contact> mergeContacts(List<Contact> contacts1, List<Contact> contacts2) {
        List<Contact> merged = new ArrayList<>();
        merged.addAll(contacts1);
        for (Contact contact : contacts2) {
            Contact foundContact = findContactByName(merged, contact);
            if (Objects.isNull(foundContact)) {
                merged.add(contact);
            } else {
                updateExistingContact(foundContact, contact);
            }
        }
        updatePrimaryFlags(merged);
        return merged;
    }

    protected void updatePrimaryFlags(List<Contact> merged) {
        boolean foundPrimary = false;
        for (Contact contact: merged) {
            if (contact.isPrimary == Boolean.TRUE) {
                if (!foundPrimary) {
                    foundPrimary = true;
                } else {
                    contact.isPrimary = false;
                }
            }
        }
        if (!foundPrimary) {
            merged.get(0).isPrimary = true;
        }
    }

    protected List<EBusinessContactType> mergeTypes(List<EBusinessContactType> types1, List<EBusinessContactType> types2) {
        List<EBusinessContactType> merged = new ArrayList<>();
        merged.addAll(types1);
        for (EBusinessContactType type : types2) {
            if (!merged.contains(type)) {
                merged.add(type);
            }
        }
        return merged;
    }

    protected Contact findContactByName(List<Contact> list, Contact contact) {
        Contact foundContact = null;
        if ((!Objects.isNull(contact.firstName)) && (!Objects.isNull(contact.lastName))) {
            for (Contact c : list) {
                if ((c.firstName.equalsIgnoreCase(contact.firstName)) &&
                    (c.lastName.equalsIgnoreCase(contact.lastName))) {
                    foundContact = c;
                    break;
                }
            }
        }
        return foundContact;
    }

    protected void updateExistingContact(Contact dest, Contact source) {
        dest.email = source.email;
        dest.division = source.division;
        for (PhoneNumber phoneNumber : source.phoneNumbers) {
            if (Objects.isNull(findPhoneNumber(dest.phoneNumbers, phoneNumber))) {
                dest.phoneNumbers.add(phoneNumber);
            }
        }
    }

    protected PhoneNumber findPhoneNumber(List<PhoneNumber> phoneNumbers, PhoneNumber phoneNumber) {
        PhoneNumber foundPhoneNumber = null;
        for (PhoneNumber pn : phoneNumbers) {
            if ((pn.phoneNumberType == phoneNumber.phoneNumberType) &&
                (pn.value.equalsIgnoreCase(phoneNumber.value))) {
                foundPhoneNumber = pn;
                break;
            }
        }
        return foundPhoneNumber;
    }
    
    boolean isManagedByNodeRPFuncEnabled(String nodeId) {
    	return organizationService.isNodeRPFuncEnabled(nodeId);
    }
}
