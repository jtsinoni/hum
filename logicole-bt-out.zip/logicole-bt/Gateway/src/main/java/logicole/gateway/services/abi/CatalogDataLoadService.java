package logicole.gateway.services.abi;

import logicole.apis.abi.ICatalogDataLoadMicroserviceApi;
import logicole.common.datamodels.abi.*;
import logicole.common.datamodels.abi.item.CatalogImportData;
import logicole.common.datamodels.abi.item.IItemTaskRequestDetailCallback;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.abi.staging.AbiCatalogRecord;
import logicole.common.datamodels.abi.types.EnterpriseProductIdentifierTypeConstants;
import logicole.common.datamodels.asset.classification.Nomenclature;
import logicole.common.datamodels.catalog.Catalog;
import logicole.common.datamodels.catalog.EnterpriseSourcing;
import logicole.common.datamodels.catalog.MasterCatalogs;
import logicole.common.datamodels.finance.referencedata.CommodityCode;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.buyer.BuyerDTO;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.ServiceProviderRef;
import logicole.common.datamodels.product.*;
import logicole.common.datamodels.sale.seller.BuyerSellerAccount;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountDTO;
import logicole.common.datamodels.sale.seller.Seller;
import logicole.common.datamodels.sale.seller.SellerType;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.util.EDateTimeFormat;
import logicole.common.general.util.ObjectMapper;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemCatalogImportDataService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.abi.referencedata.PackageUnitService;
import logicole.gateway.services.asset.AssetClassificationService;
import logicole.gateway.services.catalog.CatalogLookupService;
import logicole.gateway.services.catalog.CatalogService;
import logicole.gateway.services.catalog.EnterpriseSourcingService;
import logicole.gateway.services.equipment.EquipmentRecordService;
import logicole.gateway.services.finance.FinanceAdminService;
import logicole.gateway.services.finance.FinanceReferenceDataService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.order.OrderService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.product.ProductService;
import logicole.gateway.services.sale.SellerService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@ApplicationScoped
public class CatalogDataLoadService extends BaseGatewayService<ICatalogDataLoadMicroserviceApi> {

    @Inject
    ProductService productService;
    @Inject
    AbiCatalogService abiCatalogService;
    @Inject
    SellerService sellerService;
    @Inject
    BuyerService buyerService;
    @Inject
    OrderService orderService;
    @Inject
    OrganizationService organizationService;
    @Inject
    PackageUnitService packageUnitService;
    @Inject
    ItemService itemService;
    @Inject
    CatalogLookupService catalogLookupService;
    @Inject
    FinanceAdminService financeAdminService;
    @Inject
    FinanceReferenceDataService financeReferenceDataService;
    @Inject
    EquipmentRecordService equipmentRecordService;
    @Inject
    private EnterpriseSourcingService enterpriseSourcingService;
    @Inject
    private CatalogService catalogService;
    @Inject
    private EnterpriseCatalogLookupService enterpriseCatalogLookupService;
    @Inject
    private AssetClassificationService assetClassificationService;
    @Inject
    private ItemCatalogImportDataService itemCatalogImportDataService;
    @Inject
    private ObjectMapper mapper;

    public CatalogDataLoadService() {
        super("Catalog");
    }

    //Utility function
    public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
        Map<Object, Boolean> map = new ConcurrentHashMap<>();
        return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public void buildItemFromSiteCatalog(String dodaac) {

        List<SiteCatalogRecord> recordList1 = productService.getSiteCatalogByCommType(dodaac, "S");
        for (SiteCatalogRecord siteCatalogRecord : recordList1) {
            // Skip the deleted record now.
            if (!siteCatalogRecord.deleteInd.equals("Y")) {
                buildItem(siteCatalogRecord);
            }

        }


        List<SiteCatalogRecord> recordList = productService.getSiteCatalogByCommType(dodaac, "P");
        for (SiteCatalogRecord siteCatalogRecord : recordList) {
            // Skip the deleted record now.
            if (!siteCatalogRecord.deleteInd.equals("Y")) {
                buildItem(siteCatalogRecord);
            }

        }


        List<SiteCatalogRecord> recordList2 = productService.getSiteCatalogByCommType(dodaac, "M");
        for (SiteCatalogRecord siteCatalogRecord : recordList2) {
            // Skip the deleted record now.
            if (!siteCatalogRecord.deleteInd.equals("Y")) {
                buildItem(siteCatalogRecord);
            }

        }

        List<SiteCatalogRecord> recordList3 = productService.getSiteCatalogByCommType(dodaac, "R");
        for (SiteCatalogRecord siteCatalogRecord : recordList3) {
            // Skip the deleted record now.
            if (!siteCatalogRecord.deleteInd.equals("Y")) {
                buildItem(siteCatalogRecord);
            }

        }

        List<SiteCatalogRecord> recordList4 = productService.getSiteCatalogByCommType(dodaac, "V");
        for (SiteCatalogRecord siteCatalogRecord : recordList4) {
            // Skip the deleted record now.
            if (!siteCatalogRecord.deleteInd.equals("Y")) {
                buildItem(siteCatalogRecord);
            }

        }


    }

    public void buildItemFromEquipmentRecords(String dodaac) {
        List<DmlssLink> dmlssLinkList = equipmentRecordService.getECRIEquipItems(dodaac);
        List<SiteCatalogRecord> recordList1 = productService.getSiteCatalogByCommType(dodaac, "Q");
        for (SiteCatalogRecord siteCatalogRecord : recordList1) {
            // Skip the deleted record now.
            if (!siteCatalogRecord.deleteInd.equals("Y")) {

                List<DmlssLink> dmlssLinks = dmlssLinkList.stream().filter(c -> c.itemSerial.equals(siteCatalogRecord.itemSerial)).collect(Collectors.toList());
                if (dmlssLinks.isEmpty()) {
                    if (!StringUtil.isEmptyOrNull(dmlssLinks.get(0).enterpriseProductIdentifier)) {
                        siteCatalogRecord.enterpriseProductIdentifier = dmlssLinks.get(0).enterpriseProductIdentifier;
                    }
                }

                buildItem(siteCatalogRecord);
            }

        }

    }


    public void buildItem(SiteCatalogRecord siteCatalogRecord) {

        boolean customerPreferred = false;
        boolean logPreferred = false;
        boolean itemPersisted = true;

        Item item = new Item();

        String dmlssKey = siteCatalogRecord.siteDodaac + ".1000";
        Organization siteOrg = organizationService.findByDmlssKey(dmlssKey);
        Organization organization = organizationService.findByParentIdAndNodeIdentifier(siteOrg.getId(), siteCatalogRecord.siteDodaac);
//        organization orgt = organizationService.getOrganizationByTypeRefAndOrgName()
        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(organization.getId());
        Organization logicoleOrg = organizationService.getOrganization(OrganizationConstants.ROOT_ORG_ID);

        if (!StringUtil.isEmptyOrNull(siteCatalogRecord.enterpriseProductIdentifier)) {
            item = itemService.getByEnterpriseProductIdentifier(siteCatalogRecord.enterpriseProductIdentifier);
        }


        if ((item != null && StringUtil.isEmptyOrNull(item.enterpriseProductIdentifier)) || item == null) {
            if (item == null) {
                item = new Item();
            }

            if (!siteCatalogRecord.commType.equals("Q")) {

                if (!StringUtil.isEmptyOrNull(siteCatalogRecord.ndc)) {
                    item.enterpriseProductIdentifier = siteCatalogRecord.ndc;
                    item.productType = "NDC";
                    item.ndc = siteCatalogRecord.ndc;
                    item.enterpriseProductIdentifierType = EnterpriseProductIdentifierTypeConstants.NDC;

                } else if (!StringUtil.isEmptyOrNull(siteCatalogRecord.manufCatNum)) {

                    item.enterpriseProductIdentifier = enterpriseCatalogLookupService.getProvisionalEPI(siteCatalogRecord.manufacturerNm, siteCatalogRecord.manufCatNum);
                    item.enterpriseProductIdentifierType = EnterpriseProductIdentifierTypeConstants.Provisional;
                    item.productType = null;

                } else {
                    item.enterpriseProductIdentifier = siteCatalogRecord.enterpriseItemIdentifier;
                    item.productType = null;
                }
            } else {
                item.enterpriseProductIdentifier = siteCatalogRecord.enterpriseItemIdentifier;
                item.productType = null;
            }

            item.shortItemDescription = siteCatalogRecord.shortItemDesc;
            switch (siteCatalogRecord.commType) {
                case "Q":
                    item.commodityType = "Equipment";
                    break;
                case "R":
                case "S":
                    item.commodityType = "Med/Surg";
                    break;
                case "P":
                    item.commodityType = "Pharmaceutical";
                    break;
                default:
                    item.commodityType = "Other";
            }

            item.longItemDescription = siteCatalogRecord.longItemDesc;

            if (!StringUtil.isEmptyOrNull(siteCatalogRecord.manufacturerNm)) {
                item.manufacturer = siteCatalogRecord.manufacturerNm;
            } else {
                item.manufacturer = "NOT PROVIDED";
            }

            item.deviceCode = siteCatalogRecord.deviceCd;
            item.deviceClassCode = siteCatalogRecord.deviceClassCode;
            item.deviceClassText = siteCatalogRecord.deviceClassText;
            item.deviceText = siteCatalogRecord.deviceText;
            item.productStatus = "Active";


            item.manufacturerCatalogNumber = siteCatalogRecord.manufCatNum;
            item.hazardCode = siteCatalogRecord.hazardousMaterialInd;
            item.productUrl = siteCatalogRecord.webSite;
            item.managedByNodeRef = siteOrg.getRef();
            item.catalogSource = CatalogSourceConstants.CATALOG;


            if (!StringUtil.isEmptyOrNull(siteCatalogRecord.deviceCd)) {
                List<Nomenclature> nomenclatureList = assetClassificationService.getNomenclaturesByCode(siteCatalogRecord.deviceCd);
                if (nomenclatureList.size() > 0) {
                    item.nomenclatureRefList.add(nomenclatureList.get(0).getRef());
                }
            }

            List<Source> sourceList = siteCatalogRecord.sources;
            LinkedHashSet<PackagingDetail> packages = new LinkedHashSet<>();
            for (Source source : sourceList) {
                List<Packaging> packagingList = source.packaging;
                for (Packaging packaging : packagingList) {
                    PackagingDetail packagingDetail = new PackagingDetail();
                    packagingDetail.packageUnit = packaging.ipPackCd;
                    packagingDetail.packageQuantity = packaging.ipPackQty;
                    packagingDetail.gtin = packaging.ipGtin;
                    packagingDetail.nsn.add(packaging.nsn);
                    PackageUnit packageUnit = packageUnitService.getPackageUnitByDodPackUnit(packaging.ipPackCd);
                    if (packageUnit != null) {
                        packagingDetail.packageUnitText = packageUnit.packText;
                    }
                    packagingDetail.packageUnitDescription = Objects.requireNonNull(packageUnit).packText + " of " + packaging.ipPackQty;
                    packagingDetail.packCubeUomCd = packaging.packCubeUomCd;
                    packagingDetail.packCubeVol = packaging.packCubeVol;
                    packagingDetail.packLengthDm = packaging.packLengthDm;
                    packagingDetail.packLengthUomCd = packaging.packLengthUomCd;
                    packagingDetail.packGrossWeight = packaging.packGrossWeight;
                    packagingDetail.packGrossWeightUomCd = packaging.packGrossWeightUomCd;
                    packagingDetail.packHeightDm = packaging.packHeightDm;
                    packagingDetail.packHeightUomCd = packaging.packHeightUomCd;
                    packagingDetail.packWidthDm = packaging.packWidthDm;
                    packagingDetail.packWidthUomCd = packaging.packWidthUomCd;
                    packages.add(packagingDetail);
                }
            }

            List<PackagingDetail> uniquePackages = new ArrayList<>(packages);
            item.packaging = uniquePackages.stream().filter(distinctByKey(p -> p.packageQuantity)).collect(Collectors.toList());
        }

//        } else {
//            List<Source> sourceList = siteCatalogRecord.sources;
//            for (Source source : sourceList) {
//                List<Packaging> packagingList = source.packaging;
//                for (Packaging packaging : packagingList) {
//                    PackagingDetail packagingDetail = itemService.getPackagingFromItem(item, packaging.ipPackQty);
//                    if (!StringUtil.isEmptyOrNull(packaging.packCubeUomCd) || !StringUtil.isEmptyOrNull(packaging.packLengthUomCd) ||
//                            !StringUtil.isEmptyOrNull(packaging.packHeightUomCd) || !StringUtil.isEmptyOrNull(packaging.packWidthUomCd)) {
//                        int index = item.packaging.indexOf(packagingDetail);
//                        packagingDetail.packCubeUomCd = packaging.packCubeUomCd;
//                        packagingDetail.packCubeVol = packaging.packCubeVol;
//                        packagingDetail.packLengthDm = packaging.packLengthDm;
//                        packagingDetail.packLengthUomCd = packaging.packLengthUomCd;
//                        packagingDetail.packGrossWeight = packaging.packGrossWeight;
//                        packagingDetail.packGrossWeightUomCd = packaging.packGrossWeightUomCd;
//                        packagingDetail.packHeightDm = packaging.packHeightDm;
//                        packagingDetail.packHeightUomCd = packaging.packHeightUomCd;
//                        packagingDetail.packWidthDm = packaging.packWidthDm;
//                        packagingDetail.packWidthUomCd = packaging.packWidthUomCd;
//                        item.packaging.set(index, packagingDetail);
//                    }
//                }
//            }
//
//        }


        logger.info(siteCatalogRecord.getId());
        if (siteCatalogRecord.productSeqId != null) {
            item.mmcProductIdentifiers.add(siteCatalogRecord.productSeqId);
        }

        DmlssLink dmlssInfo = new DmlssLink();
        dmlssInfo.enterpriseItemIdentifier = siteCatalogRecord.enterpriseItemIdentifier;

        if (siteCatalogRecord.productSeqId != null) {
            dmlssInfo.mmcProductIdentifier = siteCatalogRecord.productSeqId;
        }
//        if (!StringUtil.isEmptyOrNull(siteCatalogRecord.ciiCd)) {
//            item.controlledInventoryItemCodeRef = catalogLookupService.getItemControlledInventoryCode(siteCatalogRecord.ciiCd).getRef();
//        }

        dmlssInfo.itemSerial = siteCatalogRecord.itemSerial;
        item.dmlssLinks.add(dmlssInfo);

//        List<ItemRestriction> itemRestrictionList = siteCatalogRecord.itemRestrictions;
//        for (ItemRestriction itemRestriction : itemRestrictionList) {
//            Restriction itemRestriction1 = itemService.getItemRestriction(itemRestriction.restrictCd, itemRestriction.restrictType, itemRestriction.restrictDescription);
//            item.restrictionRefList.add(itemRestriction1.getRef());
//        }
//
//        List<ItemDestruction> itemDestructionList = siteCatalogRecord.itemDestruction;
//        for (ItemDestruction itemDestruction : itemDestructionList) {
//            Destruction destruction = catalogLookupService.getItemDestruction(itemDestruction.destructCd, itemDestruction.destructDesc);
//            item.destructionRefList.add(destruction.getRef());
//        }
//        if (siteCatalogRecord.commType.equals("Q")) {
//            if (!StringUtil.isEmptyOrNull(siteCatalogRecord.enterpriseProductIdentifier)) {
//                updateItem = microservice.updateItem(item);
//            } else {
//                updateItem = item;
//                itemPersisted = false;
//            }
//        } else {
//        }

        Item updateItem;
        updateItem = microservice.updateItem(item);

        String commodityNm = StringUtil.convertToTitleCaseIteratingChars(siteCatalogRecord.commodityClsNm);
        //commodityNm = StringUtil.convertToTitleCaseIteratingChars(commodityNm);
        CommodityCodeRef commodityCodeRef = new CommodityCodeRef();

        List<CommodityCode> commodityCodes = financeReferenceDataService.getCommodityCodesByName(financialSystem.getId(), commodityNm);

        if (commodityCodes.size() == 0) {
            commodityCodes = financeAdminService.getCommodityByFinancialSystemType(financialSystem.getId(), "Supply");
        }
        if (commodityCodes.size() > 0) {
            commodityCodeRef = commodityCodes.get(0).getRef();
        }

        List<Source> sourceList = siteCatalogRecord.sources;
        boolean legacySos;
        for (Source source : sourceList) {
            String sellerName = "";
            if (source.sosTypeCd.equals("LOG") || source.sosTypeCd.equals("CAI")) {
                sellerName = source.supplierNm + " - " + siteCatalogRecord.siteDodaac;
            } else {
                DmlssSupplier dmlssSupplier = productService.getDmlssSupplier(siteCatalogRecord.siteDodaac, source.sosCd);
                if (dmlssSupplier != null) {
                    if (!StringUtil.isEmptyOrNull(dmlssSupplier.logicoleSupplierName)) {
                        sellerName = dmlssSupplier.logicoleSupplierName;
                    } else {
                        sellerName = dmlssSupplier.dmlssSosSupplierName;
                    }
                }
            }
            if (StringUtil.isEmptyOrNull(sellerName)) {
                sellerName = source.supplierNm + " - " + source.sosCd + " - " + siteCatalogRecord.siteDodaac;
            }

            Seller seller;
            if (source.sosTypeCd.equals("LOG")) {
                seller = sellerService.getSellerForOrganizationIdentifier(organization.getId());
            } else {
                seller = sellerService.getSellerByName(sellerName);
            }

            if (seller == null) {
                Seller seller1 = new Seller();
                seller1.sellerName = sellerName;
                SellerType sellerType = sellerService.getSellerTypeByType(source.sosTypeCd);
                seller1.sellerTypeRef = sellerType.getRef();
                if (source.sosTypeCd.equals("LOG") || source.sosTypeCd.equals("CAI")) {
                    seller1.isExternal = false;
                    seller1.organizationIdentifier = organization.getId();
                } else {
                    seller1.isExternal = true;
                }
                seller = sellerService.saveSeller(seller1);
            }

            List<CustomerCatalog> customerCatalogList = siteCatalogRecord.customerCatalogs;

            if (!seller.sellerTypeRef.sellerType.equals("LOG")) {
                // Add the site dodaac
                CustomerCatalog customerCatalog = new CustomerCatalog();
                customerCatalog.orgId = siteCatalogRecord.siteDodaac;
                customerCatalog.orgNm = siteCatalogRecord.siteName;
                customerCatalogList.add(customerCatalog);
            }

            legacySos = siteCatalogRecord.legacySosSerial.equals(source.sosSerial);

            List<Packaging> packagingList = source.packaging;

            // Build catalog record for once package+one source+one customer only.
            if (packagingList.size() > 0) {
                Packaging packaging = packagingList.get(0);
//            for (Packaging packaging : packagingList) {
                PackagingDetail packagingDetail = itemService.getPackagingFromItem(updateItem, packaging.ipPackQty);

                EnterpriseSourcing enterpriseSourcing = new EnterpriseSourcing();
                EnterpriseSourcing updatedEnterpriseSourcing;


                enterpriseSourcing.enterpriseProductIdentifier = updateItem.enterpriseProductIdentifier;
                enterpriseSourcing.gtin = packagingDetail.gtin;
                enterpriseSourcing.multipleOrderQuantity = packaging.multipleOrderQty;
                enterpriseSourcing.nsn = packaging.nsn;
                enterpriseSourcing.packageQuantity = packagingDetail.packageQuantity;
                enterpriseSourcing.packageUnit = packagingDetail.packageUnit;
                enterpriseSourcing.price = packaging.packPriceAmt;
                enterpriseSourcing.packageUnitText = packagingDetail.packageUnitText;
                enterpriseSourcing.packageUnitDescription = packagingDetail.packageUnitDescription;
//                    enterpriseSourcing.pricingAgreementIdentifier
//                    enterpriseSourcing.pricingAgreementType =
                enterpriseSourcing.sellerPackageQuantity = packaging.ipPackQty;
                enterpriseSourcing.sellerPackageUnit = packaging.ipPackCd;
                enterpriseSourcing.sellerProductIdentifier = source.vendItemNum;
                enterpriseSourcing.sellerProductIdentifierType = source.typeItemId;

                enterpriseSourcing.sellerRef = seller.getRef();

                enterpriseSourcing.enterpriseSourcingIdentifier = item.enterpriseProductIdentifier + "-" + packaging.ipPackCd + "-" + source.sosCd;

                if (source.productSourceSeqId != null && packaging.productSourcePriceSeqId != null) {
                    MasterCatalogs masterCatalogs = new MasterCatalogs();
                    masterCatalogs.mmcProductIdentifier = siteCatalogRecord.productSeqId;
                    masterCatalogs.mmcProductSourceIdentifier = source.productSourceSeqId;
                    masterCatalogs.mmcProductSourcePriceIdentifier = packaging.productSourcePriceSeqId;
                    enterpriseSourcing.masterCatalogs.add(masterCatalogs);
                }
//                if (!source.sosTypeCd.matches("NON|BPA|DBP|PCD|UNK|CON|EXT|SVC|CAI|HUB") && itemPersisted) {
//                    enterpriseSourcing.itemRef = updateItem.getRef();
//                    updatedEnterpriseSourcing = enterpriseSourcingService.saveEnterpriseSourcing(enterpriseSourcing);
//                } else {
                    updatedEnterpriseSourcing = enterpriseSourcing;
//                }

                List<Buyer> buyerList = buyerService.getBuyersForManagedByNodeIdentifier(siteCatalogRecord.siteDodaac);
                if (buyerList.size() > 0) {
                    for (Buyer buyer : buyerList) {
                        if (customerCatalogList.stream().anyMatch(c -> c.orgId.equals(buyer.nodeRef.nodeIdentifier))) {
                            Catalog catalog = new Catalog();
                            catalog.catalogItemIdentifier = siteCatalogRecord.itemId;
                            catalog.buyerRef = buyer.getRef();
                            catalog.itemRef = updateItem.getRef();
                            catalog.itemPackaging = itemService.getPackagingFromItem(updateItem, updatedEnterpriseSourcing.packageQuantity);
                            catalog.price = packaging.burdenedPriceAmt;
                            catalog.sellerPackageQuantity = updatedEnterpriseSourcing.packageQuantity;
                            catalog.sellerPackageUnit = updatedEnterpriseSourcing.packageUnit;
                            catalog.sellerRef = updatedEnterpriseSourcing.sellerRef;
                            catalog.sellerPackageUnitText = updatedEnterpriseSourcing.packageUnitText;
                            catalog.isPreferredSource = false;
                            catalog.shortDescription = updateItem.shortItemDescription;
                            catalog.longDescription = updateItem.longItemDescription;
                            catalog.catalogItemIdentifier = siteCatalogRecord.itemId;
                            if (!StringUtil.isEmptyOrNull(source.typeItemId)) {

                                catalog.sellerProductIdentifierType = source.typeItemId;
                            } else {
                                catalog.sellerProductIdentifierType = "MFG/PN";
                            }
                            if (!StringUtil.isEmptyOrNull(source.vendItemNum)) {
                                catalog.sellerProductIdentifier = source.vendItemNum;
                            } else {
                                catalog.sellerProductIdentifier = siteCatalogRecord.itemId;
                            }
                            catalog.isActive = true;

                            if (!StringUtil.isEmptyOrNull(commodityCodeRef.getId())) {
                                catalog.commodityCodeRef = commodityCodeRef;
                            }
                            if (buyer.nodeRef.nodeIdentifier.equals(organization.nodeIdentifier) && !StringUtil.isEmptyOrNull(packaging.priceEffDt)) {
                                try {
                                    catalog.priceEffectiveDate = EDateTimeFormat.TECH.parse(packaging.priceEffDt);
                                    catalog.priceExpireDate = EDateTimeFormat.TECH.parse(packaging.priceExpDt);
                                } catch (ParseException e) {
                                    logger.info("Price conversion error");
                                    catalog.priceEffectiveDate = null;
                                    catalog.priceExpireDate = null;
                                }
                            }
                            if (!buyer.nodeRef.nodeIdentifier.equals(organization.nodeIdentifier) && !updatedEnterpriseSourcing.sellerRef.isExternal && !customerPreferred) {
                                catalog.isPreferredSource = true;
                                customerPreferred = true;
                            }

                            if (legacySos && buyer.nodeRef.nodeIdentifier.equals(organization.nodeIdentifier) && !logPreferred) {
                                catalog.isPreferredSource = true;
                                logPreferred = true;
                            }
                            try {
                                catalogService.saveCatalogRecord(catalog);
                            } catch (Exception e) {
                                logger.info("CID:" + catalog.catalogItemIdentifier + " Error: " + e.getMessage());
                            }
                        }
                    }
                }
            }
        }
    }

    public void buildItemFromEnterpriseItemIdentifier(String enterpriseItemIdentifier) {
        SiteCatalogRecord siteCatalogRecord = productService.getSiteCatalogRecord(enterpriseItemIdentifier);
        buildItem(siteCatalogRecord);
    }

    public void buildItemFromEquipRecords(String siteDodaac, DmlssLink dmlssLink) {
        Item item = new Item();
        item.productStatus = "Active";
        if (!StringUtil.isEmptyOrNull(dmlssLink.enterpriseProductIdentifier)) {
            AbiCatalogRecord abiCatalogRecord = abiCatalogService.getAbiCatalogOrStagingRecordByEnterpriseProductIdentifier(dmlssLink.enterpriseProductIdentifier);
            if (abiCatalogRecord != null) {
                item = mapper.getObject(Item.class, abiCatalogRecord);
                item.enterpriseProductIdentifier = abiCatalogRecord.enterpriseProductIdentifier;
                item.productStatus = abiCatalogRecord.productStatus;
            }
        }
        item.dmlssLinks.add(dmlssLink);
        microservice.updateItem(item);
    }

    public void publishItemRefs() {
        itemService.sendItemRefs();
    }

    public void loadBusinesses() {
        microservice.loadBusinesses();
    }

    public void loadSiteBusinesses() {
        List<String> manufacturers = productService.getDistinctUnlinkedManufacturerNames();
        microservice.loadSiteBusinesses(manufacturers);
    }

    public void populateBusinessRefs() {
        microservice.populateBusinessRefs();
    }

    public void buildCatalogFromCatalogImport() {
        List<CatalogImportData> catalogImportDataList = itemCatalogImportDataService.getAllCatalogImportData();
        for (CatalogImportData catalogImportData : catalogImportDataList) {
            buildCatalogForVACustomers(catalogImportData);
        }

    }


    public void buildCatalogForVACustomers(CatalogImportData catalogImportData) {
        buildCatalogForVACustomers(catalogImportData, null, null);
    }

    public void buildCatalogForVACustomers(CatalogImportData catalogImportData, String requestId, IItemTaskRequestDetailCallback callback) {
        addInfo(requestId, callback, "Processing Import Data with Item Identifier '" + catalogImportData.itemId + "'.");
        Organization vaOrg = organizationService.getOrganizationByTypeRefIdAndOrgName(OrganizationConstants.AGENCY_ORG_TYPE_ID, "VA");
        List<OrganizationRef> vaCustomersRefList = organizationService.getOrganizationRefByTypeAndAncestryId(OrganizationConstants.CUSTOMER_ORG_TYPE_ID, vaOrg.getId());
        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(vaOrg.getId());
        addInfo(requestId, callback, "VA Customers Count: " + vaCustomersRefList.size());
        if (vaCustomersRefList.size() > 0) {
            for (OrganizationRef customerRef : vaCustomersRefList) {
                Buyer buyer = buyerService.getBuyerForNodeId(customerRef.getId());
                if (buyer == null) {
                    enableBusinessServices(customerRef, catalogImportData.supplierName);
                    buyer = buyerService.getBuyerForNodeId(customerRef.getId());
                }
                if (buyer != null) {
                    addInfo(requestId, callback, "Building Catalog Record for customer " + buyer.name);
                    Catalog catalog = populateCatalog(catalogImportData, buyer, financialSystem.getId(), requestId, callback);
                }
            }
        }
    }

    public void enableBusinessServices(OrganizationRef customerRef, String supplierName) {
        List<ServiceProviderRef> serviceProviderRefList = organizationService.getServiceProvidersAsRef();

        ServiceProviderRef catalogServiceProRef = serviceProviderRefList.stream().filter(serviceProviderRef -> serviceProviderRef.name.equals("Catalog")).findFirst().get();
        ServiceProviderRef customerServiceProRef = serviceProviderRefList.stream().filter(serviceProviderRef -> serviceProviderRef.name.equals("Customer")).findFirst().get();

        Organization organization = organizationService.getOrganization(customerRef.getId());
        if (organization.serviceProviderRefs.size() > 0) {
            if (organization.serviceProviderRefs.stream().noneMatch(serviceProviderRef -> serviceProviderRef.getId().equals(catalogServiceProRef.getId()))) {
                organization.serviceProviderRefs.add(catalogServiceProRef);
            }
            if (organization.serviceProviderRefs.stream().noneMatch(serviceProviderRef -> serviceProviderRef.getId().equals(customerServiceProRef.getId()))) {
                organization.serviceProviderRefs.add(customerServiceProRef);
            }
        } else {
            organization.serviceProviderRefs.add(catalogServiceProRef);
            organization.serviceProviderRefs.add(customerServiceProRef);
        }

        organization = organizationService.saveOrganization(organization);
        addRRCSuppliers(organization.getId(), supplierName);
    }


    public void addRRCSuppliers(String organizationId, String supplierName) {
        Buyer buyer = buyerService.getBuyerForNodeId(organizationId);
        Seller seller = sellerService.getSellerByName(supplierName);
        if (!Objects.isNull(buyer) && !Objects.isNull(seller)) {
            BuyerSellerAccount buyerSellerAccountExist = sellerService.getBuyerSellerAccountBySellerAndBuyerId(buyer.getId(), seller.getId());
            if (Objects.isNull(buyerSellerAccountExist)) {
                BuyerSellerAccountDTO buyerSellerAccount = new BuyerSellerAccountDTO();
                buyerSellerAccount.buyerId = buyer.getId();
                buyerSellerAccount.sellerId = seller.getId();
                sellerService.saveBuyerSellerAccount(buyerSellerAccount);
            }
        }

    }

    public Item getItem(CatalogImportData catalogImportData, OrganizationRef nodeRef) {
        Organization logicoleOrg = organizationService.getOrganization(OrganizationConstants.ROOT_ORG_ID);
        if (!StringUtil.isEmptyOrNull(catalogImportData.enterpriseProductIdentifier)) {
            Item item = itemService.getByEnterpriseProductIdentifier(catalogImportData.enterpriseProductIdentifier);

            if (item != null) {
                if (item.managedByNodeRef.getId().equals(logicoleOrg.getId()) || item.managedByNodeRef.getId().equals(nodeRef.getId())) {
                    return item;
                } else {
                    return null;
                }
            }
        }

        Item item = new Item();

        if (!StringUtil.isEmptyOrNull(catalogImportData.ndc)) {
            item.enterpriseProductIdentifier = catalogImportData.ndc;
            item.productType = "NDC";
            item.ndc = catalogImportData.ndc;
            item.enterpriseProductIdentifierType = EnterpriseProductIdentifierTypeConstants.NDC;

        } else if (!StringUtil.isEmptyOrNull(catalogImportData.manufacturerCatalogNumber)) {
            item.enterpriseProductIdentifier = enterpriseCatalogLookupService.getProvisionalEPI(catalogImportData.manufacturerName, catalogImportData.manufacturerCatalogNumber);
            item.enterpriseProductIdentifierType = EnterpriseProductIdentifierTypeConstants.Provisional;
            item.productType = null;

        } else {
            item.enterpriseProductIdentifier = catalogImportData.itemId;
            item.productType = null;
        }

        if (!StringUtil.isEmptyOrNull(catalogImportData.manufacturerName)) {
            item.manufacturer = catalogImportData.manufacturerName;
        } else {
            item.manufacturer = "NOT PROVIDED";
        }

        item.productStatus = "Active";
        item.manufacturerCatalogNumber = catalogImportData.manufacturerCatalogNumber;
        item.managedByNodeRef = nodeRef;
        item.catalogSource = CatalogSourceConstants.CATALOG;

        PackagingDetail packagingDetail = new PackagingDetail();
        packagingDetail.packageUnit = catalogImportData.ipPackCode;
        packagingDetail.packageQuantity = catalogImportData.ipPackQuantity;
        PackageUnit packageUnit = packageUnitService.getPackageUnitByDodPackUnit(catalogImportData.ipPackCode);
        if (packageUnit != null) {
            packagingDetail.packageUnitText = packageUnit.packText;
        }
        packagingDetail.packageUnitDescription = Objects.requireNonNull(packageUnit).packText + " of " + catalogImportData.ipPackQuantity;
        item.packaging.add(packagingDetail);

        Item updateItem;
        updateItem = microservice.updateItem(item);

        logger.info("populateCatalogNodeIdentifier:  EPI" + updateItem.enterpriseProductIdentifier + ": Item Id:" + updateItem.getId());
        return updateItem;
    }

    public Catalog populateCatalog(CatalogImportData catalogImportData, Buyer buyer, String financialSystemId) {
        return populateCatalog(catalogImportData, buyer, financialSystemId, null, null);
    }

    public Catalog populateCatalog(CatalogImportData catalogImportData, Buyer buyer, String financialSystemId,
                                   String requestId, IItemTaskRequestDetailCallback callback) {

        Item item = getItem(catalogImportData, buyer.managedByNodeRef);
        if (item == null) {
            addInfo(requestId, callback, "No item record found for " + buyer.managedByNodeRef.name);
            return null;
        }
        Seller seller = sellerService.getSellerByName(catalogImportData.supplierName);
        if (seller == null) {
            logger.info("populateCatalog: There is no seller information for :" + catalogImportData.supplierName);
            addInfo(requestId, callback, "No seller information for " + catalogImportData.supplierName);
            return null;
        }
        addRRCSuppliers(buyer.nodeRef.getId(), catalogImportData.supplierName);

        PackagingDetail itemPackaging = new PackagingDetail();

        if (!StringUtil.isEmptyOrNull(catalogImportData.abiPackCode)) {
            itemPackaging = itemService.getPackagingFromItemByPackUnit(item, catalogImportData.abiPackCode);
        }
        if (itemPackaging == null) {
            itemPackaging = itemService.getPackagingFromItem(item, catalogImportData.ipPackQuantity);
        }

        Catalog catalog = catalogService.getCatalogByUniqueKey(catalogImportData.itemId, seller.getId(), itemPackaging.packageUnit, buyer.getId());

        if (Objects.isNull(catalog)) {
            catalog = new Catalog();
            catalog.isPreferredSource = false;
            catalog.itemPackaging = itemPackaging;
        }
        catalog.catalogItemIdentifier = catalogImportData.itemId;
        catalog.buyerRef = buyer.getRef();
        catalog.sellerRef = seller.getRef();
        catalog.itemRef = item.getRef();
        catalog.price = catalogImportData.burdenedPriceAmount;
        catalog.itemPackaging = itemPackaging;
        catalog.sellerPackageQuantity = catalogImportData.ipPackQuantity;
        catalog.sellerPackageUnit = catalogImportData.ipPackCode;
        catalog.sellerPackageUnitText = catalog.itemPackaging.packageUnitText;

        Catalog preferredCatalog = catalogService.getPreferredSourceCatalog(catalog.catalogItemIdentifier, buyer.getId());

        if (Objects.isNull(preferredCatalog)) {
            catalog.isPreferredSource = true;
        }

        catalog.shortDescription = catalogImportData.shortItemDescription;
        catalog.longDescription = catalogImportData.longItemDescription;

        catalog.sellerProductIdentifierType = "VCN";

        if (!StringUtil.isEmptyOrNull(catalogImportData.supplierItemIdentifier)) {
            catalog.sellerProductIdentifier = catalogImportData.supplierItemIdentifier;
        } else {
            catalog.sellerProductIdentifier = catalogImportData.itemId;
        }
        catalog.isActive = true;


        String commodityNm = StringUtil.convertToTitleCaseIteratingChars(catalogImportData.commodityClassName);
        CommodityCodeRef commodityCodeRef = new CommodityCodeRef();
        List<CommodityCode> commodityCodes = financeReferenceDataService.getCommodityCodesByName(financialSystemId, commodityNm);
        if (commodityCodes.size() > 0) {
            commodityCodeRef = commodityCodes.get(0).getRef();
            addInfo(requestId, callback, "Assigning commodity code " + commodityCodeRef.name);
        }
        if (!StringUtil.isEmptyOrNull(commodityCodeRef.getId())) {
            catalog.commodityCodeRef = commodityCodeRef;
        }
        Catalog savedCatalog = new Catalog();
        try {
            addInfo(requestId, callback, "Saving catalog record.");
            savedCatalog = catalogService.saveCatalogRecord(catalog);
            logger.info("populateCatalog NodeIdentifier:  CID:" + savedCatalog.catalogItemIdentifier + ": Customer: " + buyer.name + ": Catalog Id:" + savedCatalog.getId());
            addInfo(requestId, callback, "Added Catalog record. Catalog Item Identifier: " +
                    savedCatalog.catalogItemIdentifier + ", Customer: " +
                    buyer.name + ", Catalog Record Id: " + savedCatalog.getId());
        } catch (Exception e) {
            addError(requestId, callback, "Could not save catalog record id.  Error: " + e.getMessage());
            addException(requestId, callback, e);
            logger.info("populateCatalog CID:" + catalog.catalogItemIdentifier + " Error: " + e.getMessage());
        }

        return savedCatalog;
    }

    public void addInfo(String requestId, IItemTaskRequestDetailCallback callback, String message) {
        if (callback != null) {
            callback.addInformation(requestId, message);
        }
    }

    public void addError(String requestId, IItemTaskRequestDetailCallback callback, String message) {
        if (callback != null) {
            callback.addError(requestId, message);
        }
    }

    public void addException(String requestId, IItemTaskRequestDetailCallback callback, Exception exception) {
        if (callback != null) {
            callback.addException(requestId, exception);
        }
    }

    public void processUdrTransactions() {
        microservice.processUdrTransactions();
    }

}
