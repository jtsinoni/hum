package logicole.gateway.services.asset;

import logicole.apis.asset.IMinimumEssentialCharacteristicsMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class MinimumEssentialCharacteristicsMicroserviceClient extends MicroserviceClient<IMinimumEssentialCharacteristicsMicroserviceApi> {
    public MinimumEssentialCharacteristicsMicroserviceClient() {
        super(IMinimumEssentialCharacteristicsMicroserviceApi.class, "logicole-asset");
    }

    @Produces
    public IMinimumEssentialCharacteristicsMicroserviceApi getIAssetLookupMicroserviceApi() {
        return createClient();
    }
}
