package logicole.gateway.services.realpropertysection;

import logicole.apis.realpropertysection.ISectionLookupMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class SectionLookupMicroserviceClient extends MicroserviceClient<ISectionLookupMicroserviceApi> {
    public SectionLookupMicroserviceClient() { super(ISectionLookupMicroserviceApi.class, "logicole-realproperty-section"); }

    @Produces
    public ISectionLookupMicroserviceApi getMicroserviceApi() { return createClient(); }
}
