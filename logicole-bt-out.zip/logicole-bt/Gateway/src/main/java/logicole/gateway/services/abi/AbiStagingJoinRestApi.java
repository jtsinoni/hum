package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.staging.AbiCatalogStaging;
import logicole.common.datamodels.abi.staging.join.InitiateJoinSettings;
import logicole.common.datamodels.abi.staging.join.JoinRecordCommand;
import logicole.common.datamodels.abi.staging.join.JoinStagingRecordsState;
import logicole.common.datamodels.abi.staging.join.StagingRecordByMmc;
import logicole.common.general.exception.ValidationException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi/staging/join")
public class AbiStagingJoinRestApi extends ExternalRestApi<AbiStagingJoinService> {

    @POST
    @Path("/initiateJoinRecordProcess")
    public JoinStagingRecordsState initiateJoinRecordProcess(InitiateJoinSettings settings) {
        return service.initiateJoinRecordProcess(settings);
    }

    @POST
    @Path("/processJoinRecordCommand")
    public AbiCatalogStaging processJoinRecordCommand(JoinRecordCommand joinRecordCommand) throws ValidationException {
        return service.processJoinRecordCommand(joinRecordCommand);
    }

    @GET
    @Path("/deleteMergeInitiatedRecord")
    public void deleteMergeInitiatedRecord(@QueryParam("masterRecordId") String masterRecordId) {
        service.deleteMergeInitiatedRecord(masterRecordId);
    }

    @GET
    @Path("/getMergePossibilitiesByMmc")
    public List<StagingRecordByMmc> getMergePossibilitiesByMmc() {
        return service.getMergePossibilitiesByMmc();
    }

    @GET
    @Path("/getMergedRecordList")
    public List<AbiCatalogStaging> getMergedRecordList(@QueryParam("filterData") String filterData) {
        return service.getMergedRecordList(filterData);
    }

    @GET
    @Path("/undoMerge")
    public List<AbiCatalogStaging> undoMerge(@QueryParam("masterRecordId") String masterRecordId) {
        return service.undoMerge(masterRecordId);
    }

    @GET
    @Path("/getJoinStagingRecordsState")
    public JoinStagingRecordsState getJoinStagingRecordsState(@QueryParam("masterRecordId") String masterRecordId) {
        return service.getJoinStagingRecordsState(masterRecordId);
    }
}
