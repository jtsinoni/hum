package logicole.gateway.services.spacemanagement;

import io.swagger.annotations.*;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.asset.businesscontact.BusinessContactRef;
import logicole.common.datamodels.asset.classification.AssemblyCategory;
import logicole.common.datamodels.asset.classification.FacilitySubsystem;
import logicole.common.datamodels.asset.classification.FacilitySystem;
import logicole.common.datamodels.asset.classification.Nomenclature;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.space.Space;
import logicole.common.datamodels.space.cobie.COBieExportStatus;
import logicole.common.datamodels.space.cobie.COBieImportStatus;
import logicole.common.datamodels.space.cobie.staging.*;
import logicole.gateway.rest.ExternalRestApi;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.List;

@Api(tags = {"COBie"})
@ApplicationScoped
@Path("/cobie")
public class COBieRestApi extends ExternalRestApi<COBieService> {

    @POST
    @Path("/uploadCOBieFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload Construction Operations Building Information Exchange (COBie) file",
            notes = "The return value will be the file ID")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a COBie file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadCOBieFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form)
            throws IOException {
        return service.uploadCOBieFile(form);
    }

    @GET
    @Path("/downloadCOBieFile")
    public Response downloadCOBieFile(@QueryParam("fileId") String fileId) throws IOException {
        return service.downloadCOBieFile(fileId);
    }

    @POST
    @Path("/importCOBieFile")
    public COBieImportStatus importCOBieFile(@QueryParam("facilityId") String facilityId, Attachment importFile) {
        return service.importCOBieFile(facilityId, importFile);
    }

    @GET
    @Path("/exportCOBieFile")
    @ApiOperation(value = "Export COBie File")
    public COBieExportStatus exportCOBieFile(@QueryParam("exportTemplateOnly") Boolean exportTemplateOnly,
                                             @QueryParam("facilityId") String facilityId) throws IOException {
        return service.exportCOBieFile(exportTemplateOnly, facilityId);
    }

    @GET
    @Path("/getMaxCOBieImportAttachmentSize")
    public Integer getMaxCOBieImportAttachmentSize() {
        return service.getMaxCOBieImportAttachmentSize();
    }

    @POST
    @Path("/getCOBieFileImportSearchResults")
    public SearchResult<COBieFileImport> getCOBieFileImportSearchResults(SearchInput searchInput) {
        return service.getCOBieFileImportSearchResults(searchInput);
    }

    @POST
    @Path("/getCOBieFileExportSearchResults")
    public SearchResult<COBieFileExport> getCOBieFileExportSearchResults(SearchInput searchInput) {
        return service.getCOBieFileExportSearchResults(searchInput);
    }

    @GET
    @Path("/deleteCOBieImportFile")
    public Boolean deleteCOBieImportFile(@QueryParam("id") String id) {
        return service.deleteCOBieImportFile(id);
    }

    @GET
    @Path("/deleteCOBieExportFile")
    public Boolean deleteCOBieExportFile(@QueryParam("id") String id) {
        return service.deleteCOBieExportFile(id);
    }

    // Contact
    @GET
    @Path("/getCOBieContactImportsByFileImportId")
    public List<COBieContactImport> getCOBieContactImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieContactImportsByFileImportId(fileImportId);
    }

    @GET
    @Path("/getCOBieContactImportSummariesByFileImportId")
    public List<COBieContactImportSummary> getCOBieContactImportSummariesByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieContactImportSummariesByFileImportId(fileImportId);
    }

    @POST
    @Path("/processCOBieContactImports")
    public int processCOBieContactImports(List<String> cobieContactImportIds) {
        return service.processCOBieContactImports(cobieContactImportIds);
    }

    @POST
    @Path("/saveCOBieContactImportSummary")
    public void saveCOBieContactImportSummary(COBieContactImportSummary cobieContactImportSummary) {
        service.saveCOBieContactImportSummary(cobieContactImportSummary);
    }

    @POST
    @Path("/deleteCOBieContactImports")
    public void deleteCOBieContactImports(List<String> cobieContactImportIds) {
        service.deleteCOBieContactImports(cobieContactImportIds);
    }

    @GET
    @Path("/getBusinessContactTypes")
    public List<String> getBusinessContactTypes() {
        return service.getBusinessContactTypes();
    }

    // Facility
    @GET
    @Path("/getCOBieFacilityImportsByFileImportId")
    public List<COBieFacilityImport> getCOBieFacilityImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieFacilityImportsByFileImportId(fileImportId);
    }

    // Floor
    @GET
    @Path("/getCOBieFloorImportsByFileImportId")
    public List<COBieFloorImport> getCOBieFloorImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieFloorImportsByFileImportId(fileImportId);
    }

    @GET
    @Path("/getCOBieFloorImportSummariesByFileImportId")
    public List<COBieFloorImportSummary> getCOBieFloorImportSummariesByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieFloorImportSummariesByFileImportId(fileImportId);
    }

    @POST
    @Path("/processCOBieFloorImports")
    public int processCOBieFloorImports(List<String> cobieFloorImportIds) {
        return service.processCOBieFloorImports(cobieFloorImportIds);
    }

    @POST
    @Path("/saveCOBieFloorImportSummary")
    public void saveCOBieFloorImportSummary(COBieFloorImportSummary cobieFloorImportSummary) {
        service.saveCOBieFloorImportSummary(cobieFloorImportSummary);
    }

    @POST
    @Path("/deleteCOBieFloorImports")
    public void deleteCOBieFloorImports(List<String> cobieFloorImportIds) {
        service.deleteCOBieFloorImports(cobieFloorImportIds);
    }

    @GET
    @Path("/findDuplicateCOBieFloorImportsByFileImportId")
    public void findDuplicateCOBieFloorImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        service.findDuplicateCOBieFloorImportsByFileImportId(fileImportId);
    }

    // Space
    @GET
    @Path("/getCOBieSpaceImportsByFileImportId")
    public List<COBieSpaceImport> getCOBieSpaceImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieSpaceImportsByFileImportId(fileImportId);
    }

    @GET
    @Path("/getCOBieSpaceImportSummariesByFileImportId")
    public List<COBieSpaceImportSummary> getCOBieSpaceImportSummariesByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieSpaceImportSummariesByFileImportId(fileImportId);
    }

    @POST
    @Path("/processCOBieSpaceImports")
    public int processCOBieSpaceImports(List<String> cobieSpaceImportIds) {
        return service.processCOBieSpaceImports(cobieSpaceImportIds);
    }

    @POST
    @Path("/saveCOBieSpaceImportSummary")
    public void saveCOBieSpaceImportSummary(COBieSpaceImportSummary cobieSpaceImportSummary) {
        service.saveCOBieSpaceImportSummary(cobieSpaceImportSummary);
    }

    @POST
    @Path("/deleteCOBieSpaceImports")
    public void deleteCOBieSpaceImports(List<String> cobieSpaceImportIds) {
        service.deleteCOBieSpaceImports(cobieSpaceImportIds);
    }

    @GET
    @Path("/findDuplicateCOBieSpaceImportsByFileImportId")
    public void findDuplicateCOBieSpaceImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        service.findDuplicateCOBieSpaceImportsByFileImportId(fileImportId);
    }

    // Zone
    @GET
    @Path("/getCOBieZoneImportsByFileImportId")
    public List<COBieZoneImport> getCOBieZoneImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieZoneImportsByFileImportId(fileImportId);
    }

    @GET
    @Path("/getCOBieZoneImportSummariesByFileImportId")
    public List<COBieZoneImportSummary> getCOBieZoneImportSummariesByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieZoneImportSummariesByFileImportId(fileImportId);
    }

    @POST
    @Path("/processCOBieZoneImports")
    public int processCOBieZoneImports(List<String> cobieZoneImportIds) {
        return service.processCOBieZoneImports(cobieZoneImportIds);
    }

    @POST
    @Path("/saveCOBieZoneImportSummary")
    public void saveCOBieZoneImportSummary(COBieZoneImportSummary cobieZoneImportSummary) {
        service.saveCOBieZoneImportSummary(cobieZoneImportSummary);
    }

    @POST
    @Path("/deleteCOBieZoneImports")
    public void deleteCOBieZoneImports(List<String> cobieZoneImportIds) {
        service.deleteCOBieZoneImports(cobieZoneImportIds);
    }

    @GET
    @Path("/findDuplicateCOBieZoneImportsByFileImportId")
    public void findDuplicateCOBieZoneImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        service.findDuplicateCOBieZoneImportsByFileImportId(fileImportId);
    }

    // Type
    @GET
    @Path("/getCOBieTypeImportsByFileImportId")
    public List<COBieTypeImport> getCOBieTypeImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieTypeImportsByFileImportId(fileImportId);
    }

    // Component
    @GET
    @Path("/getCOBieComponentImportsByFileImportId")
    public List<COBieComponentImport> getCOBieComponentImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieComponentImportsByFileImportId(fileImportId);
    }

    // Equipment (Component + Type)
    @GET
    @Path("/getCOBieEquipmentImportsByFileImportId")
    public List<COBieEquipmentImport> getCOBieEquipmentImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieEquipmentImportsByFileImportId(fileImportId);
    }

    @POST
    @Path("/processCOBieEquipmentImports")
    public int processCOBieEquipmentImports(List<COBieEquipmentImportIds> cobieEquipmentImportIds) {
        return service.processCOBieEquipmentImports(cobieEquipmentImportIds);
    }

    @POST
    @Path("/saveCOBieEquipmentImport")
    public void saveCOBieEquipmentImport(COBieEquipmentImport cobieEquipmentImports) {
        service.saveCOBieEquipmentImport(cobieEquipmentImports);
    }

    @POST
    @Path("/deleteCOBieEquipmentImports")
    public void deleteCOBieEquipmentImports(List<COBieEquipmentImportIds> cobieEquipmentImportIds) {
        service.deleteCOBieEquipmentImports(cobieEquipmentImportIds);
    }

    @GET
    @Path("/findDuplicateCOBieEquipmentImportsByFileImportId")
    public void findDuplicateCOBieEquipmentImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        service.findDuplicateCOBieEquipmentImportsByFileImportId(fileImportId);
    }

    @GET
    @Path("/getRoomsByFacilityId")
    public List<Space> getRoomsByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getRoomsByFacilityId(facilityId);
    }

    @GET
    @Path("/getRPEManufacturerNames")
    public List<BusinessContactRef> getRPEManufacturerNames() {
        return service.getRPEManufacturerNames();
    }

    @GET
    @Path("/getAllRPEBusinessContacts")
    public List<BusinessContactRef> getAllRPEBusinessContacts() {
        return service.getAllRPEBusinessContacts();
    }

    @GET
    @Path("/getBusinessContactRefs")
    public List<BusinessContactRef> getBusinessContactRefs(@QueryParam("isActive") String isActive) {
        return service.getBusinessContactRefs(isActive);
    }

    @GET
    @Path("/getAllActiveFacilitySystems")
    public List<FacilitySystem> getAllActiveFacilitySystems() {
        return service.getAllActiveFacilitySystems();
    }

    @GET
    @Path("/getFacilitySubsystemForFacilitySystem")
    public List<FacilitySubsystem> getFacilitySubsystemForFacilitySystem(@QueryParam("facilitySystemCode") String facilitySystemCode) {
        return service.getFacilitySubsystemForFacilitySystem(facilitySystemCode);
    }

    @GET
    @Path("/getAssemblyCategoriesForFacilitySubsystem")
    public List<AssemblyCategory> getAssemblyCategoriesForFacilitySubsystem(@QueryParam("facilitySubsystemCode") String facilitySubsystemCode) {
        return service.getAssemblyCategoriesForFacilitySubsystem(facilitySubsystemCode);
    }

    @GET
    @Path("/getNomenclaturesByCode")
    public List<Nomenclature> getNomenclaturesByCode(@QueryParam("code") String code) {
        return service.getNomenclaturesByCode(code);
    }

    // Attribute
    @GET
    @Path("/getCOBieAttributeImportsByFileImportId")
    public List<COBieAttributeImport> getCOBieAttributeImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        return service.getCOBieAttributeImportsByFileImportId(fileImportId);
    }

    @POST
    @Path("/processCOBieAttributeImports")
    public int processCOBieAttributeImports(List<String> cobieAttributeImportIds) {
        return service.processCOBieAttributeImports(cobieAttributeImportIds);
    }

    @POST
    @Path("/saveCOBieAttributeImport")
    public void saveCOBieAttributeImport(COBieAttributeImport cobieAttributeImport) {
        service.saveCOBieAttributeImport(cobieAttributeImport);
    }

    @POST
    @Path("/deleteCOBieAttributeImports")
    public void deleteCOBieAttributeImports(List<String> cobieAttributeImportIds) {
        service.deleteCOBieAttributeImports(cobieAttributeImportIds);
    }

    @GET
    @Path("/findDuplicateCOBieAttributeImportsByFileImportId")
    public void findDuplicateCOBieAttributeImportsByFileImportId(@QueryParam("fileImportId") String fileImportId) {
        service.findDuplicateCOBieAttributeImportsByFileImportId(fileImportId);
    }
}
