package logicole.gateway.services.system;

import io.swagger.annotations.Api;
import logicole.common.datamodels.Configuration;
import logicole.common.datamodels.ConfigurationCollection;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

@Api(tags = {"SystemConfiguration"})
@ApplicationScoped
@Path("/systemConfiguration")
public class SystemConfigurationRestApi extends ExternalRestApi<SystemConfigurationService> {

    @GET
    @Path("/getAllConfigurations")
    public ConfigurationCollection getAllConfigurations() {
        return service.getAllConfigurations();
    }

    @GET
    @Path("/getMicroServiceConfigurations")
    public ConfigurationCollection getMicroServiceConfigurations() {
        return service.getMicroServiceConfigurations();
    }

    @GET
    @Path("/getServerConfigurations")
    public ConfigurationCollection getServerConfigurations() {
        return service.getServerConfigurations();
    }

    @POST
    @Path("/addUpdateConfiguration")
    public Configuration addUpdateConfiguration(Configuration configuration) {
        return service.addUpdateConfiguration(configuration);
    }

    @GET
    @Path("/getConfiguration")
    public Configuration getConfiguration(@QueryParam("id") String id, @QueryParam("owner") String owner) {
        return service.getConfiguration(id, owner);
    }

    @GET
    @Path("/getConfigurationByName")
    public Configuration getConfigurationByName(@QueryParam("name") String name, @QueryParam("owner") String owner) {
        return service.getConfigurationByName(name, owner);
    }

}
