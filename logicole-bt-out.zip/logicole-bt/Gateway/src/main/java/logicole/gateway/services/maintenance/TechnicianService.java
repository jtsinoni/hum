package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.ITechnicianMicroserviceApi;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.maintenance.team.MaintenanceTeam;
import logicole.common.datamodels.maintenance.team.MaintenanceTeamRef;
import logicole.common.datamodels.maintenance.technician.EEmployeeType;
import logicole.common.datamodels.maintenance.technician.JobClass;
import logicole.common.datamodels.maintenance.technician.JobClassRef;
import logicole.common.datamodels.maintenance.technician.MasterTrainingRecord;
import logicole.common.datamodels.maintenance.technician.Technician;
import logicole.common.datamodels.maintenance.technician.TechnicianCreationWrapper;
import logicole.common.datamodels.maintenance.technician.TechnicianNode;
import logicole.common.datamodels.maintenance.technician.TechnicianRef;
import logicole.common.datamodels.maintenance.technician.TechnicianTeamAssignment;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.UnauthorizedException;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.security.SecurityConstants;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.user.UserService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@ApplicationScoped
public class TechnicianService extends BaseGatewayService<ITechnicianMicroserviceApi> {

    private static final String MEDICAL_EQUIPMENT_MAINTENANCE_TECHNICIAN_ROLE_ID = "611a6942753bab4391b09018";
    public static final String NO_TECHNICIAN_FOUND = "No Technician found with id of %s";

    @Inject
    private UserService userService;
    @Inject
    private MaintenanceTeamService maintenanceTeamService;

    public TechnicianService() {
        super("Technician");
    }

    public Technician findById(String id) {
        Technician technician = microservice.findById(id);
        if (null == technician) {
            throw new ApplicationException(String.format(NO_TECHNICIAN_FOUND, id));
        }
        validateTechnicianUserAccess(technician);
        return technician;
    }

    private void validateTechnicianUserAccess(@NotNull Technician technician) {
        for (TechnicianNode node : technician.technicianNodes) {
            if (!isMDBUser() && !node.nodeRef.ancestry.contains(currentUserBT.getCurrentNodeId())) {
                throw new UnauthorizedException("Unauthorized access");
            }
        }
    }

    private boolean isMDBUser() {
        return Objects.equals(currentUserBT.getCurrentUser().profile.pkiDn, SecurityConstants.MDB_SPECIAL_USER_PROFILE_KEY);
    }

    public Technician createTechnician(Technician technician) {
        validateBasicCreateTechnicianInfo(technician);

        technician.pkiDn = getPkiDnForNewTechnician(technician);
        List<UserProfile> userProfiles = getActiveUserProfilesFromPkiDn(technician.pkiDn);

        TechnicianCreationWrapper technicianCreationWrapper = generateTechnicianWrapper(technician, userProfiles);
        return microservice.createTechnician(technicianCreationWrapper);
    }

    private void validateBasicCreateTechnicianInfo(Technician technician) {
        if (technician == null ||
                ListUtil.isEmpty(technician.userProfileRefs) ||
                StringUtil.isBlankOrNull(technician.userProfileRefs.get(0).getId()) ||
                ListUtil.isEmpty(technician.technicianNodes)) {
            throw new ValidationException("Missing necessary Technician or Node information");
        }
    }

    private String getPkiDnForNewTechnician(Technician technician) {
        UserProfile userProfile =
                userService.getUserProfileById(technician.userProfileRefs.get(0).getId());
        if (userProfile == null) {
            throw new ValidationException("User Profile not found");
        }
        return userProfile.pkiDn;
    }

    private List<UserProfile> getActiveUserProfilesFromPkiDn(String pkiDn) {
        List<UserProfile> userProfiles = userService.getActiveUserProfiles(pkiDn);
        if (ListUtil.isEmpty(userProfiles)) {
            throw new ValidationException("No valid User Profiles found");
        }
        return userProfiles;
    }

    protected TechnicianCreationWrapper generateTechnicianWrapper(Technician technician,
                                                                  List<UserProfile> userProfiles) {
        // Protected access for unit test
        return new TechnicianCreationWrapper(technician, currentUserBT.getCurrentUser().profile.currentNodeRef, userProfiles);
    }

    public List<EEmployeeType> getEmployeeTypes() {
        return Arrays.asList(EEmployeeType.values());
    }

    public List<JobClassRef> getJobClassRefs() {
        return microservice.getJobClassRefs();
    }

    public List<UserProfile> getPotentialTechnicianUserProfiles() {
        String nodeId = currentUserBT.getCurrentNodeId();
        List<UserProfile> userProfileList = userService.getUsersAtNodeWithRole(nodeId, MEDICAL_EQUIPMENT_MAINTENANCE_TECHNICIAN_ROLE_ID);
        Map<String, UserProfile> userProfileMap = userProfileList.stream().collect(Collectors.toMap(UserProfile::getPkiDn, profile -> profile, (profile1, profile2) -> profile1));
        userProfileList = new ArrayList<>(userProfileMap.values());
        return userProfileList.stream().sorted(Comparator.comparing(UserProfile::getFullName)).collect(Collectors.toList());
    }

    public SearchResult<Technician> getTechnicianSearchResults(SearchInput searchInput) {
        return microservice.getTechnicianSearchResults(searchInput);
    }

    public Technician updateTechnician(Technician technician) {
        validateTechnicianUserAccess(technician);
        return microservice.updateTechnician(technician);
    }

    public Technician addNote(String id, Note note) {
        Technician technician = findById(id);
        validateTechnicianUserAccess(technician);
        return microservice.addNote(id, note);
    }

    public Technician saveNote(String id, Note note) {
        Technician technician = findById(id);
        validateTechnicianUserAccess(technician);
        return microservice.saveNote(id, note);
    }

    public Technician removeNote(String id, Note note) {
        Technician technician = findById(id);
        validateTechnicianUserAccess(technician);
        return microservice.removeNote(id, note);
    }

    public List<TechnicianRef> getAvailableTechniciansByOrganizationId(String organizationId) {
        return microservice.getAvailableTechniciansByOrganizationId(organizationId);
    }

    public List<MaintenanceTeam> getMaintenanceTeams() {
        return maintenanceTeamService.getMaintenanceTeams();
    }

    public JobClass updateJobClass(String id, String code) {
        return microservice.updateJobClass(id, code);
    }

    public List<MasterTrainingRecord> getMasterTrainingRecords() {
        return microservice.getMasterTrainingRecords();
    }

    public MasterTrainingRecord createMasterTrainingRecord(MasterTrainingRecord masterTrainingRecord) {
        masterTrainingRecord.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.createMasterTrainingRecord(masterTrainingRecord);
    }

    public MasterTrainingRecord updateMasterTrainingRecord(MasterTrainingRecord masterTrainingRecord) {
        return microservice.updateMasterTrainingRecord(masterTrainingRecord);
    }

    public boolean deleteMasterTrainingRecordById(String id) {
        return microservice.deleteMasterTrainingRecordById(id);
    }

    public List<MaintenanceTeam> getAvailableTeamsForAssignment(String id) {
        List<TechnicianTeamAssignment> technicianTeamAssignments = getTechnicianTeamAssignments(id);
        List<MaintenanceTeam> maintenanceTeams = maintenanceTeamService.getMaintenanceTeams();
        return maintenanceTeams.stream()
                .filter(team -> technicianTeamAssignments.stream().noneMatch(assignment -> Objects.equals(assignment.maintenanceTeamRef.getId(), team.getId())))
                .collect(Collectors.toUnmodifiableList());
    }

    public List<TechnicianTeamAssignment> getTechnicianTeamAssignments(String id) {
        return microservice.getTechnicianTeamAssignments(id);
    }

    public TechnicianTeamAssignment addTechnicianTeamAssignment(String id, Boolean isPrimary, MaintenanceTeamRef maintenanceTeamRef) {
        Technician technician = findById(id);
        validateTechnicianUserAccess(technician);
        TechnicianTeamAssignment technicianTeamAssignment = new TechnicianTeamAssignment();
        technicianTeamAssignment.technicianRef = technician.getRef();
        technicianTeamAssignment.maintenanceTeamRef = maintenanceTeamRef;
        technicianTeamAssignment.dateAssigned = new Date();
        technicianTeamAssignment.isTeamLead = false;
        technicianTeamAssignment.isPrimaryAssignment = isPrimary;
        return addTechnicianTeamAssignment(technicianTeamAssignment);
    }

    public TechnicianTeamAssignment addTechnicianTeamAssignment(TechnicianTeamAssignment technicianTeamAssignment) {
        return microservice.addTechnicianTeamAssignment(technicianTeamAssignment);
    }

    public TechnicianTeamAssignment updateTechnicianTeamAssignment(String id, TechnicianTeamAssignment technicianTeamAssignment) {
        Technician technician = findById(id);
        validateTechnicianUserAccess(technician);
        return microservice.updateTechnicianTeamAssignment(technicianTeamAssignment);
    }

    public void removeTechnicianTeamAssignment(String id, TechnicianTeamAssignment technicianTeamAssignment) {
        Technician technician = findById(id);
        validateTechnicianUserAccess(technician);
        microservice.removeTechnicianTeamAssignment(technicianTeamAssignment);
    }
}
