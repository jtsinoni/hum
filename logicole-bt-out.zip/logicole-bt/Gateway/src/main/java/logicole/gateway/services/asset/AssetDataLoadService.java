package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetDataLoadMicroserviceApi;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class AssetDataLoadService extends BaseGatewayService<IAssetDataLoadMicroserviceApi> {

    public AssetDataLoadService() {
        super("Asset");
    }

    public String getUserName() {
        return microservice.getUserName();
    }

}
