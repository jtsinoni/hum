package logicole.gateway.services.receipt;

import logicole.apis.receipt.IDueInMicroserviceApi;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.abi.item.ItemPackaging;
import logicole.common.datamodels.abi.item.ItemSummary;
import logicole.common.datamodels.abi.RestrictionRef;
import logicole.common.datamodels.delivery.DueOut;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchCriterion;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.inventory.*;
import logicole.common.datamodels.receipt.*;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.ObjectMapper;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.delivery.DueOutService;
import logicole.gateway.services.inventory.InventoryService;
import logicole.gateway.services.inventory.LocationService;
import logicole.gateway.services.order.CartService;
import logicole.common.datamodels.abi.item.Item;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;


@ApplicationScoped
public class DueInService extends BaseGatewayService<IDueInMicroserviceApi> {

    @Inject
    protected InventoryService inventoryService;

    @Inject
    LocationService locationService;

    @Inject
    protected ReceiptService receiptService;

    @Inject
    private ItemService itemService;

    @Inject
    private CartService cartService;

    @Inject
    private ObjectMapper mapper;

    @Inject
    DueOutService dueOutService;

    public DueInService() {
        super("DueIn");
    }


    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }

    public DueIn addDueIn(DueIn dueIn) {
        return microservice.addDueIn(dueIn);
    }


    public List<DueIn> addDueIns(List<DueIn> dueIns) {
        String currentNodeId = this.currentUserBT.getCurrentNodeId();
        InventorySystem system = locationService.getInventorySystemByCurrentNodeId(currentNodeId);
        if (Objects.nonNull(system) && system.inventoryPlanningConfiguration.equalsIgnoreCase("Location")) {
            dueIns.forEach( dueIn -> dueIn.isDeliveryListProcessed = false);
        }
        return microservice.addDueIns(dueIns);
    }


    public List<DueInDTO> getDueInsByBuyerId(String id) {
        List<DueIn> dueIns = microservice.getDueInsByBuyerId(id);
        List<DueInDTO> dueInsOut = convertDueIns(dueIns);

        for (DueInDTO dueIn : dueInsOut) {
            dueIn.inventoryLocationRefList = locationService.getStorageLocationRefsByNodeId(dueIn.buyerRef.currentNodeRef.id);
            dueIn.stratificationList = inventoryService.getStratifications();
        }

        return dueInsOut;
    }


    public List<DueInDTO> getDueInsBySellerId(String id) {
        List<DueIn> dueIns = microservice.getDueInsBySellerId(id);
        List<DueInDTO> dueInsOut = convertDueIns(dueIns);
        return dueInsOut;
    }

    public List<DueInDTO> getDueInsByPartialEnterpriseProductIdentifier(String partialProductIdentifier) {
        List<DueIn> dueIns = microservice.getDueInsByPartialEnterpriseProductIdentifier(partialProductIdentifier);
        List<DueInDTO> dueInsOut = convertDueIns(dueIns);
        return dueInsOut;
    }

    public List<DueInDTO> getAllDueIns() {
        List<DueIn> dueIns = microservice.getAllDueIns();
        List<DueInDTO> dueInsOut = convertDueIns(dueIns);
        return dueInsOut;
    }


    public DueIn changeDueInQuantity(String id, Integer quantity) {
        return microservice.changeDueInQuantity(id, quantity);
    }

    public DueIn changeDueInQuantityByOrderLineId(String id, Integer quantity) {
        return microservice.changeDueInQuantityByOrderLineId(id, quantity);
    }

    public void deleteDueInByOrderId(String orderId) {
        microservice.deleteDueInByOrderId(orderId);
    }

    public void updateDueInQuantityByOrderLineId(String orderLineItemId, Integer quantity) {
        microservice.updateDueInQuantityByOrderLineId(orderLineItemId, quantity);
    }

    public void updateDueInPriceByOrderLineId(String orderLineItemId, MonetaryValue price){
        microservice.updateDueInPriceByOrderLineId(orderLineItemId, price);
    }

    public Integer getSumDueInQuantityByProduct(String productIdentifier, String buyerId) {
        return microservice.getSumDueInQuantityByProduct(productIdentifier, buyerId);
    }

    private List<DueInDTO> convertDueIns(List<DueIn> dueIns) {
        List<DueInDTO> dueInsOut = new ArrayList<>();
        for (DueIn dueIn : dueIns) {
            DueInDTO dueInOut = new DueInDTO(dueIn);
            dueInsOut.add(dueInOut);
        }
        return dueInsOut;
    }

    public Receipt addReceipt(Receipt receipt) {
        return receiptService.addReceipt(receipt);
    }

    public SearchResult<DueInDTO> getDueInSearchResults(String buyerId, boolean scannerInput, SearchInput searchInput) {

        ESearchEngine searchEngine = microservice.getDueInSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            if (searchInput.searchCriteria != null) {
                setSearchCriteria(buyerId, "buyerId", searchInput);
            }
            if (scannerInput) {
                ItemPackaging itemPackaging = itemService.getItemByBarcode(searchInput.searchText);
                if (Objects.nonNull(itemPackaging.itemRef)) {
                    searchInput.searchText = itemPackaging.itemRef.id;
                }
            }

            SearchCriterion searchCriterionQuantity = new SearchCriterion();
            searchCriterionQuantity.propName = "quantity";
            searchCriterionQuantity.method = SearchCriterion.SEARCH_METHOD_GREAT_THAN;
            searchCriterionQuantity.propValues = new Integer[]{0};
            searchInput.searchCriteria.add(searchCriterionQuantity);

            SearchResult<DueIn> searchResult = microservice.getDueInSearchResults(searchInput);
            SearchResult<DueInDTO> convertedResult = new SearchResult<>();
            convertedResult.aggregations = searchResult.aggregations;

            if (!ListUtil.isEmpty(searchResult.results)) {
                convertedResult.results = convertDueInDTOs(searchResult.results);
                convertedResult.total = (long) convertedResult.results.size();
            }

            for (DueInDTO dueIn : convertedResult.results) {
                dueIn.itemSummary = cartService.populateItemSummary(dueIn.catalog);
                dueIn.dueoutQuantity = dueOutService.getSumDueOutQtyByDueinId(dueIn.id);
            }

            return convertedResult;
        }
    }

    private void setSearchCriteria(String value, String propertyName, SearchInput searchInput) {
        SearchCriterion searchCriterion = new SearchCriterion();
        searchCriterion.propName = propertyName;
        List<Object> propValues = new ArrayList<>();
        propValues.add(value);
        searchCriterion.propValues = propValues.toArray();
        searchInput.searchCriteria.add(searchCriterion);
    }

    public List<DueIn> getDueInsByBuyerIdAndItemId(String buyerId, String itemId) {
        return this.microservice.getBuyerDueInsForItem(buyerId, itemId);
    }


    private List<DueInDTO> convertDueInDTOs(List<DueIn> dueIns) {
        List<DueInDTO> dueInsOut = new ArrayList<>();

        if (!ListUtil.isEmpty(dueIns)) {
            List<Stratification> stratificationList = inventoryService.getStratifications();

            String currentNodeId = this.currentUserBT.getCurrentNodeId();
            InventorySystem system = locationService.getInventorySystemByCurrentNodeId(currentNodeId);

            for (DueIn dueIn : dueIns) {
                DueInDTO dueInOut = new DueInDTO(dueIn);

                if (system.inventoryPlanningConfiguration.equalsIgnoreCase("Location")) {
                    dueInOut.isDeliveryListProcessed = dueInOut.isDeliveryListProcessed == null ? Boolean.FALSE : dueInOut.isDeliveryListProcessed;
                }

                fetchItemSummary(dueInOut);

                dueInOut.stratificationList = stratificationList;
                dueInOut.processStatusList = new ArrayList<>();
                dueInOut.processStatusList = validateDueIn(dueIn);
                dueInOut.isRestricted = getRestrictionAlert(dueIn);

                dueInOut.inventoryLocationRefList = locationService.getStorageLocationRefsByNodeId(dueIn.buyerRef.currentNodeRef.id);
                findDefaultLocations(dueInOut, dueIn, dueIn.buyerRef.currentNodeRef.id, system.getId());

                dueInsOut.add(dueInOut);
            }
        }
        return dueInsOut;
    }

    private void findDefaultLocations(DueInDTO dueInOut, DueIn dueIn, String buyerNodeId, String inventorySystemId) {
        List<StorageLocation> locs = locationService.getStorageLocationsByNodeId(dueIn.buyerRef.currentNodeRef.id);
        for (StorageLocation sl : locs) {
            InventoryRecord iRec = inventoryService.getInventoryRecordByLocationAndItemAndInventorySystem(sl.getId(), dueIn.catalog.itemRef.id, inventorySystemId);
            if (iRec != null) {
                for (StorageLocationRef locRef : dueInOut.inventoryLocationRefList) {
                    ItemLocation foundLocation = iRec.itemLocations.stream().filter(itemLocation -> itemLocation.locationRef.id.equals(locRef.id)).findAny().orElse(null);
                    if (foundLocation != null) {
                        locRef.isPrimaryLocation = foundLocation.isPrimaryLocation;
                    }
                }

            }
        }
    }

    private void fetchItemSummary(DueInDTO dueInOut) {
        if (Objects.nonNull(dueInOut.catalog.itemRef)) {
            dueInOut.itemSummary = mapper.getObject(ItemSummary.class, dueInOut.catalog.itemRef);
        }
    }

    public List<Receipt> processSelectedReceipts(List<Receipt> receipts) {
        List<Receipt> processedReceipts = new ArrayList<>();

        for (Receipt receipt : receipts) {
            receipt = receiptService.addReceipt(receipt);

            if (!Objects.isNull(receipt)) {
                processedReceipts.add(receipt);
            }
        }
        return processedReceipts;
    }


    private List<EDueInProcessStatus> validateDueIn(DueIn dueIn) {
        List<EDueInProcessStatus> dueInProcessStatusList = new ArrayList<>();
        if (!Objects.isNull(dueIn.orderInformationRef) &&
                this.currentUserBT.getCurrentUser().getRef().getId().equals(dueIn.orderInformationRef.createdBy.getId())) {
            dueInProcessStatusList.add(EDueInProcessStatus.FISCAM_COMPLIANCE_ERROR_STATUS);
        } else if (!Objects.isNull(dueIn.orderInformationRef) &&
                !this.currentUserBT.getCurrentUser().getRef().getId().equals(dueIn.orderInformationRef.createdBy.getId())) {
            dueInProcessStatusList.add(EDueInProcessStatus.GOOD_FOR_PROCESSING);
        }
        return dueInProcessStatusList;
    }

    private boolean getRestrictionAlert(DueIn dueIn) {
        boolean isFrozenOrRefrigeratedItem = false;
        if (!Objects.isNull(dueIn.catalog.itemRef) && !StringUtil.isEmptyOrNull(dueIn.catalog.itemRef.getId())) {
            Item item = itemService.getItemById(dueIn.catalog.itemRef.getId());

            if (!Objects.isNull(item) && !item.restrictionRefList.isEmpty()) {
                for (RestrictionRef restrictionRef : item.restrictionRefList) {
                    if (restrictionRef.code.equalsIgnoreCase("3") ||
                            restrictionRef.code.equalsIgnoreCase("6") ||
                            restrictionRef.code.equalsIgnoreCase("5")) {
                        isFrozenOrRefrigeratedItem = true;
                        break;
                    }
                }
            }
        }
        return isFrozenOrRefrigeratedItem;
    }

    public DueIn getDueInByDocumentNumber(String documentNumber, String buyerId, String fulfillmentRefOrderLineItemId) {
        return microservice.getDueInByDocumentNumber(documentNumber, buyerId, fulfillmentRefOrderLineItemId);
    }

    public DueIn updateDueInDeliveryListProcessStatus(String dueOutId, Boolean status) {
        DueOut dueOut = dueOutService.getDueOutById(dueOutId);
        DueIn updatedDueIn = new DueIn();

        if (Objects.nonNull(dueOut)) {
            if (!StringUtil.isEmptyOrNull(dueOut.backOrderIndicator) && dueOut.backOrderIndicator.equalsIgnoreCase("Y")) {
                updatedDueIn = getDueInByDocumentNumber(dueOut.customerDueinRef.documentNumber, dueOut.customerDueinRef.buyerRef.getId(),
                        dueOut.customerDueinRef.orderItemLineId);
            } else if (StringUtil.isEmptyOrNull(dueOut.backOrderIndicator)) {
                updatedDueIn = getDueInByDocumentNumber(dueOut.documentNumber, dueOut.buyerRef.getId(), dueOut.fulfillmentRef.orderLineItemId);
            }
            updatedDueIn.isDeliveryListProcessed = status;
            updatedDueIn = microservice.updateDueInDeliveryListProcessStatus(updatedDueIn);
        }
      return updatedDueIn;
    }
}
