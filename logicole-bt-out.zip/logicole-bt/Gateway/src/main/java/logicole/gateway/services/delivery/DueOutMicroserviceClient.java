package logicole.gateway.services.delivery;

import logicole.apis.delivery.IDeliveryMicroserviceApi;
import logicole.apis.delivery.IDueOutMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class DueOutMicroserviceClient extends MicroserviceClient<IDueOutMicroserviceApi> {
    public DueOutMicroserviceClient(){
        super(IDueOutMicroserviceApi.class, "logicole-delivery");
    }

    @Produces
    public IDueOutMicroserviceApi getIDueOutMicroserviceApi() {
        return createClient();
    }

}
