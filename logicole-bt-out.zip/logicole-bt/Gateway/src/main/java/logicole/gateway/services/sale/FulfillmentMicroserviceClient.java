package logicole.gateway.services.sale;


import logicole.apis.sale.IFulfillmentMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class FulfillmentMicroserviceClient extends MicroserviceClient<IFulfillmentMicroserviceApi> {
    public FulfillmentMicroserviceClient(){
        super(IFulfillmentMicroserviceApi.class, "logicole-sale");
    }

    @Produces
    public IFulfillmentMicroserviceApi getIFulfillmentMicroserviceApi() {
        return createClient();
    }

}
