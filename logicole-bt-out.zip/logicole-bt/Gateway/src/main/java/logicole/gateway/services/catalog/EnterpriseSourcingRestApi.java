package logicole.gateway.services.catalog;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import logicole.common.datamodels.abi.PackageUnit;
import logicole.common.datamodels.catalog.EnterpriseSourceSummary;
import logicole.common.datamodels.catalog.EnterpriseSourcing;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Catalog"})
@ApplicationScoped
@Path("/enterpriseSourcing")
public class EnterpriseSourcingRestApi extends ExternalRestApi<EnterpriseSourcingService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getById")
    public EnterpriseSourcing getById(@QueryParam("id") String id) {
        return service.getById(id);
    }

    @POST
    @Path("/findByIds")
    public List<EnterpriseSourcing> findByIds(List<String> ids) { return service.findByIds(ids); }

    @GET
    @Path("/getByEnterpriseProductIdentifier")
    public List<EnterpriseSourcing> getByEnterpriseProductIdentifier(@QueryParam("buyerId") String buyerId, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        // return service.getByEnterpriseProductIdentifier(buyerId, enterpriseProductIdentifier);
        return null;
    }

    @POST
    @Path("/getEnterpriseSourcingSearchResults")
    public SearchResult<EnterpriseSourceSummary> getEnterpriseSourcingSearchResults(SearchInput searchInput) {
        return service.getEnterpriseSourcingSearchResults(searchInput);
    }

    @POST
    @Path("/addEnterpriseSourcing")
    @ApiOperation(value = "Insert new Enterprise Sourcing")
    public EnterpriseSourcing addEnterpriseSourcing(EnterpriseSourcing enterpriseSourcing) {
        return service.saveEnterpriseSourcing(enterpriseSourcing);
    }

    @GET
    @Path("/getEnterpriseSourcingByItemId")
    @ApiOperation(value = "Get related Enterprise Sourcing records based on a given Item Id")
    public List<EnterpriseSourcing> getEnterpriseSourcingByItemId(@QueryParam("itemId") String itemId) {
        return service.getEnterpriseSourcingByItemId(itemId);
    }

    @GET
    @Path("/getPackageUnitList")
    public List<PackageUnit> getPackageUnitList() {
        return service.getPackageUnitList();
    }

    @POST
    @Path("/updateEnterpriseSourcing")
    @ApiOperation(value = "Update an Enterprise Sourcing record")
    public EnterpriseSourcing updateEnterpriseSourcing(EnterpriseSourcing enterpriseSourcing) {
        return service.saveEnterpriseSourcing(enterpriseSourcing);
    }
}