package logicole.gateway.services.user;

import logicole.apis.user.IUserRequestMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class UserRequestMicroserviceClient extends MicroserviceClient<IUserRequestMicroserviceApi> {
    public UserRequestMicroserviceClient() {
        super(IUserRequestMicroserviceApi.class, "logicole-user");
    }

    @Produces
    public IUserRequestMicroserviceApi getIUserRequestMicroserviceApi() {
        return createClient();
    }
}
