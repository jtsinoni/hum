package logicole.gateway.services.inventory;

import logicole.apis.inventory.IInventoryMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.assemblage.Assemblage;
import logicole.common.datamodels.assemblage.AssemblageItem;
import logicole.common.datamodels.assemblage.AssemblageRef;
import logicole.common.datamodels.catalog.Catalog;
import logicole.common.datamodels.delivery.DueOut;
import logicole.common.datamodels.delivery.DueOutRef;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.search.*;
import logicole.common.datamodels.inventory.*;
import logicole.common.datamodels.inventory.Audit.InventoryAuditCount;
import logicole.common.datamodels.product.Offer;
import logicole.common.datamodels.receipt.Receipt;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.assemblage.AssemblageService;
import logicole.gateway.services.catalog.CatalogService;
import logicole.gateway.services.delivery.DueOutService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.order.CartService;
import logicole.gateway.services.receipt.DueInService;
import logicole.gateway.services.system.NotificationService;
import logicole.common.datamodels.abi.item.Item;
import logicole.gateway.services.abi.item.ItemService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.BadRequestException;

@ApplicationScoped
public class InventoryService extends BaseGatewayService<IInventoryMicroserviceApi> {

    @Inject
    protected FileManagerAdminService fileManagerAdminService;

    @Inject
    protected NotificationService notificationService;

    @Inject
    protected LocationService locationService;

    @Inject
    protected CatalogService catalogService;

    @Inject
    protected DueOutService dueOutService;

    @Inject
    protected DueInService dueInService;

    @Inject
    protected PlanningService planningService;

    @Inject
    protected ItemService itemService;

    @Inject
    protected AssemblageService assemblageService;

    @Inject
    protected BuyerService buyerService;

    @Inject
    protected CartService cartService;

    @Inject
    private StringUtil stringUtil;

    public static final String SERVICEABLE = "Operating Serviceable";
    public static final String IS_LOCATION = "Location";
    public static final String IS_ITEM = "Item";

    public InventoryService() {
        super("Inventory");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }


    public InventoryRecord getInventoryRecordById(String inventoryRecordId) {
        return microservice.getInventoryRecordById(inventoryRecordId);
    }

    public List<InventoryRecord> getInventoryRecordsByOrgId(String orgId) {
        return microservice.getInventoryRecordsByOrgId(orgId);
    }

    public List<InventoryRecord> getInventoryRecordsByLocation(String locationId) {
        return microservice.getInventoryRecordsByLocation(locationId);
    }

    public InventoryRecord getInventoryRecordByLocationAndItemAndInventorySystem(String locationId, String itemId, String inventorySystemId) {
        return microservice.getInventoryRecordByLocationAndItemAndInventorySystem(locationId, itemId, inventorySystemId);
    }

    public ProductAvailableQuantity getProductAvailableQuantityForResale(String currentNodeId,
                                                                         String enterpriseProductIdentifier) {
        return microservice.getProductAvailableQuantityForResale(currentNodeId, enterpriseProductIdentifier);
    }

    public InventoryRecord uploadInventoryRecordQueuedForPickQuantity(String currentNodeId, String enterpriseProductIdentifier, Integer queuedForPickQuantity) {
        return microservice.uploadInventoryRecordQueuedForPickQuantity(currentNodeId, enterpriseProductIdentifier, queuedForPickQuantity);
    }

    public List<ProductAvailableQuantity> getProductsAvailableQuantityForResale(String currentNodeId,
                                                                                List<String> enterpriseProductIdentifiers) {
        return microservice.getProductsAvailableQuantityForResale(currentNodeId, enterpriseProductIdentifiers);
    }

    public List<StorageLocationRef> getInventoryLocationsByProductAndOwner(String enterpriseProductId,
                                                                           String organizationId) {
        return microservice.getInventoryLocationsByProductAndOwner(enterpriseProductId, organizationId);
    }

    public List<Stratification> getStratifications() {
        return microservice.getStratifications();
    }

    public List<Stratification> getStratificationsByModule(String module) {
        return microservice.getStratificationsByModule(module);
    }

    public List<ReplenishmentRecord> getReplenishmentList() {
        String currentNodeId = getCurrentUser().profile.currentNodeRef.id;
        return getReplenishmentList(currentNodeId);
    }

    public List<ReplenishmentRecord> getReplenishmentList(String nodeId) {
        List<ReplenishmentRecord> replenishmentList = new ArrayList<>();

        InventorySystem inventorySystem = locationService.getInventorySystemByCurrentNodeId(nodeId);
        List<InventoryRecord> inventoryRecords = microservice.getInventoryRecordsByOrgId(nodeId);
        if (inventoryRecords == null || inventoryRecords.size() == 0 || inventorySystem == null)
            return replenishmentList;

        List<InventoryRecord> inventoryAMRecords = new ArrayList<>();
        for (InventoryRecord rec : inventoryRecords) {
            if ((!Objects.isNull(rec.assemblageRef) && !StringUtil.isEmptyOrNull(rec.assemblageRef.getId()))
                    || (!Objects.isNull(rec.assemblageItemRef) && !StringUtil.isEmptyOrNull(rec.assemblageItemRef.getId()))) {
                inventoryAMRecords.add(rec);
            }
        }

        if (inventoryAMRecords.size() > 0) {
           inventoryRecords.removeAll(inventoryAMRecords);
        }
        
        if (inventorySystem.inventoryPlanningConfiguration.equalsIgnoreCase(IS_LOCATION)) {
            for (InventoryRecord inventoryRecord : inventoryRecords) {
                for (ItemLocation itemLocation : inventoryRecord.itemLocations) {
                    int replenishQty = 0;
                    List<DueOutRef> dueOutRefs = new ArrayList<>();
                    List<DueOut> dueOuts = dueOutService.getDueOutByEnterpriseProductIdentifierAndSystemAndLocation(
                            inventoryRecord.itemRef.enterpriseProductIdentifier, inventoryRecord.inventorySystemRef.id, itemLocation.itemLocationIdentifier, itemLocation.locationRef.getId());;
                    if (dueOuts != null && dueOuts.size() > 0) {
                        for (DueOut dueOut : dueOuts) {
                            replenishQty += dueOut.dueOutQuantity != null ? dueOut.dueOutQuantity : 0;
                            dueOutRefs.add(dueOut.getRef());
                        }
                    }

                    replenishQty += getLevelReplenishQuantityForInventoryLocation(inventoryRecord, itemLocation);
                    if (replenishQty > 0) {
                        ReplenishmentRecord replenishmentRecord = new ReplenishmentRecord();
                        replenishmentRecord = createReplenishmentRecord(inventoryRecord, itemLocation, replenishQty);
                        replenishmentRecord.dueOutRefs = dueOutRefs;
                        replenishmentList.add(replenishmentRecord);
                    }
                }
            }
        } else if (inventorySystem.inventoryPlanningConfiguration.equalsIgnoreCase(IS_ITEM)) {
            for (InventoryRecord inventoryRecord : inventoryRecords) {
                int replenishQty = 0;
                List<DueOutRef> dueOutRefs = new ArrayList<>();
                List<DueOut> dueOuts = dueOutService.getDueOutByEnterpriseProductIdentifierAndSystem(
                        inventoryRecord.itemRef.enterpriseProductIdentifier, inventoryRecord.inventorySystemRef.id);
                if (dueOuts != null && dueOuts.size() > 0) {
                    for (DueOut dueOut : dueOuts) {
                            replenishQty += dueOut.dueOutQuantity != null ? dueOut.dueOutQuantity : 0;
                            dueOutRefs.add(dueOut.getRef());
                    }
                }
                replenishQty += getLevelReplenishQuantityForInventoryItemLocations(inventoryRecord, inventoryRecord.itemLocations);
                if (replenishQty > 0) {
                    ReplenishmentRecord replenishmentRecord = new ReplenishmentRecord();
                    replenishmentRecord = createReplenishmentRecord(inventoryRecord, getItemPrimaryLocation(inventoryRecord.itemLocations), replenishQty);
                    replenishmentRecord.dueOutRefs = dueOutRefs;
                    replenishmentList.add(replenishmentRecord);
                }
            }
        }
        if (replenishmentList.size() > 0) {
            // check for due-ins for each item and adjust the list
            List<ReplenishmentRecord> toRemove = new ArrayList<>();
            List<String> productIds = getProductIdsInReplenishmentList(replenishmentList);
            for (String productId : productIds) {
                Integer dueInQtySum = dueInService.getSumDueInQuantityByProduct(productId,
                        buyerService.getBuyerForNodeId(getCurrentUser().profile.currentNodeRef.getId()).getId());
                int sumReplishmentProducts = getSumReplenishmentByProductId(replenishmentList, productId);
                if (dueInQtySum > 0) {
                    if (dueInQtySum >= sumReplishmentProducts) {
                        // remove replenishment item from the list, since there are due ins to fill it
                        toRemove.addAll(getReplenishmentItemsToRemoveByProductId(replenishmentList, productId));
                    } else {
                        // adjust the outgoing ReplenishmentRecords, to deduct the number of each item to be replenished
                        toRemove.addAll(updateReplenishmentRecordQuantity(replenishmentList, productId, dueInQtySum));
                    }
                }
            }

            if (toRemove.size() > 0) {
                replenishmentList.removeAll(toRemove);
            }
        }
        return replenishmentList;
    }

    private List<ReplenishmentRecord>  updateReplenishmentRecordQuantity(List<ReplenishmentRecord> replenishmentList, String productId, Integer dueInQtySum) {
        List<ReplenishmentRecord> replenishmentItemsFound = new ArrayList<>();
        Integer runningSum = dueInQtySum;
        for (ReplenishmentRecord replenishmentRecord : replenishmentList) {
            if (replenishmentRecord.enterpriseProductIdentifier.equalsIgnoreCase(productId)) {
                if (replenishmentRecord.replenishmentLocation.replenishmentQty > runningSum) {
                    // record qty > dueInQtySum -> decrease the amount in the record and return, a decreased replenishment amount is required, since dueins will fill rest
                    replenishmentRecord.replenishmentLocation.replenishmentQty -= runningSum;
                    break;
                } else if (replenishmentRecord.replenishmentLocation.replenishmentQty == runningSum) {
                    // record qty = dueInQtySum -> that record is no longer needed, since dueins will fill it.
                    replenishmentItemsFound.add(replenishmentRecord);
                    break;
                } else if (replenishmentRecord.replenishmentLocation.replenishmentQty < runningSum) {
                    // record qty < dueInQtySum -> remove each record that fulfills the dueIN amount, but keep looping to check item at all locations
                    runningSum -= replenishmentRecord.replenishmentLocation.replenishmentQty;
                    replenishmentItemsFound.add(replenishmentRecord);
                }
            }
        }
        return replenishmentItemsFound;
    }

    private List<String> getProductIdsInReplenishmentList(List<ReplenishmentRecord> replenishmentList) {
        List<String> productIds = new ArrayList<>();
        for (ReplenishmentRecord replenishmentRecord : replenishmentList) {
            if (!productIds.contains(replenishmentRecord.enterpriseProductIdentifier)) {
                productIds.add(replenishmentRecord.enterpriseProductIdentifier);
            }
        }
        return productIds;
    }
    private int getSumReplenishmentByProductId(List<ReplenishmentRecord> replenishmentList, String productId) {
        int sum = 0;
        for (ReplenishmentRecord replenishmentRecord : replenishmentList) {
            if (replenishmentRecord.enterpriseProductIdentifier.equalsIgnoreCase(productId)) {
                sum += replenishmentRecord.replenishmentLocation.replenishmentQty;
            }
        }
        return sum;
    }
    private List<ReplenishmentRecord> getReplenishmentItemsToRemoveByProductId(List<ReplenishmentRecord> replenishmentList, String productId) {
        List<ReplenishmentRecord> replenishmentItemsFound = new ArrayList<>();
        for (ReplenishmentRecord replenishmentRecord : replenishmentList) {
            if (replenishmentRecord.enterpriseProductIdentifier.equalsIgnoreCase(productId)) {
                replenishmentItemsFound.add(replenishmentRecord);
            }
        }
        return replenishmentItemsFound;
    }

    private int getLevelReplenishQuantityForInventoryLocation(InventoryRecord inventoryRecord, ItemLocation itemLocation) {
        int totalOnHandQuantity = 0;
        int replenishQuantity = 0;
        if (itemLocation.isResaleLocation == true) {
            InventoryPlanning planningRecord =
                    planningService.getInventoryPlanningByRecordIdAndItemLocId(inventoryRecord.getId(),
                            itemLocation.itemLocationIdentifier);
            long locationCurrentReorderQty = 0;
            int currentLevelQty = 0;
            if (planningRecord != null) {
                locationCurrentReorderQty = planningRecord.currentReorder;
                currentLevelQty = Math.toIntExact(planningRecord.currentLevel);
            }

            for (ItemStorage itemStorage : itemLocation.itemStorage) {
                if (itemStorage.stratificationRef.name.equals(SERVICEABLE)) {
                    Integer availQty = (itemStorage.onHandQty - itemStorage.inPickQty );
                    totalOnHandQuantity += (itemStorage.onHandQty - itemStorage.inPickQty);
                }
            }
            if (totalOnHandQuantity > locationCurrentReorderQty) {
                replenishQuantity += 0;
            } else {
                replenishQuantity += (currentLevelQty - totalOnHandQuantity);
            }

        }
        return replenishQuantity;
    }

    private int getLevelReplenishQuantityForInventoryItemLocations(InventoryRecord inventoryRecord, List<ItemLocation> itemLocations) {
        int totalOnHandQuantity = 0;
        int replenishQuantity = 0;
        boolean foundPlanningRecord = false;
        long locationCurrentReorderQty = 0;
        int currentLevelQty = 0;

        // find the planning record for these locations
        for (ItemLocation itemLocation : itemLocations) {
            if (foundPlanningRecord == false) {
                if (itemLocation.isResaleLocation == true) {
                    InventoryPlanning planningRecord =
                            planningService.getInventoryPlanningByRecordIdAndItemLocId(inventoryRecord.getId(),
                                    itemLocation.itemLocationIdentifier);
                    if (planningRecord != null) {
                        locationCurrentReorderQty = planningRecord.currentReorder;
                        currentLevelQty = Math.toIntExact(planningRecord.currentLevel);
                        foundPlanningRecord = true;
                    }
                }
            }
        }
        if (foundPlanningRecord == true) {
            for (ItemLocation itemLocation : itemLocations) {
                if (itemLocation.isResaleLocation == true) {
                    for (ItemStorage itemStorage : itemLocation.itemStorage) {
                        if (itemStorage.stratificationRef.name.equals(SERVICEABLE)) {
                            totalOnHandQuantity += (itemStorage.onHandQty - itemStorage.inPickQty);
                        }
                    }
                }
            }
            totalOnHandQuantity -= inventoryRecord.getQueuedForPickQty();
            if (totalOnHandQuantity > locationCurrentReorderQty) {
                replenishQuantity += 0;
            } else {
                replenishQuantity += (currentLevelQty - totalOnHandQuantity);
            }

        }
        return replenishQuantity;
    }

    private ItemLocation getItemPrimaryLocation(List<ItemLocation> itemLocations) {
        ItemLocation foundItemLocation = null;
        for (ItemLocation itemLocation : itemLocations) {
            if (itemLocation.isPrimaryLocation == true) {
                foundItemLocation = itemLocation;
                break;
            }
        }
        return foundItemLocation;
    }

    private ReplenishmentRecord createReplenishmentRecord(InventoryRecord inventoryRecord, ItemLocation itemLocation, int replenishQuantity) {
        ReplenishmentRecord replenishmentRecord = new ReplenishmentRecord();
        replenishmentRecord.inventoryRecordId = inventoryRecord.getId();
        replenishmentRecord.inventorySystemRef = inventoryRecord.inventorySystemRef;
        replenishmentRecord.catalogRef = inventoryRecord.catalogRef;
        replenishmentRecord.enterpriseProductIdentifier = inventoryRecord.itemRef.enterpriseProductIdentifier;
        replenishmentRecord.replenishmentLocation = new ReplenishmentLocation();
        if (itemLocation != null) {
            replenishmentRecord.replenishmentLocation.itemLocationIdentifier = itemLocation.itemLocationIdentifier;
            replenishmentRecord.replenishmentLocation.locationRef = itemLocation.locationRef;
        }
        replenishmentRecord.replenishmentLocation.replenishmentQty = replenishQuantity;
        replenishmentRecord.sellerRef = inventoryRecord.sellerRef;
        return replenishmentRecord;
    }

    public List<PickRequest> getPickRequestsByInventorySystemId(String inventorySystemId) {
        return microservice.getPickRequestsByInventorySystemId(inventorySystemId);
    }

    public PickList getPickListById(String pickListId) {
        return microservice.getPickListById(pickListId);
    }

    public List<PickList> getPickListsByInventorySystemId(String inventorySystemId) {
        return microservice.getPickListsByInventorySystemId(inventorySystemId);
    }

    public List<PickList> getConfirmedPickListsByInventorySystemId(String inventorySystemId) {
        return microservice.getConfirmedPickListsByInventorySystemId(inventorySystemId);
    }

    public PickRequest updatePickRequest(PickRequest pickRequest) {
        return microservice.updatePickRequest(pickRequest);
    }

    public PickList updatePickList(PickList pickList) {
        return microservice.updatePickList(pickList);
    }

    public PickRequest createPickRequest(PickRequest pickRequest) {
        return microservice.createPickRequest(pickRequest);
    }

    public PutAway createPutAway(PutAway putAway) {
        return microservice.createPutAway(putAway);
    }


    public List<PutAway> getPutAwayRequestbyInventoryOwner(String inventoryOwnerId) {
        return microservice.getPutAwayRequestbyInventoryOwner(inventoryOwnerId);
    }

    public InventoryRecord saveInventoryRecordInfo(InventoryRecord record) {
        return microservice.saveInventoryRecordInfo(record);
    }

    public InventoryRecord saveItemLocationInfo(String inventoryRecordId, ItemLocation itemLocation) {
        return microservice.saveItemLocationInfo(inventoryRecordId, itemLocation);
    }

    public InventoryRecord setItemLocationToPrimary(String inventoryRecordId, String itemLocationId) {
        return microservice.setItemLocationToPrimary(inventoryRecordId, itemLocationId);
    }

    public InventoryRecord addNewItemLocation(String inventoryRecordId, ItemLocation itemLoc) {
        return microservice.addNewItemLocation(inventoryRecordId, itemLoc);
    }

    public InventoryRecord removeItemLocation(String inventoryRecordId, String itemLocationId) {
        InventoryPlanning planningRec = planningService.getInventoryPlanningByRecordIdAndItemLocId(inventoryRecordId, itemLocationId);
        if (planningRec != null ) {
            InventorySystem system = locationService.getInventorySystemById(planningRec.inventoryRecordRef.inventorySystemRef.getId());
            if (system.inventoryPlanningConfiguration.equalsIgnoreCase("Item")) {
                planningRec.itemLocationIdentifiersList.remove(itemLocationId);
                planningService.updatePlanningRecord(planningRec);
            } else if (system.inventoryPlanningConfiguration.equalsIgnoreCase("Location")) {
                planningService.deletePlanningRecord(planningRec.getId());
            }
        }
        return microservice.removeItemLocation(inventoryRecordId, itemLocationId);
    }

    public InventoryRecord createItemStorage(String inventoryRecordId, String itemLocationId, ItemStorage
            itemStorage) {
        return microservice.createItemStorage(inventoryRecordId, itemLocationId, itemStorage);
    }

    public InventoryRecord deleteItemStorage(String inventoryRecordId, String itemLocationId, String itemStorageId) {
        return microservice.deleteItemStorage(inventoryRecordId, itemLocationId, itemStorageId);
    }

    public InventoryRecord updateItemStorage(String inventoryRecordId, String itemLocationId, ItemStorage
            itemStorage) {
        return microservice.updateItemStorage(inventoryRecordId, itemLocationId, itemStorage);
    }

    public InventoryRecord createInventoryFromAudit(String currentNodeId,
                                                    InventoryAuditCount auditCount) {
        return microservice.createInventoryFromAudit(currentNodeId, auditCount);
    }

    public InventoryRecord createInventoryFromCatalog(String currentNodeId,
                                                      Offer offerRecord) {
        return microservice.createInventoryFromCatalog(currentNodeId, offerRecord);
    }

    public List<PickList> generatePicklist(List<PickRequest> pickRequests) {
        return microservice.generatePicklist(pickRequests);
    }

    public List<PickRequest> cancelPickRequest(List<PickRequest> pickRequests) {
        return microservice.cancelPickRequest(pickRequests);
    }

    public InventoryRecord createInventoryFromReceipt(Receipt receipt) {
        return microservice.createInventoryFromReceipt(receipt);
    }

    public InventoryRecord updateInventoryRecordFromReceipt(ReceiptRecordQuantity receiptRecordQuantity) {
        return microservice.updateInventoryRecordFromReceipt(receiptRecordQuantity);
    }


    public List<InventoryRecord> createInventoryFromReceipts(List<Receipt> receipts) {
        return microservice.createInventoryFromReceipts(receipts);
    }


    public Integer getStratificationCounts(String inventoryRecordId,
                                           String itemLocationId,
                                           String condition) {
        return microservice.getStratificationCounts(inventoryRecordId, itemLocationId, condition);
    }

    public List<InventoryRecord> getRecordsForMultipleOrgs(List<String> orgIds) {
        return microservice.getRecordsForMultipleOrgs(orgIds);
    }

    public List<InventoryRecord> getAllInventoryRecords() {
        return microservice.getAllInventoryRecords();
    }

    public List<InventoryRecord> getInventoryRecordsByProduct(String enterpriseProductIdentifier) {
        return microservice.getInventoryRecordsByProduct(enterpriseProductIdentifier);
    }

    public PickList confirmPicklist(PickList pickList) {
//        Boolean discrepancy = false;
//        for (PickDetails details : pickList.pickDetails) {
//            discrepancy = details.discrepancy == null ? false : details.discrepancy;
//            dueOutService.updatePartialConfirmedQueuedForPickQuantity(details.dueoutId, details.inPickQty - details.quantityPicked, discrepancy);
//        }
        return microservice.confirmPicklist(pickList);
    }

    public PickList savePicklistNote(String picklistId, Note note) {
        return microservice.savePicklistNote(picklistId, note);
    }

    public PickList savePicklistNotes(String picklistId, List<Note> notes) {
        return microservice.savePicklistNotes(picklistId, notes);
    }

    public PickList removePicklistNote(String picklistId, String noteId) {
        return microservice.removePicklistNote(picklistId, noteId);
    }

    public PickList removePicklistNotes(String picklistId, List<String> noteIds) {
        return microservice.removePicklistNotes(picklistId, noteIds);
    }

    public InventoryRecord setInventoryRecordStatus(boolean activeStatus, InventoryRecord record) {
        return microservice.setInventoryRecordStatus(activeStatus, record);
    }

    public Integer deleteInventoryRecord(String inventoryRecordId) {
        return microservice.deleteInventoryRecord(inventoryRecordId);
    }

    public InventoryRecord getRecordByOwnerAndProduct(String currentNodeId,
                                                      String enterpriseProductIdentifier) {
        return microservice.getRecordByOwnerAndProduct(currentNodeId, enterpriseProductIdentifier);
    }


    public InventoryRecord saveInventoryRecordNote(String inventoryRecordId, Note note) {
        return microservice.saveInventoryRecordNote(inventoryRecordId, note);
    }

    public InventoryRecord saveInventoryRecordNotes(String inventoryRecordId, List<Note> notes) {
        return microservice.saveInventoryRecordNotes(inventoryRecordId, notes);
    }

    public Attachment saveInventoryRecordAttachment(String inventoryRecordId,
                                                    Attachment attachmentToSave)
            throws ApplicationException, IOException {

        return microservice.saveInventoryRecordAttachmentInfo(inventoryRecordId, attachmentToSave);
    }


    public InventoryRecord removeInventoryRecordNote(String inventoryRecordId, String noteId) {
        return microservice.removeInventoryRecordNote(inventoryRecordId, noteId);
    }

    public InventoryRecord removeInventoryRecordNotes(String inventoryRecordId, List<String> noteIds) {
        return microservice.removeInventoryRecordNotes(inventoryRecordId, noteIds);
    }

    public InventoryRecord removeInventoryRecordAttachment(String inventoryRecordId, String fileId)
            throws IOException {

        if (inventoryRecordId == null || fileId == null) {
            throw new ApplicationException(
                    "Unable to remove InventoryRecord attachment. Need inventoryRecordId and fileId.");
        }

        try {
            fileManagerAdminService.removeFile(fileId);
        } catch (FatalProcessingException | ApplicationException e) {
            throw new ApplicationException("Was not able to upload the file");
        }

        return microservice.removeInventoryRecordAttachment(inventoryRecordId, fileId);
    }

    public Integer getMaxInventoryRecordAttachmentSize() {
        return microservice.getMaxInventoryRecordAttachmentSize();
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        } catch (BadRequestException e) {
            throw e;
        }

        return uploadedFile;
    }

    public List<InventoryRecord> findInventoryRecords(String searchString, String itemStatus) {
        String currentNodeId = this.currentUserBT.getCurrentNodeId();
        InventorySystem system = locationService.getInventorySystemByCurrentNodeId(currentNodeId);
        return microservice.findInventoryRecords(searchString, system.getId(), itemStatus);
    }

    public SearchResult<InventoryRecord> getInventoryRecordsSearchResults(String itemStatus, String nodeId, SearchInput searchInput) {
        InventorySystem system = locationService.getInventorySystemByCurrentNodeId(nodeId);
        ESearchEngine searchEngine = microservice.getInventoryRecordSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported now");
        }

        SearchCriterion inventorySystemRefCriterion = new SearchCriterion();
        inventorySystemRefCriterion.propName = "inventorySystemRef.id";
        inventorySystemRefCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
        ArrayList<String> systemRefIds = new ArrayList<>();
        systemRefIds.add(system.getId());
        inventorySystemRefCriterion.propValues = systemRefIds.toArray();
        searchInput.searchCriteria.add(inventorySystemRefCriterion);

        SearchCriterion assemblageRefCriterion = new SearchCriterion();
        assemblageRefCriterion.propName = "assemblage";
        assemblageRefCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
        ArrayList<String> assemblageRefIds = new ArrayList<>();
        assemblageRefIds.add("");
        assemblageRefIds.add(null);
        assemblageRefCriterion.propValues = assemblageRefIds.toArray();
        searchInput.searchCriteria.add(assemblageRefCriterion);

        SearchCriterion assemblageItemRefCriterion = new SearchCriterion();
        assemblageItemRefCriterion.propName = "assemblageItem";
        assemblageItemRefCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
        ArrayList<String> assemblageItemRefIds = new ArrayList<>();
        assemblageItemRefIds.add("");
        assemblageItemRefIds.add(null);
        assemblageItemRefCriterion.propValues = assemblageItemRefIds.toArray();
        searchInput.searchCriteria.add(assemblageItemRefCriterion);

        if (!itemStatus.equalsIgnoreCase("ALL")) {
            SearchCriterion recordStatusCriterion = new SearchCriterion();
            recordStatusCriterion.propName = "recordStatus";
            recordStatusCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
            ArrayList<String> recordStatuses = new ArrayList<>();
            recordStatuses.add(itemStatus);
            recordStatusCriterion.propValues = recordStatuses.toArray();
            searchInput.searchCriteria.add(recordStatusCriterion);
        }
        return microservice.getInventoryRecordsSearchResults(searchInput);
    }


    public InventoryRecord createInventoryRecord(String customerItemSourcingId) {
        String errorNoItemSourcing = "Item source cannot be found";
        String errorNoItem = "Each inventory record must specify an item.";
        String errorInventorySystemRequired = "Records must have an inventory system. Create an inventory system for your organization and try again";
        String errorMissingUnitOfInventory = "Each record must specify a unit";
        String errorRecordExists = "A record for that enterprise product already exists in inventory";

        String currentNodeId = this.currentUserBT.getCurrentNodeId();

        ItemSourcingSystemLocation itemSourcingSystemLocation = new ItemSourcingSystemLocation();

        InventorySystem system = locationService.getInventorySystemByCurrentNodeId(currentNodeId);

        if (Objects.isNull(customerItemSourcingId)) {
            throw new IllegalArgumentException("Parameter is null");
        }

        Catalog persistedItemSourcing = catalogService.getById(customerItemSourcingId);

        if (Objects.isNull(persistedItemSourcing)) {
            throw new ApplicationException(errorNoItemSourcing);
        }

        if (Objects.isNull(persistedItemSourcing.itemRef)
                || StringUtil.isEmptyOrNull(persistedItemSourcing.itemRef.id)) {
            throw new ApplicationException(errorNoItem);
        }

        if (Objects.isNull(system)) {
            throw new ApplicationException(errorInventorySystemRequired);
        }

        if (Objects.isNull(persistedItemSourcing.itemPackaging.packageUnit) || Objects.isNull(persistedItemSourcing.itemPackaging.packageUnitDescription)) {
            throw new ApplicationException(errorMissingUnitOfInventory);
        }

        InventoryRecord existingProductRecord = this.getRecordByOwnerAndProduct(currentNodeId, persistedItemSourcing.itemRef.enterpriseProductIdentifier);
        if (!Objects.isNull(existingProductRecord)) {
            throw new ApplicationException(errorRecordExists);
        }


        itemSourcingSystemLocation.catalog = persistedItemSourcing;
        itemSourcingSystemLocation.inventorySystemRef = system.getRef();
        itemSourcingSystemLocation.defaultLocationRef = system.defaultLocationRef;

        InventoryRecord recordBeingCreated = microservice.createInventoryRecord(itemSourcingSystemLocation);
        if (!Objects.isNull(recordBeingCreated)) {
            InventoryPlanning inventoryPlanning = new InventoryPlanning();
            inventoryPlanning.itemLocationIdentifiersList = new ArrayList<>();
            for (ItemLocation location : recordBeingCreated.itemLocations) {
                inventoryPlanning.itemLocationIdentifiersList.add(location.itemLocationIdentifier);
            }
            inventoryPlanning.inventoryRecordRef = new InventoryRecordRef();
            inventoryPlanning.inventoryRecordRef.id = recordBeingCreated.getId();
            inventoryPlanning.inventoryRecordRef.recordStatus = recordBeingCreated.recordStatus;
            inventoryPlanning.inventoryRecordRef.inventorySystemRef = system.getRef();
            planningService.createInventoryPlanning(inventoryPlanning);
        }
        return recordBeingCreated;
    }

    public Item getItemById(String itemId) {
        Item item = new Item();
        if (!Objects.isNull(itemId)) {
            item = itemService.getItemById(itemId);
        }
        return item;
    }

    public InventoryRecord saveInventoryRecordForAssemblage(InventoryRecord inventoryRecord) {
        inventoryRecord.setOnHandQty(inventoryRecord.itemLocations.stream().mapToInt(item -> item.itemStorage.get(0).onHandQty).sum());
        assemblageService.updateOnHandQuantity(inventoryRecord.assemblageRef.id, inventoryRecord.itemRef.id, inventoryRecord.getOnHandQty());
        inventoryRecord.itemLocations.forEach(location -> {
            if (StringUtil.isEmptyOrNull(location.itemLocationIdentifier)) {
                location.itemLocationIdentifier = stringUtil.getUUID();
            } });
        return microservice.saveInventoryRecordForAssemblage(inventoryRecord);
    }

    public InventoryRecord transferInventoryRecordForAssemblage(InventoryRecord transferInventoryRecord) {
        AssemblageRef destinationAssemblageRef = assemblageService.getAssemblageById(transferInventoryRecord.assemblageRef.id).getRef();
        transferInventoryRecord.assemblageRef = destinationAssemblageRef;

        List<AssemblageItem> destinationAssemblageItems = assemblageService.getItemsByAssemblageId(transferInventoryRecord.assemblageRef.id);
        List<AssemblageItem> destinationItem = destinationAssemblageItems.stream().filter(item -> item.catalogRef.catalogItemIdentifier.equals(transferInventoryRecord.catalogRef.catalogItemIdentifier)).collect(Collectors.toList());
        if(destinationItem == null || destinationItem.size() == 0) {
            AssemblageItem newItem = new AssemblageItem();
            assemblageService.buildItem(destinationAssemblageRef.customerNodeRef.id, newItem, transferInventoryRecord.catalogRef.catalogItemIdentifier);
            newItem.assemblageRef = transferInventoryRecord.assemblageRef;
            newItem = assemblageService.addAssemblageItem(newItem);
            transferInventoryRecord.assemblageItemRef = newItem.getRef();
        }

        InventoryRecord destinationInventoryRecord = microservice.getInventoryRecordByAssemblageAndItem(transferInventoryRecord.assemblageRef.id, transferInventoryRecord.itemRef.id);

        if(destinationInventoryRecord != null) {
            for(ItemLocation transferItemLocation : transferInventoryRecord.itemLocations) {
                List<ItemLocation> destinationItemLocation = destinationInventoryRecord.itemLocations.stream().filter(location -> location.locationRef.id.equals(transferItemLocation.locationRef.id)).collect(Collectors.toList());
                if(destinationItemLocation == null || destinationItemLocation.size() == 0) {
                    destinationInventoryRecord.itemLocations.add(transferItemLocation);
                } else {
                    destinationItemLocation.get(0).itemStorage.get(0).onHandQty = destinationItemLocation.get(0).itemStorage.get(0).onHandQty + transferItemLocation.itemStorage.get(0).onHandQty;
                }
            }
        } else {
            destinationInventoryRecord = transferInventoryRecord;
            destinationInventoryRecord._id = null;
        }

        destinationInventoryRecord.itemLocations.forEach(location -> {
            if (StringUtil.isEmptyOrNull(location.itemLocationIdentifier)) {
                location.itemLocationIdentifier = stringUtil.getUUID();
            } });
        return microservice.saveInventoryRecordForAssemblage(destinationInventoryRecord);
    }

    public Integer updateInventoryRecords(List<InventoryRecord> inventoryRecords) {
        return microservice.updateInventoryRecords(inventoryRecords);
    }

    public Integer deleteInventoryRecordForAssemblage(InventoryRecord inventoryRecord) {
        assemblageService.updateOnHandQuantity(inventoryRecord.assemblageRef.id, inventoryRecord.itemRef.id, 0);
        return microservice.deleteInventoryRecordForAssemblage(inventoryRecord.getId());
    }

    public InventoryRecord getInventoryRecordByAssemblageAndItem(String assemblageId, String itemId) {
        return microservice.getInventoryRecordByAssemblageAndItem(assemblageId, itemId);
    }

    public List<InventoryRecord> getInventoryRecordsForAssemblages(List<Assemblage> assemblages) {
        List<String> assemblageIds = assemblages.stream().map(Assemblage::getId).collect(Collectors.toList());

        return microservice.getInventoryRecordsForAssemblages(assemblageIds);
    }

    public List<InventoryRecord> getInventoryRecordsForTransferableAssemblageItems(String itemId) {
        return microservice.getInventoryRecordsForTransferableAssemblageItems(itemId);
    }

    public List<InventoryRecord> getInventoryRecordsForAssemblageById(String assemblageId) {
        return microservice.getInventoryRecordsForAssemblages(Arrays.asList(assemblageId));
    }

    public List<InventoryRecord> getInventoryRecordsForAssemblageByExpirationDate(String assemblageId, Date expirationDateStart, Date expirationDateEnd) {
        List<InventoryRecord> inventoryRecords = getInventoryRecordsForAssemblageById(assemblageId);

        for(InventoryRecord inventoryRecord : inventoryRecords) {
            inventoryRecord.itemLocations = inventoryRecord.itemLocations.stream().filter(record -> {
                if(record.itemStorage.get(0).revisedExpirationDate != null) {
                    return (record.itemStorage.get(0).revisedExpirationDate.after(expirationDateStart) && record.itemStorage.get(0).revisedExpirationDate.before(expirationDateEnd))
                            || record.itemStorage.get(0).revisedExpirationDate.equals(expirationDateStart) || record.itemStorage.get(0).revisedExpirationDate.equals(expirationDateEnd);

                } else if(record.itemStorage.get(0).expirationDate != null) {
                    return (record.itemStorage.get(0).expirationDate.after(expirationDateStart) && record.itemStorage.get(0).expirationDate.before(expirationDateEnd))
                            || record.itemStorage.get(0).expirationDate.equals(expirationDateStart) || record.itemStorage.get(0).expirationDate.equals(expirationDateEnd);
                } else {
                    return false;
                }
            }).collect(Collectors.toList());
        }


        return inventoryRecords;
    }

    public String getItemStockType(String currentNodeId,
                                   String enterpriseProductIdentifier) {
        return microservice.getItemStockType(currentNodeId, enterpriseProductIdentifier);

    }

    public List<DueOut> createDueOut (List<ReplenishmentRecordDTO> replenishmentRecordDTOS) {
        List<DueOut> dueOutList = new ArrayList<>();
        for (ReplenishmentRecordDTO replenishmentRecordDTO : replenishmentRecordDTOS) {
            InventoryRecord record = getInventoryRecordById(replenishmentRecordDTO.inventoryRecordId);
            if (!Objects.isNull(record)) {
                replenishmentRecordDTO.sellerRef = record.sellerRef;
            }
            replenishmentRecordDTO.buyerRef = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.getId()).getRef();
            DueOut dueOut = dueOutService.createDueOut(replenishmentRecordDTO);
            if (!Objects.isNull(dueOut)) {
                dueOutList.add(dueOut);
            }
        }
        return dueOutList;
    }

    public SearchResult<InventoryRecordDTO> getCustomerReplenishmentSearchResults(String nodeId, String itemType, SearchInput searchInput) {
        InventorySystem system = locationService.getInventorySystemByCurrentNodeId(nodeId);
        ESearchEngine searchEngine = microservice.getCustomerReplenishmentSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            SearchResult<InventoryRecord> customerReplenishmentResults = new SearchResult<>();
            SearchResult<InventoryRecordDTO> convertedResults = new SearchResult<>();

            SearchCriterion inventorySystemRefCriterion = new SearchCriterion();
            inventorySystemRefCriterion.propName= "inventorySystemRef.id";
            inventorySystemRefCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
            ArrayList<String> systemRefIds = new ArrayList<>();
            systemRefIds.add(system.getId());
            inventorySystemRefCriterion.propValues = systemRefIds.toArray();
            searchInput.searchCriteria.add(inventorySystemRefCriterion);

            SearchCriterion assemblageRefCriterion = new SearchCriterion();
            assemblageRefCriterion.propName = "assemblage";
            assemblageRefCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
            ArrayList<String> assemblageRefIds = new ArrayList<>();
            assemblageRefIds.add("");
            assemblageRefIds.add(null);
            assemblageRefCriterion.propValues = assemblageRefIds.toArray();
            searchInput.searchCriteria.add(assemblageRefCriterion);

            SearchCriterion assemblageItemRefCriterion = new SearchCriterion();
            assemblageItemRefCriterion.propName = "assemblageItem";
            assemblageItemRefCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
            ArrayList<String> assemblageItemRefIds = new ArrayList<>();
            assemblageItemRefIds.add("");
            assemblageItemRefIds.add(null);
            assemblageItemRefCriterion.propValues = assemblageItemRefIds.toArray();
            searchInput.searchCriteria.add(assemblageItemRefCriterion);

            if (!StringUtil.isEmptyOrNull(system.inventoryPlanningConfiguration) &&
                    system.inventoryPlanningConfiguration.equalsIgnoreCase("Location")) {
                customerReplenishmentResults = microservice.getCustomerReplenishmentSearchResults(nodeId, itemType, searchInput);
            }

            convertedResults.aggregations = customerReplenishmentResults.aggregations;
            if (!ListUtil.isEmpty(customerReplenishmentResults.results)) {
                convertedResults.results = convertInventoryRecords(customerReplenishmentResults.results);
                filterAggregations(convertedResults.results, convertedResults.aggregations);
                convertedResults.limit = customerReplenishmentResults.limit;
                convertedResults.total = (long) convertedResults.results.size();
            }

            return convertedResults;
        }
    }

    private List<InventoryRecordDTO> convertInventoryRecords(List<InventoryRecord> records) {
        List<InventoryRecordDTO> inventoryRecordDTOs = new ArrayList<>();
        for (InventoryRecord record : records) {
            InventorySystem system = locationService.getInventorySystemById(record.inventorySystemRef.getId());
            InventoryRecordDTO recordDTO = new InventoryRecordDTO(record);
            recordDTO.inventoryMethod = system.inventoryMethod.displayText;
            recordDTO.itemLocationIdentifier = record.itemLocations.get(0).itemLocationIdentifier;
            recordDTO.locationRef = record.itemLocations.get(0).locationRef;
            InventoryPlanning planningRecord = planningService.getInventoryPlanningByRecordIdAndItemLocId(record.getId(),
                    record.itemLocations.get(0).itemLocationIdentifier);
            recordDTO.level = planningRecord != null ? planningRecord.currentLevel : 0;
            if (record.itemLocations.size() > 1) {
                for (int i = 1; i < record.itemLocations.size(); i++) {
                    InventoryRecordDTO newRecordDTO = createSeparateInvRecordDTO( record.itemLocations.get(i),
                            record, system.inventoryMethod.displayText);
                    inventoryRecordDTOs.add(newRecordDTO);
                }
            }
            inventoryRecordDTOs.add(recordDTO);

        }
        return inventoryRecordDTOs;
    }

    private InventoryRecordDTO createSeparateInvRecordDTO(ItemLocation location, InventoryRecord record, String inventoryMethod) {
        InventoryRecordDTO recordDTO = new InventoryRecordDTO(record);
        recordDTO.locationRef = location.locationRef;
        recordDTO.itemLocationIdentifier = location.itemLocationIdentifier;
        recordDTO.inventoryMethod = inventoryMethod;
        InventoryPlanning planningRecord = planningService.getInventoryPlanningByRecordIdAndItemLocId(record.getId(), location.itemLocationIdentifier);
        recordDTO.level = planningRecord != null ? planningRecord.currentLevel : 0;
        return recordDTO;
    }


    private void filterAggregations (List<InventoryRecordDTO> records, List<SearchCategory> aggregations) {
        for (SearchCategory category: aggregations) {
            getSearchCount(category, records);
        }
    }

    private SearchCategory getSearchCount(SearchCategory aggregation,
                                          List<InventoryRecordDTO> records) {
        for (SearchCategoryItem categoryItem : aggregation.values) {
            categoryItem.count = 0;
            List<String> filteredVal;
            switch(aggregation.name) {
                case "enterpriseProductIdentifier":
                    filteredVal = records.stream().filter(record -> Objects.nonNull(record) &&
                            record.itemRef.enterpriseProductIdentifier.equalsIgnoreCase(categoryItem.value.toString()))
                            .map(itemId -> itemId.itemRef.enterpriseProductIdentifier).collect(Collectors.toList());
                    categoryItem.count = categoryItem.count + filteredVal.size();
                    break;
                case "itemId":
                    filteredVal = records.stream().filter(record -> Objects.nonNull(record) &&
                            record.catalogRef.catalogItemIdentifier.equalsIgnoreCase(categoryItem.value.toString()))
                            .map(itemId -> itemId.catalogRef.catalogItemIdentifier).collect(Collectors.toList());
                    categoryItem.count = categoryItem.count + filteredVal.size();
                    break;
                case "shortItemDescription":
                    filteredVal = records.stream().filter(record -> Objects.nonNull(record) &&
                            record.itemRef.shortItemDescription.equalsIgnoreCase(categoryItem.value.toString()))
                            .map(itemId -> itemId.itemRef.shortItemDescription).collect(Collectors.toList());
                    categoryItem.count = categoryItem.count + filteredVal.size();
                    break;
                case "locations":
                    filteredVal = records.stream().filter(recordDTO -> Objects.nonNull(recordDTO) &&
                            recordDTO.locationRef.name.equalsIgnoreCase(categoryItem.value.toString()))
                            .map(location -> location.locationRef.name).collect(Collectors.toList());
                    categoryItem.count = categoryItem.count + filteredVal.size();
                    break;
                default:
                    break;

            }
        }
        return aggregation;
    }

    public StorageLocationRef getPrimaryLocationByInventoryRecordId(String inventoryRecordId) {
        return microservice.getPrimaryLocationByInventoryRecordId(inventoryRecordId);
    }

    public InventoryRecord createHistoryEvent(String action, String documentNumber, String recordId) {
        InventoryRecord inventoryRecord = microservice.getInventoryRecordById(recordId);
      //  if (Objects.nonNull(inventoryRecord)) {
            inventoryRecord = microservice.createHistoryEvent(action, documentNumber, inventoryRecord);
        //}
      return inventoryRecord;
    }

    public InventoryRecord getInventoryRecordByProductAndInventorySystem(String enterpriseProductIdentifier, String inventorySystemId) {
        return microservice.getInventoryRecordByProductAndInventorySystem(enterpriseProductIdentifier, inventorySystemId);
    }

    public Integer deleteInventoryRecordsForAssemblages(List<String> assemblageIds) {
        // TODO: update on hand quantities for items deleted
        return microservice.deleteInventoryRecordsForAssemblages(assemblageIds);
    }

}


