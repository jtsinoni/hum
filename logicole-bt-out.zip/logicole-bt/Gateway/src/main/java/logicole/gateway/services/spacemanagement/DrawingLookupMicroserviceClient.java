package logicole.gateway.services.spacemanagement;

import logicole.apis.space.IDrawingLookupMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class DrawingLookupMicroserviceClient extends MicroserviceClient<IDrawingLookupMicroserviceApi> {
    public DrawingLookupMicroserviceClient() {
        super(IDrawingLookupMicroserviceApi.class, "logicole-space-management");
    }

    @Produces
    public IDrawingLookupMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
