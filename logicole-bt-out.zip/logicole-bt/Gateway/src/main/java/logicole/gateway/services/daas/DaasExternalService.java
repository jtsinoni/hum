package logicole.gateway.services.daas;

import logicole.common.datamodels.communications.httpincomingwrapper.EInterfaceSystemType;
import logicole.common.datamodels.communications.httpincomingwrapper.EInterfaceTransactionType;
import logicole.common.datamodels.communications.httpincomingwrapper.HttpIncomingWrapper;
import logicole.common.datamodels.communications.pricelookup.InboundTranslationResponse;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.remote.IDefaultRemoteApi;
import logicole.gateway.services.communications.CommunicationsSubmitRequestService;
import logicole.gateway.services.user.UserService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;

@ApplicationScoped
public class DaasExternalService extends BaseGatewayService<IDefaultRemoteApi> {
    @Inject
    CommunicationsSubmitRequestService communicationsSubmitRequestService;

    @Inject
    UserService userService;

    public DaasExternalService() {
        super("Daas");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public String acceptDaasEdi(String ediData) {
        return communicationsSubmitRequestService.submitExternalEdiForAcceptance(ediData);
    }

    public String acceptDataFromDaas(HttpIncomingWrapper daasData) {
        String returnValue;
        final String interfaceSystem = StringUtil.safeToUppercase(daasData.interfaceSystem.toString());
        final String rejectMessage = "This interface system (%s - %s) is not supported yet. The data was rejected by LogiCole.";

        switch (interfaceSystem) {
            case "ECAT":
                returnValue = communicationsSubmitRequestService.submitExternalEcatForAcceptance(daasData);
                break;
            case "EDI":
                returnValue = communicationsSubmitRequestService.submitExternalEdiForAcceptance(daasData);
                break;
            case "GFEBS":
                returnValue = communicationsSubmitRequestService.submitExternalGfebsForAcceptance(daasData);
                break;
            case "NERP":
                returnValue = String.format(rejectMessage, interfaceSystem,
                        EInterfaceTransactionType.convert(daasData.interfaceTransaction).toString());
                break;
            case "SABRS":
                returnValue = String.format(rejectMessage, interfaceSystem,
                        EInterfaceTransactionType.convert(daasData.interfaceTransaction).toString());
                break;
            case "VA HC":
                returnValue = String.format(rejectMessage, interfaceSystem,
                        EInterfaceTransactionType.convert(daasData.interfaceTransaction).toString());
                break;
            default:
                returnValue = String.format(rejectMessage, interfaceSystem, daasData.interfaceTransaction);
        }

        return returnValue;
    }

    public InboundTranslationResponse acceptEdiDataFromDaas(HttpIncomingWrapper daasData) {
        InboundTranslationResponse response = new InboundTranslationResponse();

        final String interfaceSystem = StringUtil.safeToUppercase(daasData.interfaceSystem.toString());

        // For the DAAS Testing page processing. EDI transaction go through a different route so we can get the
        // DMLSS translation format to display.
        if (StringUtil.safeEqualsIgnoreCase(interfaceSystem, "EDI")) {
            response = communicationsSubmitRequestService.submitExternalEdiDataForAcceptance(daasData);
        } else {
            response.acceptanceStatement = acceptDataFromDaas(daasData);
        }

        return response;
    }

    // This is for processing from the Daas Testing page.
    public InboundTranslationResponse sendData(@NotNull HttpIncomingWrapper daasData) {

        InboundTranslationResponse inboundTranslationResponse = new InboundTranslationResponse();

        if (daasData.interfaceSystem.equals(EInterfaceSystemType.REACHBACK)) {
            inboundTranslationResponse.acceptanceStatement = communicationsSubmitRequestService.submitDmlssStatusForAcceptance(daasData);
        } else {
            inboundTranslationResponse = acceptEdiDataFromDaas(daasData);
        }

        return inboundTranslationResponse;
    }
}