package logicole.gateway.services.asset;

import logicole.apis.asset.IMedicalEquipmentMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.abi.item.ItemRef;
import logicole.common.datamodels.asset.businesscontact.BusinessContact;
import logicole.common.datamodels.asset.businesscontact.BusinessContactRef;
import logicole.common.datamodels.asset.classification.Manufacturer;
import logicole.common.datamodels.asset.classification.ManufacturerRef;
import logicole.common.datamodels.asset.classification.Nomenclature;
import logicole.common.datamodels.asset.classification.SoftwareNomenclatureRef;
import logicole.common.datamodels.asset.management.AccountingStatus;
import logicole.common.datamodels.asset.management.AcquisitionInformation;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.asset.management.AssetBusinessContact;
import logicole.common.datamodels.asset.management.AssetCostSummary;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.Custodian;
import logicole.common.datamodels.asset.management.DurableItemRenewalInformation;
import logicole.common.datamodels.asset.management.DurableItemsOnLoan;
import logicole.common.datamodels.asset.management.EAccountingStatus;
import logicole.common.datamodels.asset.management.EAssetType;
import logicole.common.datamodels.asset.management.EMediumType;
import logicole.common.datamodels.asset.management.EOwnership;
import logicole.common.datamodels.asset.management.ESoftwareType;
import logicole.common.datamodels.asset.management.EquipmentItemRenewalInformation;
import logicole.common.datamodels.asset.management.LocationInformation;
import logicole.common.datamodels.asset.management.MedicalEquipmentAsset;
import logicole.common.datamodels.asset.management.MEEquipmentType;
import logicole.common.datamodels.asset.management.MedicalEquipmentGainDTO;
import logicole.common.datamodels.asset.management.MedicalEquipmentGeneralInformation;
import logicole.common.datamodels.asset.management.MELossRequest;
import logicole.common.datamodels.asset.management.MedicalEquipmentSearchResults;
import logicole.common.datamodels.asset.management.METransferRequest;
import logicole.common.datamodels.asset.management.MedicalEquipmentAssetLoan;
import logicole.common.datamodels.asset.management.MedicalEquipmentAssetLoanSearchResults;
import logicole.common.datamodels.asset.management.MedicalEquipmentItemsOnLoan;
import logicole.common.datamodels.asset.management.MedicalEquipmentSoftware;
import logicole.common.datamodels.asset.management.OperatingSystemRef;
import logicole.common.datamodels.asset.management.Ownership;
import logicole.common.datamodels.asset.management.SoftwareCompanyRef;
import logicole.common.datamodels.asset.management.TransactionReason;
import logicole.common.datamodels.asset.management.TransactionReasonRef;
import logicole.common.datamodels.asset.management.dropDownFeeders.EMedicalEquipmentLoanToContractType;
import logicole.common.datamodels.asset.management.dropDownFeeders.EMedicalEquipmentLoanToIndividualStatus;
import logicole.common.datamodels.asset.management.dropDownFeeders.EMedicalEquipmentLoanToMilitaryServices;
import logicole.common.datamodels.asset.management.dropDownFeeders.EMedicalEquipmentLoanToType;
import logicole.common.datamodels.asset.management.dropDownFeeders.MEConditionEntry;
import logicole.common.datamodels.catalog.CatalogRef;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.finance.referencedata.CommodityCode;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.referencedata.FundCode;
import logicole.common.datamodels.finance.referencedata.FundCodeRef;
import logicole.common.datamodels.finance.referencedata.SalesCodeType;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.organization.AncestryQuery;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationType;
import logicole.common.datamodels.organization.ScopeQuery;
import logicole.common.datamodels.realproperty.Site;
import logicole.common.datamodels.realproperty.SiteRef;
import logicole.common.datamodels.realproperty.facility.FacilitySummary;
import logicole.common.datamodels.space.Floor;
import logicole.common.datamodels.space.Space;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.asset.validation.MedicalEquipmentLossValidator;
import logicole.gateway.services.asset.validation.MedicalEquipmentSoftwareValidator;
import logicole.gateway.services.asset.validation.MedicalEquipmentTransferValidator;
import logicole.gateway.services.asset.validation.MedicalEquipmentValidator;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.finance.FinanceAdminService;
import logicole.gateway.services.finance.FinanceReferenceDataService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.realproperty.InstallationService;
import logicole.gateway.services.spacemanagement.SpaceManagementService;
import logicole.gateway.services.workorder.MedicalEquipmentWorkOrderService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static logicole.common.datamodels.organization.OrganizationConstants.AGENCY_ORG_TYPE_ID;
import static logicole.common.datamodels.organization.OrganizationConstants.DEV_ORG_ID;
import static logicole.common.datamodels.organization.OrganizationConstants.ROOT_ORG_ID;

@ApplicationScoped
public class MedicalEquipmentService extends BaseGatewayService<IMedicalEquipmentMicroserviceApi> {

    @Inject
    AssetService assetService;
    @Inject
    AssetClassificationService assetClassificationService;
    @Inject
    BusinessContactService businessContactService;
    @Inject
    FacilityService facilityService;
    @Inject
    FileManagerAdminService fileManagerAdminService;
    @Inject
    FinanceAdminService financeAdminService;
    @Inject
    FinanceReferenceDataService financeReferenceDataService;
    @Inject
    InstallationService installationService;
    @Inject
    ItemService itemService;
    @Inject
    MedicalEquipmentValidator medicalEquipmentValidator;
    @Inject
    MedicalEquipmentLossValidator medicalEquipmentLossValidator;
    @Inject
    MedicalEquipmentSoftwareValidator medicalEquipmentSoftwareValidator;
    @Inject
    MedicalEquipmentTransferValidator medicalEquipmentTransferValidator;
    @Inject
    OrganizationService organizationService;
    @Inject
    SpaceManagementService spaceManagementService;
    @Inject
    MedicalEquipmentWorkOrderService medicalEquipmentWorkOrderService;

    private static final String SERVICE_NAME_ARMY = "Army";
    private static final String SERVICE_NAME_NAVY = "Navy";
    private static final String SERVICE_NAME_AIR_FORCE = "Air Force";
    private static final String SERVICE_NAME_DHA = "DHA";

    private static final String FINANCIAL_SYSTEM_GFEBS_ID = "58cafe46bf94032ebdf3efb7";
    private static final String FINANCIAL_SYSTEM_MSC_FMS_ID = "58cafe46bf94032ebdf3efbb";
    private static final String FINANCIAL_SYSTEM_SMAS_ID = "58cafe46bf94032ebdf3efb8";

    private static final MonetaryValue CAPITAL_THRESHOLD = new MonetaryValue(250000);

    public MedicalEquipmentService() {
        super("MedicalEquipment");
    }

    public MedicalEquipmentAssetLoan addDurableItemsToLoan(String loanId, List<DurableItemsOnLoan> durableItemsList) {
        return microservice.addDurableItemsToLoan(loanId, durableItemsList);
    }

    public MedicalEquipmentAssetLoan addEquipmentItemsToLoan(String loanId, List<MedicalEquipmentItemsOnLoan> equipmentItemsList) {
        return microservice.addEquipmentItemsToLoan(loanId, equipmentItemsList);
    }

    public Asset addEquipmentNote(String assetId, Note note) {
        return assetService.addAssetNote(assetId, note);
    }

    public MedicalEquipmentAssetLoan addMedicalEquipmentAssetLoanNote(String loanId, Note note) {
        return microservice.addMedicalEquipmentAssetLoanNote(loanId, note);
    }

    public boolean doesCustomerHaveAccountableEquipment(String customerId) {
        return microservice.doesCustomerHaveAccountableEquipment(customerId);
    }

    public List<AccountingStatus> getAccountingStatus() {
        return microservice.getAccountingStatus();
    }

    public Asset getAssetById(String id) {
        return assetService.getAssetById(id);
    }

    public List<CommodityCodeRef> getCommodityRefsByCommodityTypeAndService(String commodityType) {
        String financialSystemId = this.getFinancialSystemId();
        List<CommodityCode> commodityCodes = financeAdminService.getCommodityByFinancialSystemType(financialSystemId, commodityType);
        return commodityCodes.stream()
                .map(CommodityCode::getRef)
                .collect(Collectors.toList());
    }

    public List<FundCodeRef> getFundCodeRefsByService() {
        String financialSystemId = this.getFinancialSystemId();
        List<FundCode> fundCodes = financeAdminService.getFundCodesByFinancialSystem(financialSystemId);
        return fundCodes.stream()
                .map(FundCode::getRef)
                .collect(Collectors.toList());
    }

    private String getFinancialSystemId() {
        String organizationId = currentUserBT.getCurrentUser().profile.currentNodeRef.getId();
        Organization serviceOrg =
                organizationService.getAncestorOrgOfOrgType(organizationId, OrganizationConstants.SERVICE_ORG_TYPE_ID);
        String financialSystemId = "";
        switch(serviceOrg.getName()) {
            case SERVICE_NAME_AIR_FORCE:    financialSystemId = FINANCIAL_SYSTEM_SMAS_ID; break;
            case SERVICE_NAME_NAVY:         financialSystemId = FINANCIAL_SYSTEM_MSC_FMS_ID; break;
            case SERVICE_NAME_ARMY:
            case SERVICE_NAME_DHA:          financialSystemId = FINANCIAL_SYSTEM_GFEBS_ID; break;
        }
        return financialSystemId;
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public List<FacilitySummary> getFacilitiesBySiteUid(String rpsuid) {
        return facilityService.getFacilitiesBySiteUid(rpsuid);
    }

    public List<Floor> getFloorsByFacilityId(String facilityId) {
        return spaceManagementService.getFloorsByFacilityId(facilityId);
    }

    public List<BusinessContactRef> getMEBusinessContactRefs(String isActive) {
        List<BusinessContact> businessContacts = businessContactService.getBusinessContacts(isActive);
        List<BusinessContactRef> businessContactRefs = new ArrayList<>();

        for (BusinessContact businessContact : businessContacts) {
            businessContactRefs.add(businessContact.getRef());
        }
        return businessContactRefs;
    }

    public AssetBusinessContact getMEAssetContactByBusinessContactId(String businessContactId) {
        return assetService.getAssetContactByBusinessContactId(businessContactId);
    }

    public AssetBusinessContact getMEAssetContactByContactId(String contactId) {
        return assetService.getAssetContactByContactId(contactId);
    }

    public AssetCostSummary getMEAssetCostSummaryByAssetId(String id) {
        return assetService.getAssetCostSummaryByAssetId(id);
    }

    public Asset getMEAssetRecordById(String id) {
        return assetService.getAssetById(id);
    }

    public List<Asset> getMEAssetRecordsByIds(List<String> ids) {
        return assetService.getAssetsByAssetIds(ids);
    }

    public List<MEConditionEntry> getMEConditions() {
        return microservice.getMEConditions();
    }

    public List<String> getLossFormNumbers() {
        return microservice.getLossFormNumbers();
    }

    public List<MEEquipmentType> getMEEquipmentTypes() {
        return microservice.getMEEquipmentTypes();
    }

    public SearchResult<MedicalEquipmentAssetLoanSearchResults> getMedicalEquipmentLoanSearchResults(SearchInput searchInput) {
        SearchResult<MedicalEquipmentAssetLoanSearchResults> searchResult;
        ESearchEngine searchEngine = microservice.getSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported at this time.");
        } else {
            searchResult = microservice.getMedicalEquipmentLoanSearchResults(searchInput);
        }

        return searchResult;
    }

    public List<String> getMedicalEquipmentLoanToContractTypes() {
        return EMedicalEquipmentLoanToContractType.getActiveDisplayTextList();
    }

    public List<String> getMedicalEquipmentLoanToIndividualStatuses() {
        return EMedicalEquipmentLoanToIndividualStatus.getActiveDisplayTextList();
    }

    public List<String> getMedicalEquipmentLoanToMilitaryServices() {
        return EMedicalEquipmentLoanToMilitaryServices.getActiveDisplayTextList();
    }

    public List<String> getMedicalEquipmentLoanToTypes() {
        return EMedicalEquipmentLoanToType.getActiveDisplayTextList();
    }

    public SearchResult<MedicalEquipmentSearchResults> getMedicalEquipmentSearchResults(SearchInput searchInput) {
        SearchResult<MedicalEquipmentSearchResults> searchResult;
        ESearchEngine searchEngine = microservice.getSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported at this time.");
        } else {
            searchResult = microservice.getMedicalEquipmentSearchResults(searchInput);
        }

        return searchResult;
    }

    public List<Ownership> getOwnership() {
        return microservice.getOwnership();
    }

    public List<SalesCodeType> getReceivingAgencies() {
        // TODO change getRefDataDetail to use Generics, for now cast to <List<SalesCodeType>
        return financeReferenceDataService.getRefDataDetail("SalesCodeType", null)
                .stream()
                .filter(SalesCodeType.class::isInstance)
                .map(SalesCodeType.class::cast)
                .collect(java.util.stream.Collectors.toList());
    }

    public List<SiteRef> getSiteRefsForInstallation(String installationId) {
        List<Site> sites = installationService.getSitesForInstallation(installationId);
        ArrayList<SiteRef> siteRefs = new ArrayList<>();
        sites.forEach(site -> siteRefs.add((SiteRef) site.getRef()));
        return siteRefs;
    }

    public List<SiteRef> getSitesForOrganization(String organizationId) {
        List<Site> sites = installationService.getSitesByOrganizationId(organizationId);
        ArrayList<SiteRef> siteRefs = new ArrayList<>();
        sites.forEach(site -> siteRefs.add((SiteRef) site.getRef()));
        return siteRefs;
    }

    public List<Space> getSpacesByFloorId(String floorId) {
        return spaceManagementService.getRoomsByFloorId(floorId);
    }

    public List<AssetRef> getSystemECNList() {
        String siteOrgId = this.getCurrentUser().profile.currentNodeRef.getId();
        return microservice.getSystemECNList(siteOrgId);
    }

    public boolean removeAttachment(String id, String fileId) throws IOException {
        try {
            fileManagerAdminService.removeFile(fileId);
        } catch (FatalProcessingException | ApplicationException e) {
            throw new ApplicationException("Was not able to upload the file");
        }

        return assetService.removeAttachment(id, fileId);
    }

    public Asset removeEquipmentNote(String assetId, Note note) {
        return assetService.removeAssetNote(assetId, note);
    }

    public MedicalEquipmentAssetLoan removeMedicalEquipmentAssetLoanNote(String loanId, Note note) {
        return microservice.removeMedicalEquipmentAssetLoanNote(loanId, note);
    }

    public void renewDurableItemsOnLoan(DurableItemRenewalInformation durableItemRenewalInformation) {
        microservice.renewDurableItemsOnLoan(durableItemRenewalInformation);
    }

    public MedicalEquipmentAssetLoan returnDurableItemsFromLoan(String loanId, List<DurableItemsOnLoan> durableItemsOnLoanList) {
        return microservice.returnDurableItemsFromLoan(loanId, durableItemsOnLoanList);
    }

    public void renewEquipmentItemsOnLoan(EquipmentItemRenewalInformation equipmentItemRenewalInformation) {
        microservice.renewEquipmentItemsOnLoan(equipmentItemRenewalInformation);
    }

    public MedicalEquipmentAssetLoan returnEquipmentItemsFromLoan(String loanId, List<MedicalEquipmentItemsOnLoan> equipmentItemsToReturnList) {
        return microservice.returnEquipmentItemsFromLoan(loanId, equipmentItemsToReturnList);
    }

    public Attachment saveAttachment(String id, Attachment attachmentToSave) {
        return assetService.saveAttachment(id, attachmentToSave);
    }

    public Asset saveEquipmentNote(String assetId, Note note) {
        return assetService.saveAssetNote(assetId, note);
    }

    public Asset saveLocationInformation(String id, LocationInformation locationInformation) {
        Asset asset = getAssetById(id);
        asset.locationInformation = locationInformation;
        // TODO: Add validation: validateUniqueIndex(asset)

        return microservice.saveLocationInformation(id, locationInformation);
    }

    public Asset saveMedicalEquipment(@NotNull Asset asset) {
        medicalEquipmentValidator.validateAll(asset, false, null);
        return microservice.saveMedicalEquipment(asset);
    }

    public MedicalEquipmentAssetLoan saveMedicalEquipmentAssetLoan(@NotNull MedicalEquipmentAssetLoan loan) {
        // TODO: Add validation: medicalEquipmentLoanValidator.validate(loan)
        Organization siteOrg = organizationService.getOrganization(loan.loanFromInformation.loanFromOrganizationRef.id);

        loan.loanIdentifier = generateMedicalEquipmentLoanIdentifier(siteOrg.getId());
        loan.isActive = true;
        loan.managedByNodeRef = siteOrg.getRef();
        return microservice.saveMedicalEquipmentAssetLoan(loan);
    }

    public MedicalEquipmentAssetLoan saveMedicalEquipmentAssetLoanNote(String loanId, Note note) {
        return microservice.saveMedicalEquipmentAssetLoanNote(loanId, note);
    }

    public List<Asset> saveTransfer(@NotNull METransferRequest meTransferRequest) {
        meTransferRequest.transactionReasonRef = microservice.getTransactionReasonByReasonCode("CTO");
        METransferRequest validMETransferRequest = this.medicalEquipmentTransferValidator.validate(meTransferRequest);
        return microservice.saveTransfer(validMETransferRequest);
    }

    public List<Asset> saveLoss (@NotNull MELossRequest meLossRequest) {
        MELossRequest validMELossRequest = this.medicalEquipmentLossValidator.validate(meLossRequest);
        return microservice.saveLoss(validMELossRequest);
    }

    public TransactionReason getTransactionReasonById(String id) {
        return microservice.getTransactionReasonsById(id);
    }

    public List<Asset> gainMedicalEquipment(MedicalEquipmentGainDTO medicalEquipmentGainDTO) {
        medicalEquipmentValidator.validateGainSerialNumbers(medicalEquipmentGainDTO.assetList);
        for (Asset asset : medicalEquipmentGainDTO.assetList) {
            if (asset.medicalEquipmentAsset == null) {
                asset.medicalEquipmentAsset = new MedicalEquipmentAsset();
            }
            if (asset.medicalEquipmentAsset.generalInformation == null) {
                asset.medicalEquipmentAsset.generalInformation = new MedicalEquipmentGeneralInformation();
            }
            // Retrieve item information
            if (asset.itemRef != null && !StringUtil.isEmptyOrNull(asset.itemRef.getId())) {
                Item item = itemService.getItemById(asset.itemRef.getId());
                asset.itemRef = item.getRef();

                // Get nomenclature information
                // This will retrieve site-managed nomenclature if current user is a site user, not sure if we want this
                // We might want to pass in current user's Agency node id instead. Revisit when we work on Gain
                Nomenclature nomenclature = assetClassificationService.getNomenclatureByCodeTypeAndOrg(
                        item.deviceCode, EAssetType.MEDICAL_EQUIPMENT.name(), getCurrentUser().profile.currentNodeRef);
                if (nomenclature != null) {
                    asset.nomenclatureRef = nomenclature.getRef();
                    asset.medicalEquipmentAsset.generalInformation.lifeExpectancyYearsQty = nomenclature.lifeExpectancyYearsQty;
                    asset.medicalEquipmentAsset.generalInformation.isMaintenanceRequired = nomenclature.isMaintenanceRequired;
                }
            }
            asset.assetType = EAssetType.MEDICAL_EQUIPMENT;
            asset.isActive = true;
            asset.medicalEquipmentAsset.generalInformation.isAccountable = true;
            asset.medicalEquipmentAsset.generalInformation.accountingStatus = EAccountingStatus.AWAITING_ACCEPTANCE;
            asset.medicalEquipmentAsset.generalInformation.accountingStatusDate = new Date();
            // TODO: Defaulting ownership type to Organizational. Will need to update this to populate based off transaction reason.
            asset.medicalEquipmentAsset.generalInformation.ownershipType = EOwnership.ORGANIZATIONAL.displayText;
            if (asset.acquisitionInformation.acquisitionDate == null) {
                asset.acquisitionInformation.acquisitionDate = new Date();
            }
            if (asset.acquisitionInformation.acquisitionCost.compareTo(CAPITAL_THRESHOLD) >= 0
                    && asset.acquisitionInformation.accumulatedDepreciation == null) {
                asset.acquisitionInformation.accumulatedDepreciation = new MonetaryValue(0);
            }
            if (asset.medicalEquipmentAsset.customerRef != null
                    && !StringUtil.isEmptyOrNull(asset.medicalEquipmentAsset.customerRef.getId())) {
                Organization siteOrg = organizationService.getAncestorOrgOfOrgType(
                        asset.medicalEquipmentAsset.customerRef.getId(), OrganizationConstants.SITE_ORG_TYPE_ID);
                asset.managedByNodeRef = siteOrg.getRef();

                // Get custodian information
                Custodian custodian = microservice.getCustodianByCustomerId(asset.medicalEquipmentAsset.customerRef.getId());
                if (custodian != null) {
                    asset.medicalEquipmentAsset.custodianRef = custodian.getRef();
                }
            }
            TransactionReason transactionReason = getTransactionReasonById(medicalEquipmentGainDTO.transactionReasonId);
            medicalEquipmentValidator.validateAll(asset, true, transactionReason.getRef());
        }
        List<Asset> gainedAssets = microservice.gainMedicalEquipment(medicalEquipmentGainDTO);
        gainedAssets.forEach(asset -> {
            medicalEquipmentWorkOrderService.createWorkOrderFromMedicEquipmentGain(asset);
        });
        return gainedAssets;
    }

    public List<ItemRef> findEquipmentItems(String searchString) {
        SearchInput searchInput = new SearchInput();
        searchInput.searchText = searchString;
        searchInput.searchCriteria = new ArrayList<>();
        SearchResult<ItemRef> searchResult = itemService.getItemRefs(searchInput);
        // TODO: update this to use CommodityClassRef
        List<ItemRef> results = searchResult.results.stream().filter(item -> "Equipment".equalsIgnoreCase(item.commodityType)).collect(Collectors.toList());
        return results;
    }

    public List<String> getDocumentTypes() {
        return facilityService.getDocumentTypes();
    }

    public List<CatalogRef> getDurableItemsAvailableToLoan(String customerId) {
        //TODO: get items from catalog. Need EP.
        return new ArrayList<>();
    }

    public List<DurableItemsOnLoan> getDurableItemsByLoanId(String loanId) {
        return microservice.getDurableItemsByLoanId(loanId);
    }

    public List<OrganizationRef> getEquipmentCustomers() {
        AncestryQuery ancestryQuery = new AncestryQuery();
        ancestryQuery.organizationTypeId = OrganizationConstants.CUSTOMER_ORG_TYPE_ID;
        if (OrganizationConstants.isRootOrDevUser(currentUserBT.getCurrentNodeId())) {
            ancestryQuery.scopeOrganizationIds = List.of(OrganizationConstants.ROOT_ORG_ID);
        } else {
            ancestryQuery.scopeOrganizationIds = List.of(currentUserBT.getCurrentNodeId());
        }
        List<Organization> customers = organizationService.getScopeUsingAncestry(ancestryQuery);

        return customers.stream().map(Organization::getRef).collect(Collectors.toList());
    }

    public List<MedicalEquipmentItemsOnLoan> getEquipmentItemsByLoanId(String loanId) {
        return microservice.getEquipmentItemsByLoanId(loanId);
    }

    public List<Asset> getEquipmentItemsWithNoLoanId(String customerId) {
        return microservice.getEquipmentItemsWithNoLoanId(customerId);
    }

    public List<ManufacturerRef> getManufacturersBySiteAndAgency() {
        UserProfile currentUserProfile = currentUserBT.getCurrentUser().profile;
        String currentNodeRefId = currentUserProfile.currentNodeRef.id;
        boolean isDevOrRootProfile = (currentNodeRefId.equals(ROOT_ORG_ID) || currentNodeRefId.equals(DEV_ORG_ID));
        if (isDevOrRootProfile) {
            return null;
        } else {
            List<String> organizationIds = new ArrayList<>();
            organizationIds.add(currentNodeRefId);
            Organization agencyOrg = organizationService.getAncestorOrgOfOrgType(currentNodeRefId, AGENCY_ORG_TYPE_ID);
            if (agencyOrg != null) {
                String agencyOrgId = agencyOrg.getId();
                organizationIds.add(agencyOrgId);
            }
            List<Manufacturer> manufacturers = microservice.getManufacturersByOrgIds(organizationIds);
            return manufacturers.stream()
                    .map(Manufacturer::getRef)
                    .collect(Collectors.toList());
        }
    }

    public MedicalEquipmentAssetLoan getMedicalEquipmentAssetLoanRecordById(String id) {
        return microservice.getMedicalEquipmentAssetLoanRecordById(id);
    }

    public Asset getMedicalEquipmentByECN(String ecn) {
        return microservice.getMedicalEquipmentByECN(ecn, currentUserBT.getCurrentNodeId());
    }

    public Asset getMedicalEquipmentBySerial(String serialNumber, String nameplateModel, String manufactureId) {
        return microservice.getMedicalEquipmentBySerial(serialNumber, currentUserBT.getCurrentNodeId(), nameplateModel, manufactureId);
    }

    public Item getItemById(String id) {
        return itemService.getItemById(id);
    }

    public Integer getMaxAttachmentSize() {
        return assetService.getMaxAttachmentSize();
    }

    public String generateMedicalEquipmentLoanIdentifier(String siteOrgId) {
        return microservice.generateMedicalEquipmentLoanIdentifier(siteOrgId);
    }

    public Asset saveGeneralInformation(Asset asset) {
        medicalEquipmentValidator.validateGeneralInformation(asset);
        return microservice.saveGeneralInformation(asset);
    }

    public Asset saveOwnerCustodianInformation(String id, Asset asset) {
        return microservice.saveOwnerCustodianInformation(id, asset);
    }

    public Asset setMEAssetActive(String assetId) {
        return microservice.setMEAssetActive(assetId);
    }

    public Asset setMEAssetInactive(String assetId) {
        return microservice.setMEAssetInactive(assetId);
    }

    public Asset saveMEAssetWarranty(String id, AcquisitionInformation acquisitionInformation) {
        return microservice.saveMEAssetWarranty(id, acquisitionInformation);
    }

    public MedicalEquipmentAssetLoan saveMedicalEquipmentLoanFromInformation(MedicalEquipmentAssetLoan loan) {
        return microservice.saveMedicalEquipmentLoanFromInformation(loan);
    }

    public MedicalEquipmentAssetLoan saveMedicalEquipmentLoanToInformation(MedicalEquipmentAssetLoan loan) {
        return microservice.saveMedicalEquipmentLoanToInformation(loan);
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }

    public List<TransactionReasonRef> getTransactionReasonsByCode(String code) {
        return microservice.getTransactionReasonsByCode(code);
    }

    public Organization getOrganizationById(String id) {
        return organizationService.getOrganization(id);
    }

    public List<OrganizationRef> getOrganizationRefsByCurrentUserScope() {
        OrganizationRef currentUserOrganization = this.getCurrentUser().profile.currentNodeRef;
        OrganizationType siteOrganizationType = this.getOrganizationTypeByName("Site");
        if (siteOrganizationType != null) {
            ScopeQuery scopeQuery = new ScopeQuery();
            scopeQuery.nodeTypeId = siteOrganizationType.getId();
            scopeQuery.nodeTypeName = siteOrganizationType.name;
            scopeQuery.scopeList = List.of(currentUserOrganization.getId());

            return this.organizationService.getOrganizationsInScopeByOrganizationTypeName(scopeQuery).stream()
                    .map(Organization::getRef)
                    .collect(Collectors.toList());
        } else {
            return List.of();
        }
    }

    private OrganizationType getOrganizationTypeByName(String name) {
        return this.organizationService.getOrganizationTypes().stream()
                .filter(type -> name.equalsIgnoreCase(type.name))
                .findFirst()
                .orElse(null);
    }

    public List<OrganizationRef> getChildOrganizationRefsById(String id) {
        return this.organizationService.getOrganizationChildren(id).stream()
                .map(Organization::getRef)
                .collect(Collectors.toList());
    }

    public SearchResult<MedicalEquipmentSoftware> getEquipmentSoftwareSearchResults(SearchInput searchInput) {
        return microservice.getEquipmentSoftwareSearchResults(searchInput);
    }

    public MedicalEquipmentSoftware getEquipmentSoftwareById(String id) {
        return microservice.getEquipmentSoftwareById(id);
    }

    public List<SoftwareCompanyRef> getSoftwareCompanies() {
        return microservice.getSoftwareCompanies();
    }

    public List<OperatingSystemRef> getOperatingSystems() {
        return microservice.getOperatingSystems();
    }

    public List<String> getSoftwareTypes() {
        return ESoftwareType.getDisplayTextList();
    }

    public List<String> getMediumTypes() {
        return EMediumType.getDisplayTextList();
    }

    public MedicalEquipmentSoftware saveEquipmentSoftware(MedicalEquipmentSoftware medicalEquipmentSoftware) {
        if (StringUtil.isEmptyOrNull(medicalEquipmentSoftware.getId())) {
            Organization siteOrg = organizationService.getAncestorOrgOfOrgType(
                    medicalEquipmentSoftware.ownedByNodeRef.getId(), OrganizationConstants.SITE_ORG_TYPE_ID);
            medicalEquipmentSoftware.managedByNodeRef = siteOrg.getRef();
        }
        medicalEquipmentSoftwareValidator.validate(medicalEquipmentSoftware);
        return microservice.saveEquipmentSoftware(medicalEquipmentSoftware);
    }

    public MedicalEquipmentSoftware saveEquipmentSoftwareLicense(MedicalEquipmentSoftware medicalEquipmentSoftware) {
        medicalEquipmentSoftwareValidator.validate(medicalEquipmentSoftware);
        return microservice.saveEquipmentSoftwareLicense(medicalEquipmentSoftware);
    }

    public List<SoftwareNomenclatureRef> getSoftwareNomenclatures() {
        return microservice.getSoftwareNomenclatures();
    }

    public MedicalEquipmentSoftware addEquipmentSoftwareNote(String id, Note note) {
        return microservice.addEquipmentSoftwareNote(id, note);
    }

    public MedicalEquipmentSoftware saveEquipmentSoftwareNote(String id, Note note) {
        return microservice.saveEquipmentSoftwareNote(id, note);
    }

    public MedicalEquipmentSoftware removeEquipmentSoftwareNote(String id, Note note) {
        return microservice.removeEquipmentSoftwareNote(id, note);
    }

    public List<MedicalEquipmentSoftware> getMedicalEquipmentSoftwareByAssetId(String assetId) {
        return microservice.getMedicalEquipmentSoftwareByAssetId(assetId);
    }

    public List<Asset> getAvailableEquipment(String customerId) {
        return microservice.getAvailableEquipment(customerId);
    }
}
