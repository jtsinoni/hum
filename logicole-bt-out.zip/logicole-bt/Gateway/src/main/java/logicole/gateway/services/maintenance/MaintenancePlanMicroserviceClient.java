package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.IMaintenancePlanMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class MaintenancePlanMicroserviceClient extends MicroserviceClient<IMaintenancePlanMicroserviceApi> {

    public MaintenancePlanMicroserviceClient() {
        super(IMaintenancePlanMicroserviceApi.class, "logicole-maintenance");
    }

    @Produces
    public IMaintenancePlanMicroserviceApi getIMaintenancePlanMicroserviceApi() {
        return createClient();
    }

}
