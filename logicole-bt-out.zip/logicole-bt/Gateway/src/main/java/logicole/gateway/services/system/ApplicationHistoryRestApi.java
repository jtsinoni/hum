package logicole.gateway.services.system;

import io.swagger.annotations.Api;
import logicole.common.datamodels.history.ApplicationHistory;
import logicole.gateway.rest.ExternalRestApi;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;

@Api(tags = {"ApplicationHistory"})
@ApplicationScoped
@Path("/applicationHistory")
public class ApplicationHistoryRestApi extends ExternalRestApi<ApplicationHistoryService> {

    @GET
    @Path("/findByInputParameterId")
    public List<ApplicationHistory> findByInputParameterId(@QueryParam("id") String id) {
        return service.findByInputParameterId(id);
    }

    @GET
    @Path("/findByApplication")
    public List<ApplicationHistory> findByApplication(@QueryParam("application") String application) {
        return service.findByApplication(application);
    }

    @GET
    @Path("/findByUser")
    public List<ApplicationHistory> findByUser(@QueryParam("userId") String userId) {
        return service.findByUser(userId);
    }

}
