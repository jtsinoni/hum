package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.Business;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;
import javax.enterprise.context.ApplicationScoped;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;


@Api(tags = {"EnterpriseCatalogLookup"})
@ApplicationScoped
@Path("/abi/enterprisecatalogLookup")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class EnterpriseCatalogLookupRestApi extends ExternalRestApi<EnterpriseCatalogLookupService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getBusinessByName")
    public Business getBusinessByName(@QueryParam("manufacturerName") String businessName) {
        return service.getBusinessByName(businessName);
    }

    @GET
    @Path("/getProvisionalEPI")
    @Produces(MediaType.TEXT_PLAIN)
    public String getProvisionalEPI(@QueryParam("manufacturerName") String manufacturerName, @QueryParam("manufacturerPartNumber") String manufacturerPartNumber){
        return service.getProvisionalEPI(manufacturerName, manufacturerPartNumber);
    }

}
