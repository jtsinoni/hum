package logicole.gateway.services.assemblage;

import io.swagger.annotations.Api;
import logicole.common.datamodels.assemblage.*;
import logicole.common.datamodels.inventory.StratificationRef;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import java.util.List;

@Api(tags = {"AssemblageLookup"})
@ApplicationScoped
@Path("/assemblageLookup")
public class AssemblageLookupRestApi extends ExternalRestApi<AssemblageLookupService> {

    @GET
    @Path("/getCommingledCodes")
    public List<CommingledCode> getCommingledCodes() {
        return service.getCommingledCodes();
    }


    @POST
    @Path("/createCommingledCode")
    public List<CommingledCode> createCommingledCode(CommingledCode commingledCode) {
        return service.createCommingledCode(commingledCode);
    }

    @POST
    @Path("/updateCommingledCode")
    public List<CommingledCode> updateCommingledCode(CommingledCode commingledCode) {
        return service.updateCommingledCode(commingledCode);
    }

    @POST
    @Path("/deleteCommingledCode")
    public List<CommingledCode> deleteCommingledCode(CommingledCode commingledCode) {
        return service.deleteCommingledCode(commingledCode);
    }

    @GET
    @Path("/getCriticalCodes")
    public List<CriticalCode> getCriticalCodes() {
        return service.getCriticalCodes();
    }

    @POST
    @Path("/createCriticalCode")
    public List<CriticalCode> createCriticalCode(CriticalCode criticalCode) {
        return service.createCriticalCode(criticalCode);
    }

    @POST
    @Path("/updateCriticalCode")
    public List<CriticalCode> updateCriticalCode(CriticalCode criticalCode) {
        return service.updateCriticalCode(criticalCode);
    }

    @POST
    @Path("/deleteCriticalCode")
    public List<CriticalCode> deleteCriticalCode(CriticalCode criticalCode) {
        return service.deleteCriticalCode(criticalCode);
    }

    @GET
    @Path("/getDeferredCodes")
    public List<DeferredCode> getDeferredCodes() {
        return service.getDeferredCodes();
    }

    @POST
    @Path("/createDeferredCode")
    public List<DeferredCode> createDeferredCode(DeferredCode deferredCode) {
        return service.createDeferredCode(deferredCode);
    }

    @POST
    @Path("/updateDeferredCode")
    public List<DeferredCode> updateDeferredCode(DeferredCode deferredCode) {
        return service.updateDeferredCode(deferredCode);
    }

    @POST
    @Path("/deleteDeferredCode")
    public List<DeferredCode> deleteDeferredCode(DeferredCode deferredCode) {
        return service.deleteDeferredCode(deferredCode);
    }

    @GET
    @Path("/getOperationalStatuses")
    public List<OperationalStatus> getOperationalStatuses() {
        return service.getOperationalStatuses();
    }

    @GET
    @Path("/getEquipmentReportingCodes")
    public List<EquipmentReportingCodeRef> getEquipmentReportingCodes() {
        return service.getEquipmentReportingCodes();
    }

    @GET
    @Path("/getScopes")
    public List<Scope> getScopes() {
        return service.getScopes();
    }

    @GET
    @Path("/getCustomers")
    public List<Customer> getCustomers() {
        return service.getCustomers();
    }

    @GET
    @Path("/getExpenseCenters")
    public List<ExpenseCenter> getExpenseCenters() {
        return service.getExpenseCenters();
    }

    @GET
    @Path("/getEquipmentReportingCodesAll")
    public List<EquipmentReportingCode> getEquipmentReportingCodesAll() {
        return service.getEquipmentReportingCodesAll();
    }

    @POST
    @Path("/createEquipmentReportingCode")
    public List<EquipmentReportingCode> createEquipmentReportingCode(EquipmentReportingCode equipmentReportingCode) {
        return service.createEquipmentReportingCode(equipmentReportingCode);
    }

    @POST
    @Path("/updateEquipmentReportingCode")
    public List<EquipmentReportingCode> updateEquipmentReportingCode(EquipmentReportingCode equipmentReportingCode) {
        return service.updateEquipmentReportingCode(equipmentReportingCode);
    }

    @POST
    @Path("/deleteEquipmentReportingCode")
    public List<EquipmentReportingCode> deleteEquipmentReportingCode(EquipmentReportingCode equipmentReportingCode) {
        return service.deleteEquipmentReportingCode(equipmentReportingCode);
    }

    @GET
    @Path("/getManaged")
    public List<Managed> getManaged() {
        return service.getManaged();
    }

    @GET
    @Path("/getAssociatedOrganizationRefByCode")
    public AssociatedOrganizationRef getAssociatedOrganizationRefByCode(@QueryParam("associatedOrganizationCode") String associatedOrganizationCode) {
        associatedOrganizationCode = "AF".equals(associatedOrganizationCode) ? "DF" : associatedOrganizationCode;
        return service.getAssociatedOrganizationRefByCode(associatedOrganizationCode);
    }

    @GET
    @Path("/getAssociatedOrganizationRefs")
    public List<AssociatedOrganizationRef> getAssociatedOrganizationRefs() {
        return service.getAssociatedOrganizationRefs();
    }

    @GET
    @Path("/getOrganizationRefByAgencyAndType")
    public List<OrganizationRef> getOrganizationRefByAgencyAndType(@QueryParam("targetTypeName") String targetTypeName) {
        return service.getOrganizationRefByAgencyAndType(targetTypeName);
    }

    @GET
    @Path("/getAllowanceStandardManagerInformation")
    public List<String> getAllowanceStandardManagerInformation(@QueryParam("name") String name) {
        return service.getAllowanceStandardManagerInformation(name);
    }

    @GET
    @Path("/getStratificationRefs")
    public List<StratificationRef> getStratificationRefs() {
        return service.getStratificationRefs();
    }

    @GET
    @Path("/getPriorityOptions")
    public List<Priority> getPriorityOptions() {
        return service.getPriorityOptions();
    }

    @GET
    @Path("/getShipperOptions")
    public List<Shipper> getShipperOptions() {
        return service.getShipperOptions();
    }

    @GET
    @Path("/getStatusOptions")
    public List<Status> getStatusOptions() {
        return service.getStatusOptions();
    }

    @GET
    @Path("/getCapabilityOptions")
    public List<Capability> getCapabilityOptions() {
        return service.getCapabilityOptions();
    }

    @GET
    @Path("/getRoleOfCareOptions")
    public List<RoleOfCare> getRoleOfCareOptions() {
        return service.getRoleOfCareOptions();
    }

    @GET
    @Path("/getAssemblageTypeOptions")
    public List<AssemblageType> getAssemblageTypeOptions() {
        return service.getAssemblageTypeOptions();
    }

    @GET
    @Path("/getPackTypeOptions")
    public List<PackType> getPackTypeOptions() {
        return service.getPackTypeOptions();
    }
}
