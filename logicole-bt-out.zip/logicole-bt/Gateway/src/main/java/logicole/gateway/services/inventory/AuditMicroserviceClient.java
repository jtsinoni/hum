package logicole.gateway.services.inventory;

import logicole.apis.inventory.IAuditMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AuditMicroserviceClient extends MicroserviceClient<IAuditMicroserviceApi> {
    public AuditMicroserviceClient() {
        super(IAuditMicroserviceApi.class, "logicole-inventory");
    }

    @Produces
    public IAuditMicroserviceApi getIAuditMicroserviceApi() {
        return createClient();
    }
}
