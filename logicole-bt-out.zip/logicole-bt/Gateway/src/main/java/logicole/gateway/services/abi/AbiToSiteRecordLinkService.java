package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiToSiteRecordLinkMicroserviceApi;
import logicole.common.datamodels.abi.ABiToSiteRecordLinkResult;
import logicole.common.datamodels.product.AbiToProductUpdate;
import logicole.common.datamodels.product.SiteCatalogRecord;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.product.ProductService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class AbiToSiteRecordLinkService extends BaseGatewayService<IAbiToSiteRecordLinkMicroserviceApi> {

    @Inject
    AbiStagingService abiStagingService;

    @Inject
    ProductService productService;

    public AbiToSiteRecordLinkService() {
        super("AbiToSiteRecordLink");
    }

    public List<SiteCatalogRecord> getByNdc(@QueryParam("ndc") String ndc) {
        return productService.getByNDC(ndc);
    }

    public List<SiteCatalogRecord> getByManufacturerNameAndCatalogNumber(@QueryParam("manufacturerNm") String manufacturerNm,
                                                                         @QueryParam("manufCatNum") String manufCatNum) {
        return productService.getByManufacturerNameAndCatalogNumber(manufacturerNm, manufCatNum);
    }

    public List<SiteCatalogRecord> getByManufacturerCatalogNumber(@QueryParam("manufCatNum") String manufCatNum) {
        return productService.getByManufacturerCatalogNumber(manufCatNum);
    }

    public List<SiteCatalogRecord> getByEnterpriseProductIdentifier(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return productService.getByEnterpriseProductIdentifier(enterpriseProductIdentifier);
    }

    public List<SiteCatalogRecord> getByProductSeqId(@QueryParam("productSeqId") Integer productSeqId) {
        return productService.getByProductSeqId(productSeqId);
    }

    public List<SiteCatalogRecord> getByEnterpriseItemIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier) {
        return productService.getByEnterpriseItemIdentifier(enterpriseItemIdentifier);
    }

    public ABiToSiteRecordLinkResult updateEnterpriseProductIdentifiersByIds(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier,
                                                                             List<String> idList) {
        ABiToSiteRecordLinkResult result = new ABiToSiteRecordLinkResult();
        result.updateWasSuccessful = false;
        if (StringUtil.isEmptyOrNull(enterpriseProductIdentifier)) {
            result.messages.add("A valid Enterprise Product Identifier must be specified.");
        } else if (!abiStagingService.doesEnterpriseProductIdentifierExist(enterpriseProductIdentifier)) {
            result.messages.add("The specified Enterprise Product Identifier does not exist in ABi Staging.");
        } else {
            List<String> currentEnterpriseProductIdentifiers =
                    productService.getDistinctEnterpriseProductIdentifiersByIds(idList);
            if (currentEnterpriseProductIdentifiers == null) {
                currentEnterpriseProductIdentifiers = new ArrayList<>();
            }
            if (!currentEnterpriseProductIdentifiers.contains(enterpriseProductIdentifier)) {
                currentEnterpriseProductIdentifiers.add(enterpriseProductIdentifier);
            }
            Integer numRecordsUpdated = productService.updateEnterpriseProductIdentifiersByIds(enterpriseProductIdentifier, idList);
            if (numRecordsUpdated > 0) {
                result.messages.add(numRecordsUpdated.toString() + " Site Catalog records were updated.");
                result.updateWasSuccessful = true;
                currentEnterpriseProductIdentifiers.forEach(entProdId ->
                        updateABiSiteCountsByEnterpriseProductIdentifier(entProdId, result.messages));

            } else {
                result.messages.add("No Site Catalog records were updated.");
            }
        }
        return result;
    }

    protected void updateABiSiteCountsByEnterpriseProductIdentifier(String enterpriseProductIdentifier,
                                                                    List<String> messages) {
        if (!StringUtil.isEmptyOrNull(enterpriseProductIdentifier)) {
            Integer siteCount = productService.getSiteCount(enterpriseProductIdentifier);
            Integer numUpdated = microservice.updateSiteCountForEnterpriseProductIdentifier(enterpriseProductIdentifier, siteCount);
            if (numUpdated != null) {
                if (numUpdated > 0) {
                    messages.add("Updated ABI Catalog Record Site Count to " + siteCount +
                            " for Enterprise Product Identifier '" +
                            enterpriseProductIdentifier + "'.");
                }
            } else {
                messages.add("ABI Catalog Record for Enterprise Product Identifier '" +
                        enterpriseProductIdentifier + "' could not be updated with Site Count of " + siteCount + ".");
            }
            numUpdated = microservice.updateStagingSiteCountForEnterpriseProductIdentifier(enterpriseProductIdentifier, siteCount);
            if (numUpdated != null) {
                if (numUpdated > 0) {
                    messages.add("Updated ABI Catalog Staging Record Site Count to " + siteCount +
                            " for Enterprise Product Identifier '" +
                            enterpriseProductIdentifier + "'.");
                }
            } else {
                messages.add("ABI Catalog Staging Record for Enterprise Product Identifier '" +
                        enterpriseProductIdentifier + "' could not be updated with Site Count of " + siteCount + ".");
            }
        }
    }

    public Integer updateSiteCountForEnterpriseProductIdentifier(String enterpriseProductIdentifier, Integer siteCount) {
        return microservice.updateSiteCountForEnterpriseProductIdentifier(enterpriseProductIdentifier, siteCount);
    }

    public boolean doesEnterpriseProductIdentifierExist(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return abiStagingService.doesEnterpriseProductIdentifierExist(enterpriseProductIdentifier);
    }

    public ABiToSiteRecordLinkResult removeEnterpriseProductIdentifiersByIds(List<String> idList) {
        ABiToSiteRecordLinkResult result = new ABiToSiteRecordLinkResult();
        result.updateWasSuccessful = false;

        List<String> removedEntProdIdList = new ArrayList<>();
        idList.forEach(id -> {
            SiteCatalogRecord record = productService.getById(id);
            String entProdId = record.enterpriseProductIdentifier;
            if (!removedEntProdIdList.contains(entProdId)) {
                removedEntProdIdList.add(entProdId);
            }
        });
        AbiToProductUpdate abiToProductUpdate = productService.removeEnterpriseProductIdentifiersByIds(idList);
        if ((abiToProductUpdate.siteCatalogUpdated != null) && (abiToProductUpdate.siteCatalogUpdated > 0)) {
            result.updateWasSuccessful = true;
            result.messages.add("Removed Enterprise Product Identifier from " + abiToProductUpdate.siteCatalogUpdated + " Site Catalog records.");
            removedEntProdIdList.forEach(entProdId ->
                    updateABiSiteCountsByEnterpriseProductIdentifier(entProdId, result.messages));
        }
        if ((abiToProductUpdate.ehrEnabledSiteCatalog != null) && (abiToProductUpdate.ehrEnabledSiteCatalog > 0)) {
            result.updateWasSuccessful = true;
            result.messages.add("Enterprise Product Identifier is not removed from " + abiToProductUpdate.ehrEnabledSiteCatalog + " Site Catalog records as it is marked as EHR enabled under EHR management.");
        }

        return result;
    }

    public SiteCatalogRecord findSiteCatalogById(String id) {
        return productService.getById(id);
    }

}
