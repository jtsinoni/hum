package logicole.gateway.services.finance;

import io.swagger.annotations.Api;
import logicole.common.datamodels.finance.FinanceDecision;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.request.EBusinessEventType;
import logicole.common.datamodels.finance.response.CommonFinanceResponse;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import java.util.List;

@Api(tags = {"financeProcessing"})
@ApplicationScoped
@Path("/financeProcessing")
public class FinanceProcessingRestApi extends ExternalRestApi<FinanceProcessingService> {

    @GET
    @Path("/getAllFinanceDecisionData")
    public List<FinanceDecision> getAllFinanceDecisionData() {
        return service.getAllFinanceDecisionData();
    }

    @POST
    @Path("/processFinanceRequest")
    public CommonFinanceResponse processFinanceRequest(CommonFinanceRequestFromApi commonFinanceRequestApi) {
        CommonFinanceRequest commonFinanceRequest = new CommonFinanceRequest();
        commonFinanceRequest.eventType = EBusinessEventType.fromName(commonFinanceRequestApi.eventType);
        commonFinanceRequest.requestGroups = commonFinanceRequestApi.requestGroups;
        commonFinanceRequest.requestingOrg = commonFinanceRequestApi.requestingOrg;
        commonFinanceRequest.financialSystem = commonFinanceRequestApi.financialSystem;
        commonFinanceRequest.sourceType = commonFinanceRequestApi.sourceType;
        return service.processFinanceRequest(commonFinanceRequest);
    }

}
