package logicole.gateway.services.user;

import logicole.apis.user.IUserMicroserviceApi;
import logicole.common.cache.CurrentUserCache;
import logicole.common.datamodels.Configuration;
import logicole.common.datamodels.featureflag.FeatureFlag;
import logicole.common.datamodels.notification.EmailMessage;
import logicole.common.datamodels.organization.*;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.system.InitializationRoutineRef;
import logicole.common.datamodels.system.InitializationRoutineResult;
import logicole.common.datamodels.user.*;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.UserNotFoundException;
import logicole.common.general.util.DateUtil;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.InstallationService;
import logicole.gateway.services.system.NotificationService;
import logicole.gateway.services.system.SystemFeatureFlagService;
import logicole.gateway.services.user.provider.RoleRemovalValidationProvider;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

@ApplicationScoped
public class UserService extends BaseGatewayService<IUserMicroserviceApi> {

    private static final String BUSINESS_INTELLIGENCE_FUNCTIONAL_AREA = "Business Intelligence";

    private static final String UPDATE_REASON_WARNING = "An update reason is required.";

    @Inject
    NotificationService notificationService;
    @Inject
    InvitationService invitationService;
    @Inject
    UserRequestService userRequestService;
    @Inject
    OrganizationService organizationService;
    @Inject
    PermissionService permissionService;
    @Inject
    SystemFeatureFlagService systemFeatureFlagService;
    @Inject
    RoleService roleService;
    @Inject
    RoleRemovalValidationProvider roleRemovalValidationProvider;
    @Inject
    InstallationService installationService;
    @Inject
    DateUtil dateUtil;

    @Inject
    private CurrentUserCache currentUserCache;

    @Inject
    private JSONUtil jsonUtil;

    public UserService() {
        super("User");
    }

    @Override
    protected void onInitialized() {
        super.onInitialized();
        permissionService.loadCache();
    }

    @Override
    protected void addInitializationRoutines() {
        addInitializationRoutine("5fc851c9-5816-44f4-bb37-c6e728bfba85", this::addSomeNewEndpoint);
    }

    private InitializationRoutineResult addSomeNewEndpoint(InitializationRoutineRef initializationRoutineRef) {
        return new InitializationRoutineResult(InitializationRoutineResult.EStatus.Completed);
    }


    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public LoginCredential logIn() {
        CurrentUser currentUser = this.getCurrentUser();
        String jsonWebToken = currentUserBT.getJsonWebToken();
        return new LoginCredential(currentUser, jsonWebToken);
    }

    public Boolean logOut() {

        String jsonWebToken = currentUserBT.getJsonWebToken();

        if (jsonWebToken != null) {
            currentUserCache.remove(jsonWebToken);
        }
        return true;
    }

    public UserProfile getUserProfileById(String id) {
        return microservice.getUserProfileById(id);
    }

    public UserProfile getBackupUserProfileById(String id) {
        return microservice.getBackupUserProfileById(id);
    }

    public Boolean cleanUpDevProfiles() {
        return microservice.cleanUpDevProfiles();
    }

    public UserProfile getUserProfileByUserRequestId(String id) {
        return microservice.getUserProfileByUserRequestId(id);
    }

    protected CurrentUser getCurrentUserByPkiDn(String pkiDn) {
        Map<String, FeatureFlag> ffMap = getFeatureFlagMap();
        CurrentUser currentUser = microservice.getUsersCurrentProfile(pkiDn, ffMap);

        if (null == currentUser) {
            throw new UserNotFoundException("No active profiles found.");
        }

        UserProfile profile = currentUser.profile;
        currentUser.accessToNodes = organizationService.determineOrganizationAccess(profile.nodeTypeRef.id, profile.scopeNodeRefs);

        return currentUser;
    }

    public Map<String, FeatureFlag> getFeatureFlagMap() {
        List<FeatureFlag> list = systemFeatureFlagService.getAllFeatureFlags();
        Map<String, FeatureFlag> map = new HashMap<>();
        for (FeatureFlag flag : list) {
            map.put(flag.getId(), flag);
        }
        return map;
    }

    public List<UserProfile> getUsersForRoleId(String id) {
        return microservice.getUsersForRoleId(id);
    }

    public void updateRoleRefs(UserProfile user) {
        microservice.updateRoleRefs(user);
    }

    public void updateAssignableRoleRefs(RoleRef roleRef) {
        microservice.updateAssignableRoleRefs(roleRef);
    }

    public String getCntActiveUserProfiles(String pkiDn) {
        return microservice.getCntActiveUserProfiles(pkiDn);
    }

    public List<UserProfile> getActiveUserProfiles() {
        String pkiDn = this.currentUserBT.getCurrentUser().profile.pkiDn;
        return microservice.getActiveUserProfiles(pkiDn);
    }

    public List<UserProfile> getActiveUserProfiles(String pkiDn) {
        return microservice.getActiveUserProfiles(pkiDn);
    }

    public List<RoleRef> getCurrentProfileRoleRefs() {
        return roleService.getCurrentUserRoleRefs();
    }

    public List<RoleRef> getCurrentProfileAssignableRoleRefs() {
        CurrentUser currentUser = getCurrentUser();

        if (Boolean.TRUE.equals(currentUser.profile.isAllAssignableRoles)
                || currentUser.profile.assignableRoleRefs.isEmpty()) {
            return currentUser.profile.assignableRoleRefs;
        } else {
            return roleService.getCurrentUserAssignableRoleRefs();
        }
    }

    public List<UserProfile> getUserProfilesByPkiDn(@QueryParam("pkiDn") String pkiDn) {
        return microservice.getUserProfilesByPkiDn(pkiDn);
    }

    public CurrentUser setCurrentProfile(String id) {
        return microservice.setCurrentProfile(id, getFeatureFlagMap());
    }

    public CurrentUser setCurrentOrganizationRef(String organizationRefId) {
        OrganizationRef organizationRef =
                this.organizationService.getOrganizationRefById(organizationRefId);
        return this.updateCurrentOrganizationRef(organizationRef);
    }

    private CurrentUser updateCurrentOrganizationRef(OrganizationRef organizationRef) {
        OrgFeatureFlag dto = new OrgFeatureFlag();
        dto.organizationRef = organizationRef;
        dto.featureFlagMap = getFeatureFlagMap();
        return microservice.updateCurrentOrganizationRef(dto);
    }

    public List<UserProfile> getPendingUserProfiles() {
        return microservice.getPendingUserProfiles();
    }

    public List<UserProfile> getApprovedUserProfiles(String userStatus, String managedByOption) {
        UserProfile userProfile = getCurrentUser().profile;
        String currentNodeId = userProfile.currentNodeRef.getId();
        String ancestry = userProfile.currentNodeRef.ancestry;
        return microservice.getApprovedUserProfiles(currentNodeId, ancestry, userStatus, managedByOption);
    }

    public UserProfile addProfile(UserProfile userProfile) {
        updateUserProfileNodeRefs(userProfile);
        UserProfileWrapper wrapper = microservice.addProfile(userProfile);
        notificationService.sendEmails(wrapper.messages);
        return wrapper.profile;
    }

    void updateUserProfileNodeRefs(UserProfile userProfile) {
        userProfile.currentNodeRef = this.organizationService.getOrganizationRefById((userProfile.currentNodeRef.id));
        userProfile.managedByNodeRef = this.organizationService.getOrganizationRefById((userProfile.managedByNodeRef.id));

        List<OrganizationRef> results = new ArrayList<>();
        for (OrganizationRef nodeRef : userProfile.scopeNodeRefs) {
            results.add(this.organizationService.getOrganizationRefById((nodeRef.id)));
        }

        userProfile.scopeNodeRefs = results;
    }

    public UserProfile deleteUserProfile(
            @QueryParam("userProfileId") String userProfileId, @QueryParam("reason") String reason) {
        return microservice.deleteUserProfile(userProfileId, reason);
    }

    public UserProfile renewUserProfile(
            @QueryParam("userProfileId") String userProfileId,
            @QueryParam("newExpirationDate") Date newExpirationDate) {
        return microservice.renewUserProfile(userProfileId, newExpirationDate);
    }

    public CurrentUser getCurrentProfile() {
        return microservice.getCurrentProfile(getFeatureFlagMap());
    }

    public List<UserProfile> getProfilesByEmail(@QueryParam("email") String email) {
        return microservice.getProfilesByEmail(email);
    }

    public UserProfile getUserProfile() {
        return microservice.getUserProfile();
    }

    public UserProfile lockUserProfile(@QueryParam("userProfileId") String userProfileId) {
        return microservice.lockUserProfile(userProfileId);
    }

    public UserProfile unlockUserProfile(@QueryParam("userProfileId") String userProfileId) {
        return microservice.unlockUserProfile(userProfileId);
    }

    public UserProfile updateProfileByAdmin(AdminProfileUpdate profile) {
        return microservice.updateProfileByAdmin(profile);
    }

    public boolean isOwnProfileEditingAllowed() {
        return microservice.isOwnProfileEditingAllowed();
    }

    public UserProfile saveUserPermissions(UserProfile userProfile) {
        return microservice.saveUserPermissions(userProfile);
    }

    public UserProfile saveUserRoles(UserProfile userProfile) {
        boolean isUserRequestFeatureFlagActive = systemFeatureFlagService.checkIfUserRequestFeatureFlagIsActive();
        ProfileFeatureFlag dto = new ProfileFeatureFlag();
        dto.userProfile = userProfile;
        dto.featureFlagMap = getFeatureFlagMap();
        dto.organizationRef = getUserProfile().currentNodeRef;

        if (StringUtil.isEmptyOrNull(userProfile.recentProfileUpdateReason)) {
            throw new ApplicationException(UPDATE_REASON_WARNING);
        }

        UserProfile existing = getUserProfileById(userProfile.getId());
        // TODO: Remove finance dependence, via Consumer Provider?
        roleRemovalValidationProvider.validate(existing.roleRefs, userProfile.roleRefs, userProfile.getId());

        UserProfile persistedProfile = microservice.saveUserRoles(isUserRequestFeatureFlagActive, dto);
        sendBusinessIntelligenceRoleAddedEmail(persistedProfile, existing);

        return persistedProfile;
    }

    public UserProfile saveUserAssignableRoles(UserProfile userProfile) {
        if (StringUtil.isEmptyOrNull(userProfile.recentProfileUpdateReason)) {
            throw new ApplicationException(UPDATE_REASON_WARNING);
        }

        return microservice.saveUserAssignableRoles(userProfile);
    }

    public List<String> getRoleIdsWithAssignableRoles() {
        boolean isUserRequestFeatureFlagActive = systemFeatureFlagService.checkIfUserRequestFeatureFlagIsActive();
        return microservice.getRoleIdsWithAssignableRoles(isUserRequestFeatureFlagActive);
    }

    public void sendBusinessIntelligenceRoleAddedEmail(UserProfile newProfile, UserProfile oldProfile) {
        List<String> newBiRoles = getBusinessIntelligenceRolesForEmail(newProfile);
        List<String> oldBiRoles = getBusinessIntelligenceRolesForEmail(oldProfile);

        if (!ListUtil.isEmpty(newBiRoles) || !ListUtil.isEmpty(oldBiRoles)) {
            String emailToAddress = microservice.getEmailToAddressForBiEmail();
            BusinessIntelligenceRolesEmailWrapper emailWrapper = new BusinessIntelligenceRolesEmailWrapper();
            emailWrapper.userProfile = newProfile;
            emailWrapper.rolesIncludedInEmail = newBiRoles;
            emailWrapper.emailToAddress = emailToAddress;
            EmailMessage message = microservice.buildBusinessIntelligenceRoleAddedEmail(emailWrapper);
            notificationService.sendEmail(message);
        }
    }

    private List<String> getBusinessIntelligenceRolesForEmail(UserProfile userProfile) {
        List<String> roleNames = new ArrayList<>();
        if (userProfile != null) {
            String[] roleIds = ListUtil.listOfStringsToArray(userProfile.roleRefs.stream()
                    .map(roleRef -> roleRef.id)
                    .collect(Collectors.toList()));

            List<Role> roles = roleService.getRoles(roleIds);

            List<Role> biRoles = roles.stream()
                    .filter(role -> role.functionalArea.equals(BUSINESS_INTELLIGENCE_FUNCTIONAL_AREA))
                    .collect(Collectors.toList());

            if (!ListUtil.isEmpty(biRoles)) {
                List<String> excludedRoleIds = microservice.getRoleIdsExcludedFromBiEmail();
                roleNames = biRoles.stream()
                        .filter(role -> !excludedRoleIds.contains(role.getId()))
                        .map(role -> role.name)
                        .collect(Collectors.toList());
            }
        }


        return roleNames;
    }

    public UserProfile suspendUserProfile(
            @QueryParam("userProfileId") String userProfileId,
            @QueryParam("startDate") Date startDate,
            @QueryParam("endDate") Date endDate) {
        return microservice.suspendUserProfile(userProfileId, startDate, endDate);
    }

    public UserProfile updateProfileAccess(UserProfile userProfile) {
        UserProfile profileBeforeUpdate = getUserProfileById(userProfile.getId());

        if (null == profileBeforeUpdate) {
            throw new UserNotFoundException("Profile not found.");
        }

        if (!profileBeforeUpdate.nodeTypeRef.getId().equals(userProfile.nodeTypeRef.getId())) {
            throw new ApplicationException("Cannot change Organization Access Level on an existing profile.");
        }

        if (StringUtil.isEmptyOrNull(userProfile.recentProfileUpdateReason)) {
            throw new ApplicationException(UPDATE_REASON_WARNING);
        }

        updateUserProfileNodeRefs(userProfile);
        return microservice.updateProfileAccess(userProfile);
    }

    public UserProfile updateMyProfileInfo(MyProfileUpdate profile) {
        return microservice.updateMyProfileInfo(profile);
    }

    public List<UserProfile> getUserByPkiDn(@QueryParam("pkiDn") String pkiDn) {
        return microservice.getUserByPkiDn(pkiDn);
    }

    public UserProfile requestPkiDnUpdate(String userEmail) {
        UserProfileWrapper wrapper = microservice.requestPkiDnUpdate(userEmail);
        notificationService.sendEmails(wrapper.messages);
        return wrapper.profile;
    }

    public UserProfile updateUserProfilePKIDN(UserProfile userProfile) {
        return microservice.updateUserProfilePKIDN(userProfile);
    }

    public UserProfile updateUserProfileBusinessIntelligenceId(UserProfile userProfile) {
        return microservice.updateUserProfileBusinessIntelligenceId(userProfile);
    }

    public UserProfile updatePkiDnForUser(String updateId) {
        UserProfileWrapper wrapper = microservice.updatePkiDnForUser(updateId);
        notificationService.sendEmails(wrapper.messages);
        return wrapper.profile;
    }

    public UserProfile cancelPkiDnUpdate(String updateId) {
        UserProfileWrapper wrapper = microservice.cancelPkiDnUpdate(updateId);
        notificationService.sendEmails(wrapper.messages);
        return wrapper.profile;
    }

    public UserProfile getCurrentUserProfileByUpdateId(@QueryParam("updateId") String updateId) {
        return microservice.getCurrentUserProfileByUpdateId(updateId);
    }


    public UserDashboardInfo getUserDashboardStats(String managedBy) {
        UserDashboardInfo info = new UserDashboardInfo();

        info.activeUsers = getProfileCountsPerStatus(managedBy, EUserStatus.ACTIVE.toString());
        info.lockedUsers = getProfileCountsPerStatus(managedBy, EUserStatus.LOCKED.toString());
        info.inactiveUsers = getProfileCountsPerStatus(managedBy, EUserStatus.INACTIVE.toString());
        info.expiredUsers = getProfileCountsPerStatus(managedBy, EUserStatus.EXPIRED.toString());
        info.relockedUsers = getProfileCountsPerStatus(managedBy, EUserStatus.RELOCKED.toString());
        info.pendingUsers = getProfileCountsPerStatus(managedBy, EUserStatus.PENDING.toString());
        info.calculateTotal();

        info.almostExpiringUsers = getAlmostExpiringProfileCount(managedBy);

        return info;
    }

    public long getProfileCountsPerStatus(String managedBy, String userStatus) {
        UserProfile userProfile = getCurrentUser().profile;
        return microservice.getProfileCountPerStatus(userProfile.currentNodeRef, managedBy, userStatus);
    }

    public long getAlmostExpiringProfileCount(String managedBy) {
        UserProfile userProfile = getCurrentUser().profile;
        return microservice.getAlmostExpiringProfileCount(userProfile.currentNodeRef, managedBy);
    }

    public List<UserProfile> getUsersWithRoleRefs(List<String> roleIds) {
        return getUsersWithRoleRefs(roleIds, new ArrayList<>());
    }

    public List<UserProfile> getUsersWithRoleRefs(List<String> roleIds, List<String> excludePKIDns) {
        UserProfile userProfile = getCurrentUser().profile;
        return microservice.getUsersWithRoleRefs(roleIds, userProfile.currentNodeRef, excludePKIDns);
    }

    public List<UserProfile> getUsersAtNodeWithRole(
            @QueryParam("nodeId") String nodeId, @QueryParam("roleId") String roleId) {

        List<UserProfile> profilesWithRole = findActiveProfilesWithRoleRef(roleId);

        List<UserProfile> usersFoundDOs = new ArrayList<>();

        // Traverse the tree to see if user has access to the nodeId provided:
        //    1- Get the nodes the user has access to
        //    2- Check the list for the node ID provided
        //    3- If found, add the user to the list
        //    4- Return the list
        for (UserProfile userProfile : profilesWithRole) {
            List<OrganizationRef> accessToNodeRefs =
                    determineNodeAccess(userProfile.nodeTypeRef.id, userProfile.scopeNodeRefs);

            for (OrganizationRef nodeRef : accessToNodeRefs) {
                if (nodeId.equals(nodeRef.id) && !usersFoundDOs.contains(userProfile)) {
                    usersFoundDOs.add(userProfile);
                }
            }
        }
        return usersFoundDOs;
    }

    private List<OrganizationRef> determineNodeAccess(
            String nodeTypeId, List<OrganizationRef> scopeNodeRefs) {

        AncestryQuery ancestryQuery = new AncestryQuery();
        ancestryQuery.organizationTypeId = nodeTypeId;
        ancestryQuery.scopeOrganizationIds.addAll(
                scopeNodeRefs.stream().map(OrganizationRef::getId).collect(Collectors.toList()));

        List<Organization> accessToNodes = organizationService.getScopeUsingAncestry(ancestryQuery);
        List<OrganizationRef> refs = new ArrayList<>();

        for (Organization node : accessToNodes) {
            refs.add(node.getRef());
        }

        return refs;
    }

    public List<UserProfile> findActiveProfilesWithRoleRef(String roleId, List<String> excludePkidns) {
        return microservice.findActiveProfilesWithRoleRef(roleId, excludePkidns);
    }

    public List<UserProfile> findActiveProfilesWithRoleRef(String roleId) {
        return findActiveProfilesWithRoleRef(roleId, new ArrayList<>());
    }

    UserProfile setUserLoginIpAndDate(String profileId, String ipAddress, Date loginDate) {
        return microservice.setUserLoginIpAndDate(profileId, ipAddress, loginDate);
    }

    CurrentUser getCurrentUserByProfileId(String profileId) {
        return microservice.getCurrentUserByProfileId(profileId, getFeatureFlagMap());
    }

    public void clearCurrentUserFromCache() {
        String token = currentUserBT.getJsonWebToken();
        if (currentUserCache.exists(token)) {
            currentUserCache.remove(token);
        }
    }

    public List<Configuration> getAllConfigurations() {
        return microservice.getAllConfigurations();
    }

    public Configuration addUpdateConfiguration(Configuration configuration) {
        return microservice.addUpdateConfiguration(configuration);
    }

    public Configuration getConfiguration(String id) {
        return microservice.getConfiguration(id);
    }

    public Configuration getConfigurationByName(String name) {
        return microservice.getConfigurationByName(name);
    }

    public List<FunctionalArea> getFunctionalAreasByNames(List<String> names) {
        return microservice.getFunctionalAreasByNames(names);
    }

    public InitializationRoutineResult createBusinessIntelligenceIds(InitializationRoutineRef initializationRoutineRef) {
        return microservice.createBusinessIntelligenceIds();
    }

    @Override
    public void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate) {
        super.processDataReferenceUpdate(dataReferenceUpdate);
        invitationService.processDataReferenceUpdate(dataReferenceUpdate);
        userRequestService.processDataReferenceUpdate(dataReferenceUpdate);
    }

    public List<String> getUserEmailAndPhoneByName(String name) {
        return microservice.getUserEmailAndPhoneByName(name);
    }

    public List<String> getUserExpirationWarningMessage() {
        List<String> messages = new ArrayList<>();
        int warningDays = microservice.getUserExpirationWarningDays();

        UserProfile userProfile = microservice.getUserProfile();
        Date expirationDate = userProfile.profileExpirationDate;
        expirationDate = dateUtil.removeTime(expirationDate);

        Date now = new Date();
        now = dateUtil.removeTime(now);

        int daysLeft = dateUtil.getDaysBetween(now, expirationDate);
        if (daysLeft <= warningDays) {
            String daysText = "days";
            if (daysLeft == 1) {
                daysText = "day";
            }
            messages.add(String.format("This profile will expire in %d %s, please see your Access Manager to renew your authorization if it is necessary to retain the access this profile provides.", daysLeft, daysText));
        }

        return messages;

    }

    private String getUserKeyFromCache(String userId) {
        final AtomicReference<String> jwtToken = new AtomicReference<>();
        currentUserCache.getCacheKeys().forEach(key -> {
            try {
                String actualUserString = currentUserCache.getObject(key);
                CurrentUser currentUser = jsonUtil.deserialize(actualUserString, CurrentUser.class);
                if (Objects.nonNull(currentUser) && Objects.nonNull(currentUser.profile) && currentUser.profile.getId().equalsIgnoreCase(userId)) {
                    jwtToken.set(key);
                }
            } catch (IOException ex) {
                throw new ApplicationException(ex.getMessage());
            }
        });
        return jwtToken.get();
    }

    public AssignableRolesCleanupResponseWrapper cleanupAssignableRoles(boolean isRunBackup) {
        return microservice.cleanupAssignableRoles(isRunBackup);
    }

    public boolean revertAppUserProfileCollection() {
        return microservice.revertAppUserProfileCollection();
    }


    public void updateFMUserOrganizations(boolean makeBackup, boolean siteUsers) {

        if (siteUsers) {
            this.updateFMSiteUsers(makeBackup);
        } else {
            this.updateFMServiceUsers(makeBackup);
            this.updateFMInstallationUsers();
        }

    }

    public List<FMUserOrganizationConversionResponse> getFMUserOrganizationConversions() {
        List<FMUserOrganizationConversionResponse> responses = microservice.getFMUserOrganizationConversions();

        responses.forEach(r -> r.concatenatedMessages = r.messages.stream()
                .collect(Collectors.joining(" ")));

        return responses;
    }

    private void updateFMInstallationUsers() {
        FMUserOrganizationWrapper organizationWrapper = new FMUserOrganizationWrapper();

        // Installation orgs
        organizationWrapper.fmOrganizations = organizationService.getAllOrganizationsByNodeTypeIds(getRPOrgTypeIds());
        organizationWrapper.fmNodeRefs = organizationService.getAllOrganizationsByNodeTypeIds(getRPOrgTypeIds()).stream().map(Organization::getRef).collect(Collectors.toList());
        organizationWrapper.logisticsNodeRefs = organizationService.getAllOrganizationsByNodeTypeIds(this.getLogisticsOrgTypeIds()).stream().map(Organization::getRef).collect(Collectors.toList());
        organizationWrapper.siteType = organizationService.getOrganizationTypeById(OrganizationConstants.SITE_ORG_TYPE_ID);

        organizationWrapper.installations = installationService.getAllInstallations(false);

        microservice.updateFMInstallationUserOrganizations(organizationWrapper);
    }

    private void updateFMServiceUsers(boolean makeBackUp) {
        FMUserOrganizationWrapper organizationWrapper = new FMUserOrganizationWrapper();

        organizationWrapper.fmServiceType = organizationService.getOrganizationTypeById(OrganizationConstants.RP_SERVICE_ORG_TYPE_ID);
        organizationWrapper.serviceType = organizationService.getOrganizationTypeById(OrganizationConstants.SERVICE_ORG_TYPE_ID);
        OrganizationRef navy = organizationService.getOrganizationRefById("58d0581bdf121dce611b7197");
        OrganizationRef army = organizationService.getOrganizationRefById("58d0581bdf121dce611b7186");
        OrganizationRef airForce = organizationService.getOrganizationRefById("58d0581bdf121dce611b7140");
        OrganizationRef marineCorp = organizationService.getOrganizationRefById("58d0581bdf121dce611b7194");


        organizationWrapper.mappedFMOrgIds.put(OrganizationConstants.FM_NAVY, "5c7eefaf85677dc8b9770f5f");
        organizationWrapper.mappedOrgRefs.put(OrganizationConstants.NAVY, navy);
        organizationWrapper.mappedFMOrgIds.put(OrganizationConstants.FM_ARMY, "5c7eef2985677dc8b9770ea0");
        organizationWrapper.mappedOrgRefs.put(OrganizationConstants.ARMY, army);
        organizationWrapper.mappedFMOrgIds.put(OrganizationConstants.FM_AIR_FORCE, "5c7eebe485677dc8b976fd1c");
        organizationWrapper.mappedOrgRefs.put(OrganizationConstants.AIR_FORCE, airForce);
        organizationWrapper.mappedFMOrgIds.put(OrganizationConstants.FM_MARINES, "5c7eef7b85677dc8b9770f2f");
        organizationWrapper.mappedOrgRefs.put(OrganizationConstants.MARINES, marineCorp);
        organizationWrapper.mappedFMOrgIds.put("whs", "5c7ef02e85677dc8b977100f");
        organizationWrapper.mappedFMOrgIds.put("other", "5c828b111a053993c14a3c4c");

        organizationWrapper.fmNodeRefs = organizationService.getAllOrganizationsByNodeTypeIds(getRPOrgTypeIds()).stream().map(Organization::getRef).collect(Collectors.toList());
        organizationWrapper.logisticsNodeRefs = organizationService.getAllOrganizationsByNodeTypeIds(this.getLogisticsOrgTypeIds()).stream().map(Organization::getRef).collect(Collectors.toList());
        organizationWrapper.siteType = organizationService.getOrganizationTypeById(OrganizationConstants.SITE_ORG_TYPE_ID);

        organizationWrapper.fmOrganizations = organizationService.getAllOrganizationsByNodeTypeIds(getRPOrgTypeIds());

        microservice.updateFMServiceUserOrganizations(makeBackUp, organizationWrapper);

    }

    private void updateFMSiteUsers(boolean makeBackUp) {

        FMUserOrganizationWrapper organizationWrapper = new FMUserOrganizationWrapper();

        organizationWrapper.fmNodeRefs = organizationService.getAllOrganizationsByNodeTypeIds(getRPOrgTypeIds()).stream().map(Organization::getRef).collect(Collectors.toList());
        organizationWrapper.logisticsNodeRefs = organizationService.getAllOrganizationsByNodeTypeIds(this.getLogisticsOrgTypeIds()).stream().map(Organization::getRef).collect(Collectors.toList());
        organizationWrapper.siteType = organizationService.getOrganizationTypeById(OrganizationConstants.SITE_ORG_TYPE_ID);

        organizationWrapper.fmOrganizations = organizationService.getAllOrganizationsByNodeTypeIds(getRPOrgTypeIds());

        organizationWrapper.sites = installationService.getAllSites();


        microservice.updateFMSiteUserOrganizations(makeBackUp, organizationWrapper);
    }

    public Boolean clearConversionResults() {
        return microservice.clearConversionResults();
    }

    public Boolean clearUserBackup() {
        return microservice.clearUserBackup();
    }

    private List<String> getRPOrgTypeIds() {
        List<String> rpOrgTypes = new ArrayList<>();
        rpOrgTypes.add(OrganizationConstants.RP_INSTALLATION_SITE_ORG_TYPE_ID);
        rpOrgTypes.add(OrganizationConstants.RP_INSTALLATION_ORG_TYPE_ID);
        rpOrgTypes.add(OrganizationConstants.RP_SERVICE_ORG_TYPE_ID);
        rpOrgTypes.add(OrganizationConstants.RP_FACILITY_ORG_TYPE_ID);
        return rpOrgTypes;
    }

    private List<String> getLogisticsOrgTypeIds() {
        List<String> logisticsOrgTypes = new ArrayList<>();
        logisticsOrgTypes.add(OrganizationConstants.CUSTOMER_ORG_TYPE_ID);
        logisticsOrgTypes.add(OrganizationConstants.SITE_ORG_TYPE_ID);
        logisticsOrgTypes.add(OrganizationConstants.SERVICE_ORG_TYPE_ID);
        logisticsOrgTypes.add(OrganizationConstants.AGENCY_ORG_TYPE_ID);
        logisticsOrgTypes.add(OrganizationConstants.LOGISTICS_ORG_TYPE_ID);
        logisticsOrgTypes.add("58efd65744c0a5e103d6f3a4"); // REGION
        logisticsOrgTypes.add("58efd84a44c0a5e103d6f55a"); // ORGANIZATION


        return logisticsOrgTypes;
    }

    public ScopeQuery getScopeQueryForUser(UserProfile userProfile, String nodeTypeId) {
        ScopeQuery scopeQuery = new ScopeQuery();

        scopeQuery.userProfile = userProfile;

        if (StringUtil.isEmptyOrNull(nodeTypeId)) {
            scopeQuery.nodeTypeId = userProfile.nodeTypeRef.id;
            scopeQuery.nodeTypeName = userProfile.nodeTypeRef.name;
        } else {
            scopeQuery.nodeTypeId = nodeTypeId;
        }

        if (userProfile.scopeNodeRefs.isEmpty()) {
            scopeQuery.scopeList = new ArrayList<>();
        } else {
            scopeQuery.scopeList = userProfile.scopeNodeRefs.stream().map(OrganizationRef::getId).collect(Collectors.toList());
        }

        if (userProfile.roleRefs.isEmpty()) {
            scopeQuery.userProfileRoleRefs = new ArrayList<>();
        } else {
            scopeQuery.userProfileRoleRefs = userProfile.roleRefs;
        }

        if (Boolean.FALSE.equals(userProfile.isAllAssignableRoles) && !userProfile.assignableRoleRefs.isEmpty()) {
            scopeQuery.userProfileAssignableRoleRefs = userProfile.assignableRoleRefs;
        }

        return scopeQuery;
    }
}
