package logicole.gateway.services.system;

import logicole.apis.system.IKafkaMicroserviceApi;
import logicole.apis.system.ISystemNotificationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;


@ApplicationScoped
public class KafkaMicroserviceClient extends MicroserviceClient<IKafkaMicroserviceApi> {
    public KafkaMicroserviceClient() {
        super(IKafkaMicroserviceApi.class, "logicole-system");
    }

    @Produces
    public IKafkaMicroserviceApi getMicroserviceApi() {
        return createClient();
    }
}
