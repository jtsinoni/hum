package logicole.gateway.services.assemblage;

import io.swagger.annotations.Api;
import logicole.common.datamodels.assemblage.*;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import java.util.List;

@Api(tags = {"Allowance"})
@ApplicationScoped
@Path("/allowance")
public class AllowanceRestApi extends ExternalRestApi<AllowanceService> {

    @POST
    @Path("/getAssemblagesWithItem")
    public SearchResult<AssemblageItem> getAssemblagesWithItem(SearchInput searchInput) {
        return service.getAssemblagesWithItem(searchInput);
    }

    @POST
    @Path("/getAssemblagesWithoutItem")
    public SearchResult<AssemblageItem> getAssemblagesWithoutItem(SearchInput searchInput) {
        return service.getAssemblagesWithoutItem(searchInput);
    }

    @POST
    @Path("/updateAssemblageItems")
    public void updateAssemblageItems(List<AssemblageItem> assemblageItemsToUpdate) {
        service.updateAssemblageItems(assemblageItemsToUpdate);
    }

    @POST
    @Path("/addAssemblageItems")
    public List<AssemblageItem> addAssemblageItems(List<AssemblageItem> assemblageItemsToAdd) {
        return service.addAssemblageItems(assemblageItemsToAdd);
    }
}
