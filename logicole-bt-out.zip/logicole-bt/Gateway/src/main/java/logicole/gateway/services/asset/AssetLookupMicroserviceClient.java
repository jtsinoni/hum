package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetLookupMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AssetLookupMicroserviceClient extends MicroserviceClient<IAssetLookupMicroserviceApi> {
    public AssetLookupMicroserviceClient() {
        super(IAssetLookupMicroserviceApi.class, "logicole-asset");
    }

    @Produces
    public IAssetLookupMicroserviceApi getIAssetLookupMicroserviceApi() {
        return createClient();
    }
}
