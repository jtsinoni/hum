package logicole.gateway.common.workflow;

import logicole.common.datamodels.workflow.WorkflowAction;

public interface IWorkflowVisibilityRule<T> {
    boolean isVisible(WorkflowAction workflowAction, T workflowItem);
    boolean isActionAllowedConsecutively();
}
