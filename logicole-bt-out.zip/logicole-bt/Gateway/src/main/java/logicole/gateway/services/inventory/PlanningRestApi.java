package logicole.gateway.services.inventory;


import io.swagger.annotations.Api;
import logicole.common.datamodels.inventory.InventoryDemand;
import logicole.common.datamodels.inventory.InventoryPipeline;
import logicole.common.datamodels.inventory.InventoryRecord;
import logicole.common.datamodels.inventory.InventoryPlanning;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.Date;
import java.util.List;

@Api(tags = {"Planning"})
@ApplicationScoped
@Path("/planning")
public class PlanningRestApi extends ExternalRestApi<PlanningService> {

    @GET
    @Path("/getRecommendedLevelChanges")
    public List<InventoryPlanning> getRecommendedLevelChanges(@QueryParam("inventorySystemRefId") String inventorySystemRefId) {
        return service.getRecommendedLevelChanges(inventorySystemRefId);
    }

    @POST
    @Path("/acceptLevelChange")
    public InventoryPlanning acceptLevelChange(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                               @QueryParam("locationId") String locationId) {
        return service.acceptLevelChange(inventoryRecordId, locationId);
    }

    @POST
    @Path("/rejectLevelChange")
    public InventoryPlanning rejectLevelChange(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                               @QueryParam("locationId") String locationId) {
        return service.rejectLevelChange(inventoryRecordId, locationId);
    }

    @POST
    @Path("/updateDemand")
    public InventoryPlanning updateDemand(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                        @QueryParam("itemLocationIdentifier") String itemLocationIdentifier,
                                        @QueryParam("demandDate") Date demandDate,
                                        @QueryParam("demandQuantity") Integer demandQuantity) {
        return service.updateDemand(inventoryRecordId,itemLocationIdentifier, demandDate, demandQuantity);
    }

    @POST
    @Path("/updateLeadTime")
    public InventoryPlanning updateLeadTime(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                          @QueryParam("itemLocationId") String itemLocationId,
                                          @QueryParam("dueinDate") Date dueinDate) {
        return service.updateLeadTime(inventoryRecordId, itemLocationId, dueinDate);
    }

    @GET
    @Path("/computeAverageLeadTime")
    public double computeAverageLeadTime(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                         @QueryParam("locationId") String locationId) {
        return service.computeAverageLeadTime(inventoryRecordId, locationId);
    }

    @POST
    @Path("/computeDailyDemandRate")
    public double computeDailyDemandRate(InventoryPlanning planning) {
        return service.computeDailyDemandRate(planning);
    }

    @GET
    @Path("/calculateLevelQuantity")
    public long calculateLevelQuantity(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                       @QueryParam("locationId") String locationId,
                                       @QueryParam("calculateForLog") boolean calculateForLog) {
        return service.calculateLevelQuantity(inventoryRecordId, locationId, calculateForLog);
    }

    @GET
    @Path("/calculateReorderQuantity")
    public long calculateReorderQuantity(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                         @QueryParam("locationId") String locationId,
                                         @QueryParam("calculateForLog") boolean calculateForLog) {
        return service.calculateReorderQuantity(inventoryRecordId, locationId, calculateForLog);
    }

    @POST
    @Path("/updateRecommendedLevel")
    public InventoryPlanning updateRecommendedLevel(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                                    @QueryParam("locationId") String locationId) {
        return service.updateRecommendedLevel(inventoryRecordId, locationId);
    }

    @GET
    @Path("/getInventoryPlanningByRecordId")
    public List<InventoryPlanning> getInventoryPlanningByRecordId(@QueryParam("inventoryRecordId") String inventoryRecordId) {
        return service.getInventoryPlanningByRecordId(inventoryRecordId);
    }

    @GET
    @Path("/getInventoryPlanningByRecordIdAndItemLocId")
    public InventoryPlanning getInventoryPlanningByRecordIdAndItemLocId(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                                                        @QueryParam("itemLocationIdentifier") String itemLocationIdentifier) {
        return service.getInventoryPlanningByRecordIdAndItemLocId(inventoryRecordId, itemLocationIdentifier);
    }

    @GET
    @Path("/getInventoryPlanningByInventorySystemRefId")
    public List<InventoryPlanning> getInventoryPlanningByInventorySystemRefId(@QueryParam("inventorySystemId") String inventorySystemId) {
        return service.getInventoryPlanningByInventorySystemRefId(inventorySystemId);
    }

    @POST
    @Path("/updatePlanningRecord")
    public InventoryPlanning updatePlanningRecord(InventoryPlanning planningRecordToUpdate) {
        return service.updatePlanningRecord(planningRecordToUpdate);
    }

    @POST
    @Path("/deletePlanningRecord")
    public boolean deletePlanningRecord(@QueryParam("inventoryPlanningId") String id) {
        return service.deletePlanningRecord(id);
    }

    @GET
    @Path("/getInventoryPlanningById")
    public InventoryPlanning getInventoryPlanningById(@QueryParam("inventoryPlanningId") String inventoryPlanningId) {
        return service.getInventoryPlanningById(inventoryPlanningId);
    }

    @POST
    @Path("/saveDemandPlanningInfo")
    public InventoryPlanning saveDemandPlanningInfo(@QueryParam("planningId") String planningId, InventoryDemand updatedDemand) {
        return service.saveDemandPlanningInfo(planningId, updatedDemand);
    }

    @POST
    @Path("/savePipelineInfo")
    public InventoryPlanning savePipelineInfo(InventoryPlanning planningRecordToUpdate) {
        return service.savePipelineInfo(planningRecordToUpdate);
    }

    @POST
    @Path("/addPipelineInfo")
    public InventoryPlanning addPipelineInfo(@QueryParam("inventoryPlanningId") String planningId,
                                             InventoryPipeline pipelineInfo) {
        return service.addPipelineInfo(planningId, pipelineInfo);
    }

    @POST
    @Path("/createOrUpdatePlanningRecord")
    public InventoryPlanning createOrUpdatePlanningRecord(@QueryParam("inventoryRecordId") String recordId,
                                                          @QueryParam("itemLocationIdentifier") String newItemLocationIdentifier,
                                                          InventoryPlanning planningRecord) {
        return service.createOrUpdatePlanningRecord(recordId, newItemLocationIdentifier, planningRecord);
    }
    @POST
    @Path("/hasReorderOrLevel")
    public boolean hasReorderOrLevel(@QueryParam("locationId") String locationId,
                                     List<InventoryRecord> inventoryRecords) {
        return service.hasReorderOrLevel(locationId, inventoryRecords);
    }



}
