package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.ABiConfigurationSettings;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import java.util.List;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi/configurationManager")
public class AbiConfigurationRestApi extends ExternalRestApi<AbiConfigurationService> {

    @GET
    @Path("/getABiConfigurationSettings")
    public ABiConfigurationSettings getABiConfigurationSettings() {
        return service.getABiConfigurationSettings();
    }

    @POST
    @Path("/updateABiConfigurationSettings")
    public Boolean updateABiConfigurationSettings(ABiConfigurationSettings settings) {
        return service.updateABiConfigurationSettings(settings);
    }

    @GET
    @Path("/getDocumentTypes")
    public List<String> getDocumentTypes() {
        return service.getDocumentTypes();
    }
}
