package logicole.gateway.services.system;

import logicole.apis.system.ICustomizableTypeMicroserviceApi;
import logicole.common.datamodels.general.customizabletype.CustomizableType;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class CustomizableTypeService extends BaseGatewayService<ICustomizableTypeMicroserviceApi> {

    public CustomizableTypeService() {
        super("CustomizableType");
    }

    public List<CustomizableType> getCustomizableTypes() {
        return microservice.getCustomizableTypes();
    }

}
