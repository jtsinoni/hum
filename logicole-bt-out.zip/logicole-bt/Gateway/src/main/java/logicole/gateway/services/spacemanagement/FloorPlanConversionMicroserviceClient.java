package logicole.gateway.services.spacemanagement;

import logicole.apis.space.IFloorPlanConversionMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;



@ApplicationScoped
public class FloorPlanConversionMicroserviceClient extends MicroserviceClient<IFloorPlanConversionMicroserviceApi> {
    public FloorPlanConversionMicroserviceClient(){
        super(IFloorPlanConversionMicroserviceApi.class, "logicole-space-management");
    }

    @Produces
    public IFloorPlanConversionMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
