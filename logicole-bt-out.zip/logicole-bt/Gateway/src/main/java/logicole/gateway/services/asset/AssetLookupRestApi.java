package logicole.gateway.services.asset;

import io.swagger.annotations.Api;
import logicole.common.datamodels.asset.lookup.AuthoritativeSpaceEquipmentCriteria;
import logicole.common.datamodels.asset.lookup.MilitaryStandard1691;
import logicole.common.datamodels.asset.lookup.MilitaryStandard1691Summary;
import logicole.common.datamodels.asset.lookup.SpaceEquipmentCriteria;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"AssetLookup"})
@ApplicationScoped
@Path("/assetLookup")
public class AssetLookupRestApi extends ExternalRestApi<AssetLookupService> {

    @GET
    @Path("/getAllAuthoritativeSpaceEquipmentCriteria")
    public List<AuthoritativeSpaceEquipmentCriteria> getAllAuthoritativeSpaceEquipmentCriteria(){
        return service.getAllAuthoritativeSpaceEquipmentCriteria();
    }

    @GET
    @Path("/getAllSpaceEquipmentCriteria")
    public List<SpaceEquipmentCriteria> getAllSpaceEquipmentCriteria() {
        return service.getAllSpaceEquipmentCriteria();
    }

    @GET
    @Path("/getSpaceEquipmentRooms")
    public List<SpaceEquipmentCriteria> getSpaceEquipmentRooms() {
        return service.getSpaceEquipmentRooms();
    }

    @POST
    @Path("/addSpaceEquipmentCriteria")
    public SpaceEquipmentCriteria addSpaceEquipmentCriteria(SpaceEquipmentCriteria sec) {
        return service.addSpaceEquipmentCriteria(sec);
    }

    @POST
    @Path("/updateSpaceEquipmentCriteria")
    public SpaceEquipmentCriteria updateSpaceEquipmentCriteria(SpaceEquipmentCriteria sec) {
        return service.updateSpaceEquipmentCriteria(sec);
    }

    @POST
    @Path("/deleteSpaceEquipmentCriteria")
    public void deleteSpaceEquipmentCriteria(String secId) {
        service.deleteSpaceEquipmentCriteria(secId);
    }

    @GET
    @Path("/getAllMilitaryStandard1691")
    public List<MilitaryStandard1691Summary> getAllMilitaryStandard1691() {
        return service.getAllMilitaryStandard1691();
    }

    @GET
    @Path("/getMilitaryStandard1691ById")
    public MilitaryStandard1691 getMilitaryStandard1691ById(@NotNull @QueryParam("id") String id) {
        return service.getMilitaryStandard1691ById(id);
    }

    @GET
    @Path("/getMilitaryStandard1691ByJsn")
    public MilitaryStandard1691 getMilitaryStandard1691ByJsn(@NotNull @QueryParam("jsn") String jsn) {
        return service.getMilitaryStandard1691ByJsn(jsn);
    }
}
