package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiStagingMicroserviceApi;
import logicole.common.datamodels.abi.*;
import logicole.common.datamodels.abi.staging.ABiCatalogRecordUpdate;
import logicole.common.datamodels.abi.staging.ABiCatalogStagingItemResearchRecordSummary;
import logicole.common.datamodels.abi.staging.ABiManagerBuilder;
import logicole.common.datamodels.abi.staging.ABiManagerItemResearchUploadFileBuilder;
import logicole.common.datamodels.abi.staging.ABiManagerUploadFileBuilder;
import logicole.common.datamodels.abi.staging.AbiCatalogRecord;
import logicole.common.datamodels.abi.staging.AbiCatalogStaging;
import logicole.common.datamodels.abi.staging.AbiCatalogStatistics;
import logicole.common.datamodels.abi.staging.AbiDownloadFile;
import logicole.common.datamodels.abi.staging.ApprovalRequestResult;
import logicole.common.datamodels.abi.staging.ApprovalResult;
import logicole.common.datamodels.abi.staging.EAbiFileType;
import logicole.common.datamodels.abi.staging.ESearchAndReplaceType;
import logicole.common.datamodels.abi.staging.FieldValidationStatus;
import logicole.common.datamodels.abi.staging.MoveRecordsResponse;
import logicole.common.datamodels.abi.staging.RecordStatusType;
import logicole.common.datamodels.abi.staging.StagingRequest;
import logicole.common.datamodels.abi.staging.StagingRequestQueueRecord;
import logicole.common.datamodels.abi.staging.StagingRequestResponse;
import logicole.common.datamodels.abi.staging.StagingRequestWrapper;
import logicole.common.datamodels.abi.types.StagingRequestStatusType;
import logicole.common.datamodels.abi.types.StagingRequestType;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.filemanager.FileRef;
import logicole.common.datamodels.product.AbiProductUpdate;
import logicole.common.datamodels.product.SiteCatalogRecord;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.util.DateUtil;
import logicole.common.general.util.EDateTimeFormat;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.abi.referencedata.BusinessService;
import logicole.gateway.services.abi.stagingrequest.ABiStagingRequestUtil;
import logicole.gateway.services.abi.stagingrequest.ILogAccumulatorCallback;
import logicole.gateway.services.abi.stagingrequest.LogAccumulator;
import logicole.gateway.services.abi.stagingrequest.PackagingWorksheetUploadUpdateProcessor;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.product.OfferService;
import logicole.gateway.services.product.ProductService;
import org.apache.commons.lang3.StringUtils;
import org.jboss.resteasy.specimpl.ResponseBuilderImpl;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

@ApplicationScoped
public class AbiStagingService extends BaseGatewayService<IAbiStagingMicroserviceApi> {

    private static final String NEWLINE = System.getProperty("line.separator");
    public static final String BUILD_GHX_ITEM_MASTER_SPREADSHEET = "BUILD_GHX_ITEM_MASTER_SPREADSHEET";
    public static final String BUILD_SITE_CATALOG_NO_ABI_RECORD_WORKSHEET = "BUILD_SITE_CATALOG_NO_ABI_RECORD_WORKSHEET";

    @Inject
    private DateUtil dateUtil;

    @Inject
    private StringUtil stringUtil;

    @Inject
    private ABiStagingRequestUtil aBiStagingRequestUtil;

    @Inject
    private LogAccumulator logAccumulator;

    @Inject
    private PackagingWorksheetUploadUpdateProcessor packagingWorksheetUploadUpdateProcessor;

    @Inject
    private JSONUtil jsonUtil;

    @Inject
    AbiConfigurationService configurationService;

    @Inject
    AbiCatalogService abiCatalogService;

    @Inject
    AbiStagingMoveRecordsService abiStagingMoveRecordsService;

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    ItemService itemService;

    @Inject
    OfferService offerService;

    @Inject
    ProductService productService;

    @Inject
    SiteCatalogRequestService siteCatalogRequestService;

    @Inject
    BusinessService businessService;

    @Inject
    AbiToSiteRecordLinkService abiToSiteRecordLinkService;

    public AbiStagingService() {
        super("AbiStaging");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public AbiCatalogStatistics getStatistics() {
        return microservice.getStatistics();
    }

    public List<AbiCatalogStaging> searchRecords(
            @QueryParam("mode") String mode, @QueryParam("matchOption") String matchOption, @QueryParam("filterData") String filterData) throws ApplicationException {
        mode = mode.toUpperCase();
        if (!isModeValid(mode)) {
            throw new ApplicationException("Invalid search mode specified.");
        }
        matchOption = matchOption.toUpperCase();
        if (!isMatchOptionValid(matchOption)) {
            throw new ApplicationException("Invalid matchOption specified.");
        }

        return microservice.searchRecords(mode, matchOption, filterData);
    }

    public FieldValidationStatus validateRecord(AbiCatalogStaging record) {
        return microservice.validateRecord(record);
    }

    public ApprovalRequestResult requestApprovalForRecord(AbiCatalogStaging recordRequestingApproval) {
        //Validate record requesting approval
        ApprovalRequestResult approvalRequestResult = microservice.requestApprovalForRecord(recordRequestingApproval);

        if (approvalRequestResult.approvalCanBeRequested) {
            // Save any changes first
            AbiCatalogStaging recordToUpdate = approvalRequestResult.recordRequestingApproval;

            recordToUpdate = updateRecord(recordToUpdate);

            // Change the Status
            changeRecordStatus(recordToUpdate, RecordStatusType.PENDING_APPROVAL);
            AbiCatalogStaging updatedRecord = updateRecord(recordToUpdate);

            approvalRequestResult.recordRequestingApproval = updatedRecord;
        }
        return approvalRequestResult;
    }

    public ApprovalResult approveRecord(AbiCatalogStaging recordToApprove) {
        ApprovalResult approvalResult = microservice.approveRecord(recordToApprove);
        if (approvalResult.isApproved) {

            AbiCatalogStaging recordToUpdate = approvalResult.approvedRecord;
            // Save any changes first
            recordToUpdate = updateRecord(recordToUpdate);

            // Change the Status
            changeRecordStatus(recordToUpdate, RecordStatusType.APPROVED);
            AbiCatalogStaging updatedRecord = updateRecord(recordToUpdate);

            approvalResult.approvedRecord = updatedRecord;
        }
        return approvalResult;
    }

    public AbiCatalogStaging updateRecord(AbiCatalogStaging recordToUpdate) {
        ABiManagerBuilder aBiManagerBuilder = new ABiManagerBuilder();

        AbiCatalogStaging existingRecord = null;
        if (recordToUpdate.getId() != null) {
            existingRecord = microservice.findRecordById(recordToUpdate.getId());
        }
        recordToUpdate.updatedDate = new Date();

        if (existingRecord == null) {
            prependApprovalNote(recordToUpdate, "Record created.");
            existingRecord = microservice.createNewRecord(recordToUpdate);
        } else {
            String currentEnterpriseProductIdentifier = existingRecord.enterpriseProductIdentifier;
            String updatedEnterpriseProductIdentifier = recordToUpdate.enterpriseProductIdentifier;
            List<Integer> currentProdSeqIdList = existingRecord.mmcProductIdentifiers;
            List<Integer> updatedProdSeqIdList = recordToUpdate.mmcProductIdentifiers;

            List<String> fieldsToIgnore = Arrays.asList("logger", "_id");
            processEnterpriseProductIdChanges(recordToUpdate, existingRecord);
            aBiManagerBuilder.existingRecord = existingRecord;
            aBiManagerBuilder.recordToUpdate = recordToUpdate;
            existingRecord = microservice.updateRecord(fieldsToIgnore, aBiManagerBuilder);

            logger.info("AbiStagingService: updateRecord");
            if (!currentEnterpriseProductIdentifier.equals(updatedEnterpriseProductIdentifier)) {

                logger.info("AbiStagingService: currentEnterpriseProductIdentifier " + currentEnterpriseProductIdentifier + " updatedEnterpriseProductIdentifier :" + updatedEnterpriseProductIdentifier);
                productService.updateSiteCatalogRecordFromABi(currentEnterpriseProductIdentifier, 
                                                              updatedEnterpriseProductIdentifier);

            }
        }

        return existingRecord;
    }

    public AbiCatalogStaging findRecordById(String recordId) {
        return microservice.findRecordById(recordId);
    }

    protected void processEnterpriseProductIdChanges(AbiCatalogStaging updatedRecord, AbiCatalogStaging existingRecord) {
        String existingEntProdId = existingRecord.enterpriseProductIdentifier;
        String updatedEntProdId = updatedRecord.enterpriseProductIdentifier;

        if ((existingEntProdId != null) && (updatedEntProdId != null)) {
            if (existingEntProdId.compareTo(updatedEntProdId) != 0) {/**/
                this.updateSecondaryProductIdentifiers(updatedRecord, existingEntProdId);
                productService.updateEnterpriseProductIdentifier(existingEntProdId, updatedEntProdId);
            }
        }
    }

    protected void updateSecondaryProductIdentifiers(AbiCatalogStaging updatedRecord, String existingEntProdId) {
        List<ProductIdentifier> secondaryProductIdentifiers = updatedRecord.secondaryProductIdentifiers;
        boolean foundEntProdId = false;
        for (ProductIdentifier prodIdent : secondaryProductIdentifiers) {
            if (prodIdent.identifier.compareTo(existingEntProdId) == 0) {
                foundEntProdId = true;
                break;
            }
        }
        if (!foundEntProdId) {
            ProductIdentifier newProdIdent = new ProductIdentifier();
            newProdIdent.identifier = existingEntProdId;
            newProdIdent.identifierType = "Prior EnterpriseProductIdentifier";
            secondaryProductIdentifiers.add(newProdIdent);
        }
    }

    public void changeRecordStatus(AbiCatalogStaging recordToUpdate, String recordStatusType) {
        recordToUpdate.recordStatus = recordStatusType;
        String statusNote = "";
        switch (recordStatusType) {
            case RecordStatusType.PENDING_APPROVAL:
                recordToUpdate.approvedBy = null;
                recordToUpdate.publishedDate = null;
                statusNote = "Requesting Approval.";
                break;
            case RecordStatusType.APPROVED:
                recordToUpdate.approvedBy = getCurrentUser().profile.getFullName();
                statusNote = "Approving Record.";
                break;
            case RecordStatusType.MERGED:
                statusNote = "Finalizing Merged Record";
                break;
            case RecordStatusType.PUBLISHED:
                recordToUpdate.publishedDate = new Date();
                statusNote = "Publishing Record.";
                break;
            case RecordStatusType.INCOMPLETE:
                recordToUpdate.approvedBy = null;
                recordToUpdate.publishedDate = null;
                statusNote = "Marked Incomplete.";
                break;
            case RecordStatusType.UNVERIFIED:
                statusNote = "Marked Unverified.";
                break;
            case RecordStatusType.VERIFIED:
                statusNote = "Marked Verified.";
                break;
            default:
                break;
        }
        prependApprovalNote(recordToUpdate, statusNote);
    }

    public AbiCatalogStaging updateStagingRecord(AbiCatalogStaging updatedRecord) throws ValidationException {
        FieldValidationStatus status = validateRecord(updatedRecord);

        if (!status.recordHasValidationErrors) {
            //handle update business
            Business business = businessService.checkManufacturerName(updatedRecord.manufacturer);
            if (business != null){
                updatedRecord.businessRef = business.getRef();
                updatedRecord.manufacturer = business.businessName;
            }

            AbiCatalogStaging existingRecord = null;
            if (updatedRecord.getId() != null) {
                existingRecord = microservice.findRecordById(updatedRecord.getId());
            }
            AbiCatalogStaging abiCatalogStaging = updateRecord(updatedRecord);
            // Need to update Offer when Abistaging record modified.
            if (existingRecord != null) {
                ABiCatalogRecordUpdate aBiCatalogRecordUpdate = new ABiCatalogRecordUpdate();
                String currentEnterpriseProductIdentifier = existingRecord.enterpriseProductIdentifier;
                String updatedEnterpriseProductIdentifier = updatedRecord.enterpriseProductIdentifier;
                if (!currentEnterpriseProductIdentifier.equals(updatedEnterpriseProductIdentifier)) {
                    Set<String> epiSet = new HashSet<>();
                    epiSet.add(currentEnterpriseProductIdentifier);
                    aBiCatalogRecordUpdate.epiSet = epiSet;
                    aBiCatalogRecordUpdate.syncProduct = true;
                    // EPI change only update AbiCatalog Record here.
                    abiCatalogService.updateAbiCatalogEnterpriseProductIdentifier(currentEnterpriseProductIdentifier, updatedEnterpriseProductIdentifier);
                }
                AbiCatalogRecord abiCatalogRecord = abiCatalogService.getAbiCatalogOrStagingRecordByEnterpriseProductIdentifier(updatedEnterpriseProductIdentifier);
                aBiCatalogRecordUpdate.abiCatalogRecord = abiCatalogRecord;
                List<ABiCatalogRecordUpdate> aBiCatalogRecordUpdateList = new ArrayList<>();
                aBiCatalogRecordUpdateList.add(aBiCatalogRecordUpdate);
                abiStagingMoveRecordsService.publishAbiCatalogChange(aBiCatalogRecordUpdateList);
            }

            return abiCatalogStaging;
        } else {
            throw new ValidationException("Record cannot be updated until the following validation errors are fixed:" +
                    System.lineSeparator() +
                    String.join(System.lineSeparator(), status.messageList));
        }
    }

    private void prependApprovalNote(AbiCatalogStaging recordToUpdate, String statusNote) {
        String newApprovalNote = getFormattedNote(statusNote, recordToUpdate.approvalNote);
        recordToUpdate.approvalNote = newApprovalNote;
    }

    protected String getFormattedNote(String note, String previousNote) {
        String dateString = getDateString();
        String lineToPrepend = "[" + dateString + "] " + note + "(" + getCurrentUser().profile.getFullName() + ")";
        if (previousNote == null) {
            previousNote = "";
        }
        return lineToPrepend + NEWLINE + previousNote;
    }

    protected String getDateString() {
        return EDateTimeFormat.YYYYMMMDDHHMMSS_FORMAT.format(dateUtil.getCurrentUTCDate());
    }

    private boolean isMatchOptionValid(String matchOption) {
        boolean isValid;
        matchOption = StringUtil.safeToUppercase(matchOption);
        switch (matchOption) {
            case "CONTAINS":
            case "BEGINS_WITH":
            case "ENDS_WITH":
                isValid = true;
                break;
            default:
                isValid = false;
        }
        return isValid;
    }


    private boolean isModeValid(String mode) {
        boolean isValid;
        mode = StringUtil.safeToUppercase(mode);
        switch (mode) {
            case "IN_USE":
            case "MERGED":
            case "PENDING_APPROVAL":
            case "APPROVED":
            case "PUBLISHED":
            case "ALL":
            case "INCOMPLETE":
            case "MERGING":
            case "INCOMPLETE_IN_USE":
                isValid = true;
                break;
            default:
                isValid = false;
        }
        return isValid;
    }

    public AbiCatalogStaging markRecordIncomplete(@QueryParam("id") String id) {
        AbiCatalogStaging record = findRecordById(id);
        changeRecordStatus(record, RecordStatusType.INCOMPLETE);
        return updateRecord(record);
    }

    public Integer deleteRecord(AbiCatalogStaging recordToDelete) {
        return microservice.deleteRecord(recordToDelete);
    }

    public List<StagingRequestQueueRecord> getStagingRequests(Boolean showSubtasks) {
        return microservice.getStagingRequests(showSubtasks);
    }

    public List<AbiDownloadFile> getDownloadFiles() {
        return microservice.getDownloadFiles();
    }

    public Response downloadABiFile(@QueryParam("id") String id) throws IOException, ApplicationException {

        AbiDownloadFile file = microservice.getDownloadFileInfo(id);
        byte[] bytes = getDownloadFileData(file);

        Response.ResponseBuilder responseBuilder = new ResponseBuilderImpl();

        if (file.fileType != EAbiFileType.Unknown) {
            responseBuilder
                    .header("Content-Disposition", "attachment; filename=" + file.filename)
                    .header("Content-Length", bytes.length)
                    .header("Content-Encoding", StandardCharsets.UTF_8)
                    .header("Access-Control-Expose-Headers", "Content-Disposition,Content-Type");

            responseBuilder.entity(bytes);
            responseBuilder = responseBuilder.status(Response.Status.OK);
        } else {
            responseBuilder = responseBuilder.status(Response.Status.NOT_FOUND);
        }

        return responseBuilder.build();
    }

    public byte[] getDownloadFileData(AbiDownloadFile file) throws IOException, ApplicationException {
        Byte[] contents = fileManagerAdminService.getFileContents(file.fileManagerId);
        byte[] bytes = new byte[contents.length];
        int i = 0;
        for (Byte b : contents) {
            bytes[i++] = b;
        }
        return bytes;
    }

    public StagingRequestResponse generateGHXItemMasterSpreadsheet() {
        return microservice.generateGHXItemMasterSpreadsheet();
    }

    public Integer getMaxUploadSize() throws ApplicationException {
        return fileManagerAdminService.getMaxPostSize();
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName)
            throws ApplicationException {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }

    public StagingRequestResponse generateStagingEditingSpreadsheet(@QueryParam("mode") String mode,
                                                                    @QueryParam("matchOption") String matchOption,
                                                                    @QueryParam("filterData") String filterData) {
        return microservice.generateStagingEditingSpreadsheet(mode, matchOption, filterData);
    }


    public ABiManagerUploadFileBuilder processAllStagingRequest(StagingRequest request) throws ApplicationException, IOException {
        ABiManagerUploadFileBuilder aBiManagerUploadFileBuilder = new ABiManagerUploadFileBuilder();
        if (request.requestType.equals(StagingRequestType.PROCESS_PRODUCT_SYNC)) {
            String aBiCatalogRecordUpdates = request.argumentList.get(0);
            AbiProductUpdate abiProductUpdateList = jsonUtil.deserialize(aBiCatalogRecordUpdates, AbiProductUpdate.class);

            logger.info("AbiStagingService: processAllStagingRequest PROCESS_PRODUCT_SYNC Size" + abiProductUpdateList.aBiCatalogRecordUpdateList.size() + "  " + request.requestId );
            for(ABiCatalogRecordUpdate aBiCatalogRecordUpdate: abiProductUpdateList.aBiCatalogRecordUpdateList){
                logger.info("AbiStagingService: ProcessMoveRecordToProduct" + "  " + request.requestId );
                if (aBiCatalogRecordUpdate.syncProduct != null && aBiCatalogRecordUpdate.syncProduct == true) {
                    //TODO Need to remove Product.
                    logger.info("AbiStagingMoveRecordsService: SyncProductFromAbi  " + aBiCatalogRecordUpdate.syncProduct);
                    productService.syncProductFromAbi(aBiCatalogRecordUpdate);
                    itemService.syncItemWithAbiCatalog(aBiCatalogRecordUpdate);
                }
            }

        }else {
             aBiManagerUploadFileBuilder = processStagingRequest(request);
        }
        return aBiManagerUploadFileBuilder;
    }


    public ABiManagerUploadFileBuilder processStagingRequest(StagingRequest request) throws ApplicationException, IOException {
        ABiManagerUploadFileBuilder aBiManagerUploadFileBuilder = new ABiManagerUploadFileBuilder();

        if (request.requestType.equals(StagingRequestType.BUILD_GHX_ITEM_MASTER_SPREADSHEET)) {
            aBiManagerUploadFileBuilder.productSeqIdInfoList = productService.getMedicalSupplyProductSeqIdInfo();
        }

        aBiManagerUploadFileBuilder.stagingRequest = request;
        aBiManagerUploadFileBuilder = processStagingRequest(aBiManagerUploadFileBuilder);
        if (aBiManagerUploadFileBuilder != null) {
            uploadGeneratedFile(aBiManagerUploadFileBuilder);
        }

        //Create exception file
        if ((null != aBiManagerUploadFileBuilder) && (null != aBiManagerUploadFileBuilder.exceptionFilename)) {
            aBiManagerUploadFileBuilder.fileName = aBiManagerUploadFileBuilder.exceptionFilename;

            if (request.requestType.equals(StagingRequestType.BUILD_SITE_CATALOG_NO_ABI_RECORD_WORKSHEET)) {
                aBiManagerUploadFileBuilder.abiFileType = EAbiFileType.SiteCatalogNoABiRecordWorksheetProcessLog;
            }


            if (request.requestType.equals(StagingRequestType.PROCESS_PACKAGING_WORKSHEET_UPLOAD)) {
                aBiManagerUploadFileBuilder.abiFileType = EAbiFileType.ApplyPackagingWorksheetRejectionsWorksheet;
            }
            if (request.requestType.equals(StagingRequestType.PROCESS_STAGING_FILE_UPLOAD)) {
                aBiManagerUploadFileBuilder.abiFileType = EAbiFileType.EditableStagingDataRejections;
            }
            if (request.requestType.equals(StagingRequestType.BUILD_PACKAGING_WORKSHEET)) {
                aBiManagerUploadFileBuilder.abiFileType = EAbiFileType.PackagingWorksheetSummary;
            }
            if (request.requestType.equals(StagingRequestType.PROCESS_ITEM_RESEARCH_UPLOAD)) {
                aBiManagerUploadFileBuilder.abiFileType = EAbiFileType.ApplyItemResearch;
            }
            uploadGeneratedFile(aBiManagerUploadFileBuilder);
        }
        return aBiManagerUploadFileBuilder;
    }

    protected ABiManagerUploadFileBuilder processStagingRequest(ABiManagerUploadFileBuilder aBiManagerUploadFileBuilder) throws IOException, ApplicationException {
        StagingRequest stagingRequest = aBiManagerUploadFileBuilder.stagingRequest;
        String category = aBiStagingRequestUtil.getCategoryForRequestType(stagingRequest.requestType);
        if (microservice.doesRequestAlreadyExist(stagingRequest)) {
            logger.error("ENVIRONMENT ERROR: Staging Request Already Exists.  Check JMS Queues are configured correctly.");
            logAccumulator.addMessage(category, stagingRequest.requestId, "Ignoring duplicate staging request.");
            return new ABiManagerUploadFileBuilder();
        }

        StagingRequestQueueRecord requestRecord = aBiStagingRequestUtil.createQueueRecord(stagingRequest);
        requestRecord = microservice.createStagingRequestQueueRecod(requestRecord);

        try {
            switch (stagingRequest.requestType) {
                case StagingRequestType.BUILD_GHX_ITEM_MASTER_SPREADSHEET:
                    StagingRequestWrapper wrapper = new StagingRequestWrapper(requestRecord, aBiManagerUploadFileBuilder);
                    aBiManagerUploadFileBuilder = microservice.buildGhxItemMasterSpreadsheet(wrapper);
                    break;
                case StagingRequestType.PROCESS_GHX_UPLOAD:
                    //Convert file to json
                    microservice.processGhxUpload(requestRecord);
                    break;
                case StagingRequestType.PROCESS_SCRIPT_PRO_UPLOAD:
                    microservice.processScriptProUpload(requestRecord);
                    break;
                case StagingRequestType.PROCESS_HCPCS_IMPLANT_UPLOAD:
                case StagingRequestType.PROCESS_COMMODITY_TYPE_UPLOAD:
                case StagingRequestType.PROCESS_GENERIC_ID_UNSPSC_MAP_UPLOAD:
                case StagingRequestType.PROCESS_MMC_NSN_MAP_UPLOAD:
                    aBiManagerUploadFileBuilder = microservice.processMmcNsnMapUpload(requestRecord);
                    break;
                case StagingRequestType.PROCESS_ITEM_RESEARCH_UPLOAD:

                    ABiManagerItemResearchUploadFileBuilder aBiManagerItemResearchUploadFileBuilder = microservice.processItemResearchUpload(requestRecord);
                    aBiManagerUploadFileBuilder = aBiManagerItemResearchUploadFileBuilder.aBiManagerUploadFileBuilder;
                    uploadGeneratedFile(aBiManagerItemResearchUploadFileBuilder.aBiManagerUploadFailuresFileBuilder);
                    List<ABiCatalogStagingItemResearchRecordSummary> itemResearchRecords = aBiManagerItemResearchUploadFileBuilder.updatedItemResearchRecords;

                    for( ABiCatalogStagingItemResearchRecordSummary record: itemResearchRecords){
                        List<SiteCatalogRecord> siteCatalogRecords = new ArrayList<SiteCatalogRecord>();
                        if ((Objects.nonNull(record.mmcProductIdentifiers)) && (!record.mmcProductIdentifiers.isEmpty())) {
                            siteCatalogRecords = productService.getByProductSeqIdList(record.mmcProductIdentifiers);
                        }
                        List<String> ids = new ArrayList<String>();
                        if (siteCatalogRecords != null && !siteCatalogRecords.isEmpty()) {
                            siteCatalogRecords.forEach(siteCatalogRecord -> ids.add(siteCatalogRecord.getId()));
                            if (ids != null && !ids.isEmpty() && record.enterpriseProductIdentifier != null) {
                                abiToSiteRecordLinkService.updateEnterpriseProductIdentifiersByIds(record.enterpriseProductIdentifier, ids);
                            }

                            // This is required because of update and get happen in different mongo db.
                            for (SiteCatalogRecord siteCatalogRecord : siteCatalogRecords) {
                                if (record.enterpriseProductIdentifier != null) {
                                    if (!StringUtils.equals(siteCatalogRecord.enterpriseProductIdentifier, record.enterpriseProductIdentifier)) {
                                        siteCatalogRecord.enterpriseProductIdentifier = record.enterpriseProductIdentifier;
                                        offerService.syncOffers(siteCatalogRecord);
                                        logger.info("PROCESS_ITEM_RESEARCH_UPLOAD for offer EPI =" + record.enterpriseProductIdentifier);
                                    }
                                }
                            }
                        }
                        // update site count and Abi Staging In-use
                        Integer siteCount = siteCatalogRequestService.updateSiteCount(record.enterpriseProductIdentifier);

                    }
                    break;

                case StagingRequestType.BUILD_MMC_EXCEPTION_REPORT:
                    aBiManagerUploadFileBuilder = microservice.buildMmcExceptionReport(requestRecord);
                    break;
                case StagingRequestType.RUN_APPLY_STAGING_CHANGES_TO_PRODUCTION:
                    aBiManagerUploadFileBuilder = microservice.runApplyStagingChangesToProduction(requestRecord);
                    aBiManagerUploadFileBuilder = null;
                    break;
                case StagingRequestType.APPLY_STAGING_CHANGES_TO_PRODUCTION_SUBTASK:
                    List<MoveRecordsResponse> moveRecordsResponseList =  microservice.runApplyStagingChangesToProductionSubtask(requestRecord);
                    // Need to update product, offer for EHR.
                    abiStagingMoveRecordsService.processMoveRecordResponses(moveRecordsResponseList);
                    aBiManagerUploadFileBuilder = null;
                    break;
                case StagingRequestType.UPDATE_STAGING_IMPLANT_ATTRIBUTES:
                    aBiManagerUploadFileBuilder = microservice.updateStagingImplantAttributesForRequest(requestRecord);
                    break;
                case StagingRequestType.BUILD_STAGING_EDITING_SPREADSHEET:
                    aBiManagerUploadFileBuilder = microservice.buildStagingEditingSpreadsheet(requestRecord);
                    break;
                case StagingRequestType.BUILD_PACKAGING_WORKSHEET:
                    aBiManagerUploadFileBuilder = microservice.buildPackagingWorksheet(requestRecord);
                    break;

                case StagingRequestType.BUILD_SITE_CATALOG_NO_ABI_RECORD_WORKSHEET:
                    List<String> argList3 = stagingRequest.argumentList;
                    String minimumGroupSizeStr2 = argList3.get(0);
                    String minimumOrderSizeStr2 = argList3.get(1);
                    String mmcExistsStr2 = argList3.get(2);
                    String mfrNameStart = argList3.get(3);
                    String mfrNameEnd = argList3.get(4);
                    String mfrNameSpecialCharsStr = argList3.get(5);
                    Boolean mfrNameSpecialChars = stringUtil.convertStringToBoolean(mfrNameSpecialCharsStr, false);
                    aBiManagerUploadFileBuilder = buildSiteCatalogNoABiRecordWorksheet(requestRecord, minimumGroupSizeStr2,
                            minimumOrderSizeStr2, mmcExistsStr2, mfrNameStart, mfrNameEnd, mfrNameSpecialChars);
                    break;


                case StagingRequestType.PROCESS_STAGING_FILE_UPLOAD:
                    aBiManagerUploadFileBuilder = microservice.processStagingFileUpload(requestRecord);
                    break;
                case StagingRequestType.PROCESS_PACKAGING_WORKSHEET_UPLOAD:
                    String processPackagincategory = microservice.startPackagingWorksheet(requestRecord);
                    aBiManagerUploadFileBuilder = packagingWorksheetUploadUpdateProcessor.processIncomingRequest(requestRecord, processPackagincategory);
                    break;
                case StagingRequestType.UPDATE_COMMODITY_TYPE_ATTRIBUTES:
                    aBiManagerUploadFileBuilder = microservice.updateCommodityTypeAttributesForRequest(requestRecord);
                    break;
                case StagingRequestType.UPDATE_GENERIC_ID_UNSPSC_MAP_ATTRIBUTE:
                    aBiManagerUploadFileBuilder = microservice.updateGenericIdUnspscMapAttributesForRequest(requestRecord);
                    break;
                case StagingRequestType.UPDATE_UNSPSC_CRITICAL_ITEM_CATEGORY_MAP_ATTRIBUTE:
                    aBiManagerUploadFileBuilder = microservice.updateUnspscCriticalItemCategoryMapAttributesForRequest(requestRecord);
                    break;
                case StagingRequestType.PROCESS_ECRI_UPLOAD:
                    aBiManagerUploadFileBuilder = microservice.processIncomingRequest(requestRecord);
                    break;
                case StagingRequestType.APPLY_NSNS_TO_PACKAGING_RECORDS:
                    aBiManagerUploadFileBuilder = microservice.applyNsnsToPackagingRecordsForRequest(requestRecord);
                    break;
                case StagingRequestType.PROMOTE_APPROVAL_CANDIDATES:
                    aBiManagerUploadFileBuilder = microservice.promoteApprovalCandidatesForRequest(requestRecord);
                    break;
                case StagingRequestType.APPLY_CASING_EXCEPTIONS:
                    aBiManagerUploadFileBuilder = microservice.applyCasingExceptionsForRequest(requestRecord);
                    break;
                case StagingRequestType.UPLOAD_ABI_FILE:
                    List<String> argList4 = stagingRequest.argumentList;
                    String uploadingRequestId = argList4.get(0);
                    String category2 = argList4.get(1);
                    String abiFileTypeStr = argList4.get(2);
                    EAbiFileType fileType = EAbiFileType.valueOf(abiFileTypeStr);
                    String filename = argList4.get(3);

                    String uploadMessage = "Uploading " + abiFileTypeStr + " file '" + filename + "'";
                    requestRecord.status = StagingRequestStatusType.PROCESSING;
                    requestRecord.notes = uploadMessage;

                    microservice.updateStagingRequestQueue(requestRecord);
                    String category3 = microservice.getCategoryForRequestType(stagingRequest.requestType);

                    microservice.logStagingRequestMessage(category3, stagingRequest.requestId,
                            uploadMessage);
                    uploadAbiFile(uploadingRequestId, category2, fileType, filename);
                    microservice.logStagingRequestMessage(category3, stagingRequest.requestId,
                            "File uploaded successfully.");
                    requestRecord.status = StagingRequestStatusType.COMPLETE;
                    requestRecord.notes = "File uploaded successfully.";
                    microservice.updateStagingRequestQueue(requestRecord);
                    aBiManagerUploadFileBuilder = null;
                    break;
                default:
                    break;
            }
        } catch (Exception ex) {
            // Catching all exceptions here - if any exceptions get through,  the message
            // doesn't get removed from the queue and it will continue to try to process
            // it indefinitely
            this.logger.error("Error Processing Request: ", ex);
            //logError(category, stagingRequest.requestId, , ex);
            requestRecord.status = StagingRequestStatusType.ERROR;
            requestRecord.notes = "Error processing request.";
            ExceptionInformation exceptionInfo = new ExceptionInformation(
                    "An error occurred while processing the request: " + ex.getMessage() +
                            " (Error Type: " + ex.getClass().toString() + ")",
                    StringUtil.getExceptionText(ex));
            microservice.logErrorToTaskHistory(category, requestRecord.requestId, exceptionInfo);
            microservice.updateStagingRequestQueue(requestRecord);
            throw ex;
        }
        return aBiManagerUploadFileBuilder;
    }

    private ABiManagerUploadFileBuilder buildSiteCatalogNoABiRecordWorksheet(StagingRequestQueueRecord requestRecord,
                                                                             String minimumGroupSizeStr,
                                                                             String minimumOrderSizeStr,
                                                                             String mmcExistsStr,
                                                                             String mfrNameStart,
                                                                             String mfrNameEnd,
                                                                             Boolean mfrNameSpecialChars) throws ApplicationException, IOException {


        requestRecord.status = StagingRequestStatusType.PROCESSING;
        String category = microservice.startSiteCatalogNoABiRecordWorksheet(requestRecord);
        String requestId = requestRecord.requestId;

        Integer minimumGroupSize = stringUtil.convertStringToInteger(minimumGroupSizeStr, 2);
        Integer minimumOrderSize = stringUtil.convertStringToInteger(minimumOrderSizeStr, 1000);
        Boolean mmcExists = stringUtil.convertStringToBoolean(mmcExistsStr, false);

        ABiManagerUploadFileBuilder aBiManagerUploadFileBuilder = null;
        try {
        ILogAccumulatorCallback flusher = () -> {
            microservice.logMessages(logAccumulator.getAll());
            logAccumulator.clear();
        };
        String mfrNameRange = mfrNameStart + "-" + mfrNameEnd + ((mfrNameSpecialChars) ? " and Special Characters" : "");
        logAccumulator.addMessage(category, requestId, "Running SiteCatalogNoAbiRecord Worksheet Generator ALTERNATE.");
        logAccumulator.addMessage(category, requestId, "   Min Group Size: " + minimumGroupSize);
        logAccumulator.addMessage(category, requestId, "   Min Order Size: " + minimumOrderSize);
        logAccumulator.addMessage(category, requestId, "   MMC Exists: " + mmcExists);
        logAccumulator.addMessage(category, requestId, "   Manufacturer Name Range: " + mfrNameRange);
        flusher.flush();


        logAccumulator.addMessage(category, requestId, "Getting list of manufacturers.");

        List<String> manufacturerNames = productService.getDistinctManufacturerNames();
        logAccumulator.addMessage(category, requestId, "Total Number of Manufacturers: " +
                manufacturerNames.size());
        manufacturerNames = trimManufacturerNameList(manufacturerNames, mfrNameStart, mfrNameEnd, mfrNameSpecialChars);
        logAccumulator.addMessage(category, requestId, "Number of Manufacturers in Range: " +
                manufacturerNames.size());

        flusher.flush();
        String currentMfrGroup = "";
        List<ManufacturerSiteCatalogRecords> mfrSiteCatRecList = new ArrayList<>();
        for (String manufacturerName : manufacturerNames) {
            String thisMfrGroup = null;
            if (!StringUtil.isEmptyOrNull(manufacturerName)) {
                thisMfrGroup = manufacturerName.substring(0, 1);


                if (currentMfrGroup.compareTo(thisMfrGroup) != 0) {
                    String msg = "Finding site catalog records for manufacturer names starting with '" + thisMfrGroup + "'.";
                    logAccumulator.addMessage(category, requestId, msg);
                    flusher.flush();
                    currentMfrGroup = thisMfrGroup;
                }
            }

            List<SiteCatalogRecord> siteCatRecordList = productService.getRecordsWithoutEnterpriseProductIdentifier(manufacturerName, mmcExists);
            if (!ListUtil.isEmpty(siteCatRecordList)) {
                ManufacturerSiteCatalogRecords msc = new ManufacturerSiteCatalogRecords();
                msc.manufacturerName = manufacturerName;
                msc.siteCatalogRecordList = siteCatRecordList;

                mfrSiteCatRecList.add(msc);
                    microservice.logStagingRequestMessage(category, requestId,
                            "==> Manufacturer " + msc.manufacturerName + " has " + msc.siteCatalogRecordList.size() + " records.");
                    microservice.logStagingRequestMessage(category, requestId,
                            "==> Number of manufacturers processed: " + mfrSiteCatRecList.size());
            }
        }
            microservice.logStagingRequestMessage(category, requestId, "Calling buildSiteCatalogNoABiRecordWorksheet to process records.");
        String reportName = "SiteCatalogNoABiRecord." + ((mmcExists) ? "mmcExists" : "mmcDoesntExist" + "." + mfrNameRange);

        List<String> tempDataIdList = microservice.buildSiteCatalogNoABiRecordWorksheet(requestId, category,
                minimumGroupSize, minimumOrderSize, mmcExists, reportName, mfrSiteCatRecList);

            microservice.logStagingRequestMessage(category, requestId, "Back from building spreadsheet.");


        } finally {
            microservice.logMessages(logAccumulator.getAll());
            logAccumulator.clear();
        }

        requestRecord.status = StagingRequestStatusType.COMPLETE;
        requestRecord.notes = "Site Catalog No ABi Record Worksheet generation is complete.";
        //abiSpreadsheetUtility.logMessage(category, requestRecord.requestId, "Site Catalog No ABi Record Worksheet generation is complete.");
        microservice.updateStagingRequestQueue(requestRecord);

        return null;
            }


    public List<AbiCatalogStaging> getRecordsInIdList(@QueryParam("searchType") ESearchAndReplaceType searchType,
                                                      List<String> idList) {
        return microservice.getRecordsInIdList(searchType, idList);
    }

    public List<AbiCatalogStaging> searchForWordInStagingRecords(@QueryParam("searchType") ESearchAndReplaceType searchType,
                                                                 @QueryParam("searchString") String searchString,
                                                                 @QueryParam("matchEntireAttribute") Boolean matchEntireAttribute) {
        return microservice.searchForWordInStagingRecords(searchType, searchString, matchEntireAttribute);
    }

    public List<String> replaceWordInStagingRecords(@QueryParam("searchType") ESearchAndReplaceType searchType,
                                                    @QueryParam("oldString") String oldString,
                                                    @QueryParam("newString") String newString,
                                                    @QueryParam("matchEntireAttribute") Boolean matchEntireAttribute) throws ApplicationException {
        return microservice.replaceWordInStagingRecords(searchType, oldString, newString, matchEntireAttribute);
    }

    public StagingRequestResponse generateMmcExceptionReport() {
        return microservice.generateMmcExceptionReport();
    }

    public StagingRequestResponse applyStagingChangesToProduction(Integer startIndex, Integer finalEndIndex, Integer chunkSize) {
        return microservice.applyStagingChangesToProduction(startIndex, finalEndIndex, chunkSize);
    }

    public StagingRequestResponse updateCommodityTypeAttributes() {
        return microservice.updateCommodityTypeAttributes();
    }

    public StagingRequestResponse updateGenericIdUnspscMapAttributes() {
        return microservice.updateGenericIdUnspscMapAttributes();
    }

    public StagingRequestResponse updateUnspscCriticalItemCategoryMapAttributes() {
        return microservice.updateUnspscCriticalItemCategoryMapAttributes();
    }

    public StagingRequestResponse applyNsnsToPackagingRecords() {
        return microservice.applyNsnsToPackagingRecords();
    }

    public StagingRequestResponse promoteApprovalCandidates(@QueryParam("catalogSource") String catalogSource) {
        return microservice.promoteApprovalCandidates(catalogSource);
    }

    public StagingRequestResponse applyCasingExceptions() {
        return microservice.applyCasingExceptions();
    }

    public StagingRequestResponse updateStagingImplantAttributes() {
        return microservice.updateStagingImplantAttributes();
    }

    public StagingRequestResponse generatePackagingWorksheet(@QueryParam("mode") String mode,
                                                             @QueryParam("matchOption") String matchOption,
                                                             @QueryParam("filterData") String filterData) {
        return microservice.generatePackagingWorksheet(mode, matchOption, filterData);
    }

    public StagingRequestResponse generateSiteCatalogNoABiRecordWorksheet(@QueryParam("minimumGroupSize") Integer minimumGroupSize,
                                                                          @QueryParam("minimumOrderSum") Integer minimumOrderSum,
                                                                          @QueryParam("mmcExists") Boolean mmcExists,
                                                                          @QueryParam("manufacturerNameRange") String manufacturerNameRange) {
        return microservice.generateSiteCatalogNoABiRecordWorksheet(minimumGroupSize, minimumOrderSum, mmcExists,
                manufacturerNameRange);
    }

    public List<FileRef> getFileRefsByIds(List<String> fileIds) {
        return fileManagerAdminService.getFileRefsByIds(fileIds);
    }

    public boolean deleteStagingRequest(@QueryParam("stagingRequestId") String stagingRequestId) {
        return microservice.deleteStagingRequest(stagingRequestId);
    }

    public Integer deleteABiFile(@QueryParam("id") String id) throws IOException, ApplicationException {
        AbiDownloadFile record = microservice.getDownloadFileInfo(id);
        fileManagerAdminService.removeFile(record.fileManagerId);
        return microservice.deleteABiFile(record.getId());
    }

    public boolean doesEnterpriseProductIdentifierExist(String enterpriseProductIdentifier) {
        return microservice.doesEnterpriseProductIdentifierExist(enterpriseProductIdentifier);
    }

    public Long getPriorStagingRequestCount(@QueryParam("olderThanDays") Integer olderThanDays) {
        return microservice.getPriorStagingRequestCount(olderThanDays);
    }

    public Long deletePriorStagingRequests(@QueryParam("olderThanDays") Integer olderThanDays) {
        return microservice.deletePriorStagingRequests(olderThanDays);
    }

    public void adjustEcriEquipmentCount(String ecriGuid, Integer adjustment) {
        microservice.adjustEcriEquipmentCount(ecriGuid, adjustment);
    }

    public List<String> syncEquipmentRecordCounts(Map<String, Integer> ecriProductCounts) {
        return microservice.syncEquipmentRecordCounts(ecriProductCounts);
    }

    public Long getInUseRecordsCount() {
        return microservice.getInUseRecordsCount();
    }

    protected List<String> trimManufacturerNameList(List<String> manufacturerNames, String mfrNameStart,
                                                    String mfrNameEnd, Boolean mfrNameSpecialChars) {
        List<String> result = new ArrayList<>();
        if ((!ListUtil.isEmpty(manufacturerNames)) && (!StringUtil.isBlankOrNull(mfrNameStart)) &&
                (!StringUtil.isBlankOrNull(mfrNameEnd))) {
            Character mfrNameStartChar = mfrNameStart.trim().toUpperCase().charAt(0);
            Character mfrNameEndChar = mfrNameEnd.trim().toUpperCase().charAt(0);
            if (!ListUtil.isEmpty(manufacturerNames)) {
                for (String manufacturerName : manufacturerNames) {
                    if (StringUtil.isBlankOrNull(manufacturerName)) {
                        continue;
                    }
                    Character firstChar = manufacturerName.trim().toUpperCase().charAt(0);
                    if (Character.isAlphabetic(firstChar)) {
                        if ((firstChar.compareTo(mfrNameStartChar) >= 0) &&
                                (firstChar.compareTo(mfrNameEndChar) <= 0)) {
                            result.add(manufacturerName);
                        }
                    } else if (mfrNameSpecialChars) {
                        result.add(manufacturerName);
                    }
                }
            }
        }
        return result;
    }

    protected void uploadGeneratedFile(ABiManagerUploadFileBuilder aBiManagerUploadFileBuilder) throws ApplicationException {
        uploadAbiFile(aBiManagerUploadFileBuilder.requestId, aBiManagerUploadFileBuilder.category,
                aBiManagerUploadFileBuilder.abiFileType, aBiManagerUploadFileBuilder.fileName);
    }


    protected void uploadAbiFile(String uploadingRequestId, String category, EAbiFileType abiFileType, String filename)
            throws ApplicationException {
        if (filename == null) {
            logger.error("uploadAbiFile: filename is null.");
            return;
        }
        logger.info("******************** aBiManagerUploadFileBuilder.fileName: " + filename +
                    ", category: " + category + ", abiFileType: " + abiFileType);
        if (filename == null) {
            logger.error("uploadAbiFile: filename is null. Returning.");
            return;
        }
        Path filePath = Paths.get(filename);
        File f = filePath.toFile();

        if (f.exists()) {
            String relativePath = configurationService.getGhxExtractUploadRelativePath();
            logger.info(category, uploadingRequestId, "Calling File Manager to upload file '" + filename + "' to relative path '" + relativePath + "'");

            FileManager fmf = fileManagerAdminService.uploadUnmanagedFile(filename, relativePath);

            logger.info(category, uploadingRequestId, "Creating record for Download File.");
            AbiDownloadFile fileRecord = new AbiDownloadFile();

            fileRecord.fileDate = fmf.uploadDateTime;
            fileRecord.fileManagerId = fmf.getId();
            fileRecord.fileSize = fmf.fileSize;
            fileRecord.fileType = abiFileType;
            fileRecord.filename = filePath.getFileName().toString();

            microservice.insertAbiDownloadFile(fileRecord);

            try {
                Files.delete(filePath);
            } catch (IOException e) {
                throw new ApplicationException("Could not delete file." + f.getAbsolutePath());
            }
        } else {
            throw new ApplicationException("File not found: " + filename);
        }
    }


    public void sendRequest(StagingRequest request){
        microservice.sendRequest(request);
    }

    public AbiCatalogStaging getAbiCatalogStagingRecordByEnterpriseProductIdentifier(String enterpriseProductIdentifier) {
        return microservice.getAbiCatalogStagingRecordByEnterpriseProductIdentifier(enterpriseProductIdentifier);

    }

    public List<ABiCatalogRecordRef> getAbiStagingCatalogRecordRefListforCriticalItems(){
        return microservice.getAbiStagingCatalogRecordRefListforCriticalItems();
    }

    public void updateCriticalItemCategoryRefs(CriticalItemCategoryRef ref) {
        microservice.updateCriticalItemCategoryRefs(ref);
    }

    public String applyCasingAndSubstitutionRules(String text) {
        return microservice.applyCasingAndSubstitutionRules(text);
    }
}
