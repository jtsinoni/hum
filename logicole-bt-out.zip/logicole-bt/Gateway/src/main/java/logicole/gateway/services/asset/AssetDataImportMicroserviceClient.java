package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetDataImportMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AssetDataImportMicroserviceClient extends MicroserviceClient<IAssetDataImportMicroserviceApi> {
    public AssetDataImportMicroserviceClient() {
        super(IAssetDataImportMicroserviceApi.class, "logicole-asset");
    }
    
    @Produces
    public IAssetDataImportMicroserviceApi getIAssetMicroserviceApi() {
        return createClient();
    }
}
