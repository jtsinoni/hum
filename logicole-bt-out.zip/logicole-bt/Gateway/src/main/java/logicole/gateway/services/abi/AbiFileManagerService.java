package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiFileManagerMicroserviceApi;
import logicole.common.datamodels.abi.staging.EABiUploadType;
import logicole.common.datamodels.abi.staging.StagingRequest;
import logicole.common.datamodels.abi.staging.StagingRequestResponse;
import logicole.common.datamodels.abi.types.StagingRequestType;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.general.configuration.ConfigurationManager;
import logicole.common.general.event.BusinessEvent;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.jms.JmsClient;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@ApplicationScoped
public class AbiFileManagerService extends BaseGatewayService<IAbiFileManagerMicroserviceApi> {

    public AbiFileManagerService() {
        super("AbiFileManager");
    }

    @Inject
    AbiConfigurationService abiConfigurationService;

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    private MultiPartFormUtil multiPartFormUtil;

    @Inject
    private JmsClient jmsClient;

    @Inject
    private ConfigurationManager configurationManager;

    public Integer deleteUploadHistory() {
        return microservice.deleteUploadHistory();
    }

    public FileManager uploadABiFile(EABiUploadType abiUploadType, MultipartFormDataInput form) {

        if ((abiUploadType == null) || (abiUploadType == EABiUploadType.NotSpecified)) {
            throw new FatalProcessingException("An valid ABi Upload Type must be specified.");
        }

        InputPart inputPart = multiPartFormUtil.getInputPart(form, "file");
        String uploadedFileName = multiPartFormUtil.getFileName(inputPart.getHeaders());
        FileManager fileManagerFile = null;
        StagingRequestResponse response;
        String stagingRequestType;
        List<String> arguments;
        StagingRequest request;

        try {
            InputStream inputStream = inputPart.getBody(InputStream.class, null);
            String tempFileName = saveToTempFile(inputStream);
            microservice.logUploadMessage("Uploading File: " + uploadedFileName);

            switch (abiUploadType) {
                case GHX:
                    //upload file
                    uploadFile(abiUploadType, uploadedFileName, tempFileName);

                    //create request
                    response = new StagingRequestResponse();
                    response.stagingRequestId = UUID.randomUUID().toString();
                    stagingRequestType = StagingRequestType.PROCESS_GHX_UPLOAD;
                    arguments = new ArrayList<>();
                    arguments.add(uploadedFileName);

                    request = StagingRequest.create(response.stagingRequestId, stagingRequestType, arguments);
                    sendRequest(request);

                    response.notes = "Process GHX Upload Request was queued for processing.";

                    //return file back to PT
                    fileManagerFile = new FileManager();
                    fileManagerFile.uploadedFileName = uploadedFileName;
                    fileManagerFile.uploadDateTime = new Date();
                    fileManagerFile.uploadedBy = currentUserBT.getProfileId();
                    break;
                case SCRIPTPRO:
                    //Validate json
                    boolean isValid = microservice.validateScriptProUploadFile(uploadedFileName, tempFileName);

                    if (isValid) {
                        //upload file
                        uploadFile(abiUploadType, uploadedFileName, tempFileName);

                        //create request
                        response = new StagingRequestResponse();
                        response.stagingRequestId = UUID.randomUUID().toString();
                        stagingRequestType = StagingRequestType.PROCESS_SCRIPT_PRO_UPLOAD;
                        arguments = new ArrayList<>();
                        arguments.add(uploadedFileName);

                        request = StagingRequest.create(response.stagingRequestId, stagingRequestType, arguments);
                        sendRequest(request);

                        response.notes = "Process SCRIPT PRO Upload Request was queued for processing.";

                        //return file back to PT
                        fileManagerFile = new FileManager();
                        fileManagerFile.uploadedFileName = uploadedFileName;
                        fileManagerFile.uploadDateTime = new Date();
                        fileManagerFile.uploadedBy = currentUserBT.getProfileId();
                    } else {
                        throw new ApplicationException("SCRIPTPRO file is not in valid json format");
                    }
                    break;

                case ITEM_RESEARCH:
                case PACKAGING_WORKSHEET:
                case HCPCS_IMPLANT:
                case STAGING_EDITING_SPREADSHEET:
                case COMMODITY_TYPE:
                case GENERIC_ID_UNSPSC_MAP:
                case ECRI:
                case MMC_NSN_MAP:
                    fileManagerFile = microservice.processDataUpdateUploadFile(abiUploadType, uploadedFileName, tempFileName);
                    break;
                default:
                    break;
            }
        } catch (Exception ioe) {
            this.logger.error("File could not be uploaded: " + uploadedFileName + ": " + ioe.getMessage());
            microservice.logUploadError("File could not be uploaded: " + uploadedFileName, ioe);
            throw new FatalProcessingException("An error occurred while uploading the ABi File '" + uploadedFileName + "'");
        }
        return fileManagerFile;
    }

    private void uploadFile(EABiUploadType abiUploadType, String uploadedFileName, String tempFileName) throws IOException, ApplicationException {
        FileManager fileManagerFile;
        String relativeFilePath = this.getRelativeFilePath(abiUploadType);
        Path parentDir = Paths.get(tempFileName).getParent();
        String destination = Paths.get(parentDir.toString(), uploadedFileName).toAbsolutePath().toString();
        Files.move(Paths.get(tempFileName), Paths.get(destination), StandardCopyOption.REPLACE_EXISTING);
        fileManagerFile = fileManagerAdminService.uploadUnmanagedFile(destination, relativeFilePath);
        microservice.logUploadMessage("File Uploaded. Name='" + fileManagerFile.uploadedFileName + "', size=" + fileManagerFile.fileSize);
        Files.deleteIfExists(Paths.get(destination));
    }

    private String saveToTempFile(InputStream inputStream) throws IOException, ApplicationException {
        String tempDirectory = abiConfigurationService.getAbiTempDirectory();
        validateDirectory(tempDirectory);
        File tempDirFile = new File(tempDirectory);
        File f = File.createTempFile("abi", ".tmp", tempDirFile);
        String absolutePath = f.getAbsolutePath();

        byte[] contents = IOUtils.toByteArray(inputStream);
        Path filePath = Paths.get(absolutePath);
        Files.write(filePath, contents);
        return absolutePath;
    }

    protected void validateDirectory(String tempDirectory) throws ApplicationException {
        Path tempDirPath = Paths.get(tempDirectory);
        if ((!tempDirPath.toFile().exists()) || (!tempDirPath.toFile().isDirectory())) {
            throw new ApplicationException("ENVIRONMENT ERROR: ABi Temp Directory '" + tempDirectory + "' does not exist." +
                    "Check File Shares and JBOSS modules/conf/main/properties/config.properties" +
                    "Configuration File.");
        }
    }

    private String getRelativeFilePath(EABiUploadType abiUploadType) {
        String relativePath = null;
        switch (abiUploadType) {
            case GHX:
                relativePath = abiConfigurationService.getGhxExtractUploadRelativePath();
                break;
            case SCRIPTPRO:
                relativePath = abiConfigurationService.getScriptProExtractUploadRelativePath();
                break;
            case ITEM_RESEARCH:
                relativePath = abiConfigurationService.getItemResearchUploadRelativePath();
                break;
            case HCPCS_IMPLANT:
            case PACKAGING_WORKSHEET:
            case STAGING_EDITING_SPREADSHEET:
            case COMMODITY_TYPE:
            case GENERIC_ID_UNSPSC_MAP:
            case MMC_NSN_MAP:
            case ECRI:
                relativePath = abiConfigurationService.getAbiTempDirectory() + "/uploads";
                break;
            default:
                break;
        }
        return relativePath;
    }

    private void sendRequest(StagingRequest request) {
        try {
            JSONUtil ju = new JSONUtil();
            String requestJSON = ju.serialize(request);
            BusinessEvent event = new BusinessEvent();
            event.name = request.requestType;
            event.parameterJson = requestJSON;
            jmsClient.sendTextMessageToQueue(requestJSON, "ABiStagingRequestBroker", JmsClient.BUSINESS_EVENT, null);
        } catch (IOException ex) {
            throw new FatalProcessingException("Error: Could not send request: " + ex.getMessage(), ex);
        }
    }
}
