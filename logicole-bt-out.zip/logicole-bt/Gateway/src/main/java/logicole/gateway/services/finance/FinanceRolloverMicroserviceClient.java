package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceRolloverMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class FinanceRolloverMicroserviceClient extends MicroserviceClient<IFinanceRolloverMicroserviceApi> {
    public FinanceRolloverMicroserviceClient(){
        super(IFinanceRolloverMicroserviceApi.class, "logicole-finance");
    }

    @Produces
    public IFinanceRolloverMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
