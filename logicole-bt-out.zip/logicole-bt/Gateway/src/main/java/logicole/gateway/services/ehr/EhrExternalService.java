package logicole.gateway.services.ehr;


import logicole.common.datamodels.communications.ehr.*;
import logicole.common.datamodels.communications.transmitproperty.LogiColeAuthToken;
import logicole.common.datamodels.dmlss.EhrSiteCustomer;
import logicole.common.datamodels.ehr.equipment.*;
import logicole.common.datamodels.ehr.product.*;
import logicole.common.datamodels.organization.DmlssHost;
import logicole.common.datamodels.user.LoginCredential;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.remote.IDefaultRemoteApi;
import logicole.gateway.services.communications.EhrMessagesService;
import logicole.gateway.services.communications.EhrRequestFactoryService;
import logicole.gateway.services.communications.EhrRequestQueueService;
import logicole.gateway.services.equipment.EquipmentRecordService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.product.OfferService;
import logicole.gateway.services.user.UserService;

import java.util.*;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class EhrExternalService extends BaseGatewayService<IDefaultRemoteApi> {

    @Inject
    EhrMessagesService ehrMessagesService;

    @Inject
    EhrRequestFactoryService ehrRequestFactoryService;

    @Inject
    EhrRequestQueueService ehrRequestQueueService;

    @Inject
    private EquipmentCatalogItemAccumulator equipmentCatalogItemAccumulator;

    @Inject
    EquipmentRecordService equipmentRecordService;

    @Inject
    private ItemMasterSupplyCatalogAccumulator supplyItemAccumulator;

    @Inject
    OfferService offerService;

    @Inject
    OrganizationService organizationService;

    @Inject
    UserService userService;

    public EhrExternalService() {
        super("Ehr");
    }

    public ItemMasterSupplyCatalog getItemMasterSupplyCatalog() {
        List<EhrSiteCustomer> customers = organizationService.getEhrSiteCustomers("Item");

        ItemMasterSupplyCatalog catalog = new ItemMasterSupplyCatalog();
        catalog.itemCatalogType = EItemMasterSupplyCatalogType.ITEM_COMPLETE;
        Date updateDate = new Date();

        for (EhrSiteCustomer siteCustomer: customers) {
            try {
                List<ItemMasterSupplyCatalogItem> items =
                        offerService.getCatalogItemsForSiteCustomer(siteCustomer.siteOrgId, siteCustomer.customerOrgId,
                                null, EItemMasterSupplyCatalogType.ITEM_COMPLETE);

                supplyItemAccumulator.accumulate(items, null, EItemMasterSupplyCatalogType.ITEM_COMPLETE);
                organizationService.updateLastItemCatalogDate(siteCustomer, updateDate);
            } catch (Exception ex) {
                logger.error("could not process full item catalog for - " + siteCustomer.siteOrgId, ex);
            }
        }
        catalog.itemRecords = supplyItemAccumulator.getItems();
        return catalog;

    }

    public ItemMasterSupplyCatalog getItemMasterSupplyCatalogDelta() {
        List<EhrSiteCustomer> customers = organizationService.getItemMasterEnabledCustomerOrgs();
        ItemMasterSupplyCatalog catalog = new ItemMasterSupplyCatalog();
        catalog.itemCatalogType = EItemMasterSupplyCatalogType.ITEM_DELTA;
        Date updateDate = new Date();

        for (EhrSiteCustomer siteCustomer: customers) {
            try {

                List<ItemMasterSupplyCatalogItem> items =
                        offerService.getCatalogItemsForSiteCustomer(siteCustomer.siteOrgId,
                                siteCustomer.customerOrgId,
                                siteCustomer.ehrLastItemSyncDate, EItemMasterSupplyCatalogType.ITEM_DELTA);

                supplyItemAccumulator.accumulate(items, siteCustomer.ehrLastItemSyncDate, EItemMasterSupplyCatalogType.ITEM_DELTA );
                organizationService.updateLastItemCatalogDate(siteCustomer, updateDate);
            } catch (Exception ex) {
                logger.error("could not process full item catalog for - " + siteCustomer.siteOrgId, ex);
            }
        }
        catalog.itemRecords = supplyItemAccumulator.getItems();
        return catalog;
    }

    public EquipmentCatalog getEquipmentCatalog() {
        List<EhrSiteCustomer> customers = organizationService.getEhrSiteCustomers("Equipment");

        EquipmentCatalog cat = new EquipmentCatalog();
        cat.equipmentCatalogType = EEquipmentCatalogType.EQUIPMENT_COMPLETE;
        EquipmentCatalogItemAccumulator accumulator = new EquipmentCatalogItemAccumulator();

        for (EhrSiteCustomer siteCustomer: customers) {
            try {
                Date updateDate = new Date();
                List<EquipmentCatalogItem> items = equipmentRecordService.getEquipmentCatalogItemsComplete(siteCustomer);
                equipmentCatalogItemAccumulator.accumulate(items);
                organizationService.updateLastEquipmentDate(siteCustomer, updateDate);
            } catch (Exception ex) {
                logger.error("could not process full equipment catalog for - " + siteCustomer.siteOrgId, ex);
            }
        }
        cat.equipmentItems.addAll(equipmentCatalogItemAccumulator.getItems());
        return cat;
    }

    public EquipmentCatalog getEquipmentCatalogDelta() {
        List<EhrSiteCustomer> customers = organizationService.getEhrSiteCustomers("Equipment");

        EquipmentCatalog cat = new EquipmentCatalog();
        cat.equipmentCatalogType = EEquipmentCatalogType.EQUIPMENT_DELTA;
        EquipmentCatalogItemAccumulator accumulator = new EquipmentCatalogItemAccumulator();

        for (EhrSiteCustomer siteCustomer: customers) {
            try {
                Date updateDate = new Date();
                List<EquipmentCatalogItem> items = equipmentRecordService.getEquipmentCatalogItemsDelta(siteCustomer);
                equipmentCatalogItemAccumulator.accumulate(items);
                organizationService.updateLastEquipmentDate(siteCustomer, updateDate);
            } catch (Exception ex) {
                logger.error("could not process equipment catalog delta for - " + siteCustomer.siteOrgId, ex);
            }
        }

        cat.equipmentItems.addAll(equipmentCatalogItemAccumulator.getItems());
        return cat;
    }

    public PurchaseOrderResponse placeOrder(EhrPurchaseOrder purchaseOrder) throws ApplicationException {
        String requestId = UUID.randomUUID().toString();
        EhrRequest request = ehrRequestFactoryService.createRequest(purchaseOrder, requestId);
        String status = validatePO(purchaseOrder);
        PurchaseOrderResponse response;
        EhrPurchaseOrderHistory history;
        if (EPurchaseOrderResponseStatusType.ACCEPTED.name().equals(status)) {
            response = getPOResponse(purchaseOrder, status);
            history = createHistory(purchaseOrder);
            history.response = response;
            EhrRequestResponse requestInfo = new EhrRequestResponse();
            requestInfo.stagingRequestId = requestId;
            requestInfo.notes = "Order queued for conversion and sending to DMLSS.";
            history.requestInfo = requestInfo;

            ehrRequestQueueService.sendRequest(request);
        } else {
            response = getPOResponse(status);
            history = new EhrPurchaseOrderHistory();
            history.response = response;
        }
        ehrMessagesService.createEhrPurchaseOrderHistory(history);

        return response;
    }

    EhrPurchaseOrderHistory createHistory(EhrPurchaseOrder purchaseOrder) {
        EhrPurchaseOrderHistory history = new EhrPurchaseOrderHistory();
        history.actionDate = new Date();
        history.siteOrgId = purchaseOrder.dodaac;
        history.customerOrgId = purchaseOrder.customerAccountId;
        history.purchaseOrder = purchaseOrder;
        history.receivedFromGenesisDate = new Date();
        history.sendingPkiDn = currentUserBT.getCurrentUser().profile.pkiDn;
        return history;
    }

    PurchaseOrderResponse getPOResponse(String status) {
        PurchaseOrderResponse response = new PurchaseOrderResponse();
        response.responseStatus = status;
        return response;
    }

    PurchaseOrderResponse getPOResponse(EhrPurchaseOrder purchaseOrder, String status) {
        PurchaseOrderResponse response = new PurchaseOrderResponse();
        String dodaac = purchaseOrder.dodaac;
        response.dodaac = dodaac;
        response.customerAccountId = purchaseOrder.customerAccountId;
        response.purchaseOrderNumber = purchaseOrder.purchaseOrderNumber;
        response.orderDate = purchaseOrder.orderDate;
        response.receivedDate = new Date();
        response.responseStatus = status;
        return response;
    }

    private String validatePO(EhrPurchaseOrder purchaseOrder) {
        String statusTypeString;

        if (purchaseOrder == null) {
            statusTypeString = EPurchaseOrderResponseStatusType.REJECTED_INVALID_PURCHASE_ORDER_STRUCTURE.toString();
        } else if (purchaseOrder.dodaac == null) {
            statusTypeString = EPurchaseOrderResponseStatusType.REJECTED_MISSING_OR_UNKNOWN_DODAAC.toString();
        } else if (purchaseOrder.customerAccountId == null) {
            statusTypeString = EPurchaseOrderResponseStatusType.REJECTED_MISSING_OR_UNKNOWN_CUSTOMER_ACCOUNT_ID.toString();
        } else {
            Boolean isValidSiteAndCustomerOrgId = organizationService.isSiteAndCustomerOrgIdValid(
                    purchaseOrder.dodaac,
                    purchaseOrder.customerAccountId);
            Boolean isPONumberUnique = ehrMessagesService.isPONumberUnique(
                    purchaseOrder.purchaseOrderNumber,
                    purchaseOrder.dodaac,
                    purchaseOrder.customerAccountId);

            DmlssHost dmlssHost = organizationService.getDmlssHostByDodaac(purchaseOrder.dodaac);

            if (dmlssHost == null) {
                statusTypeString = EPurchaseOrderResponseStatusType.REJECTED_MISSING_OR_UNKNOWN_DODAAC.toString();
            } else if (isPONumberUnique && isValidSiteAndCustomerOrgId) {
                statusTypeString = EPurchaseOrderResponseStatusType.ACCEPTED.toString();
            } else {
                statusTypeString = !isPONumberUnique
                        ? EPurchaseOrderResponseStatusType.REJECTED_PO_NUMBER_IS_NOT_UNIQUE.toString()
                        : EPurchaseOrderResponseStatusType.REJECTED_MISSING_OR_UNKNOWN_CUSTOMER_ACCOUNT_ID.toString();
            }
        }
        return statusTypeString;
    }

    public LogiColeAuthToken getLogicoleAuthToken() {
        LogiColeAuthToken logiColeAuthToken = new LogiColeAuthToken();
        LoginCredential loginCredential;

        loginCredential = userService.logIn();
        logiColeAuthToken.authctoken = loginCredential.getJsonWebToken();

        return logiColeAuthToken;
    }
}
