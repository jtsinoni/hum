package logicole.gateway.services.user;

import logicole.apis.user.IRoleMicroserviceApi;
import logicole.common.datamodels.featureflag.FeatureFlag;
import logicole.common.datamodels.organization.AncestryQuery;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationTypeRef;
import logicole.common.datamodels.organization.ScopeQuery;
import logicole.common.datamodels.organization.ServiceProvider;
import logicole.common.datamodels.organization.ServiceProviderRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.FilterRolesFromFeaturesWrapper;
import logicole.common.datamodels.user.FunctionalArea;
import logicole.common.datamodels.user.GroupInvitation;
import logicole.common.datamodels.user.Role;
import logicole.common.datamodels.user.RoleFunctionalArea;
import logicole.common.datamodels.user.RoleRef;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.ObjectNotFoundException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.organization.OrganizationService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static logicole.common.datamodels.user.RoleConstants.USER_ADMIN_MANAGER_ROLE_ID;
import static logicole.common.datamodels.user.RoleConstants.USER_MANAGER_ROLE_ID;

@ApplicationScoped
public class RoleService extends BaseGatewayService<IRoleMicroserviceApi> {

    @Inject
    OrganizationService organizationService;

    @Inject
    UserService userService;

    List<ServiceProvider> serviceProviders = new ArrayList<>();

    Role adminManagerRole = new Role();
    Role userManagerRole = new Role();

    public RoleService() {
        super("Role");
    }

    private UserProfile buildProfileFromGroupInvitation(GroupInvitation groupInvitation){
        UserProfile templateProfile = new UserProfile();
        templateProfile.currentNodeRef = groupInvitation.userProfileTemplate.currentNodeRef;
        templateProfile.managedByNodeRef = groupInvitation.userProfileTemplate.managedByNodeRef;
        templateProfile.nodeTypeRef = groupInvitation.userProfileTemplate.nodeTypeRef;
        templateProfile.scopeNodeRefs = groupInvitation.userProfileTemplate.scopeNodeRefs;
        templateProfile.roleRefs = groupInvitation.userProfileTemplate.roleRefs;
        templateProfile.assignableRoleRefs = groupInvitation.userProfileTemplate.assignableRoleRefs;
        templateProfile.isAllAssignableRoles = groupInvitation.userProfileTemplate.isAllAssignableRoles;
        return templateProfile;
    }

    private FilterRolesFromFeaturesWrapper createFilterRolesFromFeaturesWrapper(List<Role> roles, UserProfile userProfile) {
        Map<String, FeatureFlag> activeFeatureFlagMap = userService.getFeatureFlagMap();
        FilterRolesFromFeaturesWrapper wrapper = new FilterRolesFromFeaturesWrapper();
        wrapper.roleList = roles;
        wrapper.currentUser = currentUserBT.getCurrentUser();
        wrapper.featureFlagMap = activeFeatureFlagMap;
        wrapper.userProfile = userProfile;
        return wrapper;
    }

    private boolean doesCurrentUserContainRoleId(String roleId){
        boolean isFound = false;
        List<RoleRef> roleRefs = currentUserBT.getCurrentUser().profile.roleRefs;
        if(!roleRefs.isEmpty()){
            isFound = roleRefs.stream().anyMatch(roleRef -> roleRef.getId().equals(roleId));
        }
        return isFound;
    }

    private boolean doesUserProfileContainRoleId(UserProfile userProfile, String roleId){
        boolean isFound = false;
        List<RoleRef> roleRefs = userProfile.roleRefs;
        if(!roleRefs.isEmpty()){
            isFound = roleRefs.stream().anyMatch(roleRef -> roleRef.getId().equals(roleId));
        }
        return isFound;
    }

    private List<Role> filterUserManagementRoles(List<Role> rolesToFilter, UserProfile userProfile){

        if(adminManagerRole == null || StringUtil.isEmptyOrNull(adminManagerRole.getId())){
            adminManagerRole = microservice.getRoleById(USER_ADMIN_MANAGER_ROLE_ID);
        }

        if(userManagerRole == null || StringUtil.isEmptyOrNull(userManagerRole.getId())){
            userManagerRole = microservice.getRoleById(USER_MANAGER_ROLE_ID);
        }

        rolesToFilter = rolesToFilter.stream().filter(r -> !USER_ADMIN_MANAGER_ROLE_ID.contains(r.getId())).collect(Collectors.toList());
        rolesToFilter = rolesToFilter.stream().filter(r -> !USER_MANAGER_ROLE_ID.contains(r.getId())).collect(Collectors.toList());

        boolean isCurrUserAdminManager = doesCurrentUserContainRoleId(USER_ADMIN_MANAGER_ROLE_ID);
        boolean isProfileAtRoot = isRootLevelUser(userProfile.nodeTypeRef.id);
        if(isCurrUserAdminManager){

            rolesToFilter.add(userManagerRole);

            if(isProfileAtRoot){
                rolesToFilter.add(adminManagerRole);
            }

        }

        return rolesToFilter;
    }

    private List<Role> getRolesFromRoleRefs(List<RoleRef> roleRefs) {
        if (roleRefs == null) {
            return new ArrayList<>();
        }

        String[] arrayOfRoles = roleRefs.stream()
                .map(r -> r.id).toArray(String[]::new);

        return microservice.getRoles(arrayOfRoles);
    }

    private List<RoleRef> getRoleRefsFromRoles(List<Role> roles) {
        if (roles == null) {
            return new ArrayList<>();
        }

        return roles.stream()
                .map(Role::getRef)
                .collect(Collectors.toList());
    }

    private List<Role> getAndFilterRoles(@NotNull UserProfile userProfile, @NotNull String nodeTypeId){
        List<String> nodeTypeRefIds = new ArrayList<>();
        nodeTypeRefIds.add(nodeTypeId);

        ScopeQuery scopeQuery = userService.getScopeQueryForUser(userProfile, nodeTypeId);
        List<Organization> orgs = organizationService.getOrganizationsInScope(scopeQuery);
        if (orgs == null || orgs.isEmpty()) {
            throw new ApplicationException("No organizations for the user profile found");
        }

        serviceProviders = organizationService.getServiceProviders();

        List<String> spRoleRefIds = new ArrayList<>();
        List<String> serviceProviderIds = new ArrayList<>();

        for(Organization org : orgs){

            for (ServiceProviderRef serviceProviderRef : org.serviceProviderRefs) {

                ServiceProvider serviceProvider = serviceProviders.stream()
                        .filter(customer -> serviceProviderRef.id.equals(customer.getId()))
                        .findAny()
                        .orElse(null);

                if(serviceProvider != null){

                    if (!serviceProviderIds.contains(serviceProvider.getId())) {
                        serviceProviderIds.add(serviceProvider.getId());

                        for (RoleRef roleRef : serviceProvider.consumer.roleRefs) {

                            if (!spRoleRefIds.contains(roleRef.id)) {
                                spRoleRefIds.add(roleRef.id);
                            }

                        }

                    }
                }
            }
        }

        List<Role> roles = microservice.getRolesByRoleIdsAndOrgTypeIds(spRoleRefIds, nodeTypeRefIds);
        FilterRolesFromFeaturesWrapper wrapper = createFilterRolesFromFeaturesWrapper(roles, userProfile);
        List<Role> rolesFiltered = microservice.filterRolesFromFeatures(wrapper);

        return filterUserManagementRoles(rolesFiltered, userProfile);
    }

    private List<Role> getAndFilterAssignableRoles(UserProfile userProfile){
        // Get organizations at the profile's scope and below
        AncestryQuery ancestryQuery = new AncestryQuery();
        ancestryQuery.scopeOrganizationIds.addAll(userProfile.scopeNodeRefs.stream().map(OrganizationRef::getId).collect(Collectors.toList()));
        List<Organization> orgsInScope = organizationService.getScopeUsingAncestry(ancestryQuery);

        // Get role ids from the organization service providers (role groupings)
        List<String> spRoleRefIds = new ArrayList<>();
        List<String> orgTypeIdsCovered = new ArrayList<>();
        for (Organization org : orgsInScope) {

            if (!orgTypeIdsCovered.contains(org.nodeTypeRef.id)) {
                orgTypeIdsCovered.add(org.nodeTypeRef.id);

                for (ServiceProviderRef serviceProviderRef : org.serviceProviderRefs) {

                    ServiceProvider serviceProvider = serviceProviders.stream()
                            .filter(customer -> serviceProviderRef.id.equals(customer.getId()))
                            .findAny()
                            .orElse(null);

                    if(serviceProvider != null) {

                        for (RoleRef roleRef : serviceProvider.consumer.roleRefs) {

                            if (!spRoleRefIds.contains(roleRef.id)) {
                                spRoleRefIds.add(roleRef.id);
                            }

                        }
                    }

                }

            }

        }

        // Get roles
        List<Role> roles = microservice.getRolesByRoleIdsAndOrgTypeIds(spRoleRefIds, orgTypeIdsCovered);

        // Filter out by feature flag
        FilterRolesFromFeaturesWrapper wrapper = createFilterRolesFromFeaturesWrapper(roles, userProfile);
        List<Role> rolesFiltered = microservice.filterRolesFromFeatures(wrapper);

        return filterUserManagementRoles(rolesFiltered, userProfile);
    }

    private boolean isRootLevelUser(String profileOrgTypeId) {
        List<String> devAndRootTypes = Arrays.asList(OrganizationConstants.DEV_ORG_TYPE_ID, OrganizationConstants.ROOT_ORG_TYPE_ID);

        boolean isUpperLevelUser = false;
        for (String devOrRootType : devAndRootTypes) {
            if (profileOrgTypeId.equals(devOrRootType)) {
                isUpperLevelUser = true;
                break;
            }
        }

        return isUpperLevelUser;
    }

    private boolean isRootLevelUserWithAdminManagerRole(List<RoleRef> profileRoles, String profileOrgTypeId) {
        List<String> devAndRootTypes = Arrays.asList(OrganizationConstants.DEV_ORG_TYPE_ID, OrganizationConstants.ROOT_ORG_TYPE_ID);

        boolean isAdminManager = profileRoles.stream().anyMatch(roleRef -> roleRef.getId().equals(USER_ADMIN_MANAGER_ROLE_ID));
        if (!isAdminManager) {
            return false;
        }

        boolean isUpperLevelUser = false;
        for (String devOrRootType : devAndRootTypes) {
            if (profileOrgTypeId.equals(devOrRootType)) {
                isUpperLevelUser = true;
                break;
            }
        }

        return isUpperLevelUser;
    }

    private void setUpdatedBy(Role role) {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        role.updatedBy = currentUser.profile.getFullName();
    }

    public Role addRole(@QueryParam("roleId") String parentRoleId,
                        @QueryParam("childRoleId") String childRoleId) {
        return microservice.addRole(childRoleId, childRoleId);
    }

    public Role addRolePermission(@QueryParam("roleId") String roleId,
                                  @QueryParam("permissionId") String permissionId) {
        return microservice.addRolePermission(roleId, permissionId);
    }

    public Role activateRole(@NotNull @QueryParam("roleId") String roleId) {
        return microservice.activateRole(roleId);
    }

    public Role createRole(Role role) throws ObjectNotFoundException {
        return microservice.createRole(role);
    }

    public Role deactivateRole(@NotNull @QueryParam("roleId") String roleId) {
        return microservice.deactivateRole(roleId);
    }

    public List<Role> getAllRoles() {
        return microservice.getAllRoles();
    }

    public List<RoleRef> getAllRoleRefs() {
        return this.getAllRoles().stream().map(Role::getRef).collect(Collectors.toList());
    }

    public List<RoleRef> getCurrentUserRoleRefs() {
        List<Role> roles = getRolesFromRoleRefs(currentUserBT.getCurrentUser().profile.roleRefs);
        FilterRolesFromFeaturesWrapper wrapper = createFilterRolesFromFeaturesWrapper(roles, currentUserBT.getCurrentUser().profile);
        List<Role> filteredRoles = microservice.filterRolesFromFeatures(wrapper);
        return getRoleRefsFromRoles(filteredRoles);
    }

    public List<RoleRef> getCurrentUserAssignableRoleRefs() {
        List<Role> roles = getRolesFromRoleRefs(currentUserBT.getCurrentUser().profile.assignableRoleRefs);
        FilterRolesFromFeaturesWrapper wrapper = createFilterRolesFromFeaturesWrapper(roles, currentUserBT.getCurrentUser().profile);
        List<Role> filteredRoles = microservice.filterRolesFromFeatures(wrapper);
        return getRoleRefsFromRoles(filteredRoles);
    }

    public Boolean deleteRoleById(@NotNull String id) {
        return microservice.deleteRoleById(id);
        // TODO: Remove from role service
    }

    public Boolean doesRoleExistByName(@QueryParam("roleName") String roleName) {
        return microservice.doesRoleExistByName(roleName);
    }

    public List<RoleFunctionalArea> getAllPermissions() {
        return microservice.getAllPermissions();
    }

    public List<Role> getGroupProfileAssignableRoles(GroupInvitation groupInvitation) {
        UserProfile templateProfile = buildProfileFromGroupInvitation(groupInvitation);
        return getAndFilterAssignableRoles(templateProfile);
    }

    public List<Role> getGroupProfileRoles(@NotNull GroupInvitation groupInvitation) {
        UserProfile templateProfile = buildProfileFromGroupInvitation(groupInvitation);
        return getAndFilterRoles(templateProfile, groupInvitation.userProfileTemplate.nodeTypeRef.id);
    }

    public List<Role> getProfileAssignableRoles(@NotNull UserProfile userProfile) {
        return getAndFilterAssignableRoles(userProfile);
    }

    public List<Role> getProfileRoles(@NotNull UserProfile userProfile) {
        return getAndFilterRoles(userProfile, userProfile.nodeTypeRef.id);
    }

    public Role getRoleById(@QueryParam("roleId") String roleId) {
        return microservice.getRoleById(roleId);
    }

    public List<FunctionalArea> getRoleFunctionalAreaConfigs() {
        return microservice.getRoleFunctionalAreaConfigs();
    }

    public List<Role> getRoles(String... roleIds) throws ObjectNotFoundException {
        return microservice.getRoles(roleIds);
    }

    public List<Role> getRolesByFunctionalArea(@QueryParam("functionalArea") String functionalArea) {
        return microservice.getRolesByFunctionalArea(functionalArea);
    }

    public List<Role> getRolesByNodeIds(@NotNull ScopeQuery scopeNode) {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        if (currentUser == null || currentUser.profile == null) {
            throw new ApplicationException("No permission for this operation.");
        }

        if (scopeNode.scopeList.isEmpty()) {
            return new ArrayList<>();
        }

        String firstOrgId = scopeNode.scopeList.get(0);

        List<String> roleIds;

        if (Objects.nonNull(scopeNode.userProfileRoleRefs) && !scopeNode.userProfileRoleRefs.isEmpty()) {
            roleIds = scopeNode.userProfileRoleRefs.stream().map(RoleRef::getId).collect(Collectors.toList());
        } else {
            roleIds = organizationService.getOrganizationRoleIds(scopeNode.scopeList);
        }

        OrganizationTypeRef organizationTypeRef = organizationService.getOrganizationTypeRef(firstOrgId);

        Map<String, FeatureFlag> activeFeatureFlagMap = userService.getFeatureFlagMap();

        OrganizationRef organizationRef = organizationService.getOrganizationRefById(firstOrgId);

        List<Role> roleList = microservice.getRolesByRoleIdsAndOrgType(roleIds, organizationTypeRef.id, organizationRef);

        FilterRolesFromFeaturesWrapper wrapper = new FilterRolesFromFeaturesWrapper();
        wrapper.roleList = roleList;
        wrapper.currentUser = currentUser;
        wrapper.featureFlagMap = activeFeatureFlagMap;

        if (scopeNode.userProfile != null) {
            wrapper.userProfile = scopeNode.userProfile;
        }

        return microservice.filterRolesFromFeatures(wrapper);
    }

    public List<Role> getRolesByNodeType(@QueryParam("nodeTypeQ") String nodeTypeQ) {
        return microservice.getRolesByNodeType(nodeTypeQ);
    }

    public List<Role> getRolesForPermission(@NotNull @QueryParam("permissionId") String permissionId) {
        return microservice.getRolesForPermission(permissionId);
    }

    public Boolean removePermissionFromRoles(@QueryParam("permissionId") String permissionId) {
        return microservice.removePermissionFromRoles(permissionId);
    }

    public Role renameRole(String roleId, String newRoleName) {
        return microservice.renameRole(roleId, newRoleName);
    }

    public Role removeRolePermission(@QueryParam("roleId") String roleId,
                                     @QueryParam("permissionId") String permissionId) {
        return microservice.removeRolePermission(roleId, permissionId);
    }

    public Role saveRoleData(Role role) {
        setUpdatedBy(role);
        return microservice.saveRoleData(role);
    }

    public Role saveRolePermissions(Role role) throws ObjectNotFoundException {
        setUpdatedBy(role);
        return microservice.saveRolePermissions(role);
    }

    public Role toggleRoleEnabled(String roleId) {
        return microservice.toggleRoleEnabled(roleId);
    }

}
