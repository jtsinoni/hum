package logicole.gateway.services.finance;

import io.swagger.annotations.Api;
import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.validation.FinanceValidation;
import logicole.common.datamodels.finance.validation.FinanceValidationGroup;
import logicole.common.datamodels.finance.validation.FinanceValidationResponse;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"financeValidation"})
@ApplicationScoped
@Path("/financeValidation")
public class FinanceValidationRestApi extends ExternalRestApi<FinanceValidationService> {

    @GET
    @Path("/findGroupById")
    public FinanceValidationGroup findGroupById(@QueryParam("id") String id) {
        return service.findGroupById(id);
    }

    @GET
    @Path("/findAllFinanceValidationGroups")
    public List<FinanceValidationGroup> findAllFinanceValidationGroups() {
        return service.findAllFinanceValidationGroups();
    }

    @GET
    @Path("/findAllFinanceValidation")
    public List<FinanceValidation> findAllFinanceValidation() {
        return service.findAllFinanceValidation();
    }

    @POST
    @Path("/addFinanceValidationToGroup")
    public FinanceValidationGroup addFinanceValidationToGroup(
            @QueryParam("groupId") String groupId, String validationId) {
        return service.addFinanceValidationToGroup(groupId, validationId);
    }

    @POST
    @Path("/removeFinanceValidationToGroup")
    public FinanceValidationGroup removeFinanceValidationToGroup(
            @QueryParam("groupId") String groupId, String validationId) {
        return service.removeFinanceValidationToGroup(groupId, validationId);
    }

    @POST
    @Path("/createGroup")
    public FinanceValidationGroup createGroup(FinanceValidationGroup group) {
        return service.createGroup(group);
    }

    @POST
    @Path("/createValidation")
    public FinanceValidation createValidation(FinanceValidation item) {
        return service.createValidation(item);
    }

    @POST
    @Path("/validateRequest")
    public List<String> validateRequest(CommonFinanceRequest request) {
        return service.validateRequest(request);
    }

    @POST
    @Path("/validateAllFundingNodeTargets")
    public FinanceValidationResponse validateAllFundingNodeTargets(FundingNode fundingNode) {
        return service.validateAllFundingNodeTargets(fundingNode);
    }

}