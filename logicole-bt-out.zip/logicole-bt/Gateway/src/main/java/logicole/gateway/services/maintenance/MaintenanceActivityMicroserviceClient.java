package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.IMaintenanceActivityMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class MaintenanceActivityMicroserviceClient extends MicroserviceClient<IMaintenanceActivityMicroserviceApi> {

    public MaintenanceActivityMicroserviceClient() {
        super(IMaintenanceActivityMicroserviceApi.class, "logicole-maintenance");
    }

    @Produces
    public IMaintenanceActivityMicroserviceApi getIMaintenanceActivityMicroserviceApi() {
        return createClient();
    }

}
