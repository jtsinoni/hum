package logicole.gateway.services.product;

import logicole.apis.product.IOfferMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class OfferMicroserviceClient extends MicroserviceClient<IOfferMicroserviceApi> {
    public OfferMicroserviceClient(){
        super(IOfferMicroserviceApi.class, "logicole-product");
    }

    @Produces
    public IOfferMicroserviceApi getIOfferMicroserviceApi() {
        return createClient();
    }

}
