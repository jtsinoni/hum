package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetLookupMicroserviceApi;
import logicole.common.datamodels.asset.lookup.AuthoritativeSpaceEquipmentCriteria;
import logicole.common.datamodels.asset.lookup.MilitaryStandard1691;
import logicole.common.datamodels.asset.lookup.MilitaryStandard1691Summary;
import logicole.common.datamodels.asset.lookup.SpaceEquipmentCriteria;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import java.util.List;

@ApplicationScoped
public class AssetLookupService extends BaseGatewayService<IAssetLookupMicroserviceApi> {

    public AssetLookupService() {
        super("Asset");
    }

    public List<AuthoritativeSpaceEquipmentCriteria> getAllAuthoritativeSpaceEquipmentCriteria() {
        return microservice.getAllAuthoritativeSpaceEquipmentCriteria();
    }

    public List<SpaceEquipmentCriteria> getAllSpaceEquipmentCriteria() {
        UserProfile currentUser = currentUserBT.getCurrentUser().profile;
        return microservice.getAllSpaceEquipmentCriteria(currentUser.currentNodeRef);
    }

    public List<SpaceEquipmentCriteria> getSpaceEquipmentRooms() {
        return microservice.getSpaceEquipmentRooms();
    }

    public SpaceEquipmentCriteria addSpaceEquipmentCriteria(SpaceEquipmentCriteria sec) {
        SpaceEquipmentCriteria foundSpaceEquipmentCriteria = microservice.getSpaceEquipmentCriteriaByJsnAndRoomCode(sec.jsn, sec.roomCode);
        if (foundSpaceEquipmentCriteria == null) {
            sec.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            return microservice.addSpaceEquipmentCriteria(sec);
        } else {
            throw new ApplicationException("Space Equipment Criteria record already exists. Please update Quantity on existing record.");
        }
    }

    public SpaceEquipmentCriteria updateSpaceEquipmentCriteria(SpaceEquipmentCriteria sec) {
        if (!sec.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.currentNodeRef.getId())) {
            throw new ApplicationException("Does not have the privileges to update the Space Equipment Criteria record.");
        } else {
            SpaceEquipmentCriteria foundSpaceEquipmentCriteria = microservice.getSpaceEquipmentCriteriaById(sec.getId());
            if (foundSpaceEquipmentCriteria == null) {
                throw new ApplicationException("Space Equipment Criteria does not exist");
            } else {
                if (!(foundSpaceEquipmentCriteria.jsn.equalsIgnoreCase(sec.jsn) && foundSpaceEquipmentCriteria.roomCode.equalsIgnoreCase(sec.roomCode))
                        && microservice.getSpaceEquipmentCriteriaByJsnAndRoomCode(sec.jsn, sec.roomCode) != null) {
                    throw new ApplicationException("Space Equipment Criteria record already exists. Please update Quantity on existing record.");
                } else {
                    return microservice.updateSpaceEquipmentCriteria(sec);
                }
            }
        }
    }

    public void deleteSpaceEquipmentCriteria(String secId) {
        SpaceEquipmentCriteria foundSpaceEquipmentCriteria = microservice.getSpaceEquipmentCriteriaById(secId);
        if (foundSpaceEquipmentCriteria == null) {
            throw new ApplicationException("Space Equipment Criteria does not exist");
        } else {
            if (!foundSpaceEquipmentCriteria.managedByNodeRef.getId().equals(currentUserBT.getCurrentUser().profile.currentNodeRef.getId())) {
                throw new ApplicationException("Does not have the privileges to delete the Space Equipment Criteria record.");
            }
        }
        microservice.deleteSpaceEquipmentCriteria(secId);
    }

    public List<MilitaryStandard1691Summary> getAllMilitaryStandard1691() {
        return microservice.getAllMilitaryStandard1691();
    }

    public MilitaryStandard1691 getMilitaryStandard1691ById(@NotNull String id) {
        return microservice.getMilitaryStandard1691ById(id);
    }

    public MilitaryStandard1691 getMilitaryStandard1691ByJsn(@NotNull String jsn) {
        return microservice.getMilitaryStandard1691ByJsn(jsn);
    }
}
