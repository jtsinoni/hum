package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceDataMigrationMicroserviceApi;
import logicole.common.datamodels.finance.AuthorizedOrg;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.finance.FundingNode;
import logicole.common.datamodels.finance.FundingNodeChild;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.datamigration.CommodityCodeRefMigrationWrapper;
import logicole.common.datamodels.finance.datamigration.FundingNodeChildMigrationWrapper;
import logicole.common.datamodels.finance.datamigration.FundingNodeMigrationWrapper;
import logicole.common.datamodels.finance.datamigration.FundingSourceMigrationWrapper;
import logicole.common.datamodels.finance.fundingsource.EFundingSourceSubType;
import logicole.common.datamodels.finance.fundingsource.EFundingSourceType;
import logicole.common.datamodels.finance.fundingsource.FundingSource;
import logicole.common.datamodels.finance.fundingsource.FundingSourceRef;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.organization.EProviderType;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.organization.ProviderService;
import org.apache.commons.lang3.StringUtils;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class FinanceDataMigrationService extends BaseGatewayService<IFinanceDataMigrationMicroserviceApi> {
    @Inject
    protected OrganizationService organizationService;
    @Inject
    protected FinanceAdminService financeAdminService;

    @Inject
    protected ProviderService providerService;

    protected FinanceDataMigrationService() {
        super("FinanceDataMigration");
    }

    public FundingNode convertFundingNode(FundingNodeMigrationWrapper fundingNodeMigrationWrapper) {
        String nodeIdentifier = fundingNodeMigrationWrapper.fundingNode.fundingSourceRefs.get(0).owningOrg.nodeIdentifier;
        Organization org = organizationService.getOrganizationByOrganizationIdentifier(nodeIdentifier);

        FundingSourceRef fundingSourceRef = new FundingSourceRef();
        fundingSourceRef.type = EFundingSourceType.APPROPRIATION;
        fundingSourceRef.subType = EFundingSourceSubType.MEMORANDUM;
        fundingSourceRef.endDate = fundingNodeMigrationWrapper.fundingNode.expiredDate;
        fundingSourceRef.owningOrg = org.getRef();

        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(org.getId());
        fundingSourceRef.financialSystemRef = financialSystem.getRef();

        fundingNodeMigrationWrapper.fundingNode.fundingSourceRefs.set(0, fundingSourceRef);
        fundingNodeMigrationWrapper.fundingNode.managedByNodeRef = org.getRef();
        return microservice.convertFundingNode(fundingNodeMigrationWrapper);
    }

    public FundingNodeChild convertFundingNodeChild(FundingNodeChildMigrationWrapper childMigrationWrapper) {
        if (childMigrationWrapper.child == null || StringUtils.isBlank(childMigrationWrapper.migrationKey)) {
            throw new ApplicationException("FM Funding node child conversion data is missing");
        }

        FundingNode parent = microservice.getFundingNodeByMigrationKey(childMigrationWrapper.migrationKey);
        if (parent == null) {
            throw new ApplicationException("Unable to locate parent node associated with migration key: " + childMigrationWrapper.migrationKey);
        }

        OrganizationRef fmOrg = providerService.getProviderData(parent.managedByNodeRef.id,
                EProviderType.FM_ORGANIZATION_REFERENCE_PROVIDER.toString());

        childMigrationWrapper.child.authorizedOrgs.add(new AuthorizedOrg(fmOrg, ""));
        childMigrationWrapper.parent = parent;

        return microservice.convertFundingNodeChild(childMigrationWrapper);
    }

    public FundingSource convertFundingSource(FundingSourceMigrationWrapper fundingSourceMigrationWrapper) {
        String nodeIdentifier = fundingSourceMigrationWrapper.fundingSource.owningOrg.nodeIdentifier;
        Organization org = organizationService.getOrganizationByOrganizationIdentifier(nodeIdentifier);

        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(org.getId());
        fundingSourceMigrationWrapper.fundingSource.financialSystemRef = financialSystem.getRef();

        fundingSourceMigrationWrapper.fundingSource.owningOrg = org.getRef();
        fundingSourceMigrationWrapper.fundingSource.managedByNodeRef = org.getRef();
        return microservice.convertFundingSource(fundingSourceMigrationWrapper);
    }

    public FundingNodeRef getExpenseCenterByMigrationId(String migrationKey) {
        return microservice.getExpenseCenterByMigrationId(migrationKey);
    }

    public FundingNodeRef getProjectCenterByMigrationId(String migrationKey) {
        FundingNode node = microservice.getFundingNodeByMigrationKey(migrationKey);
        if (node == null) {
            throw new ApplicationException("Funding node not found with migration key " + migrationKey);
        }
        return node.getRef();
    }

    public CommodityCodeRef getCommodityCodeRef(CommodityCodeRefMigrationWrapper commodityCodeRefMigrationWrapper) {
        FinancialSystem financialSystem = financeAdminService.
                getFinancialSystemByNodeId(commodityCodeRefMigrationWrapper.organizationId);

        return microservice.getCommodityCodeRef(financialSystem.getId(), commodityCodeRefMigrationWrapper);
    }
}
