package logicole.gateway.services.receipt;

import logicole.apis.receipt.IReceiptDetailMicroserviceApi;
import logicole.apis.receipt.IReceiptMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class ReceiptDetailMicroserviceClient extends MicroserviceClient<IReceiptDetailMicroserviceApi> {
    public ReceiptDetailMicroserviceClient(){
        super(IReceiptDetailMicroserviceApi.class, "logicole-receipt");
    }

    @Produces
    public IReceiptDetailMicroserviceApi getIReceiptDetailMicroserviceApi() {
        return createClient();
    }

}
