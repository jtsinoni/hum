package logicole.gateway.services.spacemanagement;

import io.swagger.annotations.Api;
import logicole.common.datamodels.space.lookupdata.*;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"SpaceManagement"})
@ApplicationScoped
@Path("/spacelookup")
public class SpaceLookupRestApi extends ExternalRestApi<SpaceLookupService> {

    @Inject
    private SpaceLookupService lookupService;

    @GET
    @Path("/getAttributeTypeById")
    public AttributeType getAttributeTypeById(@QueryParam("id") String id) {
        return service.getAttributeTypeById(id);
    }

    @GET
    @Path("/getAttributeTypeList")
    public List<String> getAttributeTypeList() {
        return service.getAttributeTypeList();
    }

    @GET
    @Path("/getAttributeTypeByType")
    public List<AttributeType> getAttributeTypeByType(@QueryParam("type") String type) {
        return service.getAttributeTypeByType(type);
    }

    @GET
    @Path("/getAllAttributeType")
    public List<AttributeType> getAllAttributeType() {
        return service.getAllAttributeType();
    }

    @POST
    @Path("/createNewAttributeType")
    public AttributeType createNewAttributeType(AttributeType attributeType) {
        return service.createNewAttributeType(attributeType);
    }

    @POST
    @Path("/saveAttributeType")
    public AttributeType saveAttributeType(AttributeType attributeType) {
        return service.saveAttributeType(attributeType);
    }

    @GET
    @Path("/deleteAttributeType")
    public boolean deleteAttributeType(@QueryParam("id") String id) {
        return service.deleteAttributeType(id);
    }

    @GET
    @Path("/getCleaningRequirementById")
    public CleaningRequirement getCleaningRequirementById(@QueryParam("id") String id) {
        return service.getCleaningRequirementById(id);
    }

    @POST
    @Path("/createNewCleaningRequirement")
    public CleaningRequirement createNewCleaningRequirement(CleaningRequirement cleaningRequirement) {
        return service.createNewCleaningRequirement(cleaningRequirement);
    }

    @POST
    @Path("/saveCleaningRequirement")
    public CleaningRequirement saveCleaningRequirement(CleaningRequirement cleaningRequirement) {
        return service.saveCleaningRequirement(cleaningRequirement);
    }

    @GET
    @Path("/deleteCleaningRequirement")
    public boolean deleteCleaningRequirement(@QueryParam("id") String id) {
        return service.deleteCleaningRequirement(id);
    }

    @GET
    @Path("/getAllCleaningRequirement")
    public List<CleaningRequirement> getAllCleaningRequirement() {
        return service.getAllCleaningRequirement();
    }

    @GET
    @Path("/getHazardTypeById")
    public HazardType getHazardTypeById(@QueryParam("id") String id) {
        return service.getHazardTypeById(id);
    }

    @GET
    @Path("/getAllHazardType")
    public List<HazardType> getAllHazardType() {
        return service.getAllHazardType();
    }

    @POST
    @Path("/createNewHazardType")
    public HazardType createNewHazardType(HazardType hazardType) {
        return service.createNewHazardType(hazardType);
    }

    @POST
    @Path("/saveHazardType")
    public HazardType saveHazardType(HazardType hazardType) {
        return service.saveHazardType(hazardType);
    }

    @GET
    @Path("/deleteHazardType")
    public boolean deleteHazardType(@QueryParam("id") String id) {
        return service.deleteHazardType(id);
    }

    @GET
    @Path("/getAllPhoneClass")
    public List<String> getAllPhoneClass() {
        return service.getAllPhoneClass();
    }

    @GET
    @Path("/getRoomTypeById")
    public SpaceType getSpaceTypeById(@QueryParam("id") String id) {
        return service.getRoomTypeById(id);
    }

    @GET
    @Path("/getRoomTypeBySubtypeCode")
    public SpaceType getRoomTypeBySubtypeCode(@QueryParam("subtypeCode") String subtypeCode) {
        return service.getRoomTypeBySubtypeCode(subtypeCode);
    }

    @GET
    @Path("/getAllRoomType")
    public List<SpaceType> getAllRoomType() {
        return service.getAllRoomType();
    }

    @POST
    @Path("/createNewRoomType")
    public SpaceType createNewRoomType(SpaceType spaceType) {
        return service.createNewRoomType(spaceType);
    }

    @POST
    @Path("/saveRoomType")
    public SpaceType saveRoomType(SpaceType spaceType) {
        return service.saveRoomType(spaceType);
    }

    @GET
    @Path("/deleteRoomType")
    public boolean deleteRoomType(@QueryParam("id") String id) {
        return service.deleteRoomType(id);
    }

    @GET
    @Path("/getAllSpaceMeasurementUnits")
    public List<String> getAllSpaceMeasurementUnits() {
        return service.getAllSpaceMeasurementUnits();
    }

    @GET
    @Path("/getAllSpaceFillPatterns")
    public List<String> getAllSpaceFillPatterns() {
        return service.getAllSpaceFillPatterns();
    }

    @GET
    @Path("/getAllZoneType")
    public List<ZoneType> getAllZoneType() {
        return service.getAllZoneType();
    }

    @GET
    @Path("/getZoneTypeById")
    public ZoneType getZoneTypeById(@QueryParam("id") String id) {
        return service.getZoneTypeById(id);
    }

    @POST
    @Path("/createNewZoneType")
    public ZoneType createNewZoneType(ZoneType zoneType) {
        return service.createNewZoneType(zoneType);
    }

    @POST
    @Path("/saveZoneType")
    public ZoneType saveZoneType(ZoneType zoneType) {
        return service.saveZoneType(zoneType);
    }

    @GET
    @Path("/deleteZoneType")
    public boolean deleteZoneType(@QueryParam("id") String id) {
        return service.deleteZoneType(id);
    }

    @GET
    @Path("/getSpaceCodes")
    public List<SpaceCode> getSpaceCodes() {
        return service.getSpaceCodes();
    }

}
