package logicole.gateway.services.abi;

import logicole.common.datamodels.abi.item.ItemTaskRequest;
import logicole.gateway.common.DataReferenceMDB;
import logicole.common.datamodels.abi.staging.StagingRequest;
import logicole.common.general.event.BusinessEvent;
import logicole.common.general.util.JSONUtil;
import logicole.gateway.services.abi.item.ItemCatalogImportDataService;
import logicole.gateway.services.abi.item.ItemTaskRequestService;
import logicole.gateway.services.abi.item.ItemUploadService;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.inject.Inject;
import javax.jms.Destination;
import javax.jms.MessageListener;
import java.io.IOException;
import java.util.Objects;

@MessageDriven(name = "StagingRequestQueueMDB", activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "java:/queue/ABiStagingRequestBroker"),
        @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
        @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge")})

public class ABiStagingRequestQueueMDB extends DataReferenceMDB implements MessageListener {

    @Inject
    private AbiStagingService abiStagingService;
    @Inject
    private ItemUploadService itemUploadService;
    @Inject
    private ItemCatalogImportDataService itemCatalogImportDataService;

    @Inject
    private JSONUtil jsonUtil;

    @Override
    protected void processBusinessEvent(BusinessEvent businessEvent, Destination jmsReplyTo) {
        try {
            if ((Objects.nonNull(businessEvent.parameterJson)) && (businessEvent.parameterJson.startsWith(ItemTaskRequestService.ITEM_TASK_MESSAGE))) {
                String jsonStr = businessEvent.parameterJson;
                int prefixLength = ItemTaskRequestService.ITEM_TASK_MESSAGE.length() + 1;
                jsonStr = jsonStr.substring(prefixLength);
                ItemTaskRequest request = jsonUtil.deserialize(jsonStr, ItemTaskRequest.class);
                processItemTaskRequest(request);
            } else {
                StagingRequest stagingRequest = jsonUtil.deserialize(businessEvent.parameterJson, StagingRequest.class);
                abiStagingService.processAllStagingRequest(stagingRequest);
            }
        } catch (Exception  e) {
            throw new RuntimeException("Could not process ABiStaging Request", e);
        }
    }

    private void processItemTaskRequest(ItemTaskRequest request) {
        if (request.requestType.equalsIgnoreCase(ItemUploadService.UPLOAD_CATALOG_DATA)) {
            itemUploadService.processUploadRequest(request);
        } else if (request.requestType.equalsIgnoreCase(ItemCatalogImportDataService.PROCESS_CATALOG_IMPORT_DATA)) {
            itemCatalogImportDataService.processCatalogImportDataRequest(request);
        }
    }
}
