package logicole.gateway.common;

import logicole.common.api.IMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.HealthCheckResult;
import logicole.common.datamodels.HealthCheckResult.EHealthStatus;
import logicole.common.datamodels.VersionInformation;
import logicole.common.datamodels.businessevent.BusinessEventHistory;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.system.InitializationRoutineRef;
import logicole.common.datamodels.system.InitializationRoutineResult;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.logging.ILogger;
import logicole.common.general.util.IntrospectionUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.common.servers.history.BusinessMethodExecutioner;
import logicole.common.servers.history.MessageFactory;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.Initialized;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.servlet.ServletContext;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public abstract class BaseGatewayService<T extends IMicroserviceApi> {

    private final String name;
    private static final String API_TYPE = "Gateway Manager";

    private HashMap<String, Function<InitializationRoutineRef, InitializationRoutineResult>> initializationRoutineMap = new HashMap<>();

    @Inject
    protected ILogger logger;
    @Inject
    protected T microservice;
    @Inject
    protected CurrentUserBT currentUserBT;
    @Inject
    private MessageFactory logMessageFactory;
    @Inject
    protected EndpointAccessFilter endpointAccessFilter;
    @Inject
    private BusinessMethodExecutioner businessMethodExecutioner;

    // *** Don't add services here... Add them to the Services base class


    @Inject
    protected BaseGatewayService(String name) {
        this.name = name;
    }

    private void onInitialize(@Observes @Initialized(ApplicationScoped.class) ServletContext payload) {
        try {
            logger.debug("initializing BaseGatewayService {} - Begun", name);
            addInitializationRoutines();
            onInitialized();
            logger.debug("initializing BaseGatewayService {} - Complete", name);
        } catch (Exception e) {
            // Fortify Note: Not sure of the risk of removing this catch. The code doesn't seem to throw anything so
            //               the catch isn't, technically, necessary.
            logger.error(String.format("initializing BaseGatewayService %s - Error", name), e);

        }
    }

    protected void onInitialized(){
        // to be overloaded in derived classes for specific initialization needs
    }

    protected void addInitializationRoutines() {
        // intended to be overloaded in derived classes as needed
    }

    protected void addInitializationRoutine(String identifier, Function<InitializationRoutineRef, InitializationRoutineResult> function){
        initializationRoutineMap.put(identifier, function);
    }

    @AroundInvoke
    public Object logBusinessMethods(InvocationContext ctx) throws Exception {
        return businessMethodExecutioner.execute(BusinessMethodExecutioner.ETier.Gateway, ctx, endpointAccessFilter, null);
    }

    private String buildUserMessage(InvocationContext ctx) {
        Class<?> targetClass = ctx.getTarget().getClass();
        Method targetMethod = ctx.getMethod();
        String methodName = targetMethod.getName();
        String className = IntrospectionUtil.getClassName(targetClass);
        String endpointName = className + "." + methodName;
        return logMessageFactory.getUserMessage(endpointName, true, ctx);
    }


    public HealthCheckResult checkHealth() {

        HealthCheckResult result = createHealthCheckResult(EHealthStatus.Good);

        try {
            if (Objects.isNull(microservice)) {
                logger.error("The 'microservice' in checkHealth is null for BaseGatewayService " + this.name);
            } else {
                HealthCheckResult serverHealthCheck = microservice.checkHealth();
                if (Objects.isNull(serverHealthCheck)) {
                    logger.error("The 'serverHealthCheck' variable in checkHealth is null for BaseGatewayService " + this.name);
                } else {
                    if (Objects.isNull(serverHealthCheck.overallResult)) {
                        logger.error("The 'serverHealthCheck.overallResult' variable in checkHealth is null for BaseGatewayService " + this.name);
                    } else {
                        if (serverHealthCheck.overallResult == EHealthStatus.Failed) {
                            result.overallResult = EHealthStatus.Failed;
                        }
                    }
                }
                result.nestedHealthChecks.add(serverHealthCheck);
            }
        } catch (Exception ex) {
            result = new HealthCheckResult(name, API_TYPE, EHealthStatus.Skipped, EHealthStatus.Skipped);
            logger.error("Error running health check for: {}. {}", name, ex);
        }
        return result;
    }

    public VersionInformation getMicroserviceVersionInformation() throws IOException {
        return microservice.getVersionInformation();
    }

    public String getName() {
        return name;
    }

    protected HealthCheckResult createHealthCheckResult(EHealthStatus healthCheckStatus) {
        return new HealthCheckResult(name, API_TYPE, healthCheckStatus, healthCheckStatus);
    }

    public InitializationRoutineResult executeInitializationRoutine(InitializationRoutineRef initializationRoutineRef) {
        InitializationRoutineResult result = new InitializationRoutineResult();
        Function<InitializationRoutineRef, InitializationRoutineResult> initializationFunction = initializationRoutineMap.get(initializationRoutineRef.identifier);
        if (initializationFunction != null) {
            result = initializationFunction.apply(initializationRoutineRef);
        }
        return result;
    }

    public void processDataReferenceUpdate(DataReferenceUpdate dataReferenceUpdate) {
        microservice.processDataReferenceUpdate(dataReferenceUpdate);
    }

    public List<BusinessEventHistory> searchBusinessEventHistory(String searchString) {
        return microservice.searchBusinessEventHistory(searchString);
    }

    public List<BusinessEventHistory> findByReferencObjectId(String id) {
        return microservice.findByReferenceObjectId(id);
    }

    public BusinessEventHistory getBusinessEventById(@NotNull String id) {
        return microservice.getBusinessEventById(id);
    }

    public SearchResult<BusinessEventHistory> getTransactionHistorySearchResults(SearchInput searchInput) {
        if (StringUtil.isEmptyOrNull(searchInput.searchText) || searchInput.searchText.trim().length() < 3) {
            throw new ApplicationException("Search criteria must be at least 3 characters");
        }

        ESearchEngine searchEngine = microservice.getSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported at this time.");
        }

        return microservice.getTransactionHistorySearchResults(searchInput);
    }

}
