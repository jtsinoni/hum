package logicole.gateway.services.inventory;

import logicole.apis.inventory.IPlanningMicroserviceApi;
import logicole.common.datamodels.inventory.*;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import javax.inject.Inject;

@ApplicationScoped
public class PlanningService extends BaseGatewayService<IPlanningMicroserviceApi> {

    @Inject
    protected InventoryService inventoryService;
    @Inject
    protected LocationService locationService;

    public PlanningService() {
        super("Planning");
    }

    public List<InventoryPlanning> getRecommendedLevelChanges(String inventorySystemRefId) {
        return microservice.getRecommendedLevelChanges(inventorySystemRefId);
    }

    public InventoryPlanning acceptLevelChange(String inventoryRecordId, String locationId) {
        return microservice.acceptLevelChange(inventoryRecordId, locationId);
    }

    public InventoryPlanning rejectLevelChange(String inventoryRecordId, String locationId) {
        return microservice.rejectLevelChange(inventoryRecordId, locationId);
    }

    public InventoryPlanning updateDemand(String inventoryRecordId,
                                        String itemLocationIdentifier,
                                        Date demandDate,
                                        Integer demandQuantity) {
        return microservice.updateDemand(inventoryRecordId, itemLocationIdentifier, demandDate, demandQuantity);
    }

    public InventoryPlanning updateLeadTime(String inventoryRecordId, String itemLocationId, Date dueinDate) {
        return microservice.updateLeadTime(inventoryRecordId, itemLocationId, dueinDate);
    }

    public double computeAverageLeadTime(String inventoryRecordId, String locationId) {
        return microservice.computeAverageLeadTime(inventoryRecordId, locationId);
    }

    public double computeDailyDemandRate(InventoryPlanning planning) {
        return microservice.computeDailyDemandRate(planning);
    }

    public long calculateLevelQuantity(String inventoryRecordId,
                                       String locationId,
                                       boolean calculateForLog) {
        return microservice.calculateLevelQuantity(inventoryRecordId, locationId, calculateForLog);
    }

    public long calculateReorderQuantity(String inventoryRecordId, String locationId, boolean calculateForLog) {
        return microservice.calculateReorderQuantity(inventoryRecordId, locationId, calculateForLog);
    }

    public InventoryPlanning updateRecommendedLevel(String inventoryRecordId, String locationId) {
        return microservice.updateRecommendedLevel(inventoryRecordId, locationId);
    }

    public InventoryPlanning createInventoryPlanning(InventoryPlanning inventoryPlanning) {
        return microservice.createInventoryPlanning(inventoryPlanning);
    }

    public List<InventoryPlanning> getInventoryPlanningByRecordId(String inventoryRecordId) {
        return microservice.getInventoryPlanningByRecordId(inventoryRecordId);
    }

    public InventoryPlanning getInventoryPlanningByRecordIdAndItemLocId(String inventoryRecordId,
                                                                        String itemLocationIdentifier) {
        return microservice.getInventoryPlanningByRecordIdAndItemLocId(inventoryRecordId, itemLocationIdentifier);
    }

    public List<InventoryPlanning> getInventoryPlanningByInventorySystemRefId(String inventorySystemId) {
        return microservice.getInventoryPlanningByInventorySystemRefId(inventorySystemId);
    }

    public InventoryPlanning updatePlanningRecord(InventoryPlanning planningRecordToUpdate) {
        return microservice.updatePlanningRecord(planningRecordToUpdate);
    }

    public boolean deletePlanningRecord(String id) {
        return microservice.deletePlanningRecord(id);
    }

    public InventoryPlanning getInventoryPlanningById(String inventoryPlanningId) {
        return microservice.getInventoryPlanningById(inventoryPlanningId);
    }

    public InventoryPlanning saveDemandPlanningInfo(String planningId, InventoryDemand updatedDemand) {
        return microservice.saveDemandPlanningInfo(planningId, updatedDemand);
    }

    public InventoryPlanning savePipelineInfo(InventoryPlanning planningRecordToUpdate) {
        return microservice.savePipelineInfo(planningRecordToUpdate);
    }

    public InventoryPlanning addPipelineInfo(String planningId, InventoryPipeline pipelineInfo) {
        return microservice.addPipelineInfo(planningId, pipelineInfo);
    }

    public InventoryPlanning createOrUpdatePlanningRecord(String recordId, String newItemLocationIdentifier,
                                                          InventoryPlanning planningRecord) {
        InventoryRecord record = inventoryService.getInventoryRecordById(recordId);
        InventorySystem system =  locationService.getInventorySystemById(record.inventorySystemRef.getId());
        InventoryPlanning updatedPlanning = new InventoryPlanning();
        if (system != null) {
            if (system.inventoryPlanningConfiguration.equalsIgnoreCase("Location")) {
                planningRecord.itemLocationIdentifiersList = new ArrayList<>();
                planningRecord.itemLocationIdentifiersList.add(newItemLocationIdentifier);
                planningRecord.inventoryRecordRef = new InventoryRecordRef();
                planningRecord.inventoryRecordRef.id = record.getId();
                planningRecord.inventoryRecordRef.recordStatus = record.recordStatus;
                planningRecord.inventoryRecordRef.inventorySystemRef = record.inventorySystemRef;
                updatedPlanning = createInventoryPlanning(planningRecord);

            } else if (system.inventoryPlanningConfiguration.equalsIgnoreCase("Item")) {
                List<InventoryPlanning> updatePlanningRecord = getInventoryPlanningByRecordId(record.getId());
                if (!updatePlanningRecord.isEmpty()) {
                    updatePlanningRecord.get(0).itemLocationIdentifiersList.add(newItemLocationIdentifier);
                    updatedPlanning = updatePlanningRecord(updatePlanningRecord.get(0));
                } else {
                    InventoryPlanning newRecord = new InventoryPlanning();
                    newRecord.itemLocationIdentifiersList = new ArrayList<>();
                    for (ItemLocation loc : record.itemLocations) {
                        newRecord.itemLocationIdentifiersList.add(loc.itemLocationIdentifier);
                    }
                    newRecord.inventoryRecordRef = new InventoryRecordRef();
                    newRecord.inventoryRecordRef.inventorySystemRef = record.inventorySystemRef;
                    newRecord.inventoryRecordRef.recordStatus = record.recordStatus;
                    newRecord.inventoryRecordRef.id = record.getId();
                    updatedPlanning = createInventoryPlanning(newRecord);

                }

            }
        }
        return updatedPlanning;
    }

    public boolean hasReorderOrLevel(String locationId, List<InventoryRecord> inventoryRecords) {
        boolean hasReorderOrLevel = false;
        List<InventoryPlanning> planningList = new ArrayList<>();
        for (InventoryRecord inventoryRecord: inventoryRecords) {
           for (ItemLocation location : inventoryRecord.itemLocations) {
               if (location.locationRef.id.equalsIgnoreCase(locationId)) {
                   InventoryPlanning planning = getInventoryPlanningByRecordIdAndItemLocId(inventoryRecord.getId(),
                           location.itemLocationIdentifier);
                   planningList.add(planning);
               }
           }
        }

        if (!planningList.isEmpty()) {
            for (InventoryPlanning planningRec : planningList) {
                if (planningRec.currentReorder > 0 || planningRec.currentLevel > 0) {
                    hasReorderOrLevel = true;
                    break;
                }
            }
        }

        return hasReorderOrLevel;
    }

}
