package logicole.gateway.services.inventory;

import logicole.apis.inventory.ITransportationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class TransportationMicroserviceClient extends MicroserviceClient<ITransportationMicroserviceApi> {
    public TransportationMicroserviceClient() {
        super(ITransportationMicroserviceApi.class, "logicole-inventory");
    }

    @Produces
    public ITransportationMicroserviceApi getITransportationMicroserviceApi() {
        return createClient();
    }
}
