package logicole.gateway.services.spacemanagement;


import com.google.common.io.Files;
import logicole.apis.space.IFloorPlanConversionMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.filemanager.FileRef;
import logicole.common.datamodels.notification.ENotificationType;
import logicole.common.datamodels.notification.EmailMessage;
import logicole.common.datamodels.space.Floor;
import logicole.common.datamodels.space.staging.ConversionEmailWrapper;
import logicole.common.datamodels.space.staging.StagingFloorPlan;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.system.NotificationService;
import logicole.gateway.services.user.UserService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.ClientErrorException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import java.util.UUID;

@ApplicationScoped
public class FloorPlanConversionService extends BaseGatewayService<IFloorPlanConversionMicroserviceApi> {
    public FloorPlanConversionService() {
        super("FloorPlanConversion");
    }

    @Inject
    DrawingService drawingService;

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    NotificationService notificationService;

    @Inject
    SpaceManagementService spaceManagementService;

    @Inject
    UserService userService;

    protected void processFloorPlanConversion(String stagingFloorPlanId) throws ApplicationException, IOException {
        logger.info("[DXFConversion] processFloorPlanConversion: Starting.");
        File dxfFile = null;
        ConversionEmailWrapper emailWrapper = new ConversionEmailWrapper();
        try {
            String tempDirectory = System.getProperty("java.io.tmpdir");

            drawingService.appendStagingFloorPlanLogMessage(stagingFloorPlanId, "Received message to convert floor plan.");
            StagingFloorPlan stagingFloorPlan = drawingService.getStagingFloorPlanById(stagingFloorPlanId);
            String profileId = stagingFloorPlan.floorPlanToConvert.fileRef.uploadedBy;
            UserProfile messageRecipient = userService.getUserProfileById(profileId);
            emailWrapper.uploadedByUserEmail = messageRecipient.email;
            emailWrapper.uploadedByUserName = String.format("%s %s", messageRecipient.firstName, messageRecipient.lastName); 
            emailWrapper.uploadedDateTime = stagingFloorPlan.floorPlanToConvert.fileRef.uploadDateTime;
            emailWrapper.uploadedFileName = stagingFloorPlan.floorPlanToConvert.fileRef.uploadedFileName;

            byte[] fileContents = fileManagerAdminService.getFileContentsAsPrimitiveByte(stagingFloorPlan.floorPlanToConvert.fileRef.fileId);
            dxfFile = writeTempDxfFile(stagingFloorPlan.floorPlanToConvert.fileRef.uploadedFileName, tempDirectory, fileContents);

            drawingService.appendStagingFloorPlanLogMessage(stagingFloorPlanId, "Calling convertDxfToSvg().");
            logger.info("[DXFConversion] processFloorPlanConversion: calling microservice.convertDxfToSvg().");
            String svgFileName = microservice.convertDxfToSvg(tempDirectory, dxfFile.getAbsolutePath(), stagingFloorPlanId);

            if (svgFileName != null) {
                logger.info("[DXFConversion] processFloorPlanConversion: Conversion to SVG succeeded.");
                File svgFile = new File(svgFileName);
                stagingFloorPlan = drawingService.appendStagingFloorPlanLogMessage(stagingFloorPlanId, "Floor plan converted. Uploading file.");
                logger.info("[DXFConversion] processFloorPlanConversion: uploading SVG file.");
                Attachment svgAttachment = uploadConvertedFile(stagingFloorPlan, svgFile);
                stagingFloorPlan = drawingService.appendStagingFloorPlanLogMessage(stagingFloorPlanId, "File uploaded.  Updating floor record.");
                updateFloor(stagingFloorPlan, svgAttachment);
                stagingFloorPlan = drawingService.appendStagingFloorPlanLogMessage(stagingFloorPlanId, "Removing DXF File from file manager and temp SVG file.");
                fileManagerAdminService.removeFile(stagingFloorPlan.floorPlanToConvert.fileRef.fileId);

                boolean fileIsDeleted = svgFile.delete();
                if (Boolean.FALSE.equals(fileIsDeleted)) {
                    throw new IOException("Unable to delete the SVG file.");
                }

                emailWrapper.notificationType = ENotificationType.FLOOR_PLAN_CONVERSION_SUCCEEDED;
                emailWrapper.convertedFileName = svgFile.getName();

                logger.info("[DXFConversion] processFloorPlanConversion: Calling drawingService.findDiscrepanciesForFloor().");
                drawingService.findDiscrepanciesForFloor(stagingFloorPlan.floorRef.id, messageRecipient.getFullName());
            } else {
                logger.info("[DXFConversion] processFloorPlanConversion: Conversion to SVG failed.");
                emailWrapper.notificationType = ENotificationType.FLOOR_PLAN_CONVERSION_FAILED;
            }
            drawingService.appendStagingFloorPlanLogMessage(stagingFloorPlanId, "Deleting temp DXF file.");

            boolean fileIsDeleted = dxfFile.delete();
            if (Boolean.FALSE.equals(fileIsDeleted)) {
                throw new IOException("Unable to delete the SVG file.");
            }

            drawingService.appendStagingFloorPlanLogMessage(stagingFloorPlanId, "Conversion completed.");
            StagingFloorPlan sfp = drawingService.getStagingFloorPlanById(stagingFloorPlanId);
            if (sfp.floorRef != null) {
                drawingService.deleteStagingFloorPlan(stagingFloorPlanId);
            }
            logger.info("[DXFConversion] processFloorPlanConversion: Sending email message.");
            sendEmailNotification(emailWrapper);
        } catch (IOException | ApplicationException | InterruptedException | ClientErrorException ex) {
            String message = "ERROR in processFloorPlanConversion: " + ex.getMessage();
            drawingService.appendStagingFloorPlanLogMessage(stagingFloorPlanId, message);
            if (dxfFile != null) {
                boolean fileIsDeleted = dxfFile.delete();
                if (Boolean.FALSE.equals(fileIsDeleted)) {
                    throw new IOException(String.format("Unable to delete the SVG file. %s:", ex.getMessage()));
                }
            }
            emailWrapper.notificationType = ENotificationType.FLOOR_PLAN_CONVERSION_FAILED;
            sendEmailNotification(emailWrapper);
            throw new ApplicationException(message, ex);
        }
    }

    protected void sendEmailNotification(ConversionEmailWrapper emailWrapper) throws IOException {
        EmailMessage msg = microservice.getConversionEmailNotification(emailWrapper);
        notificationService.sendEmail(msg);
    }


    protected void updateFloor(StagingFloorPlan stagingFloorPlan, Attachment svgAttachment) {

        if ((stagingFloorPlan != null) && (svgAttachment != null)) {
            Floor floor = spaceManagementService.getFloorById(stagingFloorPlan.floorRef.id);
            Attachment previousDrawing = floor.drawing;
            floor.drawing = new Attachment();
            floor.drawing.fileRef = new FileRef();
            floor.drawing.fileRef.id = svgAttachment.fileRef.id;
            floor.drawing.fileRef.fileId = svgAttachment.fileRef.id;
            floor.drawing.fileRef.fileSize = svgAttachment.fileRef.fileSize;
            floor.drawing.fileRef.uploadDateTime = svgAttachment.fileRef.uploadDateTime;
            floor.drawing.fileRef.uploadedBy = svgAttachment.fileRef.uploadedBy;
            floor.drawing.fileRef.uploadedByName = svgAttachment.fileRef.uploadedByName;
            floor.drawing.fileRef.uploadedFileName = svgAttachment.fileRef.uploadedFileName;
            floor.drawing.fileRef.filePath = svgAttachment.fileRef.filePath;
            floor.drawing.section = null;
            floor.drawing.description = stagingFloorPlan.floorPlanToConvert.description;
            floor.unitOfMeasure = stagingFloorPlan.unitOfMeasure;

            floor.uploadedFileForConversion = null;
            floor.drawingName = convertDxfFilenameToSvgFilename(floor.drawing.fileRef.uploadedFileName);
            floor.conversionNotes.add(createConversionNote("Information", "Added drawing to floor.", floor));
            spaceManagementService.updateFloor(floor);

            if (previousDrawing != null) {
                try {
                    fileManagerAdminService.removeFile(previousDrawing.fileRef.id);
                } catch (IOException exception) {
                    throw new ApplicationException("Unable to remove the previous drawing.");
                }
            }
        }
    }

    protected Note createConversionNote(String section, String message, Floor floor) {
        Note conversionNote = new Note();
        conversionNote.dateCreated = new Date();
        conversionNote.dateModified = new Date();
        conversionNote.section = section;
        String userName = this.currentUserBT.getFullName();
        String[] parts = userName.split(",");
        conversionNote.firstName = (parts.length > 1) ? parts[1] : null;
        conversionNote.lastName = parts[0];
        conversionNote.userId = this.currentUserBT.getProfileId();
        conversionNote.noteId = UUID.randomUUID().toString();

        StringBuilder sb = new StringBuilder();
        sb.append(message);
        sb.append("  Floor: " + floor.identifier + " - " + floor.name);
        sb.append("  Drawing: " + floor.drawingName);

        conversionNote.noteText = sb.toString();
        return conversionNote;
    }

    protected String convertDxfFilenameToSvgFilename(String uploadedFileName) {
        String extension = Files.getFileExtension(uploadedFileName);
        String svgFilename = uploadedFileName.substring(0, uploadedFileName.length() - extension.length());
        svgFilename += "svg";
        return svgFilename;
    }

    protected Attachment uploadConvertedFile(StagingFloorPlan stagingFloorPlan, File convertedFile) throws IOException, ApplicationException {
        byte[] bytesArray = new byte[(int) convertedFile.length()];
        try (FileInputStream fileInputStream = new FileInputStream(convertedFile)) {
            int bytesRead = fileInputStream.read(bytesArray);
            if (bytesRead == -1) {
                throw new IOException(String.format("Unable to read file input stream for staging floor plan - %s"));
            }
        }
        FileManager managedSvgFile = fileManagerAdminService.uploadManaged(bytesArray, convertedFile.getName());
        Attachment svgAttachment = createConvertedAttachment(stagingFloorPlan.floorPlanToConvert, managedSvgFile);
        return svgAttachment;
    }

    protected Attachment createConvertedAttachment(Attachment floorPlanToConvert, FileManager managedSvgFile) {
        Attachment convertedAttachment = new Attachment();
        convertedAttachment.description = floorPlanToConvert.description;
        convertedAttachment.section = floorPlanToConvert.section;
        if (managedSvgFile != null) {
            convertedAttachment.fileRef = new FileRef();
            convertedAttachment.fileRef.uploadedByName = floorPlanToConvert.fileRef.uploadedByName;
            convertedAttachment.fileRef.uploadedBy = floorPlanToConvert.fileRef.uploadedBy;
            convertedAttachment.fileRef.id = managedSvgFile.getId();
            convertedAttachment.fileRef.filePath = managedSvgFile.filePath;
            convertedAttachment.fileRef.fileId = managedSvgFile.getId();
            convertedAttachment.fileRef.fileSize = managedSvgFile.fileSize;
            convertedAttachment.fileRef.uploadedFileName = managedSvgFile.uploadedFileName;
            convertedAttachment.fileRef.uploadDateTime = floorPlanToConvert.fileRef.uploadDateTime;
        }
        return convertedAttachment;
    }


    protected File writeTempDxfFile(String uploadedFileName, String tempDirectory, byte[] fileContents) throws IOException {

        File file = File.createTempFile(uploadedFileName + ".", ".tmp", new File(tempDirectory));

        try (OutputStream outputStream = new FileOutputStream(file)) {
            outputStream.write(fileContents);
            outputStream.flush();
            outputStream.close();
        }
        return file;

    }
}
