package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiTaskHistoryMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiTaskHistoryMicroserviceClient extends MicroserviceClient<IAbiTaskHistoryMicroserviceApi> {
    public AbiTaskHistoryMicroserviceClient() {
        super(IAbiTaskHistoryMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiTaskHistoryMicroserviceApi getABiTaskHistoryService() {
        return createClient();
    }
}

