package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiTaskHistoryMicroserviceApi;
import logicole.common.datamodels.abi.AbiTaskHistory;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.EDateTimeFormat;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.List;

@ApplicationScoped
public class AbiTaskHistoryService extends BaseGatewayService<IAbiTaskHistoryMicroserviceApi> {

    public AbiTaskHistoryService() {
        super("AbiStaging");
    }

    public List<AbiTaskHistory> getTaskHistoryByCategory(@QueryParam("category") String category) {
        return microservice.getTaskHistoryByCategory(category);
    }

    public long getTaskHistoryByRequestIdRecordCount(@QueryParam("requestId") String requestId) {
        return microservice.getTaskHistoryByRequestIdRecordCount(requestId);
    }

    public List<AbiTaskHistory> getTaskHistoryByRequestId(@QueryParam("requestId") String requestId) {
        return microservice.getTaskHistoryByRequestId(requestId);
    }

    public Response downloadTaskHistoryFile(@QueryParam("requestId") String requestId)
            throws IOException, ApplicationException {
        byte[] bytes = microservice.getTaskHistoryFileBytes(requestId);
        Response.ResponseBuilder responseBuilder = Response.ok()
                .header("Content-Disposition",
                        "attachment; filename=TaskHistory." + getDateTimeString() + ".log.tsv")
                .header("Content-Length", bytes.length)
                .header("Content-Encoding", StandardCharsets.UTF_8)
                .header("Access-Control-Expose-Headers", "Content-Disposition,Content-Type")
                .header("Content-Type", "text/tab-separated-values");

        responseBuilder.entity(bytes);
        return responseBuilder.build();
    }

    private String getDateTimeString() {
        return EDateTimeFormat.DATE_TIME_PATTERN_DDMMMYYY_WITH_MILLISECONDS.format(Calendar.getInstance().getTime());
    }
}
