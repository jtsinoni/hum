package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.CriticalItemCategoryRef;
import logicole.common.datamodels.abi.PackageUnit;
import logicole.common.datamodels.abi.staging.CommodityClass;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi/staging/lookup")
public class AbiStagingLookupRestApi extends ExternalRestApi<AbiStagingLookupService> {

    @GET
    @Path("/getEnterpriseProductIdentifierTypeList")
    public List<String> getEnterpriseProductIdentifierTypeList() {
        return service.getEnterpriseProductIdentifierTypeList();
    }

    @GET
    @Path("/getPackageUnitList")
    public List<PackageUnit> getPackageUnitList() {
        return service.getPackageUnitList();
    }

    @GET
    @Path("/getProductStatusList")
    public List<String> getProductStatusList() {
        return service.getProductStatusList();
    }

    @GET
    @Path("/getDisposableReusableList")
    public List<String> getDisposableReusableList() {
        return service.getDisposableReusableList();
    }

    @GET
    @Path("/getSterileNonSterileList")
    public List<String> getSterileNonSterileList() {
        return service.getSterileNonSterileList();
    }

    @GET
    @Path("/getHazardCodeList")
    public List<String> getHazardCodeList() {
        return service.getHazardCodeList();
    }

    @GET
    @Path("/getLatexCodeList")
    public List<String> getLatexCodeList() {
        return service.getLatexCodeList();
    }

    @GET
    @Path("/getGenderList")
    public List<String> getGenderList() {
        return service.getGenderList();
    }

    @GET
    @Path("/getBrandGenericList")
    public List<String> getBrandGenericList() {
        return service.getBrandGenericList();
    }

    @GET
    @Path("/getDeaCodeList")
    public List<String> getDeaCodeList() {
        return service.getDeaCodeList();
    }

    @GET
    @Path("/getDosageFormList")
    public List<String> getDosageFormList() {
        return service.getDosageFormList();
    }

    @GET
    @Path("/getDrugCategoryCodeList")
    public List<String> getDrugCategoryCodeList() {
        return service.getDrugCategoryCodeList();
    }

    @GET
    @Path("/getDocumentTypeList")
    public List<String> getDocumentTypeList() {
        return service.getDocumentTypeList();
    }

    @GET
    @Path("/getCommodityTypeList")
    public List<String> getCommodityTypeList() {
        return service.getCommodityTypeList();
    }

    @GET
    @Path("/getCommodityClassList")
    public List<CommodityClass> getCommodityClassList(@QueryParam("militaryServiceCode") String militaryServiceCode){
        return service.getCommodityClassList(militaryServiceCode);
    }

    @GET
    @Path("/getGudidIdentifierTypeList")
    public List<String> getGudidIdentifierTypeList() {
        return service.getGudidIdentifierTypeList();
    }

    @GET
    @Path("/getNetContentTextList")
    public List<String> getNetContentTextList() {
        return service.getNetContentTextList();
    }

    @GET
    @Path("/getManufacturerTypeaheadList")
    public List<String> getManufacturerTypeaheadList() {
        return service.getManufacturerTypeaheadList();
    }

    @GET
    @Path("/getProductNounList")
    public List<String> getProductNounList() {
        return service.getProductNounList();
    }

    @GET
    @Path("/getProductTypeList")
    public List<String> getProductTypeList() {
        return service.getProductTypeList();
    }

    @GET
    @Path("/getCriticalItemCategoryList")
    public List<CriticalItemCategoryRef> getCriticalItemCategoryList() { return service.getCriticalItemCategoryList();
    }
}
