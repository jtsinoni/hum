package logicole.gateway.services.realpropertysection;

import io.swagger.annotations.*;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.classification.AssemblyCategoryRef;
import logicole.common.datamodels.asset.classification.FacilitySubsystemRef;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.AssetSummary;
import logicole.common.datamodels.asset.schedule.Schedule;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.BulkUpdateResult;
import logicole.common.datamodels.general.customfield.CustomFieldValue;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.realpropertyproject.Requirement;
import logicole.common.datamodels.realpropertyproject.project.RealPropertyProject;
import logicole.common.datamodels.realpropertysection.*;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtype;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeHierarchy;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeRef;
import logicole.common.datamodels.space.Floor;
import logicole.common.datamodels.system.TagRef;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Api(tags = {"RealPropertySection"})
@ApplicationScoped
@Path("/section")
public class SectionRestApi extends ExternalRestApi<SectionService> {

    @Inject
    private MultiPartFormUtil uploadUtil;

    @POST
    @Path("/createSection")
    public Section createSection(Section section) {
        return service.createSection(section);
    }

    @GET
    @Path("/getSectionById")
    public Section getSectionById(@QueryParam("id") String id) {
        return service.getSectionById(id);
    }

    @POST
    @Path("/getSectionReport")
    public List<SectionSummary> getSectionReport(SearchInput searchInput) throws ApplicationException {
        return service.getSectionReport(searchInput);
    }

    @POST
    @Path("/getSectionSearchResults")
    public SearchResult<SectionSummary> getSectionSearchResults(SearchInput searchInput) throws ApplicationException {
        return service.getSectionSearchResults(searchInput);
    }

    @POST
    @Path("/updateSectionHeader")
    public Section updateSectionHeader(SectionHeader sectionHeader) {
        return service.updateSectionHeader(sectionHeader);
    }

    @GET
    @Path("/deleteSection")
    public Boolean deleteSection(@QueryParam("id") String sectionId) {
        return service.deleteSection(sectionId);
    }

    @POST
    @Path("/getSectionsByIds")
    public List<Section> getSectionsByIds(List<SectionRef> sectionList) {
        return service.getSectionsByIds(sectionList);
    }

    @POST
    @Path("/getSectionSummariesByFacilityIds")
    public List<SectionSummary> getSectionSummariesByFacilityIds(List<String> facilityIds) {
        return service.getSectionSummariesByFacilityIds(facilityIds, "ALL");
    }

    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "Select a file to upload",
                    dataType = "java.io.File", name = "file",
                    paramType = "formData", required = true)
    })
    public FileManager uploadFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        byte[] content;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            InputStream inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new ApplicationException("Unable to upload file " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxSectionAttachmentSize();
        if (content.length > maxUploadSize) {
            throw new ApplicationException("File size exceeds max size of " + maxUploadSize + " bytes");
        }

        return service.uploadFile(content, uploadedFileName);
    }


    @POST
    @Path("/saveSectionAttachment")
    public Attachment saveSectionAttachment(@QueryParam("sectionId") String sectionId, Attachment attachment) {
        return service.saveSectionAttachment(sectionId, attachment);
    }

    @POST
    @Path("/removeSectionAttachment")
    public boolean removeSectionAttachment(@QueryParam("sectionId") String sectionId, String fileId) {
        return service.removeSectionAttachment(sectionId, fileId);
    }

    @GET
    @Path("/getMaxSectionAttachmentSize")
    public Integer getMaxSectionAttachmentSize() {
        return service.getMaxSectionAttachmentSize();
    }

    @POST
    @Path("/updateSectionAudit")
    public Section updateSectionAudit(SectionAudit sectionAudit) {
        return service.updateSectionAudit(sectionAudit);
    }

    @POST
    @Path("/updateSectionComments")
    public Section updateSectionComments(SectionComments sectionComments) {
        return service.updateSectionComments(sectionComments);
    }

    @POST
    @Path("/updateSectionData")
    public Section updateSectionData(SectionData sectionData) {
        return service.updateSectionData(sectionData);
    }

    @POST
    @Path("/saveNote")
    public Section saveNote(@QueryParam("id") String id, Note note) {
        return service.saveNote(id, note);
    }

    @GET
    @Path("/removeNote")
    public Section removeNote(@QueryParam("id") String id, @QueryParam("noteId") String noteId) {
        return service.removeNote(id, noteId);
    }

    @POST
    @Path("/updateSectionPaintInformation")
    public Section updateSectionPaintInformation(SectionPaintInformation sectionPaintInformation) {
        return service.updateSectionPaintInformation(sectionPaintInformation);
    }

    @GET
    @Path("/getAssemblyCategoriesBySectionId")
    public List<AssemblyCategoryRef> getAssemblyCategoriesBySectionId(@QueryParam("sectionId") String sectionId) {
        return service.getAssemblyCategoriesBySectionId(sectionId);
    }

    @GET
    @Path("/getFacilitySubsystemsByFacilitySystemId")
    public List<FacilitySubsystemRef> getFacilitySubsystemsByFacilitySystemId(
            @QueryParam("facilitySystemId") String facilitySystemId) {
        return service.getFacilitySubsystemsByFacilitySystemId(facilitySystemId);
    }

    @GET
    @Path("/getAssemblyCategoriesByFacilitySystemIdAndFacilitySubsystemId")
    public List<AssemblyCategoryRef> getAssemblyCategoriesByFacilitySystemIdAndFacilitySubsystemId(
            @QueryParam("facilitySystemId") String facilitySystemId,
            @QueryParam("facilitySubsystemId") String facilitySubsystemId) {
        return service.getAssemblyCategoriesByFacilitySystemIdAndFacilitySubsystemId(facilitySystemId, facilitySubsystemId);
    }

    @GET
    @Path("/getComponentSubtypesBySystemHierarchyIds")
    public List<ComponentSubtypeRef> getComponentSubtypesBySystemHierarchyIds(
            @QueryParam("facilitySystemId") String facilitySystemId,
            @QueryParam("facilitySubsystemId") String facilitySubsystemId,
            @QueryParam("assemblyCategoryId") String assemblyCategoryId) {
        return service.getComponentSubtypesBySystemHierarchyIds(facilitySystemId, facilitySubsystemId, assemblyCategoryId);
    }

    @POST
    @Path("/getComponentSubtypesForSectionAssemblyCategory")
    public List<ComponentSubtypeRef> getComponentSubtypesForSectionAssemblyCategory(@QueryParam("sectionId") String sectionId, AssemblyCategoryRef assemblyCategoryRef) {
        return service.getComponentSubtypesForSectionAssemblyCategory(sectionId, assemblyCategoryRef);
    }

    @POST
    @Path("/updateSectionSystemInformationAndClassification")
    public Section updateSectionSystemInformationAndClassification(SectionSystemInformationAndClassification sectionSystemInformationAndClassification) {
        return service.updateSectionSystemInformationAndClassification(sectionSystemInformationAndClassification);
    }

    @POST
    @Path("/getAssetsById")
    public List<AssetSummary> getAssetsById(List<AssetRef> assetList) {
        return service.getAssetsById(assetList);
    }

    @GET
    @Path("/getRpeAssetsByFacilityId")
    public List<AssetSummary> getRpeAssetsByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getRpeAssetsByFacilityId(facilityId);
    }

    @GET
    @Path("/getRpeAssetsForSections")
    public List<AssetSummary> getRpeAssetsForSections(@QueryParam("sectionId") String sectionId, String facilityId) {
        return service.getRpeAssetsForSections(sectionId, facilityId);
    }


    @POST
    @Path("/updateSectionAssets")
    public Section updateSectionAssets(@QueryParam("id") String id, List<AssetRef> sectionAssets) {
        return service.updateSectionAssets(id, sectionAssets);
    }

    @GET
    @Path("/getFloorsByFacilityId")
    public List<Floor> getFloorsByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getFloorsByFacilityId(facilityId);
    }

    @POST
    @Path("/bulkSetSectionsActive")
    public BulkUpdateResult bulkSetSectionsActive(List<String> sectionIds) {
        return service.bulkSetSectionsActive(sectionIds);
    }

    @POST
    @Path("/bulkSetSectionsInactive")
    public BulkUpdateResult bulkSetSectionsInactive(List<String> sectionIds) {
        return service.bulkSetSectionsInactive(sectionIds);
    }

    @GET
    @Path("/getComponentSubtypeHierarchyByComponentSubtypeId")
    public ComponentSubtypeHierarchy getComponentSubtypeHierarchyByComponentSubtypeId(@QueryParam("componentSubtypeId") String componentSubtypeId) {
        return service.getComponentSubtypeHierarchyByComponentSubtypeId(componentSubtypeId);
    }

    @GET
    @Path("/getComponentSubtypeById")
    public ComponentSubtype getComponentSubtypeById(@QueryParam("componentSubtypeId") String componentSubtypeId) {
        return service.getComponentSubtypeById(componentSubtypeId);
    }

    @GET
    @Path("/getSectionTags")
    public List<TagRef> getSectionTags() {
        return service.getSectionTags();
    }

    @GET
    @Path("/getAllCustomFieldValues")
    public List<CustomFieldValue> getAllCustomFieldValues(@QueryParam("id") String id) {
        return service.getAllCustomFieldValues(id);
    }

    @POST
    @Path("/saveCustomFieldValues")
    public List<CustomFieldValue> saveCustomFieldValues(@QueryParam("id") String id, List<CustomFieldValue> customFieldValues) {
        return service.saveCustomFieldValues(id, customFieldValues);
    }

    @GET
    @Path("/getWorkOrdersBySectionId")
    public List<WorkOrder> getWorkOrdersBySectionId(@QueryParam("SectionId") String SectionId) {
        return service.getWorkOrdersBySectionId(SectionId);
    }

    @GET
    @Path("/getRequirementsBySectionId")
    public List<Requirement> getRequirementsBySectionId(@QueryParam("SectionId") String SectionId) {
        return service.getRequirementsBySectionId(SectionId);
    }

    @GET
    @Path("/getProjectsBySectionId")
    public List<RealPropertyProject> getProjectsBySectionId(@QueryParam("SectionId") String SectionId) {
        return service.getProjectsBySectionId(SectionId);
    }


    @GET
    @Path("/setSectionActive")
    public Section setSectionActive(@QueryParam("id") String id, @QueryParam("status") Boolean status) {
        return service.setSectionActive(id, status);
    }

    @GET
    @Path("/isSectionNameUnique")
    public boolean isSectionNameUnique(@QueryParam("facilityId") String facilityId, @QueryParam("sectionId") String sectionId,
                                       @QueryParam("sectionName") String sectionName,
                                       @QueryParam("systemId") String systemId, @QueryParam("subsystemId") String subsystemId,
                                       @QueryParam("assemblyCategoryId") String assemblyCategoryId, @QueryParam("componentSubtypeId") String componentSubtypeId) {
        return service.isSectionNameUnique(facilityId, sectionId, sectionName, systemId, subsystemId, assemblyCategoryId, componentSubtypeId);
    }

    @GET
    @Path("/getSectionDashboardStats")
    public SectionDashboardInfo getSectionDashboardStats() {
        return service.getSectionDashboardStats();
    }

    @POST
    @Path("/updateSectionAdditional")
    public Section updateSectionAdditional(SectionAdditional sectionAdditional) {
        return service.updateSectionAdditional(sectionAdditional);
    }

    @POST
    @Path("/updateSectionConditions")
    public Section updateSectionConditions(@QueryParam("sectionId") String sectionId, List<SectionCondition> sectionConditions) throws ApplicationException {
        return service.updateSectionConditions(sectionId, sectionConditions);
    }

    @POST
    @Path("/getSchedulesByAssetIds")
    public List<Schedule> getSchedulesByAssetIds(List<String> assetIds) {
        return service.getSchedulesByAssetIds(assetIds);
    }

    @GET
    @Path("/getRpeAssetsByFacilityAndSystem")
    public List<AssetSummary> getRpeAssetsByFacilityAndSystem(
            @QueryParam("sectionId") String sectionId,
            @QueryParam("facilityId") String facilityId,
            @QueryParam("facilitySystemId") String facilitySystemId,
            @QueryParam("facilitySubsystemId") String facilitySubsystemId,
            @QueryParam("assemblyCategoryId") String assemblyCategoryId) {
        return service.getRpeAssetsByFacilityAndSystem(sectionId, facilityId, facilitySystemId, facilitySubsystemId, assemblyCategoryId);
    }

    @GET
    @Path("/getDocumentTypes")
    public List<String> getDocumentTypes() {
        return service.getDocumentTypes();
    }
}
