package logicole.gateway.services.asset;

import io.swagger.annotations.*;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.businesscontact.BusinessContact;
import logicole.common.datamodels.asset.businesscontact.BusinessContactRef;
import logicole.common.datamodels.asset.classification.NomenclatureRef;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceCodeRef;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceSubject;
import logicole.common.datamodels.asset.management.*;
import logicole.common.datamodels.asset.management.dropDownFeeders.ConditionEntry;
import logicole.common.datamodels.asset.management.dropDownFeeders.RiskLevelEntry;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.customfield.CustomFieldRef;
import logicole.common.datamodels.general.customfield.CustomFieldValue;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.product.Capacity;
import logicole.common.datamodels.realproperty.Installation;
import logicole.common.datamodels.realproperty.SiteRef;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.realproperty.facility.FacilityRef;
import logicole.common.datamodels.realproperty.facility.FacilitySummary;
import logicole.common.datamodels.realpropertyproject.Requirement;
import logicole.common.datamodels.realpropertyproject.project.ProjectSummary;
import logicole.common.datamodels.realpropertysection.Section;
import logicole.common.datamodels.realpropertysection.SectionRef;
import logicole.common.datamodels.realpropertysection.SectionSummary;
import logicole.common.datamodels.space.*;
import logicole.common.datamodels.space.cobie.export.AssetCOBieExportData;
import logicole.common.datamodels.space.lookupdata.FloorPlanLayer;
import logicole.common.datamodels.system.TagRef;
import logicole.common.datamodels.workorder.Standards;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.datamodels.workorder.WorkOrderHistory;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

@Api(tags = {"Asset"})
@ApplicationScoped
@Path("/asset")
public class AssetRestApi extends ExternalRestApi<AssetService> {

    @Inject
    private MultiPartFormUtil uploadUtil;

    @POST
    @Path("/addAssetNote")
    public Asset addAssetNote(@QueryParam("id") String assetId, Note note) {
        service.addAssetNote(assetId, note);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/addReferenceDocument")
    public Asset addReferenceDocument(@QueryParam("id") String assetId, ReferenceDocument referenceDocument) {
        service.addReferenceDocument(assetId, referenceDocument);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/addStandard")
    public Asset addStandard(@QueryParam("id") String assetId, Standards standards) {
        service.addStandard(assetId, standards);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/addSubComponents")
    public Asset addSubComponents(@QueryParam("id") String assetId, List<String> subComponentIdList) {
        service.addSubComponents(assetId, subComponentIdList);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/addTagToAsset")
    public Asset addTagToAsset(@QueryParam("assetId") String assetId, TagRef tagRef) {
        service.addTagToAsset(assetId, tagRef);
        return service.getAssetById(assetId);
    }

    @GET
    @Path("/getAllActiveInstallations")
    public List<Installation> getAllActiveInstallations() {
        return service.getAllActiveInstallations();
    }

    @GET
    @Path("/getSiteRefsForInstallation")
    public List<SiteRef> getSiteRefsForInstallation(@QueryParam("installationId") String installationId) {
        return service.getSiteRefsForInstallation(installationId);
    }

    @POST
    @Path("/removeTagFromAsset")
    public Asset removeTagFromAsset(@QueryParam("assetId") String assetId, TagRef tagRef) {
        service.removeTagFromAsset(assetId, tagRef);
        return service.getAssetById(assetId);
    }

    @GET
    @Path("/getAssetTypes")
    public List<String> getAssetTypes() {
        return service.getAssetTypes();
    }

    @GET
    @Path("/getAssetTags")
    public List<TagRef> getAssetTags() {
        return service.getAssetTags();
    }

    @GET
    @Path("/getAssetById")
    public Asset getAssetRecordById(@QueryParam("id") String id) {
        return service.getAssetById(id);
    }

    @POST
    @Path("/getAssetsByIds")
    public List<AssetSummary> getAssetsByIds(List<AssetRef> assetList) {
        return service.getAssetsByIds(assetList);
    }

    @POST
    @Path("/getAssetsByAssetIds")
    public List<Asset> getAssetsByAssetIds(List<String> assetIds) {
        return service.getAssetsByAssetIds(assetIds);
    }

    @GET
    @Path("/getAssetInventoryStats")
    public AssetInventoryStats getAssetInventoryStats() {
        return service.getAssetInventoryStats();
    }

    @GET
    @Path("/getAssetsByWarrantyInfo")
    public List<AssetWarrantyInfo> getAssetsByWarrantyInfo(@QueryParam("assetWarrantyType") String assetWarrantyType, @QueryParam("daysRemainingCheck") int daysRemainingCheck) {
        return service.getAssetsByWarrantyInfo(assetWarrantyType, daysRemainingCheck);
    }

    @GET
    @Path("/getAssetsByAssetGroupId")
    public List<Asset> getAssetsByAssetGroupId(@QueryParam("assetGroupId") String assetGroupId) {
        return service.getAssetsByGroupId(assetGroupId);
    }

    @GET
    @Path("/getCustomFieldTypes")
    public List<String> getCustomFieldTypes() {
        return service.getCustomFieldTypes();
    }

    @GET
    @Path("/getAssetCustomFieldRefs")
    public List<CustomFieldRef> getAssetCustomFieldRefs() {
        return service.getAssetCustomFieldRefs();
    }

    @GET
    @Path("/getPrimeComponents")
    public List<PrimeComponent> getPrimeComponents(@QueryParam("assetId") String assetId,
                                                   @QueryParam("facilityId") String facilityId) {
        return service.getPrimeComponents(assetId, facilityId);
    }

    @GET
    @Path("/getRcCodes")
    public List<RegulatoryComplianceCodeRef> getRcCodes() {
        return service.getRcCodes();
    }

    @GET
    @Path("/getRcSubjects")
    public List<RegulatoryComplianceSubject> getRcSubjects() {
        return service.getRcSubjects();
    }

    @GET
    @Path("/getRpeAssetsByFacilityId")
    public List<AssetSummary> getRpeAssetsByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getRpeAssetsByFacilityId(facilityId);
    }

    @POST
    @Path("/getRpeAssetsByFacilityIds")
    public List<AssetSummary> getRpeAssetsByFacilityIds(List<FacilityRef> facilityIds) {
        return service.getRpeAssetsByFacilityIds(facilityIds);
    }


    @GET
    @Path("/getRpeAssetsForSpace")
    public List<AssetSummary> getRpeAssetsForSpace(@QueryParam("facilityId") String facilityId,
                                                   @QueryParam("roomId") String roomId) {
        return service.getRpeAssetsForSpace(facilityId, roomId);
    }

    @GET
    @Path("/getRpeAssetsWithNoAssetGroup")
    public List<Asset> getRpeAssetsWithNoAssetGroup(@QueryParam("nomenclatureId") String nomenclatureId,
                                                    @QueryParam("facilityId") String facilityId) {
        return service.getRpeAssetsWithNoAssetGroup(nomenclatureId, facilityId);
    }

    @GET
    @Path("/getSubComponentsForPrime")
    public List<Asset> getSubComponentsForPrime(@QueryParam("assetId") String assetId) {
        return service.getSubComponentsForPrime(assetId);
    }

    @GET
    @Path("/getSubComponentsNoPrime")
    public List<Asset> getSubComponentsNoPrime(@QueryParam("assetId") String assetId,
                                               @QueryParam("facilityId") String facilityId,
                                               @QueryParam("primeId") String primeId) {
        return service.getSubComponentsNoPrime(assetId, facilityId, primeId);
    }

    @POST
    @Path("/removeAssetNote")
    public Asset removeAssetNote(@QueryParam("id") String assetId, Note note) {
        service.removeAssetNote(assetId, note);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/removeEquipment")
    public List<DeletedEquipment> removeEquipment(List<String> equipmentIdList) {
        return service.removeEquipment(equipmentIdList);
    }

    @POST
    @Path("/removeReferenceDocument")
    public Asset removeReferenceDocument(@NotNull @QueryParam("id") String assetId, ReferenceDocument referenceDocument) {
        service.removeReferenceDocument(assetId, referenceDocument);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/removeStandard")
    public Asset removeStandard(@NotNull @QueryParam("id") String assetId, Standards standards) {
        service.removeStandard(assetId, standards);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/removeSubComponents")
    public Asset removeSubComponents(@NotNull @QueryParam("id") String assetId, List<String> subComponentIdList) {
        service.removeSubComponents(assetId, subComponentIdList);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/saveAsset")
    public Asset saveAssetRecord(Asset asset) {
        return service.saveAsset(asset);
    }

    @POST
    @Path("/removeAssetFromAssetGroup")
    public Asset removeAssetFromAssetGroup(@QueryParam("assetId") String assetId,
                                           @QueryParam("assetGroupId") String assetGroupId) {
        service.removeAssetFromAssetGroup(assetId, assetGroupId);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/removeAssetsFromAssetGroup")
    public AssetGroup removeAssetsFromAssetGroup(@QueryParam("assetGroupId") String assetGroupId,
                                                 List<String> assetIdList) {
        return service.removeAssetsFromAssetGroup(assetGroupId, assetIdList);
    }

    @POST
    @Path("/getAssetSearchResults")
    public SearchResult<AssetSearchResult> getAssetSearchResults(SearchInput searchInput) {
        return service.getAssetSearchResults(searchInput);
    }

    @POST
    @Path("/validateBulkUpdate")
    public List<AssetBulkUpdateResult> validateBulkUpdate(AssetBulkUpdateRequest request) {
        return service.validateBulkUpdate(request);
    }

    @POST
    @Path("/saveBulkUpdateRecordStatus")
    public List<AssetBulkUpdateResult> saveBulkUpdateRecordStatus(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateRecordStatus(request);
    }

    @POST
    @Path("/saveBulkUpdateRemoveRecords")
    public List<AssetBulkUpdateResult> saveBulkUpdateRemoveRecords(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateRemoveRecords(request);
    }

    @POST
    @Path("/saveBulkUpdateAssembly")
    public List<AssetBulkUpdateResult> saveBulkUpdateAssembly(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateAssembly(request);
    }

    @POST
    @Path("/saveBulkUpdateAudit")
    public List<AssetBulkUpdateResult> saveBulkUpdateAudit(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateAudit(request);
    }

    @POST
    @Path("/saveBulkUpdateAdditional")
    public List<AssetBulkUpdateResult> saveBulkUpdateAdditional(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateAdditional(request);
    }

    @POST
    @Path("/saveBulkUpdateConditionInformation")
    public List<AssetBulkUpdateResult> saveBulkUpdateConditionInformation(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateConditionInformation(request);
    }

    @POST
    @Path("/saveBulkUpdateConditionAssessment")
    public List<AssetBulkUpdateResult> saveBulkUpdateConditionAssessment(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateConditionAssessment(request);
    }

    @POST
    @Path("/saveBulkUpdateCostInformation")
    public List<AssetBulkUpdateResult> saveBulkUpdateCostInformation(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateCostInformation(request);
    }

    @POST
    @Path("/saveBulkUpdateLocation")
    public List<AssetBulkUpdateResult> saveBulkUpdateLocation(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateLocation(request);
    }

    @POST
    @Path("/saveBulkUpdateMaintenanceContractInformation")
    public List<AssetBulkUpdateResult> saveBulkUpdateMaintenanceContractInformation(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateMaintenanceContractInformation(request);
    }

    @POST
    @Path("/saveBulkUpdateProductInformation")
    public List<AssetBulkUpdateResult> saveBulkUpdateProductInformation(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateProductInformation(request);
    }

    @POST
    @Path("/saveBulkUpdateSpaceRooms")
    public List<AssetBulkUpdateResult> saveBulkUpdateSpaceRooms(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateSpaceRooms(request);
    }

    @POST
    @Path("/saveBulkUpdateSpaceZones")
    public List<AssetBulkUpdateResult> saveBulkUpdateSpaceZones(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateSpaceZones(request);
    }

    @POST
    @Path("/saveBulkUpdateWarrantyInformation")
    public List<AssetBulkUpdateResult> saveBulkUpdateWarrantyInformation(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateWarrantyInformation(request);
    }

    @POST
    @Path("/saveBulkUpdateHazards")
    public List<AssetBulkUpdateResult> saveBulkUpdateHazards(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateHazards(request);
    }

    @POST
    @Path("/saveBulkUpdateCustomFields")
    public List<AssetBulkUpdateResult> saveBulkUpdateCustomFields(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateCustomFields(request);
    }

    @POST
    @Path("/saveBulkUpdateCapacities")
    public List<AssetBulkUpdateResult> saveBulkUpdateCapacities(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateCapacities(request);
    }

    @POST
    @Path("/saveBulkUpdateSpecifications")
    public List<AssetBulkUpdateResult> saveBulkUpdateSpecifications(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateSpecifications(request);
    }

    @POST
    @Path("/saveBulkUpdateReferenceDocuments")
    public List<AssetBulkUpdateResult> saveBulkUpdateReferenceDocuments(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateReferenceDocuments(request);
    }

    @POST
    @Path("/saveBulkUpdateStandards")
    public List<AssetBulkUpdateResult> saveBulkUpdateStandards(AssetBulkUpdateRequest request) {
        return service.saveBulkUpdateStandards(request);
    }

    @POST
    @Path("/deleteAssetRefFromAssets")
    public void deleteAssetRefFromAssets(AssetRef assetRef) {
        service.deleteAssetRefFromAssets(assetRef);
    }

    @POST
    @Path("/updateAssetRefInAssets")
    public void updateAssetRefInAssets(AssetRef assetRef) {
        service.updateAssetRefInAssets(assetRef);
    }

    @POST
    @Path("/updateNomenclatureRefsInAssets")
    public void updateNomenclatureRefsInAssets(NomenclatureRef nomenclatureRef) {
        service.updateNomenclatureRefsInAssets(nomenclatureRef);
    }

    @POST
    @Path("/getAssetSearchResultsByFacilityId")
    public SearchResult<AssetSearchResult> getAssetSearchResultsByFacilityId(@QueryParam("facilityId") String facilityId, SearchInput searchInput) {
        return service.getAssetSearchResultsByFacilityId(facilityId, searchInput);
    }

    @GET
    @Path("/getAssessmentOrganizationRefs")
    public List<AssessmentOrganizationRef> getAssessmentOrganizationRefs() {
        return service.getAssessmentOrganizationRefs();
    }

    @GET
    @Path("/getCapacityUnits")
    public List<CapacityUnit> getCapacityUnits() {
        return service.getCapacityUnits();
    }

    @GET
    @Path("/getEnvironmentalHazards")
    public List<String> getEnvironmentalHazards() {
        return service.getEnvironmentalHazards();
    }

    @GET
    @Path("/getConditions")
    public List<ConditionEntry> getConditions() {
        return service.getConditions();
    }

    @GET
    @Path("/getFacilitiesForNodeIdentifier")
    public List<Facility> getFacilitiesForNodeIdentifier() {
        return service.getFacilitiesForNodeIdentifier();
    }

    @GET
    @Path("/getFacilitiesForSiteId")
    public List<Facility> getFacilitiesForSiteId() {
        return service.getFacilitiesForSiteId();
    }

    @GET
    @Path("/getActiveFacilitiesBySiteUid")
    public List<FacilitySummary> getActiveFacilitiesBySiteUid(@QueryParam("rpsuid") String rpsuid) {
        return service.getActiveFacilitiesBySiteUid(rpsuid);
    }

    @GET
    @Path("/getRPEManufacturerNames")
    public List<BusinessContactRef> getRPEManufacturerNames() {
        return service.getRPEManufacturerNames();
    }

    @GET
    @Path("/getAllRPEBusinessContacts")
    public List<BusinessContactRef> getAllRPEBusinessContacts() {
        return service.getAllRPEBusinessContacts();
    }

    @GET
    @Path("/getMaxAttachmentSize")
    public Integer getMaxAttachmentSize() {
        return service.getMaxAttachmentSize();
    }

    @GET
    @Path("/getMaxUploadSize")
    public Integer getMaxUploadSize() {
        return service.getMaxUploadSize();
    }

    @GET
    @Path("/getQaQcInspectionMethods")
    public List<String> getQaQcInspectionMethods() {
        return service.getQaQcInspectionMethods();
    }

    @GET
    @Path("/getRiskFactors")
    public List<String> getRiskFactors() {
        return service.getRiskFactors();
    }

    @GET
    @Path("/getRiskLevels")
    public List<RiskLevelEntry> getRiskLevels() {
        return service.getRiskLevels();
    }

    @GET
    @Path("/getRoomsByFacilityId")
    public List<Space> getRoomsByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getRoomsByFacilityId(facilityId);
    }

    @POST
    @Path("/getSectionsByEquipmentIds")
    public List<Section> getSectionsByEquipmentIds(List<String> equipmentIds) {
        return service.getSectionsByEquipmentIds(equipmentIds);
    }

    @POST
    @Path("/getSectionRefsByFacilityIds")
    public List<SectionRef> getSectionRefsByFacilityIds(List<String> facilityIds) {
        return service.getSectionRefsByFacilityIds(facilityIds);
    }

    @POST
    @Path("/getSectionNames")
    public List<SectionSummary> getSectionNames(List<String> facilityIds) {
        return service.getSectionNames(facilityIds);
    }

    @GET
    @Path("/getSpecificationUnits")
    public List<SpecificationUnit> getSpecificationUnits() {
        return service.getSpecificationUnits();
    }

    @GET
    @Path("/getUsersInstallations")
    public List<Installation> getUsersInstallations() {
        return service.getUsersInstallations();
    }

    @GET
    @Path("/removeAttachment")
    public boolean removeAttachment(@QueryParam("id") String id, @QueryParam("fileId") String fileId) throws IOException {
        return service.removeAttachment(id, fileId);
    }

    @POST
    @Path("/saveAdditionalInformation")
    public Asset saveAdditionalInformation(@QueryParam("id") String id, AdditionalInformation additionalInformation) {
        service.saveAdditionalInformation(id, additionalInformation);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveAssetConditionInformation")
    public Asset saveAssetConditionInformation(@QueryParam("id") String id, ConditionInformation conditionInformation) {
        service.saveAssetConditionInformation(id, conditionInformation);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveAssetConditionAssessments")
    public Asset saveAssetConditionAssessments(@QueryParam("id") String id, ConditionInformation conditionInformation) {
        service.saveAssetConditionAssessments(id, conditionInformation);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveAssetCost")
    public Asset saveAssetCost(@QueryParam("id") String id, AcquisitionInformation acquisitionInformation) {
        service.saveAssetCost(id, acquisitionInformation);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveAssetNote")
    public Asset saveAssetNote(@QueryParam("id") String assetId, Note note) {
        service.saveAssetNote(assetId, note);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/saveAssetMaintenanceContractInformation")
    public Asset saveAssetMaintenanceContractInformation(@QueryParam("id") String id, MaintenanceContractInformation maintenanceContractInformation) {
        service.saveAssetMaintenanceContractInformation(id, maintenanceContractInformation);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveAssetWarranty")
    public Asset saveAssetWarranty(@QueryParam("id") String id, AcquisitionInformation acquisitionInformation) {
        service.saveAssetWarranty(id, acquisitionInformation);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveAssemblyInformation")
    public Asset saveAssemblyInformation(@QueryParam("id") String id, AssemblyInformation assemblyInformation) {
        service.saveAssemblyInformation(id, assemblyInformation);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveAttachment")
    public Attachment saveAttachment(@QueryParam("id") String id, Attachment attachmentToSave) {
        return service.saveAttachment(id, attachmentToSave);
    }

    @POST
    @Path("/saveAuditInformation")
    public Asset saveAuditInformation(@QueryParam("id") String id, AuditInformation auditInformation) {
        service.saveAuditInformation(id, auditInformation);
        return service.getAssetById(id);
    }

    @GET
    @Path("/getAllCustomFieldValues")
    public List<CustomFieldValue> getAllCustomFieldValues(@QueryParam("id") String id) {
        return service.getAllCustomFieldValues(id);
    }

    @POST
    @Path("/saveCustomFieldValues")
    public List<CustomFieldValue> saveCustomFieldValues(@QueryParam("id") String id, List<CustomFieldValue> customFieldValues) {
        return service.saveCustomFieldValues(id, customFieldValues);
    }

    @POST
    @Path("/saveCapacityInformation")
    public Asset saveCapacityInformation(@QueryParam("id") String id, Features features) {
        service.saveCapacityInformation(id, features);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveEquipmentIdentifier")
    public Asset saveEquipmentIdentifier(@QueryParam("id") String id, String identifier) {
        service.saveEquipmentIdentifier(id, identifier);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveEquipmentTags")
    public Asset saveEquipmentTags(@QueryParam("id") String id, List<TagRef> tagRefList) {
        service.saveEquipmentTags(id, tagRefList);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveHazardsInformation")
    public Asset saveHazardsInformation(@QueryParam("id") String id, String[] hazards) {
        service.saveHazardsInformation(id, hazards);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveLocationInformation")
    public Asset saveLocationInformation(@QueryParam("id") String id, LocationInformation locationInformation) {
        service.saveLocationInformation(id, locationInformation);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveSpecificationsInformation")
    public Asset saveSpecificationsInformation(@QueryParam("id") String id, Features features) {
        service.saveSpecificationsInformation(id, features);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveProductCapacity")
    public Asset saveProductCapacity(@QueryParam("id") String id, Capacity capacity) {
        service.saveProductCapacity(id, capacity);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveMEProductInformation")
    public Asset saveMEProductInformation(@QueryParam("id") String id, AssetProductInformation assetProductInformation) {
        service.saveMEProductInformation(id, assetProductInformation);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveProductSpecifications")
    public Asset saveProductSpecifications(@QueryParam("id") String id, List<Specification> productSpecifications) {
        service.saveProductSpecifications(id, productSpecifications);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveReferenceDocument")
    public Asset saveReferenceDocument(@QueryParam("id") String assetId, ReferenceDocument referenceDocument) {
        service.saveReferenceDocument(assetId, referenceDocument);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/saveRoomsSupported")
    public Asset saveRoomsSupported(@QueryParam("id") String id, List<SpaceRef> roomsToSave) {
        service.saveRoomsSupported(id, roomsToSave);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveRPEProductInformation")
    public Asset saveRPEProductInformation(@QueryParam("id") String id, RealPropertyAsset realPropertyAsset) {
        service.saveRPEProductInformation(id, realPropertyAsset);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveStandard")
    public Asset saveStandard(@QueryParam("id") String assetId, Standards standards) {
        service.saveStandard(assetId, standards);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/saveZonesSupported")
    public Asset saveZonesSupported(@QueryParam("id") String id, List<ZoneRef> zonesToSave) {
        service.saveZonesSupported(id, zonesToSave);
        return service.getAssetById(id);
    }

    @GET
    @Path("/setAssetActive")
    public Asset setAssetActive(@QueryParam("assetId") String assetId) {
        service.setAssetActive(assetId);
        return service.getAssetById(assetId);
    }

    @GET
    @Path("/setAssetInactive")
    public Asset setAssetInactive(@QueryParam("assetId") String assetId) {
        service.setAssetInactive(assetId);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        byte[] content;

        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            InputStream inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new ApplicationException("Unable to upload file " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxAttachmentSize();
        if (content.length > maxUploadSize) {
            throw new ApplicationException(
                    "File size exceeds max size of " + maxUploadSize + " bytes");
        }

        return service.uploadFile(content, uploadedFileName);
    }

    @POST
    @Path("/uploadFileWithCustomValues")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file with custom uploadedByUserId and uploadedDateTime. Example dateTime format: Sat Jun 14 2019 03:55:07")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "Select a file to upload",
                    dataType = "java.io.File", name = "file",
                    paramType = "formData", required = true)
    })
    public FileManager uploadFileWithCustomValues(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form,
                                                  @QueryParam("uploadedByUserId") String uploadedByUserId,
                                                  @QueryParam("uploadedDateTime") Date uploadedDateTime) {
        byte[] content;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            InputStream inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new ApplicationException("Unable to upload file " + uploadedFileName);
        }
        Integer maxUploadSize = service.getMaxAttachmentSize();
        if (content.length > maxUploadSize) {
            throw new ApplicationException("File size exceeds max size of " + maxUploadSize + " bytes");
        }

        return service.uploadFileWithCustomValues(content, uploadedFileName, uploadedByUserId, uploadedDateTime);
    }

    @GET
    @Path("/getAssetAge")
    public Integer getAssetAge(@QueryParam("id") String id) {
        return service.getAssetAge(id);
    }

    @GET
    @Path("/getAssetLifeRemaining")
    public Integer getAssetLifeRemaining(@QueryParam("id") String id) {
        return service.getAssetLifeRemaining(id);
    }

    @GET
    @Path("getZonesByFacilityId")
    public List<Zone> getZonesByFacilityId(@QueryParam("id") String id) {
        return service.getZonesByFacilityId(id);
    }

    @GET
    @Path("/getRelatedCauses")
    public List<String> getRelatedCauses() {
        return service.getRelatedCauses();
    }

    @GET
    @Path("/getWorkOrderHistoryByAssetId")
    public List<WorkOrderHistory> getWorkOrderHistoryByAssetId(@QueryParam("assetId") String assetId,
                                                               @QueryParam("includeScheduled") Boolean includeScheduled,
                                                               @QueryParam("includeUnscheduled") Boolean includeUnscheduled) {
        return service.getWorkOrderHistoryByAssetId(assetId, includeScheduled, includeUnscheduled);
    }

    @GET
    @Path("/createRequirementFromAsset")
    public Requirement createRequirementFromAsset(@QueryParam("assetId") String assetId) {
        return service.createRequirementFromAsset(assetId);
    }

    @GET
    @Path("/getActiveRequirementCountByAsset")
    public long getActiveRequirementCountByAsset(@QueryParam("assetId") String assetId) {
        return service.getActiveRequirementCountByAsset(assetId);
    }

    @POST
    @Path("/createDeficiencyWorkOrder")
    public WorkOrder createDeficiencyWorkOrder(@QueryParam("assetId") String assetId) {
        return service.createDeficiencyWorkOrder(assetId);
    }

    @GET
    @Path("/getBusinessContactRefs")
    public List<BusinessContactRef> getBusinessContactRefs(@QueryParam("isActive") String isActive) {
        return service.getBusinessContactRefs(isActive);
    }

    @GET
    @Path("/getBusinessContacts")
    public List<BusinessContact> getBusinessContacts(@QueryParam("isActive") String isActive) {
        return service.getBusinessContacts(isActive);
    }

    @GET
    @Path("/getAssetContactByBusinessContactId")
    public AssetBusinessContact getAssetContactByBusinessContactId(@QueryParam("businessContactId") String businessContactId) {
        return service.getAssetContactByBusinessContactId(businessContactId);
    }

    @GET
    @Path("/getAssetContactByContactId")
    public AssetBusinessContact getAssetContactByContactId(@QueryParam("contactId") String contactId) {
        return service.getAssetContactByContactId(contactId);
    }

    @GET
    @Path("/getAssetCountInSpace")
    public long getAssetCountInSpace(@QueryParam("spaceId") String spaceId, @QueryParam("spaceIdentifier") String spaceIdentifier) {
        return service.getAssetCountInSpace(spaceId, spaceIdentifier);
    }

    @GET
    @Path("/getAssetCostSummaryByAssetId")
    public AssetCostSummary getAssetCostSummaryByAssetId(@QueryParam("assetId") String assetId) {
        return service.getAssetCostSummaryByAssetId(assetId);
    }

    @GET
    @Path("/getActiveScheduleCountByAssetId")
    public long getActiveScheduleCountByAssetId(@QueryParam("assetId") String assetId) {
        return service.getActiveScheduleCountByAssetId(assetId);
    }

    @GET
    @Path("/getCOBieExportData")
    public AssetCOBieExportData getCOBieExportData(@QueryParam("facilityId") String facilityId) {
        return service.getCOBieExportData(facilityId);
    }

    @POST
    @Path("/getRoomSummariesByFacilityIds")
    public List<RoomSummary> getRoomSummariesByFacilityIds(List<String> facilityIds) {
        return service.getRoomSummariesByFacilityIds(facilityIds);
    }

    @POST
    @Path("/getZonesByIds")
    public List<Zone> getZonesByIds(List<String> zoneIds) {
        return service.getZonesByIds(zoneIds);
    }

    @POST
    @Path("/getRoomSummariesByIds")
    public List<RoomSummary> getRoomSummariesByIds(List<String> roomIdList) {
        return service.getRoomSummariesByIds(roomIdList);
    }

    @POST
    @Path("/getZonesByFacilityIds")
    public List<Zone> getZonesByFacilityIds(List<String> facilityIds) {
        return service.getZonesByFacilityIds(facilityIds);
    }

    @GET
    @Path("/getDrawingLegend")
    public List<FloorPlanLegendEntry> getDrawingLegend(@QueryParam("floorId") String floorId, @QueryParam("legendType") String legendType) {
        return service.getDrawingLegend(floorId, legendType);
    }

    @GET
    @Path("/getFloorPlanLayers")
    public List<FloorPlanLayer> getFloorPlanLayers() {
        return service.getFloorPlanLayers();
    }

    @POST
    @Path("/getGraphicalSearchRecordsByRoomIds")
    public List<GraphicalSearchRecord> getGraphicalSearchRecordsByRoomIds(List<String> roomIds) {
        return service.getGraphicalSearchRecordsByRoomIds(roomIds);
    }

    @GET
    @Path("/getFloorById")
    public Floor getFloorById(@QueryParam("id") String id) {
        return service.getFloorById(id);
    }

    @GET
    @Path("/getFloorBySpaceId")
    public Floor getFloorBySpaceId(@QueryParam("spaceId") String spaceId) {
        return service.getFloorBySpaceId(spaceId);
    }

    @GET
    @Path("/getRoomMetadataByRoomNumber")
    public RoomMetadata getRoomMetadataByRoomNumber(@QueryParam("facilityId") String facilityId, @QueryParam("identifier") String identifier) {
        return service.getRoomMetadataByRoomNumber(facilityId, identifier);
    }

    @GET
    @Path("/getRelatedRecordCountsByRoomNumber")
    public RoomRelatedRecordCounts getRelatedRecordCountsByRoomNumber(@QueryParam("facilityId") String facilityId, @QueryParam("identifier") String identifier) {
        return service.getRelatedRecordCountsByRoomNumber(facilityId, identifier);
    }

    @GET
    @Path("/getProjectsByAssetId")
    public List<ProjectSummary> getProjectsByAssetId(@QueryParam("assetId") String assetId) {
        return service.getProjectsByAssetId(assetId);
    }

    @GET
    @Path("/getDocumentTypes")
    public List<String> getDocumentTypes() {
        return service.getDocumentTypes();
    }
}
