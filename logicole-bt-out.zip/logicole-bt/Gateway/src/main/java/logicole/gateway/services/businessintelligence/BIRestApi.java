package logicole.gateway.services.businessintelligence;

import io.swagger.annotations.Api;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Api(tags = {"BusinessIntelligence"})
@ApplicationScoped
@Path("businessintelligence")
@Consumes(MediaType.APPLICATION_JSON)
public class BIRestApi extends ExternalRestApi<BIService> {

    @GET
    @Path("/getJmarToken")
    @Produces({MediaType.TEXT_PLAIN})
    public String getJmarToken() {
        return service.getJmarToken();
    }

    @GET
    @Path("/getBcsToken")
    @Produces({MediaType.TEXT_PLAIN})
    public String getBcsToken(@QueryParam("bcsToken") String bcsToken) {
        return service.getBcsToken(bcsToken);
    }

	@GET
	@Path("/getBcsUsername")
	@Produces({MediaType.TEXT_PLAIN})
	public String getBcsUsername() {
		return service.getBcsUsername();
	}

    @GET
    @Path("/getBcsSsoEnabled")
    @Produces({MediaType.TEXT_PLAIN})
    public Boolean getBcsSsoEnabled() {
        return service.getBcsSsoEnabled();
    }

    @GET
    @Path("/getBcsSsoUrl")
    @Produces({MediaType.TEXT_PLAIN})
    public String getBcsSsoUrl() {
        return service.getBcsSsoUrl();
    }

	@GET
	@Path("/getBcsLandingUrl")
	@Produces({MediaType.TEXT_PLAIN})
	public String getBcsLandingUrl() {
		return service.getBcsLandingUrl();
	}
}
