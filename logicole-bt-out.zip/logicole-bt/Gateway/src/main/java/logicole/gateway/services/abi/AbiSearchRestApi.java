package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.BarcodeInformation;
import logicole.common.datamodels.abi.SiteEquipment;
import logicole.common.datamodels.abi.staging.SearchAbiInput;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.rest.ExternalRestApi;

import java.io.IOException;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi")
public class AbiSearchRestApi extends ExternalRestApi<AbiSearchService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @POST
    @Path("/getABiCatalogRecordESResults")
    public String getAbiRecordESResults(SearchAbiInput searchAbiInput) throws IOException, ApplicationException {
        return service.getAbiRecordESResults(searchAbiInput);
    }

    @GET
    @Path("/processBarcodeSearchString")
    @Produces(MediaType.TEXT_PLAIN)
    public String parseBarcodeSearchString(@QueryParam("barcodeString") String barcodeString) throws ApplicationException {
        return service.parseBarcodeSearchString(barcodeString);
    }

    @GET
    @Path("/parseBarcodeString")
    public BarcodeInformation parseBarcodeString(@QueryParam("barcodeString") String barcodeString) throws ApplicationException {
        return service.parseBarcodeString(barcodeString);
    }

    @GET
    @Path("/getCommodityTypes")
    public List<String> getCommodityTypes() {
        return service.getCommodityTypes();
    }

    @GET
    @Path("/getProductNouns")
    public List<String> getProductNouns() {
        return service.getProductNouns();
    }

    @GET
    @Path("/getProductTypes")
    public List<String> getProductTypes() {
        return service.getProductTypes();
    }

    @GET
    @Path("/getUnspscSegments")
    public List<String> getUnspscSegments() {
        return service.getUnspscSegments();
    }

    @GET
    @Path("/getEquipmentByEnterpriseId")
    public List<SiteEquipment> getEquipmentByEnterpriseId(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.getEquipmentByEnterpriseId(enterpriseProductIdentifier);
    }
}
