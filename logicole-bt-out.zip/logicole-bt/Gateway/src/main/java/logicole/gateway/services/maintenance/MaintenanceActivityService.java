package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.IMaintenanceActivityMicroserviceApi;
import logicole.common.datamodels.maintenance.activity.MaintenanceActivity;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.UnauthorizedException;
import logicole.common.general.security.SecurityConstants;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class MaintenanceActivityService extends BaseGatewayService<IMaintenanceActivityMicroserviceApi> {

    public static final String NO_MAINTENANCE_ACTIVITY_FOUND = "No Maintenance Activity found with id of %s";

    public MaintenanceActivityService() {
        super("MaintenanceActivity");
    }

    public MaintenanceActivity findById(String id) {
        MaintenanceActivity activity = microservice.findById(id);
        if (null == activity) {
            throw new ApplicationException(String.format(NO_MAINTENANCE_ACTIVITY_FOUND, id));
        }
        validateMaintenanceActivityUserAccess(activity);
        return activity;
    }

    private void validateMaintenanceActivityUserAccess(@NotNull MaintenanceActivity maintenanceActivity) {
        String ancestry = currentUserBT.getCurrentUser().profile.currentNodeRef.ancestry;
        boolean isNotAllowedAccess;

        isNotAllowedAccess = !isMDBUser() && !ancestry.contains(maintenanceActivity.managedByNodeRef.id);

        if (isNotAllowedAccess) {
            throw new UnauthorizedException("Unauthorized access");
        }
    }

    private boolean isMDBUser() {
        return Objects.equals(currentUserBT.getCurrentUser().profile.pkiDn, SecurityConstants.MDB_SPECIAL_USER_PROFILE_KEY);
    }

    public MaintenanceActivity createMaintenanceActivity(MaintenanceActivity maintenanceActivity) {
        maintenanceActivity.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.createMaintenanceActivity(maintenanceActivity);
    }

    public List<MaintenanceActivity> getMaintenanceActivities() {
        return microservice.getMaintenanceActivities();
    }

}
