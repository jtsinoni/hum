package logicole.gateway.services.spacemanagement;

import logicole.apis.space.IDrawingMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.filemanager.CommonUploadedFile;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.filemanager.FileRef;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.realproperty.Installation;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.realproperty.lookupdata.facility.CategoryCode;
import logicole.common.datamodels.space.*;
import logicole.common.datamodels.space.lookupdata.FloorPlanLayer;
import logicole.common.datamodels.space.lookupdata.SpaceCode;
import logicole.common.datamodels.space.lookupdata.SpaceType;
import logicole.common.datamodels.space.staging.EFloorPlanConversionStatus;
import logicole.common.datamodels.space.staging.StagingFloorPlan;
import logicole.common.datamodels.space.staging.StagingFloorPlanRef;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.AssetService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.realproperty.InstallationService;
import logicole.gateway.services.realproperty.RealPropertyLookupService;
import logicole.gateway.services.realpropertyproject.ProjectService;
import logicole.gateway.services.realpropertyproject.RequirementService;
import logicole.gateway.services.workorder.WorkOrderService;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class DrawingService extends BaseGatewayService<IDrawingMicroserviceApi> {

    @Inject
    private MultiPartFormUtil multiPartFormUtil;

    @Inject
    private JMSContext jmsContext;

    @Inject
    AssetService assetService;

    @Inject
    DrawingLookupService drawingLookupService;

    @Inject
    FacilityService facilityService;

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    InstallationService installationService;

    @Inject
    ProjectService projectService;

    @Inject
    RealPropertyLookupService realPropertyLookupService;

    @Inject
    RequirementService requirementService;

    @Inject
    SpaceLookupService spaceLookupService;

    @Inject
    SpaceManagementService spaceManagementService;

    @Inject
    WorkOrderService workOrderService;

    public DrawingService() {
        super("Drawing");
    }

    public String getUserName() {
        return microservice.getUserName();
    }

    public FileManager uploadDrawingFile(String floorId, String fileDescription, MultipartFormDataInput form)
            throws IOException {
        byte[] content;

        InputPart inputPart = multiPartFormUtil.getInputPart(form, "file");
        String uploadedFileName = multiPartFormUtil.getFileName(inputPart.getHeaders());

        InputStream inputStream = inputPart.getBody(InputStream.class, null);
        content = IOUtils.toByteArray(inputStream);

        // Validate file is in DXF Format
        if (!contentIsDxfFile(content)) {
            throw new ApplicationException("File is not a valid Drawing Exchange Format (DXF) File.");
        }
        Integer maxUploadSize = getMaxDrawingAttachmentSize();
        if (content.length > maxUploadSize) {
            throw new ApplicationException(
                    "File size exceeds max size of " + maxUploadSize + " bytes");
        }

        FileManager fileManager = fileManagerAdminService.uploadManaged(content, uploadedFileName);
        addDrawingToFloor(floorId, convertToAttachment(fileManager, fileDescription));

        return fileManager;
    }

    public Boolean deleteDrawingFile(String fileId) throws IOException {
        if (fileId != null) {
            return fileManagerAdminService.removeFile(fileId);
        } else {
            return false;
        }
    }

    public Response downloadFloorPlan(String floorPlanId) throws IOException {
        CommonUploadedFile commonUploadedFile = fileManagerAdminService.download(floorPlanId);

        Response.ResponseBuilder response;

        if (commonUploadedFile != null) {
            byte[] bytes = FileUtils.readFileToByteArray(commonUploadedFile.getFile());
            String fileType = Files.probeContentType(commonUploadedFile.getFile().toPath());

            response = Response.ok();
            response.header("Content-Disposition", "attachment; filename=" + commonUploadedFile.getUploadedFilename());
            response.header("Content-Length", bytes.length);
            response.header("Content-Encoding", StandardCharsets.UTF_8);
            response.header("Access-Control-Expose-Headers", "Content-Disposition,Content-Type");
            response.header("Content-Type", fileType);

            if (fileType == null || fileType.isEmpty()) {
                response.type(MediaType.APPLICATION_OCTET_STREAM_TYPE);
            }
            response.entity(bytes);
        } else {
            response = Response.status(Response.Status.NOT_FOUND);
        }

        return response.build();
    }

    public SearchResult<DrawingSummary> getDrawingSummarySearchResults(SearchInput searchInput) {
        if (StringUtil.isEmptyOrNull(searchInput.searchText) ||
                searchInput.searchText.trim().length() < 3) {
            throw new ApplicationException("Search criteria must be at least 3 characters");
        }

        SearchResult<Floor> searchResult = spaceManagementService.getFloorSearchResults(searchInput);
        SearchResult<DrawingSummary> convertedResult = new SearchResult<>();
        convertedResult.aggregations = searchResult.aggregations;

        if (!ListUtil.isEmpty(searchResult.results)) {
            List<DrawingSummary> allDrawingSummaries = new ArrayList<>();

            for (Floor floor : searchResult.results) {
                allDrawingSummaries.add(getDrawingSummaryForFloor(floor));
            }

            convertedResult.results = allDrawingSummaries;
            convertedResult.total = searchResult.total;
            convertedResult.limit = searchResult.limit;
        }
        return convertedResult;

    }

    public Floor updateDrawingActive(String floorId, Boolean isActive) {
        return microservice.updateDrawingActive(floorId, isActive);
    }

    public StagingFloorPlan appendStagingFloorPlanLogMessage(String stagingFloorPlanId, String message) {
        return microservice.appendStagingFloorPlanLogMessage(stagingFloorPlanId, message);
    }

    public Floor addDrawingToFloor(String floorId, Attachment drawing) {
        StagingFloorPlan stagingFloorPlan = new StagingFloorPlan();

        Floor floor = spaceManagementService.getFloorById(floorId);
        if (Objects.nonNull(floor.drawing)) {
            microservice.removeDrawingFromFloor(floorId);
        }
        stagingFloorPlan.conversionStatus = EFloorPlanConversionStatus.QUEUED;
        stagingFloorPlan.floorPlanToConvert = drawing;
        stagingFloorPlan.floorRef = (FloorRef) floor.getRef();

        logger.info("[DXFConversion] addDrawingToFloor: Calling microservice.addFloorPlanForConversion() for " + floorId);
        stagingFloorPlan = microservice.addFloorPlanForConversion(floorId, stagingFloorPlan);
        floor = spaceManagementService.getFloorById(floorId);
        floor.uploadedFileForConversion = (StagingFloorPlanRef) stagingFloorPlan.getRef();
        logger.info("[DXFConversion] addDrawingToFloor: updating floor with staging floor plan information.");
        floor = spaceManagementService.updateFloor(floor);

        logger.info("[DXFConversion] addDrawingToFloor: creating message for queue.");
        Queue queue = jmsContext.createQueue(ProcessDrawingUploadMDB.DRAWING_STAGING_SERVICE_BROKER);
        TextMessage textMessage = jmsContext.createTextMessage("stagingFloorPlanID:" + stagingFloorPlan.getId());
        JMSProducer jmsProducer = jmsContext.createProducer();
        jmsProducer.setJMSType(ProcessDrawingUploadMDB.JMS_TYPE_PROCESS_UPLOAD_DRAWING_REQUEST);

        logger.info("[DXFConversion] addDrawingToFloor: sending message to queue.");
        jmsProducer.send(queue, textMessage);
        appendStagingFloorPlanLogMessage(stagingFloorPlan.getId(), "Sent Process Upload Drawing Request.");
        return floor;
    }

    public Floor removeDrawingFromFloor(String floorId) {
        Floor floor = spaceManagementService.getFloorById(floorId);
        Attachment previousDrawing = floor.drawing;

        Floor updatedFloor = microservice.removeDrawingFromFloor(floorId);

        if (previousDrawing != null) {
            try {
                fileManagerAdminService.removeFile(previousDrawing.fileRef.id);
            } catch (IOException exception) {
                throw new ApplicationException("Unable to remove the previous drawing.");
            }
        }

        return updatedFloor;
    }

    public Floor updateDrawingForFloor(String floorId, Attachment drawing) {
        return microservice.updateDrawingForFloor(floorId, drawing);
    }

    public Integer getMaxDrawingAttachmentSize() {
        return microservice.getMaxDrawingAttachmentSize();
    }

    public List<String> getDocumentTypes() {
        return facilityService.getDocumentTypes();
    }

    public Floor updateDrawingName(String floorId, String drawingName) {
        return microservice.updateDrawingName(floorId, drawingName);
    }

    public DrawingDashboardInfo getDrawingDashboardCounts() {
        return microservice.getDrawingDashboardCounts();
    }

    public FloorPlanDiscrepancy getDiscrepanciesForFloor(String floorId, String discrepancyType) {
        return microservice.getDiscrepanciesForFloor(floorId, discrepancyType);
    }

    public FloorPlanDiscrepancy findDiscrepanciesForFloor(String floorId, String discrepancyUser) {
        Floor floor = spaceManagementService.getFloorById(floorId);

        if (floor.drawing == null) {
            throw new ApplicationException("No floor plan available for this floor");
        }

        CommonUploadedFile commonUploadedFile = fileManagerAdminService.download(floor.drawing.fileRef.fileId);
        return microservice.findDiscrepanciesForFloor(floorId, commonUploadedFile.getFile(), discrepancyUser);
    }

    public FloorPlanDiscrepancy acceptSizeDiscrepancies(FloorPlanDiscrepancy floorPlanDiscrepancy) {
        Floor floor = spaceManagementService.getFloorById(floorPlanDiscrepancy.floorId);

        if (floor == null || floor.drawing == null) {
            throw new ApplicationException("No floor plan available for this floor");
        }

        CommonUploadedFile commonUploadedFile = fileManagerAdminService.download(floor.drawing.fileRef.fileId);
        return microservice.acceptSizeDiscrepancies(floorPlanDiscrepancy, commonUploadedFile.getFile());
    }

    public void deleteStagingFloorPlan(String stagingFloorPlanId) {
        microservice.deleteStagingFloorPlan(stagingFloorPlanId);
    }

    private DrawingSummary getDrawingSummaryForFloor(Floor floor) {
        Installation installation = installationService.getInstallationForSite(floor.siteRef.id);

        DrawingSummary summary = new DrawingSummary();

        summary.installationId = installation.getId();
        summary.installationName = installation.name;

        summary.siteRef = floor.siteRef;
        summary.facilityRef = floor.facilityRef;
        summary.floorRef = (FloorRef) floor.getRef();
        summary.unitOfMeasure = floor.unitOfMeasure;

        if (floor.drawing != null) {
            summary.drawing = floor.drawing;
            summary.drawingName = floor.drawingName;
            summary.drawingDescription = floor.drawing.description;
            summary.isDrawingActive = (floor.isDrawingActive != null) ? floor.isDrawingActive : false;
            summary.isConvertedDrawing = true;
        } else if (floor.uploadedFileForConversion != null) {
            StagingFloorPlan sfp = getStagingFloorPlanById(floor.uploadedFileForConversion.id);
            String conversionStatus = null;
            switch (sfp.conversionStatus) {
                case CONVERSION_ERROR:
                    conversionStatus = "An error occurred while converting the floor plan.";
                    break;
                case CONVERTING:
                case QUEUED:
                case CONVERTED:
                case UNSPECIFIED:
                default:
                    conversionStatus = "Floor Plan is being converted.";
                    break;
            }
            summary.drawing = null;
            summary.drawingName = conversionStatus;
            summary.drawingDescription = conversionStatus;
            summary.isConvertedDrawing = false;
        }

        return summary;
    }

    public StagingFloorPlan getStagingFloorPlanById(String stagingFloorPlanId) {
        return microservice.getStagingFloorPlanById(stagingFloorPlanId);
    }

    public boolean contentIsDxfFile(byte[] content) {
        boolean isDxfFile = false;
        String[] lines = null;

        if (content != null) {
            String buffer = new String(content);
            lines = buffer.split("\r\n");
        }

        if ((lines != null) && (lines.length > 4)) {
            // Look for lines:
            // 0
            // SECTION
            // 2
            // HEADER
            int idx = 0;
            int matchCount = 0;
            while (idx < lines.length) {
                String line = lines[idx++].trim();
                if ((matchCount == 0) && ("0".equalsIgnoreCase(line))) {
                    matchCount++;
                } else if ((matchCount == 1) && ("SECTION".equalsIgnoreCase(line))) {
                    matchCount++;
                } else if ((matchCount == 2) && ("2".equalsIgnoreCase(line))) {
                    matchCount++;
                } else if ((matchCount == 3) && ("HEADER".equalsIgnoreCase(line))) {
                    isDxfFile = true;
                    break;
                } else {
                    matchCount = 0;
                }
            }
        }
        return isDxfFile;
    }

    public List<FloorPlanLegendEntry> getDrawingLegend(String floorId, String legendType) {
        return spaceManagementService.getDrawingLegend(floorId, legendType);
    }

    public RoomMetadata getRoomMetadataByRoomNumber(String facilityId, String identifier) {
        Space space;
        try {
            space = spaceManagementService.getRoomByRoomNumber(facilityId, identifier);
        } catch (ApplicationException exception) {
            logger.error(exception);
            return new RoomMetadata();
        }

        Floor floor = spaceManagementService.getFloorById(space.floorRef.id);
        Facility facility = facilityService.getFacilityById(facilityId);
        Installation installation = installationService.getInstallationForSite(facility.siteRef.id);
        
        CategoryCode categoryCode = new CategoryCode();
        if (space.categoryCodeRef != null && !StringUtil.isEmptyOrNull(space.categoryCodeRef.id)) {
            categoryCode = realPropertyLookupService.getCategoryCodeById(space.categoryCodeRef.id);
        }

        SpaceType currentRoomType = spaceLookupService.getRoomTypeBySubtypeCode(space.currentCode);
        SpaceCode currentRoomCode = new SpaceCode();
        for (SpaceCode roomCode : currentRoomType.subtypes) {
            if (roomCode.code.equals(space.currentCode)) {
                currentRoomCode = roomCode;
            }
        }

        SpaceType designRoomType = spaceLookupService.getRoomTypeBySubtypeCode(space.currentCode);
        SpaceCode designRoomCode = new SpaceCode();
        for (SpaceCode roomCode : designRoomType.subtypes) {
            if (roomCode.code.equals(space.designCode)) {
                designRoomCode = roomCode;
            }
        }

        Occupant occupant = new Occupant();
        if (space.occupants != null) {
            for (RoomOccupancy roomOccupancy : space.occupants) {
                if (roomOccupancy.isPrimary) {
                    occupant = spaceManagementService.getOccupantById(roomOccupancy.occupantRef.id);
                }
            }
        }

        RoomMetadata roomMetadata = new RoomMetadata();
        roomMetadata.installationName = installation.name;

        roomMetadata.facilityNumber = facility.facilityNumber;
        roomMetadata.facilityName = facility.name;

        roomMetadata.floorNumber = floor.identifier;
        roomMetadata.floorPlanName = floor.drawingName;

        roomMetadata.roomId = space.getId();
        roomMetadata.roomType = space.currentSpaceTypeRef.name;
        roomMetadata.roomNumber = space.identifier;

        roomMetadata.localName = space.localName;
        roomMetadata.area = space.measurement.size;
        roomMetadata.areaUnit = space.measurement.sizeUnit;
        roomMetadata.perimeter = space.measurement.perimeter;
        roomMetadata.perimeterUnit = space.measurement.perimeterUnit;
        roomMetadata.currentCode = currentRoomCode;
        roomMetadata.designCode = designRoomCode;
        roomMetadata.categoryCode = categoryCode;
        roomMetadata.signageName = space.signageName;
        roomMetadata.lastAuditBy = space.lastAuditBy;
        roomMetadata.lastAuditDate = space.lastAuditDate;
        roomMetadata.isVacant = space.isVacant;
        roomMetadata.attributes = space.attributes;

        roomMetadata.meprsCode = occupant.meprsCode;
        roomMetadata.officeSymbol = occupant.officeSymbol;
        roomMetadata.departmentName = occupant.departmentName;

        if (space.cleaningReq != null) {
            roomMetadata.areaCleaned = space.cleaningReq.areaCleaned;
            roomMetadata.areaCleanedUom = space.cleaningReq.areaCleanedUom;

            if (space.cleaningReq.cleaningReqmtRef != null) {
                roomMetadata.cleaningRequirementText = space.cleaningReq.cleaningReqmtRef.description;
                roomMetadata.cleaningRequirementNumber = space.cleaningReq.cleaningReqmtRef.code;
            }
        }

        return roomMetadata;
    }

    public RoomRelatedRecordCounts getRelatedRecordCountsByRoomNumber(String facilityId, String identifier) {
        RoomRelatedRecordCounts relatedRecordCounts = new RoomRelatedRecordCounts();

        Space space;
        try {
            space = spaceManagementService.getRoomByRoomNumber(facilityId, identifier);
        } catch (ApplicationException exception) {
            logger.error(exception);
            return relatedRecordCounts;
        }

        if (space != null) {
            relatedRecordCounts.spaceCount = 1;

            if (space.facilityRef != null) {
                relatedRecordCounts.facilityCount = 1;
            }

            if (space.floorRef != null) {
                relatedRecordCounts.floorCount = 1;
            }

            relatedRecordCounts.assetCount = assetService.getAssetCountInSpace(space.getId(), space.identifier);
            relatedRecordCounts.projectCount = projectService.getProjectCountInSpace(space.getId(), space.identifier);
            relatedRecordCounts.requirementCount = requirementService.getRequirementCountInSpace(space.getId(), space.identifier);
            relatedRecordCounts.workOrderCount = workOrderService.getWorkOrdersByRoomId(space.getId()).size();
        }

        return relatedRecordCounts;
    }

    public List<DrawingSummary> getDrawingSummariesWithFloorPlans() {
        List<Floor> floors = microservice.getFloorsWithFloorPlans();
        List<DrawingSummary> results = new ArrayList<>();

        for (Floor floor : floors) {
            results.add(getDrawingSummaryForFloor(floor));
        }

        return results;
    }

    public List<DrawingSummary> getDrawingSummariesWithoutFloorPlans() {
        List<Floor> floors = microservice.getFloorsWithoutFloorPlans();
        List<DrawingSummary> results = new ArrayList<>();

        for (Floor floor : floors) {
            results.add(getDrawingSummaryForFloor(floor));
        }

        return results;
    }

    public List<DrawingSummary> getDrawingSummariesWithOutdatedDiscrepancies() {
        List<Floor> floors = microservice.getFloorsWithOutdatedDiscrepancies();
        List<DrawingSummary> results = new ArrayList<>();

        for (Floor floor : floors) {
            results.add(getDrawingSummaryForFloor(floor));
        }

        return results;
    }

    public List<DrawingSummary> getDrawingSummariesWithDiscrepancyTypes(List<String> discrepancyTypes) {
        List<Floor> floors = microservice.getFloorsWithDiscrepancyTypes(discrepancyTypes);
        List<DrawingSummary> results = new ArrayList<>();

        for (Floor floor : floors) {
            results.add(getDrawingSummaryForFloor(floor));
        }

        return results;
    }

    public List<Space> getRoomsFromDrawing(String floorId) {
        Floor floor = spaceManagementService.getFloorById(floorId);
        List<Space> spaces = new ArrayList<>();

        if (floor != null && floor.drawing != null) {
            CommonUploadedFile commonUploadedFile = fileManagerAdminService.download(floor.drawing.fileRef.fileId);
            spaces = microservice.getRoomsFromDrawing(commonUploadedFile.getFile());
        }

        return spaces;
    }

    public int getActiveDrawingCountBySpaceId(String spaceId) {
        int drawingCount = 0;
        if (spaceId != null) {
            Space space = spaceManagementService.getRoomById(spaceId);

            if (space != null && space.floorRef != null && space.floorRef.id != null) {
                Floor floor = spaceManagementService.getFloorById(space.floorRef.id);

                if (floor != null && floor.drawing != null) {
                    drawingCount++;
                }
            }
        }

        return drawingCount;
    }

    public int getActiveDrawingCountBySpaceIds(List<String> spaceIds) {
        int drawingCount = 0;

        for (String spaceId : spaceIds) {
            drawingCount += getActiveDrawingCountBySpaceId(spaceId);

        }

        return drawingCount;
    }

    public List<GraphicalSearchRecord> getGraphicalSearchRecordsByRoomIds(List<String> roomIds) {
        return spaceManagementService.getGraphicalSearchRecordsByRoomIds(roomIds);
    }

    public Floor getFloorById(String id) {
        return spaceManagementService.getFloorById(id);
    }

    public List<FloorPlanLayer> getFloorPlanLayers() {
        return drawingLookupService.getFloorPlanLayers();
    }

    private Attachment convertToAttachment(FileManager fileManager, String fileDescription) {
        Attachment attachment = new Attachment();
        attachment.fileRef = new FileRef();
        attachment.fileRef.fileId = fileManager.getId();
        attachment.fileRef.uploadDateTime = fileManager.uploadDateTime;
        attachment.fileRef.uploadedFileName = fileManager.uploadedFileName;
        attachment.fileRef.uploadedBy = fileManager.uploadedBy;
        attachment.fileRef.uploadedByName = currentUserBT.getFullName();
        attachment.fileRef.fileSize = fileManager.fileSize;
        attachment.description = fileDescription;
        return attachment;
    }
}
