package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetClassificationMicroserviceApi;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.asset.classification.Accountability;
import logicole.common.datamodels.asset.classification.AssemblyCategory;
import logicole.common.datamodels.asset.classification.AssemblyCategoryRef;
import logicole.common.datamodels.asset.classification.ClassificationRequestDashboardInfo;
import logicole.common.datamodels.asset.classification.Consultant;
import logicole.common.datamodels.asset.classification.EClassificationRequestStatus;
import logicole.common.datamodels.asset.classification.EManufacturerContactType;
import logicole.common.datamodels.asset.classification.FacilitySubsystem;
import logicole.common.datamodels.asset.classification.FacilitySubsystemRef;
import logicole.common.datamodels.asset.classification.FacilitySystem;
import logicole.common.datamodels.asset.classification.FacilitySystemRef;
import logicole.common.datamodels.asset.classification.FederalSupplyClassRef;
import logicole.common.datamodels.asset.classification.Manufacturer;
import logicole.common.datamodels.asset.classification.ManufacturerContact;
import logicole.common.datamodels.asset.classification.ManufacturerRef;
import logicole.common.datamodels.asset.classification.ManufacturerRequest;
import logicole.common.datamodels.asset.classification.Modality;
import logicole.common.datamodels.asset.classification.ModalityDTO;
import logicole.common.datamodels.asset.classification.ModalityRef;
import logicole.common.datamodels.asset.classification.Nomenclature;
import logicole.common.datamodels.asset.classification.NomenclatureClassNameRef;
import logicole.common.datamodels.asset.classification.NomenclatureForDropdown;
import logicole.common.datamodels.asset.classification.NomenclatureRef;
import logicole.common.datamodels.asset.classification.NomenclatureRequest;
import logicole.common.datamodels.asset.classification.RiskLevel;
import logicole.common.datamodels.asset.classification.Specialty;
import logicole.common.datamodels.asset.classification.Vendor;
import logicole.common.datamodels.asset.management.EAssetType;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchCriterion;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationType;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.datamodels.user.UserProfileRef;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.security.SecurityConstants;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.asset.validation.ConsultantValidator;
import logicole.gateway.services.asset.validation.ManufacturerRequestValidator;
import logicole.gateway.services.asset.validation.ManufacturerValidator;
import logicole.gateway.services.asset.validation.ModalityValidator;
import logicole.gateway.services.asset.validation.NomenclatureRequestValidator;
import logicole.gateway.services.asset.validation.NomenclatureValidator;
import logicole.gateway.services.equipment.EquipmentRequestService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.user.UserService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static logicole.common.datamodels.organization.OrganizationConstants.AGENCY_ORG_TYPE_ID;
import static logicole.common.datamodels.organization.OrganizationConstants.DEV_ORG_ID;
import static logicole.common.datamodels.organization.OrganizationConstants.ROOT_ORG_ID;

@ApplicationScoped
public class AssetClassificationService extends BaseGatewayService<IAssetClassificationMicroserviceApi> {
    private static final String ELASTIC_SEARCH_MSG = "Elastic search is not supported at this time.";
    private static final String MEDICAL_EQUIPMENT_ELEMENT = "asset-nomenclature-medical-equipment";
    private static final String REAL_PROPERTY_EQUIPMENT_ELEMENT = "asset-nomenclature";

    private static final String CONSULTANT_ROLE_ID = "618d3b20fdd89641c5b89ceb";
    private static final String MODALITY_CONSULTANT_REVIEW = "Modality Consultant";

    @Inject
    OrganizationService organizationService;
    @Inject
    NomenclatureValidator nomenclatureValidator;
    @Inject
    ManufacturerValidator manufacturerValidator;
    @Inject
    ItemService itemService;
    @Inject
    UserService userService;
    @Inject
    NomenclatureRequestValidator nomenclatureRequestValidator;
    @Inject
    ManufacturerRequestValidator manufacturerRequestValidator;
    @Inject
    ModalityValidator modalityValidator;
    @Inject
    ConsultantValidator consultantValidator;
    @Inject
    EquipmentRequestService equipmentRequestService;

    public AssetClassificationService() {
        super("Asset");
    }

    public FacilitySystem getFacilitySystemById(String id) {
        return microservice.getFacilitySystemById(id);
    }

    public List<FacilitySystem> getAllActiveFacilitySystems() {
        return microservice.getAllActiveFacilitySystems();
    }

    public FacilitySubsystem getFacilitySubsystemById(String id) {
        return microservice.getFacilitySubsystemById(id);
    }

    public List<FacilitySubsystem> getFacilitySubsystemForFacilitySystem(String facilitySystemCode) {
        return microservice.getFacilitySubsystemForFacilitySystem(facilitySystemCode);
    }

    public List<Item> getItemsByDeviceCode(String deviceCode) {
        return itemService.getItemsByDeviceCode(deviceCode);
    }

    public List<AssemblyCategory> getAssemblyCategoriesForFacilitySubsystem(String facilitySubsystemCode) {
        return microservice.getAssemblyCategoriesForFacilitySubsystem(facilitySubsystemCode);
    }

    public SearchResult<Consultant> getConsultantSearchResults(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getConsultantSearchEngine();
        List<String> elementsList = new ArrayList<>();

        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException(ELASTIC_SEARCH_MSG);
        }

        if (StringUtil.isEmptyOrNull(searchInput.searchText) ||
                searchInput.searchText.trim().length() < 3) {
            throw new ApplicationException("Search criteria must be at least 3 characters");
        }

        includeAncestrySearchCriteria(currentUserBT.getCurrentUser().profile.currentNodeRef.ancestry, searchInput);

        return microservice.getConsultantSearchResults(searchInput, elementsList);
    }

    public List<Nomenclature> getRealPropertyEquipmentNomenclatures() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        if (currentUser.profile.currentNodeRef.id.equals(DEV_ORG_ID)) {
            return microservice.getRealPropertyEquipmentNomenclatures();
        } else {
            List<String> nodeIds = Arrays.asList(currentUser.profile.currentNodeRef.ancestry.substring(1).split(","));
            return microservice.getRealPropertyEquipmentNomenclaturesByNodes(nodeIds);
        }
    }

    public List<Nomenclature> getMedicalEquipmentNomenclatures() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        if (currentUser.profile.currentNodeRef.id.equals(DEV_ORG_ID)) {
            return microservice.getMedicalEquipmentNomenclatures();
        } else {
            List<String> nodeIds = Arrays.asList(currentUser.profile.currentNodeRef.ancestry.substring(1).split(","));
            return microservice.getMedicalEquipmentNomenclaturesByNodes(nodeIds);
        }
    }

    public SearchResult<Nomenclature> getMedicalEquipmentNomenclatures(SearchInput searchInput) {
        String ancestry = currentUserBT.getCurrentUser().profile.currentNodeRef.ancestry;
        return microservice.getMedicalEquipmentNomenclatures(searchInput, ancestry);
    }

    public SearchResult<Modality> getModalitySearchResults(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getModalitySearchEngine();
        List<String> elementsList = new ArrayList<>();

        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException(ELASTIC_SEARCH_MSG);
        }

        if (StringUtil.isEmptyOrNull(searchInput.searchText) ||
                searchInput.searchText.trim().length() < 3) {
            throw new ApplicationException("Search criteria must be at least 3 characters");
        }

        includeAncestrySearchCriteria(currentUserBT.getCurrentUser().profile.currentNodeRef.ancestry, searchInput);

        return microservice.getModalitySearchResults(searchInput, elementsList);
    }

    public ModalityRef getModalityRefByNomenclatureId(String nomenclatureId) {
        return microservice.getModalityRefByNomenclatureId(nomenclatureId);
    }

    public List<ModalityRef> getModalityRefsByAgency() {
        String organizationId = currentUserBT.getCurrentUser().profile.currentNodeRef.getId();
        String agencyId = organizationService.getAncestorOrgOfOrgType(organizationId, OrganizationConstants.AGENCY_ORG_TYPE_ID).getId();
        return microservice.getModalitiesByAgency(agencyId).stream()
                .map(Modality::getRef)
                .collect(Collectors.toList());
    }

    public List<Nomenclature> getNomenclaturesForAssemblyCategory(String assemblyCategoryId) {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        if (currentUser.profile.currentNodeRef.id.equals(DEV_ORG_ID)) {
            return microservice.getNomenclaturesForAssemblyCategory(assemblyCategoryId);
        }
        else {
            List<String> nodeIds = Arrays.asList(currentUser.profile.currentNodeRef.ancestry.substring(1).split(","));
            return microservice.getNomenclaturesForAssemblyCategoryByNodes(assemblyCategoryId, nodeIds);
        }
    }

    public List<Nomenclature> getNomenclaturesByCode(String code) {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        if ((currentUser.profile.pkiDn.equalsIgnoreCase(SecurityConstants.MDB_SPECIAL_USER_PROFILE_KEY)) ||
                (currentUser.profile.currentNodeRef.id.equals(DEV_ORG_ID))) {
            return microservice.getNomenclaturesByCode(code, new ArrayList<>());
        } else {
            List<String> nodeIds = Arrays.asList(currentUser.profile.currentNodeRef.ancestry.substring(1).split(","));
            return microservice.getNomenclaturesByCode(code, nodeIds);
        }
    }

    public List<NomenclatureForDropdown> getNomenclaturesForDropdown() {
        return microservice.getNomenclaturesForDropdown();
    }

    private String getSiteIdentifier() {
        String siteIdentifier = null;
        Organization organization = organizationService.getOrganization(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if (organization.nodeTypeRef.name.equals(OrganizationType.SITE_TYPE_NAME) ||
                organization.nodeTypeRef.name.equals("Real Property Installation Site")) {
            siteIdentifier = organization.nodeIdentifier;
        } else if (organization.nodeTypeRef.name.equals(OrganizationType.DEPARTMENT_TYPE_NAME) ||
                organization.nodeTypeRef.name.equals(OrganizationType.CUSTOMER_TYPE_NAME)) {
            organization = organizationService.getAncestorOrgOfOrgType(currentUserBT.getCurrentNodeId(), OrganizationType.SITE_TYPE_NAME);
            siteIdentifier = organization.nodeIdentifier;
        }

        return siteIdentifier;
    }

    public void processModalityRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processModalityRefUpdate(dataReferenceUpdate);
    }

    public int updateUserProfileRef(UserProfileRef userProfileRef) throws IOException {
        return microservice.updateUserProfileRef(userProfileRef);
    }

    public Nomenclature getNomenclatureById(String id) {
        return microservice.getNomenclatureById(id);
    }

    public Nomenclature updateNomenclature(Nomenclature nomenclature) {
        nomenclature.updatedDateTime = new Date();
        nomenclature.updatedBy = currentUserBT.getFullName();
        nomenclatureValidator.validate(nomenclature, currentUserBT.getCurrentNodeId());
        return microservice.updateNomenclature(nomenclature);
    }

    public void loadNomenclature(Nomenclature nomenclature) {
        microservice.loadNomenclature(nomenclature);
    }

    public void deleteNomenclature(String nomenclatureId) {
        microservice.deleteNomenclature(nomenclatureId);
    }

    private void includeAncestrySearchCriteria(String ancestry, SearchInput searchInput) {
        if (searchInput == null) {
            searchInput = new SearchInput();
        }

        if (searchInput.searchCriteria == null) {
            searchInput.searchCriteria = new ArrayList<>();
        }

        List<String> ancestors = new ArrayList<>();

        if (!StringUtil.isEmptyOrNull(ancestry)) {
            ancestors = Arrays.asList(ancestry.substring(1).split(","));
        }

        if (!OrganizationConstants.isRootOrDevUser(currentUserBT.getCurrentUser().profile.currentNodeRef.id) && !ancestors.isEmpty()) {
            SearchCriterion searchCriterion = new SearchCriterion();
            searchCriterion.propName = "managedBy";
            searchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
            searchCriterion.propValues = ancestors.toArray();
            if (searchInput.searchCriteria == null) {
                searchInput.searchCriteria = new ArrayList<>();
            }
            searchInput.searchCriteria.add(searchCriterion);
        }
    }

    public SearchResult<Nomenclature> getNomenclatureSearchResults(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getNomenclatureSearchEngine();
        List<String> elementsList = new ArrayList<>();

        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException(ELASTIC_SEARCH_MSG);
        }

        if (StringUtil.isEmptyOrNull(searchInput.searchText) ||
                searchInput.searchText.trim().length() < 3) {
            throw new ApplicationException("Search criteria must be at least 3 characters");
        }

        includeAncestrySearchCriteria(currentUserBT.getCurrentUser().profile.currentNodeRef.ancestry, searchInput);

        if (doesElementExistOnProfile(MEDICAL_EQUIPMENT_ELEMENT)) {
            elementsList.add(MEDICAL_EQUIPMENT_ELEMENT);
        }

        if (doesElementExistOnProfile(REAL_PROPERTY_EQUIPMENT_ELEMENT)) {
            elementsList.add(REAL_PROPERTY_EQUIPMENT_ELEMENT);
        }

        return microservice.getNomenclatureSearchResults(searchInput, elementsList);
    }

    public NomenclatureRequest getNomenclatureRequestById(String id) {
        return microservice.getNomenclatureRequestById(id);
    }

    public ManufacturerRequest removeManufacturerRequestNote(String id, Note note) {
        return microservice.removeManufacturerRequestNote(id, note);
    }

    public NomenclatureRequest removeNomenclatureRequestNote(String id, Note note) {
        return microservice.removeNomenclatureRequestNote(id, note);
    }

    public ManufacturerRequest saveManufacturerRequestNote(String id, Note note) {
        return microservice.saveManufacturerRequestNote(id, note);
    }

    public NomenclatureRequest saveNomenclatureRequestNote(String id, Note note) {
        return microservice.saveNomenclatureRequestNote(id, note);
    }

    public NomenclatureRequest getNomenclatureRequestByCode(String code) {
        return microservice.getNomenclatureRequestByCode(code);
    }

    public NomenclatureRequest getNomenclatureRequestByText(String text) {
        return microservice.getNomenclatureRequestByText(text);
    }

    NomenclatureRequest updateNomenclatureRequest(NomenclatureRequest nomenclatureRequest) {
        nomenclatureRequest.updatedDateTime = new Date();
        nomenclatureRequest.updatedBy = currentUserBT.getFullName();
        nomenclatureRequestValidator.validateReworkStatusAndScope(nomenclatureRequest.getId(), currentUserBT.getCurrentNodeId());
        nomenclatureRequestValidator.validate(nomenclatureRequest, currentUserBT.getCurrentNodeId());
        return microservice.updateNomenclatureRequest(nomenclatureRequest);
    }

    Nomenclature acceptNomenclatureRequest(String id) {
        NomenclatureRequest nomenclatureRequest = getNomenclatureRequestById(id);
        nomenclatureRequestValidator.validate(nomenclatureRequest, currentUserBT.getCurrentNodeId());
        UserProfile currentUserProfile = currentUserBT.getCurrentUser().profile;

        Nomenclature nomenclature = new Nomenclature();
        nomenclature.assetType = EAssetType.MEDICAL_EQUIPMENT;
        nomenclature.fsiNomenSerial = null;
        nomenclature.nomenclatureCode = nomenclatureRequest.nomenclatureCode;
        nomenclature.nomenclatureText = nomenclatureRequest.nomenclatureText;
        nomenclature.accountabilityCode = nomenclatureRequest.accountabilityCode;
        nomenclature.accountabilityDescription = nomenclatureRequest.accountabilityDescription;
        nomenclature.isMaintenanceRequired = nomenclatureRequest.isMaintenanceRequired;
        nomenclature.lifeExpectancyYearsQty = nomenclatureRequest.lifeExpectancyYearsQty;
        nomenclature.riskLevel = nomenclatureRequest.riskLevel;
        nomenclature.isActive = true;
        nomenclature.deviceDefinition = nomenclatureRequest.deviceDefinition;
        nomenclature.updatedDateTime = new Date();
        nomenclature.updatedBy = currentUserProfile.getFullName();
        nomenclature.managedByNodeRef = currentUserProfile.currentNodeRef;
        nomenclature.specialtyRefs = nomenclatureRequest.specialtyRefs;
        nomenclature.nomenclatureClassNameRef = nomenclatureRequest.nomenclatureClassNameRef;
        microservice.saveNomenclature(nomenclature);

        nomenclatureRequest.updatedDateTime = new Date();
        nomenclatureRequest.updatedBy = currentUserProfile.getFullName();
        nomenclatureRequest.status = EClassificationRequestStatus.ACCEPTED;
        nomenclatureRequest.reviewedBy = currentUserProfile.getRef();
        nomenclatureRequest.reviewedDateTime = new Date();
        microservice.updateNomenclatureRequest(nomenclatureRequest);

        return nomenclature;
    }

    ManufacturerRequest rejectManufacturerRequest(String id, String reason) {
        return microservice.rejectManufacturerRequest(id, reason);
    }

    NomenclatureRequest rejectNomenclatureRequest(String id, String reason) {
        return microservice.rejectNomenclatureRequest(id, reason);
    }

    List<ManufacturerRef> getManufacturerRefsExcludingCurrentRecord(String id) {
        return microservice.getManufacturerRefsExcludingCurrentRecord(id);
    }

    List<ManufacturerRef> getAllManufacturerRefs() {
        String organizationId = currentUserBT.getCurrentUser().profile.currentNodeRef.getId();
        Organization agencyOrg = organizationService.getAncestorOrgOfOrgType(organizationId, OrganizationConstants.AGENCY_ORG_TYPE_ID);
        return microservice.getAllManufacturerRefs(agencyOrg.getId());
    }

    Manufacturer getManufacturerById(String id) {
        return microservice.getManufacturerById(id);
    }

    Manufacturer getManufacturerByManufacturerCode(String manufacturerCode) {
        return microservice.getManufacturerByManufacturerCode(manufacturerCode);
    }

    Manufacturer getManufacturerByCageCode(String cageCode) {
        return microservice.getManufacturerByCageCode(cageCode);
    }

    Manufacturer getManufacturerByDunsCode(String dunsCode) {
        return microservice.getManufacturerByDunsCode(dunsCode);
    }

    SearchResult<Manufacturer> getManufacturerSearchResults(SearchInput searchCriteria) {
        ESearchEngine searchEngine = microservice.getManufacturerSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException(ELASTIC_SEARCH_MSG);
        }

        if (StringUtil.isEmptyOrNull(searchCriteria.searchText) ||
                searchCriteria.searchText.trim().length() < 3) {
            throw new ApplicationException("Search criteria must be at least 3 characters");
        }

        includeAncestrySearchCriteria(currentUserBT.getCurrentUser().profile.currentNodeRef.ancestry, searchCriteria);

        return microservice.getManufacturerSearchResults(searchCriteria);
    }

    Manufacturer updateManufacturer(Manufacturer manufacturer) {
        manufacturer.updatedDateTime = new Date();
        manufacturer.updatedBy = currentUserBT.getFullName();
        manufacturerValidator.validate(manufacturer, currentUserBT.getCurrentNodeId());
        return microservice.updateManufacturer(manufacturer);
    }

    public Manufacturer createManufacturer(Manufacturer manufacturer) {
        manufacturer.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        manufacturer.isActive = true;
        manufacturer.updatedDateTime = new Date();
        manufacturer.updatedBy = currentUserBT.getFullName();
        manufacturerValidator.validate(manufacturer, currentUserBT.getCurrentNodeId());
        return microservice.saveManufacturer(manufacturer);
    }

    public Manufacturer getManufacturerByNames(String name, String id) {
        return microservice.getManufacturerByNames(name, id);
    }

    public Manufacturer getManufacturerByNameCodeAndOrg(String name, String code, String organizationId) {
        return microservice.getManufacturerByNameCodeAndOrg(name, code, organizationId);
    }

    public Manufacturer getManufacturerByCageCodeAndOrg(String cageCode, String organizationId) {
        return microservice.getManufacturerByCageCodeAndOrg(cageCode, organizationId);
    }

    public Manufacturer getManufacturerByDunsCodeAndOrg(String dunsCode, String organizationId) {
        return microservice.getManufacturerByDunsCodeAndOrg(dunsCode, organizationId);
    }

    public ManufacturerRequest getManufacturerRequestByManufacturerCodeAndOrg(String manufacturerCode, String organizationId) {
        return microservice.getManufacturerRequestByManufacturerCodeAndOrg(manufacturerCode, organizationId);
    }

    public ManufacturerRequest getManufacturerRequestByCageCodeAndOrg(String cageCode, String organizationId) {
        return microservice.getManufacturerRequestByCageCodeAndOrg(cageCode, organizationId);
    }

    public ManufacturerRequest getManufacturerRequestByDunsCodeAndOrg(String dunsCode, String organizationId) {
        return microservice.getManufacturerRequestByDunsCodeAndOrg(dunsCode, organizationId);
    }

    public ManufacturerRequest getManufacturerRequestById(String id) {
        return microservice.getManufacturerRequestById(id);
    }

    List<ManufacturerRequest> getAllHistoricalManufacturerRequests(String activeFilter) {
        return microservice.getAllHistoricalManufacturerRequests(activeFilter);
    }

    List<NomenclatureRequest> getAllHistoricalNomenclatureRequests(String activeFilter) {
        return microservice.getAllHistoricalNomenclatureRequests(activeFilter);
    }

    List<ManufacturerRequest> getAllOutstandingManufacturerRequests(String activeFilter, String type) {
        return microservice.getAllOutstandingManufacturerRequests(activeFilter, type);
    }

    List<NomenclatureRequest> getAllOutstandingNomenclatureRequests(String activeFilter, String type) {
        return microservice.getAllOutstandingNomenclatureRequests(activeFilter, type);
    }

    ManufacturerRequest updateManufacturerRequest(ManufacturerRequest manufacturerRequest) {
        manufacturerRequest.updatedDateTime = new Date();
        manufacturerRequest.updatedBy = currentUserBT.getFullName();
        manufacturerRequestValidator.validateReworkStatusAndScope(manufacturerRequest.getId(), currentUserBT.getCurrentNodeId());
        manufacturerRequestValidator.validateManufacturerRequest(manufacturerRequest, currentUserBT.getCurrentNodeId());
        return microservice.updateManufacturerRequest(manufacturerRequest);
    }

    Manufacturer acceptManufacturerRequest(String id) {
        ManufacturerRequest manufacturerRequest = getManufacturerRequestById(id);
        manufacturerRequestValidator.validateManufacturerRequest(manufacturerRequest, currentUserBT.getCurrentNodeId());
        UserProfile currentUserProfile = currentUserBT.getCurrentUser().profile;

        Manufacturer manufacturer = new Manufacturer();
        manufacturer.manufacturerName = manufacturerRequest.manufacturerName;
        manufacturer.isActive = true;
        manufacturer.phoneNumber = manufacturerRequest.phoneNumber;
        manufacturer.secondaryPhoneNumber = manufacturerRequest.secondaryPhoneNumber;
        manufacturer.faxNumber = manufacturerRequest.faxNumber;
        manufacturer.emailAddress = manufacturerRequest.emailAddress;
        manufacturer.website = manufacturerRequest.website;
        manufacturer.manufacturerCode = manufacturerRequest.manufacturerCode;
        manufacturer.cageCode = manufacturerRequest.cageCode;
        manufacturer.dunsCode = manufacturerRequest.dunsCode;
        manufacturer.dunsPlus4 = manufacturerRequest.dunsPlus4;
        manufacturer.address = manufacturerRequest.address;
        manufacturer.isActiveInEcri = manufacturerRequest.isActiveInEcri;
        manufacturer.previousManufacturerRef = manufacturerRequest.previousManufacturerRef;
        manufacturer.updatedDateTime = new Date();
        manufacturer.updatedBy = currentUserProfile.getFullName();
        manufacturer.managedByNodeRef = currentUserProfile.currentNodeRef;
        microservice.saveManufacturer(manufacturer);

        manufacturerRequest.updatedDateTime = new Date();
        manufacturerRequest.updatedBy = currentUserProfile.getFullName();
        manufacturerRequest.status = EClassificationRequestStatus.ACCEPTED;
        manufacturerRequest.reviewedBy = currentUserProfile.getRef();
        manufacturerRequest.reviewedDateTime = new Date();
        microservice.updateManufacturerRequest(manufacturerRequest);

        return manufacturer;
    }

    public void updateAssemblyCategoryRefsInNomenclatures(AssemblyCategoryRef assemblyCategoryRef) {
        microservice.updateAssemblyCategoryRefsInNomenclatures(assemblyCategoryRef);
    }

    public void updateFacilitySubsystemRefInNomenclatures(FacilitySubsystemRef facilitySubsystemRef) {
        microservice.updateFacilitySubsystemRefInNomenclatures(facilitySubsystemRef);
    }

    public void updateFacilitySystemRefInNomenclature(FacilitySystemRef facilitySystemRef) {
        microservice.updateFacilitySystemRefInNomenclature(facilitySystemRef);
    }

    public void updateManufacturerRefs(ManufacturerRef manufacturerRef) {
        microservice.updateManufacturerRefs(manufacturerRef);
    }

    List<Specialty> getAllSpecialtyRecords() {
        return microservice.getAllSpecialtyRecords();
    }

    List<RiskLevel> getAllRiskLevelRecords() {
        return microservice.getAllRiskLevelRecords();
    }

    List<Accountability> getAllAccountabilityRecords() {
        return microservice.getAllAccountabilityRecords();
    }

    List<Vendor> getVendorList() {
        String siteIdentifier = getSiteIdentifier();
        return microservice.getVendorList(siteIdentifier);
    }

    public FacilitySystem updateFacilitySystem(FacilitySystem facilitySystem) {
        return microservice.updateFacilitySystem(facilitySystem);
    }

    public FacilitySubsystem updateFacilitySubsystem(FacilitySubsystem facilitySubsystem) {
        return microservice.updateFacilitySubsystem(facilitySubsystem);
    }

    public ClassificationRequestDashboardInfo getClassificationRequestDashboardStats() {
        return microservice.getClassificationRequestDashboardStats();
    }

    public NomenclatureRequest reworkNomenclatureRequest(String id, String reason) {
        if (OrganizationConstants.SITE_ORG_TYPE_ID.equals(currentUserBT.getCurrentUser().profile.nodeTypeRef.getId())) {
            nomenclatureRequestValidator.validateAccess(id, currentUserBT.getCurrentNodeId());
        }
        return microservice.reworkNomenclatureRequest(id, reason);
    }

    public ManufacturerRequest reworkManufacturerRequest(String id, String reason) {
        if (OrganizationConstants.SITE_ORG_TYPE_ID.equals(currentUserBT.getCurrentUser().profile.nodeTypeRef.getId())) {
            manufacturerRequestValidator.validateAccess(id, currentUserBT.getCurrentNodeId());
        }
        return microservice.reworkManufacturerRequest(id, reason);
    }

    public ManufacturerRequest cancelManufacturerRequest(String id, String reason) {
        return microservice.cancelManufacturerRequest(id, reason);
    }

    public NomenclatureRequest cancelNomenclatureRequest(String id, String reason) {
        return microservice.cancelNomenclatureRequest(id, reason);
    }

    public ManufacturerRequest submitManufacturerRequestForReview(ManufacturerRequest manufacturerRequest) {
        if (manufacturerRequest.getId() == null) {
            manufacturerRequest.enteredBy = currentUserBT.getCurrentUser().profile.getRef();
            manufacturerRequest.enteredDateTime = new Date();
            manufacturerRequest.isActive = true;
            manufacturerRequest.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        } else {
            manufacturerRequestValidator.validateReworkStatusAndScope(manufacturerRequest.getId(), currentUserBT.getCurrentNodeId());
        }

        manufacturerRequest.status = EClassificationRequestStatus.SUBMITTED_FOR_REVIEW;
        manufacturerRequest.updatedBy = currentUserBT.getFullName();
        manufacturerRequest.updatedDateTime = new Date();

        manufacturerRequestValidator.validateManufacturerRequest(manufacturerRequest, currentUserBT.getCurrentNodeId());
        return microservice.submitManufacturerRequestForReview(manufacturerRequest);
    }

    public NomenclatureRequest submitNomenclatureRequestForReview(NomenclatureRequest nomenclatureRequest) {
        if (nomenclatureRequest.getId() == null) {
            nomenclatureRequest.enteredBy = currentUserBT.getCurrentUser().profile.getRef();
            nomenclatureRequest.enteredDateTime = new Date();
            nomenclatureRequest.isActive = true;
            nomenclatureRequest.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        } else {
            nomenclatureRequestValidator.validateReworkStatusAndScope(nomenclatureRequest.getId(), currentUserBT.getCurrentNodeId());
        }

        nomenclatureRequest.status = EClassificationRequestStatus.SUBMITTED_FOR_REVIEW;
        nomenclatureRequest.updatedBy = currentUserBT.getFullName();
        nomenclatureRequest.updatedDateTime = new Date();

        nomenclatureRequestValidator.validate(nomenclatureRequest, currentUserBT.getCurrentNodeId());
        return microservice.submitNomenclatureRequestForReview(nomenclatureRequest);
    }

    public ManufacturerRequest saveManufacturerRequestComment(String id, String serviceOrgId, String comment) {
        return microservice.saveManufacturerRequestComment(id, serviceOrgId, comment);
    }

    public ManufacturerRequest deleteManufacturerRequestComment(String id, String serviceOrgId, String commentId) {
        return microservice.deleteManufacturerRequestComment(id, serviceOrgId, commentId);
    }

    public NomenclatureRequest saveNomenclatureRequestComment(String id, String serviceOrgId, String comment) {
        return microservice.saveNomenclatureRequestComment(id, serviceOrgId, comment);
    }

    public NomenclatureRequest deleteNomenclatureRequestComment(String id, String serviceOrgId, String commentId) {
        return microservice.deleteNomenclatureRequestComment(id, serviceOrgId, commentId);
    }

    // Use getNomenclatureByCodeTypeAndOrg() instead so it has ancestry query
    // Can remove when all calls to it are removed
    public Nomenclature getNomenclatureByCodeAndType(String code, String type) {
        return microservice.getNomenclatureByCodeAndType(code, type);
    }

    // Retrieve Nomenclatures managedBy a particular Org
    public Nomenclature getNomenclatureByCodeTypeAndOrg(String code, String type, String orgId) {
        return microservice.getNomenclatureByCodeTypeAndOrg(code, type, orgId);
    }

    // Retrieve Nomenclatures managedBy any Org in the current user's node ancestry
    public Nomenclature getNomenclatureByCodeTypeAndOrg(String code, String type, OrganizationRef org) {
        return microservice.getNomenclatureByCodeTypeAndOrg(code, type, org);
    }

    public List<NomenclatureRef> getNomenclatureRefsByUserAgency() {
        UserProfile currentUserProfile = currentUserBT.getCurrentUser().profile;
        String currentNodeRefId = currentUserProfile.currentNodeRef.id;
        List<String> orgIds;
        if (currentNodeRefId.equals(ROOT_ORG_ID) || currentNodeRefId.equals(DEV_ORG_ID)) {
            List<String> agencyOrgType = List.of(AGENCY_ORG_TYPE_ID);
            orgIds = organizationService.getAllOrganizationsByNodeTypeIds(agencyOrgType).stream()
                    .map(Organization::getId)
                    .collect(Collectors.toList());
        } else {
            Organization agencyOrg = organizationService.getAncestorOrgOfOrgType(currentNodeRefId, AGENCY_ORG_TYPE_ID);
            String agencyOrgId = (agencyOrg != null)
                    ? agencyOrg.getId()
                    : null;
            orgIds = List.of(agencyOrgId);
        }
        List<Nomenclature> nomenclatures = microservice.getNomenclaturesByOrgIds(orgIds);
        List<NomenclatureRef> nomenclatureRefs = nomenclatures.stream()
                .map(Nomenclature::getRef)
                .collect(Collectors.toList());

        return nomenclatureRefs;
    }

    public NomenclatureRef getNomenclatureRefByTextAndOrg(String text, String organizationId) {
        return microservice.getNomenclatureRefByTextAndOrg(text, organizationId);
    }

    public Nomenclature createNomenclature(Nomenclature nomenclature) {
        nomenclature.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        nomenclature.isActive = true;
        nomenclature.updatedDateTime = new Date();
        nomenclature.updatedBy = currentUserBT.getFullName();
        nomenclatureValidator.validate(nomenclature, currentUserBT.getCurrentNodeId());
        return microservice.saveNomenclature(nomenclature);
    }

    public List<FederalSupplyClassRef> getFederalSupplyClass() {
        return microservice.getFederalSupplyClass();
    }

    public List<NomenclatureClassNameRef> getNomenclatureClassNames() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        if (currentUser.profile.currentNodeRef.id.equals(DEV_ORG_ID)) {
            return microservice.getNomenclatureClassNames(new ArrayList<>());
        } else {
            List<String> nodeIds = Arrays.asList(currentUser.profile.currentNodeRef.ancestry.substring(1).split(","));
            return microservice.getNomenclatureClassNames(nodeIds);
        }
    }

    private boolean doesElementExistOnProfile(String elementName) {
        boolean doesExist = false;
        List<String> userElementsList = getUserElements();

        for (String element : userElementsList) {
            if (element.equalsIgnoreCase(elementName)) {
                doesExist = true;
                break;
            }
        }

        return doesExist;
    }

    private List<String> getUserElements() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser.elements;
    }

    public Nomenclature setNomenclatureIsActive(String id, boolean isActive) {
        return microservice.setNomenclatureIsActive(id, isActive);
    }

    public Manufacturer setManufacturerIsActive(String id, boolean isActive) {
        return microservice.setManufacturerIsActive(id, isActive);
    }

    public ManufacturerContact saveManufacturerContact(ManufacturerContact contact) {
        if (StringUtil.isEmptyOrNull(contact.getId())) {
            contact.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        }
        return microservice.saveManufacturerContact(contact);
    }

    public List<ManufacturerContact> getManufacturerContacts(String manufacturerId) {
        Organization siteOrg = organizationService.getAncestorOrgOfOrgType(
                currentUserBT.getCurrentNodeId(), OrganizationConstants.SITE_ORG_TYPE_ID);
        String siteId = (siteOrg != null) ? siteOrg.getId() : "";
        return microservice.getManufacturerContacts(manufacturerId, siteId);
    }

    public boolean removeManufacturerContact(String manufacturerContactId) {
        return microservice.removeManufacturerContact(manufacturerContactId);
    }

    public ManufacturerContact saveManufacturerContactNote(String id, Note note) {
        return microservice.saveManufacturerContactNote(id, note);
    }

    public ManufacturerContact removeManufacturerContactNote(String id, Note note) {
        return microservice.removeManufacturerContactNote(id, note);
    }

    public List<String> getManufacturerContactTypes() {
        return EManufacturerContactType.getDisplayTextList();
    }

    public Modality getModalityById(String id) {
        return microservice.getModalityById(id);
    }

    public Modality getModalityByNameAndOrg(String name, String orgId) {
        return microservice.getModalityByNameAndOrg(name, orgId);
    }

    public Modality createModality(ModalityDTO modalityDTO) {
        modalityDTO.modality.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        modalityDTO.modality.isActive = true;
        modalityDTO.modality.revisedBy = currentUserBT.getFullName();
        modalityDTO.modality.revisedByDate = new Date();
        modalityValidator.validate(modalityDTO.modality, currentUserBT.getCurrentNodeId());
        return microservice.createModality(modalityDTO);
    }

    public Modality saveModality(ModalityDTO modalityDTO) {
        List<Consultant> persistedConsultants = getAllConsultantsByModality(modalityDTO.modality.getId());

        List<Consultant> consultantsBeingRemoved = new ArrayList<>();
        if (!persistedConsultants.isEmpty()) {
            consultantsBeingRemoved = persistedConsultants.stream()
                    .filter(consultant -> modalityDTO.consultantIds.stream()
                            .noneMatch(id -> id.equals(consultant.getId())))
                    .collect(Collectors.toList());
        }

        if (!consultantsBeingRemoved.isEmpty()) {
            modalityValidator.validateConsultantsInActiveNERs(modalityDTO.modality.getId(), consultantsBeingRemoved, currentUserBT.getCurrentNodeId());
        }

        modalityDTO.modality.revisedBy = currentUserBT.getFullName();
        modalityDTO.modality.revisedByDate = new Date();
        modalityValidator.validate(modalityDTO.modality, currentUserBT.getCurrentNodeId());
        return microservice.saveModality(modalityDTO);
    }

    public List<Nomenclature> getNomenclaturesWithoutModality() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        if ((currentUser.profile.pkiDn.equalsIgnoreCase(SecurityConstants.MDB_SPECIAL_USER_PROFILE_KEY)) ||
                (currentUser.profile.currentNodeRef.id.equals(DEV_ORG_ID))) {
            return microservice.getNomenclaturesWithoutModality(new ArrayList<>());
        } else {
            List<String> nodeIds = Arrays.asList(currentUser.profile.currentNodeRef.ancestry.substring(1).split(","));
            return microservice.getNomenclaturesWithoutModality(nodeIds);
        }
    }

    public List<Nomenclature> getNomenclaturesByModality(String modalityId) {
        return microservice.getNomenclaturesByModality(modalityId);
    }

    public int getNomenclatureCountByModalityId(String modalityId) {
        List<Nomenclature> nomenclatureList =  this.getNomenclaturesByModality(modalityId);
        return (nomenclatureList != null) ? nomenclatureList.size() : 0;
    }

    public Modality setModalityIsActive(String id, boolean isActive) {
        if (!isActive) {
            ModalityRef modalityRef = this.getModalityById(id).getRef();
            modalityValidator.validateActiveNERs(id, currentUserBT.getCurrentNodeId());
            microservice.deleteNomenclatureModalityRef(modalityRef);
            microservice.deleteConsultantModalityRef(modalityRef);
        }
        return microservice.setModalityIsActive(id, isActive);
    }

    public List<Consultant> getActiveConsultantsByModality(String modalityId) {
        return microservice.getActiveConsultantsByModality(modalityId);
    }

    public List<Consultant> getAllConsultantsByModality(String modalityId) {
        return microservice.getAllConsultantsByModality(modalityId);
    }

    public List<Consultant> getAllActiveConsultantsByOrg() {
        String nodeId = currentUserBT.getCurrentNodeId();
        return microservice.getAllActiveConsultantsByOrg(nodeId);
    }

    public Consultant getConsultantById(String id) {
        return microservice.getConsultantById(id);
    }

    public List<UserProfile> getPotentialConsultantUserProfiles() {
        String nodeId = currentUserBT.getCurrentNodeId();
        List<UserProfile> userProfiles = userService.getUsersAtNodeWithRole(nodeId, CONSULTANT_ROLE_ID);
        List<Consultant> consultants = microservice.getAllConsultantsByOrg(nodeId);

        Comparator<UserProfile> byLastName = Comparator.comparing(user->user.lastName);
        // Filter out profiles that have already been added to a Consultant record
        return userProfiles.stream()
                .filter(profile -> consultants.stream()
                        .noneMatch(consultant -> consultant.userProfileRef.getId().equals(profile.getId())))
                .sorted(byLastName)
                .collect(Collectors.toList());
    }

    public Consultant createConsultant(Consultant consultant) {
        consultant.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        consultant.isActive = true;
        consultantValidator.validate(consultant, currentUserBT.getCurrentNodeId());
        return microservice.createConsultant(consultant);
    }

    public Consultant saveConsultant(Consultant consultant) {
        Consultant persistedConsultant = getConsultantById(consultant.getId());
        List<ModalityRef> persistedModalityRefs = persistedConsultant.modalityRefs;
        List<ModalityRef> modalitiesBeingRemoved = new ArrayList<>();
        if (!persistedModalityRefs.isEmpty()) {
            modalitiesBeingRemoved = persistedModalityRefs.stream()
                    .filter(modalityRef -> consultant.modalityRefs.stream()
                            .noneMatch(modalityRef1 -> modalityRef1.getId().equals(modalityRef.getId())))
                    .collect(Collectors.toList());
        }

        if (!modalitiesBeingRemoved.isEmpty()) {
            for (ModalityRef modalityRef : modalitiesBeingRemoved) {
                consultantValidator.validateActiveNERs(modalityRef, currentUserBT.getCurrentNodeId());
            }
        }

        consultantValidator.validate(consultant, currentUserBT.getCurrentNodeId());
        // Check if the name was changed and update any NERs associated to the consultant
        Consultant existingConsultant = microservice.getConsultantById(consultant.getId());
        if (existingConsultant != null && !existingConsultant.userProfileRef.getId().equals(consultant.userProfileRef.getId())) {
            equipmentRequestService.updateReviewSelectedUser(existingConsultant.userProfileRef.getId(), consultant.userProfileRef.getId(), MODALITY_CONSULTANT_REVIEW);
        }
        return microservice.saveConsultant(consultant);
    }

    public Consultant getConsultantByProfileIdAndOrg(String userProfileId, String orgId) {
        return microservice.getConsultantByProfileIdAndOrg(userProfileId, orgId);
    }

    public Boolean getHasConsultantsByModalityAndOrg(String modalityId, String orgId) {
        String agencyId = organizationService.getAncestorOrgOfOrgType(orgId, OrganizationConstants.AGENCY_ORG_TYPE_ID).getId();
        return microservice.getHasConsultantsByModalityAndOrg(modalityId, agencyId);
    }

    public Consultant setConsultantIsActive(String id, boolean isActive) {
        Consultant consultant = microservice.setConsultantIsActive(id, isActive);
        // Set any NER reviews to recall status if they are not complete
        if (!consultant.isActive) {
            equipmentRequestService.recallReviewsByReviewer(consultant.userProfileRef.getId(), MODALITY_CONSULTANT_REVIEW);
        }
        return consultant;
    }
}
