package logicole.gateway.services.asset;

import logicole.apis.asset.IBusinessContactMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class BusinessContactMicroserviceClient extends MicroserviceClient<IBusinessContactMicroserviceApi> {
    public BusinessContactMicroserviceClient() {
        super(IBusinessContactMicroserviceApi.class, "logicole-asset");
    }

    @Produces
    public IBusinessContactMicroserviceApi getIBusinessContactMicroserviceApi() {
        return createClient();
    }
}
