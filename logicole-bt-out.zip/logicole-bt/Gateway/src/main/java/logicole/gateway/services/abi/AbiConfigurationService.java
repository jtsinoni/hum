package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiConfigurationMicroserviceApi;
import logicole.common.datamodels.Configuration;
import logicole.common.datamodels.abi.ABiConfigurationSettings;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class AbiConfigurationService extends BaseGatewayService<IAbiConfigurationMicroserviceApi> {

    public AbiConfigurationService() {
        super("AbiConfiguration");
    }

    public ABiConfigurationSettings getABiConfigurationSettings() {
        return microservice.getABiConfigurationSettings();
    }

    public Boolean updateABiConfigurationSettings(ABiConfigurationSettings settings) {
        return microservice.updateABiConfigurationSettings(settings);
    }

    public List<Configuration> getAllConfigurations() {
        return microservice.getAllConfigurations();
    }

    public Configuration addUpdateConfiguration(Configuration configuration) {
        return microservice.addUpdateConfiguration(configuration);
    }

    public Configuration getConfiguration(String id) {
        return microservice.getConfiguration(id);
    }

    public Configuration getConfigurationByName(String name) {
        return microservice.getConfigurationByName(name);
    }

    public String getGhxExtractUploadRelativePath() {
        return microservice.getGhxExtractUploadRelativePath();
    }

    public String getScriptProExtractUploadRelativePath() {
        return microservice.getScriptProExtractUploadRelativePath();
    }

    public String getItemResearchUploadRelativePath() {
        return microservice.getItemResearchUploadRelativePath();
    }

    public String getAbiTempDirectory() {
        return microservice.getAbiTempDirectory();
    }

    public List<String> getDocumentTypes() {
        return microservice.getDocumentTypes();
    }

}
