package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiToSiteRecordLinkMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiToSiteRecordLinkMicroserviceClient extends MicroserviceClient<IAbiToSiteRecordLinkMicroserviceApi> {
    public AbiToSiteRecordLinkMicroserviceClient() {
        super(IAbiToSiteRecordLinkMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiToSiteRecordLinkMicroserviceApi getABiToSiteRecordLinkService() {
        return createClient();
    }
}

