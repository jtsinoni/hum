package logicole.gateway.services.spacemanagement;

import logicole.apis.space.ICOBieMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class COBieMicroserviceClient extends MicroserviceClient<ICOBieMicroserviceApi> {
    public COBieMicroserviceClient() {
        super(ICOBieMicroserviceApi.class, "logicole-space-management");
    }

    @Produces
    public ICOBieMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
