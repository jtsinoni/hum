package logicole.gateway.services.assemblage;

import io.swagger.annotations.*;
import logicole.common.datamodels.assemblage.AssemblageInfo;
import logicole.common.datamodels.assemblage.AllowanceImport;
import logicole.common.datamodels.assemblage.AllowanceItemImport;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;

import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Api(tags = {"AllowanceImport"})
@ApplicationScoped
@Path("/allowanceImport")
public class AllowanceImportRestApi extends ExternalRestApi<AllowanceImportService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getMaxFileSize")
    public int getMaxFileSize() {
        return service.getMaxFileSize();
    }

    @GET
    @Path("/getAllowanceImports")
    public List<AllowanceImport> getAllowanceImports() {
        return service.getAllowanceImports();
    }

    @POST
    @Path("/deleteAllowanceImportById")
    public void deleteAllowanceImportById(@NotNull @QueryParam("allowanceImportId") String allowanceImportId) {
        service.deleteAllowanceImportById(allowanceImportId);
    }

    @POST
    @Path("/deleteAllowanceItemImportById")
    public void deleteAllowanceItemImportById(@NotNull @QueryParam("allowanceItemImportId") String allowanceItemImportId) {
        service.deleteAllowanceItemImportById(allowanceItemImportId);
    }

    @POST
    @Path("/updateAllowanceImport")
    public AllowanceImport updateAllowanceImport(AllowanceImport allowanceImport) {
        return service.updateAllowanceImport(allowanceImport);
    }

    @POST
    @Path("/updateAllowanceItemImport")
    public AllowanceItemImport updateAllowanceItemImport(AllowanceItemImport allowanceItemImport) {
        return service.updateAllowanceItemImport(allowanceItemImport);
    }

    @GET
    @Path("/getRelatedAllowanceItemImports")
    public List<AllowanceItemImport> getRelatedAllowanceItemImports(@QueryParam("allowanceImportId") String allowanceImportId) {
        return service.getRelatedAllowanceItemImports(allowanceImportId);
    }

    @POST
    @Path("/processAllowanceImports")
    public AllowanceImport processAllowanceImports(AssemblageInfo assemblageInfo) {
        return service.processAllowanceImports(assemblageInfo);
    }

    @POST
    @Path("/importAllowanceFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.TEXT_PLAIN)
    @ApiOperation(value = "Import a file", notes = "The return value will be the file ID")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to import",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public String importAllowanceFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        return service.importAllowanceFile(form);
    }
}
