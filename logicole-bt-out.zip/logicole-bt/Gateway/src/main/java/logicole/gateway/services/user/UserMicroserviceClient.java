package logicole.gateway.services.user;

import logicole.apis.user.IUserMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class UserMicroserviceClient extends MicroserviceClient<IUserMicroserviceApi> {
    public UserMicroserviceClient() {
        super(IUserMicroserviceApi.class, "logicole-user");
    }

    @Produces
    public IUserMicroserviceApi getIUserMicroserviceApi() {
        return createClient();
    }

}
