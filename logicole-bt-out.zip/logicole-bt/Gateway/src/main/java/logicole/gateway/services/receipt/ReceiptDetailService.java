package logicole.gateway.services.receipt;

import logicole.apis.receipt.IReceiptDetailMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.delivery.DueOut;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.filemanager.FileRef;
import logicole.common.datamodels.receipt.ReceiptDetail;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.delivery.DueOutService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.inventory.InventoryService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.IOException;
import java.util.List;


@ApplicationScoped
public class ReceiptDetailService extends BaseGatewayService<IReceiptDetailMicroserviceApi> {

    private static final String INVALID_ATTACHMENT_MSG = "Attachment is missing or is not valid";

    @Inject
    protected InventoryService inventoryService;

    @Inject
    DueOutService dueOutService;

    @Inject
    DueInService dueInService;

    @Inject
    FileManagerAdminService fileManagerAdminService;


    public ReceiptDetailService() {
        super("ReceiptDetail");
    }


    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public ReceiptDetail createReceiptDetail(ReceiptDetail receiptDetail) {
        return  microservice.createReceiptDetail(receiptDetail);

    }

    public ReceiptDetail updateReceiptDetail(ReceiptDetail receiptDetail) {
         return  microservice.updateReceiptDetail(receiptDetail);
        // TODO: Should there be an update in the Workflow?
    }

    public ReceiptDetail getReceiptDetailByDueInId(String id) {
        return  microservice.getReceiptDetailByDueInId(id);
    }

    public Attachment saveAttachment(String id, Attachment attachmentToSave) {
        if (attachmentToSave == null ||
                attachmentToSave.fileRef == null ||
                (StringUtil.isBlankOrNull(attachmentToSave.fileRef.id) && StringUtil.isBlankOrNull(attachmentToSave.fileRef.fileId))) {
            throw new ApplicationException(INVALID_ATTACHMENT_MSG);
        }

        String theFileId = ((!StringUtil.isBlankOrNull(attachmentToSave.fileRef.id) ? attachmentToSave.fileRef.id : attachmentToSave.fileRef.fileId));

        FileRef theFileRef;
        if (!StringUtil.isBlankOrNull(attachmentToSave.fileRef.filePath)) {
            theFileRef = attachmentToSave.fileRef;
        } else {
            theFileRef = fileManagerAdminService.getFileRefById(theFileId);
            if (theFileRef == null) {
                throw new ApplicationException(INVALID_ATTACHMENT_MSG);
            }
        }

        makeFileIdsConsistent(theFileRef, theFileId);
        attachmentToSave.fileRef = theFileRef;
        return microservice.saveAttachment(id, attachmentToSave);
    }


    private void makeFileIdsConsistent(FileRef fileRef, String fileId) {
        fileRef.id = fileId;
        fileRef.fileId = fileId;
    }

    public ReceiptDetail removeAttachment(String id, String fileId) throws IOException {
        //This removes the file
        try {
            fileManagerAdminService.removeFile(fileId);
        } catch (FatalProcessingException | ApplicationException e) {
            throw new ApplicationException("The attachment could not be removed");
        }
        return microservice.removeAttachment(id, fileId);
    }


    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }

    public Integer getMaxAttachmentSize() {
        return microservice.getMaxAttachmentSize();
    }

    public Integer getMaxUploadSize() {
        return microservice.getMaxUploadSize();
    }

    public ReceiptDetail saveNote(String id, Note note) {
        return microservice.saveNote(id, note);
    }

    public ReceiptDetail removeNote(String id, String noteId) {
        return microservice.removeNote(id, noteId);
    }

    public List<DueOut> getDueOutListByDueInId(String id) {
        return dueOutService.getDueOutListByDueInId(id);
    }

}
