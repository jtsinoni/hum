package logicole.gateway.services.businessintelligence;

import logicole.apis.businessintelligence.IBusinessIntelligenceMicroserviceApi;
import logicole.common.datamodels.Configuration;
import logicole.common.datamodels.CurrentUserBT;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import java.util.List;

@ApplicationScoped
public class BIService extends BaseGatewayService<IBusinessIntelligenceMicroserviceApi> {

    @Inject
    private CurrentUserBT currentUserBT;

    @Context
    private HttpServletResponse response;

    public BIService() {
        super("BusinessIntelligence");
    }

    public String getJmarToken() {
        return microservice.getJmarToken();
    }

    public String getBcsToken(String bcsToken) {
        return microservice.getBcsToken(bcsToken, getBcsUsername());
    }

    public String getBcsUsername() {
        return currentUserBT.getCurrentUser().profile.businessIntelligenceId;
    }

    public Boolean getBcsSsoEnabled() {
        return microservice.getBcsSsoEnabled();
    }

    public String getBcsSsoUrl() {
        return microservice.getBcsSsoUrl();
    }

    public String getBcsLandingUrl() {
        return microservice.getBcsLandingUrl();
    }

    public Configuration addUpdateConfiguration(Configuration configuration) {
        return microservice.addUpdateConfiguration(configuration);
    }

    public List<Configuration> getAllConfigurations() {
        return microservice.getAllConfigurations();
    }

    public Configuration getConfigurationByName(String name) {
        return microservice.getConfigurationByName(name);
    }
}
