package logicole.gateway.services.ehr;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import logicole.common.datamodels.communications.ehr.DmlssEhrPurchaseOrderStatus;
import logicole.common.datamodels.communications.ehr.EhrRequestResponse;
import logicole.common.datamodels.communications.ehr.HttpEndpointLogRecord;
import logicole.common.datamodels.communications.transmitproperty.LogiColeAuthToken;
import logicole.common.datamodels.ehr.equipment.EquipmentCatalog;
import logicole.common.datamodels.ehr.equipment.ItemMasterSupplyCatalog;
import logicole.common.datamodels.ehr.product.EhrPurchaseOrder;
import logicole.common.datamodels.ehr.product.PurchaseOrderResponse;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.common.restserver.http.RequestUtil;
import logicole.gateway.rest.ExternalRestApi;
import logicole.gateway.services.communications.DmlssElectronicHealthRecordsService;
import logicole.gateway.services.communications.EhrIncomingTrafficService;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Api(tags = {"EhrExternal"})
@ApplicationScoped
@Path("/ehr/external")
public class EhrExternalRestApi extends ExternalRestApi<EhrExternalService> implements IRestLogger {
    @Inject
    private RequestUtil requestUtil;
    @Inject
    private JSONUtil jsonUtil;
    @Inject
    private EhrIncomingTrafficService ehrIncomingTrafficService;
    @Inject
    private DmlssElectronicHealthRecordsService dmlssElectronicHealthRecordsService;

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/getItemMasterSupplyCatalog")
    public String getItemMasterSupplyCatalog() {
        try {
            ItemMasterSupplyCatalog result = service.getItemMasterSupplyCatalog();
            return jsonUtil.serialize(result);
        } catch (IOException ioe) {
            throw new ApplicationException("An error occurred getting the Item Master Supply Catalog.");
        }
    }

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/getEquipmentCatalog")
    public String getEquipmentCatalog() {
        try {
            EquipmentCatalog result = service.getEquipmentCatalog();
            return jsonUtil.serialize(result);
        } catch (IOException ioe) {
            throw new ApplicationException("An error occurred getting the Equipment Catalog.");
        }
    }

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/getEquipmentCatalogDelta")
    public String getEquipmentCatalogDelta() {
        try {
            EquipmentCatalog result = service.getEquipmentCatalogDelta();
            return jsonUtil.serialize(result);
        } catch (IOException ioe) {
            throw new ApplicationException("An error occurred getting the Equipment Catalog Delta.");
        }
    }

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("/getItemMasterSupplyCatalogDelta")
    public String getItemMasterSupplyCatalogDelta() {
        try {
            ItemMasterSupplyCatalog result = service.getItemMasterSupplyCatalogDelta();
            return jsonUtil.serialize(result);
        } catch (IOException ioe) {
            throw new ApplicationException("An error occurred getting the Item Master Supply Catalog Delta.");
        }
    }

    @POST
    @Path("/placeOrder")
    public PurchaseOrderResponse placeOrder(EhrPurchaseOrder purchaseOrder) throws ApplicationException {
        return service.placeOrder(purchaseOrder);
    }

    @POST
    @Path("/SendPurchaseOrderAcknowledgement")
    @ApiOperation(value = "Process PO acknowledgement from DMLSS.")
    public EhrRequestResponse SendPurchaseOrderAcknowledgement(DmlssEhrPurchaseOrderStatus status) {
        return dmlssElectronicHealthRecordsService.processPurchaseOrderAcknowledgement(status);
    }

    @POST
    @Path("/SendPurchaseOrderChange")
    @ApiOperation(value = "Process PO change from DMLSS.")
    public EhrRequestResponse SendPurchaseOrderChange(DmlssEhrPurchaseOrderStatus status) {
        return dmlssElectronicHealthRecordsService.processPurchaseOrderChange(status);
    }

    @POST
    @Path("/SendShippingNotice")
    @ApiOperation(value = "Process shipping notice from DMLSS.")
    public EhrRequestResponse SendShippingNotice(DmlssEhrPurchaseOrderStatus status) {
        return dmlssElectronicHealthRecordsService.processShippingNotice(status);
    }


    @POST
    @Path("/getLogicoleAuthToken")
    @Consumes({MediaType.APPLICATION_FORM_URLENCODED, MediaType.APPLICATION_JSON, "application/x-www-form-url-encoded"})
    @ApiOperation(value = "Get a LogiColeAuthToken object. Note: This must be a POST since DMLSS and GENESIS both use POST to get the token.")
    public LogiColeAuthToken getLogicoleAuthToken() {
        return service.getLogicoleAuthToken();
    }

    @AroundInvoke
    public Object aroundRestMethods(InvocationContext ctx) {

        Object result = null;

        IRestLogger restLogger = getLogger();
        HttpEndpointLogRecord logRecord = new HttpEndpointLogRecord();

        try {
            restLogger.preCall(logRecord, ctx);

            result = ctx.proceed();

            restLogger.postCall(logRecord, result);

        } catch (Exception exception) {
            // FORTIFY NOTE: ctx.proceed() causes compile error
            // if java.lang.Exception is not caught here
            restLogger.exception(logRecord, exception);
            throw new RuntimeException(exception);

        } finally {
            restLogger.wrapUp(logRecord);
        }

        return result;
    }

    public void preCall(HttpEndpointLogRecord logRecord, InvocationContext ctx) throws IOException {
        logRecord.requestUrl = (requestUtil.getUrl().toString());
        logRecord.pkiDn = dmlssElectronicHealthRecordsService.getCurrentUser().profile.pkiDn;
        logRecord.actionDate = new Date();
        Object[] params = ctx.getParameters();

        if ((params != null) && (params.length > 0)) {
            Object request = ctx.getParameters()[0];
            String requestString = jsonUtil.serialize(request);
            logRecord.request = requestString;
            logRecord.requestSize = requestString.length();
        }
    }

    public void postCall(HttpEndpointLogRecord logRecord, Object result) throws IOException {
        String response = jsonUtil.serialize(result);
        logRecord.httpResponseCode = 200;
        if (response != null) {
            logRecord.response = response;
            logRecord.responseSize = response.length();
        }
    }

    @Override
    public void exception(HttpEndpointLogRecord logRecord, Exception exception) {
        logRecord.errorMessage = StringUtil.getExceptionText(exception);
        logRecord.httpResponseCode = 500;
    }

    @Override
    public void wrapUp(HttpEndpointLogRecord logRecord) {
        ehrIncomingTrafficService.insertIncommingTrafficRecord(logRecord);
    }


    public IRestLogger getLogger() {
        return this;
    }
}

