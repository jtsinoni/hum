package logicole.gateway.services.system;

import logicole.apis.system.IApplicationHistoryMicroserviceApi;
import logicole.common.datamodels.history.ApplicationHistory;
import logicole.gateway.common.BaseGatewayService;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ApplicationHistoryService extends BaseGatewayService<IApplicationHistoryMicroserviceApi> {

    public ApplicationHistoryService(){
        super("ApplicationHistory");
    }

    public List<ApplicationHistory> findByInputParameterId(String id) {
        return microservice.findByInputParameterId(id);
    }

    public List<ApplicationHistory> findByApplication(String application) {
        return microservice.findByApplication(application);
    }

    public List<ApplicationHistory> findByUser(String userId) {
        return microservice.findByUser(userId);
    }
}

