package logicole.gateway.common.Saga;

import logicole.common.general.logging.ILogger;
import logicole.common.general.logging.LogManager;

import java.util.function.BiFunction;
import java.util.function.Function;

public class SagaStep<T, R, S>{
    private final Saga saga;
    public final String name;
    private Function<T, R> forwardFunction;
    private BiFunction<T, R, S> reversalFunction;
    private BiFunction<T, R, S> completionFunction;
    private T functionParameter;
    private R forwardResult;
    private boolean executed;

    ILogger logger = LogManager.developerLogger;

    public SagaStep(Saga saga, String name, Function<T, R> forwardFunction) {
        this(saga, name, forwardFunction, null, null);
    }

    public SagaStep(Saga saga, String name, Function<T, R> forwardFunction, BiFunction<T, R, S> reversalFunction) {
        this(saga, name, forwardFunction, reversalFunction, null);
    }

    public SagaStep(Saga saga, String name, Function<T, R> forwardFunction, BiFunction<T, R, S> reversalFunction, BiFunction<T, R, S> completionFunction) {
        this.saga = saga;
        this.name = name;
        this.forwardFunction = forwardFunction;
        this.reversalFunction = reversalFunction;
        this.completionFunction = completionFunction;
    }

    public SagaStep(SagaStep<T, R, S> trsSagaStep) {
        this.forwardFunction = trsSagaStep.forwardFunction;
        this.completionFunction = trsSagaStep.completionFunction;
        this.reversalFunction = trsSagaStep.reversalFunction;
        this.name = trsSagaStep.name;
        this.saga = trsSagaStep.saga;
    }

    R executeForward() {
        logger.debug("Executing Saga {}, Step {} with parameter {}", saga.name, name, functionParameter);
        forwardResult = forwardFunction.apply(functionParameter);
        logger.debug("Executed Saga {}, Step {} with parameter {}, result... {}", saga.name, name, functionParameter, forwardResult);

        return forwardResult;
    }

    void executeReverse() {
        if (reversalFunction != null){
            S result = reversalFunction.apply(functionParameter, forwardResult);
            logger.debug("Executing Saga {}, Step REVERSAL {}.  result... {}", saga.name, name, result);
        }else{
            logger.debug("Executing Saga {}, Step REVERSAL {} - No Op", saga.name, name);
        }
    }

    void executeCompletion() {
        if (completionFunction != null){
            S result = completionFunction.apply(functionParameter, forwardResult);
            logger.debug("Executing Saga {}, Step COMPLETION of {}, result... {}", saga.name, name, result);
        }else{
            logger.debug("Executing Saga {} Step COMPLETION of {} - No Op", saga.name, name);
        }
    }

    public R execute(T t) {
        SagaStep<T, R, S> newStep = this;
        if (executed == true){
            newStep = new SagaStep(this);
        }

        newStep.executed = true;
        newStep.functionParameter = t;
        R result = saga.executeStep(newStep);
        return result;
    }

    public SagaStep<T, R, S> defineReversalFunction(BiFunction<T, R, S> reversalFunction){
        this.reversalFunction = reversalFunction;
        return this;
    }

    public SagaStep<T, R, S> defineCompletionFunction(BiFunction<T, R, S> completionFunction){
        this.completionFunction = completionFunction;
        return this;
    }

}

