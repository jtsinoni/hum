package logicole.gateway.services.receipt;

import io.swagger.annotations.Api;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.receipt.DueIn;
import logicole.common.datamodels.receipt.DueInDTO;
import logicole.common.datamodels.receipt.Receipt;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Api(tags = {"DueIn"})
@ApplicationScoped
@Path("/dueIn")
public class DueInRestApi extends ExternalRestApi<DueInService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @POST
    @Path("/addReceipt")
    public Receipt addReceipt(Receipt receipt){
        return service.addReceipt(receipt);
    }


    @POST
    @Path("/getDueInSearchResults")
    public SearchResult<DueInDTO> getDueInSearchResults(@QueryParam("buyerId") String buyerId,
                                                        @QueryParam("scannerInput") boolean scannerInput,
                                                        SearchInput searchInput) {
        return service.getDueInSearchResults(buyerId, scannerInput, searchInput);
    }

    @POST
    @Path("/processSelectedReceipts")
    public List<Receipt> processSelectedReceipts(List<Receipt> receipts) {
        return service.processSelectedReceipts(receipts);
    }

    @GET
    @Path("/getDueInByDocumentNumber")
    public DueIn getDueInByDocumentNumber(@QueryParam("documentNumber") String documentNumber,
                                          @QueryParam("buyerId") String buyerId,
                                          @QueryParam("fulfillmentRefOrderLineItemId") String fulfillmentRefOrderLineItemId) {
        return service.getDueInByDocumentNumber(documentNumber,buyerId, fulfillmentRefOrderLineItemId);
    }
}
