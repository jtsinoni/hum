package logicole.gateway.services.order;

import logicole.gateway.rest.MicroserviceClient;
import logicole.apis.order.IBuyerMicroserviceApi;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class BuyerMicroserviceClient extends MicroserviceClient<IBuyerMicroserviceApi> {
    public BuyerMicroserviceClient() {
        super(IBuyerMicroserviceApi.class, "logicole-order");
    }

    @Produces
    public IBuyerMicroserviceApi getIBuyerMicroserviceApi() {
        return createClient();
    }
}
