package logicole.gateway.services.product;

import logicole.apis.product.IOfferMicroserviceApi;
import logicole.common.datamodels.abi.PackageUnit;
import logicole.common.datamodels.abi.staging.ABiCatalogRecordUpdate;
import logicole.common.datamodels.dmlss.EhrSiteCustomer;
import logicole.common.datamodels.ehr.equipment.ItemMasterSupplyCatalogItem;
import logicole.common.datamodels.ehr.equipment.EItemMasterSupplyCatalogType;
import logicole.common.datamodels.ehr.equipment.EItemMasterSupplyItemDeltaType;
import logicole.common.datamodels.ehr.product.EhrSearchCriteria;
import logicole.common.datamodels.product.Offer;
import logicole.common.datamodels.product.OfferSellerUpdateResponse;
import logicole.common.datamodels.product.OfferSummary;
import logicole.common.datamodels.product.SearchInputOffer;
import logicole.common.datamodels.product.SiteCatalogOfferSync;
import logicole.common.datamodels.product.SiteCatalogRecord;
import logicole.common.datamodels.inventory.InventoryRecord;
import logicole.common.general.exception.ApplicationException;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountDTO;

import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.AbiCatalogService;
import logicole.gateway.services.abi.AbiStagingLookupService;
import logicole.gateway.services.inventory.InventoryService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.organization.OrganizationService;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.util.*;

@ApplicationScoped
public class OfferService extends BaseGatewayService<IOfferMicroserviceApi> {
    @Inject
    AbiCatalogService abiCatalogService;

    @Inject
    BuyerService buyerService;

    @Inject
    InventoryService inventoryService;

    @Inject
    OrganizationService organizationService;

    @Inject
    ProductService productService;

    @Inject
    private ItemMasterSupplyItemsFactory itemMasterSupplyCatalogFactory;

    @Inject
    AbiStagingLookupService abiStagingLookupService;

    public OfferService() {
        super("Offer");
    }

    public String aggregateSearchOffer(@QueryParam("searchText") String searchText, @QueryParam("criteria") String criteria, @QueryParam("projection") String projection, @QueryParam("limit") Integer limit) {
        return microservice.aggregateSearchOffer(searchText, criteria, projection, limit);
    }

    public List<String> getDistinctSellerNamesFromOffers() {
        return microservice.getDistinctSellerNamesFromOffers();
    }

    public List<Offer> getOfferByEnterpriseItemIdentifier(String organizationIdentifier, String enterpriseItemIdentifier) {
        return microservice.getOfferByEnterpriseItemIdentifier(organizationIdentifier, enterpriseItemIdentifier);
    }

    public List<Offer> getOfferByEnterpriseItemIdentifierDefault(String organizationIdentifier, String enterpriseItemIdentifier) {
        return microservice.getOfferByEnterpriseItemIdentifierDefault(organizationIdentifier, enterpriseItemIdentifier);
    }

    public List<Offer> getOfferByEnterpriseItemIdentifierSeller(String organizationIdentifier, String enterpriseItemIdentifier, String sellerName) {
        return microservice.getOfferByEnterpriseItemIdentifierSeller(organizationIdentifier, enterpriseItemIdentifier, sellerName);
    }

    public List<Offer> getOfferByEnterpriseProductIdentifier(String organizationIdentifier, String enterpriseProductIdentifier) {
        return microservice.getOfferByEnterpriseProductIdentifier(organizationIdentifier, enterpriseProductIdentifier);
    }

    public List<Offer> getOfferByEnterpriseProductIdentifierDefault(String organizationIdentifier, String enterpriseProductIdentifier) {
        return microservice.getOfferByEnterpriseProductIdentifierDefault(organizationIdentifier, enterpriseProductIdentifier);
    }

    public Offer getOfferById(@QueryParam("id") String id) {
        return microservice.getOfferById(id);
    }

    public List<Offer> getOfferByOrganizationIdentifier(String organizationIdentifier) {
        return microservice.getOfferByOrganizationIdentifier(organizationIdentifier);
    }

    public List<Offer> getOfferByPartialEnterpriseProductIdentifier(String organizationIdentifier, String partialProductIdentifier) {
        return microservice.getOfferByPartialEnterpriseProductIdentifier(organizationIdentifier, partialProductIdentifier);
    }

    public List<Offer> getOfferByPartialProductIdentifier(String organizationIdentifier, String partialProductIdentifier) {
        return microservice.getOfferByPartialProductIdentifier(organizationIdentifier, partialProductIdentifier);
    }

    public List<Offer> getOfferByProductIdentifier(String organizationIdentifier, String productIdentifier) {
        return microservice.getOfferByProductIdentifier(organizationIdentifier, productIdentifier);
    }

    public List<Offer> getOfferByProductIdentifierDefault(String organizationIdentifier, String productIdentifier) {
        return microservice.getOfferByProductIdentifierDefault(organizationIdentifier, productIdentifier);
    }

    public List<Offer> getOfferBySellerName(String organizationIdentifier, String sellerName) {
        return microservice.getOfferBySellerName(organizationIdentifier, sellerName);
    }

    public List<Offer> getOffers(@QueryParam("filter") String filter) {
        return microservice.getOffers(filter);
    }

    public Offer saveOffer(Offer offer) {
        EhrSiteCustomer siteCustomer = organizationService.findBySiteCustomerOrgId(offer.organizationIdentifier, offer.customerIdentifier);
        Offer saved = microservice.saveOffer(offer, siteCustomer.ehrLastItemSyncDate);
        productService.updateProduct(offer);
        return saved;
    }

    public String saveOfferDocument(@QueryParam("offer") String offer) {
        return microservice.saveOfferDocument(offer);
    }

    public Integer syncOffers(SiteCatalogRecord siteCatalogRecord) {
        if (!StringUtil.isEmptyOrNull(siteCatalogRecord.enterpriseProductIdentifier)) {
            SiteCatalogOfferSync siteCatalogOfferSync = new SiteCatalogOfferSync();
            //get it from AbiStaging if there is no record in AbiCatalog
            siteCatalogOfferSync.abiCatalogRecord = abiCatalogService.getAbiCatalogOrStagingRecordByEnterpriseProductIdentifier(siteCatalogRecord.enterpriseProductIdentifier);
            siteCatalogOfferSync.siteCatalogRecord = siteCatalogRecord;
            return microservice.syncOffers(siteCatalogOfferSync);
    }
        return 0;
    }

    public List<Offer> textSearchOffer(@QueryParam("siteId") String siteId, @QueryParam("searchString") String
            searchString) {
        return microservice.textSearchOffer(siteId, searchString);
    }

    public OfferSellerUpdateResponse updateSellersInOffers(String changeToSellerId, String
            changeToSellerName, String changeToSellerType, List<String> sellerNamesToUpdate) {
        return microservice.updateSellersInOffers(changeToSellerId, changeToSellerName, changeToSellerType, sellerNamesToUpdate);
    }

    public List<Offer> findByEnterpriseProductIdentifier(String siteOrgId,
                                                         String customerId,
                                                         String enterpriseProductIdentifier) {
        return microservice.findByEnterpriseProductIdentifier(siteOrgId, customerId, enterpriseProductIdentifier);
    }

    public List<Offer> findActiveEHROffersByEnterpriseProductIdentifier(String siteOrgId,
                                                                        String customerId,
                                                                        String enterpriseProductIdentifier) {
        return microservice.findActiveEHROffersByEnterpriseProductIdentifier(siteOrgId, customerId, enterpriseProductIdentifier);
    }

    public String getOfferSearchResults(SearchInputOffer searchInputOffer) {
        // add criteria for list of suppliers
       /* if (searchInputOffer.criteria != null && !searchInputOffer.criteria.contains("sellerName") && searchInputOffer.criteria.endsWith("}")) {
            List<BuyerSellerAccountDTO> buyerAccounts = buyerService.getBuyerSellerAccountListByBuyerId(searchInputOffer.buyerId);
            String sellerCriteria;
            StringBuilder inClause = new StringBuilder();
            if (buyerAccounts != null && !buyerAccounts.isEmpty()) {
                HashSet<String> names = new HashSet<>();  // get a unique list, in case sellers are in the list more than once
                for (BuyerSellerAccountDTO buyerAccountDTO : buyerAccounts) {
                    if (!names.contains(buyerAccountDTO.sellerName)) {
                        names.add(buyerAccountDTO.sellerName);
                        inClause.append("\"").append(buyerAccountDTO.sellerName).append("\",");
                    }
                }
            }
            sellerCriteria = ",\"sellerName\":{$in:[" + inClause.toString() + "]}";
            searchInputOffer.criteria = searchInputOffer.criteria.substring(0, searchInputOffer.criteria.length() - 1) + sellerCriteria + "}";
        }*/
        return microservice.aggregateSearchOffer(searchInputOffer.searchText, searchInputOffer.criteria, searchInputOffer.projection, searchInputOffer.limit);
    }

    public List<Offer> findByEnterpriseItemIdentifier(String siteOrgId,
                                                      String customerId,
                                                      String enterpriseItemIdentifier) {
        return microservice.findByEnterpriseItemIdentifier(siteOrgId, customerId, enterpriseItemIdentifier);
    }

    public List<Offer> findBySiteItemIdentifier(String siteOrgId,
                                                String customerId,
                                                String siteItemIdentifier) {
        return microservice.findBySiteItemIdentifier(siteOrgId, customerId, siteItemIdentifier);
    }

    public List<Offer> findActiveEHROffersBySiteItemIdentifier(String siteOrgId,
                                                String customerId,
                                                String siteItemIdentifier) {
        return microservice.findActiveEHROffersBySiteItemIdentifier(siteOrgId, customerId, siteItemIdentifier);
    }

    public List<Offer> findByNDC(String siteOrgId, String ndc) {
        return microservice.findByNDC(siteOrgId, ndc);
    }

    public List<Offer> findByManufacturerNameAndCatalogNumber(String siteOrgId, String manufacturerNm, String
            manufCatNum) {
        return microservice.findByManufacturerNameAndCatalogNumber(siteOrgId, manufacturerNm, manufCatNum);
    }

    public InventoryRecord addOfferToInventory(String currentNodeId, String offerId) throws ApplicationException {
        Offer offer = microservice.getOfferById(offerId);
        return inventoryService.createInventoryFromCatalog(currentNodeId, offer);
    }

    public List<Offer> findByManufacturerCatalogNumber(String siteOrgId, String manufCatNum) {
        return microservice.findByManufacturerCatalogNumber(siteOrgId, manufCatNum);
    }

    public List<Offer> findByMMCId(String siteOrgId, Integer mmcId) {
        return microservice.findByMMCId(siteOrgId, mmcId);
    }

    public List<Offer> findBySiteItemId(String siteOrgId, String siteItemId) {
        return microservice.findBySiteItemId(siteOrgId, siteItemId);
    }

    public List<Offer> findByProductSeqId(String siteOrgId, Integer productSeqId) {
        return microservice.findByProductSeqId(siteOrgId, productSeqId);
    }

    public Offer findRecordById(String id) {
        return microservice.findRecordById(id);
    }

    public List<ItemMasterSupplyCatalogItem> getCatalogItemsForSiteCustomer(String siteId, String customerId, Date
            afterDate,
                                                                            EItemMasterSupplyCatalogType catType) {
        List<Offer> offers = microservice.findEhrBySiteCustomer(siteId, customerId, afterDate);
        return itemMasterSupplyCatalogFactory.convert(offers, catType, afterDate, siteId, customerId);
    }

    public List<OfferSummary> getOffersByEHRSearchCriteria(EhrSearchCriteria ehrSearchCriteria) {
        List<Offer> offers = microservice.findByEHRSearchCriteria(ehrSearchCriteria);
        List<OfferSummary> offerSummaries = new ArrayList<>();
        for (Offer offer : offers) {
            OfferSummary summary = buildSummaryFromOffer(offer);
            offerSummaries.add(summary);
        }

        return offerSummaries;
    }

    OfferSummary buildSummaryFromOffer(Offer offer) {
            OfferSummary offerSummary = new OfferSummary();
            offerSummary.setId(offer.getId());
            offerSummary.customerIdentifier = offer.customerIdentifier;
            offerSummary.organizationIdentifier = offer.organizationIdentifier;
            offerSummary.siteItemIdentifier = offer.siteItemIdentifier;
            offerSummary.enterpriseProductIdentifier = offer.enterpriseProductIdentifier;
            offerSummary.manufacturer = offer.product.manufacturer;
            offerSummary.manufacturerCatalogNumber = offer.product.manufacturerCatalogNumber;
            offerSummary.longItemDescription = offer.product.longItemDescription;
            offerSummary.hcpcsCode = offer.product.hcpcsCode;
            offerSummary.packageUnitDescription = offer.packageUnitDescription;
            offerSummary.price = offer.price;
            offerSummary.sellerName = offer.sellerName;
            offerSummary.unspscCode = offer.product.unspscCode;
            offerSummary.isEhrCatalogItem = offer.isEhrCatalogItem;
        return offerSummary;
    }

    public List<Offer> addOffersToEHRCatalog(String[] offerIds) {
        return microservice.addOffersToEHRCatalog(offerIds);
    }

    public Offer buildOfferFromABiCatalog(Offer abiOffer) throws ApplicationException {

        // Check for duplicate offer
        EhrSearchCriteria ehrSearchCriteria = new EhrSearchCriteria();
        ehrSearchCriteria.siteOrgId = abiOffer.organizationIdentifier;
        ehrSearchCriteria.customerOrgId = abiOffer.customerIdentifier;
        ehrSearchCriteria.enterpriseProductIdentifier = abiOffer.enterpriseProductIdentifier;
        ehrSearchCriteria.packageUnit = abiOffer.packageUnit;
        ehrSearchCriteria.sellerName = abiOffer.sellerName;
        ehrSearchCriteria.isEhrEnabled = null;
        List<OfferSummary> offers = getOffersByEHRSearchCriteria(ehrSearchCriteria);
        if (!offers.isEmpty()) {
            throw new ApplicationException("An Item already exists for this Site Customer");
        }

        EhrSiteCustomer ehrSiteCustomer = organizationService.findBySiteCustomerOrgId(abiOffer.organizationIdentifier, abiOffer.customerIdentifier);
        if (ehrSiteCustomer != null) {
            abiOffer.organizationName = ehrSiteCustomer.siteName;
            abiOffer.customerName = ehrSiteCustomer.customerName;
        }
        abiOffer.ehrPackageQuantity = abiOffer.packageQuantity;
        abiOffer.ehrPackageUnit = abiOffer.packageUnit;
        abiOffer.ehrPrice = abiOffer.price;
        abiOffer.isActive = true;
        return saveOffer(abiOffer);
    }

    public void updateOfferProductData(ABiCatalogRecordUpdate aBiCatalogRecordUpdate) {
        microservice.updateOfferProductData(aBiCatalogRecordUpdate);
    }

    public OfferSummary setItemEhrEnabled(String id, boolean isEhrEnabled) {
        Offer offer = findRecordById(id);
        EhrSiteCustomer siteCustomer = organizationService.findBySiteCustomerOrgId(offer.organizationIdentifier, offer.customerIdentifier);
        offer = microservice.setItemEhrEnabled(id, isEhrEnabled, siteCustomer.ehrLastItemSyncDate);
        OfferSummary summary = buildSummaryFromOffer(offer);
        return summary;

    }

    public Boolean enterpriseProductIdentifierIsEHREnabled(String enterpriseProductIdentifier) {
        return microservice.enterpriseProductIdentifierIsEHREnabled(enterpriseProductIdentifier);
    }

    public List<Document> getEpiDuplicates(String epi) {
        return microservice.getEpiDuplicates(epi);
    }

    public long getEHREnabledenterpriseProductIdentifierCount(List<String> enterpriseProductIdentifiers) {
        return microservice.getEHREnabledenterpriseProductIdentifierCount(enterpriseProductIdentifiers);
    }
    public EItemMasterSupplyItemDeltaType getProductEHRDeltaType(Date lastCatRequestDate, String enterpriseProductIdentifier) {
        return microservice.getProductEHRDeltaType(lastCatRequestDate, enterpriseProductIdentifier);
    }

    //TODO this needs to part of a CatalogLookupService
    public List<PackageUnit> getPackageUnitList() {
        return abiStagingLookupService.getPackageUnitList();
    }
}
