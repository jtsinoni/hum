package logicole.gateway.services.organization;

import logicole.apis.organization.IOrganizationHierDataMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class OrganizationHierDataMicroserviceClient extends MicroserviceClient<IOrganizationHierDataMicroserviceApi> {
    public OrganizationHierDataMicroserviceClient() {
        super(IOrganizationHierDataMicroserviceApi.class, "logicole-organization");
    }

    @Produces
    public IOrganizationHierDataMicroserviceApi getIOrganizationHierDataMicroserviceApi() {
        return createClient();
    }

}
