package logicole.gateway.services.organization;

import io.swagger.annotations.Api;
import logicole.common.datamodels.organization.BusinessServiceDefinition;
import logicole.common.datamodels.organization.BusinessServiceDefinitionRef;
import logicole.common.datamodels.organization.EEngagementModel;
import logicole.common.datamodels.user.RoleRef;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"BusinessServiceDefinition"})
@ApplicationScoped
@Path("/businessServiceDefinition")
public class BusinessServiceDefinitionRestApi extends ExternalRestApi<BusinessServiceDefinitionService> {

    @POST
    @Path("/addBusinessServiceDefinition")
    public BusinessServiceDefinition addBusinessServiceDefinition(BusinessServiceDefinition businessService) {
        return service.addBusinessServiceDefinition(businessService);
    }

    @POST
    @Path("/updateBusinessServiceDefinition")
    public BusinessServiceDefinition updateBusinessServiceDefinition(BusinessServiceDefinition businessService) {
        return service.updateBusinessServiceDefinition(businessService);
    }


    @GET
    @Path("/deleteBusinessServiceDefinition")
    public void deleteBusinessServiceDefinition(@QueryParam("id") String id) {
        service.deleteBusinessServiceDefinition(id);
    }

    @POST
    @Path("/updateRoles")
    public BusinessServiceDefinition updateRoles(@QueryParam("businessServiceDefinitionId") String businessServiceDefinitionId,
                                          @QueryParam("engagementModel") EEngagementModel engagementModel,
                                          List<RoleRef> roleRefs) {
        return service.updateRoles(businessServiceDefinitionId, engagementModel, roleRefs);
    }
    @GET
    @Path("/getBusinessServiceDefinitionRoleRefs")
    public List<RoleRef> getBusinessServiceDefinitionRoleRefs(@QueryParam("businessServiceDefinitionId") String businessServiceDefinitionId,
                                                              @QueryParam("engagementModel") EEngagementModel engagementModel) {
        return service.getBusinessServiceDefinitionRoleRefs(businessServiceDefinitionId, engagementModel);
    }

    @GET
    @Path("/getEngagementModelSelections")
    public List<String> getEngagementModelSelections() {
        return service.getEngagementModelSelections();
    }

    @GET
    @Path("/getAllBusinessServiceDefinitions")
    public List<BusinessServiceDefinition> getAllBusinessServiceDefinitions() {
        return service.getAllBusinessServiceDefinitions();
    }

    @GET
    @Path("/getAllBusinessServiceDefinitionRefs")
    public List<BusinessServiceDefinitionRef> getAllBusinessServiceDefinitionRefs() {
        return service.getAllBusinessServiceDefinitionRefs();
    }

}
