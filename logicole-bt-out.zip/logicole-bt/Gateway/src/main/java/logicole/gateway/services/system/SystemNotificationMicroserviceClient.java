package logicole.gateway.services.system;

import logicole.apis.system.ISystemNotificationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;


@ApplicationScoped
public class SystemNotificationMicroserviceClient extends MicroserviceClient<ISystemNotificationMicroserviceApi> {
    public SystemNotificationMicroserviceClient() {
        super(ISystemNotificationMicroserviceApi.class, "logicole-system");
    }

    @Produces
    public ISystemNotificationMicroserviceApi getMicroserviceApi() {
        return createClient();
    }
}
