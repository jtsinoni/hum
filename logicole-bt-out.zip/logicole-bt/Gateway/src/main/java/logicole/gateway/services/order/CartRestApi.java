package logicole.gateway.services.order;

import io.swagger.annotations.Api;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.catalog.Catalog;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.output.AuthorizedNode;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.order.CatalogPurchase;
import logicole.common.datamodels.order.cart.*;
import logicole.common.datamodels.order.order.OrderDTO;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.CurrentUserBtRef;
import logicole.common.general.exception.ValidationException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Cart"})
@ApplicationScoped
@Path("/cart")
public class CartRestApi extends ExternalRestApi<CartService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }


    @GET
    @Path("/removeItemFromCart")
    public CartDTO removeItemFromCart(@QueryParam("cartItemId") String cartItemId, @QueryParam("application") String application) {
        return service.removeItemFromCart(cartItemId, application);
    }

    @GET
    @Path("/getCartByBuyerId")
    public CartDTO getCartByBuyerId(@QueryParam("application") String application) {
        return service.getCartByBuyerId(application);
    }

    @POST
    @Path("/addCartItemToCart")
    public CartDTO addCartItemToCart(CartItem cartItem) {
        return service.addCartItemToCart(cartItem);
    }

    @GET
    @Path("/updateCartItemFund")
    public CartItem updateCartItemFund(@QueryParam("cartItemId") String cartItemId, @QueryParam("fundNodeId") String fundNodeId) {
        return service.updateCartItemFund(cartItemId, fundNodeId);
    }

    @GET
    @Path("/updateCartItemIsNonSubmitOrder")
    public CartItem updateCartItemIsNonSubmitOrder(@QueryParam("cartItemId") String cartItemId, @QueryParam("isNonSubmitOrder") boolean isNonSubmitOrder) {
        return service.updateCartItemIsNonSubmitOrder(cartItemId, isNonSubmitOrder);
    }

    @GET
    @Path("/updateCartItemQuantity")
    public CartItem updateCartItemQuantity(@QueryParam("cartItemId") String cartItemId, @QueryParam("quantity") Integer quantity) {
        return service.updateCartItemQuantity(cartItemId, quantity);
    }

    @POST
    @Path("/updateCartItemPrice")
    public CartItem updateCartItemPrice(@QueryParam("cartItemId") String cartItemId, MonetaryValue price) {
        return service.updateCartItemPrice(cartItemId, price);
    }

    @POST
    @Path("/updateCartItem")
    public CartItem updateCartItem(CartItem cartItem) {
        return service.updateCartItem(cartItem);
    }

    @POST
    @Path("/addNewItemToCart")
    public CartDTO addNewItemToCart(@QueryParam("quantity") Integer quantity, @QueryParam("assemblageId") String assemblageId,
                                    Catalog catalog) {
       return service.addNewItemToCart(quantity, assemblageId, catalog);
    }

    @POST
    @Path("/cartCheckout")
    public List<OrderDTO> cartCheckout(CartSellerItemsDTO group) throws ValidationException{
        return service.cartCheckout(group);
    }

    @GET
    @Path("/getFundingNodes")
    public List<FundingNodeRef> getFundingNodes() {
        return service.getFundingNodes();
    }

    @POST
    @Path("/addReplenishmentItemToCart")
    public CartDTO addReplenishmentItemToCart(CartItem cartItem) {
        return service.addReplenishmentItemToCart(cartItem);
    }

    @POST
    @Path("/validateCartItems")
    public CartSellerItemsDTO validateCartItems(CartSellerItemsDTO sellerGroup) {
        return service.validateCartItems(sellerGroup);
    }

    @GET
    @Path("/getAdviceCodes")
    public List<AdviceCode> getAdviceCodes(){
        return service.getAdviceCodes();
    }

    @GET
    @Path("/getDemandCodes")
    public List<DemandCode> getDemandCodes(){
        return service.getDemandCodes();
    }

    @GET
    @Path("/getPriorityCodesByDesignator")
    public List<PriorityCode> getPriorityCodesByDesignator(@QueryParam("designator") String designator) {
        return service.getPriorityCodesByDesignator(designator);
    }

    @GET
    @Path("/getSignalCodes")
    public List<SignalCode> getSignalCodes() {
        return service.getSignalCodes();
    }

    @GET
    @Path("/getMediaStatusCodes")
    public List<MediaStatusCode> getMediaStatusCodes() {
        return service.getMediaStatusCodes();
    }

    @GET
    @Path("/getDistributionCodes")
    public List<DistributionCode> getDistributionCodes() {
        return service.getDistributionCodes();
    }

    @POST
    @Path("/getCatalogPurchaseSearchResults")
    public SearchResult<CatalogPurchase> getCatalogPurchaseSearchResults(SearchInput searchInput) {
        return service.getCatalogPurchaseSearchResults(searchInput);
    }

    @POST
    @Path("/getNonCatalogPurchaseSearchResults")
    public SearchResult<CatalogPurchase> getNonCatalogPurchaseSearchResults(SearchInput searchInput) {
        return service.getNonCatalogPurchaseSearchResults(searchInput);
    }

    @POST
    @Path("/saveAssignedUserToCart")
    public CartDTO saveAssignedUserToCart(@QueryParam("sellerId") String sellerId, @QueryParam("application") String application, CurrentUserBtRef assignedUserRef) {
        return service.saveAssignedUserToCart(sellerId, assignedUserRef, application);
    }

    @GET
    @Path("/getAssignableCartUsers")
    public List<CurrentUserBtRef> getAssignableCartUsers(){
        return service.getAssignableCartUsers();
    }

    @GET
    @Path("/getFundingCommodityCodeRef")
    public List<CommodityCodeRef> getFundingCommodityCodeRef() {
        return service.getFundingCommodityCodeRef();
    }

}

