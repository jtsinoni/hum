package logicole.gateway.services.assemblage;


import logicole.apis.assemblage.IAssemblageMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AssemblageMicroserviceClient extends MicroserviceClient<IAssemblageMicroserviceApi> {
    public AssemblageMicroserviceClient(){
        super(IAssemblageMicroserviceApi.class, "logicole-assemblage");
    }

    @Produces
    public IAssemblageMicroserviceApi getIAssemblageMicroserviceApi() {
        return createClient();
    }

}
