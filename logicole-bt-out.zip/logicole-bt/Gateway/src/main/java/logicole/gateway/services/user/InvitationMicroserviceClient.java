package logicole.gateway.services.user;

import logicole.apis.user.IInvitationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class InvitationMicroserviceClient extends MicroserviceClient<IInvitationMicroserviceApi> {
    public InvitationMicroserviceClient() {
        super(IInvitationMicroserviceApi.class, "logicole-user");
    }

    @Produces
    public IInvitationMicroserviceApi getIUserMicroserviceApi() {
        return createClient();
    }

}
