package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiCatalogMicroserviceApi;
import logicole.common.datamodels.abi.CriticalItemCategoryRef;
import logicole.common.datamodels.abi.staging.AbiCatalogRecord;
import logicole.common.datamodels.abi.staging.AbiCatalogStaging;
import logicole.common.datamodels.abi.staging.SearchAbiInput;
import logicole.common.datamodels.ehr.product.EhrSearchCriteria;
import logicole.common.datamodels.search.DmlesSearchResponse;
import logicole.common.datamodels.search.request.DmlesSearchRequest;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.ObjectMapper;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.ehr.EhrSearchUtil;
import logicole.gateway.services.search.SearchService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@ApplicationScoped
public class AbiCatalogService extends BaseGatewayService<IAbiCatalogMicroserviceApi> {
    @Inject
    AbiSearchService abiSearchService;

    @Inject
    AbiStagingService abiStagingService;

    @Inject
    SearchService searchService;

    public AbiCatalogService() {
        super("AbiCatalog");
    }

    @Inject
    private ObjectMapper objectMapper;
    @Inject
    private JSONUtil jsonUtil;

    public int adjustEcriEquipmentCount(String ecriGuid, Integer adjustment) {
        return microservice.adjustEcriEquipmentCount(ecriGuid, adjustment);
    }

    public List<AbiCatalogRecord> findByEHRSearchCriteria(EhrSearchCriteria ehrSearchCriteria) throws IOException, ApplicationException {
        SearchAbiInput searchAbiInput = new SearchAbiInput();
        searchAbiInput.queryString = EhrSearchUtil.buildEhrSearchString(ehrSearchCriteria);
        searchAbiInput.searchFields = EhrSearchUtil.buildAbiSearchFields(ehrSearchCriteria);
        DmlesSearchRequest searchRequest = abiSearchService.buildAbiSearchRequest(searchAbiInput);
        DmlesSearchResponse searchResponse = searchService.getSearchResponse(searchRequest);
        String resultsString = jsonUtil.serialize(searchResponse.hits.fields);
        List<AbiCatalogRecord> records = jsonUtil.deserializeList(resultsString, AbiCatalogRecord[].class);
        return records;
    }

    public List<String> syncEquipmentRecordCounts(Map<String, Integer> ecriProductCounts){
        return microservice.syncEquipmentRecordCounts(ecriProductCounts);
    }

    public AbiCatalogRecord getAbiCatalogRecordByEnterpriseProductIdentifier(String enterpriseProductIdentifier) {
        return microservice.getAbiCatalogRecordByEnterpriseProductIdentifier(enterpriseProductIdentifier);
    }

    public AbiCatalogRecord getAbiCatalogOrStagingRecordByEnterpriseProductIdentifier(String enterpriseProductIdentifier) {
        AbiCatalogRecord abiCatalogRecord = getAbiCatalogRecordByEnterpriseProductIdentifier(enterpriseProductIdentifier);
        if(abiCatalogRecord==null){
            AbiCatalogStaging abiCatalogStaging = abiStagingService.getAbiCatalogStagingRecordByEnterpriseProductIdentifier(enterpriseProductIdentifier);
            abiCatalogRecord = objectMapper.getObject(AbiCatalogRecord.class, abiCatalogStaging);
        }
        return abiCatalogRecord;
    }

    public int updateAbiCatalogEnterpriseProductIdentifier(String oldEnterpriseProductIdentifier, String newEnterpriseProductIdentifier){
        return microservice.updateAbiCatalogEnterpriseProductIdentifier(oldEnterpriseProductIdentifier,newEnterpriseProductIdentifier );
    }

    public void updateCriticalItemCategoryRefs(CriticalItemCategoryRef ref) {
        microservice.updateCriticalItemCategoryRefs(ref);
    }

    public AbiCatalogRecord findByEcriGuid(String ecriGuid) {
        return microservice.findByEcriGuid(ecriGuid);
    }
}
