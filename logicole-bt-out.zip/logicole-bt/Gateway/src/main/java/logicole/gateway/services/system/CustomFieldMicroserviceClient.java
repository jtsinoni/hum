package logicole.gateway.services.system;

import logicole.apis.system.ICustomFieldMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class CustomFieldMicroserviceClient extends MicroserviceClient<ICustomFieldMicroserviceApi> {
    public CustomFieldMicroserviceClient() {
        super(ICustomFieldMicroserviceApi.class, "logicole-system");
    }
    
    @Produces
    public ICustomFieldMicroserviceApi getICustomFieldMicroserviceApi() {
        return createClient();
    }
    
}
