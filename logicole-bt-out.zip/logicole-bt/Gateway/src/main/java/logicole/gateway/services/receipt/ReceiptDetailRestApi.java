package logicole.gateway.services.receipt;

import io.swagger.annotations.*;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.receipt.ReceiptDetail;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;
import logicole.common.datamodels.delivery.DueOut;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Api(tags = {"ReceiptDetail"})
@ApplicationScoped
@Path("/receiptDetail")
public class ReceiptDetailRestApi extends ExternalRestApi<ReceiptDetailService> {

    @Inject
    private MultiPartFormUtil uploadUtil;

    @POST
    @Path("/createReceiptDetail")
    public ReceiptDetail createReceiptDetail(ReceiptDetail receiptDetail) {
        return service.createReceiptDetail(receiptDetail);
    }

    @POST
    @Path("/updateReceiptDetail")
    public ReceiptDetail updateReceiptDetail(ReceiptDetail receiptDetail) {
        return service.updateReceiptDetail(receiptDetail);
    }

    @GET
    @Path("/getReceiptDetailByDueInId")
    public ReceiptDetail getReceiptDetailByDueInId(@QueryParam("id") String id) {
        return service.getReceiptDetailByDueInId(id);
    }

    @POST
    @Path("/saveAttachment")
    public Attachment saveAttachment(@QueryParam("id") String id, Attachment attachmentToSave) {
        return service.saveAttachment(id, attachmentToSave);
    }

    @POST
    @Path("/removeAttachment")
    public ReceiptDetail removeAttachment(@QueryParam("id") String id, @QueryParam("fileId") String fileId) throws IOException, ApplicationException {
        return service.removeAttachment(id, fileId);
    }

    @GET
    @Path("/getMaxAttachmentSize")
    public Integer getMaxAttachmentSize() {
        return service.getMaxAttachmentSize();
    }

    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        byte[] content;

        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            InputStream inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new ApplicationException("Unable to upload file " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxAttachmentSize();
        if (content.length > maxUploadSize) {
            throw new ApplicationException(
                    "File size exceeds max size of " + maxUploadSize + " bytes");
        }

        return service.uploadFile(content, uploadedFileName);
    }

    @POST
    @Path("/saveNote")
    public ReceiptDetail saveNote(@QueryParam("id") String id, Note note) {
        return service.saveNote(id, note);
    }

    @GET
    @Path("/removeNote")
    public ReceiptDetail removeNote(@QueryParam("id") String id, @QueryParam("noteId") String noteId) {
        return service.removeNote(id, noteId);
    }

    @GET
    @Path("/getDueOutListByDueInId")
    public List<DueOut> getDueOutListByDueInId(@QueryParam("id") String id) {
        return service.getDueOutListByDueInId(id);
    }
}
