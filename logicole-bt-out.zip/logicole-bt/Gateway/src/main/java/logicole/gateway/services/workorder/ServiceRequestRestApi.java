package logicole.gateway.services.workorder;

import io.swagger.annotations.*;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.AssetSummary;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.realproperty.Site;
import logicole.common.datamodels.realproperty.facility.FacilitySummary;
import logicole.common.datamodels.space.RoomSummary;
import logicole.common.datamodels.workorder.*;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Api(tags = {"WorkOrder"})
@ApplicationScoped
@Path("/serviceRequest")
public class ServiceRequestRestApi extends ExternalRestApi<ServiceRequestService> {
    @Inject
    private MultiPartFormUtil uploadUtil;

    @POST
    @Path("/createServiceRequest")
    public ServiceRequest createServiceRequest(ServiceRequest serviceRequest) {
        return service.createServiceRequest(serviceRequest);
    }

    @POST
    @Path("/requestCancel")
    public ServiceRequest requestCancel(ServiceRequest serviceRequest) {
        return service.requestCancel(serviceRequest);
    }

    @POST
    @Path("/getServiceRequests")
    public List<ServiceRequest> getServiceRequests(ServiceRequestSearchCriteria searchCriteria) {
        return service.getServiceRequests(searchCriteria);
    }

    @POST
    @Path("/cloneServiceRequest")
    public ServiceRequest cloneServiceRequest(@NotNull @QueryParam("id") String id) {
        return service.cloneServiceRequest(id);
    }

    @GET
    @Path("/getRequestTypes")
    public List<String> getRequestTypes() {
        return EServiceRequestType.getDisplayTextList();
    }

    @GET
    @Path("/getAssetSummariesByFacilityId")
    public List<AssetSummary> getAssetSummariesByFacilityId(@NotNull @QueryParam("facilityId") String facilityId) {
        return service.getAssetSummariesByFacilityId(facilityId);
    }

    @POST
    @Path("/addNote")
    public ServiceRequest addNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.addNote(id, note);
    }

    @POST
    @Path("/saveNote")
    public ServiceRequest saveNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.saveNote(id, note);
    }

    @POST
    @Path("/removeNote")
    public ServiceRequest removeNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.removeNote(id, note);
    }

    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadFile(
            @ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        InputStream inputStream;
        byte[] content;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new FatalProcessingException(
                    "Was not able to extract file from request " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxUploadSize();

        if (content.length > maxUploadSize) {
            throw new FatalProcessingException(
                    "Uploaded file size exceeds server max POST Size value  of " + maxUploadSize
                            + " bytes");
        }

        return service.uploadFile(content, uploadedFileName);
    }

    @GET
    @Path("/getMaxUploadSize")
    public Integer getMaxUploadSize() {
        return service.getMaxUploadSize();
    }

    @POST
    @Path("/saveAttachment")
    public Attachment saveAttachment(@NotNull @QueryParam("id") String id, Attachment attachmentToSave) {
        return service.saveAttachment(id, attachmentToSave);
    }

    @GET
    @Path("/removeAttachment")
    public List<Attachment> removeAttachment(@NotNull @QueryParam("id") String id, @QueryParam("fileId") String fileId)
            throws IOException {
        return service.removeAttachment(id, fileId);
    }

    @POST
    @Path("/removeAttachments")
    public void removeAttachments(List<String> fileIds) {
        service.removeAttachments(fileIds);
    }

    @POST
    @Path("/updateDetails")
    public ServiceRequest updateDetails(ServiceRequest serviceRequest) {
        return service.updateDetails(serviceRequest);
    }

    @GET
    @Path("/getActiveClassificationTypes")
    public List<ClassificationType> getActiveClassificationTypes() {
        return service.getActiveClassificationTypes();
    }

    @GET
    @Path("/getActiveServiceRequestPriorityGroups")
    public List<PriorityGroup> getActiveServiceRequestPriorityGroups() {
        return service.getActiveServiceRequestPriorityGroups();
    }

    @GET
    @Path("/getAllSites")
    public List<Site> getAllSites() {
        return service.getAllSites();
    }

    @GET
    @Path("/getActiveFacilitiesBySiteUid")
    public List<FacilitySummary> getActiveFacilitiesBySiteUid(@QueryParam("rpsuid") String rpsuid) {
        return service.getActiveFacilitiesBySiteUid(rpsuid);
    }

    @GET
    @Path("/getRoomSummariesByFacilityId")
    public List<RoomSummary> getRoomSummariesByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getRoomSummariesByFacilityId(facilityId);
    }

    @POST
    @Path("/updateLocation")
    public ServiceRequest updateLocation(ServiceRequest serviceRequest) {
        return service.updateLocation(serviceRequest);
    }

    @POST
    @Path("/updateAssets")
    public ServiceRequest updateAssets(ServiceRequest serviceRequest) {
        return service.updateAssets(serviceRequest);
    }

    @POST
    @Path("/getAssetsByIds")
    public List<AssetSummary> getAssetsByIds(List<AssetRef> assetList) {
        return service.getAssetsByIds(assetList);
    }

    @GET
    @Path("/getDocumentTypes")
    public List<String> getDocumentTypes() {
        return service.getDocumentTypes();
    }

    @GET
    @Path("/findById")
    public ServiceRequest findById(@QueryParam("id") String id) {
        return service.findById(id);
    }
}
