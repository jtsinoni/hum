package logicole.gateway.rest;

import logicole.common.general.constants.ExceptionConstants;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientResponseContext;
import javax.ws.rs.client.ClientResponseFilter;
import javax.ws.rs.core.Response;

@ApplicationScoped
public class MicroserviceClientResponseFilter implements ClientResponseFilter {
    @Override
    public void filter(ClientRequestContext clientRequestContext, ClientResponseContext clientResponseContext) {
        Response.StatusType statusInfo = clientResponseContext.getStatusInfo();
        Response.Status.Family responseFamily = statusInfo.getFamily();

        if (responseFamily != Response.Status.Family.SUCCESSFUL) {
            String customErrorMessage = clientResponseContext.getHeaderString(ExceptionConstants.CUSTOM_ERROR_MSG_HEADER_KEY);
            if (!StringUtil.isEmptyOrNull(customErrorMessage)) {
                if (responseFamily == Response.Status.Family.CLIENT_ERROR) throw new ApplicationException(customErrorMessage);
                throw new RuntimeException(customErrorMessage);
            }
        }
    }
}
