package logicole.gateway.services.spacemanagement;

import logicole.apis.space.ISpaceMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.management.AssetSummary;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.BulkUpdateResult;
import logicole.common.datamodels.general.FailedItem;
import logicole.common.datamodels.general.customfield.CustomField;
import logicole.common.datamodels.general.customfield.CustomFieldValue;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchCriterion;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.realproperty.Site;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.realproperty.facility.FacilityRef;
import logicole.common.datamodels.realproperty.lookupdata.facility.CategoryCode;
import logicole.common.datamodels.realproperty.lookupdata.facility.CategoryCodeRef;
import logicole.common.datamodels.realproperty.lookupdata.facility.DmisId;
import logicole.common.datamodels.realproperty.lookupdata.facility.DmisIdRef;
import logicole.common.datamodels.realpropertyproject.Requirement;
import logicole.common.datamodels.realpropertyproject.project.RealPropertyProject;
import logicole.common.datamodels.realpropertysection.Section;
import logicole.common.datamodels.space.AssociatedRecordsWithRoom;
import logicole.common.datamodels.space.AuditSearch;
import logicole.common.datamodels.space.BulkDataFieldUpdate;
import logicole.common.datamodels.space.BulkFieldUpdateValue;
import logicole.common.datamodels.space.Floor;
import logicole.common.datamodels.space.FloorPlanLegendEntry;
import logicole.common.datamodels.space.GraphicalSearchRecord;
import logicole.common.datamodels.space.Occupant;
import logicole.common.datamodels.space.OccupantRef;
import logicole.common.datamodels.space.OccupantSummary;
import logicole.common.datamodels.space.RoomAdditional;
import logicole.common.datamodels.space.RoomAttribute;
import logicole.common.datamodels.space.RoomAttributeBulkUpdates;
import logicole.common.datamodels.space.RoomAudit;
import logicole.common.datamodels.space.RoomAuditDataBulkUpdate;
import logicole.common.datamodels.space.RoomBulkMultiUpdate;
import logicole.common.datamodels.space.RoomClassification;
import logicole.common.datamodels.space.RoomCleaningRequirement;
import logicole.common.datamodels.space.RoomCommunication;
import logicole.common.datamodels.space.RoomDataDrop;
import logicole.common.datamodels.space.RoomHazard;
import logicole.common.datamodels.space.RoomHazardBulkUpdates;
import logicole.common.datamodels.space.RoomHeader;
import logicole.common.datamodels.space.RoomMeasurement;
import logicole.common.datamodels.space.RoomOccupancy;
import logicole.common.datamodels.space.RoomOccupancyBulkUpdates;
import logicole.common.datamodels.space.RoomSummary;
import logicole.common.datamodels.space.RoomTypeAndCodeBulkUpdate;
import logicole.common.datamodels.space.Space;
import logicole.common.datamodels.space.SpaceDashboardInfo;
import logicole.common.datamodels.space.SpaceRef;
import logicole.common.datamodels.space.Zone;
import logicole.common.datamodels.space.cobie.export.FloorCOBieExportData;
import logicole.common.datamodels.space.cobie.export.SpaceCOBieExportData;
import logicole.common.datamodels.space.cobie.export.ZoneCOBieExportData;
import logicole.common.datamodels.space.cobie.staging.COBieFileImport;
import logicole.common.datamodels.space.cobie.staging.COBieFloorImportSummary;
import logicole.common.datamodels.space.cobie.staging.COBieSpaceImportSummary;
import logicole.common.datamodels.space.cobie.staging.COBieZoneImportSummary;
import logicole.common.datamodels.space.lookupdata.AttributeType;
import logicole.common.datamodels.space.lookupdata.EMeasurementUnit;
import logicole.common.datamodels.space.lookupdata.HazardType;
import logicole.common.datamodels.space.lookupdata.SpaceType;
import logicole.common.datamodels.space.lookupdata.SpaceTypeRef;
import logicole.common.datamodels.system.EBusinessArea;
import logicole.common.datamodels.system.TagRef;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.AssetService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.realproperty.InstallationService;
import logicole.gateway.services.realproperty.RealPropertyLookupService;
import logicole.gateway.services.realpropertyproject.ProjectService;
import logicole.gateway.services.realpropertyproject.RequirementService;
import logicole.gateway.services.realpropertysection.SectionService;
import logicole.gateway.services.system.TagService;
import logicole.gateway.services.workorder.WorkOrderService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.QueryParam;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@ApplicationScoped
public class SpaceManagementService extends BaseGatewayService<ISpaceMicroserviceApi> {

    @Inject
    AssetService assetService;

    @Inject
    DrawingService drawingService;

    @Inject
    FacilityService facilityService;

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    InstallationService installationService;

    @Inject
    ProjectService projectService;

    @Inject
    RealPropertyLookupService realPropertyLookupService;

    @Inject
    RequirementService requirementService;

    @Inject
    SectionService sectionService;

    @Inject
    SpaceLookupService spaceLookupService;

    @Inject
    SpaceManagementService spaceManagementService;

    @Inject
    TagService tagService;

    @Inject
    WorkOrderService workOrderService;

    @Inject
    private StringUtil stringUtil;
    
    @Inject
    OrganizationService organizationService;

    public static final String ELASTIC_SEARCH_NOT_SUPPORTED = "Elastic search is not supported now";
    public static final String ACTIVE = "ACTIVE";
    public static final String INACTIVE = "INACTIVE";

    public SpaceManagementService() {
        super("SpaceManagement");
    }

    public Floor getFloorById(String id) {
        return microservice.getFloorById(id);
    }

    public Floor getFloorBySpaceId(String spaceId) {
        Space space = getRoomById(spaceId);
        if (space != null && space.floorRef != null && !StringUtil.isEmptyOrNull(space.floorRef.id)) {
            return getFloorById(space.floorRef.id);
        } else {
            return null;
        }
    }

    public Occupant getOccupantById(String id) {
        return microservice.getOccupantById(id);
    }

    public Space getRoomById(String id) {
        return microservice.getRoomById(id);
    }

    public List<Space> getRoomsByIds(List<String> ids) {
        return microservice.getRoomsByIds(ids);
    }

    public List<Space> getRoomsById(List<SpaceRef> roomList) {
        return microservice.getRoomsById(roomList);
    }

    public Space getRoomByRoomNumber(String facilityId, String roomNumber) {
        return microservice.getRoomByRoomNumber(facilityId, roomNumber);
    }

    public Occupant getOccupantByCustomerIdAndManagedByNode(String customerId, String managedByNodeId) {
        return microservice.getOccupantByCustomerIdAndManagedByNode(customerId, managedByNodeId);
    }

    public List<Occupant> getOccupantsByDepartmentIdAndSite(String departmentId, String siteId) {
        return microservice.getOccupantsByDepartmentIdAndSite(departmentId, siteId);
    }

    public SearchResult<OccupantSummary> getOccupantSearchResults(SearchInput searchInput) throws ApplicationException {
        ESearchEngine searchEngine = microservice.getOccupantSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException(ELASTIC_SEARCH_NOT_SUPPORTED);
        } else {
        	if (StringUtil.isEmptyOrNull(searchInput.searchText) ||
        			searchInput.searchText.trim().length() < 3) {
        		throw new ApplicationException("Search criteria must be at least 3 characters");
        	}
        	
            SearchResult<OccupantSummary> convertedResult = new SearchResult<>();
            List<Site> siteList = installationService.getAllSites(false);
            if (ListUtil.isEmpty(siteList)) {
                return convertedResult;
            }

            List<String> allowedSiteIds = siteList.stream().map(Site::getId).collect(Collectors.toList());
            SearchCriterion siteCriterion = new SearchCriterion();
            siteCriterion.propValues = allowedSiteIds.toArray();
            siteCriterion.propName = "siteId";
            siteCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
            searchInput.searchCriteria.add(siteCriterion);
            
            organizationService.setRPFuncFilterInSearch(searchInput);
            SearchResult<Occupant> searchResult = microservice.getOccupantSearchResults(searchInput);
            convertedResult.aggregations = searchResult.aggregations;

            if (!ListUtil.isEmpty(searchResult.results)) {
                List<OccupantSummary> allOccupantSummaries = new ArrayList<>();

                List <String> occupantIds = searchResult.results.stream()
                        .map(occupant -> occupant._id.toString())
                        .collect(Collectors.toList());

                List<Space> spaceList = microservice.getRoomsByOccupantIds(occupantIds);

                for (Occupant occupant : searchResult.results) {
                    OccupantSummary occupantSummary = convertOccupantToOccupantSummary(occupant);
                    occupantSummary.roomIdList = new ArrayList<>();

                    List <Space> spaces = getSpacesForOccupant(spaceList, occupant.getId());

                    for (Space space : spaces) {
                        occupantSummary.roomIdList.add(space.getId());
                    }

                    allOccupantSummaries.add(occupantSummary);
                }

                convertedResult.results = allOccupantSummaries;
                convertedResult.total = searchResult.total;
                convertedResult.limit = searchResult.limit;
            }

            return convertedResult;
        }
    }

    List <Space> getSpacesForOccupant(List <Space> spaceList, String occupantId) {
        List <Space> spaces = new ArrayList();
        spaceList.forEach( space -> {
            List <RoomOccupancy> occupants = space.occupants;

            occupants.forEach( occupant -> {
               OccupantRef ref = occupant.occupantRef;
               if (ref.id.equalsIgnoreCase(occupantId)) {
                   spaces.add(space);
               }
            });
        });

        return spaces;
    }

    public List<OccupantSummary> getOccupantsByRoomId(String roomId) {
        return microservice.getOccupantsByRoomId(roomId);
    }

    public List<OccupantSummary> getOccupantsByRoomIds(List<String> roomIdList) {
        return microservice.getOccupantsByRoomIds(roomIdList);
    }

    public List<Space> getRoomsByFacilityId(String facilityId) {
        return microservice.getRoomsByFacilityId(facilityId);
    }

    public List<Space> getRoomsByFacilityIds(List<String> facilityIds) {
        return microservice.getRoomsByFacilityIds(facilityIds);
    }

    public long getRoomStatusCountByFacilityId(String facilityId, Boolean isActive) {
        return microservice.getRoomStatusCountByFacilityId(facilityId, isActive);
    }

    public List<Space> getRoomsByFloorId(String floorId) {
        return microservice.getRoomsByFloorId(floorId);
    }

    public List<Space> getRoomsByOccupantId(String occupantId) {
        return microservice.getRoomsByOccupantId(occupantId);
    }

    public List<Space> getRoomsByOccupantIdAndStatus(String occupantId, String selectedStatus) {
        List<Space> roomsList = microservice.getRoomsByOccupantId(occupantId);
        List<Space> activeRoomSummeries = new ArrayList<>();
        List<Space> inactiveRoomSummeries = new ArrayList<>();
        for (Space space : roomsList) {
            if (space.isRecordActive) {
                activeRoomSummeries.add(space);
            } else {
                inactiveRoomSummeries.add(space);
            }
        }

        if (selectedStatus.equals(ACTIVE)) {
            return activeRoomSummeries;
        } else if (selectedStatus.equals(INACTIVE)) {
            return inactiveRoomSummeries;
        } else {
            return roomsList;
        }
    }

    public List<RoomSummary> getRoomSummeries(String selectedStatus) {
        List<Facility> facilities = facilityService.getAllFacilities();
        List<RoomSummary> allRoomSummeries = new ArrayList<>();
        List<RoomSummary> activeRoomSummeries = new ArrayList<>();
        List<RoomSummary> inactiveRoomSummeries = new ArrayList<>();

        // Get the Rooms for Each facility...
        for (Facility facility : facilities) {
            List<Space> roomsList = getRoomsByFacilityId(facility.getId());

            for (Space space : roomsList) {
                RoomSummary summary = new RoomSummary();
                summary.setId(space.getId());

                summary = convertRoomToRoomSummary(space);

                allRoomSummeries.add(summary);
                if (summary.isRoomActive) {
                    activeRoomSummeries.add(summary);
                } else {
                    inactiveRoomSummeries.add(summary);
                }
            }
        }

        if (selectedStatus.equals(ACTIVE)) {
            return activeRoomSummeries;
        } else if (selectedStatus.equals(INACTIVE)) {
            return inactiveRoomSummeries;
        } else {
            return allRoomSummeries;
        }
    }

    public List<RoomSummary> getRoomSummaryByFacilityId(String facilityId, String selectedStatus) {
        List<RoomSummary> roomSummaries = new ArrayList<>();

        if (!StringUtil.isBlankOrNull(facilityId)) {
            List<String> facilityIds = new ArrayList<>();
            facilityIds.add(facilityId);

            roomSummaries = getSpacesByFacilityIds(facilityIds, selectedStatus, Boolean.FALSE);
        }
        return roomSummaries;
    }

    public List<RoomSummary> getSpacesSimpleInfoByFacilityIds(List<String> facilityIds, String selectedStatus) {
        return getSpacesByFacilityIds(facilityIds, selectedStatus, Boolean.TRUE);
    }

    private List<RoomSummary> getSpacesByFacilityIds(List<String> facilityIds, String selectedStatus, Boolean isProjected) {
        List<RoomSummary> roomSummaries = new ArrayList<>();

        if (!ListUtil.isEmpty(facilityIds)) {
            Boolean isActive = null;
            if (!StringUtil.isEmptyOrNull(selectedStatus)) {
                if (selectedStatus.equals(ACTIVE)) {
                    isActive = Boolean.TRUE;
                } else if (selectedStatus.equals(INACTIVE)) {
                    isActive = Boolean.FALSE;
                }
            }

            List<Space> roomList = microservice.getSpacesByFacilityIds(facilityIds, isActive, isProjected);
            if (!ListUtil.isEmpty(roomList)) {
                roomSummaries = roomList.stream().map(this::convertRoomToRoomSummary).collect(Collectors.toList());
            }
        }
        return roomSummaries;
    }


    public List<RoomSummary> getRoomSummaryByFacilityIds(List<FacilityRef> list) {
        List<RoomSummary> roomSummaries = new ArrayList<>();
        if (!ListUtil.isEmpty(list)) {
            List<String> facilityIds = list.stream().map(FacilityRef::getId).collect(Collectors.toList());
            roomSummaries = getSpacesByFacilityIds(facilityIds, ACTIVE, Boolean.FALSE);
        }

        return roomSummaries;
    }

    public List<RoomSummary> getRoomSummaryByFloorId(String floorId, String selectedStatus) {
        List<Space> roomsList = microservice.getRoomsByFloorId(floorId);
        if (!ListUtil.isEmpty(roomsList)) {

            List<RoomSummary> allRoomSummaries = new ArrayList<>();
            List<RoomSummary> activeRoomSummaries = new ArrayList<>();
            List<RoomSummary> inactiveRoomSummaries = new ArrayList<>();

            for (Space space : roomsList) {
                RoomSummary summary = convertRoomToRoomSummary(space);

                allRoomSummaries.add(summary);
                if (summary.isRoomActive) {
                    activeRoomSummaries.add(summary);
                } else {
                    inactiveRoomSummaries.add(summary);
                }
            }

            if (selectedStatus.equals(ACTIVE)) {
                return activeRoomSummaries;
            } else if (selectedStatus.equals(INACTIVE)) {
                return inactiveRoomSummaries;
            } else {
                return allRoomSummaries;
            }
        } else {
            return new ArrayList<>();
        }
    }

    public Space createRoom(Space space) {
        checkMandatoryRoomFields(space);

        if (!isRoomNumberUnique(space.facilityRef.id, null, space.identifier)) {
            throw new ApplicationException("A Space with this Space Number already exists.");
        }

        if (space.categoryCodeRef != null && !StringUtil.isEmptyOrNull(space.categoryCodeRef.id)) {
            CategoryCode categoryCode = realPropertyLookupService.getCategoryCodeById(space.categoryCodeRef.id);
            if (categoryCode != null)
                space.categoryCodeRef = (CategoryCodeRef) categoryCode.getRef();
        }

        Facility facility = facilityService.getFacilityById(space.facilityRef.id);
        if (facility != null) {
            space.facilityRef = facility.getRef();
            space.siteRef = facility.siteRef;

            space.managedByNodeRef = facility.managedByNodeRef;
        }

        if (space.currentSpaceTypeRef != null && !StringUtil.isEmptyOrNull(space.currentSpaceTypeRef.id)) {
            SpaceType currentSpaceType = spaceLookupService.getRoomTypeById(space.currentSpaceTypeRef.id);
            if (currentSpaceType != null)
                space.currentSpaceTypeRef = (SpaceTypeRef) currentSpaceType.getRef();
        }

        if (space.designSpaceTypeRef != null && !StringUtil.isEmptyOrNull(space.designSpaceTypeRef.id)) {
            SpaceType designSpaceType = spaceLookupService.getRoomTypeById(space.designSpaceTypeRef.id);
            if (designSpaceType != null)
                space.designSpaceTypeRef = (SpaceTypeRef) designSpaceType.getRef();
        }
        if (space.dmisIdRef != null && !StringUtil.isEmptyOrNull(space.dmisIdRef.id)) {
            DmisId dmisId = realPropertyLookupService.getDmisById(space.dmisIdRef.id);
            if (dmisId != null)
                space.dmisIdRef = (DmisIdRef) dmisId.getRef();
        }

        if (space.cleaningReq == null ) {
            RoomCleaningRequirement cleanReq = new RoomCleaningRequirement();
            space.cleaningReq = cleanReq;
        }
        space.cleaningReq.areaCleanedUom = EMeasurementUnit.SF;
        
        return microservice.createRoom(space);
    }

    public Boolean deleteRoom(String id) {
        BulkUpdateResult result = new BulkUpdateResult();
        List<String> roomIds = new ArrayList<>();
        roomIds.add(id);

        List<String> qualifiedRoomIds;
        // check requirements
        qualifiedRoomIds = checkRequirementsForRoomInActive(roomIds, result.failedItems, true);

        // check - Assets
        qualifiedRoomIds = checkAssetsForRoomInActive(qualifiedRoomIds, result.failedItems, true);

        // check - Projects
        qualifiedRoomIds = checkProjectsForRoomInActive(qualifiedRoomIds, result.failedItems, true);

        // check - Work Orders.
        qualifiedRoomIds = checkWorkOrdersForRoomInActive(qualifiedRoomIds, result.failedItems, true);

        // check - Drawings
        qualifiedRoomIds = checkDrawingsForRoomInActive(qualifiedRoomIds, result.failedItems, true);


        if (ListUtil.isEmpty(qualifiedRoomIds)) {
            throw new ApplicationException(result.failedItems.get(0).errorMsg);
        }

        return microservice.deleteRoom(id);
    }

    public BulkUpdateResult createRooms(List<Space> spaces) {
        BulkUpdateResult results = new BulkUpdateResult();

        for (int i = 0; i < spaces.size(); i++) {
            Space space = spaces.get(i);
            try {
                createRoom(space);
                results.succeedItems.add(String.valueOf(i));
            } catch (ApplicationException e) {
                logger.error(e);
                FailedItem failedItem = new FailedItem();
                failedItem.id = String.valueOf(i);
                failedItem.errorMsg = e.getMessage();
                results.failedItems.add(failedItem);
            }
        }

        return results;
    }

    private Double getPrimaryRoomSizeByRoom(Space space) {
        Double primaryRoomSize = 0.000;
        if (space != null && space.measurement != null && space.measurement.size != null) {
            primaryRoomSize = space.measurement.size;
        }
        primaryRoomSize = Double.parseDouble(String.format("%.3f", primaryRoomSize));

        return primaryRoomSize;
    }

    private void setPrimaryInformation(Space space, RoomSummary summary) {
        // Need to convert to Occupant to get the customerName
        if (space != null && !ListUtil.isEmpty(space.occupants)) {
            Occupant occupant;
            List<RoomOccupancy> roomOccupancies = space.occupants;
            if (roomOccupancies.size() > 0) {
                for (RoomOccupancy roomOccupancy : roomOccupancies) {
                    if (roomOccupancy != null) {
                        Boolean isPrimary = false;
                        isPrimary = roomOccupancy.isPrimary;
                        if (isPrimary != null && isPrimary) {
                            if (roomOccupancy.occupantRef != null) {
                                summary.primaryOrganizationIdentifier = roomOccupancy.occupantRef.customerId;
                                summary.primaryOrganizationName = roomOccupancy.occupantRef.customerName;
                                summary.primaryDepartmentIdentifier = roomOccupancy.occupantRef.departmentId;
                                summary.primaryDepartmentName = roomOccupancy.occupantRef.departmentName;
                            }
                        }
                        break;
                    }
                }
            }
        }
    }

    public Occupant createOccupant(Occupant occupant) {
        validateOccupant(occupant);
        return microservice.createOccupant(occupant);
    }

    public Occupant deleteOccupantById(String occupantId) {
        return microservice.deleteOccupantById(occupantId);
    }

    public Floor updateFloor(Floor floorToUpdate) {
        return microservice.updateFloor(floorToUpdate);
    }

    public Occupant updateOccupant(Occupant occupant) {
        validateOccupant(occupant);
        return microservice.updateOccupant(occupant);
    }

    private void validateOccupant(Occupant occupant) {
        if (!hasMandatoryOccupantFields(occupant)) {
            throw new ApplicationException("The Occupant does not have all mandatory fields.");
        }

        if (!isOccupantUnique(occupant.customerId, occupant.managedByNodeRef.getId(), occupant.getId())) {
            throw new ApplicationException(
                    String.format("An Occupant already exists at this Responsible Organization with Service Identifier: %s", occupant.customerId));
        }

        String departmentName = getExistingOccupantDepartmentName(occupant.departmentId, occupant.siteRef.getId(), occupant.getId());
        if (departmentName != null && !departmentName.equalsIgnoreCase(occupant.departmentName)) {
            throw new ApplicationException(
                    String.format("This Department Identifier already exists with Department Name: %s", departmentName));
        }
    }

    public Space updateRoom(Space space) {
//    	if (!isRoomNumberUnique(room.facilityRef.id, null, room.roomNumber)) {
//            throw new ApplicationException("A Space with this Space Number already exists.");
//        }
        return microservice.updateRoom(space);
    }

    public Space updateRoomAdditional(RoomAdditional roomAdditional) {
        roomAdditional.tagRefList = tagService.verifyAndAddTags(roomAdditional.tagRefList, EBusinessArea.SPACE_ROOMS);
        return microservice.updateRoomAdditional(roomAdditional);
    }

    public Space updateRoomAudit(RoomAudit roomAudit) {
        return microservice.updateRoomAudit(roomAudit);
    }

    public List<Floor> getFloorsByFacilityId(String facilityId) {
        return microservice.getFloorsByFacilityId(facilityId);
    }

    public Floor deleteFloorById(String floorId) {
        List<Space> spaces = getRoomsByFloorId(floorId);
        if (!ListUtil.isEmpty(spaces)) {
            throw new ApplicationException("This record has space records associated and cannot be deleted until the floor is removed from all associated space records.");
        }

        Floor floor = getFloorById(floorId);
        if (floor.drawing != null) {
            throw new ApplicationException("This record has a drawing associated and cannot be deleted until all associated drawings are deleted.");
        }

        List<String> floorIds = new ArrayList<>();
        floorIds.add(floorId);
        List<Section> sections = sectionService.getSectionsByFloorIds(floorIds);
        if (!ListUtil.isEmpty(sections)) {
            throw new ApplicationException("This record has section records associated and cannot be deleted until the floor is removed from all associated section records.");
        }

        return microservice.deleteFloorById(floorId);
    }

    public Floor addFloorToFacility(String facilityId, Floor floorToAdd) {
        checkMandatoryFloorFields(floorToAdd);

        if (!isFloorNumberUnique(facilityId, floorToAdd.identifier)) {
            throw new ApplicationException("A Floor with this Floor Number already exists.");
        }


        if (floorToAdd.facilityRef == null || floorToAdd.siteRef == null || floorToAdd.managedByNodeRef == null) {
            Facility facility = facilityService.getFacilityById(facilityId);
            floorToAdd.facilityRef = facility.getRef();
            floorToAdd.siteRef = facility.siteRef;
            floorToAdd.managedByNodeRef = facility.managedByNodeRef;
        }

        return microservice.addFloor(floorToAdd);
    }

    public BulkUpdateResult createFloors(List<Floor> floors) {
        BulkUpdateResult results = new BulkUpdateResult();

        for (Floor floor : floors) {
            try {
                addFloorToFacility(floor.facilityRef.id, floor);
                results.succeedItems.add(floor.identifier);
            } catch (ApplicationException e) {
                logger.error(e);
                FailedItem failedItem = new FailedItem();
                failedItem.id = floor.identifier;
                failedItem.errorMsg = e.getMessage();
                results.failedItems.add(failedItem);
            }
        }

        return results;
    }

    public Space updateRoomAttributes(String roomId, List<RoomAttribute> roomAttribute) throws ApplicationException {
        return microservice.updateRoomAttributes(roomId, roomAttribute);
    }

    public Space updateRoomClassification(RoomClassification roomClassification) {
        return microservice.updateRoomClassification(roomClassification);
    }

    public Space updateRoomCleaningRequirement(String roomId, RoomCleaningRequirement roomCleaningRequirement) {
        return microservice.updateRoomCleaningRequirement(roomId, roomCleaningRequirement);
    }

    public Space updateRoomCommunication(RoomCommunication roomCommunication) throws ApplicationException {
        return microservice.updateRoomCommunication(roomCommunication);
    }

    public Space updateRoomDataDrops(String roomId, List<RoomDataDrop> roomDataDrops) throws ApplicationException {
        return microservice.updateRoomDataDrops(roomId, roomDataDrops);
    }

    public Space updateRoomHeader(RoomHeader roomHeader) throws ApplicationException {
        if (!isRoomNumberUnique(roomHeader.facilityRef.id, roomHeader.roomId, roomHeader.identifier)) {
            throw new ApplicationException("A Space with this Space Number already exists.");
        }
        return microservice.updateRoomHeader(roomHeader);
    }

    public Space updateRoomMeasurement(String roomId, RoomMeasurement roomMeasurement) {
        return microservice.updateRoomMeasurement(roomId, roomMeasurement);
    }

    public Space updateRoomOccupancy(String roomId, List<OccupantSummary> occupants) {
        return microservice.updateRoomOccupancy(roomId, occupants);
    }

    public Space updateRoomHazards(String roomId, List<RoomHazard> roomHazards) throws ApplicationException {
        return microservice.updateRoomHazards(roomId, roomHazards);
    }

    public BulkUpdateResult updateRoomActive(String roomId, Boolean isActive) throws ApplicationException {
        BulkUpdateResult result = new BulkUpdateResult();
        List<String> roomIds = new ArrayList<>();
        roomIds.add(roomId);

        List<String> qualifiedRoomIds;
        if (!isActive) {
            // check requirements
            qualifiedRoomIds = checkRequirementsForRoomInActive(roomIds, result.failedItems, false);

            // check - Assets
            qualifiedRoomIds = checkAssetsForRoomInActive(qualifiedRoomIds, result.failedItems, false);

            // check - Projects
            qualifiedRoomIds = checkProjectsForRoomInActive(qualifiedRoomIds, result.failedItems, false);

            // check - Work Orders.
            qualifiedRoomIds = checkWorkOrdersForRoomInActive(qualifiedRoomIds, result.failedItems, false);

            // check - Drawings
            qualifiedRoomIds = checkDrawingsForRoomInActive(qualifiedRoomIds, result.failedItems, false);

        } else {
            //If we set a space record to active, the Facility must be active, else it fails.
            qualifiedRoomIds = checkFacilitiesForRoomActive(roomIds, result.failedItems);
        }

        if (!ListUtil.isEmpty(qualifiedRoomIds)) {
            microservice.updateRoomActive(roomId, isActive);
        }

        return result;
    }

    public Space saveRoomNote(String roomId, Note roomNote) throws ApplicationException {
        return microservice.saveRoomNote(roomId, roomNote);
    }

    public Space deleteRoomNote(String roomId, String noteId) throws ApplicationException {
        return microservice.deleteRoomNote(roomId, noteId);
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) throws ApplicationException {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        } catch (BadRequestException e) {
            throw e;
        }

        return uploadedFile;
    }

    public Integer getMaxRoomAttachmentSize() {
        return microservice.getMaxSpaceAttachmentSize();
    }

    public Integer getMaxUploadSize() {
        return microservice.getMaxUploadSize();
    }

    public Attachment saveRoomAttachment(String roomId, Attachment attachmentToSave) throws ApplicationException {
        return microservice.saveRoomAttachment(roomId, attachmentToSave);
    }

    public boolean removeRoomAttachment(String roomId, String fileId) throws ApplicationException {
        //This removes the file
        try {
            fileManagerAdminService.removeFile(fileId);
        } catch (IOException | ApplicationException e) {
            throw new ApplicationException("Was not able to upload the file");
        }

        return microservice.removeRoomAttachment(roomId, fileId);
    }

    private RoomSummary convertRoomToRoomSummary(Space space) {
        RoomSummary summary = new RoomSummary();
        summary.setId(space.getId());

        summary.siteName = space.siteRef.name;
        summary.facilityName = space.facilityRef.name;
        summary.facilityNumber = space.facilityRef.facilityNumber;
        if (space.floorRef != null) {
            summary.floorNumber = space.floorRef.identifier;
        }
        summary.roomName = space.localName;
        summary.roomNumber = space.identifier;
        summary.localRoomNumber = space.localNumber;
        if (space.currentSpaceTypeRef != null) {
            summary.roomType = space.currentSpaceTypeRef.name;
        }

        summary.primaryRoomSize = getPrimaryRoomSizeByRoom(space);

        setPrimaryInformation(space, summary);

        if (space.dmisIdRef != null) {
            summary.dmisName = space.dmisIdRef.dmisId + " - " + space.dmisIdRef.facilityName;
        }

        summary.isRoomActive = space.isRecordActive;

        String zoneRefNames = "";
        for (int i = 0; space.zoneRefs != null && i < space.zoneRefs.size(); i++) {
            zoneRefNames += space.zoneRefs.get(i).name;
            if (i + 1 != space.zoneRefs.size()) {
                zoneRefNames += ", ";
            }
        }

        if (space.zoneRefs != null && space.zoneRefs.size() > 0) {
            summary.zoneRefName = zoneRefNames;
        }

        summary.lastAuditDate = space.lastAuditDate;
        summary.lastAuditBy = space.lastAuditBy;
        if (space.categoryCodeRef != null) {
            summary.categoryCode = space.categoryCodeRef.code + " - " + space.categoryCodeRef.name;
        }
        summary.currentCode = space.currentCode;
        if (space.currentSpaceTypeRef != null) {
            summary.currentRoomType = space.currentSpaceTypeRef.name;
        }
        summary.designCode = space.designCode;
        if (space.designSpaceTypeRef != null) {
            summary.designRoomType = space.designSpaceTypeRef.name;
        }

        summary.signageName = space.signageName;
        summary.tagRefList = space.tagRefList;
        summary.isVacant = space.isVacant;

        return summary;
    }

    public List<RoomSummary> searchRoomSummaries(String searchInput) {
        List<Space> roomsList = microservice.searchRooms(searchInput);
        List<RoomSummary> allRoomSummeries = new ArrayList<>();

        if (!ListUtil.isEmpty(roomsList)) {
            for (Space space : roomsList) {
                allRoomSummeries.add(convertRoomToRoomSummary(space));
            }
        }

        return allRoomSummeries;
    }

    public List<String> getRoomNames() {
        List<Facility> facilityList = facilityService.getAllFacilities();

        List <String> facilityIds = facilityList.stream()
                .map(facility -> facility._id.toString())
                .collect(Collectors.toList());

        List <Space> spaceList = microservice.getRoomsByFacilityIds(facilityIds);

        List <String> roomNamesList = spaceList.stream()
                .map(space -> space.localName)
                .distinct()
                .filter(name -> name != null && name.length() > 0)
                .collect(Collectors.toList());

        if (roomNamesList.size() > 1)
            Collections.sort(roomNamesList);

        return roomNamesList;
    }

    public boolean isRoomNumberUnique(String facilityId, String roomId, String roomNum) {
        boolean isUnique = true;

        List<Space> roomsList = getRoomsByFacilityId(facilityId);

        for (Space space : roomsList) {
            if (StringUtil.safeEqualsIgnoreCase(space.identifier, roomNum)
                    && (StringUtil.isBlankOrNull(roomId) || !StringUtil.safeEqualsIgnoreCase(space.getId(), roomId))) {
                isUnique = false;
            }
        }

        return isUnique;
    }

    public boolean isFloorNumberUnique(String facilityId, String floorNumber) {
        boolean isUnique = true;

        List<Floor> floorsList = getFloorsByFacilityId(facilityId);

        for (Floor floor : floorsList) {
            if (StringUtil.safeEqualsIgnoreCase(floor.identifier, floorNumber)) {
                isUnique = false;
                break;
            }
        }

        return isUnique;
    }

    public boolean isOccupantUnique(String customerId, String managedByNodeId, String occupantIdToIgnore) {
        boolean isUnique = true;
        if (!StringUtil.isBlankOrNull(customerId) && !StringUtil.isBlankOrNull(managedByNodeId)) {
            Occupant persistedOccupant = getOccupantByCustomerIdAndManagedByNode(customerId, managedByNodeId);
            if (persistedOccupant != null && !persistedOccupant.getId().equals(occupantIdToIgnore)) {
                isUnique = false;
            }
        }
        return isUnique;
    }

    public boolean isZoneUnique(Zone zone) {
        boolean isUnique = true;

        List<Zone> zonesList = getZonesByFacilityId(zone.facilityRef.id);

        for (Zone currentZone : zonesList) {
            if (StringUtil.safeEqualsIgnoreCase(currentZone.name, zone.name)
                    && StringUtil.safeEqualsIgnoreCase(currentZone.zoneTypeRef.id, zone.zoneTypeRef.id)) {
                isUnique = false;
                break;
            }
        }

        return isUnique;
    }

    public String getExistingOccupantDepartmentName(String departmentId, String siteId, String occupantIdToIgnore) {
        // If siteRef is populated, this can be used to enforce consistency between departmentId and departmentName
        String deptName = null;
        if (!StringUtil.isBlankOrNull(departmentId) && !StringUtil.isBlankOrNull(siteId)) {
            List<Occupant> occupants = getOccupantsByDepartmentIdAndSite(departmentId, siteId);
            for (Occupant occupant : occupants) {
                if (!StringUtil.safeEquals(occupant.getId(), occupantIdToIgnore)) {
                    deptName = occupant.departmentName;
                    break;
                }
            }
        }
        return deptName;
    }

    public void checkMandatoryRoomFields(Space space) {
        if (space.facilityRef == null || StringUtil.isEmptyOrNull(space.facilityRef.id)) {
            throw new ApplicationException("The Space does not have a Facility.");
        }

        if (StringUtil.isEmptyOrNull(space.identifier)) {
            throw new ApplicationException("The Space does not have a Room Number.");
        }

        if (StringUtil.isEmptyOrNull(space.localName)) {
            throw new ApplicationException("The Space does not have a Room Name.");
        }

        if (space.currentSpaceTypeRef == null || StringUtil.isEmptyOrNull(space.currentSpaceTypeRef.id)) {
            throw new ApplicationException("The Space does not have a Current Room Type.");
        }

        if (space.measurement == null) {
            throw new ApplicationException("The Space does not have measurements.");
        }

        if (space.occupants == null) {
            throw new ApplicationException("The Space does not have a matching occupant.");
        }
    }

    public void checkMandatoryFloorFields(Floor floor) {
        if (StringUtil.isEmptyOrNull(floor.identifier)) {
            throw new ApplicationException("The Floor does not have a Floor Number.");
        }

        if (StringUtil.isEmptyOrNull(floor.name)) {
            throw new ApplicationException("The Floor does not have a Floor Name.");
        }
    }

    public void checkMandatoryZoneFields(Zone zone) {
        if (zone.facilityRef == null || StringUtil.isEmptyOrNull(zone.facilityRef.id)) {
            throw new ApplicationException("The Zone does not have a Facility.");
        }

        if (StringUtil.isEmptyOrNull(zone.name)) {
            throw new ApplicationException("The Zone does not have a Zone Name.");
        }

        if (zone.zoneTypeRef == null) {
            throw new ApplicationException("The Zone does not have a Zone Type.");
        }
    }

    public boolean hasMandatoryOccupantFields(Occupant occupant) {
        boolean hasMandatoryOccupantFields = true;
        if (occupant.siteRef == null || StringUtil.isEmptyOrNull(occupant.siteRef.id) ||
                StringUtil.isEmptyOrNull(occupant.departmentId) || StringUtil.isEmptyOrNull(occupant.departmentName) ||
                StringUtil.isEmptyOrNull(occupant.siteRef.rpsuid) || StringUtil.isEmptyOrNull(occupant.siteRef.name) ||
                StringUtil.isEmptyOrNull(occupant.customerId) || StringUtil.isEmptyOrNull(occupant.customerName)) {
            hasMandatoryOccupantFields = false;
        }

        return hasMandatoryOccupantFields;
    }

    public Zone getZoneById(String zoneId) {
        return microservice.getZoneById(zoneId);
    }

    public List<Zone> getZonesByFacilityId(String facilityId) {
        return microservice.getZonesByFacilityId(facilityId);
    }

    public Zone deleteZoneById(String zoneId) throws ApplicationException {
        return microservice.deleteZoneById(zoneId);
    }

    public Zone addZone(Zone zone) throws ApplicationException {
        checkMandatoryZoneFields(zone);
        if (!isZoneUnique(zone)) {
            throw new ApplicationException("A Zone with this name and type already exists.");
        }
        return microservice.addZone(zone);
    }

    public Zone updateZone(Zone zone) throws ApplicationException {
        return microservice.updateZone(zone);
    }

    public List<CustomField> getAllCustomFields(@NotNull @QueryParam("customizableTypeId") String customizableTypeId) {
        return microservice.getAllCustomFields(customizableTypeId);
    }

    public List<CustomFieldValue> getAllCustomFieldValues(String id) {
        return microservice.getAllCustomFieldValues(id);
    }

    public CustomField addCustomField(@QueryParam("maxCustomFieldRecords") Integer maxCustomFieldRecords,
                                      @NotNull CustomField customField) {
        return microservice.addCustomField(maxCustomFieldRecords, customField);
    }

    public CustomField updateCustomField(@NotNull CustomField customField) {
        return microservice.updateCustomField(customField);
    }

    public void deleteCustomField(@NotNull CustomField customField) {
        microservice.deleteCustomField(customField);
    }

    public boolean checkIfCustomFieldValuesExist(@NotNull @QueryParam("customFieldId") String customFieldId) {
        return microservice.checkIfCustomFieldValuesExist(customFieldId);
    }

    public boolean checkDuplicateLabel(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                       @QueryParam("label") String label) {
        return microservice.checkDuplicateLabel(customizableTypeId, label);
    }

    public List<CustomFieldValue> saveCustomFieldValues(String id, List<CustomFieldValue> customFieldValues) {
        return microservice.saveCustomFieldValues(id, customFieldValues);
    }

    public SearchResult<RoomSummary> getRoomSearchResults(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getRoomSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException(ELASTIC_SEARCH_NOT_SUPPORTED);
        } else {
        	if (StringUtil.isEmptyOrNull(searchInput.searchText) ||
        			searchInput.searchText.trim().length() < 3) {
        		throw new ApplicationException("Search criteria must be at least 3 characters");
        	}

            SearchResult<RoomSummary> convertedResult = new SearchResult<>();

            organizationService.setRPFuncFilterInSearch(searchInput);

            SearchResult<Space> searchResult = microservice.getRoomSearchResults(searchInput);
            convertedResult.aggregations = searchResult.aggregations;

            if (!ListUtil.isEmpty(searchResult.results)) {
                List<RoomSummary> allRoomSummaries = new ArrayList<>();

                for (Space space : searchResult.results) {
                    allRoomSummaries.add(convertRoomToRoomSummary(space));
                }

                convertedResult.results = allRoomSummaries;
                convertedResult.total = searchResult.total;
                convertedResult.limit = searchResult.limit;
            }
            return convertedResult;
        }
    }

    public SearchResult<Floor> getFloorSearchResults(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getFloorSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException(ELASTIC_SEARCH_NOT_SUPPORTED);
        } else {
            organizationService.setRPFuncFilterInSearch(searchInput);
            return microservice.getFloorSearchResults(searchInput);
        }
    }

    public List<RoomSummary> getRoomSummariesByAuditDateRange(AuditSearch auditSearch) {
        if (auditSearch.startDate == null && auditSearch.endDate == null) {
            throw new ApplicationException("Either Start Date, End Date or both must be supplied");
        }

        auditSearch.facilityIds = facilityService.getUserFacilityIdList("ACTIVE");
        return microservice.getSpacesByAuditDateRange(auditSearch);
    }

    public SpaceDashboardInfo getSpaceDashboardCounts() {
        return microservice.getSpaceDashboardCounts(facilityService.getUserFacilityIdList("ACTIVE"));
    }

    public Occupant setOccupantActive(String occupantId, Boolean isActive) {
        Occupant occupant = getOccupantById(occupantId);
        occupant.isActive = isActive;
        updateOccupant(occupant);

        if (!isActive) {
            List<Space> spaces = getRoomsByOccupantId(occupantId);
            if (!spaces.isEmpty()) {
                for (Space occupantRoom : spaces) {
                    for (int i = 0; i < occupantRoom.occupants.size(); i++) {
                        if (occupantId.equalsIgnoreCase(occupantRoom.occupants.get(i).occupantRef.id)) {
                            occupantRoom.occupants.remove(i);
                            updateRoom(occupantRoom);
                            break;
                        }
                    }
                }
            }
        }
        return occupant;
    }

    public int bulkUpdateRoomHazardsToRooms(RoomHazardBulkUpdates roomHazardBulkUpdates) {
        return microservice.bulkUpdateRoomHazardsToRooms(roomHazardBulkUpdates);
    }

    public int bulkUpdateRoomAttributesToRooms(RoomAttributeBulkUpdates roomAttributeBulkUpdates) {
        return microservice.bulkUpdateRoomAttributesToRooms(roomAttributeBulkUpdates);
    }

    public int bulkUpdateRoomOccupanciesToRooms(RoomOccupancyBulkUpdates roomOccupancyBulkUpdates) {
        return microservice.bulkUpdateRoomOccupanciesToRooms(roomOccupancyBulkUpdates);
    }

    public int bulkUpdateRoomTypeAndCodeToRoom(RoomTypeAndCodeBulkUpdate roomTypeAndCodeBulkUpdate) {
        return microservice.bulkUpdateRoomTypeAndCodeToRoom(roomTypeAndCodeBulkUpdate);
    }

    public int bulkUpdateRoomAuditDataToRooms(RoomAuditDataBulkUpdate roomAuditDataBulkUpdate) {
        return microservice.bulkUpdateRoomAuditDataToRooms(roomAuditDataBulkUpdate);
    }

    public List<Occupant> getActiveOccupantsBySite(String siteId, Boolean isActive) {
        return microservice.getActiveOccupantsBySite(siteId, isActive);
    }

    public List<Occupant> getActiveOccupantsBySiteIds(List<String> siteIds, Boolean isActive) {
        return microservice.getActiveOccupantsBySiteIds(siteIds, isActive);
    }

    public long setRoomsActiveByFacilityIds(List<String> facilityIds) {
        return microservice.setRoomsActiveByFacilityIds(facilityIds);
    }

    public BulkUpdateResult bulkSetRoomActiveToRooms(List<String> roomIds) {
        BulkUpdateResult result = new BulkUpdateResult();
        //If we set a space record to active, the Facility must be active, else it fails.
        List<String> qualifiedRoomIds = checkFacilitiesForRoomActive(roomIds, result.failedItems);

        BulkUpdateResult spaceSeviceResult = microservice.bulkSetRoomActiveToRooms(qualifiedRoomIds);
        result.succeedItems.addAll(spaceSeviceResult.succeedItems);
        result.failedItems.addAll(spaceSeviceResult.failedItems);

        return result;
    }

    public BulkUpdateResult bulkSetRoomInactiveToRooms(List<String> roomIds) {
        BulkUpdateResult result = new BulkUpdateResult();
        List<String> qualifiedRoomIds;
        // check requirements
        qualifiedRoomIds = checkRequirementsForRoomInActive(roomIds, result.failedItems, false);

        // check - Assets
        qualifiedRoomIds = checkAssetsForRoomInActive(qualifiedRoomIds, result.failedItems, false);

        // check - Projects
        qualifiedRoomIds = checkProjectsForRoomInActive(qualifiedRoomIds, result.failedItems, false);

        // check - Work Orders.
        qualifiedRoomIds = checkWorkOrdersForRoomInActive(qualifiedRoomIds, result.failedItems, false);

        // check - Drawings
        qualifiedRoomIds = checkDrawingsForRoomInActive(qualifiedRoomIds, result.failedItems, false);

        if (!ListUtil.isEmpty(qualifiedRoomIds)) {
            BulkUpdateResult spaceServiceResult = microservice.bulkSetRoomInactiveToRooms(qualifiedRoomIds);
            result.succeedItems.addAll(spaceServiceResult.succeedItems);
            result.failedItems.addAll(spaceServiceResult.failedItems);
        }

        return result;
    }

    private List<String> checkFacilitiesForRoomActive(List<String> roomIds, List<FailedItem> failedItems) {
        String errMsg = "The associated facility doesn't exist or is not in active status";

        List<String> qualifiedRoomIds = new ArrayList<>();
        if (!ListUtil.isEmpty(roomIds)) {
            List<Space> spaces = microservice.getRoomsByIds(roomIds);

            Facility facility;
            for (Space space : spaces) {
                facility = facilityService.getFacilityById(space.facilityRef.id);
                if (facility != null && facility.isFacilityActive) {
                    qualifiedRoomIds.add(space.getId());
                } else {
                    FailedItem failedItem = new FailedItem();
                    failedItem.id = space.getId();
                    failedItem.errorMsg = errMsg;
                    failedItems.add(failedItem);
                }
            }
        }
        return qualifiedRoomIds;
    }

    private List<String> checkRequirementsForRoomInActive(List<String> roomIds, List<FailedItem> failedItems, Boolean isDeleted) {
        String errMsg;
        if (isDeleted) {
            errMsg = "This record is linked to an active Requirement and cannot be deleted.";
        } else {
            errMsg = "This record is linked to an active Requirement and cannot be set inactive.";
        }

        List<String> qualifiedRoomIds = new ArrayList<>();
        if (!ListUtil.isEmpty(roomIds)) {
            List<AssociatedRecordsWithRoom<Requirement>> associatedRecordsList = requirementService.getRequirementsByRoomIds(roomIds);
            for (AssociatedRecordsWithRoom<?> item : associatedRecordsList) {
                if (ListUtil.isEmpty(item.associatedRecords)) {
                    qualifiedRoomIds.add(item.roomId);
                } else {
                    boolean qualified = true;
                    for (Requirement requiremnt : (List<Requirement>) item.associatedRecords) {
                        if (requiremnt.isRecordActive) {
                            qualified = false;
                            break;
                        }
                    }
                    if (qualified) {
                        qualifiedRoomIds.add(item.roomId);
                    } else {
                        FailedItem failedItem = new FailedItem();
                        failedItem.id = item.roomId;
                        failedItem.errorMsg = errMsg;
                        failedItems.add(failedItem);
                    }
                }
            }
        }

        return qualifiedRoomIds;
    }

    private List<String> checkProjectsForRoomInActive(List<String> roomIds, List<FailedItem> failedItems, Boolean isDeleted) {
        String errMsg;
        if (isDeleted) {
            errMsg = "This record is linked to an active Project and cannot be deleted.";
        } else {
            errMsg = "This record is linked to an active Project and cannot be set inactive.";
        }

        List<String> qualifiedRoomIds = new ArrayList<>();
        if (!ListUtil.isEmpty(roomIds)) {
            List<AssociatedRecordsWithRoom<RealPropertyProject>> associatedRecordsList = projectService.getProjectsByRoomIds(roomIds);
            for (AssociatedRecordsWithRoom<?> item : associatedRecordsList) {
                if (ListUtil.isEmpty(item.associatedRecords)) {
                    qualifiedRoomIds.add(item.roomId);
                } else {
                    boolean qualified = true;
                    for (RealPropertyProject project : (List<RealPropertyProject>) item.associatedRecords) {
                        if (project.isRecordActive) {
                            qualified = false;
                            break;
                        }
                    }
                    if (qualified) {
                        qualifiedRoomIds.add(item.roomId);
                    } else {
                        FailedItem failedItem = new FailedItem();
                        failedItem.id = item.roomId;
                        failedItem.errorMsg = errMsg;
                        failedItems.add(failedItem);
                    }
                }
            }
        }

        return qualifiedRoomIds;
    }

    private List<String> checkWorkOrdersForRoomInActive(List<String> roomIds, List<FailedItem> failedItems, Boolean isDeleted) {
        String errMsg;
        if (isDeleted) {
            errMsg = "This record is linked to an active Work Order and cannot be deleted.";
        } else {
            errMsg = "This record is linked to an active Work Order and cannot be set inactive.";
        }

        List<String> qualifiedRoomIds = new ArrayList<>();
        if (!ListUtil.isEmpty(roomIds)) {
            for (String roomId : roomIds) {
                List<WorkOrder> associatedRecords = workOrderService.getWorkOrdersByRoomId(roomId);
                if (ListUtil.isEmpty(associatedRecords)) {
                    qualifiedRoomIds.add(roomId);
                } else {
                    //TODO: need to check work status later
	               /* boolean qualified = true;
	                for (WorkOrder workOrder : (List<WorkOrder>) associatedRecords) {
	                    if (workOrder.is) {
	                        qualified = false;
	                        break;
	                    }
	                }
	    			if ( qualified ) {
	                    qualifiedRoomIds.add(roomId);
	    			} else*/
                    {
                        FailedItem failedItem = new FailedItem();
                        failedItem.id = roomId;
                        failedItem.errorMsg = errMsg;
                        failedItems.add(failedItem);
                    }
                }
            }
        }

        return qualifiedRoomIds;
    }

    private List<String> checkAssetsForRoomInActive(List<String> roomIds, List<FailedItem> failedItems, Boolean isDeleted) {
        String errMsg;
        if (isDeleted) {
            errMsg = "This record is linked to an active RP Equipment and cannot be deleted.";
        } else {
            errMsg = "This record is linked to an active RP Equipment and cannot be set inactive.";
        }

        List<String> qualifiedRoomIds = new ArrayList<>();

        if (!ListUtil.isEmpty(roomIds)) {
            //TODO: after asset API removes the parameter "facilityId", don't need to retrieve room details
            List<Space> roomList = microservice.getRoomsByIds(roomIds);
            //  for (String roomId : roomIds) {
            for (Space space : roomList) {
                String roomId = space.getId();
                String facilityId = (space.facilityRef == null) ? null : space.facilityRef.id;
                List<AssetSummary> associatedRecords = assetService.getRpeAssetsForSpace(facilityId, roomId);
                if (ListUtil.isEmpty(associatedRecords)) {
                    qualifiedRoomIds.add(roomId);
                } else {
                    boolean qualified = true;
                    for (AssetSummary asset : associatedRecords) {
                        if (asset.isActive) {
                            qualified = false;
                            break;
                        }
                    }
                    if (qualified) {
                        qualifiedRoomIds.add(roomId);
                    } else {
                        FailedItem failedItem = new FailedItem();
                        failedItem.id = roomId;
                        failedItem.errorMsg = errMsg;
                        failedItems.add(failedItem);
                    }
                }
            }
        }

        return qualifiedRoomIds;
    }

    private List<String> checkDrawingsForRoomInActive(List<String> roomIds, List<FailedItem> failedItems, Boolean isDeleted) {
        String errMsg;

        if (isDeleted) {
            errMsg = "This record is linked to a Drawing and cannot be deleted.";
        } else {
            errMsg = "This record is linked to a Drawing and cannot be set inactive.";
        }

        List<String> qualifiedRoomIds = new ArrayList<>();
        if (!ListUtil.isEmpty(roomIds)) {
            for (String roomId : roomIds) {
                boolean qualified = true;

                Space space = spaceManagementService.getRoomById(roomId);

                if (space != null && space.floorRef != null && !StringUtil.isBlankOrNull(space.floorRef.id)) {
                    List<Space> drawingSpaces = drawingService.getRoomsFromDrawing(space.floorRef.id);

                    for (Space drawingSpace : drawingSpaces) {
                        if (drawingSpace.identifier.equals(space.identifier)) {
                            qualified = false;
                            break;
                        }
                    }

                    if (qualified) {
                        qualifiedRoomIds.add(roomId);
                    } else {
                        FailedItem failedItem = new FailedItem();
                        failedItem.id = roomId;
                        failedItem.errorMsg = errMsg;
                        failedItems.add(failedItem);
                    }
                } else {
                    // Floor is optional for a space/room and can be null.  The room should still be considered qualified.
                    qualifiedRoomIds.add(roomId);
                }
            }
        }

        return qualifiedRoomIds;
    }

    public BulkUpdateResult bulkUpdateMultiRoomDataToRooms(RoomBulkMultiUpdate roomBulkMultiUpdate) {
        if (BulkDataFieldUpdate.DATA_NAME_SHARED_OCCUPANCY.equalsIgnoreCase(roomBulkMultiUpdate.dataFieldUpdateList.get(0).dataName)) {
            if (!validateSharedSpace(roomBulkMultiUpdate.dataFieldUpdateList.get(0).dataValues)) {
                throw new ApplicationException("The value of \"% Shared Space\" is invalid: value must be between 1 and 99");
            }
        }

        for (BulkDataFieldUpdate dataField : roomBulkMultiUpdate.dataFieldUpdateList) {
            if (dataField.dataName.equalsIgnoreCase(BulkDataFieldUpdate.DATA_NAME_CATEGORY_CODE)) {

                for (BulkFieldUpdateValue dataValue : dataField.dataValues) {
                    BulkFieldUpdateValue newDataValue = new BulkFieldUpdateValue();

                    CategoryCode categoryCode = realPropertyLookupService.getCategoryCodeById(dataValue.updateValues.get("dataValue").toString());

                    newDataValue.updateAction = dataValue.updateAction;
                    Map<String, Object> updateValue = new HashMap<>();
                    updateValue.put("dataValue", categoryCode.getRef());
                    newDataValue.updateValues = dataValue.updateValues = updateValue;
                }
            }
        }

        return microservice.bulkUpdateMultiRoomDataToRooms(roomBulkMultiUpdate);
    }

    private boolean validateSharedSpace(List<BulkFieldUpdateValue> dataValue) {
        for (BulkFieldUpdateValue occupancy : dataValue) {
            if (BulkFieldUpdateValue.ACTION_ADD.equalsIgnoreCase(occupancy.updateAction) ||
                    BulkFieldUpdateValue.ACTION_UPDATE.equalsIgnoreCase(occupancy.updateAction)) {
                Double sharedSpace = 0.0;
                try {
                    sharedSpace = stringUtil.convertStringToDouble(occupancy.updateValues.get("sharedSpace").toString());
                } catch (NumberFormatException e) {
                    logger.error("Error occurred in validatesharedspace :"+e.getMessage());
                }
                if (sharedSpace < 1.0 || sharedSpace > 99.0)
                    return false;
            }
        }
        return true;
    }

    public List<GraphicalSearchRecord> getGraphicalSearchRecordsByRoomIds(List<String> roomIds) {
        Map<String, GraphicalSearchRecord> graphicalSearchRecords = new HashMap<>();
        List<Space> spaces = microservice.getRoomsByIds(roomIds);

        for (Space space : spaces) {
            if (space != null && space.floorRef != null && !StringUtil.isBlankOrNull(space.floorRef.id)) {
                GraphicalSearchRecord graphicalSearchRecord = graphicalSearchRecords.get(space.floorRef.id);

                if (graphicalSearchRecord == null) {
                    Floor floor = getFloorById(space.floorRef.id);
                    graphicalSearchRecord = new GraphicalSearchRecord();
                    graphicalSearchRecord.siteRef = space.siteRef;
                    graphicalSearchRecord.facilityRef = space.facilityRef;
                    graphicalSearchRecord.floorRef = space.floorRef;
                    graphicalSearchRecord.roomList = new ArrayList<>();
                    graphicalSearchRecord.numberOfRooms = 0;
                    graphicalSearchRecord.floorPlanName = floor.drawingName;
                }

                if (!graphicalSearchRecord.roomList.contains(space)) {
                    graphicalSearchRecord.roomList.add(space);
                    graphicalSearchRecord.numberOfRooms++;
                }

                graphicalSearchRecords.put(graphicalSearchRecord.floorRef.id, graphicalSearchRecord);
            }
        }

        return new ArrayList<>(graphicalSearchRecords.values());
    }

    public List<FloorPlanLegendEntry> getDrawingLegend(String floorId, String legendType) {
        return microservice.getDrawingLegend(floorId, legendType);
    }

    private OccupantSummary convertOccupantToOccupantSummary(Occupant occupant) {
        OccupantSummary summary = new OccupantSummary();
        summary.occupantId = occupant.getId();
        summary.customerId = occupant.customerId;
        summary.customerName = occupant.customerName;
        summary.departmentId = occupant.departmentId;
        summary.departmentName = occupant.departmentName;
        summary.meprsCode = occupant.meprsCode;
        summary.officeSymbol = occupant.officeSymbol;
        summary.spaceFillColor = occupant.spaceFillColor;
        summary.spaceFillPattern = occupant.spaceFillPattern;
        summary.isActive = occupant.isActive;
        summary.siteRef = occupant.siteRef;
        if (occupant.managedByNodeRef != null) {
            summary.managedByNodeRef = occupant.managedByNodeRef;
        }

        return summary;
    }

    public List<AssetSummary> getRpieAssetsForSpace(String facilityId, String roomId) {
        return assetService.getRpeAssetsForSpace(facilityId, roomId);
    }

    public List<RoomSummary> getRoomSummariesByIds(List<String> roomIds) {
        List<Space> rooms;
        List<RoomSummary> roomSummaries = new ArrayList<>();
        rooms = microservice.getRoomsByIds(roomIds);

        if (rooms.size() > 0) {
            for (Space room : rooms) {
                roomSummaries.add(convertRoomToRoomSummary(room));
            }
        }
        return roomSummaries;
    }

    public List<Zone> getZonesByIds(List<String> zoneIds) {
        return microservice.getZonesByIds(zoneIds);
    }

    public List<RoomSummary> getRoomSummariesByFacilityIds(List<String> facilityIds) {
        return getSpacesByFacilityIds(facilityIds, ACTIVE, Boolean.FALSE);
    }

    public List<Zone> getZonesByFacilityIds(List<String> facilityIds) {
        return this.microservice.getZonesByFacilityIds(facilityIds);
    }

    public List<TagRef> getSpaceTags() {
        return tagService.getTagRefsForBusinessArea(EBusinessArea.SPACE_ROOMS);
    }

    public List<WorkOrder> getWorkOrdersByRoomId(String roomId) {
        return this.workOrderService.getWorkOrdersByRoomId(roomId);
    }

    public List<Occupant> getActiveOccupantsByManagedByNode(String managedByNodeId) {
        return microservice.getActiveOccupantsByManagedByNode(managedByNodeId);
    }

    public List<String> getDocumentTypes() {
        return facilityService.getDocumentTypes();
    }

    public List<FloorCOBieExportData> getFloorCOBieExportDataByFacilityId(String facilityId) {
        return microservice.getFloorCOBieExportDataByFacilityId(facilityId);
    }

    public List<SpaceCOBieExportData> getSpaceCOBieExportDataByFacilityId(String facilityId) {
        return microservice.getSpaceCOBieExportDataByFacilityId(facilityId);
    }

    public List<ZoneCOBieExportData> getZoneCOBieExportDataByFacilityId(String facilityId) {
        return microservice.getZoneCOBieExportDataByFacilityId(facilityId);
    }

    public Floor getCOBieFloor(COBieFloorImportSummary cobieFloorImportSummary) {
        return microservice.getCOBieFloor(cobieFloorImportSummary);
    }

    public List<Floor> getCOBieFloors(List<COBieFloorImportSummary> cobieFloorImportSummaries) {
        return microservice.getCOBieFloors(cobieFloorImportSummaries);
    }

    public Space getCOBieSpace(COBieSpaceImportSummary cobieSpaceImportSummary) {
        return microservice.getCOBieSpace(cobieSpaceImportSummary);
    }

    public List<Space> getCOBieSpaces(List<COBieSpaceImportSummary> cobieSpaceImportSummaries) {
        return microservice.getCOBieSpaces(cobieSpaceImportSummaries);
    }

    public Zone createCOBieZone(COBieZoneImportSummary cobieZoneImportSummary) {
        return microservice.createCOBieZone(cobieZoneImportSummary);
    }

    public BulkUpdateResult createCOBieZones(List<COBieZoneImportSummary> cobieZoneImportSummaries) {
        return microservice.createCOBieZones(cobieZoneImportSummaries);
    }

    public List<String> getActiveDepartmentsBySite(String managedByNodeRefId) {
        List<Occupant> occupants = microservice.getActiveOccupantsByManagedByNode(managedByNodeRefId);
        List<String> departmentList = new ArrayList<>();

        for (Occupant occupant : occupants) {
            if (occupant.departmentId != null && occupant.siteRef != null && occupant.managedByNodeRef.id.equals(managedByNodeRefId)) {
                if (departmentList.stream().noneMatch(object -> object.equals(occupant.departmentName))) {
                    departmentList.add(occupant.departmentId + " - "+ occupant.departmentName);
                }
            }
        }
        return departmentList;
    }

    public List<String> getActiveServiceBySite(String managedByNodeRefId) {
        List<Occupant> occupants = microservice.getActiveOccupantsByManagedByNode(managedByNodeRefId);
        List<String> serviceList = new ArrayList<>();

        for (Occupant occupant : occupants) {
            if (occupant.customerId != null && occupant.siteRef != null && occupant.managedByNodeRef.id.equals(managedByNodeRefId)) {
                if (serviceList.stream().noneMatch(object -> object.equals(occupant.customerName))) {
                    serviceList.add(occupant.customerId + " - "+ occupant.customerName);
                }
            }
        }
        return serviceList;
    }

    public COBieFileImport getCOBieFileImportById(String cobieFileImportId) {
        return microservice.getCOBieFileImportById(cobieFileImportId);
    }

    public List<SpaceRef> getSpaceRefListByRoomNumberList(String facilityId, List<String> roomNumberList) {
        return microservice.getSpaceRefListByRoomNumberList(facilityId, roomNumberList);
    }

    public AttributeType getRoomAttributeType(String attributeType, String attributeName) {
        return microservice.getRoomAttributeType(attributeType, attributeName);
    }

    public HazardType getRoomHazardType(String attributeValue) {
        return microservice.getRoomHazardType(attributeValue);
    }

    public SpaceType getSpaceTypeBySubtype(String code) {
        return microservice.getSpaceTypeBySubtype(code);
    }

    public BulkUpdateResult saveRooms(List<Space> spaces) {
        BulkUpdateResult results = new BulkUpdateResult();

        for (Space space : spaces) {
            try {
                updateRoom(space);
                results.succeedItems.add(space.identifier);
            } catch (ApplicationException e) {
                logger.error(e);
                FailedItem failedItem = new FailedItem();
                failedItem.id = space.identifier;
                failedItem.errorMsg = e.getMessage();
                results.failedItems.add(failedItem);
            }
        }

        return results;
    }

    public void syncFacilityManagedByNodeRef(String facilityId, OrganizationRef managedBy) {
    	microservice.syncFacilityManagedByNodeRef(facilityId, managedBy);
    }

    public Floor getFloorByFloorNumber(String facilityId, String floorNumber) {
        return microservice.getFloorByFloorNumber(facilityId, floorNumber);
    }

    public Zone getCOBieZone(COBieZoneImportSummary summary) {
        return microservice.getCOBieZone(summary);
    }

    public Zone getFacilityZoneByTypeId(String facilityId, String zoneTypeId) {
        return microservice.getFacilityZoneByTypeId(facilityId, zoneTypeId);
    }

    public Zone updateCOBieZone(COBieZoneImportSummary summary) {
        return microservice.updateCOBieZone(summary);
    }
}

