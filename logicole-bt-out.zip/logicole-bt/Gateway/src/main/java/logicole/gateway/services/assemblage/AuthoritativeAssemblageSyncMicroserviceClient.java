package logicole.gateway.services.assemblage;

import logicole.apis.assemblage.IAuthoritativeAssemblageSyncMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AuthoritativeAssemblageSyncMicroserviceClient extends MicroserviceClient<IAuthoritativeAssemblageSyncMicroserviceApi> {
    public AuthoritativeAssemblageSyncMicroserviceClient(){
        super(IAuthoritativeAssemblageSyncMicroserviceApi.class, "logicole-assemblage");
    }

    @Produces
    public IAuthoritativeAssemblageSyncMicroserviceApi getIAuthoritativeAssemblageSyncMicroserviceApi() {
        return createClient();
    }
}
