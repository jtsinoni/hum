package logicole.gateway.services.catalog;

import logicole.apis.abi.IAbiStagingMicroserviceApi;
import logicole.apis.catalog.ICatalogMicroserviceApi;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.abi.item.ItemRef;
import logicole.common.datamodels.abi.item.ItemSummary;
import logicole.common.datamodels.abi.item.SuggestedItemDTO;
import logicole.common.datamodels.assemblage.AssemblageItem;
import logicole.common.datamodels.catalog.Catalog;
import logicole.common.datamodels.catalog.CatalogAddRequest;
import logicole.common.datamodels.catalog.CatalogAddResult;
import logicole.common.datamodels.catalog.CatalogDTO;
import logicole.common.datamodels.catalog.CatalogItem;
import logicole.common.datamodels.catalog.CatalogSourcing;
import logicole.common.datamodels.catalog.CatalogUpdateRequest;
import logicole.common.datamodels.catalog.CatalogUpdateResult;
import logicole.common.datamodels.catalog.CustomAttribute;
import logicole.common.datamodels.finance.ECommodityCodeUsageType;
import logicole.common.datamodels.finance.referencedata.CommodityCode;
import logicole.common.datamodels.general.search.*;
import logicole.common.datamodels.order.CatalogPurchase;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.buyer.BuyerRef;
import logicole.common.datamodels.order.order.OrderItem;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountDTO;
import logicole.common.datamodels.sale.seller.Seller;
import logicole.common.datamodels.sale.seller.SellerRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.ObjectMapper;
import logicole.common.general.util.string.StringUtil;
import logicole.common.servers.business.SearchHelper;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.finance.FinanceReferenceDataService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.order.OrderService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.sale.SellerService;
import org.bson.types.ObjectId;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@ApplicationScoped
public class CatalogService extends BaseGatewayService<ICatalogMicroserviceApi> {
    public static final String BUYER = "buyer";
    public static final String CUSTOMER_NOT_FOUND_EXCEPTION = "No Customer is associated to this profile";

    @Inject
    private BuyerService buyerService;

    @Inject
    private SellerService sellerService;

    @Inject
    private ItemService itemService;

    @Inject
    private ObjectMapper mapper;

    @Inject
    private OrderService orderService;

    @Inject
    private IAbiStagingMicroserviceApi abiStagingMicrosserviceApi;

    @Inject
    private OrganizationService organizationService;

    @Inject
    private FinanceReferenceDataService financeReferenceDataService;

    @Inject
    private SearchHelper searchHelper;

    public CatalogService() {
        super("Catalog");
    }

    public List<Catalog> doesCatalogRecordExist(Catalog catalog) {
        return microservice.doesCatalogRecordExist(catalog);
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public Catalog getById(@QueryParam("id") String id) {
        return microservice.getById(id);
    }

    public CatalogAddResult addCatalogRecord(CatalogAddRequest catalogAddRequest) {
        CatalogAddResult result = new CatalogAddResult();
        result.addedSuccessfully = true;

        Catalog catalog = catalogAddRequest.newCatalogRecord;
        Item item = itemService.getByEnterpriseProductIdentifier(catalogAddRequest.newCatalogRecordItem.enterpriseProductIdentifier);

        if (Objects.isNull(item)) {
            String currentNodeId = this.currentUserBT.getCurrentNodeId();
            Organization siteNode = organizationService.getAncestorOrgOfOrgType(currentNodeId, OrganizationConstants.SITE_ORG_TYPE_ID);

            item = catalogAddRequest.newCatalogRecordItem;
            item.catalogSource = "CATALOG";
            item.managedByNodeRef = siteNode.getRef();
            applyItemRecordEdits(catalog, item);
            item = itemService.saveItem(item);
        }

        catalog.itemRef = item.getRef();
        CatalogItem catalogItem = mapper.getObject(CatalogItem.class, catalog);
        catalogItem.item = item;
        applyCatalogRecordEdits(catalogItem);
        catalog = saveCatalogRecord(catalog);


        result.catalogRecordItem = mapper.getObject(CatalogItem.class, catalog);
        result.catalogRecordItem.item = item;
        return result;
    }

    public Catalog saveCatalogRecord(Catalog catalog) {
        if (Objects.isNull(catalog.buyerRef) || (Objects.nonNull(catalog.buyerRef) && StringUtil.isEmptyOrNull(catalog.buyerRef.id))) {
            Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
            if (Objects.nonNull(buyer)) {
                catalog.buyerRef = buyer.getRef();
            }
        }
        catalog = postProcessCatalogRecord(catalog);
        return microservice.saveCatalogRecord(catalog);
    }

    public Catalog addItemToCatalog(String catalogId, Item newItem) {
        Catalog tempCatalog = this.getById(catalogId);
        Item tempItem = itemService.saveItem(newItem);

        tempCatalog.itemRef = tempItem.getRef();
        return this.saveCatalogRecord(tempCatalog);
//        return microservice.updateCatalogRecord(tempCatalog);
    }

    public List<Catalog> saveEntireCatalog(List<Catalog> catalogRecordList) {
        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);

        if (Objects.nonNull(buyer)) {
            BuyerRef buyerRef = buyer.getRef();
        }
        for (int i = 0; i < catalogRecordList.size(); i++) {
            Catalog catalog1 = catalogRecordList.get(i);
            catalog1.buyerRef = buyer.getRef();
            catalog1 = postProcessCatalogRecord(catalog1);
            catalogRecordList.set(i, catalog1);
        }

        return microservice.saveCatalogRecords(catalogRecordList);
    }

    public SearchResult<CatalogDTO> getScopedCatalogSearchResults(String scope, SearchInput searchInput) {
        SearchResult<CatalogDTO> searchResult = new SearchResult<>();

        if (scope.equals("Catalog")) {
            searchResult = this.getCatalogSearchResultsByScope("Customer", searchInput);
        }
        if (scope.equals("Site")) {
            searchResult = buildSiteScopedSearchResults(searchInput);
        }

        if (scope.equals("Items")) {
            searchResult = buildItemScopedSearchResults(searchInput);
        }
        searchResult = removeDuplicateCatalogItems(searchResult);
        sortResultsByScope(searchResult);
        limitResults(searchResult);
        return searchResult;
    }

    private SearchResult<CatalogDTO> buildItemScopedSearchResults(SearchInput searchInput) {
        SearchResult<CatalogDTO> searchResult = new SearchResult<>();
        SearchResult<CatalogDTO> customerSearchResults = this.getCatalogSearchResultsByScope("Customer", searchInput);
        if (customerSearchResults.total >= customerSearchResults.limit) {
            return customerSearchResults;
        }

        SearchResult<CatalogDTO> siteSearchResults = this.getCatalogSearchResultsByScope("Site", searchInput);
        logger.error("CatalogService.getScopedCatalogSearchResults: Site search returns " + siteSearchResults.total + " records.");
        if (siteSearchResults.total > 0) {
            searchResult.total = customerSearchResults.total + siteSearchResults.total;
            searchResult.results.addAll(customerSearchResults.results);
            searchResult.results.addAll(siteSearchResults.results);
            searchResult.limit = customerSearchResults.limit;

            searchResult.aggregations = mergeAggregations(searchResult.aggregations, customerSearchResults.aggregations);
            searchResult.aggregations = mergeAggregations(searchResult.aggregations, siteSearchResults.aggregations);

            if (searchResult.total >= searchResult.limit) {
                return searchResult;
            }
        } else {
            searchResult = customerSearchResults;
        }

        SearchInput itemSearchInput = buildItemSearchInput(searchInput);
        if (Objects.nonNull(itemSearchInput)) {

            SearchResult<ItemSummary> itemSummarySearchResult = itemService.getItemSearchResults(itemSearchInput);
            if (itemSummarySearchResult.total > 0) {
                List<CatalogDTO> catalogDTOList = new ArrayList<CatalogDTO>();
                Long catalogSearchResultsTotal = 0L;

                if (searchResult.total > 0) {
                    catalogDTOList = searchResult.results;
                    catalogSearchResultsTotal = searchResult.total;
                }

                List<CatalogDTO> catalogDTOS = new ArrayList<>();

                if (Objects.nonNull(itemSummarySearchResult) && Objects.nonNull(itemSummarySearchResult.results) && !itemSummarySearchResult.results.isEmpty()) {
                    for (ItemSummary itemSummary : itemSummarySearchResult.results) {
                        if (catalogDTOList.stream().filter(catalogDTO -> catalogDTO.itemRef.enterpriseProductIdentifier.equals(itemSummary.enterpriseProductIdentifier)).count() == 0) {
                            CatalogDTO catalogDTO = new CatalogDTO();
                            catalogDTO.itemRef = mapper.getObject(ItemRef.class, itemSummary);
                            catalogDTO.itemSummary = itemSummary;
                            catalogDTO.source = "Enterprise";
                            catalogDTO.sourceValue = 2;
                            catalogDTOS.add(catalogDTO);
                            catalogSearchResultsTotal++;
                        }
                    }
                    searchResult.results.addAll(catalogDTOS);

                    searchResult.aggregations = mergeAggregations(searchResult.aggregations, itemSummarySearchResult.aggregations);
                    searchResult.total = catalogSearchResultsTotal;
                }
            }
        }
        return searchResult;
    }

    private SearchResult<CatalogDTO> buildSiteScopedSearchResults(SearchInput searchInput) {
        SearchResult<CatalogDTO> searchResult = new SearchResult<>();
        SearchResult<CatalogDTO> customerSearchResults = this.getCatalogSearchResultsByScope("Customer", searchInput);
        if (customerSearchResults.total >= customerSearchResults.limit) {
            sortResultsByScope(customerSearchResults);
            limitResults(customerSearchResults);
            return customerSearchResults;
        }
        SearchResult<CatalogDTO> siteSearchResults = this.getCatalogSearchResultsByScope("Site", searchInput);

        if (siteSearchResults.total == 0) {
            sortResultsByScope(customerSearchResults);
            limitResults(customerSearchResults);
            return customerSearchResults;
        }
        searchResult.total = customerSearchResults.total + siteSearchResults.total;
        searchResult.results.addAll(customerSearchResults.results);
        searchResult.results.addAll(siteSearchResults.results);
        searchResult.limit = customerSearchResults.limit;

        searchResult.aggregations = mergeAggregations(searchResult.aggregations, customerSearchResults.aggregations);
        searchResult.aggregations = mergeAggregations(searchResult.aggregations, siteSearchResults.aggregations);
        return searchResult;
    }

    private SearchInput buildItemSearchInput(SearchInput searchInput) {
        SearchInput itemSearchInput = new SearchInput();
        itemSearchInput.searchText = searchInput.searchText;
        itemSearchInput.searchCriteria = new ArrayList<>();

        for (SearchCriterion sc : searchInput.searchCriteria) {
            if (sc.propName.startsWith("itemRef.")) {
                SearchCriterion isc = new SearchCriterion();
                isc.propName = sc.propName.substring(8);
                isc.propValues = sc.propValues;
                isc.method = sc.method;
                itemSearchInput.searchCriteria.add(isc);
            } else if ((!sc.propName.startsWith("buyer")) && (!sc.propName.startsWith("site"))) {
                // if search criteria starts with buyer or site, that is to limit catalog records.
                // Ignore those fields for item search, since they do not exist.
                // any other search criteria should be part of a facet search.
                // If facet is specified that is not on itemRef, return null
                // to indicate that item search should not be performed.
                itemSearchInput = null;
                break;
            }
        }
        return itemSearchInput;

    }

    private void limitResults(SearchResult<CatalogDTO> searchResults) {
        if (searchResults.results.size() > searchResults.limit) {
            searchResults.results = searchResults.results.subList(0, searchResults.limit);
        }
    }

    private void sortResultsByScope(SearchResult<CatalogDTO> searchResult) {
        searchResult.results.sort((left, right) -> {
            return Integer.compare(left.sourceValue, right.sourceValue);
        });
    }

    private List<SearchCategory> mergeAggregations(List<SearchCategory> aggregations, List<SearchCategory> aggregations1) {
        HashMap<String, SearchCategory> categoryMap = new HashMap<>();
        for (SearchCategory agg : aggregations) {
            categoryMap.put(agg.name, agg);
        }
        for (SearchCategory agg : aggregations1) {
            String key = agg.name;
            if (categoryMap.containsKey(key)) {
                SearchCategory found = categoryMap.get(key);
                found.values = mergeAggregationValues(found.values, agg.values);
            } else {
                categoryMap.put(key, agg);
            }
        }
        return new ArrayList<>(categoryMap.values());
    }

    private List<SearchCategoryItem> mergeAggregationValues(List<SearchCategoryItem> values, List<SearchCategoryItem> values1) {
        HashMap<String, SearchCategoryItem> itemMap = new HashMap<>();
        for (SearchCategoryItem value : values) {
            String key = (Objects.nonNull(value.value)) ? value.value.toString() : "";
            itemMap.put(key, value);
        }
        for (SearchCategoryItem value : values1) {
            String key = (Objects.nonNull(value.value)) ? value.value.toString() : "";
            if (itemMap.containsKey(key)) {
                SearchCategoryItem found = itemMap.get(key);
                found.count = found.count + value.count;
            } else {
                itemMap.put(key, value);
            }
        }
        return new ArrayList<>(itemMap.values());
    }

    public SearchResult<CatalogDTO> getCatalogSearchResultsByScope(String scope, SearchInput searchInput) {

        if (scope.equals("Customer")) {

            Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
            if (Objects.isNull(buyer)) {
                throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
            }

            SearchCriterion buyerSearchCriterion = new SearchCriterion();
            buyerSearchCriterion.propName = BUYER;
            buyerSearchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
            ArrayList<String> buyerIds = new ArrayList<>();
            buyerIds.add(buyer.getId());
            buyerSearchCriterion.propValues = buyerIds.toArray();
            searchInput.searchCriteria.add(buyerSearchCriterion);
        }

        if (scope.equals("Site")) {

            Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
            if (Objects.isNull(buyer)) {
                throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
            }

            SearchCriterion siteSearchCriterion = new SearchCriterion();
            siteSearchCriterion.propName = "site";
            siteSearchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
            ArrayList<String> siteIds = new ArrayList<>();
            siteIds.add(buyer.managedByNodeRef.getId());
            siteSearchCriterion.propValues = siteIds.toArray();
            searchInput.searchCriteria.add(siteSearchCriterion);

            SearchCriterion buyerSearchCriterion = new SearchCriterion();
            buyerSearchCriterion.propName = BUYER;
            buyerSearchCriterion.method = SearchCriterion.SEARCH_METHOD_NOT_IN;
            ArrayList<String> buyerIds = new ArrayList<>();
            buyerIds.add(buyer.getId());
            buyerSearchCriterion.propValues = buyerIds.toArray();
            searchInput.searchCriteria.add(buyerSearchCriterion);
        }


        return this.getCatalogSearchResults(searchInput, scope);


    }


    public SearchResult<CatalogDTO> getCatalogSearchResults(SearchInput searchInput, String scope) {
        ESearchEngine searchEngine = microservice.getCatalogSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            if (!doesSearchCriterionContain(searchInput.searchCriteria, BUYER)) {
                // if being called from the catalog search, the BUYER search criteria will already be added, so don't add it again
                Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
                if (Objects.isNull(buyer)) {
                    throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
                }

                SearchCriterion buyerSearchCriterion = new SearchCriterion();
                buyerSearchCriterion.propName = BUYER;
                buyerSearchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
                ArrayList<String> buyerIds = new ArrayList<>();
                buyerIds.add(buyer.getId());
                buyerSearchCriterion.propValues = buyerIds.toArray();
                searchInput.searchCriteria.add(buyerSearchCriterion);
            }

            SearchResult<CatalogDTO> searchResult = microservice.getScopedCatalogSearchResults(scope, searchInput);
            return populateSearchResultsItemSummary(searchResult, scope);
        }
    }


    public SearchResult<CatalogDTO> getCatalogSearchResults(SearchInput searchInput) {
        return getCatalogSearchResults(searchInput, null);
    }

    public SearchResult<CatalogDTO> getNonCatalogPurchaseSearchResults(SearchInput searchInput) {
        return microservice.getCatalogSearchResults(searchInput);
    }

    public List<String> getOrderCatalogIds(List<String> itemIds) {
        List<OrderItem> entireOrderList = orderService.getOrdersByItemIds(itemIds);
        List<String> nonCatalogOrderIds = new ArrayList<>();

        for (OrderItem orderItem : entireOrderList) {
            String id = orderItem.catalogPurchase.catalog.getId();
            if (itemIds.contains(id)) {
                nonCatalogOrderIds.add(id);
            }
        }
        return nonCatalogOrderIds;
    }

    public List<Catalog> getMedicalEquipmentRepairParts(String managedByNodeId) {
        return microservice.getMedicalEquipmentRepairParts(managedByNodeId);
    }

    public List<Catalog> getPreferredSourcesByEnterpriseProductIdentifier(String buyerId, String enterpriseProductIdentifier) {
        return microservice.getPreferredSourcesByEnterpriseProductIdentifier(buyerId, enterpriseProductIdentifier);
    }

    public List<Catalog> getRecordsByCustomerItemIdentifier(String buyerId, String itemIdentifier) {
        return microservice.getRecordsByCustomerItemIdentifier(buyerId, itemIdentifier);
    }

    public List<Catalog> getRecordsByCustomerItemIdentifierOrDescription(String buyerId, String searchText) {
        return microservice.getRecordsByCustomerItemIdentifierOrDescription(buyerId, searchText);
    }

    public List<Catalog> getAncestryRecordsByCustomerItemIdentifierOrDescription(String buyerId, String searchText) {
        return microservice.getAncestryRecordsByCustomerItemIdentifierOrDescription(buyerId, searchText);
    }

    public List<Catalog> getDefaultRecordsByEnterpriseProductIdentifier(String enterpriseProductIdentifier) {
        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if (Objects.isNull(buyer)) {
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }
        return microservice.getDefaultRecordsByEnterpriseProductIdentifier(buyer.getId(), enterpriseProductIdentifier);
    }

    public Catalog updateCatalogRecord(Catalog catalog) {
        return microservice.updateCatalogRecord(catalog);
    }


    public Catalog postProcessCatalogRecord(Catalog recordToUpdate) {
        return postProcessCatalogRecord(recordToUpdate, null);
    }

    public Catalog postProcessCatalogRecord(Catalog recordToUpdate, List<String> fieldNames) {
        recordToUpdate = (Catalog) applyFormatting(recordToUpdate, fieldNames);
        return recordToUpdate;
    }

    public String applyCasingAndSubstitutionRules(String text) {
        return abiStagingMicrosserviceApi.applyCasingAndSubstitutionRules(text);
    }

    private boolean doesSearchCriterionContain(List<SearchCriterion> searchCriterion, String propName) {
        boolean contains = false;
        for (SearchCriterion searchCriteria : searchCriterion) {
            if (searchCriteria.propName.equalsIgnoreCase(propName)) {
                contains = true;
                break;
            }
        }
        return contains;
    }

    private SearchResult<CatalogDTO> populateSearchResultsItemSummary(SearchResult<CatalogDTO> searchResult, String scope) {
        if (StringUtil.isBlankOrNull(scope)){
            scope = "Customer";
        }
        if (Objects.nonNull(searchResult) && Objects.nonNull(searchResult.results) && !searchResult.results.isEmpty()) {
            for (CatalogDTO catalog : searchResult.results) {
                if (Objects.nonNull(catalog.itemRef)) {
                    catalog.itemSummary = mapper.getObject(ItemSummary.class, catalog.itemRef);
                    catalog.source = scope;
                    if (scope.equals("Customer")){
                        catalog.sourceValue = 0;
                    }
                    else if (scope.equals("Site")){
                        catalog.sourceValue = 1;
                    }
                    else if (scope.equals("Item")){
                        catalog.sourceValue = 2;
                    }
                }
            }
        }
        return searchResult;
    }

    public CatalogUpdateResult updateLocalItemInformation(CatalogUpdateRequest catalogUpdateRequest) {
        Item item = itemService.getItemById(catalogUpdateRequest.updatedCatalogItemRecord.itemRef.getId());
        catalogUpdateRequest.updatedCatalogItemRecord.item = item;
        applyCatalogRecordEdits(catalogUpdateRequest.updatedCatalogItemRecord);
        CatalogUpdateResult result = microservice.updateLocalItemInformation(catalogUpdateRequest);
        item = itemService.getItemById(catalogUpdateRequest.updatedCatalogItemRecord.itemRef.getId());
        result.databaseCatalogItemRecord.item = item;
        return result;
    }

    public CatalogItem getCatalogWithItemById(String id) {
        Catalog catalog = this.getById(id);
        Item item = itemService.getItemById(catalog.itemRef.getId());
        CatalogItem catalogItem;
        catalogItem = mapper.getObject(CatalogItem.class, catalog);
        catalogItem.item = item;
        return catalogItem;
    }

    protected OrganizationRef getManagedByNodeRef() {
        String currentNodeId = this.currentUserBT.getCurrentNodeId();
        return organizationService.getOrganizationRefById(currentNodeId);
    }

    public SearchResult<CatalogPurchase> getCatalogSearchResultsForAssemblage(List<AssemblageItem> items) {
        ESearchEngine searchEngine = microservice.getCatalogSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            List<String> catalogIds = new ArrayList<>();
            items.forEach(item -> catalogIds.add(item.catalogRef.id));
            SearchResult<CatalogDTO> catalogDTOSearchResults = microservice.getCatalogSearchResultsForAssemblage(catalogIds);
            SearchResult<CatalogPurchase> catalogPurchaseSearchResults = new SearchResult<>();
            catalogPurchaseSearchResults.limit = catalogDTOSearchResults.limit;
            catalogPurchaseSearchResults.total = catalogDTOSearchResults.total;
            catalogPurchaseSearchResults.aggregations = catalogDTOSearchResults.aggregations;

            if (Objects.nonNull(catalogDTOSearchResults.results) && !catalogDTOSearchResults.results.isEmpty()) {
                for (CatalogDTO catalogDTO : catalogDTOSearchResults.results) {
                    CatalogPurchase catalogPurchase = new CatalogPurchase();
                    catalogPurchase.item = itemService.getItemById(catalogDTO.itemRef.getId());
                    catalogPurchase.catalog = mapper.getObject(Catalog.class, catalogDTO);
                    items.stream().filter(item -> item.catalogRef.id.equals(catalogPurchase.catalog._id.toString())).findFirst().ifPresent(i -> catalogPurchase.assemblageItemId = i._id.toString());
                    catalogPurchaseSearchResults.results.add(catalogPurchase);
                }
            }
            return catalogPurchaseSearchResults;
        }
    }

    public List<CommodityCode> getCatalogItemCommodityCodeList() {
        return financeReferenceDataService.getFullCommodityCodesByUsage(ECommodityCodeUsageType.MM);
    }

    protected void applyItemRecordEdits(Catalog catalog, Item item) {
        if (StringUtil.isBlankOrNull(item.shortItemDescription)) {
            item.shortItemDescription = catalog.shortDescription;
        }
        if (StringUtil.isBlankOrNull(item.longItemDescription)) {
            item.longItemDescription = catalog.longDescription;
        }
    }

    protected void applyCatalogRecordEdits(CatalogItem catalogItem) {
        // Future
        // Populate Catalog.shortDescription from Basic attributes when Catalog record built from Item or Medical Master Catalog
        // Populate Catalog.longDescription from Basic attributes when Catalog record built from Item or Medical Master Catalog

        if (StringUtil.isBlankOrNull(catalogItem.catalogItemIdentifier)) {
            catalogItem.catalogItemIdentifier = catalogItem.item.enterpriseProductIdentifier;
        }

        catalogItem.shortDescription = safeApplyCasingAndSubstitutionRules(catalogItem.shortDescription);
        catalogItem.longDescription = safeApplyCasingAndSubstitutionRules(catalogItem.longDescription);

        if (!ListUtil.isEmpty(catalogItem.customAttributes)) {
            for (int i = 0; i < catalogItem.customAttributes.size(); i++) {
                CustomAttribute customAttribute = catalogItem.customAttributes.get(i);
                customAttribute.name = customAttribute.name.trim();
                customAttribute.value = customAttribute.value.trim();
                catalogItem.customAttributes.set(i, customAttribute);
            }
        }
    }

    protected String safeApplyCasingAndSubstitutionRules(String strValue) {
        String retValue = strValue;
        if (!StringUtil.isBlankOrNull(strValue)) {
            retValue = applyCasingAndSubstitutionRules(strValue);
        }
        return retValue;
    }


    public Catalog applyFormatting(Catalog recordToUpdate) {
        return applyFormatting(recordToUpdate, null);
    }

    public Catalog applyFormatting(Catalog recordToUpdate, List<String> fieldNames) {

        if (needToCheckField("longDescription", fieldNames)) {
            recordToUpdate.longDescription = applyCasingAndSubstitutionRules(recordToUpdate.longDescription);
        }
        if (needToCheckField("shortDescription", fieldNames)) {
            recordToUpdate.shortDescription = applyCasingAndSubstitutionRules(recordToUpdate.shortDescription);
        }

        return recordToUpdate;
    }

    private boolean needToCheckField(String fieldName, List<String> fieldNames) {
        return (fieldNames == null) || (fieldNames.contains(fieldName));
    }

    public List<Catalog> getCatalogCommodityResults(String searchText) {
        return microservice.getCatalogCommodityResults(searchText, getUserSiteIdentifier());
    }

    public List<Catalog> getCatalogProductGroupResults(String searchText) {
        return microservice.getCatalogProductGroupResults(searchText, getUserSiteIdentifier());
    }

    public List<Catalog> getCatalogProductSubstituteGroupResults(String searchText) {
        return microservice.getCatalogProductSubstituteGroupResults(searchText, getUserSiteIdentifier());
    }

    public List<Catalog> findCatalogByCriteria(ItemSearchCriteria searchInput) {
        List<Catalog> Catalogs = microservice.findCatalogByCriteria(searchInput);
        return Catalogs;
    }

    private String getUserSiteIdentifier() {
        String currentNodeId = this.currentUserBT.getCurrentNodeId();
        Organization siteNode = organizationService.getAncestorOrgOfOrgType(currentNodeId, OrganizationConstants.SITE_ORG_TYPE_ID);
        return siteNode.nodeIdentifier;
    }

    public List<SuggestedItemDTO> findExistingCatalogItems(String manufacturerName, String manufacturerCatalogNumber, String ndc) {
        String currentNodeId = this.currentUserBT.getCurrentNodeId();
        Organization logicoleOrg = organizationService.getOrganization(OrganizationConstants.ROOT_ORG_ID);
        List<String> managedByNodeIds = new ArrayList<>();
        managedByNodeIds.add(logicoleOrg.getId());
        Organization siteNode = organizationService.getAncestorOrgOfOrgType(currentNodeId, OrganizationConstants.SITE_ORG_TYPE_ID);
        if (!Objects.isNull(siteNode)) {
            managedByNodeIds.add(siteNode.getId());
        }
        ItemSearchCriteria itemSearchCriteria = new ItemSearchCriteria();
        itemSearchCriteria.manufacturerCatalogNumber = manufacturerCatalogNumber;
        itemSearchCriteria.manufacturerName = manufacturerName;
        itemSearchCriteria.ndc = ndc;
        itemSearchCriteria.managedByNodeIds = managedByNodeIds;
        List<SuggestedItemDTO> suggestedItemDTOList = itemService.findExistingItems(manufacturerName, manufacturerCatalogNumber, ndc);
        List<Catalog> catalogRecords = findCatalogByCriteria(itemSearchCriteria);
        resolveCatalogItems(suggestedItemDTOList, catalogRecords);
        return suggestedItemDTOList;
    }

    private void resolveCatalogItems(List<SuggestedItemDTO> suggestedItemList, List<Catalog> catalogRecords) {
        // Loop through catalog with suggestedItemDTO.EPI = catalog.itemRef.EPI- add catalogItemIdentifier, source = LOCAL CATALOG
        // if you don't find it , skip the record.
        for (Catalog catalog : catalogRecords) {

            String catalogEPI = catalog.itemRef.enterpriseProductIdentifier;
            SuggestedItemDTO suggestedItemDTO = findSuggestedItemByEPI(suggestedItemList, catalogEPI);

            if (suggestedItemDTO != null) {
                String currentNodeId = this.currentUserBT.getCurrentNodeId();
                if (catalog.buyerRef.currentNodeRef.id.equals(currentNodeId)) {
//                    suggestedItemList.remove(suggestedItemDTO);
                    suggestedItemDTO.catalogId = catalog.getId();
                }


                suggestedItemDTO.catalogItemIdentifier = catalog.catalogItemIdentifier;
                suggestedItemDTO.source = "Local Catalog Item";

            }
        }
    }

    private SuggestedItemDTO findSuggestedItemByEPI(List<SuggestedItemDTO> suggestedItemList,
                                                    String enterpriseProductIdentifier) {
        SuggestedItemDTO foundItem = null;
        for (SuggestedItemDTO suggestedItem : suggestedItemList) {
            if (suggestedItem.enterpriseProductIdentifier.equalsIgnoreCase(enterpriseProductIdentifier)) {
                foundItem = suggestedItem;
                break;
            }
        }
        return foundItem;
    }

    public CatalogSourcing getCatalogSourcing(String catalogItemIdentifier) {
        CatalogSourcing catalogSourcing = new CatalogSourcing();
        catalogSourcing.catalogItemIdentifier = catalogItemIdentifier;
        String currentNodeId = this.currentUserBT.getCurrentNodeId();
        List<Catalog> records =
                microservice.getCatalogRecordsByCatalogItemIdentifier(catalogItemIdentifier, currentNodeId);
        if (Objects.nonNull(records) && (records.size() > 0)) {
            catalogSourcing.catalogSourcingRecords = new ArrayList<>();
            records.forEach((record) -> {
                if (Objects.nonNull(record.sellerRef) && (!StringUtil.isEmptyOrNull(record.sellerRef.id))) {
                    catalogSourcing.catalogSourcingRecords.add(record);
                } else {
                    catalogSourcing.templateRecord = getCatalogWithItemById(record.getId());
                    catalogSourcing.templateRecord.price = new MonetaryValue(0.01);
                }
            });

            if (Objects.isNull(catalogSourcing.templateRecord)) {
                catalogSourcing.templateRecord = getCatalogWithItemById(records.get(0).getId());
                catalogSourcing.templateRecord._id = null;
                catalogSourcing.templateRecord.isPreferredSource = false;
                catalogSourcing.templateRecord.leadTimeDays = null;
                catalogSourcing.templateRecord.maximumOrderQuantity = null;
                catalogSourcing.templateRecord.minimumOrderQuantity = null;
                catalogSourcing.templateRecord.multipleOrderQuantity = null;
                catalogSourcing.templateRecord.price = new MonetaryValue(0.01);
                catalogSourcing.templateRecord.sellerPackageQuantity = null;
                catalogSourcing.templateRecord.sellerPackageUnit = null;
                catalogSourcing.templateRecord.sellerPackageUnitText = null;
                catalogSourcing.templateRecord.sellerProductIdentifier = null;
                catalogSourcing.templateRecord.sellerProductIdentifierType = null;
                catalogSourcing.templateRecord.sellerRef = null;
            }
            if (records.size() == 1 && !StringUtil.isBlankOrNull(catalogSourcing.templateRecord.getId())) {
                catalogSourcing.templateRecord.isPreferredSource = true;
                catalogSourcing.templateRecord.isActive = true;
            }

        }
        return catalogSourcing;
    }

    public List<BuyerSellerAccountDTO> getAuthorizedSellersForCurrentNode() {
        return buyerService.getBuyerSellerAccountList();
    }

    public SellerRef getSellerRefFromBuyerSellerAccount(BuyerSellerAccountDTO buyerSellerAccount) {
        Seller seller = sellerService.getSellerById(buyerSellerAccount.sellerId);
        return (Objects.isNull(seller)) ? null : seller.getRef();
    }

    public Catalog addCatalogSourcingRecord(Catalog catalogSourcingRecord) {
        if (Objects.isNull(catalogSourcingRecord.buyerRef) ||
                (Objects.nonNull(catalogSourcingRecord.buyerRef) && StringUtil.isEmptyOrNull(catalogSourcingRecord.buyerRef.id))) {
            Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
            if (Objects.nonNull(buyer)) {
                catalogSourcingRecord.buyerRef = buyer.getRef();
            }
        }
        return microservice.saveCatalogSourcingRecord(catalogSourcingRecord);
    }

    public Integer getCountByCustomer(String itemId) {
        return microservice.getCountByCustomer(itemId);
    }

    public Map<String, Long> getItemCountByCustomer(List<String> itemIds) {
        return microservice.getItemCountByCustomer(itemIds);
    }

    public Catalog getCatalogByUniqueKey(String catalogItemIdentifier, String sellerId, String packageUnit, String buyerId){
        return microservice.getCatalogByUniqueKey(catalogItemIdentifier,sellerId,packageUnit,buyerId);
    }

    public List<Catalog> getCatalogListByUniqueKey(String catalogItemIdentifier, String packageUnit, String buyerId, List<String> sellerIds){
        return microservice.getCatalogListByUniqueKey(catalogItemIdentifier, packageUnit, buyerId, sellerIds);
    }
    public Catalog getPreferredSourceCatalog(String catalogItemIdentifier, String buyerId){
        return microservice.getPreferredSourceCatalog(catalogItemIdentifier,buyerId);
    }
    public Integer getSearchLimit(){
        return microservice.getSearchLimit();
    }

    private SearchResult<CatalogDTO> removeDuplicateCatalogItems(SearchResult<CatalogDTO> searchResult) {
        if (Objects.isNull(searchResult)) {
            return searchResult;
        }
        if (Objects.isNull(searchResult.results)) {
            return searchResult;
        }
        if (searchResult.results.isEmpty()) {
            return searchResult;
        }
        Map<String, List<CatalogDTO>> catalogItemIdentifierMap = new HashMap<>();
        for (CatalogDTO result : searchResult.results) {
            List<CatalogDTO> catalogItemIdentifierList;
            String key = result.catalogItemIdentifier;
            if (catalogItemIdentifierMap.containsKey(key)) {
                catalogItemIdentifierList = catalogItemIdentifierMap.get(key);
                catalogItemIdentifierList.add(result);
            } else {
                catalogItemIdentifierList = new ArrayList<>();
                catalogItemIdentifierList.add(result);
                catalogItemIdentifierMap.put(key, catalogItemIdentifierList);
            }
        }
        searchResult.results = removeRecordsWithoutSourcingOrHigherScope(catalogItemIdentifierMap);
        return searchResult;
    }

    private List<CatalogDTO> removeRecordsWithoutSourcingOrHigherScope(Map<String, List<CatalogDTO>> catalogItemIdentifierMap) {
        List<CatalogDTO> results = new ArrayList<>();
        if (Objects.isNull(catalogItemIdentifierMap)) {
            return results;
        }
        if (catalogItemIdentifierMap.isEmpty()) {
            return results;
        }
        for (String key : catalogItemIdentifierMap.keySet()) {
            List<CatalogDTO> catalogRecords = catalogItemIdentifierMap.get(key);
            catalogRecords = getScopedCatalogRecords(catalogRecords);
            results.addAll(catalogRecords);
        }
        return results;
    }

    private List<CatalogDTO> getScopedCatalogRecords(List<CatalogDTO> catalogRecords) {
        if (Objects.isNull(catalogRecords)) {
            return catalogRecords;
        }
        if (catalogRecords.size() <= 1) {
            return catalogRecords;
        }
        List<CatalogDTO> results = new ArrayList<>();
        results.addAll(catalogRecords);
        catalogRecords = sortCatalogRecords(catalogRecords);
        int currentIndex = 0;
        CatalogDTO currentCatRec = catalogRecords.get(currentIndex);

        int lowestScope = currentCatRec.sourceValue;
        Stack<Integer> indicesToRemove = new Stack<>();

        int currentScope = currentCatRec.sourceValue;
        String currentSourcing = ((Objects.nonNull(currentCatRec.sellerRef)) ? currentCatRec.sellerRef.id : "");
        for (int i = 1; i < catalogRecords.size(); i++) {
            CatalogDTO thisCatRec = catalogRecords.get(i);
            int thisScope = thisCatRec.sourceValue;
            String thisSourcing = ((Objects.nonNull(thisCatRec.sellerRef)) ? thisCatRec.sellerRef.id : "");
            if (thisScope > currentScope) {
                indicesToRemove.push(i);
            } else if ((StringUtil.isEmptyOrNull(currentSourcing)) && (!StringUtil.isEmptyOrNull(thisSourcing))) {
                indicesToRemove.push(currentIndex);
                currentIndex = i;
                lowestScope = thisScope;
                currentSourcing = thisSourcing;
            }
        }
        while (!indicesToRemove.isEmpty()) {
            int indexToRemove = indicesToRemove.pop();
            catalogRecords.remove(indexToRemove);
        }
        return catalogRecords;
    }

    private List<CatalogDTO> sortCatalogRecords(List<CatalogDTO> catalogRecords) {
        catalogRecords.sort((left, right) -> {
            int rc = Integer.compare(left.sourceValue, right.sourceValue);
            if (rc == 0) {
                String lval = ((Objects.nonNull(left.sellerRef)) ? left.sellerRef.id : "");
                String rval = ((Objects.nonNull(right.sellerRef)) ? right.sellerRef.id : "");
                rc = lval.compareTo(rval);
            }
            return rc;
        });
        return catalogRecords;
    }
}
