package logicole.gateway.services.inventory;

import logicole.apis.inventory.IReturnsMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class ReturnsMicroserviceClient extends MicroserviceClient<IReturnsMicroserviceApi> {

    public ReturnsMicroserviceClient() {
        super(IReturnsMicroserviceApi.class, "logicole-inventory");
    }

    @Produces
    public IReturnsMicroserviceApi getIReturnsMicroserviceApi() {
        return createClient();
    }
}
