package logicole.gateway.services.spacemanagement;

import io.swagger.annotations.*;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.space.*;
import logicole.common.datamodels.space.lookupdata.FloorPlanLayer;
import logicole.common.datamodels.space.staging.StagingFloorPlan;
import logicole.gateway.rest.ExternalRestApi;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.List;

@Api(tags = {"Drawing"})
@ApplicationScoped
@Path("/drawing")
public class DrawingRestApi extends ExternalRestApi<DrawingService> {

    @GET
    @Path("/getUserName")
    @Produces(MediaType.TEXT_PLAIN)
    public String getUserName() {
        return service.getUserName();
    }

    @POST
    @Path("/uploadDrawingFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload Drawing file", notes = "The return value will be the file ID")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a drawing file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadDrawingFile(@QueryParam("floorId") String floorId, @QueryParam("fileDescription") String fileDescription, @ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form)
            throws IOException {
        return service.uploadDrawingFile(floorId, fileDescription, form);
    }

    @GET
    @Path("/deleteDrawingFile")
    public Boolean deleteDrawingFile(@QueryParam("fileId") String fileId) throws IOException {
        return service.deleteDrawingFile(fileId);
    }

    @GET
    @Path("/downloadFloorPlan")
    @ApiOperation(value = "Download Floor Plan", notes = "The floorPlanId should be the GUID returned from the uploadDrawingFile REST API")
    public Response downloadFloorPlan(@ApiParam(value = "The Floor Plan ID", required = true) @QueryParam("floorPlanId") String floorPlanId) throws IOException {
        return service.downloadFloorPlan(floorPlanId);
    }

    @POST
    @Path("/getDrawingSummarySearchResults")
    public SearchResult<DrawingSummary> getDrawingSummarySearchResults(SearchInput searchInput) {
        return service.getDrawingSummarySearchResults(searchInput);
    }

    @GET
    @Path("/updateDrawingActive")
    public Floor updateDrawingActive(@QueryParam("floorId") String floorId, @QueryParam("isActive") Boolean isActive) {
        return service.updateDrawingActive(floorId, isActive);
    }

    @POST
    @Path("/addDrawingToFloor")
    public Floor addDrawingToFloor(@QueryParam("floorId") String floorId, Attachment drawing) {
        return service.addDrawingToFloor(floorId, drawing);
    }

    @GET
    @Path("/removeDrawingFromFloor")
    public Floor removeDrawingFromFloor(@QueryParam("floorId") String floorId) {
        return service.removeDrawingFromFloor(floorId);
    }

    @POST
    @Path("/updateDrawingForFloor")
    public Floor updateDrawingForFloor(@QueryParam("floorId") String floorId, Attachment drawing) {
        return service.updateDrawingForFloor(floorId, drawing);
    }

    @GET
    @Path("/getMaxDrawingAttachmentSize")
    public Integer getMaxDrawingAttachmentSize() {
        return service.getMaxDrawingAttachmentSize();
    }

    @GET
    @Path("/getDocumentTypes")
    public List<String> getDocumentTypes() {
        return service.getDocumentTypes();
    }

    @POST
    @Path("/updateDrawingName")
    public Floor updateDrawingName(@QueryParam("floorId") String floorId, String drawingName) {
        return service.updateDrawingName(floorId, drawingName);
    }

    @GET
    @Path("/getStagingFloorPlanById")
    public StagingFloorPlan getStagingFloorPlanById(@QueryParam("stagingFloorPlanId") String stagingFloorPlanId) {
        return service.getStagingFloorPlanById(stagingFloorPlanId);
    }

    @GET
    @Path("/getDrawingDashboardCounts")
    public DrawingDashboardInfo getDrawingDashboardCounts() {
        return service.getDrawingDashboardCounts();
    }

    @GET
    @Path("/getDiscrepanciesForFloor")
    public FloorPlanDiscrepancy getDiscrepanciesForFloor(@QueryParam("floorId") String floorId, @QueryParam("discrepancyType") String discrepancyType) {
        return service.getDiscrepanciesForFloor(floorId, discrepancyType);
    }

    @GET
    @Path("/findDiscrepanciesForFloor")
    public FloorPlanDiscrepancy findDiscrepanciesForFloor(@QueryParam("floorId") String floorId) {
        return service.findDiscrepanciesForFloor(floorId, null);
    }

    @POST
    @Path("/acceptSizeDiscrepancies")
    public FloorPlanDiscrepancy acceptSizeDiscrepancies(FloorPlanDiscrepancy floorPlanDiscrepancy) {
        return service.acceptSizeDiscrepancies(floorPlanDiscrepancy);
    }

    @GET
    @Path("/getDrawingLegend")
    public List<FloorPlanLegendEntry> getDrawingLegend(@QueryParam("floorId") String floorId, @QueryParam("legendType") String legendType) {
        return service.getDrawingLegend(floorId, legendType);
    }

    @GET
    @Path("/getRoomMetadataByRoomNumber")
    public RoomMetadata getRoomMetadataByRoomNumber(@QueryParam("facilityId") String facilityId, @QueryParam("identifier") String identifier) {
        return service.getRoomMetadataByRoomNumber(facilityId, identifier);
    }

    @GET
    @Path("/getRelatedRecordCountsByRoomNumber")
    public RoomRelatedRecordCounts getRelatedRecordCountsByRoomNumber(@QueryParam("facilityId") String facilityId, @QueryParam("identifier") String identifier) {
        return service.getRelatedRecordCountsByRoomNumber(facilityId, identifier);
    }

    @GET
    @Path("/getDrawingSummariesWithFloorPlans")
    public List<DrawingSummary> getDrawingSummariesWithFloorPlans() {
        return service.getDrawingSummariesWithFloorPlans();
    }

    @GET
    @Path("/getDrawingSummariesWithoutFloorPlans")
    public List<DrawingSummary> getDrawingSummariesWithoutFloorPlans() {
        return service.getDrawingSummariesWithoutFloorPlans();
    }

    @GET
    @Path("/getDrawingSummariesWithOutdatedDiscrepancies")
    public List<DrawingSummary> getDrawingSummariesWithOutdatedDiscrepancies() {
        return service.getDrawingSummariesWithOutdatedDiscrepancies();
    }

    @POST
    @Path("/getDrawingSummariesWithDiscrepancyTypes")
    public List<DrawingSummary> getDrawingSummariesWithDiscrepancyTypes(List<String> discrepancyTypes) {
        return service.getDrawingSummariesWithDiscrepancyTypes(discrepancyTypes);
    }

    @GET
    @Path("/getRoomsFromDrawing")
    public List<Space> getRoomsFromDrawing(String floorId) {
        return service.getRoomsFromDrawing(floorId);
    }

    @GET
    @Path("/getActiveDrawingCountBySpaceId")
    public int getActiveDrawingCountBySpaceId(@QueryParam("spaceId") String spaceId) {
        return service.getActiveDrawingCountBySpaceId(spaceId);
    }

    @POST
    @Path("/getActiveDrawingCountBySpaceIds")
    public int getActiveDrawingCountBySpaceIds(List<String> spaceIds) {
        return service.getActiveDrawingCountBySpaceIds(spaceIds);
    }

    @POST
    @Path("/getGraphicalSearchRecordsByRoomIds")
    public List<GraphicalSearchRecord> getGraphicalSearchRecordsByRoomIds(List<String> roomIds) {
        return service.getGraphicalSearchRecordsByRoomIds(roomIds);
    }

    @GET
    @Path("/getFloorById")
    public Floor getFloorById(@QueryParam("id") String id) {
        return service.getFloorById(id);
    }

    @GET
    @Path("/getFloorPlanLayers")
    public List<FloorPlanLayer> getFloorPlanLayers() {
        return service.getFloorPlanLayers();
    }
}
