package logicole.gateway.services.abi;

import logicole.gateway.common.DataReferenceMDB;
import logicole.common.datamodels.abi.delta.DeltaRequest;
import logicole.common.general.event.BusinessEvent;
import logicole.common.general.util.JSONUtil;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.inject.Inject;
import javax.jms.Destination;
import javax.jms.MessageListener;
import java.io.IOException;

@MessageDriven(name = "DeltaRequestQueueMDB", activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "java:/queue/ABiDeltaRequestBroker"),
        @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
        @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge")})

public class DeltaRequestQueueMDB extends DataReferenceMDB implements MessageListener {

    @Inject
    AbiDeltaService deltaService;

    @Override
    protected void processBusinessEvent(BusinessEvent businessEvent, Destination jmsReplyTo) {
        JSONUtil ju = new JSONUtil();
        try {
            DeltaRequest deltaRequest = ju.deserialize(businessEvent.parameterJson, DeltaRequest.class);
            deltaService.processDeltaRequest(deltaRequest);
        } catch (IOException ex) {
            this.logger.error("ERROR: processing ABi Delta Request: " + ex.getMessage());
        }
    }
}

