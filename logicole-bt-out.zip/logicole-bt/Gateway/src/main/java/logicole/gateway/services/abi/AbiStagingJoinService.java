package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiStagingJoinMicroserviceApi;
import logicole.common.datamodels.abi.ProductIdentifier;
import logicole.common.datamodels.abi.staging.*;
import logicole.common.datamodels.abi.staging.join.InitiateJoinSettings;
import logicole.common.datamodels.abi.staging.join.JoinRecordCommand;
import logicole.common.datamodels.abi.staging.join.JoinStagingRecordsState;
import logicole.common.datamodels.abi.staging.join.StagingRecordByMmc;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ValidationException;
import logicole.common.general.util.string.StringUtil;
import logicole.common.general.util.ObjectMapper;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.product.OfferService;
import logicole.gateway.services.product.ProductService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class AbiStagingJoinService extends BaseGatewayService<IAbiStagingJoinMicroserviceApi> {

    @Inject
    AbiStagingService stagingService;

    @Inject
    ProductService serviceProduct;

    @Inject
    OfferService offerService;

    @Inject
    ProductService productService;

    @Inject
    private ObjectMapper objectMapper;

    public AbiStagingJoinService() {
        super("AbiStaging");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public JoinStagingRecordsState initiateJoinRecordProcess(InitiateJoinSettings settings) {
        return microservice.initiateJoinRecordProcess(settings);
    }

    public AbiCatalogStaging processJoinRecordCommand(JoinRecordCommand joinRecordCommand) throws ValidationException {

        List<String> epis = new ArrayList<String>();
        for (String childRecord:joinRecordCommand.childRecords ) {
            AbiCatalogStaging record = stagingService.findRecordById(childRecord);
            if (Objects.nonNull(record)) {
                if ((!StringUtil.isEmptyOrNull(record.enterpriseProductIdentifier)) &&
                        (!epis.contains(record.enterpriseProductIdentifier))) {
                    epis.add(record.enterpriseProductIdentifier);
                }
            }
        }
       if ( offerService.getEHREnabledenterpriseProductIdentifierCount(epis) > 1 ) {
           throw new ValidationException("Attempted to merge abi records when multiple EHR Enabled Offers exist");
       }

        logger.debug("Inside of processJoinRecordCommand.");
        logger.debug("MODE: " + joinRecordCommand.mode);

        AbiCatalogStaging finalMasterRecord = null;
        ABiManagerBuilder aBiManagerBuilder = new ABiManagerBuilder();

        AbiCatalogStaging updatedMasterRecord = joinRecordCommand.masterRecord;
        updatedMasterRecord.updatedDate = new Date();

        AbiCatalogStaging existingMasterRecord = microservice.getMasterRecord(joinRecordCommand);

        String joinMode = joinRecordCommand.mode;
        if (joinMode != null) {
            joinMode = StringUtil.safeToLowercase(joinMode);
        }

        if ("save".equals(joinMode)) {
            aBiManagerBuilder.recordToUpdate = updatedMasterRecord;
            aBiManagerBuilder.existingRecord = existingMasterRecord;
            finalMasterRecord = microservice.processSaveJoinRecordCommand(aBiManagerBuilder);
        } else if ("merge".equals(joinMode)) {
            finalMasterRecord = processMergeJoinRecordCommand(existingMasterRecord, updatedMasterRecord, joinRecordCommand.childRecords);
        } else {
            throw new ValidationException("Command " + joinMode + " is not supported.");
        }

        for (String childId : joinRecordCommand.childRecords) {
            String mergedToId = finalMasterRecord.getId();
            Integer numRecordsUpdated = microservice.setMergedToField(childId, mergedToId);
            this.logger.debug("*** Update child record (" + childId + ") merged to field to "
                    + finalMasterRecord.getId() + ". Update Count: " + numRecordsUpdated);
        }

        return finalMasterRecord;
    }

    protected AbiCatalogStaging processMergeJoinRecordCommand(AbiCatalogStaging existingMasterRecord,
                                                              AbiCatalogStaging updatedMasterRecord,
                                                              List<String> childRecords) {
        ABiManagerBuilder aBiManagerBuilder = new ABiManagerBuilder();
        updatedMasterRecord.recordStatus = RecordStatusType.INCOMPLETE;
        updatedMasterRecord.catalogSource = CatalogSourceType.MERGED;
        for (String childId : childRecords) {
            AbiCatalogStaging childRecord = stagingService.findRecordById(childId);
            this.markChildRecordAsMerged(childRecord);
            this.processSiteCatalogChanges(updatedMasterRecord, childRecord);
            this.processMmcIdChanges(updatedMasterRecord, childRecord);
        }

        aBiManagerBuilder.existingRecord = existingMasterRecord;
        aBiManagerBuilder.recordToUpdate = updatedMasterRecord;
        return microservice.saveMasterRecord(aBiManagerBuilder);
    }

    protected void markChildRecordAsMerged(AbiCatalogStaging recordThatWasMerged) {
        stagingService.changeRecordStatus(recordThatWasMerged, RecordStatusType.MERGED);
        stagingService.updateRecord(recordThatWasMerged);
    }

    protected void processSiteCatalogChanges(AbiCatalogStaging masterRecord, AbiCatalogStaging childRecord) {
        String childEntProdId = childRecord.enterpriseProductIdentifier;
        String masterEntProdId = masterRecord.enterpriseProductIdentifier;

        if (!childEntProdId.equals(masterEntProdId)) {

           logger.info("AbiStagingJoinService: childEntProdId " + childEntProdId + " masterEntProdId :" + masterEntProdId);
           productService.updateEnterpriseProductId(childEntProdId, masterEntProdId);
        }

        if (childEntProdId.compareTo(masterEntProdId) != 0) {
            this.updateSecondaryProductIdentifiers(masterRecord, childEntProdId);
        }

    }

    protected void updateSecondaryProductIdentifiers(AbiCatalogStaging masterRecord, String childEntProdId) {
        List<ProductIdentifier> secondaryProductIdentifiers = masterRecord.secondaryProductIdentifiers;
        boolean foundEntProdId = false;
        for (ProductIdentifier prodIdent : secondaryProductIdentifiers) {
            if (prodIdent.identifier.compareTo(childEntProdId) == 0) {
                foundEntProdId = true;
                break;
            }
        }
        if (!foundEntProdId) {
            ProductIdentifier newProdIdent = new ProductIdentifier();
            newProdIdent.identifier = childEntProdId;
            newProdIdent.identifierType = "Prior EnterpriseProductIdentifier";
            secondaryProductIdentifiers.add(newProdIdent);
        }
    }

    protected void processMmcIdChanges(AbiCatalogStaging masterRecord, AbiCatalogStaging childRecord) {
        List<Integer> childMmcIds = childRecord.mmcProductIdentifiers;
        List<Integer> masterMmcIds = masterRecord.mmcProductIdentifiers;

        if ((Objects.isNull(childMmcIds)) || (Objects.isNull(masterMmcIds)) ||
            (childMmcIds.isEmpty()) || (masterMmcIds.isEmpty())) {
                return;
        }

        childMmcIds = new ArrayList<>();
        childMmcIds.addAll(childRecord.mmcProductIdentifiers);
        Collections.sort(childMmcIds);
        
        masterMmcIds = new ArrayList<>();
        masterMmcIds.addAll(masterRecord.mmcProductIdentifiers);
        Collections.sort(masterMmcIds);


        if (!childMmcIds.equals(masterMmcIds)) {
            for (Integer childMmcId : childMmcIds) {
                if (!microservice.doesOldMmcProductIdentifierExist(childMmcId)) {
                    List<MmcProductIdentifierMapRecord> recordList = new ArrayList<>();
                    for (Integer masterMmcId : masterMmcIds) {
                        MmcProductIdentifierMapRecord record = new MmcProductIdentifierMapRecord();
                        record.mmcProductIdentifierOld = childMmcId;
                        record.mmcProductIdentifier = masterMmcId;
                        recordList.add(record);
                    }
                    microservice.insertNewMmcProductList(recordList);
                }
            }
        }
    }

    public void deleteMergeInitiatedRecord(@QueryParam("masterRecordId") String masterRecordId) {
        microservice.deleteMergeInitiatedRecord(masterRecordId);
    }

    public List<StagingRecordByMmc> getMergePossibilitiesByMmc() {
        return microservice.getMergePossibilitiesByMmc();
    }

    public List<AbiCatalogStaging> getMergedRecordList(@QueryParam("filterData") String filterData) {
        return microservice.getMergedRecordList(filterData);
    }

    public List<AbiCatalogStaging> undoMerge(@QueryParam("masterRecordId") String masterRecordId) {
        AbiCatalogStaging existingMasterRecord =  stagingService.findRecordById(masterRecordId);
        List<AbiCatalogStaging> childRecords = microservice.undoMerge(masterRecordId);

        for (AbiCatalogStaging childRecord: childRecords) {
            if ((Objects.nonNull(childRecord.mmcProductIdentifiers)) && (!childRecord.mmcProductIdentifiers.isEmpty())) {
                for (Integer mmcId : childRecord.mmcProductIdentifiers) {
                    productService.updateEpiFromMmcId(mmcId, existingMasterRecord.enterpriseProductIdentifier, childRecord.enterpriseProductIdentifier);
                }
            }
        }
        return childRecords;
    }

    public JoinStagingRecordsState getJoinStagingRecordsState(@QueryParam("masterRecordId") String masterRecordId) {
        return microservice.getJoinStagingRecordsState(masterRecordId);
    }
}
