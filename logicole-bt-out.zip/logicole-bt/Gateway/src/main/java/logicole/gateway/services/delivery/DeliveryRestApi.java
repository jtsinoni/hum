package logicole.gateway.services.delivery;

import io.swagger.annotations.Api;

import logicole.common.datamodels.delivery.DeliveryList;
import logicole.common.datamodels.inventory.PickList;
import logicole.common.datamodels.sale.fulfillment.AutomaticFulfillmentDTO;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Api(tags = {"Delivery"})
@ApplicationScoped
@Path("/delivery")
public class DeliveryRestApi extends ExternalRestApi<DeliveryService> {


    @POST
    @Path("/generateDeliveryList")
    @Produces(MediaType.TEXT_PLAIN)
    public boolean generateDeliveryList(PickList pickList) {
        return service.generateDeliveryList(pickList);
    }

    @POST
    @Path("/generateBackOrderDeliveryList")
    public List<DeliveryList> generateBackOrderDeliveryList(AutomaticFulfillmentDTO automaticFulfillmentDTO) {
        return service.generateBackOrderDeliveryList(automaticFulfillmentDTO);
    }

    @GET
    @Path("/getGeneratedDeliveryListsByInventorySystemId")
    public List<DeliveryList> getGeneratedDeliveryListsByInventorySystemId(@QueryParam("inventorySystemId") String inventorySystemId) {
        return service.getGeneratedDeliveryListsByInventorySystemId(inventorySystemId);
    }

    @GET
    @Path("/getDeliveryListById")
    public DeliveryList getDeliveryListById(@QueryParam("deliveryListId") String deliveryListId) {
        return service.getDeliveryListById(deliveryListId);
    }


    @GET
    @Path("/getProcessedDeliveryListsByInventorySystemId")
    public List<DeliveryList> getProcessedDeliveryListsByInventorySystemId(@QueryParam("inventorySystemId") String inventorySystemId) {
        return service.getProcessedDeliveryListsByInventorySystemId(inventorySystemId);
    }


    @POST
    @Path("/processDeliveryList")
    public DeliveryList processDeliveryList(DeliveryList deliveryList) {
        return service.processDeliveryList(deliveryList);
    }
}
