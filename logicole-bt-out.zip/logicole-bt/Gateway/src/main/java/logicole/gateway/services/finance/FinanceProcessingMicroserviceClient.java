package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceProcessingMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class FinanceProcessingMicroserviceClient extends MicroserviceClient<IFinanceProcessingMicroserviceApi> {
    public FinanceProcessingMicroserviceClient(){
        super(IFinanceProcessingMicroserviceApi.class, "logicole-finance");
    }

    @Produces
    public IFinanceProcessingMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
