package logicole.gateway.services.system;

import io.swagger.annotations.Api;
import logicole.common.datamodels.system.SystemNotification;
import logicole.gateway.rest.ExternalRestApi;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;

@Api(tags = {"SystemNotification"})
@ApplicationScoped
@Path("/systemNotification")
public class SystemNotificationRestApi extends ExternalRestApi<SystemNotificationService> {

    @GET
    @Path("/getActiveSystemNotifications")
    public List<SystemNotification> getActiveSystemNotifications() {
        return service.getActiveSystemNotifications();
    }

    @GET
    @Path("/getAllSystemNotifications")
    public List<SystemNotification> getAllSystemNotifications() {
        return service.getAllSystemNotifications();
    }

    @POST
    @Path("/addSystemNotification")
    public SystemNotification addSystemNotification(SystemNotification systemNotification) {
        return service.addSystemNotification(systemNotification);
    }

    @GET
    @Path("/getSystemNotificationById")
    public SystemNotification getSystemNotificationById(@QueryParam("notificationId") String notificationId) {
        return service.getSystemNotificationById(notificationId);
    }

    @POST
    @Path("/saveSystemNotification")
    public SystemNotification saveSystemNotification(SystemNotification systemNotification) {
        return service.saveSystemNotification(systemNotification);
    }

}
