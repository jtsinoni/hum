package logicole.gateway.services.assemblage;

import logicole.apis.assemblage.IAllowanceImportMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AllowanceImportMicroserviceClient extends MicroserviceClient<IAllowanceImportMicroserviceApi> {

    public AllowanceImportMicroserviceClient(){
        super(IAllowanceImportMicroserviceApi.class, "logicole-assemblage");
    }

    @Produces
    public IAllowanceImportMicroserviceApi getIAllowanceImportMicroserviceApi() {
        return createClient();
    }
}
