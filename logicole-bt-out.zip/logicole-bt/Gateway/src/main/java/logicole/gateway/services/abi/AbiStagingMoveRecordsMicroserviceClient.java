package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiStagingMoveRecordsMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiStagingMoveRecordsMicroserviceClient extends MicroserviceClient<IAbiStagingMoveRecordsMicroserviceApi> {
    public AbiStagingMoveRecordsMicroserviceClient() {
        super(IAbiStagingMoveRecordsMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiStagingMoveRecordsMicroserviceApi getAbiStagingMoveRecordsService() {
        return createClient();
    }
}

