package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.taxonomy.*;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi/taxonomy")
public class AbiTaxonomyRestApi extends ExternalRestApi<AbiTaxonomyService> {

    @GET
    @Path("/getSegments")
    public List<UnspscSegment> getSegments() {
        return service.getSegments();
    }

    @GET
    @Path("/getFamilies")
    public List<UnspscFamily> getFamilies(@QueryParam("segmentId") String segmentId) {
        return service.getFamilies(segmentId);
    }

    @GET
    @Path("/getClasses")
    public List<UnspscClass> getClasses(@QueryParam("familyId") String familyId) {
        return service.getClasses(familyId);
    }

    @GET
    @Path("/getCommodities")
    public List<UnspscCommodity> getCommodities(@QueryParam("classId") String classId) {
        return service.getCommodities(classId);
    }

    @GET
    @Path("/getSegmentHierarchy")
    public UnspscSegmentHierarchy getSegmentHierarchy(@QueryParam("segmentId") String segmentId) {
        return service.getSegmentHierarchy(segmentId);
    }

    @GET
    @Path("/getTaxonomyLevelDetails")
    public UnspscLevelDetails getTaxonomyLevelDetails(@QueryParam("level") String level,
                                                      @QueryParam("levelId") String levelId) {
        return service.getTaxonomyLevelDetails(level, levelId);
    }

    @GET
    @Path("/getTaxonomyLevelDetailsByUnspscCode")
    public UnspscLevelDetails getTaxonomyLevelDetailsByUnspscCode(@QueryParam("unspscCode") Integer unspscCode) {
        return service.getTaxonomyLevelDetailsByUnspscCode(unspscCode);
    }

    @GET
    @Path("/search")
    public List<UnspscRecord> search(@QueryParam("code") String code, @QueryParam("title") String title) {
        return service.search(code, title);
    }

    @GET
    @Path("/getSegmentRecords")
    public List<UnspscRecord> getSegmentRecords() {
        return service.getSegmentRecords();
    }

    @GET
    @Path("/getFamilyRecords")
    public List<UnspscRecord> getFamilyRecords(@QueryParam("segmentId") String segmentId) {
        return service.getFamilyRecords(segmentId);
    }

    @GET
    @Path("/getClassRecords")
    public List<UnspscRecord> getClassRecords(@QueryParam("familyId") String familyId) {
        return service.getClassRecords(familyId);
    }

    @GET
    @Path("/getCommodityRecords")
    public List<UnspscRecord> getCommodityRecords(@QueryParam("classId") String classId) {
        return service.getCommodityRecords(classId);
    }


    @GET
    @Path("/getDistinctProductNouns")
    public List<String> getDistinctProductNouns() {
        return service.getDistinctProductNouns();
    }

    @GET
    @Path("/getUnspscCodesForProductNoun")
    public List<Integer> getUnspscCodesForProductNoun(@QueryParam("productNoun") String productNoun) {
        return service.getUnspscCodesForProductNoun(productNoun);
    }

    @POST
    @Path("/getUnspscRecordsByUnspscCodeList")
    public List<UnspscRecord> getUnspscRecordsByUnspscCodeList(List<Integer> unspscCodeList) {
        return service.getUnspscRecordsByUnspscCodeList(unspscCodeList);
    }
}
