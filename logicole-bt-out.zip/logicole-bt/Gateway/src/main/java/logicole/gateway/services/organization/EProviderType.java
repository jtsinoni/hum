package logicole.gateway.services.organization;

import java.util.ArrayList;
import java.util.List;

public enum EProviderType {

    EQUIPMENT_REQUEST_WORKFLOW_DEFINITION ("Equipment Workflow Definition","equipmentWorkflowDefinitionProvider"),
    FINANCE_SYSTEM_CONFIG_PROVIDER("Financial System Configuration", "financialSystemConfigProvider"),
    FM_ORGANIZATION_REFERENCE_PROVIDER("Organization Reference", "fmOrganizationReferenceProvider"),
    MEDICAL_MATERIAL_REFERENCE_PROVIDER( "Primary Medical Material Activity", "primaryMedicalMaterialActivityProvider"),
    MEDICAL_EQUIPMENT_REFERENCE_PROVIDER( "Primary Medical Equipment Activity", "primaryMedicalEquipmentActivityProvider"),
    MEDICAL_MAINTENANCE_REFERENCE_PROVIDER( "Primary Medical Maintenance Activity", "primaryMedicalMaintenanceActivityProvider"),
    FACILITY_MANAGEMENT_REFERENCE_PROVIDER( "Primary Facility Management Activity","primaryFacilityManagementActivityProvider"),
    EXCESS_ACTIVITY_REFERENCE_PROVIDER("Excess Activity", "excessActivityProvider"),
    LOAN_ACTIVITY_REFERENCE_PROVIDER("Loan Activity", "loanActivityProvider");


    public final String displayText;
    public final String value;

    EProviderType(String displayText, String value) {
        this.displayText = displayText;
        this.value = value;
    }

    @Override
    public String toString() {
        return this.value;
    }

    private static final List<ProviderType> displayTextList = new ArrayList<>();

    public static List<ProviderType> getDisplayTextList() {
        if (displayTextList.isEmpty()) {
            for (EProviderType value : values()) {
                ProviderType providerType = new ProviderType(value.displayText, value.value);
                displayTextList.add(providerType);
            }

        }
        return displayTextList;
    }
}
