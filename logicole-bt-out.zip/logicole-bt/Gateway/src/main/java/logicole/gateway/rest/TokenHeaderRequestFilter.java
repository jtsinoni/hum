package logicole.gateway.rest;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.general.EThreadType;
import logicole.common.general.security.SecurityConstants;
import logicole.common.general.security.token.SystemUserTokenUtil;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.core.MultivaluedMap;

@ApplicationScoped
public class TokenHeaderRequestFilter implements ClientRequestFilter {

    @Inject
    private CurrentUserBT currentUserBt;

    @Inject
    protected SystemUserTokenUtil systemUserTokenUtil;

    @Override
    public void filter(ClientRequestContext requestContext) {
        MultivaluedMap<String, Object> headers = requestContext.getHeaders();
        headers.add(SecurityConstants.CLIENT_ID, SecurityConstants.CLIENT_ID_LOGICOLE);

        String jsonWebToken = null;
        String correlationId = null;

        EThreadType threadType = EThreadType.determineThreadType();
        if (threadType.supportsContext) {
            correlationId = currentUserBt.getCorrelationId();
            jsonWebToken = currentUserBt.getJsonWebToken();
        }else{
            jsonWebToken = systemUserTokenUtil.getJwtForSystemUserProfile(SecurityConstants.MDB_SPECIAL_USER_PROFILE_KEY);
        }

        headers.add(SecurityConstants.CORRELATION_ID, correlationId);

        if (jsonWebToken != null) {
            String authHeader = SecurityConstants.AUTH_JWT_PREFIX + jsonWebToken;
            headers.add(SecurityConstants.AUTHORIZATION, authHeader);
        }
    }
}
