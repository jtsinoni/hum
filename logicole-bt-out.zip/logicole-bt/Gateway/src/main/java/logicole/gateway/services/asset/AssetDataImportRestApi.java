package logicole.gateway.services.asset;

import io.swagger.annotations.*;
import logicole.common.datamodels.system.AuthoritativeSourceRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.List;

@Api(tags = {"AssetDataImport"})
@ApplicationScoped
@Path("/assetDataImport")
public class AssetDataImportRestApi extends ExternalRestApi<AssetDataImportService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getAllAuthoritativeSourceRefs")
    public List<AuthoritativeSourceRef> getAllAuthoritativeSourceRefs() {
        return service.getAllAuthoritativeSourceRefs();
    }

    @GET
    @Path("/getMaxUploadSize")
    public Integer getMaxUploadSize() {
        return service.getMaxUploadSize();
    }

    @POST
    @Path("/importAssetFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.TEXT_PLAIN)
    @ApiOperation(value = "Import a file", notes = "The return value will be the file ID")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to import",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public String importAssetFile(@QueryParam("fileType") String fileType,
                                  @ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) throws IOException {
        return service.importFile(fileType, form);
    }

}
