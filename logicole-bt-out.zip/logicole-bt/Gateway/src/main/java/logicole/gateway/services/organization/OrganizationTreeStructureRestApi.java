package logicole.gateway.services.organization;

import io.swagger.annotations.Api;
import logicole.common.datamodels.organization.OrganizationTreeStructure;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"OrganizationTreeStructure"})
@ApplicationScoped
@Path("/organizationTreeStructure")
public class OrganizationTreeStructureRestApi extends ExternalRestApi<OrganizationTreeStructureService> {

    @GET
    @Path("/getOrganizationTreeStructures")
    public List<OrganizationTreeStructure> getOrganizationTreeStructures(@QueryParam("orgId") String orgId) {
        return service.getOrganizationTreeStructures(orgId);
    }

    @GET
    @Path("/getOrganizationTreeStructure")
    public OrganizationTreeStructure getOrganizationTreeStructure(@QueryParam("organizationTreeStructureId")
                                                                              String organizationTreeStructureId) {
        return service.getOrganizationTreeStructure(organizationTreeStructureId);
    }

    @POST
    @Path("/createOrganizationTreeStructure")
    public OrganizationTreeStructure createOrganizationTreeStructure(OrganizationTreeStructure organizationTreeStructure) {
        return service.createOrganizationTreeStructure(organizationTreeStructure);
    }

    @POST
    @Path("/updateOrganizationTreeStructure")
    public OrganizationTreeStructure updateOrganizationTreeStructure(OrganizationTreeStructure organizationTreeStructure) {
        return service.updateOrganizationTreeStructure(organizationTreeStructure);
    }

    @POST
    @Path("/deleteOrganizationTreeStructure")
    public void deleteOrganizationTreeStructure(String organizationTreeStructureId) {
        service.deleteOrganizationTreeStructure(organizationTreeStructureId);
    }

}
