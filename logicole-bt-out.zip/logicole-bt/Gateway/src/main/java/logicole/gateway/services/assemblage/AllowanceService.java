package logicole.gateway.services.assemblage;

import logicole.apis.assemblage.IAllowanceMicroserviceApi;
import logicole.gateway.services.assemblage.logging.AMLogger;
import logicole.common.datamodels.assemblage.AssemblageItem;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@ApplicationScoped
public class AllowanceService extends BaseGatewayService<IAllowanceMicroserviceApi> {

    @Inject
    AMLogger amLogger;

    private static final String ELASTIC_MESSAGE = "Elastic search is not supported now";

    public AllowanceService() {
        super("Allowance");
    }

    public SearchResult<AssemblageItem> getAssemblagesWithItem(SearchInput searchInput) {

        validateSearchEngine();
        return microservice.getAssemblagesWithItem(searchInput);
    }

    public SearchResult<AssemblageItem> getAssemblagesWithoutItem(SearchInput searchInput) {

        validateSearchEngine();

        searchInput.searchText = "";

        return microservice.getAssemblagesWithoutItem(searchInput);

    }

    public void updateAssemblageItems(List<AssemblageItem> assemblageItemsToUpdate) {

        for (AssemblageItem updatedItem : assemblageItemsToUpdate) {

            if (deleteItem(updatedItem)) {
                microservice.deleteAssemblageItem(updatedItem);
            }

            else {
                AssemblageItem currentItem = microservice.getAssemblageItemById(updatedItem.getId());
                logChanges(updatedItem, currentItem);
                microservice.updateAssemblageItem(updatedItem);
            }
        }
    }

    private boolean deleteItem(AssemblageItem updatedItem) {

        boolean deleteItem = false;

        int minimumQuantityAllowance = updatedItem.minimumQuantityAllowance == null ? 0 : updatedItem.minimumQuantityAllowance;
        int onHandQuantity = updatedItem.onHandQuantity == null ? 0 : updatedItem.onHandQuantity;
        int dueInQuantity = updatedItem.dueInQuantity == null ? 0 : updatedItem.dueInQuantity;

        if (minimumQuantityAllowance == 0 && onHandQuantity == 0 && dueInQuantity == 0) {
            deleteItem = true;
        }

        return deleteItem;
    }

    private void logChanges(AssemblageItem updatedItem, AssemblageItem currentItem) {

        if (updatedItem != null && currentItem != null) {

            logMinimumQuantityAllowanceChange(updatedItem, currentItem);
            logCommingledIndicatorChange(updatedItem, currentItem);
            logCommingledQuantityChange(updatedItem, currentItem);
            logCommingledCodeChange(updatedItem, currentItem);
            logCriticalIndicatorChange(updatedItem, currentItem);
            logCriticalQuantityChange(updatedItem, currentItem);
            logCriticalCodeChange(updatedItem, currentItem);
            logDeferredIndicatorChange(updatedItem, currentItem);
            logDeferredQuantityChange(updatedItem, currentItem);
            logDeferredCodeChange(updatedItem, currentItem);
        }
    }

    private void logMinimumQuantityAllowanceChange(AssemblageItem updatedItem, AssemblageItem currentItem) {

        int updated = updatedItem.minimumQuantityAllowance == null ? 0 : updatedItem.minimumQuantityAllowance;
        int current = currentItem.minimumQuantityAllowance == null ? 0 : currentItem.minimumQuantityAllowance;

        if (updated != current) {
            amLogger.logAssemblageItemChange(updatedItem,"Allow Quantity", Integer.toString(current), Integer.toString(updated), currentUserBT);
            updatedItem.previousQuantityAllowance = current;
        }
    }

    private void logCommingledIndicatorChange(AssemblageItem updatedItem, AssemblageItem currentItem) {

        boolean updated = updatedItem.isCommingled == null ? false : updatedItem.isCommingled;
        boolean current = currentItem.isCommingled == null ? false : currentItem.isCommingled;

        if (updated != current) {
            amLogger.logAssemblageItemChange(updatedItem, "Commingled Indicator", Boolean.toString(current), Boolean.toString(updated), currentUserBT);
        }
    }

    private void logCommingledQuantityChange(AssemblageItem updatedItem, AssemblageItem currentItem) {

        int updated = updatedItem.commingledQuantity == null ? 0 : updatedItem.commingledQuantity;
        int current = currentItem.commingledQuantity == null ? 0 : currentItem.commingledQuantity;

        if (updated != current) {
            amLogger.logAssemblageItemChange(updatedItem, "Commingled Quantity", Integer.toString(current), Integer.toString(updated), currentUserBT);
        }
    }

    private void logCommingledCodeChange(AssemblageItem updatedItem, AssemblageItem currentItem) {

        if (updatedItem.commingledRef != null && updatedItem.commingledRef.commingledCode != null &&
            currentItem.commingledRef != null &&currentItem.commingledRef.commingledCode != null) {

            String updated = updatedItem.commingledRef.commingledCode;
            String current = currentItem.commingledRef.commingledCode;

            if (!updated.equals(current)) {
                amLogger.logAssemblageItemChange(updatedItem, "Commingled Code", current, updated, currentUserBT);
            }
        }
    }

    private void logCriticalIndicatorChange(AssemblageItem updatedItem, AssemblageItem currentItem) {

        boolean updated = updatedItem.isCritical == null ? false : updatedItem.isCritical;
        boolean current = currentItem.isCritical == null ? false : currentItem.isCritical;

        if (updated != current) {
            amLogger.logAssemblageItemChange(updatedItem, "Critical Indicator", Boolean.toString(current), Boolean.toString(updated), currentUserBT);
        }
    }

    public void logCriticalQuantityChange(AssemblageItem updatedItem, AssemblageItem currentItem) {

        int updated = updatedItem.criticalQuantity == null ? 0 : updatedItem.criticalQuantity;
        int current = currentItem.criticalQuantity == null ? 0 : currentItem.criticalQuantity;

        if (updated != current) {
            amLogger.logAssemblageItemChange(updatedItem, "Critical Quantity", Integer.toString(current), Integer.toString(updated), currentUserBT);
        }
    }

    public void logCriticalCodeChange(AssemblageItem updatedItem, AssemblageItem currentItem) {

        if (updatedItem.criticalRef != null && updatedItem.criticalRef.criticalCode != null &&
            currentItem.criticalRef != null &&currentItem.criticalRef.criticalCode != null) {

            String updated = updatedItem.criticalRef.criticalCode;
            String current = currentItem.criticalRef.criticalCode;

            if (!updated.equals(current)) {
                amLogger.logAssemblageItemChange(updatedItem, "Critical Code", current, updated, currentUserBT);
            }
        }
    }

    private void logDeferredIndicatorChange(AssemblageItem updatedItem, AssemblageItem currentItem) {

        boolean updated = updatedItem.isDeferred == null ? false : updatedItem.isDeferred;
        boolean current = currentItem.isDeferred == null ? false : currentItem.isDeferred;

        if (updated != current) {
            amLogger.logAssemblageItemChange(updatedItem, "Deferred Indicator", Boolean.toString(current), Boolean.toString(updated), currentUserBT);
        }
    }

    private void logDeferredQuantityChange(AssemblageItem updatedItem, AssemblageItem currentItem) {

        int updated = updatedItem.deferredQuantity == null ? 0 : updatedItem.deferredQuantity;
        int current = currentItem.deferredQuantity == null ? 0 : currentItem.deferredQuantity;

        if (updated != current) {
           amLogger.logAssemblageItemChange(updatedItem, "Deferred Quantity", Integer.toString(current), Integer.toString(updated), currentUserBT);
        }
    }

    private void logDeferredCodeChange(AssemblageItem updatedItem, AssemblageItem currentItem) {

        if (updatedItem.deferredRef != null && updatedItem.deferredRef.deferredCode != null &&
            currentItem.deferredRef != null &&currentItem.deferredRef.deferredCode != null) {

            String updated = updatedItem.deferredRef.deferredCode;
            String current = currentItem.deferredRef.deferredCode;

            if (!updated.equals(current)) {
                amLogger.logAssemblageItemChange(updatedItem, "Deferred Code", current, updated, currentUserBT);
            }
        }
    }

    public List<AssemblageItem> addAssemblageItems(List<AssemblageItem> assemblageItemsToAdd) {
        return microservice.addAssemblageItems(assemblageItemsToAdd);
    }

    private void validateSearchEngine() {

        if (ESearchEngine.ELASTIC.equals(microservice.getSearchEngine())){
            throw new ApplicationException(ELASTIC_MESSAGE);
        }
    }
}
