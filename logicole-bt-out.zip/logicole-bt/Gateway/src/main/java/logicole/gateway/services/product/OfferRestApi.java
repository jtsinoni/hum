package logicole.gateway.services.product;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import logicole.common.datamodels.abi.PackageUnit;
import logicole.common.datamodels.ehr.product.EhrSearchCriteria;
import logicole.common.datamodels.inventory.InventoryRecord;
import logicole.common.datamodels.product.Offer;
import logicole.common.datamodels.product.OfferSellerUpdateResponse;
import logicole.common.datamodels.product.OfferSummary;
import logicole.common.datamodels.product.SiteCatalogRecord;
import logicole.common.datamodels.product.SearchInputOffer;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.rest.ExternalRestApi;
import org.bson.Document;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Offer"})
@ApplicationScoped
@Path("/offer")
public class OfferRestApi extends ExternalRestApi<OfferService> {

    @POST
    @Path("/addOffer")
    @ApiOperation(value = "Insert new offer")
    public Offer addOffer(Offer newOffer) {
        return service.saveOffer(newOffer);
    }

    @POST
    @Path("/addOfferToInventory")
    public InventoryRecord addOfferToInventory(@QueryParam("currentNodeId") String currentNodeId, @QueryParam("offerId") String offerId) throws ApplicationException {
        return service.addOfferToInventory(currentNodeId, offerId);
    }

    @GET
    @Path("/aggregateSearchOffer")
    @ApiOperation(value = "Perform a aggregate search.")
    public String aggregateSearchOffer(@QueryParam("searchText") String searchText, @QueryParam("criteria") String criteria, @QueryParam("projection") String projection, @QueryParam("limit") Integer limit) {
        return service.aggregateSearchOffer(searchText, criteria, projection, limit);
    }

    @GET
    @Path("/getDistinctSellerNamesFromOffers")
    public List<String> getDistinctSellerNamesFromOffers() {
        return service.getDistinctSellerNamesFromOffers();
    }

    @GET
    @Path("/getOfferByEnterpriseItemIdentifier")
    public List<Offer> getOfferByEnterpriseItemIdentifier(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier) {
        return service.getOfferByEnterpriseItemIdentifier(organizationIdentifier, enterpriseItemIdentifier);
    }

    @GET
    @Path("/getOfferByEnterpriseItemIdentifierDefault")
    public List<Offer> getOfferByEnterpriseItemIdentifierDefault(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier) {
        return service.getOfferByEnterpriseItemIdentifierDefault(organizationIdentifier, enterpriseItemIdentifier);
    }

    @GET
    @Path("/getOfferByEnterpriseItemIdentifierSeller")
    public List<Offer> getOfferByEnterpriseItemIdentifierSeller(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier, @QueryParam("sellerName") String sellerName) {
        return service.getOfferByEnterpriseItemIdentifierSeller(organizationIdentifier, enterpriseItemIdentifier, sellerName);
    }

    @GET
    @Path("/getOfferByEnterpriseProductIdentifier")
    public List<Offer> getOfferByEnterpriseProductIdentifier(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.getOfferByEnterpriseProductIdentifier(organizationIdentifier, enterpriseProductIdentifier);
    }

    @GET
    @Path("/getOfferByEnterpriseProductIdentifierDefault")
    public List<Offer> getOfferByEnterpriseProductIdentifierDefault(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.getOfferByEnterpriseProductIdentifierDefault(organizationIdentifier, enterpriseProductIdentifier);
    }

    @GET
    @Path("/getOfferById")
    public Offer getOfferById(@QueryParam("id") String id) {
        return service.getOfferById(id);
    }

    @GET
    @Path("/getOfferByOrganizationIdentifier")
    public List<Offer> getOfferByOrganizationIdentifier(@QueryParam("organizationIdentifier") String organizationIdentifier) {
        return service.getOfferByOrganizationIdentifier(organizationIdentifier);
    }

    @GET
    @Path("/getOfferByPartialEnterpriseProductIdentifier")
    public List<Offer> getOfferByPartialEnterpriseProductIdentifier(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("partialProductIdentifier") String partialProductIdentifier) {
        return service.getOfferByPartialEnterpriseProductIdentifier(organizationIdentifier, partialProductIdentifier);
    }

    @GET
    @Path("/getOfferByPartialProductIdentifier")
    public List<Offer> getOfferByPartialProductIdentifier(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("partialProductIdentifier") String partialProductIdentifier) {
        return service.getOfferByPartialProductIdentifier(organizationIdentifier, partialProductIdentifier);
    }

    @GET
    @Path("/getOfferByProductIdentifier")
    public List<Offer> getOfferByProductIdentifier(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("productIdentifier") String productIdentifier) {
        return service.getOfferByProductIdentifier(organizationIdentifier, productIdentifier);
    }

    @GET
    @Path("/getOfferByProductIdentifierDefault")
    public List<Offer> getOfferByProductIdentifierDefault(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("productIdentifier") String productIdentifier) {
        return service.getOfferByProductIdentifierDefault(organizationIdentifier, productIdentifier);
    }

    @GET
    @Path("/getOfferBySellerName")
    public List<Offer> getOfferBySellerName(@QueryParam("organizationIdentifier") String organizationIdentifier, @QueryParam("sellerName") String sellerName) {
        return service.getOfferBySellerName(organizationIdentifier, sellerName);
    }

    @GET
    @Path("/getOffers")
    @ApiOperation(value = "Performs a query for the given JSON filter document")
    public List<Offer> getOffers(@QueryParam("filter") String filter) {
        return service.getOffers(filter);
    }

    @POST
    @Path("/getOfferSearchResults")
    public String getOfferSearchResults(SearchInputOffer searchInputOffer) {
        return service.getOfferSearchResults(searchInputOffer);
    }

    @PUT
    @Path("/saveOffer")
    @ApiOperation(value = "Insert new or update existing offer.")
    public Offer saveOffer(Offer offer) {
        return service.saveOffer(offer);
    }

    @PUT
    @Path("/syncOffers")
    @ApiOperation(value = "Update offers when siteCatalog updated")
    public Integer syncOffers(SiteCatalogRecord siteCatalogRecord) {
        return service.syncOffers(siteCatalogRecord);
    }

    @PUT
    @Path("/saveOfferDocument")
    @ApiOperation(value = "Insert new or update existing offer.")
    public String saveOffer(@QueryParam("offer") String offer) {
        return service.saveOfferDocument(offer);
    }

    @GET
    @Path("/textSearchOffer")
    @ApiOperation(value = "Perform a keyword search for the given criteria.")
    public List<Offer> textSearchOffer(@QueryParam("siteId") String siteId, @QueryParam("searchString") String searchString) {
        return service.textSearchOffer(siteId, searchString);
    }

    @PUT
    @Path("/updateSellersInOffers")
    public OfferSellerUpdateResponse updateSellersInOffers(@QueryParam("changeToSellerId") String changeToSellerId, @QueryParam("changeToSellerName") String changeToSellerName, @QueryParam("changeToSellerType") String changeToSellerType, List<String> sellerNamesToUpdate) {
        return service.updateSellersInOffers(changeToSellerId, changeToSellerName, changeToSellerType, sellerNamesToUpdate);
    }

    @GET
    @Path("/findByEnterpriseProductIdentifier")
    public List<Offer> findByEnterpriseProductIdentifier(@QueryParam("siteOrgId") String siteOrgId,
                                                         @QueryParam("customerId") String customerId,
                                                         @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.findByEnterpriseProductIdentifier(siteOrgId, customerId, enterpriseProductIdentifier);
    }

    @GET
    @Path("/findByEnterpriseItemIdentifier")
    public List<Offer> findByEnterpriseItemIdentifier(@QueryParam("siteOrgId") String siteOrgId,
                                                      @QueryParam("customerId") String customerId,
                                                      @QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier) {
        return service.findByEnterpriseItemIdentifier(siteOrgId, customerId, enterpriseItemIdentifier);
    }

    @GET
    @Path("/findBySiteItemIdentifier")
    public List<Offer> findBySiteItemIdentifier(@QueryParam("siteOrgId") String siteOrgId,
                                                @QueryParam("customerId") String customerId,
                                                @QueryParam("siteItemIdentifier") String siteItemIdentifier) {
        return service.findBySiteItemIdentifier(siteOrgId, customerId, siteItemIdentifier);
    }

    @GET
    @Path("/findByNDC")
    public List<Offer> findByNDC(@QueryParam("siteOrgId") String siteOrgId,
                                 @QueryParam("ndc") String ndc) {
        return service.findByNDC(siteOrgId, ndc);
    }

    @GET
    @Path("/findByManufacturerNameAndCatalogNumber")
    public List<Offer> findByManufacturerNameAndCatalogNumber(@QueryParam("siteOrgId") String siteOrgId,
                                                              @QueryParam("manufacturerNm") String manufacturerNm,
                                                              @QueryParam("manufCatNum") String manufCatNum) {
        return service.findByManufacturerNameAndCatalogNumber(siteOrgId, manufacturerNm, manufCatNum);
    }

    @GET
    @Path("/findByManufacturerCatalogNumber")
    public List<Offer> findByManufacturerCatalogNumber(@QueryParam("siteOrgId") String siteOrgId,
                                                       @QueryParam("manufCatNum") String manufCatNum) {
        return service.findByManufacturerCatalogNumber(siteOrgId, manufCatNum);
    }

    @GET
    @Path("/findByMMCId")
    public List<Offer> findByMMCId(@QueryParam("siteOrgId") String siteOrgId,
                                   @QueryParam("mmcId") Integer mmcId) {
        return service.findByMMCId(siteOrgId, mmcId);
    }

    @GET
    @Path("/findBySiteItemId")
    public List<Offer> findBySiteItemId(@QueryParam("siteOrgId") String siteOrgId,
                                        @QueryParam("siteItemId") String siteItemId) {
        return service.findBySiteItemId(siteOrgId, siteItemId);
    }

    @GET
    @Path("/findByProductSeqId")
    public List<Offer> findByProductSeqId(@QueryParam("siteOrgId") String siteOrgId,
                                          @QueryParam("productSeqId") Integer productSeqId) {
        return service.findByProductSeqId(siteOrgId, productSeqId);
    }

    @GET
    @Path("/findRecordById")
    public Offer findRecordById(@QueryParam("id") String id) {
        return service.findRecordById(id);
    }

    @POST
    @Path("/getOffersByEHRSearchCriteria")
    public List<OfferSummary> getOffersByEHRSearchCriteria(EhrSearchCriteria ehrSearchCriteria) {
        return service.getOffersByEHRSearchCriteria(ehrSearchCriteria);
    }

    @POST
    @Path("/addOffersToEHRCatalog")
    public List<Offer> addOffersToEHRCatalog(String[] offerIds) {
        return service.addOffersToEHRCatalog(offerIds);
    }

    @POST
    @Path("/buildOfferFromABiCatalog")
    public Offer buildOfferFromABiCatalog(Offer abiOffer) throws ApplicationException {
        return service.buildOfferFromABiCatalog(abiOffer);
    }

    @GET
    @Path("getEpiDuplicates")
    public List<Document> getEpiDuplicates(@QueryParam("epi") String enterpriseProductId) {
        return service.getEpiDuplicates(enterpriseProductId);
    }

    @POST
    @Path("/getEHREnabledenterpriseProductIdentifierCount")
    public long getEHREnabledenterpriseProductIdentifierCount(List<String> enterpriseProductIdentifiers) {
        return service.getEHREnabledenterpriseProductIdentifierCount(enterpriseProductIdentifiers);
    }

    @GET
    @Path("getPackageUnitList")
    public List<PackageUnit> getPackageUnitList() {
        return service.getPackageUnitList();
    }
}
