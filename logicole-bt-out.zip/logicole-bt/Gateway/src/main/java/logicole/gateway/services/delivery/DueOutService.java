package logicole.gateway.services.delivery;

import logicole.apis.delivery.IDueOutMicroserviceApi;
import logicole.common.datamodels.delivery.DueOut;
import logicole.common.datamodels.inventory.ReplenishmentRecordDTO;
import logicole.common.datamodels.receipt.DueIn;
import logicole.common.datamodels.receipt.DueinRef;
import logicole.common.datamodels.sale.fulfillment.Fulfillment;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.order.OrderService;
import logicole.gateway.services.inventory.LocationService;
import logicole.common.datamodels.inventory.InventorySystem;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class DueOutService extends BaseGatewayService<IDueOutMicroserviceApi> {

    @Inject
    OrderService orderService;

    @Inject
    LocationService locationService;

    public DueOutService() {
        super("Delivery");
    }

    public CurrentUser getCurrentUser() {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        return currentUser;
    }

    //this is created for processing fulfillment on the incoming orders.
    //each customer duein to LOG/CaimSOS will have a fulfillment dueout
    // This is internal dueout and No IOU transaction posted.
    // will be deleted after fulfillment process is completed on the duein.
    public List<DueOut> createFulfillmentDueOut(List<Fulfillment> fulfillmentList) {
        return microservice.createFulfillmentDueOut(fulfillmentList);
    }

    public List<DueOut> getDueOutList(String inventoryOwnerId) {
        InventorySystem system = locationService.getInventorySystemById(inventoryOwnerId);
        String organizationId = "";
        if (system != null) {
            organizationId = system.nodeRef.getId();
        }
        return microservice.getDueOutList(inventoryOwnerId, organizationId);
    }

    public DueOut updateQueuedForPickQuantity(String dueOutId, Integer quantity, Integer backOrderqty) {
        return microservice.updateQueuedForPickQuantity(dueOutId, quantity, backOrderqty);
    }

    public DueOut updatePartialConfirmedQueuedForPickQuantity(String dueOutId, Integer quantity, Boolean discrepancy) {
        return microservice.updatePartialConfirmedQueuedForPickQuantity(dueOutId, quantity, discrepancy);
    }

    public DueOut getDueOutById(String dueOutId) {
        return microservice.getDueOutById(dueOutId);
    }

    public void deleteDueOutById(String dueOutId) {
        microservice.deleteDueOutById(dueOutId);
    }

    public List<DueOut> getDueOutListbyProductId(String productIdentifier, String currentOrgId) {
        return microservice.getDueOutListByProductId(productIdentifier, currentOrgId);
    }

    public List<DueOut> getDueOutBackOrderListByEnterpriseProductIdentifier(String enterpriseProductIdentifier, String inventorySystemId) {
        return microservice.getDueOutBackOrderListByEnterpriseProductIdentifier(enterpriseProductIdentifier, inventorySystemId);
    }

    public List<DueOut> getDueOutListByOrgId(String orgId) {
        return microservice.getDueOutListByOrgId(orgId);
    }

    public Integer getSumBackOrderQuantityByProduct(String productIdentifier, String organizationId) {
        return microservice.getSumBackOrderQuantityByProduct(productIdentifier, organizationId);
    }

    public DueOut updateQueuedForDeliveryQuantity(String dueOutId, Integer quantity, Integer inPickQty) {
        return microservice.updateQueuedForDeliveryQuantity(dueOutId, quantity, inPickQty);
    }

    public List<DueOut> getPassThroughDueOutList(String organizationId) {
        return microservice.getPassThroughDueOutList(organizationId);
    }

    public List<DueOut> getDueOutBackOrderListByOrgId(String orgId) {
        return microservice.getDueOutBackOrderListByOrgId(orgId);
    }

/*    public List<DueOut> getBackOrderedDueOutListByInventorySystem(String enterpriseProductIdentifier, String inventorySystemId) {
        return microservice.getBackOrderedDueOutListByInventorySystem(enterpriseProductIdentifier, inventorySystemId);
    }*/

    public List<DueOut> getDueOutByEnterpriseProductIdentifierAndSystem(String enterpriseProductIdentifier, String inventorySystemId) {
        return microservice.getDueOutByEnterpriseProductIdentifierAndSystem(enterpriseProductIdentifier, inventorySystemId);
    }

    public List<DueOut> getDueOutByEnterpriseProductIdentifierAndSystemAndLocation(String enterpriseProductIdentifier, String inventorySystemId,
                                                                                   String itemLocationIdentifier, String storageLocationId) {
        return microservice.getDueOutByEnterpriseProductIdentifierAndSystemAndLocation(enterpriseProductIdentifier, inventorySystemId, itemLocationIdentifier, storageLocationId);
    }

    //this is created for backOrder dueouts with backOrderIndicator Y.
    //Created from Fulfillment - manage/Auto/confirm picklist. - IOU is created.
    // dueoutQty will be set to Zero when it is processed or BRS.
    public DueOut createDueOut(ReplenishmentRecordDTO replenishmentRecordDTO) {
        if(replenishmentRecordDTO.documentNumber == null) {
            //for backorder dueout use customer duein document number which is populated in replenishmentRecordDTO
            replenishmentRecordDTO.documentNumber = replenishmentRecordDTO.buyerRef.currentNodeRef.nodeIdentifier + orderService.getInternalReferenceId(replenishmentRecordDTO.buyerRef.managedByNodeRef.nodeIdentifier);
        }
        return microservice.createDueOut(replenishmentRecordDTO);
    }

    public DueOut getDueOutByDocumentNumber(String documentNumber, String backOrderInd) {
        return microservice.getDueOutByDocumentNumber(documentNumber, backOrderInd);
    }

    public DueOut updateDueoutQuantity(String dueOutId, Integer quantity) {
        return microservice.updateDueoutQuantity(dueOutId, quantity);
    }

    public List<DueOut> getDueOutListByDueInId(String id) {
        return microservice.getDueOutListByDueInId(id);
    }

    public Integer getSumDueOutQtyByDueinId(String id) {
        return microservice.getSumDueOutQtyByDueinId(id);
    }

    public DueOut updateDueInRefByDueOutId(String dueOutId, DueIn dueIn) {
        return microservice.updateDueInRefByDueOutId(dueOutId, dueIn);
    }

}
