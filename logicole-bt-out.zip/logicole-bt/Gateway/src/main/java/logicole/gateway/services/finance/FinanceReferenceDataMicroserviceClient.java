package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceReferenceDataMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class FinanceReferenceDataMicroserviceClient extends MicroserviceClient<IFinanceReferenceDataMicroserviceApi> {
    public FinanceReferenceDataMicroserviceClient(){
        super(IFinanceReferenceDataMicroserviceApi.class, "logicole-finance");
    }

    @Produces
    public IFinanceReferenceDataMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
