package logicole.gateway.services.slep;


import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.slep.AppUserProfile;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.util.JSONUtil;

import java.io.IOException;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.core.MultivaluedMap;

@RequestScoped
public class SlepHeaderRequestFilter implements ClientRequestFilter {

    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private JSONUtil jsonUtil;

    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {
        
            MultivaluedMap<String,Object> headers = requestContext.getHeaders();

            CurrentUser currentUser = currentUserBT.getCurrentUser();
            String refString = null;

            if (currentUser != null) {
            	AppUserProfile ref = SlepService.convertToAppUserProfile(currentUser.profile);
            	if ( ref != null ) {
	                refString = jsonUtil.serialize(ref);
	                headers.add("SlepCurrentUser", refString);
            	}
            }

    }
  
}
