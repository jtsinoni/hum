package logicole.gateway.services.asset;

import io.swagger.annotations.Api;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.businesscontact.*;
import logicole.common.datamodels.general.Address;
import logicole.common.datamodels.general.BulkUpdateResult;
import logicole.common.datamodels.general.Contact;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.space.cobie.staging.COBieContactImportSummary;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"BusinessContact"})
@ApplicationScoped
@Path("/businessContact")
public class BusinessContactRestApi extends ExternalRestApi<BusinessContactService> {

    @Inject
    private AssetMaintenanceProcedureService assetMaintenanceProcedureService;

    @POST
    @Path("/findContacts")
    public List<BusinessContact> findContacts(@QueryParam("searchString") String searchString,
                                              @QueryParam("specificSkill") String specificSkill,
                                              @QueryParam("specificType") String specificType,
                                              List<String> searchFields) {
        return service.findContacts(searchString, specificSkill, specificType, searchFields);
    }

    @POST
    @Path("/getSearchFields")
    public List<EMenuSelectionFields> getSearchFields(List<String> excludedSearchFields) {
        return service.getSearchFields(excludedSearchFields);
    }

    @GET
    @Path("/getBusinessContactById")
    public BusinessContact getBusinessContactById(@NotNull @QueryParam("id") String id) {
        return service.getBusinessContactById(id);
    }

    @GET
    @Path("/addMaintenanceActivityOutsourcedToBusinessContact")
    public BusinessContact addMaintenanceActivityOutsourcedToBusinessContact(@NotNull @QueryParam("id") String id) {
        return service.addMaintenanceActivityOutsourcedToBusinessContact(id);
    }

    @POST
    @Path("/createNewBusinessContact")
    public BusinessContact createNewBusinessContact(BusinessContact businessContact) {
        return service.createNewBusinessContact(businessContact);
    }

    @POST
    @Path("/saveBusinessContact")
    public BusinessContact saveBusinessContact(BusinessContact businessContact) {
        return service.saveBusinessContact(businessContact);
    }

    @POST
    @Path("/saveBusinessContactInformation")
    public BusinessContact saveBusinessContactInformation(BusinessContact businessContact) {
        return service.saveBusinessContactInformation(businessContact);
    }

    @POST
    @Path("/saveBusinessContactContacts")
    public BusinessContact saveBusinessContactContacts(@QueryParam("businessContactId") String businessContactId, List<Contact> contacts) {
        return service.saveBusinessContactContacts(businessContactId, contacts);
    }

    @POST
    @Path("/saveBusinessContactInformationWithContacts")
    public BusinessContact saveBusinessContactInformationWithContacts(BusinessContact businessContact) {
        return service.saveBusinessContactInformationWithContacts(businessContact);
    }

    @POST
    @Path("/saveBusinessContactAddress")
    public BusinessContact saveBusinessContactAddress(@QueryParam("businessContactId") String businessContactId, Address address) {
        return service.saveBusinessContactAddress(businessContactId, address);
    }

    @POST
    @Path("/saveBusinessContactServices")
    public BusinessContact saveBusinessContactServices(@QueryParam("businessContactId") String businessContactId, List<Services> services) {
        return service.saveBusinessContactServices(businessContactId, services);
    }

    @POST
    @Path("/deleteBusinessContact")
    public void deleteBusinessContact(@QueryParam("id") String id) {
        service.deleteBusinessContact(id);
    }

    @GET
    @Path("/getBusinessContactByName")
    public List<BusinessContact> getBusinessContactByName(@QueryParam("name") String name) {
        return service.getBusinessContactByName(name);
    }

    @POST
    @Path("/getAllBusinessContactsSearch")
    public List<BusinessContactSearch> getAllBusinessContactsSearch(SearchInput searchInput) {
        return service.getAllBusinessContactsSearch(searchInput);
    }

    @POST
    @Path("/getBusinessContactByType")
    public List<BusinessContact> getBusinessContactByType(List<String> types) {
        return service.getBusinessContactByType(types);
    }

    @GET
    @Path("/getAllSkills")
    public List<Skill> getAllSkills() {
        return assetMaintenanceProcedureService.getAllSkills();
    }

    @GET
    @Path("/getBusinessContactBySkill")
    public List<BusinessContact> getBusinessContactBySkill(@QueryParam("skill") String skill) {
        return service.getBusinessContactBySkill(skill);
    }

    @GET
    @Path("/setBusinessContactInActive")
    public BusinessContact setBusinessContactInActive(@QueryParam("id") String id, @QueryParam("status") Boolean status) {
        return service.setBusinessContactInActive(id, status);
    }

    @POST
    @Path("/saveNote")
    public BusinessContact saveNote(@QueryParam("id") String id, Note note) {
        return service.saveNote(id, note);
    }

    @POST
    @Path("/removeNote")
    public BusinessContact removeNote(@QueryParam("id") String id, Note note) {
        return service.removeNote(id, note);
    }

    @GET
    @Path("/getBusinessContactTypes")
    public List<String> getBusinessContactTypes() {
        return service.getBusinessContactTypes();
    }

    @POST
    @Path("/createCOBieContact")
    public BusinessContact createCOBieContact(COBieContactImportSummary cobieContactImportSummary) {
        return service.createCOBieContact(cobieContactImportSummary);
    }

    @POST
    @Path("/createCOBieContacts")
    public BulkUpdateResult createCOBieContacts(List<COBieContactImportSummary> cobieContactImportSummaries) {
        return service.createCOBieContacts(cobieContactImportSummaries);
    }

    @GET
    @Path("/isManagedByNodeRPFuncEnabled")
    public Boolean isManagedByNodeRPFuncEnabled(@QueryParam("nodeId") String nodeId) {
        return service.isManagedByNodeRPFuncEnabled(nodeId);
    }
}

