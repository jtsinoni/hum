package logicole.gateway.services.user;

import logicole.common.cache.CurrentUserCache;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.EUserStatus;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.InvalidCredentialsException;
import logicole.common.general.logging.ILogger;
import logicole.common.general.security.SecurityConstants;
import logicole.common.general.security.token.SystemUserTokenUtil;
import logicole.common.general.security.token.Token;
import logicole.common.general.security.token.TokenUtil;
import logicole.common.general.security.token.TokenValidator;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.string.StringUtil;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.Date;

@ApplicationScoped
public class CurrentUserService {

    @Inject
    private CurrentUserBT currentUserBT;
    @Inject
    private UserService userService;
    @Inject
    private CurrentUserCache cache;
    @Inject
    private TokenValidator tokenValidator;
    @Inject
    private TokenUtil tokenUtil;
    @Inject
    private SystemUserTokenUtil systemUserTokenUtil;
    @Inject
    private JSONUtil jsonUtil;
    @Inject
    private ILogger logger;


    public void setCurrentUserForRequest(String requestUri, String pkiDn, String authHeader, String clientIpAddress)
            throws IOException {

        if (requestUri.equals(SecurityConstants.URI_LOGIN)
                || requestUri.equals(SecurityConstants.URI_GET_LOGICOLE_AUTH_TOKEN)
                || requestUri.equals(SecurityConstants.URI_GET_EHR_LC_AUTH_TOKEN)
                || requestUri.equals(SecurityConstants.URI_GET_MAXIMO_LC_AUTH_TOKEN)
                || requestUri.equals(SecurityConstants.URI_REACHBACK_FROM_DMLSS)) {
            setCurrentUserForLoginRequest(pkiDn, clientIpAddress);
        } else if (SecurityConstants.INVITATION_ENDPOINT_URIS.contains(requestUri)) {
            setCurrentUserForInvitationRequest(pkiDn);

        } else if (SecurityConstants.PKI_DN_RENEW_ENDPOINT_URIS.contains(requestUri)) {
            setCurrentUserForPkiDnUpdateRequest(pkiDn);

        } else if (SecurityConstants.USER_REQUEST_ENDPOINT_URIS.contains(requestUri)) {
            setCurrentUserForUserRequest(pkiDn);
        } else if (requestUri.equals(SecurityConstants.URI_GET_SSO_SAP_TEWLS_AUTH_TOKEN)
                || requestUri.equals(SecurityConstants.URI_GET_SSO_SAP_TEWLS_URL)) {
            setCurrentUserForSsoSapTewlsRequest(pkiDn);
        }
        else {
            setCurrentUserForStandardRequest(pkiDn, authHeader);
        }
    }

    private void setCurrentUserForInvitationRequest(String pkiDn) {
        try {
            // Set currentUserBt to temporary Login user so we can make initial call to userService.
            CurrentUser loginUser = getTemporaryLoginUser(pkiDn);
            // Add all endpoints for CAC renew to temporary profile
            loginUser.effectiveEndpoints.addAll(SecurityConstants.INVITATION_ENDPOINTS);
            String loginUserJwtString = systemUserTokenUtil.getJwtForSystemUserProfile(
                    SecurityConstants.LOGIN_SPECIAL_USER_PROFILE_KEY, pkiDn);

            currentUserBT.setCurrentUser(loginUser);
            currentUserBT.setJsonWebToken(loginUserJwtString);
            currentUserBT.setAlreadySecure(false);

        } finally { // Just in case something went wrong, make sure currentUserBt gets set to false
            currentUserBT.setAlreadySecure(false);
        }
    }

    private void setCurrentUserForUserRequest(String pkiDn) {
        try {
            // Set currentUserBt to temporary Login user so we can make initial call to userRequestService.
            CurrentUser loginUser = getTemporaryLoginUser(pkiDn);
            // Add all endpoints for CAC renew to temporary profile
            loginUser.effectiveEndpoints.addAll(SecurityConstants.USER_REQUEST_ENDPOINTS);
            String loginUserJwtString = systemUserTokenUtil.getJwtForSystemUserProfile(
                    SecurityConstants.LOGIN_SPECIAL_USER_PROFILE_KEY, pkiDn);

            currentUserBT.setCurrentUser(loginUser);
            currentUserBT.setJsonWebToken(loginUserJwtString);
            currentUserBT.setAlreadySecure(false);

        } finally { // Just in case something went wrong, make sure currentUserBt gets set to false
            currentUserBT.setAlreadySecure(false);
        }
    }

    private void setCurrentUserForLoginRequest(String pkiDn, String clientIpAddress) throws IOException {

        try {
            // Set currentUserBt to temporary Login user so we can make initial call to userService.
            CurrentUser loginUser = getTemporaryLoginUser(pkiDn);
            // Add all login-related endpoints to temporary profile
            loginUser.effectiveEndpoints.addAll(SecurityConstants.LOGIN_ENDPOINTS);
            String loginUserJwtString = systemUserTokenUtil.getJwtForSystemUserProfile(
                    SecurityConstants.LOGIN_SPECIAL_USER_PROFILE_KEY, pkiDn);

            currentUserBT.setCurrentUser(loginUser);
            currentUserBT.setJsonWebToken(loginUserJwtString);
            currentUserBT.setAlreadySecure(false);

            // Make initial call to userService to get the true, actual user
            CurrentUser actualUser = userService.getCurrentUserByPkiDn(pkiDn);

            if (actualUser != null && actualUser.profile.userProfileStatus.equals(EUserStatus.ACTIVE.toString())) {
                // True/Actual user is now populated...generate JsonWebToken, set currentUserBt appropriately
                String actualUserJwtString =
                        tokenUtil.generateJsonWebToken(pkiDn, actualUser.profile.getId(), SecurityConstants.CLIENT_ID_LOGICOLE);

                // Update the lastLogin fields in the actual UserProfile
                actualUser.profile = userService.setUserLoginIpAndDate(actualUser.profile.getId(), clientIpAddress, new Date());

                currentUserBT.setCurrentUser(actualUser);
                currentUserBT.setJsonWebToken(actualUserJwtString);
                currentUserBT.setAlreadySecure(false);

                putCurrentUserIntoCache(actualUserJwtString, actualUser, cache.getLifespanMillis());
            }

        } finally { // Just in case something went wrong, make sure currentUserBt gets set to false
            currentUserBT.setAlreadySecure(false);
        }
    }

    private void setCurrentUserForPkiDnUpdateRequest(String pkiDn) {

        try {
            // Set currentUserBt to temporary Login user for request to update Pki Dn
            CurrentUser loginUser = getTemporaryLoginUser(pkiDn);

            // Add all endpoints for CAC renew to temporary profile
            loginUser.effectiveEndpoints.addAll(SecurityConstants.PKI_DN_RENEW_ENDPOINTS);
            String loginUserJwtString = systemUserTokenUtil.getJwtForSystemUserProfile(
                    SecurityConstants.LOGIN_SPECIAL_USER_PROFILE_KEY, pkiDn);

            currentUserBT.setCurrentUser(loginUser);
            currentUserBT.setJsonWebToken(loginUserJwtString);
            currentUserBT.setAlreadySecure(false);

        } finally { // Just in case something went wrong, make sure currentUserBt gets set back to false
            currentUserBT.setAlreadySecure(false);
        }
    }

    private void setCurrentUserForStandardRequest(@NotNull String pkiDn, @NotNull String authHeader) throws IOException {

        try {
            String actualUserJwtString = tokenUtil.stripPrefixFromJsonWebToken(authHeader);
            CurrentUser actualUser;

            if (cache.exists(actualUserJwtString)) {
                String actualUserString = cache.getObject(actualUserJwtString);
                actualUser = jsonUtil.deserialize(actualUserString, CurrentUser.class);
            } else if (tokenValidator.jwtIsValidAndCurrent(actualUserJwtString, SecurityConstants.CLIENT_ID_LOGICOLE)) {
                // JWT is not in the cache, but it is valid and current.
                logger.info("JsonWebToken is valid but not in the currentUserBtCache. Will attempt to reload.");

                // Grab correct userProfileId from the JWT, use it to call userService to get user info
                Token actualUserToken = tokenUtil.parseJwt(actualUserJwtString, SecurityConstants.CLIENT_ID_LOGICOLE);

                // Set currentUserBt to temp Login user so we can call UserService to get actual User info.
                if (!StringUtil.isEmptyOrNull(pkiDn)) {
                    CurrentUser loginUser = getTemporaryLoginUser(pkiDn);
                    // Add all login-related endpoints to temporary profile
                    loginUser.effectiveEndpoints.addAll(SecurityConstants.LOGIN_ENDPOINTS);
                    String loginUserJwtString = systemUserTokenUtil.getJwtForSystemUserProfile(
                            SecurityConstants.LOGIN_SPECIAL_USER_PROFILE_KEY, pkiDn);

                    currentUserBT.setCurrentUser(loginUser);
                    currentUserBT.setJsonWebToken(loginUserJwtString);
                    currentUserBT.setAlreadySecure(false);

                    actualUser = userService.getCurrentUserByPkiDn(pkiDn);
                } else {
                    actualUser = userService.getCurrentUserByProfileId(actualUserToken.getUserProfileId());
                }

                long cacheLifespanMillis = tokenUtil.calcProperCacheEntryLifespan(actualUserToken, cache.getLifespanMillis());
                putCurrentUserIntoCache(actualUserJwtString, actualUser, cacheLifespanMillis);
            } else {
                throw new InvalidCredentialsException("Invalid or expired JsonWebToken");
            }

            currentUserBT.setCurrentUser(actualUser);
            currentUserBT.setJsonWebToken(actualUserJwtString);
            currentUserBT.setAlreadySecure(false);

        } finally { // Just in case something went wrong, make sure currentUserBt gets set to false
            currentUserBT.setAlreadySecure(false);
        }
    }

    private void setCurrentUserForSsoSapTewlsRequest(String pkiDn) {
        try {
            // Set currentUserBt to temporary Login user so we can make initial call to userService.
            CurrentUser loginUser = getTemporaryLoginUser(pkiDn);
            // Add all endpoints for tewls to temporary profile
            loginUser.effectiveEndpoints.addAll(SecurityConstants.SSO_ENDPOINTS);
            String loginUserJwtString = systemUserTokenUtil.getJwtForSystemUserProfile(
                    SecurityConstants.LOGIN_SPECIAL_USER_PROFILE_KEY, pkiDn);

            currentUserBT.setCurrentUser(loginUser);
            currentUserBT.setJsonWebToken(loginUserJwtString);
            currentUserBT.setAlreadySecure(false);

        } finally { // Just in case something went wrong, make sure currentUserBt gets set to false
            currentUserBT.setAlreadySecure(false);
        }
    }

    private CurrentUser getTemporaryLoginUser(String pkiDn) {

        CurrentUser loginUser = new CurrentUser();
        loginUser.profile = new UserProfile();
        loginUser.profile.pkiDn = pkiDn;
        OrganizationRef orgRef = new OrganizationRef();
        orgRef.ancestry = "";
        loginUser.profile.currentNodeRef = orgRef;

        loginUser.profile.firstName = SecurityConstants.LOGIN_SPECIAL_USER_PROFILE_FIRST_NAME;
        loginUser.profile.lastName = SecurityConstants.LOGIN_SPECIAL_USER_PROFILE_LAST_NAME;
        return loginUser;
    }

    private CurrentUser getTemporaryLoginUser() {
        return getTemporaryLoginUser(SecurityConstants.LOGIN_SPECIAL_USER_PROFILE_KEY);
    }

    private void putCurrentUserIntoCache(String jsonWebToken, CurrentUser currentUser, long cacheLifespanMillis)
            throws IOException {

        String currentUserJsonString = jsonUtil.serialize(currentUser);
        cache.putObject(jsonWebToken, currentUserJsonString, cacheLifespanMillis);
    }

}
