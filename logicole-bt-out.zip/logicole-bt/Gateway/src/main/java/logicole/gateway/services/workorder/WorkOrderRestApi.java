package logicole.gateway.services.workorder;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.businesscontact.BusinessContact;
import logicole.common.datamodels.asset.businesscontact.BusinessContactRef;
import logicole.common.datamodels.asset.businesscontact.BusinessContactSearch;
import logicole.common.datamodels.asset.businesscontact.Skill;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceCodeRef;
import logicole.common.datamodels.asset.maintenance.procedure.RegulatoryComplianceSubject;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.AssetSummary;
import logicole.common.datamodels.asset.schedule.Schedule;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.general.EActiveStatus;
import logicole.common.datamodels.general.customfield.CustomFieldValue;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.realproperty.Installation;
import logicole.common.datamodels.realproperty.RealPropertyFundingNodeSummary;
import logicole.common.datamodels.realproperty.Site;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.realproperty.facility.FacilitySummary;
import logicole.common.datamodels.realpropertyproject.Requirement;
import logicole.common.datamodels.realpropertyproject.project.RealPropertyProject;
import logicole.common.datamodels.realpropertysection.Section;
import logicole.common.datamodels.realpropertysection.SectionSummary;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.report.ExportFileInfo;
import logicole.common.datamodels.space.Floor;
import logicole.common.datamodels.space.FloorPlanLegendEntry;
import logicole.common.datamodels.space.GraphicalSearchRecord;
import logicole.common.datamodels.space.OccupantRef;
import logicole.common.datamodels.space.RoomMetadata;
import logicole.common.datamodels.space.RoomRelatedRecordCounts;
import logicole.common.datamodels.space.RoomSummary;
import logicole.common.datamodels.space.Zone;
import logicole.common.datamodels.space.ZoneRef;
import logicole.common.datamodels.space.lookupdata.FloorPlanLayer;
import logicole.common.datamodels.system.TagRef;
import logicole.common.datamodels.system.frequency.FrequencyRef;
import logicole.common.datamodels.workflow.WorkflowDefinition;
import logicole.common.datamodels.workflow.WorkflowStepSummary;
import logicole.common.datamodels.workorder.ActualCost;
import logicole.common.datamodels.workorder.Assignment;
import logicole.common.datamodels.workorder.AssignmentEstimateResult;
import logicole.common.datamodels.workorder.ClassificationType;
import logicole.common.datamodels.workorder.CmmsError;
import logicole.common.datamodels.workorder.CmmsErrorSearchCriteria;
import logicole.common.datamodels.workorder.CmmsErrorType;
import logicole.common.datamodels.workorder.CmmsExpenseCenter;
import logicole.common.datamodels.workorder.CmmsExpenseCenterRef;
import logicole.common.datamodels.workorder.Comment;
import logicole.common.datamodels.workorder.CostSummary;
import logicole.common.datamodels.workorder.CostumerComplaintRecordForm;
import logicole.common.datamodels.workorder.DaForm4283Form;
import logicole.common.datamodels.workorder.EnvironmentalImpactSummary;
import logicole.common.datamodels.workorder.FloorRooms;
import logicole.common.datamodels.workorder.Impact;
import logicole.common.datamodels.workorder.ImpactReason;
import logicole.common.datamodels.workorder.ImpactType;
import logicole.common.datamodels.workorder.LaborRateFactor;
import logicole.common.datamodels.workorder.LegacyWorkRequestStatusHistory;
import logicole.common.datamodels.workorder.Navfac9WorkRequestForm;
import logicole.common.datamodels.workorder.NonCatalogPart;
import logicole.common.datamodels.workorder.PartOption;
import logicole.common.datamodels.workorder.PreventativeMaintenanceWorkOrderForm;
import logicole.common.datamodels.workorder.PriorityGroup;
import logicole.common.datamodels.workorder.SeverityRef;
import logicole.common.datamodels.workorder.Standards;
import logicole.common.datamodels.workorder.UnscheduledWorkRequestForm;
import logicole.common.datamodels.workorder.WorkLoadSearchCriteria;
import logicole.common.datamodels.workorder.WorkLoadSummary;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.datamodels.workorder.WorkOrderDashboardInfo;
import logicole.common.datamodels.workorder.WorkOrderHistory;
import logicole.common.datamodels.workorder.WorkOrderLegacyAssociationResult;
import logicole.common.datamodels.workorder.WorkOrderReport;
import logicole.common.datamodels.workorder.WorkOrderRequirementMigrationResult;
import logicole.common.datamodels.workorder.WorkOrderSurvey;
import logicole.common.datamodels.workorder.WorkOrderType;
import logicole.common.datamodels.workorder.bulk.BulkResponse;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;

@Api(tags = {"WorkOrder"})
@ApplicationScoped
@Path("/workOrder")
public class WorkOrderRestApi extends ExternalRestApi<WorkOrderService> {

    @Inject
    private MultiPartFormUtil uploadUtil;

    @GET
    @Path("/findById")
    public WorkOrder findById(@QueryParam("id") String id) {
        return service.findById(id);
    }

    @POST
    @Path("/findByIds")
    public List<WorkOrder> findByIds(List<String> ids) {
        return service.findByIds(ids);
    }

    @GET
    @Path("/getWorkOrderCountInSpace")
    public long getWorkOrderCountInSpace(@QueryParam("spaceId") String spaceId, @QueryParam("spaceIdentifier") String spaceIdentifier) {
        return service.getWorkOrderCountInSpace(spaceId, spaceIdentifier);
    }

    @POST
    @Path("/addPriorityGroup")
    public PriorityGroup addPriorityGroup(PriorityGroup priorityGroup) {
        return service.addPriorityGroup(priorityGroup);
    }

    @POST
    @Path("/updatePriorityGroup")
    public PriorityGroup updatePriorityGroup(PriorityGroup priorityGroup) {
        return service.updatePriorityGroup(priorityGroup);
    }

    @POST
    @Path("/deletePriorityGroup")
    public void deletePriorityGroup(PriorityGroup priorityGroup) {
        service.deletePriorityGroup(priorityGroup);
    }

    @GET
    @Path("/getActivePriorityGroups")
    public List<PriorityGroup> getActivePriorityGroups() {
        return service.getActivePriorityGroups();
    }

    @GET
    @Path("/getHigherPriorityGroups")
    public List<PriorityGroup> getHigherPriorityGroups(@NotNull @QueryParam("priority") Integer priority) {
        return service.getHigherPriorityGroups(priority);
    }

    @GET
    @Path("/getLowerPriorityGroups")
    public List<PriorityGroup> getLowerPriorityGroups(@NotNull @QueryParam("priority") Integer priority) {
        return service.getLowerPriorityGroups(priority);
    }

    @GET
    @Path("/getActiveSeverityRefs")
    public List<SeverityRef> getActiveSeverityRefs() {
        return service.getActiveSeverityRefs();
    }

    @GET
    @Path("/buildWorkflowFromLegacyWorkflowHistories")
    public WorkOrder buildWorkflowFromLegacyWorkflowHistories(@NotNull @QueryParam("workOrderId") String workOrderId) {
        return service.buildWorkflowFromLegacyWorkflowHistories(workOrderId);
    }

    @POST
    @Path("/addNote")
    public WorkOrder addNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.addNote(id, note);
    }

    @POST
    @Path("/saveNote")
    public WorkOrder saveNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.saveNote(id, note);
    }

    @POST
    @Path("/removeNote")
    public WorkOrder removeNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.removeNote(id, note);
    }

    @POST
    @Path("/addClassificationType")
    public ClassificationType addClassificationType(ClassificationType classificationType) {
        return service.addClassificationType(classificationType);
    }

    @POST
    @Path("/updateClassificationType")
    public ClassificationType updateClassificationType(ClassificationType classificationType) {
        return service.updateClassificationType(classificationType);
    }

    @POST
    @Path("/deleteClassificationType")
    public void deleteClassificationType(ClassificationType classificationType) {
        service.deleteClassificationType(classificationType);
    }

    @GET
    @Path("/getActiveClassificationTypes")
    public List<ClassificationType> getActiveClassificationTypes() {
        return service.getActiveClassificationTypes();
    }

    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadFile(
            @ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        InputStream inputStream;
        byte[] content;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new FatalProcessingException(
                    "Was not able to extract file from request " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxUploadSize();

        if (content.length > maxUploadSize) {
            throw new FatalProcessingException(
                    "Uploaded file size exceeds server max POST Size value  of " + maxUploadSize
                            + " bytes");
        }

        return service.uploadFile(content, uploadedFileName);
    }

    @POST
    @Path("/uploadFileWithCustomValues")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file with custom uploadedByUserId and uploadedDateTime. Example dateTime format: Sat Jun 14 2019 03:55:07")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "Select a file to upload",
                    dataType = "java.io.File", name = "file",
                    paramType = "formData", required = true)
    })
    public FileManager uploadFileWithCustomValues(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form,
                                                  @QueryParam("uploadedByUserId") String uploadedByUserId,
                                                  @QueryParam("uploadedDateTime") Date uploadedDateTime) {
        byte[] content;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            InputStream inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new ApplicationException("Unable to upload file " + uploadedFileName);
        }
        Integer maxUploadSize = service.getMaxUploadSize();
        if (content.length > maxUploadSize) {
            throw new ApplicationException("File size exceeds max size of " + maxUploadSize + " bytes");
        }

        return service.uploadFileWithCustomValues(content, uploadedFileName, uploadedByUserId, uploadedDateTime);
    }

    @GET
    @Path("/getMaxUploadSize")
    public Integer getMaxUploadSize() {
        return service.getMaxUploadSize();
    }

    @POST
    @Path("/saveAttachment")
    public Attachment saveAttachment(@QueryParam("id") String id, Attachment attachmentToSave) {
        return service.saveAttachment(id, attachmentToSave);
    }

    @GET
    @Path("/removeAttachment")
    public List<Attachment> removeAttachment(@QueryParam("id") String id, @QueryParam("fileId") String fileId)
            throws IOException {
        return service.removeAttachment(id, fileId);
    }

    @GET
    @Path("/getNotes")
    public List<Note> getNotes(@NotNull @QueryParam("id") String id) {
        return service.getNotes(id);
    }

    @GET
    @Path("/getAllCustomFieldValues")
    public List<CustomFieldValue> getAllCustomFieldValues(@QueryParam("id") String id) {
        return service.getAllCustomFieldValues(id);
    }

    @POST
    @Path("/saveCustomFieldValues")
    public List<CustomFieldValue> saveCustomFieldValues(@QueryParam("id") String id, List<CustomFieldValue> customFieldValues) {
        return service.saveCustomFieldValues(id, customFieldValues);
    }

    @GET
    @Path("/getWorkOrderTags")
    public List<TagRef> getWorkOrderTags() {
        return service.getWorkOrderTags();
    }

    @POST
    @Path("/saveWorkOrderTags")
    public List<TagRef> saveWorkOrderTags(@QueryParam("id") String id, List<TagRef> tagRefList) {
        return service.saveWorkOrderTags(id, tagRefList);
    }

    @POST
    @Path("/getWorkOrders")
    public SearchResult<WorkOrder> getWorkOrders(SearchInput searchInput) {
        return service.getWorkOrders(searchInput);
    }

    @GET
    @Path("/getCmmsErrorTypes")
    public List<CmmsErrorType> getCmmsErrorTypes() {
        return service.getCmmsErrorTypes();
    }

    @POST
    @Path("/getCmmsErrors")
    public List<CmmsError> getCmmsErrors(CmmsErrorSearchCriteria cmmsErrorSearchCriteria) {
        return service.getCmmsErrors(cmmsErrorSearchCriteria);
    }

    @GET
    @Path("/deleteCmmsError")
    public void deleteCmmsError(@NotNull @QueryParam("cmmsErrorId") String cmmsErrorId) {
        service.deleteCmmsError(cmmsErrorId);
    }

    @GET
    @Path("/getWorkOrderHistoryByAssetId")
    public List<WorkOrderHistory> getWorkOrderHistoryByAssetId(@NotNull @QueryParam("assetId") String assetId,
                                                               @NotNull @QueryParam("includeScheduled") Boolean includeScheduled,
                                                               @NotNull @QueryParam("includeUnscheduled") Boolean includeUnscheduled) {
        return service.getWorkOrderHistoryByAssetId(assetId, includeScheduled, includeUnscheduled);
    }

    @GET
    @Path("/getAssignmentsForWorkOrder")
    public List<Assignment> getAssignmentsForWorkOrder(@NotNull @QueryParam("id") String id) {
        return service.getAssignmentsForWorkOrder(id);
    }

    @POST
    @Path("/createWorkOrder")
    public WorkOrder createWorkOrder(WorkOrder workOrder,
                                     @DefaultValue("true") @QueryParam("startWorkflow") boolean startWorkflow) {
        return service.createWorkOrder(workOrder, startWorkflow);
    }

    @POST
    @Path("/updateWorkOrderDetails")
    public WorkOrder updateWorkOrderDetails(WorkOrder workOrder) {
        return service.updateWorkOrderDetails(workOrder);
    }

    @POST
    @Path("/updateWorkOrderRequester")
    public WorkOrder updateWorkOrderRequester(WorkOrder workOrder) {
        return service.updateWorkOrderRequester(workOrder);
    }

    @POST
    @Path("/updateWorkOrderLocation")
    public WorkOrder updateWorkOrderLocation(WorkOrder workOrder) {
        return service.updateWorkOrderLocation(workOrder);
    }

    @POST
    @Path("/updateSpaceDetails")
    public WorkOrder updateSpaceDetails(WorkOrder workOrder) {
        return service.updateSpaceDetails(workOrder);
    }

    @POST
    @Path("/updateZones")
    public WorkOrder updateZones(WorkOrder workOrder) {
        return service.updateZones(workOrder);
    }

    @POST
    @Path("/updateSpaces")
    public WorkOrder updateSpaces(WorkOrder workOrder) {
        return service.updateSpaces(workOrder);
    }

    @POST
    @Path("/updateEstimatedCosts")
    public WorkOrder updateEstimatedCosts(@QueryParam("workOrderId") String workOrderId, CostSummary costSummary) {
        return service.updateEstimatedCosts(workOrderId, costSummary);
    }

    @POST
    @Path("/addAssignment")
    public WorkOrder addAssignment(@NotNull @QueryParam("workOrderId") String workOrderId, Assignment assignment) {
        return service.addAssignment(workOrderId, assignment);
    }

    @POST
    @Path("/saveAssignment")
    public WorkOrder saveAssignment(@NotNull @QueryParam("workOrderId") String workOrderId, Assignment assignment) {
        return service.saveAssignment(workOrderId, assignment);
    }

    @POST
    @Path("/removeAssignment")
    public WorkOrder removeAssignment(@NotNull @QueryParam("workOrderId") String workOrderId, Assignment assignment) {
        return service.removeAssignment(workOrderId, assignment);
    }

    @GET
    @Path("/getStandardsForWorkOrder")
    public List<Standards> getStandardsForWorkOrder(@NotNull @QueryParam("workOrderId") String workOrderId) {
        return service.getStandardsForWorkOrder(workOrderId);
    }

    @GET
    @Path("/getRegulatoryComplianceCodeRefs")
    public List<RegulatoryComplianceCodeRef> getRegulatoryComplianceCodeRefs() {
        return service.getRegulatoryComplianceCodeRefs();
    }

    @GET
    @Path("/getRegulatoryComplianceSubjects")
    public List<RegulatoryComplianceSubject> getRegulatoryComplianceSubjects() {
        return service.getRegulatoryComplianceSubjects();
    }

    @POST
    @Path("/addStandard")
    public WorkOrder addStandard(@NotNull @QueryParam("workOrderId") String workOrderId, Standards standards) {
        return service.addStandard(workOrderId, standards);
    }

    @POST
    @Path("/saveStandard")
    public WorkOrder saveStandard(@NotNull @QueryParam("workOrderId") String workOrderId, Standards standards) {
        return service.saveStandard(workOrderId, standards);
    }

    @POST
    @Path("/removeStandard")
    public WorkOrder removeStandard(@NotNull @QueryParam("workOrderId") String workOrderId, Standards standards) {
        return service.removeStandard(workOrderId, standards);
    }

    @GET
    @Path("/getWorkflowByName")
    public WorkflowDefinition getWorkflowByName(@QueryParam("name") String name) {
        return service.getWorkflowByName(name);
    }

    @GET
    @Path("/startScheduled")
    public WorkOrder startScheduled(@QueryParam("id") String id) {
        return service.startScheduled(id);
    }

    @GET
    @Path("/openScheduled")
    public WorkOrder openScheduled(@QueryParam("id") String id) {
        return service.openScheduled(id);
    }

    @GET
    @Path("/startUnscheduled")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021")
    public WorkOrder startUnscheduled(@NotNull @QueryParam("id") String id, @QueryParam("customDate") Date customDate) {
        return customDate == null ? service.startUnscheduled(id) : service.startUnscheduled(id, customDate);
    }

    @POST
    @Path("/updateEnvironmentalImpacts")
    public WorkOrder updateEnvironmentalImpacts(@NotNull @QueryParam("workOrderId") String workOrderId,
                                                EnvironmentalImpactSummary environmentalImpactSummary) {
        return service.updateEnvironmentalImpacts(workOrderId, environmentalImpactSummary);
    }

    @GET
    @Path("/getAssetSummariesByFacilityId")
    public List<AssetSummary> getAssetSummariesByFacilityId(@QueryParam("facilityId") String facilityId, @QueryParam("activeStatus") EActiveStatus activeStatus) {
        return service.getAssetSummariesByFacilityId(facilityId, activeStatus);
    }

    @GET
    @Path("/getCountByPriorityGroupAndScope")
    public long getCountByPriorityGroupAndScope(@NotNull @QueryParam("priorityGroupId") String priorityGroupId,
                                                @NotNull @QueryParam("scopeOrgId") String scopeOrgId) {
        return service.getCountByPriorityGroupAndScope(priorityGroupId, scopeOrgId);
    }

    @GET
    @Path("/getCountByClassificationTypeAndScope")
    public long getCountByClassificationTypeAndScope(@NotNull @QueryParam("classificationTypeId") String classificationTypeId,
                                                     @NotNull @QueryParam("scopeOrgId") String scopeOrgId) {
        return service.getCountByClassificationTypeAndScope(classificationTypeId, scopeOrgId);
    }

    @GET
    @Path("/updateImpactReason")
    public ImpactReason updateImpactReason(@NotNull @QueryParam("id") String id, @NotNull @QueryParam("name") String name) {
        return service.updateImpactReason(id, name);
    }

    @POST
    @Path("/deleteImpactReason")
    public void deleteImpactReason(ImpactReason impactReason) {
        service.deleteImpactReason(impactReason);
    }

    @GET
    @Path("/updateImpactType")
    public ImpactType updateImpactType(@NotNull @QueryParam("id") String id, @NotNull @QueryParam("name") String name) {
        return service.updateImpactType(id, name);
    }

    @POST
    @Path("/deleteImpactType")
    public void deleteImpactType(ImpactType impactType) {
        service.deleteImpactType(impactType);
    }

    @GET
    @Path("/getImpactTypes")
    public List<ImpactType> getImpactTypes() {
        return service.getImpactTypes();
    }

    @GET
    @Path("/getImpactReasons")
    public List<ImpactReason> getImpactReasons() {
        return service.getImpactReasons();
    }

    @POST
    @Path("/addImpact")
    public WorkOrder addImpact(@NotNull @QueryParam("id") String id, Impact impact) {
        return service.addImpact(id, impact);
    }

    @POST
    @Path("/saveImpact")
    public WorkOrder saveImpact(@NotNull @QueryParam("id") String id, Impact impact) {
        return service.saveImpact(id, impact);
    }

    @POST
    @Path("/removeImpact")
    public WorkOrder removeImpact(@NotNull @QueryParam("id") String id, Impact impact) {
        return service.removeImpact(id, impact);
    }

    @POST
    @Path("/addComment")
    public WorkOrder addComment(@NotNull @QueryParam("id") String id, Comment comment) {
        return service.addComment(id, comment);
    }

    @POST
    @Path("/removeComment")
    public WorkOrder removeComment(@NotNull @QueryParam("id") String id, Comment comment) {
        return service.removeComment(id, comment);
    }

    @POST
    @Path("/saveComment")
    public WorkOrder saveComment(@NotNull @QueryParam("id") String id, Comment comment) {
        return service.saveComment(id, comment);
    }

    @POST
    @Path("/buildWorkflowStepSummary")
    public List<WorkflowStepSummary> buildWorkflowStepSummary(WorkOrder workOrder) {
        return service.buildWorkflowStepSummary(workOrder);
    }

    @POST
    @Path("/generateUnscheduledWorkRequestForm")
    @ApiOperation(value = "Gets a Unscheduled Work Request form for given Work Orders")
    public List<UnscheduledWorkRequestForm> generateUnscheduledWorkRequestFormData(List<String> workOrderIds, @QueryParam("isWithActions") boolean isWithActions, @QueryParam("isWithEquipment") boolean isWithEquipment) {
        return service.generateUnscheduledWorkRequestForm(workOrderIds, isWithActions, isWithEquipment);
    }

    @POST
    @Path("/generatePreventativeMaintenanceWorkRequestForm")
    @ApiOperation(value = "Gets a Preventative Maintenance Work Request form for given Work Orders")
    public List<PreventativeMaintenanceWorkOrderForm> generatePreventativeMaintenanceWorkRequestForm(WorkOrderReport workOrderReport) {
        return service.generatePreventativeMaintenanceWorkRequestForm(workOrderReport);
    }

    @POST
    @Path("/generateNavfac9WorkRequestForm")
    @ApiOperation(value = "Gets a NAVFAC 9 Work Request form for given Work Orders")
    public List<Navfac9WorkRequestForm> generateNavfac9WorkRequestForm(List<String> workOrderIds) {
        return service.generateNavfac9WorkRequestForm(workOrderIds);
    }

    @POST
    @Path("/generateCustomerComplaintRecordForm")
    @ApiOperation(value = "Gets a Customer Complaint Record form for given Work Orders")
    public List<CostumerComplaintRecordForm> generateCustomerComplaintRecordForm(List<String> workOrderIds) {
        return service.generateCustomerComplaintRecordForm(workOrderIds);
    }

    @POST
    @Path("/generateDaForm4283Form")
    @ApiOperation(value = "Generates the data for the DA 4283 Form")
    public List<DaForm4283Form> generateDaForm4283Form(List<String> workOrderIds) {
        return service.generateDaForm4283Form(workOrderIds);
    }

    @POST
    @Path("/generateWorkLoadSummaryForm")
    @ApiOperation(value = "Generates a Work Load Summary report for given Work Orders")
    public Response generateWorkLoadSummaryForm(List<String> workOrderIds) {
        ExportFileInfo destFileInfo = service.generateWorkLoadSummaryForm(workOrderIds);
        Response.ResponseBuilder response;

        if (destFileInfo != null) {
            response = Response.ok()
                    .header("Content-Disposition", "attachment; filename=" + destFileInfo.exportFileName)
                    .header("Content-Length", destFileInfo.contentSize)
                    .header("Content-Encoding", StandardCharsets.UTF_8)
                    .header("Access-Control-Expose-Headers", "Content-Disposition,Content-Type")
                    .header("Content-Type", destFileInfo.contentType);
            response.entity(ArrayUtils.toPrimitive(destFileInfo.fileContent));
        } else {
            response = Response.status(Response.Status.NOT_FOUND);
        }

        return response.build();
    }

    @GET
    @Path("/getZonesByFacilityId")
    public List<Zone> getZonesByFacilityId(@NotNull @QueryParam("facilityId") String facilityId) {
        return service.getZonesByFacilityId(facilityId);
    }

    @GET
    @Path("/getZoneRefsByFacilityId")
    public List<ZoneRef> getZoneRefsByFacilityId(@NotNull @QueryParam("facilityId") String facilityId) {
        return service.getZoneRefsByFacilityId(facilityId);
    }

    @POST
    @Path("/getZonesByIds")
    public List<Zone> getZonesByIds(@NotNull List<String> zoneIds) {
        return service.getZonesByIds(zoneIds);
    }

    @GET
    @Path("/getWorkOrderFacilityFloorsAndRooms")
    public List<FloorRooms> getWorkOrderFacilityFloorsAndRooms(@NotNull @QueryParam("workOrderId") String workOrderId) {
        return service.getWorkOrderFacilityFloorsAndRooms(workOrderId);
    }

    @POST
    @Path("/sendForReview")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021")
    public WorkOrder sendForReview(WorkOrder workOrder, @QueryParam("customDate") Date customDate) {
        return customDate == null ? service.sendForReview(workOrder) : service.sendForReview(workOrder, customDate);
    }

    @POST
    @Path("/elevatePriority")
    public WorkOrder elevatePriority(WorkOrder workOrder) {
        return service.elevatePriority(workOrder);
    }

    @POST
    @Path("/downgradePriority")
    public WorkOrder downgradePriority(WorkOrder workOrder) {
        return service.downgradePriority(workOrder);
    }

    @POST
    @Path("/complete")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021")
    public WorkOrder complete(WorkOrder workOrder, @QueryParam("customDate") Date customDate) {
        return customDate == null ? service.complete(workOrder) : service.complete(workOrder, customDate);
    }

    @POST
    @Path("/cancel")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021")
    public WorkOrder cancel(WorkOrder workOrder, @QueryParam("customDate") Date customDate) {
        return customDate == null ? service.cancel(workOrder) : service.cancel(workOrder, customDate);
    }

    @POST
    @Path("/accept")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021. Set workflowOnly to true if not actually closing assoc. Requirements, only handling Workflow steps.")
    public WorkOrder accept(WorkOrder workOrder,
                            @QueryParam("customDate") Date customDate,
                            @DefaultValue("false") @QueryParam("workflowOnly") boolean workflowOnly) {
        return customDate == null ? service.accept(workOrder) : service.accept(workOrder, customDate, workflowOnly);
    }

    @GET
    @Path("/getActiveWorkOrderTypes")
    public List<WorkOrderType> getActiveWorkOrderTypes() {
        return service.getActiveWorkOrderTypes();
    }

    @POST
    @Path("/updateWorkOrderType")
    public WorkOrderType updateWorkOrderType(WorkOrderType workOrderType) {
        return service.updateWorkOrderType(workOrderType);
    }

    @POST
    @Path("/createWorkOrderType")
    public WorkOrderType createWorkOrderType(WorkOrderType workOrderType) {
        return service.createWorkOrderType(workOrderType);
    }

    @GET
    @Path("/deleteWorkOrderType")
    public boolean deleteWorkOrderType(@QueryParam("WorkOrderTypeId") String id) {
        return service.deleteWorkOrderType(id);
    }


    @POST
    @Path("/addNonCatalogPart")
    public WorkOrder addNonCatalogPart(@NotNull @QueryParam("id") String id, NonCatalogPart nonCatalogPart) {
        return service.addNonCatalogPart(id, nonCatalogPart);
    }

    @POST
    @Path("/updateNonCatalogPart")
    public WorkOrder updateNonCatalogPart(@NotNull @QueryParam("id") String id, NonCatalogPart nonCatalogPart) {
        return service.updateNonCatalogPart(id, nonCatalogPart);
    }

    @POST
    @Path("/removeNonCatalogPart")
    public WorkOrder removeNonCatalogPart(@NotNull @QueryParam("id") String id, NonCatalogPart nonCatalogPart) {
        return service.removeNonCatalogPart(id, nonCatalogPart);
    }

    @POST
    @Path("/findDupeNonCatalogPart")
    @Produces(MediaType.TEXT_PLAIN)
    public String findDupeNonCatalogPart(@NotNull @QueryParam("workOrderId") String workOrderId,
                                         NonCatalogPart nonCatalogPart) {
        return service.findDupeNonCatalogPart(workOrderId, nonCatalogPart);
    }

    @GET
    @Path("/getNonCatalogParts")
    public List<NonCatalogPart> getNonCatalogParts() {
        return service.getNonCatalogParts();
    }

    @GET
    @Path("/findSourceOptions")
    public List<String> findSourceOptions() {
        return service.findSourceOptions();
    }

    @GET
    @Path("/findPartOptions")
    public List<PartOption> findPartOptions() {
        return service.findPartOptions();
    }

    @GET
    @Path("/getAvailableCostTypes")
    public List<String> getAvailableCostTypes(@NotNull @QueryParam("workOrderId") String workOrderId) {
        return service.getAvailableCostTypes(workOrderId);
    }

    @POST
    @Path("/addActualCost")
    public WorkOrder addActualCost(@NotNull @QueryParam("workOrderId") String workOrderId, @NotNull @QueryParam("assignmentId") String assignmentId, ActualCost actualCost) {
        return service.addActualCost(workOrderId, assignmentId, actualCost);
    }

    @POST
    @Path("/updateActualCost")
    public WorkOrder updateActualCost(@NotNull @QueryParam("workOrderId") String workOrderId, @NotNull @QueryParam("assignmentId") String assignmentId, ActualCost actualCost) {
        return service.updateActualCost(workOrderId, assignmentId, actualCost);
    }

    @POST
    @Path("/deleteActualCost")
    public WorkOrder deleteActualCost(@NotNull @QueryParam("workOrderId") String workOrderId, @NotNull @QueryParam("assignmentId") String assignmentId, ActualCost actualCost) {
        return service.deleteActualCost(workOrderId, assignmentId, actualCost);
    }

    @POST
    @Path("/prorateCostAndHours")
    public WorkOrder prorateCostAndHours(@NotNull @QueryParam("workOrderId") String workOrderId, @NotNull @QueryParam("assignmentId") String assignmentId, String actualCostId) {
        return service.prorateCostAndHours(workOrderId, assignmentId, actualCostId);
    }

    @POST
    @Path("/getProratedActualCost")
    public List<ActualCost> getProratedActualCost(@NotNull @QueryParam("workOrderId") String workOrderId, ActualCost actualCost) {
        return service.getProratedActualCost(workOrderId, actualCost);
    }

    @POST
    @Path("/processAssetRefUpdate")
    public void processAssetRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        service.processAssetRefUpdate(dataReferenceUpdate);
    }

    @POST
    @Path("/bulkOpenScheduled")
    public BulkResponse bulkOpenScheduled(@NotNull List<String> ids) {
        return service.bulkOpenScheduled(ids);
    }

    @POST
    @Path("/updateSectionInspectionForWorkOrders")
    public BulkResponse updateSectionInspectionForWorkOrders(@QueryParam("isSectionInspection") boolean isSectionInspection,
                                                             @NotNull List<String> workOrderIds) {
        return service.updateSectionInspectionForWorkOrders(workOrderIds, isSectionInspection);
    }

    @POST
    @Path("/updateWorkOrdersIsDeferred")
    public BulkResponse updateWorkOrdersIsDeferred(@NotNull @QueryParam("isDeferred") boolean isDeferred,
                                                   @NotNull @QueryParam("reason") String reason,
                                                   @NotNull List<String> workOrderIds) {
        return service.updateWorkOrdersIsDeferred(workOrderIds, isDeferred, reason);
    }

    @GET
    @Path("/getEnvironmentalImpactOptions")
    public List<String> getEnvironmentalImpactOptions() {
        return service.getEnvironmentalImpactOptions();
    }

    @GET
    @Path("/getOccupantRefsBySite")
    public List<OccupantRef> getOccupantRefsBySite(@NotNull @QueryParam("siteId") String siteId) {
        return service.getOccupantRefsbySite(siteId);
    }

    @GET
    @Path("/getRoomSummariesByFacilityId")
    public List<RoomSummary> getRoomSummariesByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getRoomSummariesByFacilityId(facilityId);
    }

    @GET
    @Path("/getFacilityById")
    public Facility getFacilityById(@NotNull @QueryParam("id") String facilityId) {
        return service.getFacilityById(facilityId);
    }

    @POST
    @Path("/assign")
    public WorkOrder assign(WorkOrder workOrder) {
        return service.assign(workOrder);
    }

    @POST
    @Path("/sendForApproval")
    public WorkOrder sendForApproval(WorkOrder workOrder) {
        return service.sendForApproval(workOrder);
    }

    @POST
    @Path("/approve")
    public WorkOrder approve(WorkOrder workOrder) {
        return service.approve(workOrder);
    }

    @POST
    @Path("/sendForFundsApproval")
    public WorkOrder sendForFundsApproval(WorkOrder workOrder) {
        return service.sendForFundsApproval(workOrder);
    }

    @POST
    @Path("/fundsApproved")
    public WorkOrder fundsApproved(WorkOrder workOrder) {
        return service.fundsApproved(workOrder);
    }

    @POST
    @Path("/sendForValidation")
    public WorkOrder sendForValidation(WorkOrder workOrder) {
        return service.sendForValidation(workOrder);
    }

    @POST
    @Path("/validated")
    public WorkOrder validated(WorkOrder workOrder) {
        return service.validated(workOrder);
    }

    @POST
    @Path("/defer")
    public WorkOrder defer(WorkOrder workOrder) {
        return service.defer(workOrder);
    }

    @POST
    @Path("/unDefer")
    public WorkOrder unDefer(WorkOrder workOrder) {
        return service.unDefer(workOrder);
    }

    @POST
    @Path("/convertToRequirement")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021. Set workflowOnly to true if not actually updating Refs, only handling Workflow steps.")
    public WorkOrder convertToRequirement(WorkOrder workOrder,
                                          @QueryParam("customDate") Date customDate,
                                          @DefaultValue("false") @QueryParam("workflowOnly") boolean workflowOnly) {
        return customDate == null ? service.convertToRequirement(workOrder) : service.convertToRequirement(workOrder, customDate, workflowOnly);
    }

    @GET
    @Path("/getRequirementFromWorkOrderId")
    public Requirement getRequirementFromWorkOrderId(@NotNull @QueryParam("workOrderId") String workOrderId) {
        return service.getRequirementFromWorkOrderId(workOrderId);
    }

    @POST
    @Path("/bulkConvertToRequirement")
    public BulkResponse bulkConvertToRequirement(@NotNull List<String> workOrderIds, @NotNull @QueryParam("reason") String reason) {
        return service.bulkConvertToRequirement(workOrderIds, reason);
    }

    @POST
    @Path("/bulkHoldWorkOrders")
    public BulkResponse bulkHoldWorkOrders(@NotNull List<String> workOrderIds, @NotNull @QueryParam("reason") String reason) {
        return service.bulkHoldWorkOrders(workOrderIds, reason);
    }

    @POST
    @Path("/bulkResumeWorkOrders")
    public BulkResponse bulkResumeWorkOrders(@NotNull List<String> workOrderIds) {
        return service.bulkResumeWorkOrders(workOrderIds);
    }

    @POST
    @Path("/assignToProject")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021. Set workflowOnly to true if not actually updating Refs, only handling Workflow steps.")
    public WorkOrder assignToProject(WorkOrder workOrder,
                                     @QueryParam("customDate") Date customDate,
                                     @DefaultValue("false") @QueryParam("workflowOnly") boolean workflowOnly) {
        return customDate == null ? service.assignToProject(workOrder) : service.assignToProject(workOrder, customDate, workflowOnly);
    }

    @POST
    @Path("/reject")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021. Set workflowOnly to true if not actually closing assoc. Requirements, only handling Workflow steps.")
    public WorkOrder reject(WorkOrder workOrder,
                            @QueryParam("customDate") Date customDate,
                            @DefaultValue("false") @QueryParam("workflowOnly") boolean workflowOnly) {
        return customDate == null ? service.reject(workOrder) : service.reject(workOrder, customDate, workflowOnly);
    }

    @POST
    @Path("/setAwaitingParts")
    public WorkOrder setAwaitingParts(WorkOrder workOrder) {
        return service.setAwaitingParts(workOrder);
    }

    @POST
    @Path("/setPartsReceived")
    public WorkOrder setPartsReceived(WorkOrder workOrder) {
        return service.setPartsReceived(workOrder);
    }

    @POST
    @Path("/setPartsCancelled")
    public WorkOrder setPartsCancelled(WorkOrder workOrder) {
        return service.setPartsCancelled(workOrder);
    }

    @GET
    @Path("getAllSkills")
    public List<Skill> getAllSkills() {
        return service.getAllSkills();
    }

    @GET
    @Path("getBusinessContact")
    public BusinessContact getBusinessContact(@NotNull @QueryParam("businessContactId") String businessContactId) {
        return service.getBusinessContact(businessContactId);
    }

    @GET
    @Path("getBusinessContacts")
    public List<BusinessContact> getBusinessContacts() {
        return service.getBusinessContacts();
    }

    @GET
    @Path("/getBusinessContactRef")
    public BusinessContactRef getBusinessContactRef(@QueryParam("id") String id) {
        return service.getBusinessContactRef(id);
    }

    @GET
    @Path("getAssignmentReasonOptions")
    public List<String> getAssignmentReasonOptions() {
        return service.getAssignmentReasonOptions();
    }

    @POST
    @Path("/passQualityControl")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021")
    public WorkOrder passQualityControl(WorkOrder workOrder, @QueryParam("customDate") Date customDate) {
        return customDate == null ? service.passQualityControl(workOrder) : service.passQualityControl(workOrder, customDate);
    }

    @POST
    @Path("/failQualityControl")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021")
    public WorkOrder failQualityControl(WorkOrder workOrder, @QueryParam("customDate") Date customDate) {
        return customDate == null ? service.failQualityControl(workOrder) : service.failQualityControl(workOrder, customDate);
    }

    @POST
    @Path("/markQualityControlAsNotPerformed")
    public WorkOrder markQualityControlAsNotPerformed(WorkOrder workOrder) {
        return service.markQualityControlAsNotPerformed(workOrder);
    }

    @POST
    @Path("/markQualityControlAsNotRequired")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021")
    public WorkOrder markQualityControlAsNotRequired(WorkOrder workOrder, @QueryParam("customDate") Date customDate) {
        return customDate == null ? service.markQualityControlAsNotRequired(workOrder) : service.markQualityControlAsNotRequired(workOrder, customDate);
    }

    @GET
    @Path("/findIdsByScheduleIdentifier")
    public List<String> findIdsByScheduleIdentifier(@NotNull @QueryParam("scheduleIdentifier") String scheduleIdentifier) {
        return service.findIdsByScheduleIdentifier(scheduleIdentifier);
    }

    @POST
    @Path("/getWorkLoadSummary")
    public List<WorkLoadSummary> getWorkLoadSummary(WorkLoadSearchCriteria workLoadSearchCriteria) {
        return service.getWorkLoadSummary(workLoadSearchCriteria);
    }

    @GET
    @Path("/getAllSites")
    public List<Site> getAllSites() {
        return service.getAllSites();
    }

    @GET
    @Path("/getSitesForInstallation")
    public List<Site> getSitesForInstallation(@QueryParam("installationId") String installationId) {
        return service.getSitesForInstallation(installationId);
    }

    @GET
    @Path("/getActiveFacilitiesBySiteUid")
    public List<FacilitySummary> getActiveFacilitiesBySiteUid(@QueryParam("rpsuid") String rpsuid) {
        return service.getActiveFacilitiesBySiteUid(rpsuid);
    }

    @GET
    @Path("/getFacilitiesBySiteId")
    public List<FacilitySummary> getFacilitiesBySiteId(@QueryParam("siteId") String siteId) {
        return service.getFacilitiesBySiteId(siteId);
    }

    @GET
    @Path("/getAllFrequencyRefs")
    public List<FrequencyRef> getAllFrequencyRefs() {
        return service.getAllFrequencyRefs();
    }

    @GET
    @Path("/getAllBusinessContacts")
    public List<BusinessContactSearch> getAllBusinessContacts() {
        return service.getAllBusinessContacts();
    }

    @GET
    @Path("/getAllInstallations")
    public List<Installation> getAllInstallations() {
        return service.getAllInstallations();
    }

    @POST
    @Path("/passQualityAssurance")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021")
    public WorkOrder passQualityAssurance(WorkOrder workOrder, @QueryParam("customDate") Date customDate) {
        return customDate == null ? service.passQualityAssurance(workOrder) : service.passQualityAssurance(workOrder, customDate);
    }

    @POST
    @Path("/failQualityAssurance")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021")
    public WorkOrder failQualityAssurance(WorkOrder workOrder, @QueryParam("customDate") Date customDate) {
        return customDate == null ? service.failQualityAssurance(workOrder) : service.failQualityAssurance(workOrder, customDate);
    }

    @POST
    @Path("/markQualityAssuranceAsNotPerformed")
    public WorkOrder markQualityAssuranceAsNotPerformed(WorkOrder workOrder) {
        return service.markQualityAssuranceAsNotPerformed(workOrder);
    }

    @POST
    @Path("/markQualityAssuranceAsNotRequired")
    @ApiOperation(value = "Optional customDate format: Fri May 7 2021")
    public WorkOrder markQualityAssuranceAsNotRequired(WorkOrder workOrder, @QueryParam("customDate") Date customDate) {
        return customDate == null ? service.markQualityAssuranceAsNotRequired(workOrder) : service.markQualityAssuranceAsNotRequired(workOrder, customDate);
    }

    @GET
    @Path("/getWorkOrderDashboardStats")
    public WorkOrderDashboardInfo getWorkOrderDashboardStats() {
        return service.getWorkOrderDashboardStats();
    }

    @POST
    @Path("/getWorkLoadSummaryForNextMonth")
    public List<WorkLoadSummary> getWorkLoadSummaryForNextMonth(WorkLoadSearchCriteria workLoadSearchCriteria) {
        return service.getWorkLoadSummaryForNextMonth(workLoadSearchCriteria);
    }

    @POST
    @Path("/getAssetsByIds")
    public List<AssetSummary> getAssetsByIds(List<AssetRef> assetList) {
        return service.getAssetsByIds(assetList);
    }

    @POST
    @Path("/getRoomSummariesByIds")
    public List<RoomSummary> getRoomSummariesByIds(List<String> roomIdList) {
        return service.getRoomSummariesByIds(roomIdList);
    }

    @GET
    @Path("/getLaborRateFactors")
    public List<LaborRateFactor> getLaborRateFactors() {
        return service.getLaborRateFactors();
    }

    @POST
    @Path("/saveAssignmentEstimate")
    public AssignmentEstimateResult saveAssignmentEstimate(@NotNull @QueryParam("workOrderId") String workOrderId, Assignment assignment) {
        return service.saveAssignmentEstimate(workOrderId, assignment);
    }

    @POST
    @Path("/bulkAcceptWorkOrders")
    public BulkResponse bulkAcceptWorkOrders(@NotNull List<String> workOrderIds) {
        return service.bulkAcceptWorkOrders(workOrderIds);
    }

    @POST
    @Path("/bulkRejectWorkOrders")
    public BulkResponse bulkRejectWorkOrders(@NotNull List<String> workOrderIds, @NotNull @QueryParam("reason") String reason) {
        return service.bulkRejectWorkOrders(workOrderIds, reason);
    }

    @POST
    @Path("/saveDonatedResources")
    public WorkOrder saveDonatedResources(@NotNull @QueryParam("workOrderId") String workOrderId, List<String> donatedResources) {
        return service.saveDonatedResources(workOrderId, donatedResources);
    }

    @GET
    @Path("/getDonatedResources")
    public List<String> getDonatedResources() {
        return service.getDonatedResources();
    }

    @POST
    @Path("/bulkCancel")
    public BulkResponse bulkCancel(@NotNull List<String> ids, @NotNull @QueryParam("reason") String reason) {
        return service.bulkCancel(ids, reason);
    }

    @POST
    @Path("/updateScheduledWorkOrders")
    public void updateScheduledWorkOrders(@NotNull Schedule schedule) {
        service.updateScheduledWorkOrders(schedule);
    }

    @GET
    @Path("/getSectionById")
    public Section getSectionById(@QueryParam("sectionId") String sectionId) {
        return service.getSectionById(sectionId);
    }

    @POST
    @Path("/getSectionSummariesByIds")
    public List<SectionSummary> getSectionSummariesByIds(List<String> sectionIdList) {
        return service.getSectionSummariesByIds(sectionIdList);
    }

    @GET
    @Path("/getSectionSummariesByFacilityId")
    public List<SectionSummary> getSectionSummariesByFacilityId(@NotNull @QueryParam("facilityId") String facilityId) {
        return service.getSectionSummariesByFacilityId(facilityId);
    }

    @POST
    @Path("/updateWorkOrderSections")
    public WorkOrder updateWorkOrderSections(@NotNull WorkOrder workOrder) {
        return service.updateWorkOrderSections(workOrder);
    }

    @GET
    @Path("/getAssociateWorkOrders")
    public List<WorkOrder> getAssociateWorkOrders(@NotNull @QueryParam("workOrderId") String workOrderId) {
        return service.getAssociateWorkOrders(workOrderId);
    }

    @GET
    @Path("/getAssociateAndNonAssociateWorkOrders")
    public List<WorkOrder> getAssociateAndNonAssociateWorkOrders(@NotNull @QueryParam("workOrderId") String workOrderId) {
        return service.getAssociateAndNonAssociateWorkOrders(workOrderId);
    }

    @POST
    @Path("/updateAssociateWorkOrder")
    public WorkOrder updateAssociateWorkOrder(@NotNull WorkOrder workOrder) {
        return service.updateAssociateWorkOrder(workOrder);
    }

    @POST
    @Path("/updateWorkOrderAssets")
    public WorkOrder updateWorkOrderAssets(@NotNull WorkOrder workOrder) {
        return service.updateWorkOrderAssets(workOrder);
    }

    @GET
    @Path("/getProjectsByFacility")
    public List<RealPropertyProject> getProjectsByFacility(@NotNull @QueryParam("facilityId") String facilityId) {
        return service.getProjectsByFacility(facilityId);
    }

    @POST
    @Path("/updateQuality")
    public WorkOrder updateQuality(@NotNull WorkOrder workOrder) {
        return service.updateQuality(workOrder);
    }

    @GET
    @Path("/getAssignedBusinessContacts")
    public List<BusinessContact> getAssignedBusinessContacts(@NotNull @QueryParam("id") String id) {
        return service.getAssignedBusinessContacts(id);
    }

    @GET
    @Path("/getManagedBusinessContactsForQualityAssurance")
    public List<BusinessContact> getManagedBusinessContactsForQualityAssurance() {
        return service.getManagedBusinessContactsForQualityAssurance();
    }

    @GET
    @Path("/getParentOrganizationName")
    @Produces(MediaType.TEXT_PLAIN)
    public String getParentOrganizationName(@NotNull @QueryParam("organizationId") String organizationId) {
        return service.getParentOrganizationName(organizationId);
    }

    @GET
    @Path("/getInstallationNameFromSiteId")
    @Produces(MediaType.TEXT_PLAIN)
    public String getInstallationNameFromSiteId(@NotNull @QueryParam("siteId") String siteId) {
        return service.getInstallationNameFromSiteId(siteId);
    }

    @GET
    @Path("/getWorkOrdersForPrioritization")
    public List<WorkOrder> getWorkOrdersForPrioritization(@NotNull @QueryParam("priorityGroupId") String priorityGroupId,
                                                          @NotNull @QueryParam("classificationTypeId") String classificationTypeId,
                                                          @NotNull @QueryParam("facilityId") String facilityId) {
        return service.getWorkOrdersForPrioritization(priorityGroupId, classificationTypeId, facilityId);
    }

    @POST
    @Path("/updateWorkOrderPriorityOrder")
    public int updateWorkOrderPriorityOrder(List<WorkOrder> workOrders) {
        return service.updateWorkOrderPriorityOrder(workOrders);
    }

    @GET
    @Path("/getRelatedCauses")
    public List<String> getRelatedCauses() {
        return service.getRelatedCauses();
    }

    @GET
    @Path("/getDocumentTypes")
    public List<String> getDocumentTypes() {
        return service.getDocumentTypes();
    }

    @POST
    @Path("/setPreventativeMaintenanceDeferred")
    public WorkOrder setPreventativeMaintenanceDeferred(WorkOrder workOrder) {
        return service.setPreventativeMaintenanceDeferred(workOrder);
    }

    @POST
    @Path("/setUnableToLocate")
    public WorkOrder setUnableToLocate(WorkOrder workOrder) {
        return service.setUnableToLocate(workOrder);
    }

    @POST
    @Path("/setSendToWorkControl")
    public WorkOrder setSendToWorkControl(WorkOrder workOrder) {
        return service.setSendToWorkControl(workOrder);
    }

    @POST
    @Path("/setSendForScheduling")
    public WorkOrder setSendForScheduling(WorkOrder workOrder) {
        return service.setSendForScheduling(workOrder);
    }

    @POST
    @Path("/setSendForServiceOrder")
    public WorkOrder setSendForServiceOrder(WorkOrder workOrder) {
        return service.setSendForServiceOrder(workOrder);
    }

    @POST
    @Path("/setSendForContractAgencyApproval")
    public WorkOrder setSendForContractAgencyApproval(WorkOrder workOrder) {
        return service.setSendForContractAgencyApproval(workOrder);
    }

    @POST
    @Path("/setNoticeToProceed")
    public WorkOrder setNoticeToProceed(WorkOrder workOrder) {
        return service.setNoticeToProceed(workOrder);
    }

    @POST
    @Path("/setRework")
    public WorkOrder setRework(WorkOrder workOrder) {
        return service.setRework(workOrder);
    }

    @POST
    @Path("/hold")
    public WorkOrder hold(WorkOrder workOrder) {
        return service.hold(workOrder);
    }

    @POST
    @Path("/resume")
    public WorkOrder resume(WorkOrder workOrder) {
        return service.resume(workOrder);
    }

    @GET
    @Path("/checkIfMaximoEnabled")
    public boolean checkIfMaximoEnabled() {
        return service.checkIfMaximoEnabled();
    }

    @GET
    @Path("/submitWorkOrderToMaximo")
    public WorkOrder submitWorkOrderToMaximo(@NotNull @QueryParam("workOrderId") String workOrderId) {
        return service.submitWorkOrderToMaximo(workOrderId);
    }


    @POST
    @Path("/updateWorkOrderEquipmentInspections")
    public WorkOrder updateWorkOrderEquipmentInspections(@NotNull WorkOrder workOrder) {
        return service.updateWorkOrderEquipmentInspections(workOrder);
    }


    @GET
    @Path("/getCmmsExpenseCenters")
    public List<CmmsExpenseCenter> getCmmsExpenseCenters() {
        return service.getCmmsExpenseCenters();
    }

    @POST
    @Path("/createCmmsExpenseCenter")
    public CmmsExpenseCenter createCmmsExpenseCenter(@NotNull CmmsExpenseCenter cmmsExpenseCenter) {
        return service.createCmmsExpenseCenter(cmmsExpenseCenter);
    }

    @POST
    @Path("/updateCmmsExpenseCenter")
    public CmmsExpenseCenter updateCmmsExpenseCenter(@NotNull CmmsExpenseCenter cmmsExpenseCenter) {
        return service.updateCmmsExpenseCenter(cmmsExpenseCenter);
    }

    @GET
    @Path("/deleteCmmsExpenseCenter")
    public void deleteCmmsExpenseCenter(@NotNull @QueryParam("id") String id) {
        service.deleteCmmsExpenseCenter(id);
    }

    @GET
    @Path("/getAvailableCmmsExpenseCenterRefs")
    public List<CmmsExpenseCenterRef> getAvailableCmmsExpenseCenterRefs(@NotNull @QueryParam("workOrderId") String workOrderId,
                                                                        @NotNull @QueryParam("fiscalYear") String fiscalYear) {
        return service.getAvailableCmmsExpenseCenterRefs(workOrderId, fiscalYear);
    }

    @POST
    @Path("/saveCmmsExpenseCenter")
    public WorkOrder saveCmmsExpenseCenter(@NotNull WorkOrder workOrder) {
        return service.saveCmmsExpenseCenter(workOrder);
    }

    @GET
    @Path("/getDrawingLegend")
    public List<FloorPlanLegendEntry> getDrawingLegend(@QueryParam("floorId") String floorId, @QueryParam("legendType") String legendType) {
        return service.getDrawingLegend(floorId, legendType);
    }

    @GET
    @Path("/getFloorPlanLayers")
    public List<FloorPlanLayer> getFloorPlanLayers() {
        return service.getFloorPlanLayers();
    }

    @POST
    @Path("/getGraphicalSearchRecordsByRoomIds")
    public List<GraphicalSearchRecord> getGraphicalSearchRecordsByRoomIds(List<String> roomIds) {
        return service.getGraphicalSearchRecordsByRoomIds(roomIds);
    }

    @GET
    @Path("/getFloorById")
    public Floor getFloorById(@QueryParam("id") String id) {
        return service.getFloorById(id);
    }

    @GET
    @Path("/getRoomMetadataByRoomNumber")
    public RoomMetadata getRoomMetadataByRoomNumber(@QueryParam("facilityId") String facilityId, @QueryParam("identifier") String identifier) {
        return service.getRoomMetadataByRoomNumber(facilityId, identifier);
    }

    @GET
    @Path("/getRelatedRecordCountsByRoomNumber")
    public RoomRelatedRecordCounts getRelatedRecordCountsByRoomNumber(@QueryParam("facilityId") String facilityId, @QueryParam("identifier") String identifier) {
        return service.getRelatedRecordCountsByRoomNumber(facilityId, identifier);
    }

    @GET
    @Path("/isAllowedToEditWorkOrder")
    public boolean isAllowedToEditWorkOrder(@NotNull @QueryParam("id") String id) {
        return service.isAllowedToEditWorkOrder(id);
    }

    @POST
    @Path("/approveRequest")
    public WorkOrder approveRequest(WorkOrder workOrder) {
        return service.approveRequest(workOrder);
    }

    @POST
    @Path("/approveCancel")
    public WorkOrder approveCancel(WorkOrder workOrder) {
        return service.approveCancel(workOrder);
    }

    @POST
    @Path("/cancelServiceRequest")
    public WorkOrder cancelServiceRequest(WorkOrder workOrder) {
        return service.cancelServiceRequest(workOrder);
    }

    @GET
    @Path("/getSurveyRating")
    public List<String> getSurveyRating() {
        return service.getSurveyRating();
    }

    @POST
    @Path("/updateWorkOrderSurvey")
    public WorkOrder updateWorkOrderSurvey(@NotNull @QueryParam("workOrderId") String workOrderId, WorkOrderSurvey survey) {
        return service.updateWorkOrderSurvey(workOrderId, survey);
    }

    @POST
    @Path("/addSurveyComment")
    public WorkOrder addSurveyComment(@NotNull @QueryParam("id") String id, Comment comment) {
        return service.addSurveyComment(id, comment);
    }

    @POST
    @Path("/removeSurveyComment")
    public WorkOrder removeSurveyComment(@NotNull @QueryParam("id") String id, Comment comment) {
        return service.removeSurveyComment(id, comment);
    }

    @POST
    @Path("/addReplaceLegacyWorkRequestStatusHistories")
    public WorkOrder addReplaceLegacyWorkRequestStatusHistories(@NotNull @QueryParam("workOrderId") String workOrderId,
                                                                List<LegacyWorkRequestStatusHistory> statusHistories) {
        return service.addReplaceLegacyWorkRequestStatusHistories(workOrderId, statusHistories);
    }

    @GET
    @Path("/migrateWorkOrderRequirementAssociation")
    public WorkOrderRequirementMigrationResult migrateWorkOrderRequirementAssociation(
            @NotNull @QueryParam("siteDodaac") String siteDodaac,
            @NotNull @QueryParam("dmlssWorkRequestSerial") Integer dmlssWorkRequestSerial,
            @QueryParam("dmlssRequirementNumber") String dmlssRequirementNumber,
            @QueryParam("dmlssRequirementSerial") Integer dmlssRequirementSerial) {
        return service.migrateWorkOrderRequirementAssociation(
                siteDodaac, dmlssWorkRequestSerial, dmlssRequirementNumber, dmlssRequirementSerial);
    }

    @GET
    @Path("/associateLegacyWorkOrders")
    public WorkOrderLegacyAssociationResult associateLegacyWorkOrders(
            @NotNull @QueryParam("siteDodaac") String siteDodaac,
            @NotNull @QueryParam("dmlssWorkRequestSerial") Integer dmlssWorkRequestSerial,
            @NotNull @QueryParam("relatedDmlssWorkRequestSerial") Integer relatedDmlssWorkRequestSerial) {
        return service.associateLegacyWorkOrders(siteDodaac, dmlssWorkRequestSerial, relatedDmlssWorkRequestSerial);
    }

    @POST
    @Path("/saveSurveyComment")
    public WorkOrder saveSurveyComment(@NotNull @QueryParam("id") String id, Comment comment) {
        return service.saveSurveyComment(id, comment);
    }

    @GET
    @Path("/getProjectFundingNodeSummaries")
    public List<RealPropertyFundingNodeSummary> getProjectFundingNodeSummaries(@QueryParam("organizationNodeId") String organizationNodeId) {
        return service.getProjectFundingNodeSummaries(organizationNodeId);
    }

    @GET
    @Path("/getExpenseFundingNodeSummaries")
    public List<RealPropertyFundingNodeSummary> getExpenseFundingNodeSummaries(@QueryParam("projectFundingNodeId") String projectFundingNodeId) {
        return service.getExpenseFundingNodeSummaries(projectFundingNodeId);
    }

    @GET
    @Path("/getCommodityCodeRefs")
    public List<CommodityCodeRef> getCommodityCodeRefs(@QueryParam("organizationNodeId") String organizationNodeId) {
        return service.getCommodityCodeRefs(organizationNodeId);
    }

    @GET
    @Path("/getActualCostProjectFundingNodeSummaries")
    public List<RealPropertyFundingNodeSummary> getActualCostProjectFundingNodeSummaries(@NotNull @QueryParam("workOrderId") String workOrderId, @NotNull @QueryParam("assignmentId") String assignmentId) {
        return service.getActualCostProjectFundingNodeSummaries(workOrderId, assignmentId);
    }

    @GET
    @Path("/getActualCostExpenseFundingNodeSummaries")
    public List<RealPropertyFundingNodeSummary> getActualCostExpenseFundingNodeSummaries(@NotNull @QueryParam("workOrderId") String workOrderId, @NotNull @QueryParam("assignmentId") String assignmentId, @NotNull @QueryParam("projectFundingNodeId") String projectFundingNodeId) {
        return service.getActualCostExpenseFundingNodeSummaries(workOrderId, assignmentId, projectFundingNodeId);
    }
}
