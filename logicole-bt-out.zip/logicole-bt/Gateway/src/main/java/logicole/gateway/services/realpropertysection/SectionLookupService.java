package logicole.gateway.services.realpropertysection;

import logicole.apis.realpropertysection.ISectionLookupMicroserviceApi;
import logicole.common.datamodels.asset.classification.AssemblyCategory;
import logicole.common.datamodels.asset.classification.AssemblyCategoryRef;
import logicole.common.datamodels.asset.classification.FacilitySubsystem;
import logicole.common.datamodels.asset.classification.FacilitySubsystemRef;
import logicole.common.datamodels.asset.classification.FacilitySystem;
import logicole.common.datamodels.asset.classification.FacilitySystemRef;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtype;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeHierarchy;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeRef;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeUnit;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeUnitRef;
import logicole.common.datamodels.realpropertysection.lookupdata.ESectionConditionType;
import logicole.common.datamodels.realpropertysection.lookupdata.ESectionInspectionType;
import logicole.common.datamodels.realpropertysection.lookupdata.PaintType;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.AssetMaintenanceProcedureService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@ApplicationScoped
public class SectionLookupService extends BaseGatewayService<ISectionLookupMicroserviceApi> {

    @Inject
    AssetMaintenanceProcedureService assetMaintenanceProcedureService;

    SectionLookupService() {
        super("SectionLookup");
    }

    public List<PaintType> getAllPaintTypes() {
        return microservice.getAllPaintTypes();
    }

    public List<ESectionConditionType> getAllSectionConditionTypes() {
        return Arrays.asList(ESectionConditionType.values());
    }

    public List<ComponentSubtype> getAllComponentSubtypes() {
        return microservice.getAllComponentSubtypes();
    }

    public List<ComponentSubtypeRef> getAllComponentSubtypesRefs() {
        List<ComponentSubtype> componentSubtypes = getAllComponentSubtypes();
        List<ComponentSubtypeRef> componentSubtypeRefs = new ArrayList<>();
        for (ComponentSubtype componentSubtype : componentSubtypes) {
            componentSubtypeRefs.add((ComponentSubtypeRef) componentSubtype.getRef());
        }
        return componentSubtypeRefs;
    }

    public List<ComponentSubtypeUnit> getAllComponentSubtypeUnits() {
        return microservice.getAllComponentSubtypeUnits();
    }

    public List<ComponentSubtypeUnitRef> getAllComponentSubtypeUnitRefs() {
        List<ComponentSubtypeUnit> componentSubtypeUnits = getAllComponentSubtypeUnits();
        List<ComponentSubtypeUnitRef> componentSubtypeUnitRefs = new ArrayList<>();
        for (ComponentSubtypeUnit componentSubtypeUnit : componentSubtypeUnits) {
            componentSubtypeUnitRefs.add((ComponentSubtypeUnitRef) componentSubtypeUnit.getRef());
        }
        return componentSubtypeUnitRefs;
    }

    public PaintType createNewPaintType(PaintType paintType) {
        PaintType dupPaintType = microservice.getPaintTypeByType(paintType.type);
        if (dupPaintType == null) {
            paintType.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            paintType.type = StringUtil.toDisplayCase(paintType.type);
            return microservice.createNewPaintType(paintType);
        } else {
            throw new ApplicationException("Paint Type already exists");
        }
    }

    public ComponentSubtype createComponentSubtype(ComponentSubtype componentSubtype) {
        ComponentSubtype dupComponentSubtype = microservice.getComponentSubtypeByDescription(componentSubtype.description);
        if (dupComponentSubtype == null) {
            componentSubtype.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            componentSubtype.description = StringUtil.toDisplayCase(componentSubtype.description);
            return microservice.createComponentSubtype(componentSubtype);
        } else {
            throw new ApplicationException("Component Subtype already exists");
        }
    }

    public ComponentSubtypeUnit createComponentSubtypeUnit(ComponentSubtypeUnit componentSubtypeUnit) {
        ComponentSubtypeUnit dupComponentSubtypeUnit = microservice.getComponentSubtypeUnitByDescription(componentSubtypeUnit.description);
        if (dupComponentSubtypeUnit == null) {
            componentSubtypeUnit.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            componentSubtypeUnit.description = StringUtil.toDisplayCase(componentSubtypeUnit.description);
            return microservice.createComponentSubtypeUnit(componentSubtypeUnit);
        } else {
            throw new ApplicationException("Component Subtype Unit already exists");
        }
    }

    public PaintType updatePaintType(PaintType paintType) {
        PaintType foundPaintType = microservice.getPaintTypeById(paintType.getId());
        if (foundPaintType == null) {
            throw new ApplicationException("Paint Type does not exist");
        } else {
            if (microservice.getPaintTypeByType(paintType.type) != null &&
                    !(paintType.type.equalsIgnoreCase(foundPaintType.type))) {
                throw new ApplicationException("Paint Type already exists");
            }
            paintType.type = StringUtil.toDisplayCase(paintType.type);
            return microservice.updatePaintType(paintType);
        }
    }

    public ComponentSubtype updateComponentSubtype(ComponentSubtype componentSubtype) {
        ComponentSubtype foundComponentSubtype = microservice.getComponentSubtypeById(componentSubtype.getId());
        if (foundComponentSubtype == null) {
            throw new ApplicationException("Component Subtype does not exist");
        } else {
            if (microservice.getComponentSubtypeByDescription(componentSubtype.description) != null &&
                    !(componentSubtype.description.equalsIgnoreCase(foundComponentSubtype.description))) {
                throw new ApplicationException("Component Subtype already exists");
            }
            componentSubtype.description = StringUtil.toDisplayCase(componentSubtype.description);
            return microservice.updateComponentSubtype(componentSubtype);
        }
    }

    public ComponentSubtypeUnit updateComponentSubtypeUnit(ComponentSubtypeUnit componentSubtypeUnit) {
        ComponentSubtypeUnit foundComponentSubtypeUnit = microservice.getComponentSubtypeUnitById(componentSubtypeUnit.getId());
        if (foundComponentSubtypeUnit == null) {
            throw new ApplicationException("Component Subtype Unit does not exist");
        } else {
            if (microservice.getComponentSubtypeUnitByDescription(componentSubtypeUnit.description) != null &&
                    !(componentSubtypeUnit.description.equalsIgnoreCase(foundComponentSubtypeUnit.description))) {
                throw new ApplicationException("Component Subtype Unit already exists");
            }
            componentSubtypeUnit.description = StringUtil.toDisplayCase(componentSubtypeUnit.description);
            return microservice.updateComponentSubtypeUnit(componentSubtypeUnit);
        }
    }

    public boolean deletePaintType(String id) {
        return microservice.deletePaintType(id);
    }

    public boolean deleteComponentSubtype(String id) { return microservice.deleteComponentSubtype(id); }

    public boolean deleteComponentSubtypeUnit(String id) { return microservice.deleteComponentSubtypeUnit(id); }

    private AssemblyCategoryRef getAssemblyCategoryRefs(AssemblyCategoryRef assemblyCategoryRef) {
        List<AssemblyCategory> listOfAssemblyCategories = assetMaintenanceProcedureService.getAllAssemblyCategories();
        AssemblyCategoryRef acRef = new AssemblyCategoryRef();
        for (AssemblyCategory ac : listOfAssemblyCategories) {
            if (ac.code.equalsIgnoreCase(assemblyCategoryRef.code) &&
                    ac.description.equalsIgnoreCase(assemblyCategoryRef.description)) {
                acRef = ac.getRef();
            }
        }

        return acRef;
    }

    private FacilitySubsystemRef getFacilitySubsystemRefs(FacilitySubsystemRef facilitySubsystemRef) {
        List<FacilitySubsystem> listOfFacilitySubsystems = assetMaintenanceProcedureService.getAllFacilitySubsystems();
        FacilitySubsystemRef subsysRefs = new FacilitySubsystemRef();
        for (FacilitySubsystem fs : listOfFacilitySubsystems) {
            if (fs.code.equalsIgnoreCase(facilitySubsystemRef.code) &&
                    fs.description.equalsIgnoreCase(facilitySubsystemRef.description)) {
                subsysRefs = fs.getRef();
            }
        }

        return subsysRefs;
    }

    private FacilitySystemRef getFacilitySystemRefs(FacilitySystemRef facilitySystemRef) {
        List<FacilitySystem> listOfFacilitySystems = assetMaintenanceProcedureService.getAllFacilitySystems();
        FacilitySystemRef fsRefs = new FacilitySystemRef();
        for (FacilitySystem fs : listOfFacilitySystems) {
            if (fs.code.equalsIgnoreCase(facilitySystemRef.code)
                    && fs.description.equalsIgnoreCase(facilitySystemRef.description)) {
                fsRefs = fs.getRef();
            }
        }
        return fsRefs;
    }

    private ComponentSubtypeRef getComponentSubtypeRef(ComponentSubtypeRef componentSubtypeRef) {
        List<ComponentSubtype> listOfComponentSubtypes = getAllComponentSubtypes();
        ComponentSubtypeRef subtypeRefs = new ComponentSubtypeRef();
        for (ComponentSubtype cs : listOfComponentSubtypes) {
            if (cs.description.equalsIgnoreCase(componentSubtypeRef.description) &&
                    cs.measurementUnit == componentSubtypeRef.measurementUnit) {
                subtypeRefs = (ComponentSubtypeRef) cs.getRef();
            }
        }
        return subtypeRefs;
    }


    public ComponentSubtypeHierarchy getComponentSubtypeHierarchyById(String id) {
        return microservice.getComponentSubtypeHierarchyById(id);
    }

    public List<ComponentSubtypeHierarchy> getComponentSubtypeHierarchies() {
        return microservice.getComponentSubtypeHierarchies();
    }

    public ComponentSubtypeHierarchy updateComponentSubtypeHierarchy(ComponentSubtypeHierarchy componentSubtypeHierarchy) {
        ComponentSubtypeHierarchy foundCompSubtypeHierarchy =
                microservice.getComponentSubtypeHierarchyById(componentSubtypeHierarchy.getId());

        if (foundCompSubtypeHierarchy == null) {
            throw new ApplicationException("Component Subtype Hierarchy does not exist");
        } else {
            componentSubtypeHierarchy.componentSubtypeRef = getComponentSubtypeRef(componentSubtypeHierarchy.componentSubtypeRef);
            componentSubtypeHierarchy.assemblyCategoryRef = getAssemblyCategoryRefs(componentSubtypeHierarchy.assemblyCategoryRef);
            componentSubtypeHierarchy.systemRef = getFacilitySystemRefs(componentSubtypeHierarchy.systemRef);
            componentSubtypeHierarchy.subsystemRef = getFacilitySubsystemRefs(componentSubtypeHierarchy.subsystemRef);

            return microservice.updateComponentSubtypeHierarchy(componentSubtypeHierarchy);
        }
    }

    public ComponentSubtypeHierarchy createComponentSubtypeHierarchy(ComponentSubtypeHierarchy componentSubtypeHierarchy) {
        componentSubtypeHierarchy.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        if (componentSubtypeHierarchy.assemblyCategoryRef.getId() == null ||
                componentSubtypeHierarchy.assemblyCategoryRef.getId().isEmpty()) {

            componentSubtypeHierarchy.assemblyCategoryRef =
                    getAssemblyCategoryRefs(componentSubtypeHierarchy.assemblyCategoryRef);
        }
        if (componentSubtypeHierarchy.componentSubtypeRef.getId() == null ||
                componentSubtypeHierarchy.componentSubtypeRef.getId().isEmpty()) {

            componentSubtypeHierarchy.componentSubtypeRef =
                    getComponentSubtypeRef(componentSubtypeHierarchy.componentSubtypeRef);
        }
        if (componentSubtypeHierarchy.subsystemRef.getId() == null || componentSubtypeHierarchy.subsystemRef.getId().isEmpty()) {

            componentSubtypeHierarchy.subsystemRef = getFacilitySubsystemRefs(componentSubtypeHierarchy.subsystemRef);
        }
        if (componentSubtypeHierarchy.systemRef.getId() == null || componentSubtypeHierarchy.systemRef.getId().isEmpty()) {

            componentSubtypeHierarchy.systemRef = getFacilitySystemRefs(componentSubtypeHierarchy.systemRef);
        }
        return microservice.createComponentSubtypeHierarchy(componentSubtypeHierarchy);
    }

    public boolean deleteComponentSubtypeHierarchy(String id) {
        return microservice.deleteComponentSubtypeHierarchy(id);
    }

/*    public List<String> getAllSectionConditionTypes() {
        List<String> SectionConditionTypeList = new ArrayList<>();
        for (ESectionConditionType sectionConditionType : ESectionConditionType.values()) {
            SectionConditionTypeList.add(sectionConditionType.getSubTypeLabel());
        }
        return SectionConditionTypeList;
    }*/

    public List<String> getAllSectionInspectionTypes() {
        List<String> SectionInspectionTypeList = new ArrayList<>();
        for (ESectionInspectionType sectionInspectionType : ESectionInspectionType.values()) {
            SectionInspectionTypeList.add(sectionInspectionType.displayText);
        }
        return SectionInspectionTypeList;
    }

}
