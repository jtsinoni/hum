package logicole.gateway.services.catalog;

import io.swagger.annotations.Api;
import logicole.common.datamodels.catalog.CatalogNote;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import java.util.List;

@Api(tags = {"CatalogNotes"})
@ApplicationScoped
@Path("/catalogNotes")
public class CatalogNotesRestApi extends ExternalRestApi<CatalogNotesService> {

    @GET
    @Path("/getNotesByAssociatedRecordId")
    public List<CatalogNote> getNotesByAssociatedRecordId(@QueryParam("associatedRecordId") String associatedRecordId) {
        return service.getNotesByAssociatedRecordId(associatedRecordId);
    }

    @POST
    @Path("/addNote")
    public CatalogNote addNote(CatalogNote newNote) {
        return service.addNote(newNote);
    }

    @POST
    @Path("/deleteNote")
    public Integer deleteNote(CatalogNote newNote) {
        return service.deleteNote(newNote);
    }

    @POST
    @Path("/updateNote")
    public CatalogNote updateNote(CatalogNote newNote) {
        return service.updateNote(newNote);
    }
}

