package logicole.gateway.services.spacemanagement;

import logicole.apis.space.ILookupMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class SpaceLookupMicroserviceClient extends MicroserviceClient<ILookupMicroserviceApi> {
    public SpaceLookupMicroserviceClient(){
        super(ILookupMicroserviceApi.class, "logicole-space-management");
    }

    @Produces
    public ILookupMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
