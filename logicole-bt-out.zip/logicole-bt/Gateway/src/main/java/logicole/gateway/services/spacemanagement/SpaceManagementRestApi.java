
package logicole.gateway.services.spacemanagement;

import io.swagger.annotations.*;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.management.AssetSummary;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.BulkUpdateResult;
import logicole.common.datamodels.general.customfield.CustomFieldValue;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.realproperty.facility.FacilityRef;
import logicole.common.datamodels.space.*;
import logicole.common.datamodels.space.cobie.export.FloorCOBieExportData;
import logicole.common.datamodels.space.cobie.export.SpaceCOBieExportData;
import logicole.common.datamodels.space.cobie.staging.COBieFloorImportSummary;
import logicole.common.datamodels.space.cobie.staging.COBieSpaceImportSummary;
import logicole.common.datamodels.space.cobie.staging.COBieZoneImportSummary;
import logicole.common.datamodels.system.TagRef;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Api(tags = {"SpaceManagement"})
@ApplicationScoped
@Path("/spacemanagement")
public class SpaceManagementRestApi extends ExternalRestApi<SpaceManagementService> {

    @Inject
    private MultiPartFormUtil uploadUtil;

    ////////////////////////////////////
    // Floor Methods
    ///////////////////////////////////
    @GET
    @Path("/getFloorById")
    public Floor getFloorById(@QueryParam("id") String id) {
        return service.getFloorById(id);
    }

    @GET
    @Path("/getFloorsByFacilityId")
    public List<Floor> getFloorsByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getFloorsByFacilityId(facilityId);
    }

    @GET
    @Path("/deleteFloorById")
    public Floor deleteFloorById(@QueryParam("floorId") String floorId) {
        return service.deleteFloorById(floorId);
    }

    @POST
    @Path("/addFloorToFacility")
    public Floor addFloorToFacility(@QueryParam("facilityId") String facilityId, Floor floorToAdd) {
        return service.addFloorToFacility(facilityId, floorToAdd);
    }

    @POST
    @Path("/createFloors")
    public BulkUpdateResult createFloors(List<Floor> floors) {
        return service.createFloors(floors);
    }

    @POST
    @Path("/updateFloor")
    public Floor updateFloor(Floor floorToUpdate) {
        return service.updateFloor(floorToUpdate);
    }

    ////////////////////////////////////
    // Space Occupants
    ////////////////////////////////////
    @GET
    @Path("/getOccupantById")
    public Occupant getOccupantById(@QueryParam("id") String id) {
        return service.getOccupantById(id);
    }

    @GET
    @Path("/getOccupantByCustomerIdAndManagedByNode")
    public Occupant getOccupantByCustomerIdAndManagedByNode(
            @NotNull @QueryParam("customerId") String customerId,
            @NotNull @QueryParam("managedByNodeId") String managedByNodeId) {
        return service.getOccupantByCustomerIdAndManagedByNode(customerId, managedByNodeId);
    }

    @POST
    @Path("/getOccupantSearchResults")
    public SearchResult<OccupantSummary> getOccupantSearchResults(SearchInput searchInput) {
        return service.getOccupantSearchResults(searchInput);
    }

    @GET
    @Path("/getOccupantsByRoomId")
    public List<OccupantSummary> getOccupantsByRoomId(@QueryParam("roomId") String roomId) {
        return service.getOccupantsByRoomId(roomId);
    }

    @POST
    @Path("/getOccupantsByRoomIds")
    public List<OccupantSummary> getOccupantsByRoomIds(List<String> roomIdList) {
        return service.getOccupantsByRoomIds(roomIdList);
    }

    @GET
    @Path("/deleteOccupantById")
    public Occupant deleteOccupantById(@QueryParam("occupantId") String occupantId) {
        return service.deleteOccupantById(occupantId);
    }

    @POST
    @Path("/createOccupant")
    public Occupant createOccupant(Occupant occupant) throws ApplicationException {
        return service.createOccupant(occupant);
    }

    @POST
    @Path("/updateOccupant")
    public Occupant updateOccupant(Occupant occupant) throws ApplicationException {
        return service.updateOccupant(occupant);
    }

    @GET
    @Path("/isOccupantUnique")
    public boolean isOccupantUnique(@NotNull @QueryParam("customerId") String customerId,
                                    @NotNull @QueryParam("managedByNodeId") String managedByNodeId,
                                    @QueryParam("occupantIdToIgnore") String occupantIdToIgnore) {
        return service.isOccupantUnique(customerId, managedByNodeId, occupantIdToIgnore);
    }

    @GET
    @Path("/getExistingOccupantDepartmentName")
    @Produces(MediaType.TEXT_PLAIN)
    public String getExistingOccupantDepartmentName(@NotNull @QueryParam("departmentId") String departmentId,
                                                    @NotNull @QueryParam("siteId") String siteId,
                                                    @QueryParam("occupantIdToIgnore") String occupantIdToIgnore) {
        return service.getExistingOccupantDepartmentName(departmentId, siteId, occupantIdToIgnore);
    }

    //////////////////
    // Space Methods
    //////////////////
    @GET
    @Path("/getRoomById")
    public Space getRoomById(@QueryParam("id") String id) {
        return service.getRoomById(id);
    }

    @POST
    @Path("/getRoomsById")
    public List<Space> getRoomsById(List<SpaceRef> roomList) {
        return service.getRoomsById(roomList);
    }

    @GET
    @Path("/getRoomByRoomNumber")
    public Space getRoomByRoomNumber(@QueryParam("facilityId") String facilityId, @QueryParam("roomNumber") String roomNumber) {
        return service.getRoomByRoomNumber(facilityId, roomNumber);
    }

    @GET
    @Path("/getRoomsByFacilityId")
    public List<Space> getRoomsByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getRoomsByFacilityId(facilityId);
    }

    @GET
    @Path("/getRoomsByFloorId")
    public List<Space> getRoomsByFloorId(@QueryParam("floorId") String floorId) {
        return service.getRoomsByFloorId(floorId);
    }

    @GET
    @Path("/getRoomsByOccupantId")
    public List<Space> getRoomsByOccupantId(@QueryParam("occupantId") String occupantId) {
        return service.getRoomsByOccupantId(occupantId);
    }

    @GET
    @Path("/getRoomsByOccupantIdAndStatus")
    public List<Space> getRoomsByOccupantIdAndStatus(@QueryParam("occupantId") String occupantId, @QueryParam("selectedStatus") String selectedStatus) {
        return service.getRoomsByOccupantIdAndStatus(occupantId, selectedStatus);
    }

    @GET
    @Path("/getRoomSummaryByFacilityId")
    public List<RoomSummary> getRoomSummaryByFacilityId(@QueryParam("facilityId") String facilityId, @QueryParam("selectedStatus") String selectedStatus) {
        return service.getRoomSummaryByFacilityId(facilityId, selectedStatus);
    }

    @POST
    @Path("/getRoomSummaryByFacilityIds")
    public List<RoomSummary> getRoomSummaryByFacilityIds(List<FacilityRef> facilityIds) {
        return service.getRoomSummaryByFacilityIds(facilityIds);
    }

    @POST
    @Path("/getSpacesSimpleInfoByFacilityIds")
    public List<RoomSummary> getSpacesSimpleInfoByFacilityIds(List<String> facilityIds, @QueryParam("selectedStatus") String selectedStatus) {
        return service.getSpacesSimpleInfoByFacilityIds(facilityIds, selectedStatus);
    }

    @GET
    @Path("/getRoomSummaryByFloorId")
    public List<RoomSummary> getRoomSummaryByFloorId(@QueryParam("floorId") String floorId, @QueryParam("selectedStatus") String selectedStatus) {
        return service.getRoomSummaryByFloorId(floorId, selectedStatus);
    }

    @GET
    @Path("/getRoomNames")
    public List<String> getRoomNames() {
        return service.getRoomNames();
    }

    @GET
    @Path("/isRoomNumberUnique")
    public boolean isRoomNumberUnique(@QueryParam("facilityId") String facilityId, @QueryParam("roomId") String roomId, @QueryParam("roomNum") String roomNum) {
        return service.isRoomNumberUnique(facilityId, roomId, roomNum);
    }

    @GET
    @Path("/getRoomSummeries")
    public List<RoomSummary> getRoomSummeries(@QueryParam("selectedStatus") String selectedStatus) {
        return service.getRoomSummeries(selectedStatus);
    }

    @POST
    @Path("/createRoom")
    public Space createRoom(Space space) throws ApplicationException {
        return service.createRoom(space);
    }

    @GET
    @Path("/deleteRoom")
    public Boolean deleteRoom(@QueryParam("id") String id) {
        return service.deleteRoom(id);
    }

    @POST
    @Path("/createRooms")
    public BulkUpdateResult createRooms(List<Space> spaces) throws ApplicationException {
        return service.createRooms(spaces);
    }

    ////////////////////////////////////
    // Space - Update Methods...
    ////////////////////////////////////
    @POST
    @Path("/updateRoomAdditional")
    public Space updateRoomAdditional(RoomAdditional roomAdditional) {
        return service.updateRoomAdditional(roomAdditional);
    }

    @POST
    @Path("/updateRoomAttributes")
    public Space updateRoomAttributes(@QueryParam("roomId") String roomId, List<RoomAttribute> roomAttribute) throws ApplicationException {
        return service.updateRoomAttributes(roomId, roomAttribute);
    }

    @POST
    @Path("/updateRoomAudit")
    public Space updateRoomAudit(RoomAudit roomAudit) {
        return service.updateRoomAudit(roomAudit);
    }

    @POST
    @Path("/updateRoomClassification")
    public Space updateRoomClassification(RoomClassification roomClassification) {
        return service.updateRoomClassification(roomClassification);
    }

    @POST
    @Path("/updateRoomCleaningRequirement")
    public Space updateRoomCleaningRequirement(@QueryParam("roomId") String roomId, RoomCleaningRequirement roomCleaningRequirement) {
        return service.updateRoomCleaningRequirement(roomId, roomCleaningRequirement);
    }

    @POST
    @Path("/updateRoomHeader")
    public Space updateRoomHeader(RoomHeader roomHeader) throws ApplicationException {
        return service.updateRoomHeader(roomHeader);
    }

    @POST
    @Path("/updateRoomOccupancy")
    public Space updateRoomOccupancy(@QueryParam("roomId") String roomId, List<OccupantSummary> occupants) {
        return service.updateRoomOccupancy(roomId, occupants);
    }

    @POST
    @Path("/updateRoomMeasurement")
    public Space updateRoomMeasurement(@QueryParam("roomId") String roomId, RoomMeasurement roomMeasurement) {
        return service.updateRoomMeasurement(roomId, roomMeasurement);
    }

    @POST
    @Path("/updateRoomHazards")
    public Space updateRoomHazards(@QueryParam("roomId") String roomId, List<RoomHazard> roomHazards) throws ApplicationException {
        return service.updateRoomHazards(roomId, roomHazards);
    }

    @POST
    @Path("/updateRoomCommunication")
    public Space updateRoomCommunication(RoomCommunication roomCommunication) throws ApplicationException {
        return service.updateRoomCommunication(roomCommunication);
    }

    @POST
    @Path("/updateRoomDataDrops")
    public Space updateRoomDataDrops(@QueryParam("roomId") String roomId, List<RoomDataDrop> roomDataDrops) throws ApplicationException {
        return service.updateRoomDataDrops(roomId, roomDataDrops);
    }

    @GET
    @Path("/updateRoomActive")
    public BulkUpdateResult updateRoomActive(@QueryParam("roomId") String roomId, @QueryParam("isActive") Boolean isActive) throws ApplicationException {
        return service.updateRoomActive(roomId, isActive);
    }

    @POST
    @Path("/saveRoomNote")
    public Space saveRoomNote(@QueryParam("roomId") String roomId, Note roomNote) throws ApplicationException {
        return service.saveRoomNote(roomId, roomNote);
    }

    @GET
    @Path("/deleteRoomNote")
    public Space deleteRoomNote(@QueryParam("roomId") String roomId, @QueryParam("noteId") String noteId) throws ApplicationException {
        return service.deleteRoomNote(roomId, noteId);
    }

    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "Select a file to upload",
                    dataType = "java.io.File", name = "file",
                    paramType = "formData", required = true)
    })
    public FileManager uploadFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) throws ApplicationException {
        byte[] content;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            InputStream inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new ApplicationException("Unable to upload file " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxRoomAttachmentSize();
        if (content.length > maxUploadSize) {
            throw new ApplicationException("File size exceeds max size of " + maxUploadSize + " bytes");
        }

        return service.uploadFile(content, uploadedFileName);
    }

    @GET
    @Path("/getMaxUploadSize")
    public Integer getMaxUploadSize() {
        return service.getMaxUploadSize();
    }

    @POST
    @Path("/saveRoomAttachment")
    public Attachment saveRoomAttachment(@QueryParam("roomId") String roomId, Attachment attachmentToSave) throws ApplicationException {
        return service.saveRoomAttachment(roomId, attachmentToSave);
    }

    @GET
    @Path("/removeRoomAttachment")
    public boolean removeRoomAttachment(@QueryParam("roomId") String roomId, @QueryParam("fileId") String fileId) throws ApplicationException {
        return service.removeRoomAttachment(roomId, fileId);
    }

    @GET
    @Path("/searchRoomSummaries")
    public List<RoomSummary> searchRoomSummaries(@QueryParam("searchInput") String searchInput) {
        return service.searchRoomSummaries(searchInput);
    }

    @GET
    @Path("/getZoneById")
    public Zone getZoneById(@QueryParam("zoneId") String zoneId) {
        return service.getZoneById(zoneId);
    }

    @GET
    @Path("/getZonesByFacilityId")
    public List<Zone> getZonesByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getZonesByFacilityId(facilityId);
    }

    @POST
    @Path("/deleteZoneById")
    public Zone deleteZoneById(@QueryParam("zoneId") String zoneId) throws ApplicationException {
        return service.deleteZoneById(zoneId);
    }

    @POST
    @Path("/addZone")
    public Zone addZone(Zone zone) throws ApplicationException {
        return service.addZone(zone);
    }

    @POST
    @Path("/updateZone")
    public Zone updateZone(Zone zone) throws ApplicationException {
        return service.updateZone(zone);
    }

    @GET
    @Path("/getAllCustomFieldValues")
    public List<CustomFieldValue> getAllCustomFieldValues(@QueryParam("id") String id) {
        return service.getAllCustomFieldValues(id);
    }

    @POST
    @Path("/saveCustomFieldValues")
    public List<CustomFieldValue> saveCustomFieldValues(@QueryParam("id") String id, List<CustomFieldValue> customFieldValues) {
        return service.saveCustomFieldValues(id, customFieldValues);
    }

    @POST
    @Path("/getRoomSearchResults")
    public SearchResult<RoomSummary> getRoomSearchResults(SearchInput searchInput) {
        return service.getRoomSearchResults(searchInput);
    }

    @POST
    @Path("/getFloorSearchResults")
    public SearchResult<Floor> getFloorSearchResults(SearchInput searchInput) {
        return service.getFloorSearchResults(searchInput);
    }

    @POST
    @Path("/getRoomSummariesByAuditDateRange")
    public List<RoomSummary> getRoomSummariesByAuditDateRange(AuditSearch auditSearch) {
        return service.getRoomSummariesByAuditDateRange(auditSearch);
    }

    @GET
    @Path("/getSpaceDashboardCounts")
    public SpaceDashboardInfo getSpaceDashboardCounts() {
        return service.getSpaceDashboardCounts();
    }

    @GET
    @Path("/setOccupantActive")
    public Occupant setOccupantActive(@QueryParam("occupantId") String occupantId, @QueryParam("isActive") Boolean isActive) throws ApplicationException {
        return service.setOccupantActive(occupantId, isActive);
    }

    @POST
    @Path("/bulkUpdateRoomHazardsToRooms")
    public Integer bulkUpdateRoomHazardsToRooms(RoomHazardBulkUpdates roomHazardBulkUpdates) {
        return service.bulkUpdateRoomHazardsToRooms(roomHazardBulkUpdates);
    }

    @POST
    @Path("/bulkUpdateRoomAttributesToRooms")
    public Integer bulkUpdateRoomAttributesToRooms(RoomAttributeBulkUpdates roomAttributeBulkUpdates) {
        return service.bulkUpdateRoomAttributesToRooms(roomAttributeBulkUpdates);
    }

    @POST
    @Path("/bulkUpdateRoomOccupanciesToRooms")
    public Integer bulkUpdateRoomOccupanciesToRooms(RoomOccupancyBulkUpdates roomOccupancyBulkUpdates) {
        return service.bulkUpdateRoomOccupanciesToRooms(roomOccupancyBulkUpdates);
    }

    @POST
    @Path("/bulkUpdateRoomTypeAndCodeToRooms")
    public Integer bulkUpdateRoomTypeAndCodeToRoom(RoomTypeAndCodeBulkUpdate roomTypeAndCodeBulkUpdate) {
        return service.bulkUpdateRoomTypeAndCodeToRoom(roomTypeAndCodeBulkUpdate);
    }

    @POST
    @Path("/bulkUpdateRoomAuditDataToRooms")
    public Integer bulkUpdateRoomAuditDataToRooms(RoomAuditDataBulkUpdate roomAuditDataBulkUpdate) {
        return service.bulkUpdateRoomAuditDataToRooms(roomAuditDataBulkUpdate);
    }

    @GET
    @Path("/getActiveOccupantsBySite")
    public List<Occupant> getActiveOccupantsBySite(@QueryParam("siteId") String siteId, @QueryParam("isActive") Boolean isActive) {
        return service.getActiveOccupantsBySite(siteId, isActive);
    }

    @POST
    @Path("/bulkSetRoomActiveToRooms")
    public BulkUpdateResult bulkSetRoomActiveToRooms(List<String> roomIds) {
        return service.bulkSetRoomActiveToRooms(roomIds);
    }

    @POST
    @Path("/bulkSetRoomInactiveToRooms")
    public BulkUpdateResult bulkSetRoomInactiveToRooms(List<String> roomIds) {
        return service.bulkSetRoomInactiveToRooms(roomIds);
    }

    @POST
    @Path("/bulkUpdateMultiRoomDataToRooms")
    public BulkUpdateResult bulkUpdateMultiRoomDataToRooms(RoomBulkMultiUpdate roomBulkMultiUpdate) {
        return service.bulkUpdateMultiRoomDataToRooms(roomBulkMultiUpdate);
    }

    @POST
    @Path("/getGraphicalSearchRecordsByRoomIds")
    public List<GraphicalSearchRecord> getGraphicalSearchRecordsByRoomIds(List<String> roomIds) {
        return service.getGraphicalSearchRecordsByRoomIds(roomIds);
    }

    @GET
    @Path("/getMaxRoomAttachmentSize")
    public Integer getMaxRoomAttachmentSize() {
        return service.getMaxRoomAttachmentSize();
    }

    @GET
    @Path("/getRpieAssetsForSpace")
    public List<AssetSummary> getRpieAssetsForSpace(@QueryParam("facilityId") String facilityId, @QueryParam("roomId") String roomId) {
        return service.getRpieAssetsForSpace(facilityId, roomId);
    }

    @POST
    @Path("getRoomSummariesByIds")
    public List<RoomSummary> getRoomSummariesByIds(List<String> roomIdList) {
        return service.getRoomSummariesByIds(roomIdList);
    }

    @POST
    @Path("/getZonesByIds")
    public List<Zone> getZonesByIds(List<String> zoneIds) {
        return service.getZonesByIds(zoneIds);
    }

    @POST
    @Path("/getRoomSummariesByFacilityIds")
    public List<RoomSummary> getRoomSummariesByFacilityIds(List<String> facilityIds) {
        return service.getRoomSummariesByFacilityIds(facilityIds);
    }

    @POST
    @Path("/getZonesByFacilityIds")
    public List<Zone> getZonesByFacilityIds(List<String> facilityIds) {
        return service.getZonesByFacilityIds(facilityIds);
    }

    @GET
    @Path("/getSpaceTags")
    public List<TagRef> getSpaceTags() {
        return service.getSpaceTags();
    }

    @GET
    @Path("/getWorkOrdersByRoomId")
    public List<WorkOrder> getWorkOrdersByRoomId(@QueryParam("roomId") String roomId) {
        return service.getWorkOrdersByRoomId(roomId);
    }

    @GET
    @Path("/getDocumentTypes")
    public List<String> getDocumentTypes() {
        return service.getDocumentTypes();
    }

    @GET
    @Path("/getFloorCOBieExportDataByFacilityId")
    public List<FloorCOBieExportData> getFloorCOBieExportDataByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getFloorCOBieExportDataByFacilityId(facilityId);
    }

    @GET
    @Path("/getSpaceCOBieExportDataByFacilityId")
    public List<SpaceCOBieExportData> getSpaceCOBieExportDataByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getSpaceCOBieExportDataByFacilityId(facilityId);
    }

    @POST
    @Path("/getCOBieFloors")
    public List<Floor> getCOBieFloors(List<COBieFloorImportSummary> cobieFloorImportSummaries) {
        return service.getCOBieFloors(cobieFloorImportSummaries);
    }

    @POST
    @Path("/getCOBieSpaces")
    public List<Space> getCOBieSpaces(List<COBieSpaceImportSummary> cobieSpaceImportSummaries) {
        return service.getCOBieSpaces(cobieSpaceImportSummaries);
    }

    @POST
    @Path("/createCOBieZones")
    public BulkUpdateResult createCOBieZones(List<COBieZoneImportSummary> cobieZoneImportSummaries) {
        return service.createCOBieZones(cobieZoneImportSummaries);
    }

    @GET
    @Path("/getDrawingLegend")
    public List<FloorPlanLegendEntry> getDrawingLegend(@QueryParam("floorId") String floorId, @QueryParam("legendType") String legendType) {
        return service.getDrawingLegend(floorId, legendType);
    }
}
