package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetScheduleMicroserviceApi;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.businesscontact.BusinessContact;
import logicole.common.datamodels.asset.businesscontact.BusinessContactRef;
import logicole.common.datamodels.asset.businesscontact.EBusinessContactType;
import logicole.common.datamodels.asset.classification.Nomenclature;
import logicole.common.datamodels.asset.classification.NomenclatureForDropdown;
import logicole.common.datamodels.asset.maintenance.procedure.MaintenanceProcedure;
import logicole.common.datamodels.asset.maintenance.procedure.MaintenanceProcedureRef;
import logicole.common.datamodels.asset.maintenance.procedure.MaintenanceProcedureSummary;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.asset.management.AssetGroup;
import logicole.common.datamodels.asset.management.AssetGroupRef;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.AssetSummary;
import logicole.common.datamodels.asset.schedule.BusinessContactBulkUpdateWrapper;
import logicole.common.datamodels.asset.schedule.FundingSourceBulkUpdateWrapper;
import logicole.common.datamodels.asset.schedule.QualityBulkUpdateWrapper;
import logicole.common.datamodels.asset.schedule.Review;
import logicole.common.datamodels.asset.schedule.Schedule;
import logicole.common.datamodels.asset.schedule.ScheduleRef;
import logicole.common.datamodels.asset.schedule.ScheduleSummary;
import logicole.common.datamodels.asset.schedule.bulk.BulkResponse;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.ECommodityCodeUsageType;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.finance.FundingNodeDTO;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.ProcessingBalance;
import logicole.common.datamodels.finance.datamigration.CommodityCodeRefMigrationWrapper;
import logicole.common.datamodels.general.BulkUpdateResult;
import logicole.common.datamodels.general.EActiveStatus;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.realproperty.RealPropertyFunding;
import logicole.common.datamodels.realproperty.RealPropertyFundingNodeSummary;
import logicole.common.datamodels.realproperty.Site;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.realproperty.facility.FacilitySummary;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.datamodels.ref.ReferenceObject;
import logicole.common.datamodels.space.RoomSummary;
import logicole.common.datamodels.space.SpaceRef;
import logicole.common.datamodels.workorder.Comment;
import logicole.common.datamodels.workorder.EWorkflowStepName;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.datamodels.workorder.WorkOrderSummary;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.DateUtil;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.validation.ScheduleValidator;
import logicole.gateway.services.finance.FinanceAdminService;
import logicole.gateway.services.finance.FinanceDataMigrationService;
import logicole.gateway.services.finance.FinanceReferenceDataService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.realproperty.InstallationService;
import logicole.gateway.services.spacemanagement.SpaceManagementService;
import logicole.gateway.services.workorder.WorkOrderService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@ApplicationScoped
public class AssetScheduleService extends BaseGatewayService<IAssetScheduleMicroserviceApi> {

    @Inject
    AssetClassificationService assetClassificationService;
    @Inject
    AssetMaintenanceProcedureService assetMaintenanceProcedureService;
    @Inject
    AssetService assetService;
    @Inject
    BusinessContactService businessContactService;
    @Inject
    FacilityService facilityService;
    @Inject
    InstallationService installationService;
    @Inject
    SpaceManagementService spaceManagementService;
    @Inject
    WorkOrderService workOrderService;
    @Inject
    OrganizationService organizationService;
    @Inject
    ScheduleValidator scheduleValidator;
    @Inject
    StringUtil stringUtil;
    @Inject
    FinanceDataMigrationService financeDataMigrationService;
    @Inject
    private FinanceAdminService financeAdminService;
    @Inject
    private FinanceReferenceDataService financeReferenceDataService;

    public static final String FM_COMMODITY_USAGE_TYPE = "Facility Management";

    public AssetScheduleService() {
        super("Asset");
    }

    public List<Site> getAllSites() {
        return installationService.getAllSites();
    }

    public List<FacilitySummary> getActiveFacilitiesBySiteUid(String rpsuid) {
        return facilityService.getActiveFacilitiesBySiteUid(rpsuid, true);
    }

    public Facility getFacilityById(String facilityId) {
        return facilityService.getFacilityById(facilityId);
    }

    public List<RoomSummary> getRoomSummariesByFacilityId(String facilityId, String selectedStatus) {
        List<String> facilityIds = new ArrayList<>();
        facilityIds.add(facilityId);
        return spaceManagementService.getSpacesSimpleInfoByFacilityIds(facilityIds, selectedStatus);
    }

    public List<WorkOrderSummary> getWorkOrderSummariesBySchedule(String scheduleId) {
        List<WorkOrderSummary> workOrders = workOrderService.getWorkOrderSummariesBySchedule(scheduleId);
        Schedule schedule = microservice.findScheduleById(scheduleId);

        if (schedule.assetRefs != null && !schedule.assetRefs.isEmpty()) {
            List<String> assetIds = schedule.assetRefs.stream()
                    .map(AssetRef::getId).collect(Collectors.toList());
            List<Asset> assets = assetService.getAssetsByAssetIds(assetIds);
            boolean isAssetAssignedSection = assets.stream()
                    .anyMatch(asset -> asset.sectionRef != null && asset.sectionRef.getId() != null);

            workOrders.stream().forEach(workOrder -> workOrder.isSectionInspectionAllowed = isAssetAssignedSection);
        }


        return workOrders;
    }

    public SearchResult<ScheduleSummary> findSchedules(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getScheduleSearchEngine();

        if (ESearchEngine.ELASTIC.equals(searchEngine)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            organizationService.setRPFuncFilterInSearch(searchInput);
            SearchResult<ScheduleSummary> searchResult = microservice.findSchedules(searchInput);

            if (!ListUtil.isEmpty(searchResult.results)) {
                searchResult.total = (long) searchResult.results.size();
            }

            return searchResult;
        }
    }

    public Schedule findScheduleById(String id) {
        return microservice.findScheduleById(id);
    }

    public ScheduleRef findScheduleRefById(String id) {
        return microservice.findScheduleRefById(id);
    }

    public List<Schedule> findSchedulesByIds(List<String> ids) {
        return microservice.findSchedulesByIds(ids);
    }

    public List<Schedule> findBySiteDodaacAndDmlssScheduleSerial(String siteDodaac, Integer dmlssScheduleSerial) {
        return microservice.findBySiteDodaacAndDmlssScheduleSerial(siteDodaac, dmlssScheduleSerial);
    }

    public Schedule saveNewSchedule(Schedule schedule) {
        if (!ListUtil.isEmpty(schedule.assetRefs)) {
            List<String> assetIds = schedule.assetRefs.stream().map(AssetRef::getId).collect(Collectors.toList());
            addParentManagedAssets(schedule, assetIds, schedule.facilityRef.id);
            List<Asset> assetsByIds = assetService.getAssetsByAssetIds(assetIds);
            populateScheduleSpaceRefsFromAssets(schedule, assetsByIds);
            populateScheduleOtherLocationFromAssets(schedule, assetsByIds);

            if (schedule.maintenanceProcedureRef != null && !StringUtil.isBlankOrNull(schedule.maintenanceProcedureRef.getId())) {
                MaintenanceProcedureSummary scheduleMP = getMaintenanceProcedureSummary(schedule.maintenanceProcedureRef.getId());
                schedule.maintenanceProcedureRef.facilitySystemRef = scheduleMP.facilitySystemRef;
                schedule.maintenanceProcedureRef.facilitySubsystemRef = scheduleMP.facilitySubsystemRef;
            }
        }

        validateSchedule(schedule);
        schedule.scheduleIdentifier = stringUtil.getUniqueIdentifier();
        schedule.managedByOrganizationRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        fillRealPropertyFunding(schedule) ;
        // Need to save to DB to get MongoDB id to pass to WorkOrderService as part of Schedule object
        Schedule scheduleSaved = microservice.saveNewSchedule(schedule);
        workOrderService.createWorkOrdersForScheduleReplace(scheduleSaved);
        return scheduleSaved;
    }

    private MaintenanceProcedureSummary getMaintenanceProcedureSummary(String procedureId) {
        MaintenanceProcedureSummary summary = assetMaintenanceProcedureService.getMaintenanceProcedureSummaryById(procedureId);
        if (summary == null) {
            throw new ApplicationException(
                    String.format("MaintenanceProcedure %s specified for this Schedule was not found", procedureId));
        }
        return summary;
    }

    public List<MaintenanceProcedureRef> getProcedureRefsForNomenclature(String nomenclatureId) {
        return assetMaintenanceProcedureService.getProceduresForNomenclature(nomenclatureId).stream().
                map(MaintenanceProcedure::getRef).collect(Collectors.toList());
    }

    public List<MaintenanceProcedureRef> getRegulatoryComplianceProcedureRefs() {
        return assetMaintenanceProcedureService.getRegulatoryComplianceProcedureRefs();
    }

    public Nomenclature getNomenclatureById(String nomenclatureId) {
        return assetMaintenanceProcedureService.getNomenclatureById(nomenclatureId);
    }

    public List<NomenclatureForDropdown> getNomenclaturesForDropdown() {
        return assetClassificationService.getNomenclaturesForDropdown();
    }

    private void addParentManagedAssets(Schedule schedule, List<String> assetIds, String facilityId) {
        List<AssetRef> childAssets = assetService.getParentManagedChildAssets(assetIds, facilityId);
        schedule.assetRefs.addAll(childAssets);
        List<String> childrenAssetIds = childAssets.stream().map(ReferenceObject::getId).collect(Collectors.toList());
        assetIds.addAll(childrenAssetIds);
    }

    private void populateScheduleSpaceRefsFromAssets(Schedule schedule, List<Asset> assetsByIds) {
        Set<SpaceRef> spaceRefs = assetsByIds.stream()
                .map(asset -> asset.locationInformation.spaceRef)
                .filter(Objects::nonNull)
                .filter(spaceRef -> {
                    return spaceRef.id != null;
                })
                .collect(Collectors.toSet());
        if (!spaceRefs.isEmpty()) {
            schedule.spaceRefs = new ArrayList<>(spaceRefs);
        }
    }

    private void populateScheduleOtherLocationFromAssets(Schedule schedule, List<Asset> assetsByIds) {
        Optional<String> otherLocationOptional = assetsByIds.stream()
                .map(asset -> asset.locationInformation.otherLocation).distinct()
                .filter(Objects::nonNull)
                .reduce((otherLocation, accum) -> accum + ", " + otherLocation);
        otherLocationOptional.ifPresent(locationValue -> schedule.otherLocation = locationValue);
    }

    public void updateScheduleBusinessContact(BusinessContact businessContact) {

        List<Schedule> schedules = microservice.getSchedulesByBusinessContact(businessContact);

        if (schedules != null && !schedules.isEmpty()) {
            for (Schedule schedule : schedules) {
                businessContact.services.forEach(bcService -> {

                    if (bcService.skillRef.id.equals(schedule.scheduleBusinessContact.service.skillRef.id)) {
                        schedule.scheduleBusinessContact.service = bcService;

                        if (bcService.personnel != null && !bcService.personnel.isEmpty()) {

                            if (schedule.scheduleBusinessContact.personnel != null) {
                                bcService.personnel.forEach(bcPersonnel -> {

                                    if (bcPersonnel.personnelId.equals(schedule.scheduleBusinessContact.personnel.personnelId)) {
                                        schedule.scheduleBusinessContact.personnel = bcPersonnel;
                                    }
                                });
                            }
                        } else {
                            schedule.scheduleBusinessContact.personnel = null;
                        }
                    }
                });
                logger.info("Updating schedule {} for Business Contact {} changes", schedule.scheduleIdentifier, businessContact.name);
                updateScheduleDetail(schedule);
            }
        }
    }

    public Schedule updateScheduleDetail(Schedule schedule) {
        return updateScheduleDetail(schedule, false);
    }

    public Schedule updateScheduleDetail(Schedule schedule, boolean forceReplace) {
        validateSchedule(schedule);

        fillRealPropertyFunding(schedule) ;
        
        if (forceReplace || shouldWorkOrdersBeReplaced(schedule)) {
            workOrderService.deleteWorkOrdersBySchedule(schedule.getId());
            workOrderService.createWorkOrdersForScheduleReplace(schedule);
        } else {
            // Big update to WorkOrder, based on data in the Schedule, going way beyond what's in the scheduleRef
            workOrderService.updateScheduledWorkOrders(schedule);
        }
        return microservice.updateScheduleDetail(schedule);
    }

    private boolean migrateFundingFromDMLSS(Schedule schedule) {
		return (schedule.dmlssRealPropertyFunding != null
				&& (schedule.laborFunding == null || schedule.laborFunding.projectFundingNodeRef == null)
				&& (schedule.materialFunding == null || schedule.materialFunding.projectFundingNodeRef == null) );
    }
    
    private void fillRealPropertyFunding(Schedule schedule) {
        // Added for DMLSS=>LC Data migration...
        if (migrateFundingFromDMLSS(schedule)) {
            try {
                FundingNodeRef laborProjectFundingNodeRef = null;
                FundingNodeRef laborExpenseFundingNodeRef = null;
                CommodityCodeRef laborCommodityCodeRef = null;

                FundingNodeRef materialProjectFundingNodeRef = null;
                FundingNodeRef materialExpenseFundingNodeRef = null;
                CommodityCodeRef materialCommodityCodeRef = null;

                // Get the labor FundingNodeRef...
                if (schedule.dmlssRealPropertyFunding.projectCenterSerial > 0) {
                    laborProjectFundingNodeRef = financeDataMigrationService.getProjectCenterByMigrationId(schedule.dmlssRealPropertyFunding.siteDodaac + "." +
                            schedule.dmlssRealPropertyFunding.projectCenterSerial);
                }
                if (schedule.dmlssRealPropertyFunding.expenseCenterSerial > 0) {
                    laborExpenseFundingNodeRef = financeDataMigrationService.getExpenseCenterByMigrationId(schedule.dmlssRealPropertyFunding.siteDodaac + "." +
                            schedule.dmlssRealPropertyFunding.expenseCenterSerial);
                }
                if (schedule.dmlssRealPropertyFunding.eorCode != null) {
                    CommodityCodeRefMigrationWrapper codeRefMigrationWrapper = new CommodityCodeRefMigrationWrapper();

                    CommodityCodeRef laborMigrationCode = new CommodityCodeRef();
                    laborMigrationCode.code = schedule.dmlssRealPropertyFunding.eorCode;
                    laborMigrationCode.name = schedule.dmlssRealPropertyFunding.eorName;
                    codeRefMigrationWrapper.commodityCodeRef = laborMigrationCode;

                    codeRefMigrationWrapper.commodityUsageType = FM_COMMODITY_USAGE_TYPE;
                    codeRefMigrationWrapper.organizationId = schedule.managedByOrganizationRef.id;

                    laborCommodityCodeRef = financeDataMigrationService.getCommodityCodeRef(codeRefMigrationWrapper);
                }

                if (laborProjectFundingNodeRef != null && laborExpenseFundingNodeRef != null && laborCommodityCodeRef != null) {
                    RealPropertyFunding laborFunding = new RealPropertyFunding();

                    laborFunding.projectFundingNodeRef = laborProjectFundingNodeRef;
                    laborFunding.expenseFundingNodeRef = laborExpenseFundingNodeRef;
                    laborFunding.commodityCodeRef = laborCommodityCodeRef;

                    schedule.laborFunding = laborFunding;
                }
                // Get the material FundingNodeRef...
                if ((schedule.dmlssRealPropertyFunding.equipmentProjectCenterSerial != null) &&
                        (schedule.dmlssRealPropertyFunding.equipmentProjectCenterSerial > 0)) {
                    materialProjectFundingNodeRef = financeDataMigrationService.getProjectCenterByMigrationId(schedule.dmlssRealPropertyFunding.siteDodaac + "." +
                            schedule.dmlssRealPropertyFunding.equipmentProjectCenterSerial);
                }
                if ((schedule.dmlssRealPropertyFunding.equipmentExpenseCenterSerial != null) &&
                        (schedule.dmlssRealPropertyFunding.equipmentExpenseCenterSerial > 0)) {
                    materialExpenseFundingNodeRef = financeDataMigrationService.getExpenseCenterByMigrationId(schedule.dmlssRealPropertyFunding.siteDodaac + "." +
                            schedule.dmlssRealPropertyFunding.equipmentExpenseCenterSerial);
                }
                if (schedule.dmlssRealPropertyFunding.equipmentEorCode != null) {
                    CommodityCodeRefMigrationWrapper materialcodeRefMigrationWrapper = new CommodityCodeRefMigrationWrapper();
                    CommodityCodeRef materialMigrationCode = new CommodityCodeRef();

                    materialMigrationCode.code = schedule.dmlssRealPropertyFunding.equipmentEorCode;
                    materialMigrationCode.name = schedule.dmlssRealPropertyFunding.equipmentEorName;
                    materialcodeRefMigrationWrapper.commodityCodeRef = materialMigrationCode;

                    materialcodeRefMigrationWrapper.commodityUsageType = FM_COMMODITY_USAGE_TYPE;
                    materialcodeRefMigrationWrapper.organizationId = schedule.managedByOrganizationRef.id;

                    materialCommodityCodeRef = financeDataMigrationService.getCommodityCodeRef(materialcodeRefMigrationWrapper);
                }

                if (materialProjectFundingNodeRef != null && materialExpenseFundingNodeRef != null && materialCommodityCodeRef != null) {
                    RealPropertyFunding materialFunding = new RealPropertyFunding();

                    materialFunding.projectFundingNodeRef = materialProjectFundingNodeRef;
                    materialFunding.expenseFundingNodeRef = materialExpenseFundingNodeRef;
                    materialFunding.commodityCodeRef = materialCommodityCodeRef;

                    schedule.materialFunding = materialFunding;
                }
            } catch (ApplicationException e) {
                logger.error("An error occurred while migrating the DMLSS Funds:",
                      e.getMessage());
            }
        } else {
            if (schedule.laborFunding != null) {
                workOrderService.populateRealPropertyFunding(schedule.laborFunding);
            }
            if (schedule.materialFunding != null) {
                workOrderService.populateRealPropertyFunding(schedule.materialFunding);
            }
        }
    }

    private boolean shouldWorkOrdersBeReplaced(Schedule schedule) {
        return microservice.shouldWorkOrdersBeReplaced(schedule);
    }

    private void validateSchedule(Schedule schedule) {
        if (schedule.maintenanceProcedureRef == null || StringUtil.isBlankOrNull(schedule.maintenanceProcedureRef.getId())) {
            throw new ApplicationException("MaintenanceProcedureRef is required");
        }
        boolean assetValidationRequired = !Objects.equals(schedule.maintenanceProcedureRef.procedureType, "Regulatory Compliance");
        scheduleValidator.validate(schedule, assetValidationRequired);
        List<Schedule> schedulesByAssetIds = getSchedulesByAssetIds(schedule.assetRefs.stream().map(AssetRef::getId).collect(Collectors.toList()));
        scheduleValidator.validateNoDuplicates(schedule, schedulesByAssetIds);

        ensureLegacyScheduleIsUnique(schedule);

    }

    private void ensureLegacyScheduleIsUnique(Schedule schedule) {
        if (schedule.dmlssScheduleSerial != null && schedule.facilityRef != null &&
                !StringUtil.isBlankOrNull(schedule.facilityRef.siteDodaac)) {
            List<Schedule> persistedSchedules = findBySiteDodaacAndDmlssScheduleSerial(
                    schedule.facilityRef.siteDodaac, schedule.dmlssScheduleSerial);
            if (!ListUtil.isEmpty(persistedSchedules)) {
                if (!StringUtil.isBlankOrNull(schedule.getId()) && persistedSchedules.size() > 1) {
                    throw new ApplicationException(String.format("Schedule already exists (siteDodaac %s, dmlssScheduleSerial %d)",
                            schedule.facilityRef.siteDodaac, schedule.dmlssScheduleSerial));
                }
            }
        }
    }

    public void deleteSchedule(String id) {
        Schedule schedule = microservice.findScheduleById(id);
        workOrderService.deleteScheduleWorkOrders(schedule);
        microservice.deleteSchedule(id);
    }

    public List<Schedule> getSchedulesByAssetId(String assetId) {
        return microservice.getSchedulesByAssetId(assetId);
    }

    public List<Schedule> getSchedulesByAssetIds(List<String> assetIds) {
        return microservice.getSchedulesByAssetIds(assetIds);
    }

    public List<MaintenanceProcedure> getProceduresForNomenclature(String id) {
        return assetMaintenanceProcedureService.getProceduresForNomenclature(id);
    }

    public List<BusinessContact> getMaintenanceBusinessContactsBySkill(String skillId) {
        List<String> businessTypes = new ArrayList<>();
        businessTypes.add(EBusinessContactType.MAINTENANCE_ACTIVITY_IN_HOUSE.name());
        businessTypes.add(EBusinessContactType.MAINTENANCE_ACTIVITY_OUTSOURCED.name());
        businessTypes.add(EBusinessContactType.ENVIRONMENTAL_SERVICE_IN_HOUSE.name());
        businessTypes.add(EBusinessContactType.ENVIRONMENTAL_SERVICE_OUTSOURCED.name());
        businessTypes.add(EBusinessContactType.GOVERNMENT_AGENCY.name());
        return businessContactService.getBusinessContactByType(businessTypes);
    }

    public BusinessContactRef getBusinessContactRef(String id) {
        BusinessContact businessContact = businessContactService.getBusinessContactById(id);
        if (businessContact != null) {
            return businessContact.getRef();
        } else {
            return null;
        }
    }

    public List<MaintenanceProcedureRef> getProcedureRefsWithSameNomenclature(String nomenclatureId) {
        return assetMaintenanceProcedureService.getProcedureRefsWithSameNomenclature(nomenclatureId);
    }

    public boolean schedulesExistForMaintenanceProcedure(String maintenanceProcedureId) {
        return microservice.schedulesExistForMaintenanceProcedure(maintenanceProcedureId);
    }

    public Schedule addNote(String id, Note note) {
        return microservice.addNote(id, note);
    }

    public Schedule saveNote(String id, Note note) {
        return microservice.saveNote(id, note);
    }

    public Schedule removeNote(String id, Note note) {
        return microservice.removeNote(id, note);
    }

    public List<String> getScheduleIdsByMaintenanceProcedureId(String maintenanceProcedureId) {
        return microservice.getScheduleIdsByMaintenanceProcedureId(maintenanceProcedureId);
    }

    public Schedule updateMaintenanceProcedureRef(String scheduleId, MaintenanceProcedureRef newMaintProcRef) {
        Schedule schedule = microservice.updateMaintenanceProcedureRef(scheduleId, newMaintProcRef);

        // Big update to WorkOrder, based on data in the Schedule, going way beyond what's in the scheduleRef
        workOrderService.updateScheduledWorkOrders(schedule);

        return schedule;
    }

    public List<Schedule> getYearlyAndMonthlySchedulesByAssetAndSkill(String assetId,
                                                                      String skillId,
                                                                      String scheduleIdToExclude) {
        return microservice.getYearlyAndMonthlySchedulesByAssetAndSkill(assetId, skillId, scheduleIdToExclude);
    }

    public void updateWorkOrderIsDeferred(String id, boolean isDeferred, String reason) {
        WorkOrder workOrder = new WorkOrder();
        workOrder.setId(id);
        workOrder.newComment = new Comment();
        workOrder.newComment.text = reason;

        if (isDeferred) {
            workOrderService.defer(workOrder);
        } else {
            workOrderService.unDefer(workOrder);
        }
    }

    public int updateSectionInspectionForWorkOrders(List<String> workOrderIds, boolean isSectionInspection) {
        return workOrderService.updateSectionInspectionForWorkOrders(workOrderIds, isSectionInspection).successfulItems.size();
    }

    public WorkOrder openNextScheduledWorkOrder(String scheduleId) {
        Schedule schedule = microservice.findScheduleById(scheduleId);
        if (schedule == null) {
            throw new ApplicationException(String.format("Schedule not found with id of %s", scheduleId));
        }
        WorkOrderSummary nextWorkOrderSummary = getNextScheduledWorkOrder(schedule);
        WorkOrder nextWorkOrder = workOrderService.openScheduled(nextWorkOrderSummary.getId());
        nextWorkOrder = workOrderService.saveWorkOrder(nextWorkOrder);
        workOrderService.createWorkOrdersForScheduleAppend(schedule);

        return nextWorkOrder;
    }

    private WorkOrderSummary getNextScheduledWorkOrder(Schedule schedule) {
        List<Integer> stepPositions = Arrays.asList(EWorkflowStepName.SCHEDULED.position, EWorkflowStepName.IN_PROGRESS.position);
        List<WorkOrderSummary> workOrderSummaries = workOrderService.getWorkOrderSummariesBySchedule(schedule.getId());
        Optional<WorkOrderSummary> nextWorkOrderSummaryOptional = workOrderSummaries.stream()
                .filter(workOrderSummary -> stepPositions.contains(workOrderSummary.workflowCurrentPosition))
                .min((wo1, wo2) -> DateUtil.safeDateCompare(wo1.estimatedStartDate, wo2.estimatedStartDate));

        WorkOrderSummary nextWorkOrderSummary;
        if (nextWorkOrderSummaryOptional.isPresent()) {
            nextWorkOrderSummary = nextWorkOrderSummaryOptional.get();
        } else {
            throw new ApplicationException(String.format("No Work Order available for Schedule %s", schedule.getId()));
        }

        int openWorkOrderFutureDaysThreshold = getOpenWorkOrderFutureDaysThresholdConfig();
        if (!DateUtil.dateIsLessThanNNDaysFromToday(nextWorkOrderSummary.estimatedStartDate, openWorkOrderFutureDaysThreshold)) {
            throw new ApplicationException(
                    String.format("For Schedule %s, there are no Work Orders scheduled between today and %d days from today",
                            schedule.getId(), openWorkOrderFutureDaysThreshold));
        }

        return nextWorkOrderSummary;
    }

    public int getOpenWorkOrderFutureDaysThresholdConfig() {
        return microservice.getOpenWorkOrderFutureDaysThresholdConfig();
    }

    public BulkResponse bulkUpdateBusinessContact(BusinessContactBulkUpdateWrapper businessContactBulkUpdateWrapper) {
        if (businessContactBulkUpdateWrapper.ids == null || businessContactBulkUpdateWrapper.ids.isEmpty()) {
            throw new ApplicationException("At least one schedule is required to perform the bulk update.");
        }

        validateBulkUpdateRecordLimit(businessContactBulkUpdateWrapper.ids.size());
        String businessContactId = businessContactBulkUpdateWrapper.scheduleBusinessContact.businessContactRef.id;
        BusinessContact businessContact = businessContactService.getBusinessContactById(businessContactId);
        if (businessContact == null) {
            throw new ApplicationException(
                    String.format("Could not find BusinessContact with id of %s", businessContactId));
        }

        BulkResponse bulkResponse = microservice.bulkUpdateBusinessContact(businessContactBulkUpdateWrapper);
        // Big update to WorkOrder, based on data in the Schedule, going way beyond what's in the scheduleRef
        workOrderService.updateBulkScheduledWorkOrders(bulkResponse.successfulItems);
        return bulkResponse;
    }

    private void validateBulkUpdateRecordLimit(int recordsToProcessCount) {
        int limit = microservice.getBulkUpdateRecordLimit();
        if (recordsToProcessCount > limit) {
            throw new ApplicationException(String.format("Bulk update operation is limited to %s records", limit));
        }
    }

    public Integer bulkUpdateQualityAssurance(QualityBulkUpdateWrapper qualityBulkUpdateWrapper) {
        return microservice.bulkUpdateQualityAssurance(qualityBulkUpdateWrapper);
    }

    public Integer bulkUpdateQualityControl(QualityBulkUpdateWrapper qualityBulkUpdateWrapper) {
        return microservice.bulkUpdateQualityControl(qualityBulkUpdateWrapper);
    }

    public BulkUpdateResult bulkUpdateFundingSource(FundingSourceBulkUpdateWrapper wrapper) {
        RealPropertyFunding labor = wrapper.laborFunding;
        RealPropertyFunding material = wrapper.materialFunding;

        boolean laborProjectCenterIsEmpty = labor == null || labor.projectFundingNodeRef == null || labor.projectFundingNodeRef.getId() == null;
        boolean laborExpenseCenterIsEmpty = labor == null || labor.expenseFundingNodeRef == null || labor.expenseFundingNodeRef.getId() == null;
        boolean laborCommodityClassIsEmpty = labor == null || labor.commodityCodeRef == null || labor.commodityCodeRef.getId() == null;

        if (!laborProjectCenterIsEmpty && !laborExpenseCenterIsEmpty && !laborCommodityClassIsEmpty){
            workOrderService.populateRealPropertyFunding(wrapper.laborFunding);
        } else {
            if (laborProjectCenterIsEmpty && laborExpenseCenterIsEmpty && laborCommodityClassIsEmpty) {
                wrapper.laborFunding = null;
            } else {
                throw new ApplicationException("All Labor Funding values must be supplied if one Labor Funding value is supplied.");
            }
        }

        boolean materialProjectCenterIsEmpty = material == null || material.projectFundingNodeRef == null || material.projectFundingNodeRef.getId() == null;
        boolean materialExpenseCenterIsEmpty = material == null || material.expenseFundingNodeRef == null || material.expenseFundingNodeRef.getId() == null;
        boolean materialCommodityClassIsEmpty = material == null || material.commodityCodeRef == null || material.commodityCodeRef.getId() == null;

        if (!materialProjectCenterIsEmpty && !materialExpenseCenterIsEmpty && !materialCommodityClassIsEmpty){
            if (!laborProjectCenterIsEmpty){
                if (labor.projectFundingNodeRef.getId().equals(material.projectFundingNodeRef.getId())
                        && labor.expenseFundingNodeRef.getId().equals(material.expenseFundingNodeRef.getId())
                        && labor.commodityCodeRef.getId().equals(material.commodityCodeRef.getId())) {
                    throw new ApplicationException("Labor Project/Expense/Commodity and Material Project/Expense/Commodity must be different.");
                } else {
                    workOrderService.populateRealPropertyFunding(wrapper.materialFunding);
                }
            } else {
                workOrderService.populateRealPropertyFunding(wrapper.materialFunding);
            }
        } else
            if (materialProjectCenterIsEmpty && materialExpenseCenterIsEmpty && materialCommodityClassIsEmpty) {
                wrapper.materialFunding = null;
            } else {
               throw new ApplicationException("All Material Funding values must be supplied if one Material Funding value is supplied.");
            }

        return microservice.bulkUpdateFundingSource(wrapper);
    }

    public BulkUpdateResult bulkDeleteMaterialFundingSource(FundingSourceBulkUpdateWrapper wrapper) {
        return microservice.bulkDeleteMaterialFundingSource(wrapper);
    }

    public Schedule saveReview(String id, Review review) {
        return microservice.saveReview(id, review);
    }

    public void processAssetRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processAssetRefUpdate(dataReferenceUpdate);
    }

    public void processFacilityRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processFacilityRefUpdate(dataReferenceUpdate);
    }

    public void processSpaceRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processSpaceRefUpdate(dataReferenceUpdate);
    }

    public void updateAssetGroupSchedules(AssetGroup assetGroup) {
        List<Asset> assetsByGroupId = assetService.getAssetsByGroupId(assetGroup.getId());
        List<AssetRef> assetRefs = assetsByGroupId.stream().map(Asset::getRef).collect(Collectors.toList());
        List<Schedule> schedulesByAssetGroupId = microservice.getSchedulesByAssetId(assetGroup.getId());
        schedulesByAssetGroupId.forEach(schedule -> {
            schedule.assetRefs = assetRefs;
            Schedule updatedSchedule = microservice.updateScheduleAssetRefs(schedule);
            workOrderService.updateAssetGroupScheduledWorkOrderAssetRefs(updatedSchedule);
        });
    }

    public void processAssetGroupRefUpdate(DataReferenceUpdate dataReferenceUpdate) throws IOException {
        microservice.processAssetGroupRefUpdate(dataReferenceUpdate);
    }

    public void deleteAssetGroupSchedules(String assetGroupId) {
        List<Schedule> schedulesByAssetGroupId = microservice.getSchedulesByAssetId(assetGroupId);
        schedulesByAssetGroupId.forEach(schedule -> deleteSchedule(schedule.getId()));
    }

    public void scheduleExistsForGroup(String assetGroupId) {
        List<Schedule> schedulesByAssetGroupId = microservice.getSchedulesByAssetId(assetGroupId);
        if (schedulesByAssetGroupId != null && !schedulesByAssetGroupId.isEmpty()) {
            throw new ApplicationException("This Group has at least one Schedule.  Groups with Schedules may not be deleted.");
        }
    }

    public List<String> findIdsByScheduleIdentifier(String scheduleIdentifier) {
        return microservice.findIdsByScheduleIdentifier(scheduleIdentifier);
    }

    public List<MaintenanceProcedureRef> getMaintenanceProcedureRefs() {
        String currentNodeId = currentUserBT.getCurrentNodeId();
        return assetMaintenanceProcedureService.getProceduresForOrganization(currentNodeId).stream().map(MaintenanceProcedure::getRef).collect(Collectors.toList());
    }

    public List<AssetSummary> getAssetSummariesByFacilityId(String facilityId) {
        return assetService.getAssetSummariesByFacilityId(facilityId, true, EActiveStatus.ALL);
    }

    public List<AssetSummary> getAssetSummariesByFacilityIdAndProcedureId(String facilityId, String procedureId) {
        MaintenanceProcedure procedure = assetMaintenanceProcedureService.findById(procedureId);
        if (procedure == null || procedure.nomenclatureRef == null || procedure.nomenclatureRef.id == null) {
            throw new ApplicationException("Invalid procedureId");
        }
        return assetService.getAssetSummariesByFacilityIdAndNomenclatureId(facilityId, procedure.nomenclatureRef.id);
    }

    public List<AssetGroup> getAssetGroupsByFacilityId(String facilityId) {
        return assetService.getAssetGroupsByFacilityId(facilityId);
    }

    public List<AssetGroup> getAssetGroupsByFacilityIdAndProcedureId(String facilityId, String procedureId) {
        MaintenanceProcedure procedure = assetMaintenanceProcedureService.findById(procedureId);
        if (procedure == null || procedure.nomenclatureRef == null || procedure.nomenclatureRef.id == null) {
            throw new ApplicationException("Invalid procedureId");
        }
        return assetService.getAssetGroupsByFacilityIdAndNomenclatureId(facilityId, procedure.nomenclatureRef.id);
    }

    public List<AssetSummary> getAssetSummariesByAssetGroupId(String assetGroupId) {
        return assetService.getAssetSummariesByAssetGroupId(assetGroupId);
    }

    public long getActiveScheduleCountByAssetId(String assetId) {
        return microservice.getActiveScheduleCountByAssetId(assetId);
    }

    public void onCreateAsset(Asset asset) {
        if (asset != null &&
                asset.parentAssetRef != null &&
                asset.parentAssetRef.getId() != null
                && asset.maintenanceInformation != null &&
                asset.maintenanceInformation.isMaintenancePerformedOnParentAsset) {
            addRemoveAsset(asset, EAssetScheduleUpdateOption.ADD);
        }
    }

    public void onUpdateAssetAssembly(Asset asset,
                                      Asset persisted) {
        boolean isMaintenancePerformedOnParentAsset = asset.maintenanceInformation.isMaintenancePerformedOnParentAsset;
        boolean isPersistedMaintenancePerformedOnParentAsset = persisted.maintenanceInformation.isMaintenancePerformedOnParentAsset;
        if (isMaintenancePerformedOnParentAsset == isPersistedMaintenancePerformedOnParentAsset) {
            if (!Objects.equals(asset.parentAssetRef, persisted.parentAssetRef)) {
                if (!isMaintenancePerformedOnParentAsset) {
                    return;
                } else {
                    addRemoveAsset(persisted, EAssetScheduleUpdateOption.REMOVE);
                    addRemoveAsset(asset, EAssetScheduleUpdateOption.ADD);
                }
            }
        } else {
            if (isPersistedMaintenancePerformedOnParentAsset) {
                addRemoveAsset(persisted, EAssetScheduleUpdateOption.REMOVE);
            } else {
                addRemoveAsset(asset, EAssetScheduleUpdateOption.ADD);
            }
        }
    }

    public void onActiveChange(String assetId, EAssetScheduleUpdateOption option) {
        Asset asset = assetService.getAssetById(assetId);
        if (asset.maintenanceInformation.isMaintenancePerformedOnParentAsset) {
            addRemoveAsset(asset, option);
        }
    }

    void addRemoveAsset(Asset asset, EAssetScheduleUpdateOption updateOption) {

        AssetRef assetRef = asset.getRef();
        List<Schedule> assetSchedules = microservice.getSchedulesByAssetId(asset.parentAssetRef.id);
        alterScheduleDetails(assetRef, assetSchedules, updateOption);

        if (asset.parentAssetRef != null && asset.parentAssetRef.id != null) {
            Asset parent = assetService.getAssetById(asset.parentAssetRef.id);
            if (parent.assetGroupRef != null && parent.assetGroupRef.id != null) {
                List<Schedule> groupSchedules = microservice.getSchedulesByAssetGroupId(parent.assetGroupRef.id);
                alterScheduleDetails(assetRef, groupSchedules, updateOption);
            }
        }
    }

    void alterScheduleDetails(AssetRef assetRef, List<Schedule> schedules, EAssetScheduleUpdateOption updateOption) {
        for (Schedule schedule : schedules) {
            if (EAssetScheduleUpdateOption.ADD == updateOption) {
                if (!schedule.assetRefs.contains(assetRef)) {
                    schedule.assetRefs.add(assetRef);
                }
            } else {
                schedule.assetRefs.remove(assetRef);
            }
            updateScheduleDetail(schedule);
        }
    }

    public void addRemoveAssetGroupRelationship(AssetGroupRef realPropertyEquipmentGroup,
                                                List<Asset> assets,
                                                EAssetScheduleUpdateOption option) {
        List<Schedule> schedules = microservice.getSchedulesByAssetGroupId(realPropertyEquipmentGroup.id);
        for (Schedule schedule : schedules) {
            boolean hasScheduleChanges = false;
            for (Asset asset : assets) {
                AssetRef assetRef = asset.getRef();
                if (EAssetScheduleUpdateOption.ADD == option) {
                    if (!schedule.assetRefs.contains(assetRef)) {
                        schedule.assetRefs.add(assetRef);
                    }
                } else {
                    schedule.assetRefs.remove(assetRef);
                }
                if (hasScheduleChanges) {
                    microservice.updateScheduleDetail(schedule);
                }
            }
        }
    }

    public void addRemoveAssetGroupRelationship(String assetId, String assetGroupId, EAssetScheduleUpdateOption option) {
        List<String> assetIds = Arrays.asList(assetId);
        addRemoveAssetGroupRelationship(assetGroupId, assetIds, option);
    }

    public void addRemoveAssetGroupRelationship(String assetGroupId, List<String> assetIds, EAssetScheduleUpdateOption option) {
        List<Asset> assets = assetService.getAssetsByAssetIds(assetIds);
        List<AssetRef> assetRefs = assets.stream().map(Asset::getRef).collect(Collectors.toList());
        addRemoveAssetGroupRelationship(assetRefs, assetGroupId, option);
    }

    public void addRemoveAssetGroupRelationship(List<AssetRef> assetRefs, String assetGroupId, EAssetScheduleUpdateOption option) {

        List<Schedule> schedules = microservice.getSchedulesByAssetGroupId(assetGroupId);
        for (Schedule schedule : schedules) {
            boolean hasScheduleChanges = false;
            for (AssetRef ref : assetRefs) {
                if (EAssetScheduleUpdateOption.ADD == option) {
                    if (!containsAssetRef(schedule.assetRefs, ref)) {
                        schedule.assetRefs.add(ref);
                        hasScheduleChanges = true;
                    }
                } else {
                    if (containsAssetRef(schedule.assetRefs, ref)) {
                        schedule.assetRefs.remove(ref);
                        hasScheduleChanges = true;
                    }
                }
            }
            if (hasScheduleChanges) {
                microservice.updateScheduleDetail(schedule);
            }
        }
    }

    public boolean containsAssetRef(final List<AssetRef> list, final AssetRef ref) {
        return list.stream().anyMatch(o -> o.identifier.equals(ref.identifier));
    }

    public enum EAssetScheduleUpdateOption {
        ADD,
        REMOVE
    }
    
    public List<RealPropertyFundingNodeSummary> getProjectFundingNodeSummaries(String organizationNodeId) {
    	if (StringUtil.isEmptyOrNull(organizationNodeId)) {
    		throw new ApplicationException("Organization node Id must be passed");
    	}
   
    	List<RealPropertyFundingNodeSummary> projectNodeSummaries = new ArrayList<>();
    	List<FundingNodeDTO> projectNodes = financeAdminService.getMemorandumFunds(organizationNodeId);
    	if ( !ListUtil.isEmpty(projectNodes)) {
    		projectNodeSummaries = projectNodes.stream().map(fundingNodeDTO -> new RealPropertyFundingNodeSummary(fundingNodeDTO.fundingNodeRef)).collect(Collectors.toList());
    	}

    	return projectNodeSummaries;
    }
 
    public List<RealPropertyFundingNodeSummary> getExpenseFundingNodeSummaries( String projectFundingNodeId) {
    	if (StringUtil.isEmptyOrNull(projectFundingNodeId)) {
    		throw new ApplicationException("Project funding node Id must be passed");
    	}
    	
    	ProcessingBalance projectFundingPB = financeAdminService.getFundingNodeById(projectFundingNodeId);
    	List<RealPropertyFundingNodeSummary> expenseNodeSummaries = new ArrayList<>();
    	if ( projectFundingPB != null && !ListUtil.isEmpty(projectFundingPB.fundingNode.children)) {
    		expenseNodeSummaries = projectFundingPB.fundingNode.children.stream().map(child -> new RealPropertyFundingNodeSummary(child.getRef())).collect(Collectors.toList());
    	}

    	return expenseNodeSummaries;
    }
  
    public List<CommodityCodeRef> getCommodityCodeRefs(String organizationNodeId ) {
    	if (StringUtil.isEmptyOrNull(organizationNodeId)) {
    		throw new ApplicationException("Organization node Id must be passed");
    	}
  
    	List<CommodityCodeRef> commodityCodeRefs = new ArrayList<>();
    	FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(organizationNodeId);
    	if ( financialSystem != null && !StringUtil.isEmptyOrNull(financialSystem.getId())) {
    		commodityCodeRefs = financeReferenceDataService.getCommodityCodesBySystemAndUsage(financialSystem.getId(), ECommodityCodeUsageType.FM);
    	}
    	
    	return commodityCodeRefs;
    }

}
