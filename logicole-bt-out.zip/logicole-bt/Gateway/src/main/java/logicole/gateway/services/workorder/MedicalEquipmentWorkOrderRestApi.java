package logicole.gateway.services.workorder;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.maintenance.technician.TechnicianRef;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.workflow.WorkflowStepSummary;
import logicole.common.datamodels.workorder.MedicalEquipmentWorkOrderDashboardInfo;
import logicole.common.datamodels.workorder.PriorityGroup;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.datamodels.workorder.WorkOrderType;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Api(tags = {"MedicalEquipmentWorkOrder"})
@ApplicationScoped
@Path("/medicalEquipmentWorkOrder")
public class MedicalEquipmentWorkOrderRestApi extends ExternalRestApi<MedicalEquipmentWorkOrderService> {

    private static final String FILE_SIZE_ERROR_TEMPLATE = "Uploaded file size exceeds server max POST Size value of %s bytes";
    public static final String FILE_EXTRACTION_ERROR_TEMPLATE = "Was not able to extract file from request %s";

    @Inject
    private MultiPartFormUtil uploadUtil;

    @GET
    @Path("/findById")
    public WorkOrder findById(@NotNull @QueryParam("id") String id) {
        return service.findById(id);
    }

    @POST
    @Path("/getWorkOrders")
    public SearchResult<WorkOrder> getWorkOrders(SearchInput searchInput) {
        return service.getWorkOrders(searchInput);
    }

    @GET
    @Path("/getWorkOrderDashboardStats")
    public MedicalEquipmentWorkOrderDashboardInfo getWorkOrderDashboardStats() {
        return service.getWorkOrderDashboardStats();
    }

    @POST
    @Path("/addNote")
    public WorkOrder addNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.addNote(id, note);
    }

    @POST
    @Path("/saveNote")
    public WorkOrder saveNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.saveNote(id, note);
    }

    @POST
    @Path("/removeNote")
    public WorkOrder removeNote(@NotNull @QueryParam("id") String id, Note note) {
        return service.removeNote(id, note);
    }

    @GET
    @Path("/getMaxUploadSize")
    public Integer getMaxUploadSize() {
        return service.getMaxUploadSize();
    }

    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        byte[] content;
        try (InputStream inputStream = inputPart.getBody(InputStream.class, null)) {
            content = IOUtils.toByteArray(inputStream);
            Integer maxUploadSize = service.getMaxUploadSize();
            if (content.length > maxUploadSize) {
                throw new FatalProcessingException(String.format(FILE_SIZE_ERROR_TEMPLATE, maxUploadSize));
            }

            return service.uploadFile(content, uploadedFileName);
        } catch (IOException ioe) {
            throw new FatalProcessingException(String.format(FILE_EXTRACTION_ERROR_TEMPLATE, uploadedFileName));
        }
    }

    @POST
    @Path("/saveAttachment")
    public Attachment saveAttachment(@NotNull @QueryParam("id") String id, Attachment attachmentToSave) {
        return service.saveAttachment(id, attachmentToSave);
    }

    @GET
    @Path("/removeAttachment")
    public List<Attachment> removeAttachment(@NotNull @QueryParam("id") String id, @NotNull @QueryParam("fileId") String fileId)
            throws IOException {
        return service.removeAttachment(id, fileId);
    }

    @GET
    @Path("/getWorkOrderTypes")
    public List<WorkOrderType> getWorkOrderTypes() {
        return service.getWorkOrderTypes();
    }

    @GET
    @Path("/getUnscheduledWorkOrderTypes")
    public List<WorkOrderType> getUnscheduledWorkOrderTypes() {
        return service.getUnscheduledWorkOrderTypes();
    }

    @GET
    @Path("/getScheduledWorkOrderTypes")
    public List<WorkOrderType> getScheduledWorkOrderTypes() {
        return service.getScheduledWorkOrderTypes();
    }

    @GET
    @Path("/getPriorityGroups")
    public List<PriorityGroup> getPriorityGroups() {
        return service.getPriorityGroups();
    }

    @GET
    @Path("/getWorkLocationOptions")
    public List<String> getWorkLocationOptions() {
        return service.getWorkLocationOptions();
    }

    @POST
    @Path("/saveGeneralInformation")
    public WorkOrder saveGeneralInformation(@NotNull WorkOrder workOrder) {
        return service.saveGeneralInformation(workOrder);
    }

    @POST
    @Path("/savePersonnel")
    public WorkOrder savePersonnel(@NotNull WorkOrder workOrder) {
        return service.savePersonnel(workOrder);
    }

    @POST
    @Path("/saveServiceInformation")
    public WorkOrder saveServiceInformation(@NotNull WorkOrder workOrder) {
        return service.saveServiceInformation(workOrder);
    }

    @POST
    @Path("setWorkInProgress")
    public WorkOrder setWorkInProgress(WorkOrder workOrder) {
        return service.setWorkInProgress(workOrder);
    }

    @POST
    @Path("hold")
    public WorkOrder hold(WorkOrder workOrder) {
        return service.hold(workOrder);
    }

    @POST
    @Path("resume")
    public WorkOrder resume(WorkOrder workOrder) {
        return service.resume(workOrder);
    }

    @POST
    @Path("/complete")
    public WorkOrder complete(WorkOrder workOrder) {
        return service.complete(workOrder);
    }

    @POST
    @Path("/buildWorkflowStepSummary")
    public List<WorkflowStepSummary> buildWorkflowStepSummary(WorkOrder workOrder) {
        return service.buildWorkflowStepSummary(workOrder);
    }

    @GET
    @Path("/isAllowedToEditWorkOrder")
    public boolean isAllowedToEditWorkOrder(@NotNull @QueryParam("id") String id) {
        return service.isAllowedToEditWorkOrder(id);
    }

    @POST
    @Path("/createWorkOrder")
    public WorkOrder createWorkOrder(@NotNull WorkOrder workOrder) {
        return service.createWorkOrder(workOrder);
    }

    @GET
    @Path("/getAvailableEquipment")
    public List<Asset> getAvailableEquipment(@QueryParam("customerId") String customerId) {
        return service.getAvailableEquipment(customerId);
    }

    @GET
    @Path("/getEquipmentCustomers")
    public List<OrganizationRef> getEquipmentCustomers() {
        return service.getEquipmentCustomers();
    }

    @GET
    @Path("/getOpenWorkOrders")
    public List<WorkOrder> getOpenWorkOrders(@QueryParam("customerId") String customerId, @QueryParam("ecn") String ecn) {
        return service.getOpenWorkOrders(customerId, ecn);
    }

    @GET
    @Path("/getAssetById")
    public Asset getAssetById(@QueryParam("assetId") @NotNull String assetId) {
        return service.getAssetById(assetId);
    }

    @GET
    @Path("/getAvailableTechniciansByOrganizationId")
    public List<TechnicianRef> getAvailableTechniciansByOrganizationId(@NotNull @QueryParam("organizationId") String organizationId) {
        return service.getAvailableTechniciansByOrganizationId(organizationId);
    }

}
