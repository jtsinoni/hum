package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

@Api(tags = {"CatalogDataLoad"})
@ApplicationScoped
@Path("/catalogDataLoad")
public class CatalogDataLoadRestApi extends ExternalRestApi<CatalogDataLoadService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/buildItemFromSiteCatalog")
    @ApiOperation(value = "Build Item from SiteCatalog record")
    public void buildItemFromSiteCatalog(@QueryParam("dodaac") String dodaac) {
        service.buildItemFromSiteCatalog(dodaac);
    }

    @GET
    @Path("/buildItemFromEnterpriseItemIdentifier")
    @ApiOperation(value = "Build Item from SiteCatalog record")
    public void buildItemFromEnterpriseItemIdentifier(@QueryParam("enterpriseItemIdentifier") String enterpriseItemIdentifier) {
        service.buildItemFromEnterpriseItemIdentifier(enterpriseItemIdentifier);
    }

    @GET
    @Path("/buildItemFromEquipmentRecords")
    @ApiOperation(value = "Build Item from Equipment record")
    public void buildItemFromEquipmentRecords(@QueryParam("dodaac") String dodaac) {
        service.buildItemFromEquipmentRecords(dodaac);
    }

    @GET
    @Path("/publishItemRefs")
    public void publishItemRefs() {
        service.publishItemRefs();
    }

    @GET
    @Path("/loadBusinesses")
    public void loadBusinesses() {
        service.loadBusinesses();
    }

    @GET
    @Path("/loadSiteBusinesses")
    public void loadSiteBusinesses() {
        service.loadSiteBusinesses();
    }

    @GET
    @Path("/populateBusinessRefs")
    public void populateBusinessRefs() {
        service.populateBusinessRefs();
    }

    @GET
    @Path("/buildCatalogFromCatalogImport")
    public void buildCatalogFromCatalogImport() {
        service.buildCatalogFromCatalogImport();
    }

    @GET
    @Path("/processUdrTransactions")
    public void processUdrTransactions() { service.processUdrTransactions(); }

}