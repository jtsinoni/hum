package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiFileManagerMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiFileManagerMicroserviceClient extends MicroserviceClient<IAbiFileManagerMicroserviceApi> {
    public AbiFileManagerMicroserviceClient() {
        super(IAbiFileManagerMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiFileManagerMicroserviceApi getABiFileManagerService() {
        return createClient();
    }
}

