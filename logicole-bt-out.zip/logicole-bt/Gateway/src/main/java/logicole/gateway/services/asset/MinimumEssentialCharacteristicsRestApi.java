package logicole.gateway.services.asset;

import io.swagger.annotations.Api;
import logicole.common.datamodels.asset.lookup.MilitaryStandard1691Summary;
import logicole.common.datamodels.asset.minimumessentialcharacteristics.MinimumEssentialCharacteristics;
import logicole.common.datamodels.equipment.request.Device;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"MinimumEssentialCharacteristics"})
@ApplicationScoped
@Path("/assetMec")
public class MinimumEssentialCharacteristicsRestApi extends ExternalRestApi<MinimumEssentialCharacteristicsService> {

    @GET
    @Path("/getAllMinimumEssentialCharacteristics")
    public List<MinimumEssentialCharacteristics> getAllMinimumEssentialCharacteristics() {
        return service.getAllMinimumEssentialCharacteristics();
    }

    @POST
    @Path("/addMinimumEssentialCharacteristic")
    public MinimumEssentialCharacteristics addMinimumEssentialCharacteristic(MinimumEssentialCharacteristics mec) {
        return service.addMinimumEssentialCharacteristic(mec);
    }

    @POST
    @Path("/updateMinimumEssentialCharacteristic")
    public MinimumEssentialCharacteristics updateMinimumEssentialCharacteristic(MinimumEssentialCharacteristics mec) {
        return service.updateMinimumEssentialCharacteristic(mec);
    }

    @POST
    @Path("/deleteMinimumEssentialCharacteristic")
    public void deleteMinimumEssentialCharacteristic(String mecId) {
        service.deleteMinimumEssentialCharacteristic(mecId);
    }

    @GET
    @Path("/checkIfMecRefExistsInActiveEquipmentRequests")
    public boolean checkIfMecRefExistsInActiveEquipmentRequests(@NotNull @QueryParam("mecId") String mecId) {
        return service.checkIfMecRefExistsInActiveEquipmentRequests(mecId);
    }

    @GET
    @Path("/getAllDeviceCodes")
    public List<Device> getAllDeviceCodes() {
        return service.getAllDeviceCodes();
    }

    @GET
    @Path("/getAllMilitaryStandard1691")
    public List<MilitaryStandard1691Summary> getAllMilitaryStandard1691() {
        return service.getAllMilitaryStandard1691();
    }
}
