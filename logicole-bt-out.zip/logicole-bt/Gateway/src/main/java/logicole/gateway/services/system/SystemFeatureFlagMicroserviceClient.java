package logicole.gateway.services.system;

import logicole.apis.system.ISystemFeatureFlagMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class SystemFeatureFlagMicroserviceClient extends MicroserviceClient<ISystemFeatureFlagMicroserviceApi> {
    public SystemFeatureFlagMicroserviceClient(){
        super(ISystemFeatureFlagMicroserviceApi.class, "logicole-system");
    }

    @Produces
    public ISystemFeatureFlagMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
