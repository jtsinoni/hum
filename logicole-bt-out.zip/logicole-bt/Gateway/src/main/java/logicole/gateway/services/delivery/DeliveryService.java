package logicole.gateway.services.delivery;

import logicole.apis.delivery.IDeliveryMicroserviceApi;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.delivery.DeliveryList;
import logicole.common.datamodels.delivery.DueOut;
import logicole.common.datamodels.inventory.PickList;
import logicole.common.datamodels.receipt.DueIn;
import logicole.common.datamodels.sale.fulfillment.AutomaticFulfillmentDTO;
import logicole.common.datamodels.sale.fulfillment.FulfillmentHistory;
import logicole.common.datamodels.sale.seller.Seller;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.order.OrderService;
import logicole.gateway.services.receipt.DueInService;
import logicole.gateway.services.sale.FulfillmentService;
import logicole.gateway.services.sale.SellerService;
import logicole.common.datamodels.order.buyer.Buyer;

import java.util.List;
import java.util.Objects;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class DeliveryService extends BaseGatewayService<IDeliveryMicroserviceApi> {

    @Inject
    FulfillmentService fulfillmentService;
    @Inject
    ItemService itemService;
    @Inject
    DueOutService dueOutService;
    @Inject
    SellerService sellerService;
    @Inject
    OrderService orderService;
    @Inject
    DueInService dueInService;
    @Inject
    BuyerService buyerService;


    public DeliveryService() {
        super("Delivery");
    }

    public boolean generateDeliveryList(PickList pickList) {
        Seller seller = sellerService.getSellerById(pickList.sellerId);
        if (!Objects.isNull(seller)) {
            pickList.sellerName = seller.sellerName;
        }
        pickList.pickDetails.forEach(pickDetail -> {
            Item item = itemService.getItemById(pickDetail.itemId);
            if (!Objects.isNull(item)) {
                pickDetail.controlledInventoryItemCodeRef = item.controlledInventoryItemCodeRef;
                pickDetail.hazardCode = item.hazardCode;
            }
            DueOut dueOut = dueOutService.getDueOutById(pickDetail.dueoutId);
            if (Objects.isNull(pickList.shippingAddress)
                    && !Objects.isNull(dueOut)
                    && !Objects.isNull(dueOut.fulfillmentRef)) {
                pickList.shippingAddress = orderService.getOrderById(dueOut.fulfillmentRef.orderId).shippingAddress;
            }

        });
        return microservice.generateDeliveryList(pickList);
    }

    public List<DeliveryList> generateBackOrderDeliveryList(AutomaticFulfillmentDTO automaticFulfillmentDTO) {
        return microservice.generateBackOrderDeliveryList(automaticFulfillmentDTO);
    }


    public List<DeliveryList> getGeneratedDeliveryListsByInventorySystemId(String inventorySystemId) {
        return microservice.getGeneratedDeliveryListsByInventorySystemId(inventorySystemId);
    }

    public DeliveryList getDeliveryListById(String deliveryListId) {
        return microservice.getDeliveryListById(deliveryListId);
    }


    public List<DeliveryList> getProcessedDeliveryListsByInventorySystemId(String inventorySystemId) {
        return microservice.getProcessedDeliveryListsByInventorySystemId(inventorySystemId);
    }

    public DeliveryList processDeliveryList(DeliveryList deliveryList) {

        DeliveryList deliveryList1 = microservice.processDeliveryList(deliveryList);
        Buyer buyer = buyerService.getBuyerByBuyerId(deliveryList1.buyerRef.getId());
        deliveryList1.deliveryListItems.forEach(deliveryListItem -> {
            if (Objects.nonNull(buyer) && !buyer.isAutoReceipts) {
                dueInService.updateDueInDeliveryListProcessStatus(deliveryListItem.dueOutId, true);
            }
            if (deliveryListItem.quantityPicked > 0 && deliveryListItem.fulfillmentRefId != null) {
                FulfillmentHistory fulfillmentHistory = new FulfillmentHistory();
                fulfillmentHistory.quantity = deliveryListItem.quantityPicked;
                fulfillmentHistory.reason = "Processed Delivery";
                fulfillmentService.addFulfillmentHistory(deliveryListItem.fulfillmentRefId, fulfillmentHistory);
                //Delete the fulfillment dueout once it is fully processed.
                dueOutService.deleteDueOutById(deliveryListItem.dueOutId);
            }
        });
        return deliveryList1;
    }

    public DeliveryList updateDeliveryListItem(String deliveryListId,String deliveryListItemIdentifier, String status){
        DeliveryList deliveryList1 = microservice.updateDeliveryListItem(deliveryListId, deliveryListItemIdentifier, status);
        return deliveryList1;
    }

    public void setDeliveryListToProcessStatus(DeliveryList deliveryList) {
        microservice.setDeliveryListToProcessStatus(deliveryList);
        deliveryList.deliveryListItems.forEach(deliveryListItem -> {
            if (deliveryListItem.quantityPicked > 0 && deliveryListItem.fulfillmentRefId != null) {
                FulfillmentHistory fulfillmentHistory = new FulfillmentHistory();
                fulfillmentHistory.quantity = deliveryListItem.quantityPicked;
                fulfillmentHistory.reason = "Processed Delivery";
                fulfillmentService.addFulfillmentHistory(deliveryListItem.fulfillmentRefId, fulfillmentHistory);
                //Delete the fulfillment dueout once it is fully processed.
                dueOutService.deleteDueOutById(deliveryListItem.dueOutId);
            }
        });
    }
}