package logicole.gateway.services.receipt;

import logicole.apis.receipt.IReceiptMicroserviceApi;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.delivery.DeliveryList;
import logicole.common.datamodels.delivery.DueOut;
import logicole.common.datamodels.finance.request.FinanceItem;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.request.EBusinessEventType;
import logicole.common.datamodels.finance.request.RequestGroup;
import logicole.common.datamodels.finance.response.CommonFinanceResponse;
import logicole.common.datamodels.inventory.EDiscrepancyActionCode;
import logicole.common.datamodels.inventory.EDiscrepancyCode;
import logicole.common.datamodels.inventory.InventoryRecord;
import logicole.common.datamodels.inventory.ReceiptRecordQuantity;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.order.OrderDTO;
import logicole.common.datamodels.order.order.OrderInformation;
import logicole.common.datamodels.order.order.OrderItem;
import logicole.common.datamodels.order.order.OrderItemRef;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.datamodels.receipt.ManifestDetail;
import logicole.common.datamodels.receipt.Receipt;
import logicole.common.datamodels.sale.fulfillment.AutomaticFulfillmentDTO;
import logicole.common.datamodels.sale.fulfillment.FulfillmentHistory;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.delivery.DeliveryService;
import logicole.gateway.services.delivery.DueOutService;
import logicole.gateway.services.finance.FinanceProcessingService;
import logicole.gateway.services.inventory.InventoryService;
import logicole.gateway.services.inventory.LocationService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.order.OrderService;
import logicole.gateway.services.sale.FulfillmentService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class ReceiptService extends BaseGatewayService<IReceiptMicroserviceApi> {

    @Inject
    protected InventoryService inventoryService;

    @Inject
    protected OrderService orderService;

    @Inject
    private DeliveryService deliveryService;

    @Inject
    private FulfillmentService fulfillmentService;

    @Inject
    private LocationService locationService;

    @Inject
    private DueOutService dueOutService;

    @Inject
    private BuyerService buyerService;

    @Inject
    private ItemService itemService;

    @Inject
    private FinanceProcessingService financeProcessingService;

    @Inject
    private DueInService dueInService;

    public ReceiptService() {
        super("Receipt");
    }


    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public Receipt addReceipt(Receipt receipt) {
        boolean isIssuedToInventory = false;
        Receipt returnReceipt = microservice.addReceipt(receipt);

        if (!returnReceipt.dueIn.price.equals(receipt.dueIn.price)) {
            OrderItem orderItem = orderService.getOrderItemById(receipt.dueIn.orderItemLineId);
            OrderInformation orderInformation =
                    orderService.getOrderInformationById(receipt.dueIn.orderInformationRef.getId());
            if (Objects.nonNull(orderItem)) {
                orderItem.price = receipt.price;
                orderItem = orderService.updateOrderItemDetails(orderItem);
                if (Objects.nonNull(orderInformation)) {
                    for (OrderItemRef orderItemRef: orderInformation.orderItemRefs) {
                        if (orderItem.getId().equals(orderItemRef.getId())) {
                            orderItemRef.price = orderItem.price;
                            orderService.updateOrderInformation(orderInformation);
                        }
                    }
                }
            }

            CommonFinanceRequest financeRequest = this.createFinanceRequest(receipt,
                    EBusinessEventType.ORDER_ITEMS_UPDATE);

            CommonFinanceResponse financeResponse  = financeProcessingService.processFinanceRequest(financeRequest);

            if (financeResponse.responseGroups.isEmpty()) {
                throw new ApplicationException("There was an error with updating the funding.");
            }

            returnReceipt = microservice.addReceiptEvent(returnReceipt, "Price change on Receipts");
        }

        if (!Objects.isNull(receipt.dueIn.catalog.itemRef.enterpriseProductIdentifier)) {
            InventoryRecord inventoryRecord;

            int sum = receipt.getManifestDetailSumQuantity();
            int fulfilledDueOuts = 0;
            int availableForReceipt;

            inventoryRecord = inventoryService.getRecordByOwnerAndProduct(receipt.dueIn.buyerRef.currentNodeRef.id,
                    receipt.dueIn.catalog.itemRef.enterpriseProductIdentifier);
            OrderDTO order = orderService.getOrderById(receipt.dueIn.orderInformationRef.id);
            Item item = itemService.getItemById(receipt.dueIn.catalog.itemRef.id);
            AutomaticFulfillmentDTO automaticFulfillmentDTO = this.setAutomaticFulfillment(receipt, sum, order, item);
            if (!Objects.isNull(automaticFulfillmentDTO)) {
                availableForReceipt = automaticFulfillmentDTO.getQuantityAvailableForReceipt();
                if (automaticFulfillmentDTO.backOrderedQuantity > 0) {
                    this.processAutomaticFulfillment(automaticFulfillmentDTO);
                }
                sum = Math.max(availableForReceipt, 0);

                fulfilledDueOuts = automaticFulfillmentDTO.backOrderedQuantity;
            }

            int total = sum + fulfilledDueOuts;
            orderService.receiveOrderLineItem(receipt.dueIn.orderInformationRef.id,
                    receipt.dueIn.orderItemLineId, total, isIssuedToInventory);


//                If Verify Receipts on, enable the putaway logic.
//                Buyer buyer = buyerService.getBuyerByBuyerId(receipt.dueIn.buyerRef.getId());
// ToDo: add this code back, if we decide that the PutAway concept will be used
//                if (buyer.isVerifyReceipts) {
//                    PutAway putAway = new PutAway();
//                    putAway.receiptId = returnReceipt.getId();
//                    putAway.enterpriseProductIdentifier = returnReceipt.dueIn.customerItemSourcing.enterpriseProductIdentifier;
//                    putAway.itemDescription = returnReceipt.dueIn.customerItemSourcing.itemSourcingRef.itemRef.shortItemDescription;
//                    putAway.packageUnitDescription = returnReceipt.dueIn.customerItemSourcing.packageUnitDescription;
//                    putAway.unitPrice = returnReceipt.price;
//                    putAway.manifestItems = returnReceipt.manifestItems;
//                    putAway.buyerRef = returnReceipt.dueIn.buyerRef;
//                    putAway.queuedForPutQty = sum;
//                    inventoryService.createPutAway(putAway);
//                } else {

            if (Objects.isNull(inventoryRecord)) {
                inventoryService.createInventoryFromReceipt(receipt);
            } else {
                ReceiptRecordQuantity receiptRecordQuantity = new ReceiptRecordQuantity();
                receiptRecordQuantity.receipt = this.updateReceiptQuantity(receipt, fulfilledDueOuts);
                receiptRecordQuantity.totalManifestQuantity = sum;
                receiptRecordQuantity.inventoryRecord = inventoryRecord;
                inventoryService.updateInventoryRecordFromReceipt(receiptRecordQuantity);
            }

//                }   //ToDo putaway ending brace
        } else {
            if (getCurrentUser().profile.nodeTypeRef.getId().equals(OrganizationConstants.CUSTOMER_ORG_TYPE_ID)) {
                // non-catalog item received by a Customer
                int sum = receipt.getManifestDetailSumQuantity();
                orderService.receiveOrderLineItem(receipt.dueIn.orderInformationRef.id,
                        receipt.dueIn.orderItemLineId, sum, isIssuedToInventory);
            } else if (getCurrentUser().profile.nodeTypeRef.getId().equals(OrganizationConstants.LOGISTICS_ORG_TYPE_ID)) {}
            // different logic, if receiving non-catalog item for LOG
        }

        // update orderLineItem cancelQty.
        if (returnReceipt.cancelledQuantity > 0){
            orderService.updateItemRemainingQuantity(returnReceipt.dueIn.orderInformationRef.orderIdentifier, returnReceipt.dueIn.orderItemLineId,0);
        }

        return returnReceipt;
    }

    private AutomaticFulfillmentDTO setAutomaticFulfillment(Receipt receipt, int receivedQuantity, OrderDTO order, Item item) {
        AutomaticFulfillmentDTO automaticFulfillmentDTO = null;
        List<DueOut> dueOuts = this.getBackOrderedDueOutsForReceivedItem(receipt);

        if (!Objects.isNull(dueOuts) && !dueOuts.isEmpty()) {
            automaticFulfillmentDTO = new AutomaticFulfillmentDTO();
            automaticFulfillmentDTO.itemsReceivedQuantity = receivedQuantity;
            automaticFulfillmentDTO.buyerRef = order.buyerRef;
            automaticFulfillmentDTO.shippingAddress = order.shippingAddress;


            for (DueOut dueOut : dueOuts) {
                //Dueout is the log dueout with backorderquantity 0 and dueout qty > 0
               /* int backOrderQty = Objects.nonNull(dueOut.backOrderQuantity) ? dueOut.backOrderQuantity : 0;

                if (backOrderQty > 0) {
                    automaticFulfillmentDTO.backOrderedQuantity += backOrderQty;
                    automaticFulfillmentDTO.setDueOutItemAssociation(dueOut, item);
                }*/

                int dueOutQuantity = Objects.nonNull(dueOut.dueOutQuantity) ? dueOut.dueOutQuantity : 0;

                if (dueOutQuantity > 0) {
                    DueOut fulfillmentDueout = dueOutService.getDueOutByDocumentNumber(dueOut.documentNumber, "N");
                    //Set orginal cusotmer fulfillment dueout detail for delivery list.
                    dueOut.fulfillmentRef = fulfillmentDueout.fulfillmentRef;
                    dueOut.buyerRef = fulfillmentDueout.buyerRef;
                    dueOut.inventorySystemId = fulfillmentDueout.inventorySystemId;
                    automaticFulfillmentDTO.backOrderedQuantity += dueOutQuantity;
                    automaticFulfillmentDTO.setDueOutItemAssociation(dueOut, item);
                }
            }
        }
        return automaticFulfillmentDTO;
    }

    private List<DueOut> getBackOrderedDueOutsForReceivedItem(Receipt receipt) {
        if (!Objects.isNull(receipt.dueIn)) {

            // In Logicole all backOrder dueouts will be linked.
            //duein_id in dueout is used to get backorderDueouts.
            return dueOutService.getDueOutListByDueInId(receipt.dueIn.getId());

            /*InventorySystem system = locationService.getCurrentUserInventorySystem();
              return dueOutService.getBackOrderedDueOutListByInventorySystem(
                    receipt.dueIn.catalog.itemRef.enterpriseProductIdentifier,
                    system.getId());*/
        } else {
            return new ArrayList<>();
        }
    }


    private Receipt updateReceiptQuantity(@NotNull Receipt receipt, int fulfilledDueOutQty) {
        int manifestQuantity;
        int dueOutQuantity = fulfilledDueOutQty;
        if (fulfilledDueOutQty > 0) {
            int index = 0;
            if (receipt.manifestItems.size() == 1) {
                manifestQuantity = receipt.manifestItems.get(index).quantity - fulfilledDueOutQty;
                receipt.manifestItems.get(index).quantity = Math.max(manifestQuantity, 0);
                return receipt;
            }

            while (index < receipt.manifestItems.size()) {
                manifestQuantity = receipt.manifestItems.get(index).quantity;
                if (manifestQuantity - dueOutQuantity >= 0) {
                    receipt.manifestItems.get(index).quantity = manifestQuantity - dueOutQuantity;
                    dueOutQuantity = 0;
                } else {
                    dueOutQuantity = dueOutQuantity - manifestQuantity;
                    receipt.manifestItems.get(index).quantity = Math.max(dueOutQuantity, 0);
                }
                if (dueOutQuantity <= 0) {
                    break;
                }
                index++;
            }
        }
        return receipt;
    }

    public void processAutomaticFulfillment(AutomaticFulfillmentDTO automaticFulfillmentDTO) {

        //created multiple deliveryList based on isHazardous and isControlledItem.
        List< DeliveryList> deliveryLists = deliveryService.generateBackOrderDeliveryList(automaticFulfillmentDTO);

        deliveryLists.forEach(deliveryList -> {
            if (Objects.nonNull(deliveryList)) {

                // udpate dueout quantity ONLY for BRS fulfilled dueouts. fulfilled dueouts are in deliveryListItem.
                // backorder release picked qty and inPick are same for BRS.
                deliveryList.deliveryListItems.forEach(deliveryListItem -> {

                    if (deliveryListItem.status != null && deliveryListItem.status.equals("Created")) {

                        //This is LOG backorder dueout quantity.
                        dueOutService.updateDueoutQuantity(deliveryListItem.dueOutId, deliveryListItem.quantityPicked * -1);
                        InventoryRecord inventoryRecord = inventoryService.getInventoryRecordByProductAndInventorySystem(deliveryListItem.enterpriseProductIdentifier, deliveryListItem.inventorySystemId);
                        inventoryService.createHistoryEvent("BRS Created", deliveryListItem.documentNumber, inventoryRecord.getId());

                        // update fulfillment Dueout quantity
                        DueOut backOrderDueout = dueOutService.getDueOutByDocumentNumber(deliveryListItem.documentNumber, "Y");
                        DueOut dueOut = dueOutService.updateQueuedForDeliveryQuantity(backOrderDueout.getId(), deliveryListItem.quantityPicked, deliveryListItem.quantityPicked);

                        if (deliveryListItem.fulfillmentRefId != null) {

                            FulfillmentHistory fulfillmentHistory = new FulfillmentHistory();
                            fulfillmentHistory.quantity = deliveryListItem.quantityPicked;
                            fulfillmentHistory.price = deliveryListItem.fulfillmentPrice;
                            fulfillmentHistory.reason = "Back Order Release";
                            fulfillmentService.addFulfillmentHistory(deliveryListItem.fulfillmentRefId, fulfillmentHistory);

                            FulfillmentHistory DeliveryfulfillmentHistory = new FulfillmentHistory();
                            DeliveryfulfillmentHistory.quantity = deliveryListItem.quantityPicked;
                            DeliveryfulfillmentHistory.price = deliveryListItem.fulfillmentPrice;
                            DeliveryfulfillmentHistory.reason = "Awaiting Delivery";
                            fulfillmentService.addFulfillmentHistory(deliveryListItem.fulfillmentRefId, DeliveryfulfillmentHistory);
                        } else {
                            throw new ApplicationException("Could not create Delivery list for back ordered items");
                        }

                        deliveryService.updateDeliveryListItem(deliveryList.getId(),deliveryListItem.deliveryListItemIdentifier, "Processed" );
                    }
                    Buyer buyer = buyerService.getBuyerByBuyerId(deliveryList.buyerRef.getId());
                    if (Objects.nonNull(buyer) && !buyer.isAutoReceipts) {
                        dueInService.updateDueInDeliveryListProcessStatus(deliveryListItem.dueOutId, true);
                    }

                });
                deliveryService.setDeliveryListToProcessStatus(deliveryList);
            }
        });
    }

    public List<Receipt> addReceipts(List<Receipt> receipts) {
        return microservice.addReceipts(receipts);
    }

    public List<String> getDiscrepancyCodes() {
        return EDiscrepancyCode.getDisplayTextList();
    }

    public List<String> getDiscrepancyActionCodes() {
        return EDiscrepancyActionCode.getDisplayTextList();
    }

    public List<Receipt> getReceiptsByBuyerId(String id) {
        return microservice.getReceiptsByBuyerId(id);
    }

    public Receipt getReceiptByDueInId(String dueInId) {
        return microservice.getReceiptByDueInId(dueInId);
    }

    public List<Receipt> getReceiptsBySellerId(String id) {
        return microservice.getReceiptsBySellerId(id);
    }

    public List<Receipt> getReceiptsByPartialEnterpriseProductIdentifier(String partialProductIdentifier) {
        return microservice.getReceiptsByPartialEnterpriseProductIdentifier(partialProductIdentifier);
    }

    public Receipt addReceiptByDueInId(String dueInId, Integer quantity, MonetaryValue price) {
        //
        //contact API here - createInventoryFromReceipt(DueIn dueIn)
        //
        Receipt receipt = microservice.addReceiptByDueInId(dueInId, quantity, price);

        if (receipt != null && receipt.dueIn.orderInformationRef.id != null) {
            orderService.receiveOrderLineItem(receipt.dueIn.orderInformationRef.id, receipt.dueIn.orderItemLineId, quantity, false);
        }
        return receipt;
    }

    private CommonFinanceRequest createFinanceRequest(Receipt receipt, EBusinessEventType businessEventType) {
        CommonFinanceRequest financeRequest = new CommonFinanceRequest();
        Buyer buyer = buyerService.getBuyerByBuyerId(receipt.dueIn.buyerRef.id);
        financeRequest.eventType = businessEventType;
        financeRequest.sourceType = receipt.dueIn.sellerRef.sellerType;
        financeRequest.requestingOrg = buyer.nodeRef;
        financeRequest.requestGroups = new ArrayList<>();

        RequestGroup requestGroup = new RequestGroup();
        requestGroup.fundingNodeRef = receipt.dueIn.fundingNodeRef;
        requestGroup.buyerRef = buyer.getRef();
        requestGroup.currentNodeRef = buyer.nodeRef;
        requestGroup.items = new ArrayList<>();
        requestGroup.throwExceptionOnError = false;
        requestGroup.orderInformationRef = receipt.dueIn.orderInformationRef;
        FinanceItem financeItem = new FinanceItem();
        financeItem.documentNumber = receipt.dueIn.documentNumber;
        Integer sumOfReceiptQty = 0;
        for (ManifestDetail manifestDetail: receipt.manifestItems) {
            sumOfReceiptQty += manifestDetail.quantity;
        }
        financeItem.quantity = sumOfReceiptQty;
        financeItem.catalog = receipt.dueIn.catalog;
        financeItem.itemRef = receipt.dueIn.catalog.itemRef;
        // Temporarily us the receipt price until we can do the price change on the catalog
        financeItem.catalog.price = (receipt.price.subtract(receipt.dueIn.price));
        financeItem.catalog.sellerRef =  receipt.dueIn.catalog.sellerRef;
        financeItem.lineNumber = receipt.dueIn.orderLineNumber;
        financeItem.fiscalYear = receipt.dueIn.fundingNodeRef.fiscalYear;
        financeItem.isStocked = false;
        financeItem.amount = (receipt.price.subtract(receipt.dueIn.price));
        requestGroup.items.add(financeItem);
        financeRequest.requestGroups.add(requestGroup);
        return financeRequest;
    }





}
