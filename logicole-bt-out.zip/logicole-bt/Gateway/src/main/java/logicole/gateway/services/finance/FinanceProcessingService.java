package logicole.gateway.services.finance;

import com.fasterxml.jackson.databind.ObjectMapper;
import logicole.apis.finance.IFinanceProcessingMicroserviceApi;
import logicole.common.datamodels.communications.CommsItem;
import logicole.common.datamodels.communications.CommunicationRequest;
import logicole.common.datamodels.communications.OutputFileGroup;
import logicole.common.datamodels.finance.FinanceDecision;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.finance.FundingNodeRef;
import logicole.common.datamodels.finance.output.request.EFinanceOutputRequestType;
import logicole.common.datamodels.finance.output.request.OutputDataRequest;
import logicole.common.datamodels.finance.request.CommonFinanceRequest;
import logicole.common.datamodels.finance.request.RequestGroup;
import logicole.common.datamodels.finance.request.RequestGroupProcessing;
import logicole.common.datamodels.finance.response.CommonFinanceResponse;
import logicole.common.datamodels.finance.response.ResponseGroup;
import logicole.common.datamodels.finance.response.ResponseItem;
import logicole.common.datamodels.notification.ApplicationNotification;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.order.OrderService;
import logicole.gateway.services.system.NotificationService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ApplicationScoped
public class FinanceProcessingService extends BaseGatewayService<IFinanceProcessingMicroserviceApi> {

    @Inject
    protected FinanceAdminService financeAdminService;
    @Inject
    protected NotificationService notificationService;
    @Inject
    OrderService orderService;


    public FinanceProcessingService() {
        super("FinanceProcessing");
    }

    public CommonFinanceResponse processFinanceRequest(CommonFinanceRequest commonFinanceRequest) {

        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(commonFinanceRequest.requestingOrg.id);
        commonFinanceRequest.financialSystem = financialSystem;

        RequestGroupProcessing requestGroupProcessing = new RequestGroupProcessing();
        requestGroupProcessing.commonFinanceResponse = new CommonFinanceResponse();
        requestGroupProcessing.eventType = commonFinanceRequest.eventType;

//        List<String> errors = financeProcessingValidator.validateRequestGroups(commonFinanceRequest.requestGroups);
//        if (!errors.isEmpty()) {
//            requestGroupProcessing.commonFinanceResponse.validationErrors = errors;
//            return requestGroupProcessing.commonFinanceResponse;
//        }

        for (RequestGroup requestGroup: commonFinanceRequest.requestGroups) {
            requestGroup.currentNodeRef = commonFinanceRequest.requestingOrg;
            if (requestGroupProcessing.order != null) {
                requestGroupProcessing.order = orderService.getOrderById(requestGroup.orderInformationRef.id);
            }
            requestGroupProcessing.requestGroup = requestGroup;
            requestGroupProcessing.sourceType = commonFinanceRequest.sourceType;

            requestGroupProcessing.commonFinanceResponse = microservice.processRequestGroup(requestGroupProcessing);
        }
        // TODO: this will move to periodic processing
        // List<Obligations> obligationsList = financeOutputService.getObligations(requestGroupProcessing.commonFinanceResponse, financialSystem.getRef());
        ;//populateManagedByOrganization(obligationsList);

        OutputDataRequest outputDataRequest = new OutputDataRequest();
        outputDataRequest.financialSystemRef = financialSystem.getRef();
        outputDataRequest.financeOutputRequestType = EFinanceOutputRequestType.OBLIGATION;

//        sendObligations(obligationsList, outputDataRequest);

        microservice.insertOutputDataRequest(outputDataRequest);
        //Expenses expenses = financeOutputService.getExpenses(response, financialSystem.getRef());
        //communicationsSubmitRequestService.submitFinancialRequest(expenses);

        // TODO reevaluate this code
//        List<FundingNodeRef> negativeBalanceNodes = microservice.checkForNegativeFundsNotification(response.responseGroups);
//        sendNegativeBalanceNotification(negativeBalanceNodes);
        return requestGroupProcessing.commonFinanceResponse;
    }

    // TODO - Reevaluate this functionality at a later date
//    void sendObligations(List<Obligations> obligationsList, OutputDataRequest outputDataRequest) {
//
//        for (Obligations obligations : obligationsList) {
//            OutputData outputData = new OutputData();
//            outputData.obligationsRef = obligations.getRef();
//            CommunicationResponse communicationResponse = communicationsSubmitRequestService.submitFinancialRequest(obligations);
//            outputData.communicationResponse = communicationResponse;
//            outputDataRequest.outputData.add(outputData);
//        }
//    }

    // this seems odd
//    private void populateManagedByOrganization(List<Obligations> obligationsList) {
//        for (Obligations obligations : obligationsList) {
//            obligations.managedByNodeRef = organizationService.getOrganizationRefById(obligations.managedByNodeRef.id);
//        }
//    }


    void sendNegativeBalanceNotification(List<FundingNodeRef> negativeBalanceNodes) {
        for (FundingNodeRef ref : negativeBalanceNodes) {
            ApplicationNotification notification = new ApplicationNotification();
            notification.content = "Balance exceeded for funds - " + ref.name;

            notificationService.addApplicationNotification(notification);
        }
    }

    void formatOutputRequest(CommonFinanceResponse response, CommunicationRequest communicationRequest) {

        for (ResponseGroup responseGroup : response.responseGroups) {
            FundingNodeRef fundingNodeRef = responseGroup.fundingNodeRef;

            OutputFileGroup ofg = new OutputFileGroup();
            ofg.fundingNodeRef = fundingNodeRef;
            ofg.items = buildComsItems(responseGroup.responseItems);
            communicationRequest.outputFileGroups.add(ofg);
        }
    }

    List<CommsItem> buildComsItems(List<ResponseItem> items) {

        ObjectMapper mapper = new ObjectMapper();

        List<CommsItem> list = new ArrayList<>();

        for (ResponseItem item : items) {
            CommsItem commsItem = new CommsItem();
            Map<String, Object> objectMap = mapper.convertValue(item, Map.class);
            Map<String, String> fieldMap = new HashMap<>();
            Map<String, Object> itemMap = (Map<String, Object>) objectMap.get("item");
            getStringMap(itemMap, fieldMap);
            commsItem.commsFields = fieldMap;
            list.add(commsItem);
        }
        return list;
    }

    private void getStringMap(Map<String, Object> itemMap, Map<String, String> fieldMap) {

        for (Map.Entry<String, Object> entry : itemMap.entrySet()) {
            if (entry.getValue() instanceof Map) {
                Map<String, Object> value = (Map<String, Object>) entry.getValue();
                getStringMap(value, fieldMap);
            } else {
                fieldMap.put(entry.getKey(), entry.getValue().toString());
            }
        }
    }

    public List<FinanceDecision> getAllFinanceDecisionData() {
        return microservice.getAllFinanceDecisionData();
    }

}

