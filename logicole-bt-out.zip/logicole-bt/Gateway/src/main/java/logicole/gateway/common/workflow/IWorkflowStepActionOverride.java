package logicole.gateway.common.workflow;

import logicole.common.datamodels.workflow.WorkflowState;

import java.util.List;

public interface IWorkflowStepActionOverride<T> {

    List<String> determineOverride(String action, WorkflowState workflowState, T workflowItem);

}
