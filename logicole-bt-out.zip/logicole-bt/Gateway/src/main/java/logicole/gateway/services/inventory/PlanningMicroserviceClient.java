package logicole.gateway.services.inventory;

import logicole.apis.inventory.IPlanningMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class PlanningMicroserviceClient extends MicroserviceClient<IPlanningMicroserviceApi> {
    public PlanningMicroserviceClient() {
        super(IPlanningMicroserviceApi.class, "logicole-inventory");
    }

    @Produces
    public IPlanningMicroserviceApi getIPlanningMicroserviceApi() {
        return createClient();
    }
}
