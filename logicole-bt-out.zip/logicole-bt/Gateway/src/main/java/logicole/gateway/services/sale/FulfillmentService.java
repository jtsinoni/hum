package logicole.gateway.services.sale;

import logicole.apis.sale.IFulfillmentMicroserviceApi;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.delivery.DueOut;
import logicole.common.datamodels.inventory.EPickListStatus;
import logicole.common.datamodels.inventory.InventoryRecord;
import logicole.common.datamodels.inventory.InventorySystem;
import logicole.common.datamodels.inventory.PickDetails;
import logicole.common.datamodels.inventory.PickList;
import logicole.common.datamodels.inventory.PickRequest;
import logicole.common.datamodels.inventory.ProductAvailableQuantity;
import logicole.common.datamodels.order.order.OrderDTO;
import logicole.common.datamodels.receipt.DueIn;
import logicole.common.datamodels.receipt.DueinRef;
import logicole.common.datamodels.sale.fulfillment.Fulfillment;
import logicole.common.datamodels.sale.fulfillment.FulfillmentHistory;
import logicole.common.datamodels.sale.fulfillment.ManualFulfillmentDTO;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.delivery.DeliveryService;
import logicole.gateway.services.delivery.DueOutService;
import logicole.gateway.services.inventory.InventoryService;
import logicole.gateway.services.inventory.LocationService;
import logicole.gateway.services.order.OrderService;
import logicole.gateway.services.order.BuyerService;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.inventory.ReplenishmentRecordDTO;
import logicole.gateway.services.receipt.DueInService;

import java.util.*;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class FulfillmentService extends BaseGatewayService<IFulfillmentMicroserviceApi> {

    @Inject
    protected DeliveryService deliveryService;

    @Inject
    protected DueOutService dueOutService;

    @Inject
    protected InventoryService inventoryService;

    @Inject
    private LocationService locationService;

    @Inject
    private ItemService itemService;

    @Inject
    private OrderService orderService;

    @Inject
    private BuyerService buyerService;

    @Inject
    private DueInService dueInService;

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public FulfillmentService() {
        super("Fulfillment");
    }

    public void acceptOrder(OrderDTO order) {
        //Inventory System in the dueout and fulfillment should be the seller (Warehouse)
        InventorySystem inventorySystem = locationService.getInventorySystemByCurrentNodeId(order.orderItems.get(0).orderInformationRef.sellerRef.currentNodeId);
        List<Fulfillment> fulfillmentList = microservice.acceptOrder(inventorySystem.getId(), order);
        fulfillmentList.forEach(f -> f.isManageFulfillment = order.buyer.isIssueIndicator);
        //Log dueouts will be created and fulfillment will use this to process issues.
        //BuyerRef is customer and sellerRef is LOG
        dueOutService.createFulfillmentDueOut(fulfillmentList);
        if (!order.buyer.isIssueIndicator) {
            processAutoFulfillment(order.id, inventorySystem.nodeRef.getId());
        }
    }

    private void processAutoFulfillment(String orderId, String organizationId) {
        List<DueOut> autoFulfillmentDueOuts = dueOutService.getPassThroughDueOutList(organizationId);
        for (DueOut dueOut : autoFulfillmentDueOuts) {
            if (dueOut.fulfillmentRef.orderId.equals(orderId) && (dueOut.backOrderQuantity.equals(0)
                    && dueOut.queuedForPickQuantity.equals(0) && dueOut.queuedForDeliveryQuantity.equals(0))) {
                ManualFulfillmentDTO autoFulfillmentDTO = new ManualFulfillmentDTO();
                ProductAvailableQuantity productAvailableQuantity =
                        inventoryService.getProductAvailableQuantityForResale(organizationId,
                                dueOut.enterpriseProductIdentifier);

                autoFulfillmentDTO.productDescription = dueOut.productDescription;
                autoFulfillmentDTO.packageUnitDescription = dueOut.packageUnit != null ? dueOut.packageUnit.name : "";
                autoFulfillmentDTO.isBackOrderRelease = false;
                autoFulfillmentDTO.enterpriseProductIdentifier = dueOut.enterpriseProductIdentifier;
                autoFulfillmentDTO.availableInventoryQuantity = productAvailableQuantity.availableQuantity;
                autoFulfillmentDTO.onHandQuantity = productAvailableQuantity.onHandQuantity;

                if (dueOut.dueOutQuantity <= autoFulfillmentDTO.availableInventoryQuantity) {
                    dueOut.userIssueQuantity = dueOut.dueOutQuantity;
                    dueOut.backOrderQuantity = 0;
                } else {
                    dueOut.userIssueQuantity = autoFulfillmentDTO.availableInventoryQuantity;
                    dueOut.backOrderQuantity = dueOut.dueOutQuantity - autoFulfillmentDTO.availableInventoryQuantity;
                }
                autoFulfillmentDTO.buyerGroups.add(dueOut);
                processManualFulfillment(autoFulfillmentDTO);

            }
        }
    }


    public List<Fulfillment> getFulfillmentActivity(String inventoryOwnerId) {
        return microservice.getFulfillmentActivity(inventoryOwnerId);
    }

    public List<ManualFulfillmentDTO> getManualFulfillmentList(String inventoryOwnerId) {
        List<ManualFulfillmentDTO> manualFulfillmentDTOS = new ArrayList<>();
        List<DueOut> dueOuts = dueOutService.getDueOutList(inventoryOwnerId);
        Comparator<DueOut> dueOutComparator = (DueOut do1, DueOut do2) -> {
            int do1CodeInt = Integer.parseInt(do1.priorityCodeRef==null ? "13" : do1.priorityCodeRef.code);
            int do2CodeInt = Integer.parseInt(do2.priorityCodeRef==null ? "13" : do2.priorityCodeRef.code);
            if (do1CodeInt > do2CodeInt) return 1;
            if (do1CodeInt < do2CodeInt) return -1;
            return 0;
        };
        Collections.sort(dueOuts, dueOutComparator);
        List<String> enterpriseProductIdentifiers = dueOuts.stream().map(dueOut -> dueOut.enterpriseProductIdentifier).distinct().collect(Collectors.toList());
        if (!dueOuts.isEmpty()) {
            String currentNodeId = dueOuts.get(0).sellerRef.currentNodeId;
            for (String enterpriseProductId : enterpriseProductIdentifiers) {
                ManualFulfillmentDTO manualFulfillmentDTO = new ManualFulfillmentDTO();
                manualFulfillmentDTO.enterpriseProductIdentifier = enterpriseProductId;
                manualFulfillmentDTO.isBackOrderRelease = false;
                ProductAvailableQuantity paq = inventoryService.getProductAvailableQuantityForResale(currentNodeId, enterpriseProductId);
                manualFulfillmentDTO.availableInventoryQuantity = paq.availableQuantity;
                manualFulfillmentDTO.onHandQuantity = paq.onHandQuantity;
                // This value is for auto-populating the fields on the screen for the user
                int manualAvailableQuantity = manualFulfillmentDTO.availableInventoryQuantity;
                for (DueOut dueOut : dueOuts) {
                    Buyer buyer = buyerService.getBuyerByBuyerId(dueOut.buyerRef.id);
                    boolean managingFulfillment = buyer.isIssueIndicator;
                    if ((dueOut.backOrderQuantity != null && dueOut.backOrderQuantity > 0) &&
                            (manualFulfillmentDTO.availableInventoryQuantity == 0
                                    || (!managingFulfillment && manualFulfillmentDTO.availableInventoryQuantity > 0))) {
                        continue;
                    }
                    if (dueOut.enterpriseProductIdentifier.equals(enterpriseProductId)) {
                        manualFulfillmentDTO.isBackOrderRelease = (dueOut.backOrderQuantity != null && dueOut.backOrderQuantity > 0
                                && manualFulfillmentDTO.availableInventoryQuantity > 0);
                        manualFulfillmentDTO.packageUnitDescription = dueOut.packageUnit != null ? dueOut.packageUnit.name : "";
                        manualFulfillmentDTO.productDescription = dueOut.productDescription;
                        if (dueOut.dueOutQuantity <= manualAvailableQuantity) {
                            dueOut.userIssueQuantity = dueOut.dueOutQuantity;
                            dueOut.backOrderQuantity = 0;
                            manualAvailableQuantity -= dueOut.dueOutQuantity;
                        } else {
                            dueOut.userIssueQuantity = manualAvailableQuantity;
                            dueOut.backOrderQuantity = dueOut.dueOutQuantity - manualAvailableQuantity;
                            manualAvailableQuantity = 0;
                        }
                        manualFulfillmentDTO.buyerGroups.add(dueOut);
                    }
                }
                if (!manualFulfillmentDTO.buyerGroups.isEmpty())
                    manualFulfillmentDTOS.add(manualFulfillmentDTO);
            }
        }
        return manualFulfillmentDTOS;
    }


    public DueOut processFulfillment(String dueOutId, Integer quantity, Integer backOrderqty, Boolean isBackOrderRelease) {
        DueOut dueOut = dueOutService.getDueOutById(dueOutId);
        InventorySystem system = locationService.getInventorySystemById(dueOut.inventorySystemId);

        PickRequest pickRequest = createPickRequestFromDueOut(dueOut, system);
        pickRequest.queuedForPickQty = quantity < 0 ? 0 : quantity;
        pickRequest.isBackOrderRelease = isBackOrderRelease;

        DueOut updatedDueOut = dueOutService.updateQueuedForPickQuantity(dueOutId, quantity, backOrderqty);

        if (pickRequest.queuedForPickQty > 0) {
            if (updatedDueOut.fulfillmentRef.id != null) {
                Fulfillment fulfillment = createFulfillmentHistoryRecord(
                        updatedDueOut.fulfillmentRef.id, quantity, updatedDueOut.unitPrice, "Quantity Reserved");
                pickRequest.documentNumber = fulfillment.documentNumber;
            }
            inventoryService.createPickRequest(pickRequest);
        }
        if (backOrderqty > 0 && updatedDueOut.fulfillmentRef.id != null)  {
            //create backorder dueout which will be pushed to Cart
            ReplenishmentRecordDTO replenishmentRecordDTO = createReplenishmentRecortDtoFromDueOut(updatedDueOut);
            updateReplenishmentRecordDtoInventoryRecordRelatedFields(system, updatedDueOut, replenishmentRecordDTO);
            replenishmentRecordDTO.replenishmentQuantity = backOrderqty;

            //This is replenishment Dueout for LOG or CAIM SOS for the backordered qty
            //getReplenishmentList will retrieve this dueout and send to Cart.
            dueOutService.createDueOut(replenishmentRecordDTO);
            createFulfillmentHistoryRecord(
                    updatedDueOut.fulfillmentRef.id, backOrderqty, updatedDueOut.unitPrice, "Quantity backorder requested");
        }
        return updatedDueOut;
    }

    public List<ManualFulfillmentDTO> processAllManualFulfillment(List<ManualFulfillmentDTO> manualFulfillmentDTOs) {
        List<ManualFulfillmentDTO> fulfillmentDTOs = new ArrayList<>();
        for (ManualFulfillmentDTO fulfillmentDTO : manualFulfillmentDTOs) {
            var processed = this.processManualFulfillment(fulfillmentDTO);
            if (processed != null)
                fulfillmentDTOs.add(processed);
        }
        return fulfillmentDTOs;
    }

    public ManualFulfillmentDTO processManualFulfillment(ManualFulfillmentDTO manualFulfillmentDTO) {
        ManualFulfillmentDTO manualFulfillmentReturn = new ManualFulfillmentDTO();
        List<DueOut> dueOutDTOS = manualFulfillmentDTO.buyerGroups;
        //String currentNodeId = currentUserBT.getCurrentNodeId();
        String currentNodeId = manualFulfillmentDTO.buyerGroups.get(0).sellerRef.currentNodeId;
        Comparator<DueOut> dueOutComparator = (DueOut do1, DueOut do2) -> {
            int do1CodeInt = Integer.parseInt(do1.priorityCodeRef==null ? "13" : do1.priorityCodeRef.code);
            int do2CodeInt = Integer.parseInt(do2.priorityCodeRef==null ? "13" : do2.priorityCodeRef.code);
            if (do1CodeInt > do2CodeInt) return 1;
            if (do1CodeInt < do2CodeInt) return -1;
            return 0;
        };

        for (DueOut dueOutDTO : dueOutDTOS) {
            Integer userQuantity = (dueOutDTO.userIssueQuantity == null || dueOutDTO.userIssueQuantity < 0) ? 0 : dueOutDTO.userIssueQuantity;
            Integer backOrderQty = (dueOutDTO.backOrderQuantity == null || dueOutDTO.backOrderQuantity < 0) ? 0 : dueOutDTO.backOrderQuantity;
            String dueOutId = dueOutDTO.getId();
            if (userQuantity > 0 || backOrderQty > 0) {
                DueOut dueOutDTO1 = this.processFulfillment(dueOutId, userQuantity, backOrderQty, manualFulfillmentDTO.isBackOrderRelease);
                if (dueOutDTO1.dueOutQuantity > 0) {
                    manualFulfillmentReturn.buyerGroups.add(dueOutDTO1);
                }
            } else {
                manualFulfillmentReturn.buyerGroups.add(dueOutDTO);
            }
        }

        if (!manualFulfillmentReturn.buyerGroups.isEmpty()) {
            manualFulfillmentReturn.enterpriseProductIdentifier = manualFulfillmentDTO.enterpriseProductIdentifier;
            manualFulfillmentReturn.packageUnitDescription = manualFulfillmentDTO.packageUnitDescription;
            manualFulfillmentReturn.productDescription = manualFulfillmentDTO.productDescription;
            ProductAvailableQuantity productAvailableQuantity = inventoryService.getProductAvailableQuantityForResale(
                    currentNodeId,
                    manualFulfillmentDTO.enterpriseProductIdentifier);

            if (productAvailableQuantity.productExistsInInventory) {
                manualFulfillmentReturn.availableInventoryQuantity = productAvailableQuantity.availableQuantity;

                // This value is for auto-populating the fields on the screen for the user
                int manualAvailableQuantity = manualFulfillmentReturn.availableInventoryQuantity < 0 ? 0 : manualFulfillmentReturn.availableInventoryQuantity;
                Collections.sort(manualFulfillmentReturn.buyerGroups, dueOutComparator);
                for (DueOut dueOut : manualFulfillmentReturn.buyerGroups) {
                    if (dueOut.dueOutQuantity <= manualAvailableQuantity) {
                        dueOut.userIssueQuantity = dueOut.dueOutQuantity;
                        dueOut.backOrderQuantity = 0;
                        manualAvailableQuantity -= dueOut.dueOutQuantity;
                    } else {
                        dueOut.userIssueQuantity = manualAvailableQuantity;
                        dueOut.backOrderQuantity = dueOut.dueOutQuantity - manualAvailableQuantity;
                        manualAvailableQuantity = 0;
                    }
                    if (dueOut.queuedForPickQuantity != null && dueOut.queuedForPickQuantity > 0) {
                        inventoryService.uploadInventoryRecordQueuedForPickQuantity(currentNodeId,
                                manualFulfillmentDTO.enterpriseProductIdentifier, dueOut.queuedForPickQuantity);
                    }
                }
            }
        }

        return manualFulfillmentReturn;
    }

    public List<PickList> generatePicklist(List<PickRequest> pickRequests) {
        List<PickList> pickListArrayList = new ArrayList<>();

        pickListArrayList = inventoryService.generatePicklist(pickRequests);
        if (!pickListArrayList.isEmpty()) {
            for (PickRequest pickRequest : pickRequests) {
                if (pickRequest.fulfillmentRef.id != null) {
                    FulfillmentHistory fulfillmentHistory = new FulfillmentHistory();
                    fulfillmentHistory.quantity = pickRequest.queuedForPickQty;
                    fulfillmentHistory.reason = "Added to a Pick List";
                    addFulfillmentHistory(pickRequest.fulfillmentRef.id, fulfillmentHistory);
                }
            }
        }
        return pickListArrayList;
    }

    public List<PickRequest> cancelPickRequest(List<PickRequest> pickRequests) {

        List<PickRequest> pickRequestArrayList;

        pickRequestArrayList = inventoryService.cancelPickRequest(pickRequests);
        for (PickRequest pickRequest : pickRequests) {
            if (pickRequest.fulfillmentRef.id != null) {
                FulfillmentHistory fulfillmentHistory = new FulfillmentHistory();
                fulfillmentHistory.quantity = pickRequest.queuedForPickQty;
                fulfillmentHistory.reason = "Cancelled Reserved Quantity";
                addFulfillmentHistory(pickRequest.fulfillmentRef.id, fulfillmentHistory);
                rejectFulfillmentFromPickRequest(pickRequest.dueoutId);
            }
        }
        return pickRequestArrayList;
    }

    public PickList confirmPicklist(PickList pickList) {
        for (PickDetails pickDetail : pickList.pickDetails) {
            if (pickDetail.quantityPicked > 0 && pickDetail.quantityPicked <= pickDetail.inPickQty) {
                DueOut dueOut = dueOutService.getDueOutById(pickDetail.dueoutId);
                if (dueOut == null)
                    continue;
                dueOut = dueOutService.updateQueuedForDeliveryQuantity(pickDetail.dueoutId, pickDetail.quantityPicked, pickDetail.inPickQty);
                if (pickDetail.fulfillmentRefId != null) {
                    FulfillmentHistory fulfillmentHistory = new FulfillmentHistory();
                    fulfillmentHistory.quantity = pickDetail.quantityPicked;
                    fulfillmentHistory.reason = "Awaiting Delivery";
                    addFulfillmentHistory(pickDetail.fulfillmentRefId, fulfillmentHistory);
                }
            }
        }
        PickList confirmedPickList = inventoryService.confirmPicklist(pickList);
        if (confirmedPickList.status != EPickListStatus.GENERATED) {
            deliveryService.generateDeliveryList(confirmedPickList);
        }

        // create backorder dueouts for the discrepancy qunantity in confirm pick.
        for (PickDetails confirmedPickDetail : confirmedPickList.pickDetails) {
            if (confirmedPickDetail.discrepancy != null){
                if (confirmedPickDetail.discrepancyQty > 0) {
                    DueOut dueOut = dueOutService.getDueOutById(confirmedPickDetail.dueoutId);
                    DueOut backOrderDueout = dueOutService.getDueOutByDocumentNumber(dueOut.documentNumber, "Y");
                    //create new dueout if backdorder does not exist OR update dueout qty.
                    if (backOrderDueout == null) {
                        InventoryRecord inventoryRecord = inventoryService.getRecordByOwnerAndProduct(getCurrentUser().profile.currentNodeRef.getId(), dueOut.enterpriseProductIdentifier);
                        ReplenishmentRecordDTO replenishmentRecordDTO = new ReplenishmentRecordDTO();
                        replenishmentRecordDTO.documentNumber = dueOut.documentNumber;
                        replenishmentRecordDTO.enterpriseProductIdentifier = dueOut.enterpriseProductIdentifier;
                        replenishmentRecordDTO.buyerRef = buyerService.getBuyerForNodeId(getCurrentUser().profile.currentNodeRef.getId()).getRef();
                        replenishmentRecordDTO.sellerRef = inventoryRecord.sellerRef;
                        replenishmentRecordDTO.inventorySystemRef = inventoryRecord.inventorySystemRef;
                        replenishmentRecordDTO.replenishmentQuantity = confirmedPickDetail.discrepancyQty;
                        replenishmentRecordDTO.inventoryRecordId = inventoryRecord.getId();
                        replenishmentRecordDTO.itemDescription = inventoryRecord.catalogRef.shortDescription;
                        replenishmentRecordDTO.unitOfPackaging = inventoryRecord.unitOfInventory.name;
                        replenishmentRecordDTO.unitPrice = dueOut.unitPrice;
                        //create dueout for the sellers primary Location.
                        replenishmentRecordDTO.locationRef = inventoryService.getPrimaryLocationByInventoryRecordId(inventoryRecord.getId());
                        replenishmentRecordDTO.unitPrice = dueOut.unitPrice;
                        replenishmentRecordDTO.backOrderIndicator = "Y";

                        //This is replenishment Dueout for LOG or CAIM SOS for the discrepancy qty duein confirm pick.
                        //getReplenishmentList will retrieve this dueout and send to Cart.
                        dueOutService.createDueOut(replenishmentRecordDTO);
                    } else {
                        dueOutService.updateDueoutQuantity(backOrderDueout.getId(), confirmedPickDetail.discrepancyQty);
                    }
                }
            }
        }

        return confirmedPickList;
    }

    public List<PickRequest> getPickRequestsByInventorySystemId(String inventorySystemId) {
        return inventoryService.getPickRequestsByInventorySystemId(inventorySystemId);
    }

    public PickList getPickListById(String pickListId) {
        return inventoryService.getPickListById(pickListId);
    }

    public PickList getPickListReportDataById(String pickListId) {
        PickList pickList = inventoryService.getPickListById(pickListId);
        return this.updatePicklistDataForReport(pickList);
    }

    private PickList updatePicklistDataForReport(PickList pickList) {
        pickList.pickDetails.forEach(pickDetail -> {
            Item item = itemService.getItemById(pickDetail.itemId);
            InventoryRecord record = inventoryService.getInventoryRecordById(pickDetail.inventoryRecordId);
            pickDetail.isHazardous = record.itemRef.isHazardous;
            if (!Objects.isNull(item)) {
                pickDetail.controlledInventoryItemCodeRef = item.controlledInventoryItemCodeRef;
            }
        });
        return pickList;
    }

    public List<PickList> getPickListsByInventorySystemId(String inventorySystemId) {
        return inventoryService.getPickListsByInventorySystemId(inventorySystemId);
    }

    public List<PickList> getConfirmedPickListsByInventorySystemId(String inventorySystemId) {
        return inventoryService.getConfirmedPickListsByInventorySystemId(inventorySystemId);
    }

    public Fulfillment addFulfillmentHistory(String id, FulfillmentHistory history) {
        return microservice.addFulfillmentHistory(id, history);
    }

    public List<ManualFulfillmentDTO> rejectSelectedFulfillment(List<ManualFulfillmentDTO> manualFulfillmentDTOs) {
        List<ManualFulfillmentDTO> fulfillmentDTOs = new ArrayList<>();
        for (ManualFulfillmentDTO fulfillmentDTO : manualFulfillmentDTOs) {
            var rejected = this.rejectFulfillment(fulfillmentDTO);
            if (rejected != null)
                fulfillmentDTOs.add(rejected);
        }
        return fulfillmentDTOs;
    }


    public ManualFulfillmentDTO rejectFulfillment(ManualFulfillmentDTO manualFulfillmentDTO) {
        List<DueOut> dueOutLists = manualFulfillmentDTO.buyerGroups;
        for (DueOut dueOut : dueOutLists) {
            dueOutService.deleteDueOutById(dueOut.getId());
            if (dueOut.fulfillmentRef != null) {
                FulfillmentHistory fulfillmentHistory = new FulfillmentHistory();
                fulfillmentHistory.reason = "Cancelled Fulfillment Request";
                fulfillmentHistory.quantity = dueOut.userIssueQuantity;
                addFulfillmentHistory(dueOut.fulfillmentRef.id, fulfillmentHistory);
                orderService.updateItemRemainingQuantity(dueOut.fulfillmentRef.orderId, dueOut.fulfillmentRef.orderLineItemId, 0);
            }
        }
        return manualFulfillmentDTO;
    }

    private void rejectFulfillmentFromPickRequest(String dueOutId) {
        DueOut dueOut = dueOutService.getDueOutById(dueOutId);
        dueOutService.deleteDueOutById(dueOut.getId());
        if (dueOut.fulfillmentRef != null) {
            FulfillmentHistory fulfillmentHistory = new FulfillmentHistory();
            fulfillmentHistory.reason = "Cancelled Fulfillment Request";
            fulfillmentHistory.quantity = dueOut.queuedForPickQuantity;
            addFulfillmentHistory(dueOut.fulfillmentRef.id, fulfillmentHistory);
            orderService.updateItemRemainingQuantity(dueOut.fulfillmentRef.orderId, dueOut.fulfillmentRef.orderLineItemId, 0);
        }
    }

    public boolean processBackOrderRelease() {
        String nodeId = currentUserBT.getCurrentNodeId();
        List<DueOut> dueOuts = dueOutService.getDueOutBackOrderListByOrgId(nodeId);
        if (dueOuts == null || dueOuts.size() == 0)
            return false;

        for (DueOut dueOut : dueOuts) {
            ProductAvailableQuantity productAvailableQuantity = inventoryService.getProductAvailableQuantityForResale(nodeId, dueOut.enterpriseProductIdentifier);
            if (productAvailableQuantity.productExistsInInventory) {
                if (dueOut.backOrderQuantity > 0 && dueOut.backOrderQuantity < productAvailableQuantity.availableQuantity) {
                    dueOut.userIssueQuantity = dueOut.dueOutQuantity;
                    dueOut.backOrderQuantity = 0;

                    ManualFulfillmentDTO manualFulfillment = new ManualFulfillmentDTO();
                    manualFulfillment.isBackOrderRelease = true;
                    manualFulfillment.buyerGroups.add(dueOut);
                    processManualFulfillment(manualFulfillment);
                }
            }
        }
        return true;
    }

    private PickRequest createPickRequestFromDueOut(DueOut dueOut, InventorySystem system) {
        PickRequest pickRequest = new PickRequest();
        pickRequest.buyerRef = dueOut.buyerRef;
        pickRequest.fulfillmentRef = dueOut.fulfillmentRef;
        pickRequest.enterpriseProductIdentifier = dueOut.enterpriseProductIdentifier;
        pickRequest.packageUnitDescription = dueOut.packageUnit != null ? dueOut.packageUnit.name : "";
        pickRequest.sellerRef = dueOut.sellerRef;
        pickRequest.itemDescription = dueOut.productDescription;
        pickRequest.unitPrice = dueOut.unitPrice;
        pickRequest.dueoutId = dueOut.getId();
        pickRequest.inventorySystemRef = system.getRef();
        return pickRequest;
    }

    private ReplenishmentRecordDTO createReplenishmentRecortDtoFromDueOut(DueOut updatedDueOut) {
        ReplenishmentRecordDTO replenishmentRecordDTO = new ReplenishmentRecordDTO();
        replenishmentRecordDTO.documentNumber = updatedDueOut.documentNumber;
        replenishmentRecordDTO.enterpriseProductIdentifier = updatedDueOut.enterpriseProductIdentifier;
        replenishmentRecordDTO.packaging = updatedDueOut.packageUnit;
        //replenishmentRecordDTO.unitPrice = updatedDueOut.unitPrice;
        replenishmentRecordDTO.unitPrice = updatedDueOut.unitPrice != null ? updatedDueOut.unitPrice : new MonetaryValue(0);
        replenishmentRecordDTO.backOrderIndicator = "Y";
        replenishmentRecordDTO.itemLocationIdentifier = updatedDueOut.itemLocationIdentifier;
        replenishmentRecordDTO.customerDueinRef = getCustomerDueInRefFromDueOut(updatedDueOut);
        return replenishmentRecordDTO;
    }

    private void updateReplenishmentRecordDtoInventoryRecordRelatedFields(InventorySystem system, DueOut updatedDueOut, ReplenishmentRecordDTO replenishmentRecordDTO) {
        InventoryRecord inventoryRecord = inventoryService.getRecordByOwnerAndProduct(system.nodeRef.getId(), updatedDueOut.enterpriseProductIdentifier);
        replenishmentRecordDTO.buyerRef = buyerService.getBuyerForNodeId(system.nodeRef.getId()).getRef();
        replenishmentRecordDTO.sellerRef = inventoryRecord.sellerRef;
        replenishmentRecordDTO.inventorySystemRef = inventoryRecord.inventorySystemRef;
        replenishmentRecordDTO.inventoryRecordId = inventoryRecord.getId();
        replenishmentRecordDTO.itemDescription = inventoryRecord.catalogRef.shortDescription;
        replenishmentRecordDTO.locationRef = inventoryService.getPrimaryLocationByInventoryRecordId(inventoryRecord.getId());
    }

    private DueinRef getCustomerDueInRefFromDueOut(DueOut dueOut){
        DueIn dueIn = dueInService.getDueInByDocumentNumber(dueOut.documentNumber,
                dueOut.buyerRef.id, dueOut.fulfillmentRef.orderLineItemId);
        if (null == dueIn) {
            return null;
        }
        return dueIn.getRef();
    }

    private Fulfillment createFulfillmentHistoryRecord(String dueOutFulfillmentRefId, Integer quantity, MonetaryValue price, String reason) {
        FulfillmentHistory fulfillmentHistory = new FulfillmentHistory();
        fulfillmentHistory.quantity = quantity;
        fulfillmentHistory.price = price;
        fulfillmentHistory.reason = reason;
        return microservice.addFulfillmentHistory(dueOutFulfillmentRefId, fulfillmentHistory);

    }

}
