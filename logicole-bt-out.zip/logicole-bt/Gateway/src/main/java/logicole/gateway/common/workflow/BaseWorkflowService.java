package logicole.gateway.common.workflow;

import logicole.common.crossservice.workflow.IWorkFlowMicroserviceApi;
import logicole.common.datamodels.PersistedEntity;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.workflow.EWorkflowActionType;
import logicole.common.datamodels.workflow.IWorkflowItem;
import logicole.common.datamodels.workflow.WorkflowAction;
import logicole.common.datamodels.workflow.WorkflowDefinition;
import logicole.common.datamodels.workflow.WorkflowDefinitionRef;
import logicole.common.datamodels.workflow.WorkflowState;
import logicole.common.datamodels.workflow.WorkflowStep;
import logicole.common.datamodels.workflow.WorkflowStepDefinition;
import logicole.common.datamodels.workflow.WorkflowStepDuration;
import logicole.common.datamodels.workflow.WorkflowStepSummary;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.CalendarDaySpan;
import logicole.common.general.util.CdiUtil;
import logicole.common.general.util.DateUtil;
import logicole.common.general.util.ListUtil;
import logicole.common.general.util.string.StringUtil;

import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public abstract class BaseWorkflowService<T extends PersistedEntity, U extends IWorkFlowMicroserviceApi> {

    @Inject
    protected U microservice;
    @Inject
    private CdiUtil cdiUtil;
    @Inject
    private ListUtil listUtil;

    public static final String HOLD_ACTION = "Hold";
    public static final String RESUME_ACTION = "Resume";

    public T startAction(@NotNull IWorkflowItem objectToProcess,
                         @NotNull String workflowName,
                         @NotNull OrganizationRef orgRef) {
        return startAction(objectToProcess, workflowName, 0, orgRef);
    }

    public T startAction(@NotNull IWorkflowItem objectToProcess,
                         @NotNull String workflowName,
                         @NotNull int startWorkflowStepPosition,
                         @NotNull OrganizationRef orgRef) {

        WorkflowDefinition workflowDefinition = microservice.findCurrentWorkflowByName(workflowName);

        WorkflowState state = new WorkflowState();
        state.workflowDefinitionRef = workflowDefinition.getRef();
        state.currentStep = setupNewStep(null, startWorkflowStepPosition, workflowDefinition);
        state.currentPosition = startWorkflowStepPosition;
        state.modifiedMillis = new Date().getTime();

        state.organizationRef = orgRef;

        objectToProcess.setWorkflowState(state);
        return (T) microservice.updateWorkflowState(objectToProcess.getId(), null, state);
    }

    public T takeAction(@NotNull IWorkflowItem objectToProcess,
                        @NotNull String action,
                        @NotNull CurrentUser currentUser) {
        return takeAction(objectToProcess, action, currentUser, false);
    }

    public T takeAction(@NotNull IWorkflowItem objectToProcess,
                        @NotNull String action,
                        @NotNull CurrentUser currentUser,
                        boolean isOverride) {
        return takeAction(objectToProcess, action, currentUser, isOverride, null, false);
    }

    public T takeAction(@NotNull IWorkflowItem objectToProcess,
                        @NotNull String action,
                        @NotNull CurrentUser currentUser,
                        boolean isOverride,
                        Date customActionDate,
                        Boolean actionDateEqualsStepEntryDate) {
        // TODO remove date parameters, just use RequestData.requestWorkflowData instead for handling custom dates
        WorkflowState workflowState = objectToProcess.getWorkflowState();
        WorkflowDefinitionRef workflowDefinitionRef = workflowState.workflowDefinitionRef;

        WorkflowDefinition workflowDefinition = microservice.findWorkflowById(workflowDefinitionRef.id);
        if (workflowDefinition == null) {
            throw new ApplicationException("Workflow definition not found - " + workflowDefinitionRef.name);
        }
        WorkflowStepDefinition currentStepDefinition = workflowDefinition.steps.get(workflowState.currentPosition);
        WorkflowAction wfAction = getWorkflowAction(action, currentStepDefinition, workflowState.currentStep);

        T updatedItem = null;

        if (!isOverride && !StringUtil.isBlankOrNull(wfAction.actionOverrideName)) {
            IWorkflowStepActionOverride actionOverrideProcessor =
                    cdiUtil.getNamedClass(wfAction.actionOverrideName, IWorkflowStepActionOverride.class);
            List<String> overrideActions = actionOverrideProcessor.determineOverride(action, workflowState, objectToProcess);
            if (!listUtil.isNullOrEmpty(overrideActions)) {
                for (String overrideAction : overrideActions) {
                    updatedItem = takeAction(objectToProcess, overrideAction, currentUser, true, customActionDate, actionDateEqualsStepEntryDate);
                    objectToProcess = (IWorkflowItem) updatedItem;
                }
                return updatedItem;
            }
        }

        // validate step
        if (!StringUtil.isBlankOrNull(currentStepDefinition.stepExitValidatorCdiName)) {
            IWorkflowValidator stepValidator = cdiUtil.getNamedClass(currentStepDefinition.stepExitValidatorCdiName, IWorkflowValidator.class);
            stepValidator.validate(workflowState, objectToProcess);
        }

        //validate action
        if (!StringUtil.isBlankOrNull(wfAction.actionValidatorCdiName)) {
            IWorkflowValidator actionValidator = cdiUtil.getNamedClass(wfAction.actionValidatorCdiName, IWorkflowValidator.class);
            actionValidator.validate(workflowState, objectToProcess);
        }

        // process action
        if (customActionDate == null) {
            updatedItem = processWorkflowAction(wfAction, workflowState, objectToProcess, action, workflowDefinition, currentUser);
        } else {
            updatedItem = processWorkflowAction(
                    wfAction, workflowState, objectToProcess, action, workflowDefinition, currentUser, customActionDate, actionDateEqualsStepEntryDate);
        }

        return updatedItem;
    }

    void validateOnHold(String action,
                        WorkflowStepDefinition currentStepDefinition,
                        WorkflowStep workflowStep) {
        if (!currentStepDefinition.allowHold && HOLD_ACTION.equalsIgnoreCase(action)) {
            throw new ApplicationException("Workflow Item is not allowed to be put on hold in this step");
        }
        if (HOLD_ACTION.equalsIgnoreCase(workflowStep.previousActionName) && !RESUME_ACTION.equalsIgnoreCase(action)) {
            throw new ApplicationException("Workflow Item is on hold. Only the resume action is allowed");
        }
    }

    void validateResume(String action, WorkflowStep workflowStep) {
        if (RESUME_ACTION.equalsIgnoreCase(workflowStep.previousActionName) && RESUME_ACTION.equalsIgnoreCase(action)) {
            throw new ApplicationException("Workflow Item has already been resumed");
        }
    }

    public T processWorkflowAction(WorkflowAction wfAction, WorkflowState workflowState,
                                   IWorkflowItem objectToProcess, String action, WorkflowDefinition workflowDefinition,
                                   CurrentUser currentUser) {
        return processWorkflowAction(
                wfAction, workflowState, objectToProcess, action, workflowDefinition, currentUser, null, false);
    }

    public T processWorkflowAction(WorkflowAction wfAction, WorkflowState workflowState,
                                   IWorkflowItem objectToProcess, String action, WorkflowDefinition workflowDefinition,
                                   CurrentUser currentUser, Date customActionDate, Boolean actionDateEqualsStepEntryDate) {
        // TODO remove date parameters, just use RequestData.requestWorkflowData instead for handling custom dates
        WorkflowStep currentStepPosition = workflowState.currentStep;

        if (customActionDate != null) {
            currentStepPosition.actionDate = customActionDate;
            if (Boolean.TRUE.equals(actionDateEqualsStepEntryDate)) {
                currentStepPosition.stepEntryDate = customActionDate;
            }
        } else {
            currentStepPosition.actionDate = new Date();
        }

        currentStepPosition.workflowActionName = action;
        currentStepPosition.currentUserBtRef = currentUser.getRef();
        currentStepPosition.message = wfAction.message;
        handleWorkflowStepDuration(currentStepPosition);

        //take action
        if (!StringUtil.isEmptyOrNull(wfAction.actionProcessorCdiName)) {
            IWorkflowProcessor processor = cdiUtil.getNamedClass(wfAction.actionProcessorCdiName, IWorkflowProcessor.class);
            processor.process(workflowState, objectToProcess, currentUser.profile, action);
        }

        //handle 'hold' or 'resume' situation if applicable
        if ((HOLD_ACTION.equalsIgnoreCase(action) || RESUME_ACTION.equalsIgnoreCase(action))
                && !StringUtil.isEmptyOrNull(workflowDefinition.holdProcessor)) {
            IWorkflowProcessor processor = cdiUtil.getNamedClass(workflowDefinition.holdProcessor, IWorkflowProcessor.class);
            processor.process(workflowState, objectToProcess, currentUser.profile, action);
        }

        WorkflowStep newStep = setupNewStep(wfAction, workflowDefinition);
        newStep.previousStepPosition = workflowState.currentPosition;
        workflowState.workflowStepHistories.add(currentStepPosition);
        workflowState.currentStep = newStep;
        handleStateProperties(workflowState, wfAction.addStateProperties, wfAction.removeStateProperties);

        Long previousModified = getPreviousModifiedDate(workflowState.modifiedMillis);
        workflowState.modifiedMillis = new Date().getTime();
        workflowState.currentPosition = wfAction.nextStepPosition;
        return (T) microservice.updateWorkflowState(objectToProcess.getId(), previousModified, workflowState);
    }

    public void handleWorkflowStepDuration(WorkflowStep currentStepPosition) {
        CalendarDaySpan calendarDaySpan = DateUtil.calculateCalendarDaysBetweenDates(currentStepPosition.stepEntryDate, currentStepPosition.actionDate);
        currentStepPosition.workflowStepDuration = new WorkflowStepDuration();
        currentStepPosition.workflowStepDuration.calendarDays = calendarDaySpan.days;
        currentStepPosition.workflowStepDuration.calendarHours = calendarDaySpan.hours;
        currentStepPosition.workflowStepDuration.calendarMinutes = calendarDaySpan.minutes;
        currentStepPosition.workflowStepDuration.businessDays = DateUtil.calculateBusinessDays(currentStepPosition.stepEntryDate, currentStepPosition.actionDate);
    }

    public void handleStateProperties(WorkflowState workflowState, List<String> addStateProperties, List<String> removeStateProperties) {
        List<String> stateProperties = workflowState.stateProperties;

        stateProperties.removeAll(removeStateProperties);

        for (String prop : addStateProperties) {
            if (!stateProperties.contains(prop)) {
                stateProperties.add(prop);
            }
        }
    }

    public Long getPreviousModifiedDate(Long modifiedMillis) {
        Long prev = null;
        if (modifiedMillis != null) {
            prev = modifiedMillis;
        }
        return prev;
    }

    public WorkflowStep setupNewStep(WorkflowAction wfAction, WorkflowDefinition workflowDefinition) {
        return setupNewStep(wfAction, 0, workflowDefinition);
    }

    public WorkflowStep setupNewStep(WorkflowAction wfAction, int nextStepPosition, WorkflowDefinition workflowDefinition) {

        WorkflowStep newStep = new WorkflowStep();
        newStep.stepEntryDate = new Date();

        if (wfAction != null) {
            nextStepPosition = wfAction.nextStepPosition;
            newStep.previousActionName = wfAction.name;
        }

        newStep.workflowStepDefinition = workflowDefinition.steps.get(nextStepPosition);
        // Need to populate name so that startAction method works correctly, but TODO ...determine if workflowActionName and name are redundant
        newStep.name = newStep.workflowStepDefinition.name;

        return newStep;
    }

    public WorkflowAction getWorkflowAction(String action, WorkflowStepDefinition workflowStepDefinition, WorkflowStep currentStep) {
        WorkflowAction foundAction = null;

        validateOnHold(action, workflowStepDefinition, currentStep);
        validateResume(action, currentStep);

        if (HOLD_ACTION.equalsIgnoreCase(currentStep.previousActionName)) {
            return buildResumeAction(workflowStepDefinition);
        } else if (HOLD_ACTION.equalsIgnoreCase(action)) {
            return buildHoldAction(workflowStepDefinition);
        }

        for (WorkflowAction definitionAction : workflowStepDefinition.workflowActions) {
            if (definitionAction.name.equals(action)) {
                foundAction = definitionAction;
                break;
            }
        }
        if (foundAction == null) {
            String msg = String.format("Workflow action %s not found in workflow step %s", action, workflowStepDefinition.name);
            throw new WorkflowValidationException(msg);
        }

        // if nextStepPosition = -1, it's determined by previous step 
        if (foundAction.nextStepPosition == -1) {
            foundAction.nextStepPosition = currentStep.previousStepPosition;
        }
        return foundAction;
    }

    public List<WorkflowStepSummary> buildWorkflowStepSummary(IWorkflowItem workflowItem) {

        WorkflowState workflowState = workflowItem.getWorkflowState();
        //Set the history steps first
        if (null == workflowState || null == workflowState.workflowStepHistories) {
            throw new ApplicationException("The workflow has not been initialized");
        }

        //Get full list of workflow definitions to build out rest of available steps
        WorkflowDefinition workflowDefinition = microservice.findWorkflowById(workflowState.workflowDefinitionRef.id);

        //Set Remaining steps
        if (null == workflowDefinition || workflowDefinition.steps.isEmpty()) {
            throw new ApplicationException("The workflow item has no workflow definitions defined");
        }

        return setWorkflowSteps(workflowState, workflowDefinition, workflowItem);
    }

    private List<WorkflowStepSummary> setWorkflowSteps(WorkflowState workflowState, WorkflowDefinition workflowDefinition, IWorkflowItem workflowItem) {
        //build list using history. when done with history build with definition
        WorkflowStepSummary[] summaries = new WorkflowStepSummary[workflowDefinition.steps.size()];
        int lastPosition = 0;

        for (WorkflowStep step : workflowState.workflowStepHistories) {
            WorkflowStepDefinition stepDefinition = getWorkflowStepDefinition(step, workflowDefinition);

            if (stepDefinition == null) {
                throw new ApplicationException("The workflow step has no workflow definition");
            }

            if (step.workflowStepDefinition.position < lastPosition) {
                // Clear out future workflow steps whenever the workflow goes back to an earlier step
                // to ensure that if a step is skipped in the future the correct state is shown.
                for (int j = step.workflowStepDefinition.position; j < summaries.length; j++) {
                    summaries[j] = null;
                }
            }

            WorkflowStepSummary workflowStepSummary = new WorkflowStepSummary();
            workflowStepSummary.stepName = step.name;
            workflowStepSummary.isCurrentStep = stepDefinition.position == workflowState.currentPosition;
            workflowStepSummary.workflowActionName = step.workflowActionName;
            workflowStepSummary.workflowActionType = getActionType(workflowStepSummary.workflowActionName, stepDefinition);
            workflowStepSummary.message = step.message;

            summaries[stepDefinition.position] = workflowStepSummary;
            lastPosition = stepDefinition.position;
        }


        int currentPosition = workflowState.currentPosition;
        boolean atEnd = false;
        while (!atEnd) {
            WorkflowStepDefinition step = workflowDefinition.steps.get(currentPosition);
            WorkflowStepSummary workflowStepSummary = summaries[step.position];

            if (workflowStepSummary == null
                    || shouldClearStepSummaryState(workflowState, workflowStepSummary)) {
                workflowStepSummary = new WorkflowStepSummary();
                workflowStepSummary.stepName = step.name;
                workflowStepSummary.isCurrentStep = step.position == workflowState.currentPosition;
            }

            if (workflowStepSummary.isCurrentStep) {
                workflowStepSummary.stepActions = buildWorkflowStepActions(workflowState.currentStep, step, workflowItem);
                if (workflowState.currentStep.previousStepPosition > workflowState.currentPosition) {
                    workflowStepSummary.workflowActionName = workflowState.currentStep.previousActionName;
                    workflowStepSummary.message = getPreviousActionMessage(workflowState.currentStep, workflowDefinition);

                }
            }

            summaries[currentPosition] = workflowStepSummary;
            if (step.isEndOfWorkflow) {
                atEnd = true;
            } else {
                currentPosition = getNextPosition(currentPosition, step);
            }
        }

        // remove any null array items
        List<WorkflowStepSummary> workflowStepSummaryList = new ArrayList<>();
        workflowStepSummaryList.addAll(Arrays.asList(summaries));
        workflowStepSummaryList.removeIf(Objects::isNull);
        return workflowStepSummaryList;
    }

    int getNextPosition(int currentPosition, WorkflowStepDefinition step) {
        int nextPosition = 0;
        boolean nextFound = false;
        for (WorkflowAction action : step.workflowActions) {
            if (action.isDefault) {
                nextPosition = action.nextStepPosition;
                nextFound = true;
            }
        }

        if (!nextFound) {
            nextPosition = currentPosition + 1;
        }

        return nextPosition;
    }

    private String getPreviousActionMessage(WorkflowStep step, WorkflowDefinition workflowDefinition) {
        int position = step.previousStepPosition;
        String action = step.previousActionName;

        WorkflowStepDefinition foundStep = workflowDefinition.steps.stream().filter(s -> s.position == position).findFirst().get();
        return foundStep.workflowActions.stream().filter(a -> a.name.equals(action)).findFirst().get().message;
    }

    private boolean shouldClearStepSummaryState(WorkflowState workflowState, WorkflowStepSummary workflowStepSummary) {
        boolean clearStepSummary = false;

        if (!workflowStepSummary.isCurrentStep
                && !EWorkflowActionType.ERROR.equals(workflowStepSummary.workflowActionType)) {
            clearStepSummary = true;
        }

        if (!clearStepSummary && workflowState.workflowStepHistories != null
                && !workflowState.workflowStepHistories.isEmpty()) {
            WorkflowStep lastStepHistory = workflowState.workflowStepHistories.get(workflowState.workflowStepHistories.size() - 1);
            clearStepSummary = !lastStepHistory.name.equals(workflowStepSummary.stepName);
        }

        return clearStepSummary;
    }

    private WorkflowStepDefinition getWorkflowStepDefinition(WorkflowStep step, WorkflowDefinition workflowDefinition) {
        if (workflowDefinition != null && workflowDefinition.steps != null && !workflowDefinition.steps.isEmpty()) {
            Optional<WorkflowStepDefinition> workflowStepDefinition = workflowDefinition.steps.stream()
                    .filter(stepDefinition -> stepDefinition.name.equals(step.name)).findFirst();

            if (workflowStepDefinition.isPresent()) {
                return workflowStepDefinition.get();
            }
        }

        return null;
    }

    private EWorkflowActionType getActionType(String workflowActionName, WorkflowStepDefinition stepDefinition) {
        EWorkflowActionType type = null;

        for (WorkflowAction action : stepDefinition.workflowActions) {
            if (action.name.equals(workflowActionName)) {
                type = action.type;
                break;
            }
        }
        return type;
    }

    WorkflowAction buildResumeAction(WorkflowStepDefinition stepDefinition) {
        WorkflowAction resumeAction = new WorkflowAction();
        resumeAction.name = RESUME_ACTION;
        resumeAction.apiEndpointName = "resume";
        resumeAction.message = RESUME_ACTION;
        resumeAction.nextStepPosition = stepDefinition.position;
        resumeAction.message = RESUME_ACTION;
        resumeAction.type = EWorkflowActionType.SUCCESS;
        resumeAction.element = "workflow-resume";
        resumeAction.icon = "fa fa-arrow-up";
        return resumeAction;
    }

    WorkflowAction buildHoldAction(WorkflowStepDefinition stepDefinition) {
        WorkflowAction holdAction = new WorkflowAction();
        holdAction.name = HOLD_ACTION;
        holdAction.apiEndpointName = "hold";
        holdAction.message = HOLD_ACTION;
        holdAction.nextStepPosition = stepDefinition.position;
        holdAction.message = HOLD_ACTION;
        holdAction.type = EWorkflowActionType.SUCCESS;
        holdAction.element = "workflow-hold";
        holdAction.icon = "fa fa-arrow-down";
        return holdAction;
    }

    private List<WorkflowAction> buildWorkflowStepActions(WorkflowStep currentStep, WorkflowStepDefinition stepDefinition, IWorkflowItem workflowItem) {
        List<WorkflowAction> stepActions = new ArrayList<>();

        if (HOLD_ACTION.equalsIgnoreCase(currentStep.previousActionName)) {
            stepActions.add(buildResumeAction(stepDefinition));
        } else {
            if (stepDefinition.allowHold) {
                stepActions.add(buildHoldAction(stepDefinition));
            }

            for (WorkflowAction stepAction : stepDefinition.workflowActions) {
                if (stepAction.isVisible
                        && !isActionThePreviousAction(currentStep, stepDefinition, stepAction)
                        && isActionVisible(stepAction, workflowItem)) {
                    stepActions.add(stepAction);
                }
            }
        }
        stepActions.sort(Comparator.comparing(act -> act.name));

        return stepActions;
    }

    private boolean isActionThePreviousAction(WorkflowStep currentStep, WorkflowStepDefinition stepDefinition, WorkflowAction stepAction) {
        return currentStep != null && currentStep.previousActionName != null
                && currentStep.previousStepPosition == stepDefinition.position
                && currentStep.previousActionName.equals(stepAction.name)
                && !isActionAllowedConsecutively(stepAction);
    }

    private boolean isActionVisible(WorkflowAction workflowAction, IWorkflowItem workflowItem) {
        boolean isVisible = true;

        if (workflowAction.actionVisibilityCdiName != null) {
            IWorkflowVisibilityRule visibilityRule = cdiUtil.getNamedClass(workflowAction.actionVisibilityCdiName, IWorkflowVisibilityRule.class);
            isVisible = visibilityRule.isVisible(workflowAction, workflowItem);
        }

        return isVisible;
    }

    private boolean isActionAllowedConsecutively(WorkflowAction workflowAction) {
        boolean isPreviousActionAllowedAgain = false;

        if (workflowAction.actionVisibilityCdiName != null) {
            IWorkflowVisibilityRule visibilityRule = cdiUtil.getNamedClass(workflowAction.actionVisibilityCdiName, IWorkflowVisibilityRule.class);
            isPreviousActionAllowedAgain = visibilityRule.isActionAllowedConsecutively();
        }

        return isPreviousActionAllowedAgain;
    }

}
