package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetMaintenanceProcedureMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AssetMaintenanceProcedureMicroserviceClient extends MicroserviceClient<IAssetMaintenanceProcedureMicroserviceApi> {
    public AssetMaintenanceProcedureMicroserviceClient() {
        super(IAssetMaintenanceProcedureMicroserviceApi.class, "logicole-asset");
    }
    
    @Produces
    public IAssetMaintenanceProcedureMicroserviceApi getIAssetMicroserviceApi() {
        return createClient();
    }
}
