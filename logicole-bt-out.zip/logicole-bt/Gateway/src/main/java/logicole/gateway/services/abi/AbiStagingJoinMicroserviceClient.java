package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiStagingJoinMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiStagingJoinMicroserviceClient extends MicroserviceClient<IAbiStagingJoinMicroserviceApi> {
    public AbiStagingJoinMicroserviceClient() {
        super(IAbiStagingJoinMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiStagingJoinMicroserviceApi getABiStagingJoinService() {
        return createClient();
    }
}

