package logicole.gateway.services.system;

import io.swagger.annotations.Api;
import logicole.common.datamodels.general.customfield.CustomField;
import logicole.common.datamodels.general.customizabletype.CustomizableType;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import java.util.List;

@Api(tags = {"CustomField"})
@ApplicationScoped
@Path("/customField")
public class CustomFieldRestApi extends ExternalRestApi<CustomFieldService> {

    @GET
    @Path("/getCustomFieldTypes")
    public List<String> getCustomFieldTypes() {
        return service.getCustomFieldTypes();
    }

    @GET
    @Path("/getCustomizableTypes")
    public List<CustomizableType> getCustomizableTypes() {
        return service.getCustomizableTypes();
    }

    @GET
    @Path("/getAllCustomFields")
    public List<CustomField> getAllCustomFields(@NotNull @QueryParam("customizableTypeId") String customizableTypeId) {
        return service.getAllCustomFields(customizableTypeId);
    }

    @POST
    @Path("/addCustomField")
    public CustomField addCustomField(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                      @NotNull CustomField customField) {
        return service.addCustomField(customizableTypeId, customField);
    }

    @POST
    @Path("/updateCustomField")
    public CustomField updateCustomField(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                         @NotNull CustomField customField) {
        return service.updateCustomField(customizableTypeId, customField);
    }

    @POST
    @Path("/deleteCustomField")
    public void deleteCustomField(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                  @NotNull CustomField customField) {
        service.deleteCustomField(customizableTypeId, customField);
    }

    @GET
    @Path("/checkIfCustomFieldValuesExist")
    public boolean checkIfCustomFieldValuesExist(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                                 @NotNull @QueryParam("customFieldId") String customFieldId) {
        return service.checkIfCustomFieldValuesExist(customizableTypeId, customFieldId);
    }

    @GET
    @Path("/checkDuplicateLabel")
    public boolean checkDuplicateLabel(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                       @QueryParam("label") String label) {
        return service.checkDuplicateLabel(customizableTypeId, label);
    }
}
