package logicole.gateway.services.workorder;

import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.AssetSummary;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.EActiveStatus;
import logicole.common.datamodels.realproperty.Site;
import logicole.common.datamodels.realproperty.facility.FacilitySummary;
import logicole.common.datamodels.space.RoomSummary;
import logicole.common.datamodels.workorder.ClassificationType;
import logicole.common.datamodels.workorder.Comment;
import logicole.common.datamodels.workorder.EWorkflowActionName;
import logicole.common.datamodels.workorder.EWorkflowStepName;
import logicole.common.datamodels.workorder.PriorityGroup;
import logicole.common.datamodels.workorder.ServiceRequest;
import logicole.common.datamodels.workorder.ServiceRequestSearchCriteria;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.general.exception.ValidationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.remote.IDefaultRemoteApi;
import logicole.gateway.services.realproperty.FacilityService;
import logicole.gateway.services.realproperty.InstallationService;
import logicole.gateway.services.spacemanagement.SpaceManagementService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@ApplicationScoped
public class ServiceRequestService extends BaseGatewayService<IDefaultRemoteApi> {
    @Inject
    private WorkOrderService service;
    @Inject
    private InstallationService installationService;
    @Inject
    private FacilityService facilityService;
    @Inject
    private SpaceManagementService spaceManagementService;

    public ServiceRequestService() {
        super("ServiceRequest");
    }

    public ServiceRequest createServiceRequest(ServiceRequest serviceRequest) {
        WorkOrder workOrder = service.createServiceRequest(mapServiceRequestToWorkOrder(serviceRequest));
        return mapWorkOrderToServiceRequest(workOrder);
    }

    public ServiceRequest requestCancel(ServiceRequest serviceRequest) {
        WorkOrder workOrder = service.requestCancel(mapServiceRequestToWorkOrder(serviceRequest));
        return mapWorkOrderToServiceRequest(workOrder);
    }

    public List<ServiceRequest> getServiceRequests(ServiceRequestSearchCriteria searchCriteria) {
        return service.getServiceRequests(searchCriteria);
    }

    public ServiceRequest cloneServiceRequest(String id) {
        return mapWorkOrderToServiceRequest(service.cloneServiceRequest(id));
    }

    public List<AssetSummary> getAssetSummariesByFacilityId(String facilityId) {
        return service.getAssetSummariesByFacilityId(facilityId, EActiveStatus.ACTIVE);
    }

    public ServiceRequest addNote(String id, Note note) {
        return mapWorkOrderToServiceRequest(service.addNote(id, note));
    }

    public ServiceRequest saveNote(String id, Note note) {
        return mapWorkOrderToServiceRequest(service.saveNote(id, note));
    }

    public ServiceRequest removeNote(String id, Note note) {
        return mapWorkOrderToServiceRequest(service.removeNote(id, note));
    }

    public Integer getMaxUploadSize() {
        return service.getMaxUploadSize();
    }

    public Attachment saveAttachment(String id, Attachment attachmentToSave) {
        return service.saveAttachment(id, attachmentToSave);
    }

    public List<Attachment> removeAttachment(String id, String fileId) throws IOException {
        return service.removeAttachment(id, fileId);
    }

    public void removeAttachments(List<String> fileIds) {
        service.removeAttachments(fileIds);
    }

    public FileManager uploadFile(byte[] content, String uploadedFileName) {
        return service.uploadFile(content, uploadedFileName);
    }

    public ServiceRequest updateDetails(ServiceRequest serviceRequest) {
        validateServiceRequestEditAllowed(serviceRequest);
        WorkOrder workOrder = service.updateServiceRequestDetails(mapServiceRequestToWorkOrder(serviceRequest));
        return mapWorkOrderToServiceRequest(workOrder);
    }

    public List<ClassificationType> getActiveClassificationTypes() {
        return service.getActiveClassificationTypes();
    }

    public List<PriorityGroup> getActiveServiceRequestPriorityGroups() {
        return service.getActiveServiceRequestPriorityGroups();
    }

    private ServiceRequest mapWorkOrderToServiceRequest(WorkOrder workOrder) {
        ServiceRequest serviceRequest = new ServiceRequest();
        serviceRequest.setId(workOrder.getId());
        serviceRequest.workOrderNumber = workOrder.workOrderNumber;
        serviceRequest.subject = workOrder.subject;
        serviceRequest.description = workOrder.description;
        serviceRequest.justification = workOrder.justification;
        serviceRequest.otherLocation = workOrder.otherLocation;
        serviceRequest.classificationTypeRef = workOrder.classificationTypeRef;
        serviceRequest.estimatedStartDate = workOrder.estimatedStartDate;
        serviceRequest.requestDate = workOrder.requestDate;
        serviceRequest.requesterName = workOrder.requesterName;
        serviceRequest.requesterContactNumber = workOrder.requesterContactNumber;
        serviceRequest.priorityGroupRef = workOrder.priorityGroupRef;
        serviceRequest.siteRef = workOrder.siteRef;
        serviceRequest.facilityRef = workOrder.facilityRef;
        serviceRequest.workflowState = workOrder.workflowState;
        serviceRequest.clonedWorkOrderId = workOrder.clonedWorkOrderId;
        serviceRequest.requestType = workOrder.requestType;
        serviceRequest.assetRefs = workOrder.assetRefs;
        serviceRequest.spaceRefs = workOrder.spaceRefs;
        serviceRequest.attachments = workOrder.attachments;
        serviceRequest.isSurveyCompleted = workOrder.isSurveyCompleted;
        serviceRequest.newComment = workOrder.newComment;
        serviceRequest.createdByRef = workOrder.createdByRef;

        return serviceRequest;
    }

    private WorkOrder mapServiceRequestToWorkOrder(ServiceRequest serviceRequest) {
        WorkOrder workOrder = new WorkOrder();

        workOrder.setId(serviceRequest.getId());
        workOrder.workOrderNumber = serviceRequest.workOrderNumber;
        workOrder.subject = serviceRequest.subject;
        workOrder.description = serviceRequest.description;
        workOrder.justification = serviceRequest.justification;
        workOrder.otherLocation = serviceRequest.otherLocation;
        workOrder.classificationTypeRef = serviceRequest.classificationTypeRef;
        workOrder.estimatedStartDate = serviceRequest.estimatedStartDate;
        workOrder.requestDate = serviceRequest.requestDate;
        workOrder.requesterName = serviceRequest.requesterName;
        workOrder.requesterContactNumber = serviceRequest.requesterContactNumber;
        workOrder.priorityGroupRef = serviceRequest.priorityGroupRef;
        workOrder.siteRef = serviceRequest.siteRef;
        workOrder.facilityRef = serviceRequest.facilityRef;
        workOrder.workflowState = serviceRequest.workflowState;
        workOrder.clonedWorkOrderId = serviceRequest.clonedWorkOrderId;
        workOrder.requestType = serviceRequest.requestType;
        workOrder.assetRefs = serviceRequest.assetRefs;
        workOrder.spaceRefs = serviceRequest.spaceRefs;
        workOrder.attachments = serviceRequest.attachments;
        workOrder.isSurveyCompleted = serviceRequest.isSurveyCompleted;
        workOrder.newComment = serviceRequest.newComment;
        workOrder.createdByRef = serviceRequest.createdByRef;

        return workOrder;
    }

    public List<Site> getAllSites() {
        return installationService.getAllSites();
    }

    public List<FacilitySummary> getActiveFacilitiesBySiteUid(String rpsuid) {
        return facilityService.getActiveFacilitiesBySiteUid(rpsuid, true);
    }

    public List<RoomSummary> getRoomSummariesByFacilityId(String facilityId) {
        return spaceManagementService.getRoomSummariesByFacilityIds(Collections.singletonList(facilityId));
    }

    public ServiceRequest updateLocation(ServiceRequest serviceRequest) {
        validateServiceRequestEditAllowed(serviceRequest);
        WorkOrder workOrder = mapServiceRequestToWorkOrder(serviceRequest);
        return mapWorkOrderToServiceRequest(service.updateServiceRequestLocation(workOrder));
    }

    public ServiceRequest updateAssets(ServiceRequest serviceRequest) {
        validateServiceRequestEditAllowed(serviceRequest);
        WorkOrder workOrder = mapServiceRequestToWorkOrder(serviceRequest);
        return mapWorkOrderToServiceRequest(service.updateWorkOrderAssets(workOrder));
    }

    public List<AssetSummary> getAssetsByIds(List<AssetRef> assetList) {
        return service.getAssetsByIds(assetList);
    }

    public List<String> getDocumentTypes() {
        return service.getDocumentTypes();
    }

    public ServiceRequest findById(String id) {
        WorkOrder workOrder = service.findById(id);
        ServiceRequest serviceRequest = mapWorkOrderToServiceRequest(workOrder);
        addCancellationCommentsToServiceRequest(workOrder, serviceRequest);
        return serviceRequest;
    }

    private void addCancellationCommentsToServiceRequest(WorkOrder workOrder, ServiceRequest serviceRequest) {
        if (!workOrder.comments.isEmpty()) {
            Optional<Comment> requestCancelComment = workOrder.comments.stream()
                    .filter(comment -> Objects.equals(comment.action, EWorkflowActionName.REQUEST_CANCEL.displayText))
                    .findFirst();
            requestCancelComment.ifPresent(comment -> serviceRequest.requestCancelComment = comment.text);
            Optional<Comment> cancelComment = workOrder.comments.stream()
                    .filter(comment -> Objects.equals(comment.action, EWorkflowActionName.CANCEL_SERVICE_REQUEST.displayText))
                    .findFirst();
            cancelComment.ifPresent(comment -> serviceRequest.facilityManagerCancelComment = comment.text);
            Optional<Comment> reviewCompleteComment = workOrder.comments.stream()
                    .filter(comment -> Objects.equals(comment.action, EWorkflowActionName.COMPLETE.displayText))
                    .findFirst();
            reviewCompleteComment.ifPresent(comment -> serviceRequest.reviewCompleteComment = comment.text);
            Optional<Comment> finalAcceptanceAcceptComment = workOrder.comments.stream()
                    .filter(comment -> Objects.equals(comment.action, EWorkflowActionName.ACCEPT.displayText))
                    .findFirst();
            finalAcceptanceAcceptComment.ifPresent(comment -> serviceRequest.finalAcceptanceAcceptComment = comment.text);
        }
    }

    private void validateServiceRequestEditAllowed(@NotNull ServiceRequest serviceRequest) {
        if (!Objects.equals(serviceRequest.createdByRef.id, currentUserBT.getProfileId())) {
            throw new ValidationException("You do not have permission to edit this Service Request");
        }
        if (!Objects.equals(serviceRequest.workflowState.currentStep.name, EWorkflowStepName.SUBMITTED.displayText)) {
            throw new ValidationException("A Service Request cannot be edited once it leaves the Submitted step");
        }
    }
}