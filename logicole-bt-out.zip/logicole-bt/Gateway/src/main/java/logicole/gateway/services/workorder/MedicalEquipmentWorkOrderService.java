package logicole.gateway.services.workorder;

import logicole.apis.workorder.IMedicalEquipmentWorkOrderMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.filemanager.FileRef;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.maintenance.technician.TechnicianRef;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.workflow.WorkflowStepSummary;
import logicole.common.datamodels.workorder.EWorkLocation;
import logicole.common.datamodels.workorder.EWorkflowActionName;
import logicole.common.datamodels.workorder.EWorkflowName;
import logicole.common.datamodels.workorder.EWorkflowStepName;
import logicole.common.datamodels.workorder.MedicalEquipmentWorkOrderDashboardInfo;
import logicole.common.datamodels.workorder.PriorityGroup;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.datamodels.workorder.WorkOrderSavePersonnelWrapper;
import logicole.common.datamodels.workorder.WorkOrderType;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.exception.UnauthorizedException;
import logicole.common.general.security.SecurityConstants;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.MedicalEquipmentService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.maintenance.TechnicianService;
import logicole.gateway.services.workorder.validator.MedicalEquipmentWorkOrderGainValidator;
import logicole.gateway.services.workorder.workflow.MedicalEquipmentWorkOrderWorkflowService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class MedicalEquipmentWorkOrderService extends BaseGatewayService<IMedicalEquipmentWorkOrderMicroserviceApi> {

    private static final String INVALID_ATTACHMENT_MSG = "Attachment is missing or is not valid";

    @Inject
    private MedicalEquipmentWorkOrderGainValidator medicalEquipmentWorkOrderGainValidator;
    @Inject
    private MedicalEquipmentWorkOrderWorkflowService workflowService;
    @Inject
    private WorkOrderService workOrderService;
    @Inject
    private FileManagerAdminService fileManagerAdminService;
    @Inject
    private MedicalEquipmentService medicalEquipmentService;
    @Inject
    private TechnicianService technicianService;

    public MedicalEquipmentWorkOrderService() {
        super("MedicalWorkOrder");
    }

    public WorkOrder findById(String id) {
        WorkOrder workOrder = microservice.findById(id);
        validateWorkOrderUserAccess(workOrder);
        return workOrder;
    }

    private void validateWorkOrderUserAccess(WorkOrder workOrder) {
        if (!isMDBUser() && !workOrder.managedByOrganizationRef.ancestry.contains(currentUserBT.getCurrentNodeId())) {
            throw new UnauthorizedException("Unauthorized access");
        }
    }

    private boolean isMDBUser() {
        return Objects.equals(currentUserBT.getCurrentUser().profile.pkiDn, SecurityConstants.MDB_SPECIAL_USER_PROFILE_KEY);
    }

    public WorkOrder createWorkOrderFromMedicEquipmentGain(Asset medicalEquipment) {
        medicalEquipmentWorkOrderGainValidator.validate(medicalEquipment);
        WorkOrder workOrder = microservice.createWorkOrderFromMedicalEquipmentGain(medicalEquipment);
        workflowService.startUnassigned(workOrder, currentUserBT.getCurrentUser().profile.managedByNodeRef);
        return microservice.findById(workOrder.getId());
    }

    public SearchResult<WorkOrder> getWorkOrders(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getSearchEngine();
        if (ESearchEngine.ELASTIC.equals(searchEngine)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            return microservice.getWorkOrderSearchResults(searchInput);
        }
    }

    public MedicalEquipmentWorkOrderDashboardInfo getWorkOrderDashboardStats() {
        return microservice.getWorkOrderDashboardStats();
    }

    public WorkOrder addNote(String id, Note note) {
        return microservice.addNote(id, note);
    }

    public WorkOrder saveNote(String id, Note note) {
        return microservice.saveNote(id, note);
    }

    public WorkOrder removeNote(String id, Note note) {
        return microservice.removeNote(id, note);
    }

    public Integer getMaxUploadSize() {
        return workOrderService.getMaxUploadSize();
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) {
        try {
            return fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }
    }

    public Attachment saveAttachment(String id, Attachment attachmentToSave) {
        if (attachmentToSave == null || attachmentToSave.fileRef == null ||
                (StringUtil.isBlankOrNull(attachmentToSave.fileRef.id) && StringUtil.isBlankOrNull(attachmentToSave.fileRef.fileId))) {
            throw new ApplicationException(INVALID_ATTACHMENT_MSG);
        }

        String fileId = (!StringUtil.isBlankOrNull(attachmentToSave.fileRef.id) ? attachmentToSave.fileRef.id : attachmentToSave.fileRef.fileId);

        FileRef fileRef;
        if (!StringUtil.isBlankOrNull(attachmentToSave.fileRef.filePath)) {
            fileRef = attachmentToSave.fileRef;
        } else {
            fileRef = fileManagerAdminService.getFileRefById(fileId);
            if (fileRef == null) {
                throw new ApplicationException(INVALID_ATTACHMENT_MSG);
            }
        }

        makeFileIdsConsistent(fileRef, fileId);
        attachmentToSave.fileRef = fileRef;
        return microservice.saveAttachment(id, attachmentToSave);
    }

    private void makeFileIdsConsistent(FileRef fileRef, String fileId) {
        fileRef.id = fileId;
        fileRef.fileId = fileId;
    }

    public List<Attachment> removeAttachment(String id, String fileId) throws IOException {
        try {
            fileManagerAdminService.removeFile(fileId);
            return microservice.removeAttachment(id, fileId);
        } catch (FatalProcessingException | ApplicationException e) {
            throw new ApplicationException("Was not able to remove the file");
        }
    }

    public List<WorkOrderType> getWorkOrderTypes() {
        return microservice.getWorkOrderTypes();
    }

    public List<WorkOrderType> getUnscheduledWorkOrderTypes() {
        return microservice.getUnscheduledWorkOrderTypes();
    }

    public List<WorkOrderType> getScheduledWorkOrderTypes() {
        return microservice.getScheduledWorkOrderTypes();
    }

    public List<PriorityGroup> getPriorityGroups() {
        return microservice.getPriorityGroups();
    }

    public List<String> getWorkLocationOptions() {
        return EWorkLocation.getDisplayTextList();
    }

    public WorkOrder saveGeneralInformation(WorkOrder workOrder) {
        return microservice.saveGeneralInformation(workOrder);
    }

    public WorkOrder savePersonnel(WorkOrder workOrder) {
        WorkOrderSavePersonnelWrapper workOrderWrapper = microservice.savePersonnel(workOrder);

        if (WorkOrderSavePersonnelWrapper.EWorkflowActionNeeded.ASSIGN.equals(workOrderWrapper.workflowActionNeeded)) {
            assign(workOrderWrapper.workOrder);
        } else if (WorkOrderSavePersonnelWrapper.EWorkflowActionNeeded.UNASSIGN.equals(workOrderWrapper.workflowActionNeeded)) {
            unassign(workOrderWrapper.workOrder);
        }

        return workOrderWrapper.workOrder;
    }

    public boolean isWorkOrderCurrentlyAssigned(final WorkOrder workOrder) {
        return microservice.isWorkOrderCurrentlyAssigned(workOrder);
    }

    public boolean isWorkOrderOnHold(final WorkOrder workOrder) {
        return microservice.isWorkOrderOnHold(workOrder);
    }

    public WorkOrder saveServiceInformation(WorkOrder workOrder) {
        return microservice.saveServiceInformation(workOrder);
    }

    private WorkOrder assign(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.assign(workOrder, currentUserBT.getCurrentUser());
        return workOrder;
    }

    private WorkOrder unassign(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.unassign(workOrder, currentUserBT.getCurrentUser());
        return workOrder;
    }

    public WorkOrder hold(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.hold(workOrder, currentUserBT.getCurrentUser());
        return workOrder;
    }

    public WorkOrder resume(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.resume(workOrder, currentUserBT.getCurrentUser());
        return workOrder;
    }

    public WorkOrder setWorkInProgress(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.setWorkInProgress(workOrder, currentUserBT.getCurrentUser());
        return workOrder;
    }

    public WorkOrder complete(WorkOrder workOrderWorkItem) {
        WorkOrder workOrder = microservice.findById(workOrderWorkItem.getId());
        workflowService.complete(workOrder, currentUserBT.getCurrentUser());
        return microservice.findById(workOrderWorkItem.getId());
    }

    public List<WorkflowStepSummary> buildWorkflowStepSummary(WorkOrder workOrder) {
        return workflowService.buildWorkflowStepSummary(workOrder);
    }

    public boolean isAllowedToEditWorkOrder(String id) {
        return workOrderService.isAllowedToEditWorkOrder(id);
    }

    public WorkOrder createWorkOrder(WorkOrder workOrder) {
        workOrder.managedByOrganizationRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        workOrder.createdByRef = currentUserBT.getCurrentUser().profile.getRef();
        WorkOrder newWorkOrder = microservice.createWorkOrder(workOrder);
        workflowService.startAction(newWorkOrder, EWorkflowName.STANDARD_MEDICAL_EQUIPMENT_WORK_ORDER.displayText, EWorkflowStepName.SUBMITTED.position, currentUserBT.getCurrentUser().profile.managedByNodeRef);
        workflowService.takeAction(newWorkOrder, EWorkflowActionName.UNASSIGN.displayText, currentUserBT.getCurrentUser());
        return newWorkOrder;
    }

    public List<Asset> getAvailableEquipment(String customerId) {
        return medicalEquipmentService.getAvailableEquipment(customerId);
    }

    public List<OrganizationRef> getEquipmentCustomers() {
        return medicalEquipmentService.getEquipmentCustomers();
    }

    public List<WorkOrder> getOpenWorkOrders(String customerId, String ecn) {
        return microservice.getOpenWorkOrders(customerId, ecn);
    }

    public Asset getAssetById(String assetId) {
        return medicalEquipmentService.getAssetById(assetId);
    }

    public List<TechnicianRef> getAvailableTechniciansByOrganizationId(@NotNull String organizationId) {
        return technicianService.getAvailableTechniciansByOrganizationId(organizationId);
    }

}