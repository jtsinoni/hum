package logicole.gateway.services.sale;

import io.swagger.annotations.Api;
import logicole.common.datamodels.order.order.OrderDTO;
import logicole.common.datamodels.product.OfferSellerUpdateResponse;
import logicole.common.datamodels.sale.seller.*;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Api(tags = {"Seller"})
@ApplicationScoped
@Path("/seller")
public class SellerRestApi extends ExternalRestApi<SellerService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getAllSellers")
    public List<Seller> getAllSellers() {
        return service.getAllSellers();
    }

    @GET
    @Path("/getSellersForNewAccount")
    public List<Seller> getSellersForNewAccount(@QueryParam("organizationId") String organizationId) {
        return service.getSellersForNewAccount(organizationId);
    }

    @GET
    @Path("/getSellerList")
    public List<Seller> getSellerList(@QueryParam("externalIndicator") boolean externalIndicator) {
        return service.getSellerList(externalIndicator);
    }

    @GET
    @Path("/getSellerListByType")
    public List<Seller> getSellerListByType(@QueryParam("sellerType") String sellerType) {
        return service.getSellerListByType(sellerType);
    }

    @POST
    @Path("/getSellerListByTypes")
    public List<Seller> getSellerListByTypes(List<String> sellerTypes) {
        return service.getSellerListByTypes(sellerTypes);
    }

    @GET
    @Path("/getSellerById")
    public Seller getSellerById(@QueryParam("sellerId") String sellerId) {
        return service.getSellerById(sellerId);
    }

    @GET
    @Path("/getSellerLocationsBySellerId")
    public List<SellerLocation> getSellerLocationsBySellerId(@QueryParam("sellerId") String sellerId) {
        return service.getSellerLocationsBySellerId(sellerId);
    }

    @POST
    @Path("/saveSellerLocation")
    public List<SellerLocation> saveSellerLocation(SellerLocation location) {
        return service.saveSellerLocation(location);
    }

    @GET
    @Path("/deleteSellerLocation")
    public List<SellerLocation> deleteSellerLocation(@QueryParam("sellerId") String sellerId) {
        return service.deleteSellerLocation(sellerId);
    }

    @GET
    @Path("/getSellerByName")
    public Seller getSellerByName(@QueryParam("sellerName") String sellerName) {
        return service.getSellerByName(sellerName);
    }

    @GET
    @Path("/getSellerForOrganizationIdentifier")
    public Seller getSellerForOrganizationIdentifier(@QueryParam("organizationId") String organizationId) {
        return service.getSellerForOrganizationIdentifier(organizationId);
    }

    @POST
    @Path("/saveNewSeller")
    public Seller saveNewSeller(Seller seller) {
        return service.saveNewSeller(seller);
    }

    @POST
    @Path("/save")
    public Seller save(Seller seller) {
        return service.saveSeller(seller);
    }

    @GET
    @Path("/deleteSeller")
    public Seller deleteSeller(@QueryParam("Id") String sellerId) {
        return service.deleteSeller(sellerId);
    }

    @POST
    @Path("/acceptOrder")
    public void acceptOrder(OrderDTO order){
         service.acceptOrder(order);
    }

    @GET
    @Path("/getInternalSellerList")
    public List<Seller> getInternalSellerList() {
        return service.getInternalSellerList();
    }

    @GET
    @Path("/getPrimeVendorListByBuyerOrganizationId")
    public List<BuyerSellerAccountDTO> getPrimeVendorListByBuyerOrganizationId(@QueryParam("Id") String organizationId) {
        return service.getPrimeVendorListByBuyerOrganizationId(organizationId);
    }

    @POST
    @Path("/updateSellersAndOffers")
    public OfferSellerUpdateResponse updateSellersAndOffers(@QueryParam("changeToSellerName") String changeToSellerName, List<String> sellerNamesToUpdate){
        return service.updateSellersAndOffers(changeToSellerName, sellerNamesToUpdate);
    }

    @GET
    @Path("/getCustomerContractList")
    public List<CustomerContract> getCustomerContractList() {
        return service.getCustomerContractList();
    }

    @GET
    @Path("/getCustomerContractById")
    public CustomerContract getCustomerContractById(@QueryParam("Id") String customerContractId) {
        return service.getCustomerContractById(customerContractId);
    }

    @GET
    @Path("/getCustomerContractListByOrderingCustomerId")
    public List<CustomerContract> getCustomerContractListByOrderingCustomerId(@QueryParam("Id") String orderingCustomerId) {
        return service.getCustomerContractListByOrderingCustomerId(orderingCustomerId);
    }

    @GET
    @Path("/getCustomerContractListByCustomer")
    public List<CustomerContract> getCustomerContractListByCustomer(@QueryParam("CustomerOrganization") String customerOrganization, @QueryParam("OrderingCustomerId") String orderingCustomerId) {
        return service.getCustomerContractListByCustomer(customerOrganization, orderingCustomerId);
    }

    @GET
    @Path("/getBuyerSellerAccountById")
    public BuyerSellerAccount getBuyerSellerAccountById(@QueryParam("Id") String buyerAccountId) {
        return service.getBuyerSellerAccountById(buyerAccountId);
    }

    @GET
    @Path("/getBuyerSellerAccountListBySellerId")
    public List<BuyerSellerAccountDTO> getBuyerSellerAccountListBySellerId(@QueryParam("Id") String sellerId) {
        return service.getBuyerSellerAccountListBySellerId(sellerId);
    }

    @POST
    @Path("/saveBuyerSellerAccount")
    public BuyerSellerAccountDTO saveBuyerSellerAccount(BuyerSellerAccountDTO buyerSellerAccount) {
        return service.saveBuyerSellerAccount(buyerSellerAccount);
    }

    @GET
    @Path("/getCustomerContractListForPrimeVendorSeller")
    public List<CustomerContract> getCustomerContractListForPrimeVendorSeller(@QueryParam("sellerId") String sellerId, @QueryParam("customer") String customer, @QueryParam("orderingCustomer") String orderingCustomer) {
        return service.getCustomerContractListForPrimeVendorSeller(sellerId, orderingCustomer, orderingCustomer);
    }

    @POST
    @Path("/getPrimeVendorCustomerContractByBuyerIdAndSellerId")
    public CustomerContractNumberForPrimeVendorResponse getPrimeVendorCustomerContractByBuyerIdAndSellerId(@QueryParam("buyerId") String buyerId, @QueryParam("sellerId") String sellerId) {
        return service.getPrimeVendorCustomerContractByBuyerIdAndSellerId(buyerId, sellerId);
    }

    @GET
    @Path("/getAndAdvanceNextCallNumberForCustomerContract")
    @Produces(MediaType.TEXT_PLAIN)
    public String getAndAdvanceNextCallNumberForCustomerContract(@QueryParam("contractId") String contractId) {
        return service.getAndAdvanceNextCallNumberForCustomerContract(contractId);
    }

    @GET
    @Path("/getSellerTypes")
    public List<SellerType> getSellerTypes() {
        return service.getSellerTypes();
    }

    @GET
    @Path("/getSellerTypeOrderConfiguration")
    public SellerTypeOrderConfiguration getSellerTypeOrderConfiguration(@QueryParam("type") String type) {
        return service.getSellerTypeOrderConfiguration(type);
    }

    @GET
    @Path("/getCurrentCustomerContract")
    public CustomerContractDTO getCurrentCustomerContract(@QueryParam("custDodaac") String custDodaac, @QueryParam("orderingCustId") String orderingCustId, @QueryParam("sosCd") String sosCd, @QueryParam("contractPriorityCd") String contractPriorityCd) {
        return service.getCurrentCustomerContract(custDodaac, orderingCustId, sosCd, contractPriorityCd);
    }

    @GET
    @Path("/getCallNumber")
    public SellerCallNumber getCallNumber(@QueryParam("sellerId") String sellerId){
        return service.getCallNumber(sellerId);
    }

    @GET
    @Path("/getBuyerSellerAccountBySellerAndBuyerId")
    public BuyerSellerAccount getBuyerSellerAccountBySellerAndBuyerId(@QueryParam("buyerId") String buyerId, @QueryParam("sellerId") String sellerId) {
        return service.getBuyerSellerAccountBySellerAndBuyerId(buyerId, sellerId);
    }

    @GET
    @Path("/getOrganizationSellerAccountNumber")
    public OrganizationSellerAccountNumber getOrganizationSellerAccountNumber(@QueryParam("sellerId") String sellerId) {
        return service.getOrganizationSellerAccountNumber(sellerId);
    }

    @POST
    @Path("/saveOrganizationSellerAccountNumber")
    public OrganizationSellerAccountNumber saveOrganizationSellerAccountNumber(OrganizationSellerAccountNumber organizationSellerAccountNumber) {
        return service.saveOrganizationSellerAccountNumber(organizationSellerAccountNumber);
    }

   @GET
    @Path("/getUserSellerAccountById")
    public UserSellerAccount getUserSellerAccountById (@QueryParam("id") String id) {
        return service.getUserSellerAccountById(id);
    }

    @GET
    @Path("/getUserSellerAccountNumber")
    public UserSellerAccount getUserSellerAccountNumber(@QueryParam("sellerId") String sellerId) {
        return service.getUserSellerAccountNumber(sellerId);
    }

    @POST
    @Path("/saveUserSellerAccount")
    public UserSellerAccount saveUserSellerAccount(UserSellerAccount userSellerAccount) {
        return service.saveUserSellerAccount(userSellerAccount);
    }
}
