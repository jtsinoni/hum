package logicole.gateway.services.system;

import logicole.apis.system.ICustomFieldMicroserviceApi;
import logicole.common.datamodels.general.customfield.CustomField;
import logicole.common.datamodels.general.customfield.ECustomFieldType;
import logicole.common.datamodels.general.customizabletype.CustomizableType;
import logicole.common.datamodels.organization.OrganizationConstants;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.AssetService;
import logicole.gateway.services.realpropertyproject.ProjectService;
import logicole.gateway.services.realpropertyproject.RequirementService;
import logicole.gateway.services.realpropertysection.SectionService;
import logicole.gateway.services.spacemanagement.SpaceManagementService;
import logicole.gateway.services.workorder.WorkOrderService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class CustomFieldService extends BaseGatewayService<ICustomFieldMicroserviceApi> {

    private static final int MAX_CUSTOM_FIELD_RECORDS = 10;
    private static final String ASSET_CUSTOMIZABLE_TYPE_ID = "5fbc1626fa954c348feaf08e";
    private static final String SPACE_CUSTOMIZABLE_TYPE_ID = "5fc6a79b3935a09a13d4c64d";
    private static final String PROJECT_CUSTOMIZABLE_TYPE_ID = "5fcfd9ae9a22284461b12493";
    private static final String SECTION_CUSTOMIZABLE_TYPE_ID = "5fd7b7115d093d9123fd64bb";
    private static final String REQUIREMENT_CUSTOMIZABLE_TYPE_ID = "5fe20011b3f3bf470e0e13f4";
    private static final String WORK_ORDER_CUSTOMIZABLE_TYPE_ID = "5fdb8233005d648e9f0b2a93";

    @Inject
    AssetService assetService;

    @Inject
    ProjectService projectService;

    @Inject
    RequirementService requirementService;

    @Inject
    SectionService sectionService;

    @Inject
    SpaceManagementService spaceManagementService;

    @Inject
    WorkOrderService workOrderService;

    @Inject
    CustomizableTypeService customizableTypeService;

    public CustomFieldService() {
        super("CustomField");
    }

    //TODO: Returning only the display text is probably not appropriate.
    public List<String> getCustomFieldTypes() {
        return ECustomFieldType.getDisplayTextList();
    }

    public List<CustomizableType> getCustomizableTypes() {
        return customizableTypeService.getCustomizableTypes();
    }

    public List<CustomField> getAllCustomFields(@NotNull @QueryParam("customizableTypeId") String customizableTypeId) {
        List<CustomField> customFieldsRetrieved = new ArrayList<>();

        switch (customizableTypeId) {
            case ASSET_CUSTOMIZABLE_TYPE_ID:
                customFieldsRetrieved = assetService.getAllCustomFields(customizableTypeId);
                break;
            case SPACE_CUSTOMIZABLE_TYPE_ID:
                customFieldsRetrieved = spaceManagementService.getAllCustomFields(customizableTypeId);
                break;
            case PROJECT_CUSTOMIZABLE_TYPE_ID:
                customFieldsRetrieved = projectService.getAllCustomFields(customizableTypeId);
                break;
            case SECTION_CUSTOMIZABLE_TYPE_ID:
                customFieldsRetrieved = sectionService.getAllCustomFields(customizableTypeId);
                break;
            case REQUIREMENT_CUSTOMIZABLE_TYPE_ID:
                customFieldsRetrieved = requirementService.getAllCustomFields(customizableTypeId);
                break;
            case WORK_ORDER_CUSTOMIZABLE_TYPE_ID:
                customFieldsRetrieved = workOrderService.getAllCustomFields(customizableTypeId);
                break;
            default:
                logger.error("Cannot retrieve Custom Fields");
                break;
        }

        return customFieldsRetrieved;
    }

    public CustomField addCustomField(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                      @NotNull CustomField customField) {
        customField.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        CustomField newCustomField = null;
        customField.customizableTypeId = customizableTypeId;

        switch (customizableTypeId) {
            case ASSET_CUSTOMIZABLE_TYPE_ID:
                newCustomField = assetService.addCustomField(MAX_CUSTOM_FIELD_RECORDS, customField);
                break;
            case SPACE_CUSTOMIZABLE_TYPE_ID:
                newCustomField = spaceManagementService.addCustomField(MAX_CUSTOM_FIELD_RECORDS, customField);
                break;
            case PROJECT_CUSTOMIZABLE_TYPE_ID:
                newCustomField = projectService.addCustomField(MAX_CUSTOM_FIELD_RECORDS, customField);
                break;
            case SECTION_CUSTOMIZABLE_TYPE_ID:
                newCustomField = sectionService.addCustomField(MAX_CUSTOM_FIELD_RECORDS, customField);
                break;
            case REQUIREMENT_CUSTOMIZABLE_TYPE_ID:
                newCustomField = requirementService.addCustomField(MAX_CUSTOM_FIELD_RECORDS, customField);
                break;
            case WORK_ORDER_CUSTOMIZABLE_TYPE_ID:
                newCustomField = workOrderService.addCustomField(MAX_CUSTOM_FIELD_RECORDS, customField);
                break;
            default:
                logger.error("Cannot add Custom Field");
                break;
        }

        return newCustomField;
    }

    public CustomField updateCustomField(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                         @NotNull CustomField customField) {
        if (!userHasEditScope(customField)) {
            throw new ApplicationException("User does not have Organization scope to update this Custom Field");
        }

        CustomField updatedCustomField = null;

        switch (customizableTypeId) {
            case ASSET_CUSTOMIZABLE_TYPE_ID:
                updatedCustomField = assetService.updateCustomField(customField);
                break;
            case SPACE_CUSTOMIZABLE_TYPE_ID:
                updatedCustomField = spaceManagementService.updateCustomField(customField);
                break;
            case PROJECT_CUSTOMIZABLE_TYPE_ID:
                updatedCustomField = projectService.updateCustomField(customField);
                break;
            case SECTION_CUSTOMIZABLE_TYPE_ID:
                updatedCustomField = sectionService.updateCustomField(customField);
                break;
            case REQUIREMENT_CUSTOMIZABLE_TYPE_ID:
                updatedCustomField = requirementService.updateCustomField(customField);
                break;
            case WORK_ORDER_CUSTOMIZABLE_TYPE_ID:
                updatedCustomField = workOrderService.updateCustomField(customField);
                break;
            default:
                logger.error("Cannot update Custom Field");
                break;
        }

        return updatedCustomField;
    }

    public void deleteCustomField(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                  @NotNull CustomField customField) {
        if (!userHasEditScope(customField)) {
            throw new ApplicationException("User does not have Organization scope to delete this Custom Field");
        }

        switch (customizableTypeId) {
            case ASSET_CUSTOMIZABLE_TYPE_ID:
                assetService.deleteCustomField(customField);
                break;
            case SPACE_CUSTOMIZABLE_TYPE_ID:
                spaceManagementService.deleteCustomField(customField);
                break;
            case PROJECT_CUSTOMIZABLE_TYPE_ID:
                projectService.deleteCustomField(customField);
                break;
            case SECTION_CUSTOMIZABLE_TYPE_ID:
                sectionService.deleteCustomField(customField);
                break;
            case REQUIREMENT_CUSTOMIZABLE_TYPE_ID:
                requirementService.deleteCustomField(customField);
                break;
            case WORK_ORDER_CUSTOMIZABLE_TYPE_ID:
                workOrderService.deleteCustomField(customField);
                break;
            default:
                logger.error("Cannot delete Custom Field");
                break;
        }
    }

    public boolean checkIfCustomFieldValuesExist(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                                 @NotNull @QueryParam("customFieldId") String customFieldId) {
        boolean customValueFieldsExist = false;

        switch (customizableTypeId) {
            case ASSET_CUSTOMIZABLE_TYPE_ID:
                customValueFieldsExist = assetService.checkIfCustomFieldValuesExist(customFieldId);
                break;
            case SPACE_CUSTOMIZABLE_TYPE_ID:
                customValueFieldsExist = spaceManagementService.checkIfCustomFieldValuesExist(customFieldId);
                break;
            case PROJECT_CUSTOMIZABLE_TYPE_ID:
                customValueFieldsExist = projectService.checkIfCustomFieldValuesExist(customFieldId);
                break;
            case SECTION_CUSTOMIZABLE_TYPE_ID:
                customValueFieldsExist = sectionService.checkIfCustomFieldValuesExist(customFieldId);
                break;
            case REQUIREMENT_CUSTOMIZABLE_TYPE_ID:
                customValueFieldsExist = requirementService.checkIfCustomFieldValuesExist(customFieldId);
                break;
            case WORK_ORDER_CUSTOMIZABLE_TYPE_ID:
                customValueFieldsExist = workOrderService.checkIfCustomFieldValuesExist(customFieldId);
                break;
            default:
                logger.error("Cannot check if Custom Field values exist");
                break;
        }

        return customValueFieldsExist;
    }

    public boolean checkDuplicateLabel(@NotNull @QueryParam("customizableTypeId") String customizableTypeId,
                                       @NotNull @QueryParam("label") String label) {
        boolean labelAlreadyExists = false;

        switch (customizableTypeId) {
            case ASSET_CUSTOMIZABLE_TYPE_ID:
                labelAlreadyExists = assetService.checkDuplicateLabel(customizableTypeId, label);
                break;
            case SPACE_CUSTOMIZABLE_TYPE_ID:
                labelAlreadyExists = spaceManagementService.checkDuplicateLabel(customizableTypeId, label);
                break;
            case PROJECT_CUSTOMIZABLE_TYPE_ID:
                labelAlreadyExists = projectService.checkDuplicateLabel(customizableTypeId, label);
                break;
            case SECTION_CUSTOMIZABLE_TYPE_ID:
                labelAlreadyExists = sectionService.checkDuplicateLabel(customizableTypeId, label);
                break;
            case REQUIREMENT_CUSTOMIZABLE_TYPE_ID:
                labelAlreadyExists = requirementService.checkDuplicateLabel(customizableTypeId, label);
                break;
            case WORK_ORDER_CUSTOMIZABLE_TYPE_ID:
                labelAlreadyExists = workOrderService.checkDuplicateLabel(customizableTypeId, label);
                break;
            default:
                logger.error("Cannot check if duplicate label exists");
                break;
        }

        return labelAlreadyExists;
    }

    private boolean userHasEditScope(CustomField customField) {
        boolean hasEditScope = false;
        if (currentUserBT.getCurrentUser().profile.currentNodeRef.getId().equals(OrganizationConstants.DEV_ORG_ID)
                || (!StringUtil.isEmptyOrNull(customField.managedByNodeRef.ancestry) && customField.managedByNodeRef.ancestry.contains(currentUserBT.getCurrentUser().profile.currentNodeRef.getId()))) {
            hasEditScope = true;
        }
        return hasEditScope;
    }

}
