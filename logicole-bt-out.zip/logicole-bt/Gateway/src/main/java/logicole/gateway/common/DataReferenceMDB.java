package logicole.gateway.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import logicole.common.crossservice.mdb.BaseMDB;
import logicole.common.crossservice.sync.SyncManager;
import logicole.common.datamodels.ref.DataReferenceUpdate;
import logicole.common.general.constants.JmsConstants;
import logicole.common.general.event.BusinessEvent;
import logicole.common.general.jms.JmsClient;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;
import java.io.IOException;

public abstract class DataReferenceMDB<T extends BaseGatewayService> extends BaseMDB {

    protected SyncManager syncManager = new SyncManager();
    private String className;

    protected T gatewayService;

    public DataReferenceMDB() {
        this.className = this.getClass().getSimpleName();
    }

    @Override
    protected void processMessage(Message message) {
        String jmsType = determineJmsType(message);

        if (JmsConstants.JMS_TYPE_DATA_REF_UPDATE.equals(jmsType)) {
            processDataReferenceUpdateMessage(message);
        } else if (JmsConstants.JMS_TYPE_BUSINESS_EVENT.equals(jmsType)) {
            processBusinessEventMessage(message);
        } else {
            logger.error("DataReferenceMDB: {} was unable to process message. Unknown or unexpected JMSType {}.", className, jmsType);
        }
    }

    private void processDataReferenceUpdateMessage(Message message) {
        DataReferenceUpdate dataReferenceUpdate = getDataReferenceUpdate(message);

        if (dataReferenceUpdate != null) {
            logger.debug("DataReferenceMDB: Processing DataReferenceUpdate message in {} for {}", className, dataReferenceUpdate.getRefObjectName());
            if (gatewayService != null) {
                gatewayService.processDataReferenceUpdate(dataReferenceUpdate);
            }
            processUsingSyncProcessor(dataReferenceUpdate);
        } else {
            logger.warn("DataReferenceMDB: DataReferenceMDB: Unable to process message for {}, could not build DataReferenceUpdate. Message: {}.",className, message);
        }
    }

    private DataReferenceUpdate getDataReferenceUpdate(Message message) {
        DataReferenceUpdate dataReferenceUpdate = null;

        try {
            if (message instanceof TextMessage) {
                TextMessage textMessage = (TextMessage) message;
                String messageText = textMessage.getText();
                ObjectMapper mapper = new ObjectMapper();

                try {
                    dataReferenceUpdate = mapper.readValue(messageText, DataReferenceUpdate.class);
                } catch (IOException e) {
                    logger.warn("DataReferenceMDB: {}, IOException in onMessage() for TextMessage: {}, ABORTING.",
                            className, e.getMessage());
                }

            } else if (message instanceof ObjectMessage) {
                ObjectMessage objMessage = (ObjectMessage) message;
                Object obj = objMessage.getObject();

                if (obj instanceof DataReferenceUpdate) {
                    dataReferenceUpdate = (DataReferenceUpdate) obj;
                }
            } else {
                logger.warn("DataReferenceMDB: {}, onMessage() called with unsupported message: {}, ABORTING.",
                        className, message);
            }
        } catch (JMSException e) {
            logger.error("DataReferenceMDB: {}, JMSException in onMessage(): {}, ABORTING.", className, e.getMessage());
        }
        return dataReferenceUpdate;
    }

    private void processUsingSyncProcessor(DataReferenceUpdate dataReferenceUpdate) {
        try {
            syncManager.process(dataReferenceUpdate);
        } catch (IOException e) {
            logger.warn("DataReferenceMDB: {}, IOException processing JMS message: {}", className, e.getMessage());
        }
    }

    private void processBusinessEventMessage(Message message) {
        BusinessEvent businessEvent = getBusinessEvent(message);

        try {
            processBusinessEvent(businessEvent, message.getJMSReplyTo());
        }catch(JMSException e){
            throw new RuntimeException(String.format("Error processing business event %s", businessEvent.toString()), e);
        }
    }

    private BusinessEvent getBusinessEvent(Message message){
        BusinessEvent businessEvent;

        if (message instanceof TextMessage) {
            TextMessage textMessage = (TextMessage) message;

            String messageText;
            try {
                messageText = textMessage.getText();
            } catch (JMSException e) {
                throw new RuntimeException("Error processing business event for a text message", e);
            }

            businessEvent = new BusinessEvent(JmsClient.BUSINESS_EVENT, messageText);
        } else if (message instanceof ObjectMessage) {
            ObjectMessage objMessage = (ObjectMessage) message;
            Object obj;
            try {
                obj = objMessage.getObject();
            } catch (JMSException e) {
                throw new RuntimeException(e);
            }
            businessEvent = (BusinessEvent) obj;
        } else {
            throw new RuntimeException("BusinessEvent message in JMS queue was not of type TextMessage or ObjectMessage");
        }
        return businessEvent;
    }

    // Override this method in subclasses
    protected void processBusinessEvent(BusinessEvent businessEvent, Destination jmsReplyTo) {

    }
}
