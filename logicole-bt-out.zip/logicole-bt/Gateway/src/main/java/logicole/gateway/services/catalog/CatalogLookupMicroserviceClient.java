package logicole.gateway.services.catalog;

import logicole.apis.catalog.ICatalogLookupMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class CatalogLookupMicroserviceClient extends MicroserviceClient<ICatalogLookupMicroserviceApi> {
    public CatalogLookupMicroserviceClient() {
        super(ICatalogLookupMicroserviceApi.class, "logicole-catalog");
    }

    @Produces
    public ICatalogLookupMicroserviceApi getICatalogLookupMicroserviceApi(){
        return createClient();
    }
}
