package logicole.gateway.services.spacemanagement;

import logicole.apis.space.IDrawingMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class DrawingMicroserviceClient extends MicroserviceClient<IDrawingMicroserviceApi> {
    public DrawingMicroserviceClient(){
        super(IDrawingMicroserviceApi.class, "logicole-space-management");
    }

    @Produces
    public IDrawingMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
