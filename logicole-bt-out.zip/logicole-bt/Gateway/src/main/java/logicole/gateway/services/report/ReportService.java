package logicole.gateway.services.report;

import logicole.apis.report.IReportMicroserviceApi;
import logicole.common.datamodels.report.ExportFileInfo;
import logicole.common.datamodels.report.ReportContainer;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import java.util.Map;

@ApplicationScoped
public class ReportService extends BaseGatewayService<IReportMicroserviceApi> {

    public ReportService() {
        super("Report");
    }

    public Boolean test(){
        return true;
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public ExportFileInfo generateReport(ReportContainer reportContainer) {
        return microservice.generate(reportContainer);
    }
}
