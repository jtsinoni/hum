package logicole.gateway.services.abi;

import logicole.apis.abi.IEnterpriseCatalogLookupMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class EnterpriseCatalogLookupMicroserviceClient extends MicroserviceClient<IEnterpriseCatalogLookupMicroserviceApi> {
    public EnterpriseCatalogLookupMicroserviceClient() {
        super(IEnterpriseCatalogLookupMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IEnterpriseCatalogLookupMicroserviceApi getEnterpriseICatalogLookupMicroserviceApi(){
        return createClient();
    }
}
