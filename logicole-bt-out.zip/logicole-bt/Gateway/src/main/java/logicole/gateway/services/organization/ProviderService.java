package logicole.gateway.services.organization;

import logicole.apis.organization.IProviderMicroserviceApi;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.Provider;
import logicole.common.datamodels.organization.ProviderRef;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.CdiUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@ApplicationScoped
public class ProviderService extends BaseGatewayService<IProviderMicroserviceApi> {

    @Inject
    OrganizationService organizationService;
    @Inject
    private CdiUtil cdiUtil;

    public ProviderService() {
        super("Provider");
    }

    public <T> T getProviderData(String startNode, String providerType) {
        ProviderRef providerRef = organizationService.getProvider(startNode, providerType);
        T retVal = null;
        if (providerRef != null) {
            Provider provider = findProviderById(providerRef.id);
            List<String> parameters;
            if (provider.addContainerIdAsParameter) {
                parameters = providerRef.referenceParameters;
            } else {
                parameters = provider.parameters;
            }
            IOrgProvider orgProvider = cdiUtil.getNamedClass(provider.type, IOrgProvider.class);
            retVal = (T) orgProvider.provide(parameters);
        }
        return retVal;
    }

    public Provider findProviderById(String id) {
        return microservice.findProviderById(id);
    }

    public List<Provider> getAllProviders() {
        return microservice.getAllProviders();
    }

    public List<Provider> getFinancialServiceProviders() {
        return microservice.getFinancialServiceProviders();
    }

    public Provider saveProvider(Provider provider) {
        String errorProviderNameRequired = "Providers must have a name.";
        String errorProviderTypeRequired = "Providers must have a type.";

        if (StringUtil.isEmptyOrNull(provider.name)) {
            throw new ApplicationException(errorProviderNameRequired);
        }
        if (StringUtil.isEmptyOrNull(provider.type)) {
            throw new ApplicationException(errorProviderTypeRequired);
        }

        return microservice.saveProvider(provider);
    }

     public void deleteProvider(String providerId) {
        String errorProviderAttachedToConsumer = "Provider is associated with a consumer, remove the consumer reference then the provider";
        boolean consumerHasProvider = organizationService.consumerHasProviderRef(providerId);
        if (consumerHasProvider) {
            throw new ApplicationException(errorProviderAttachedToConsumer);
        } else {
            microservice.deleteProvider(providerId);
        }
     }

     public List<ProviderType> getProviderTypes() {
        return EProviderType.getDisplayTextList();
    }

    public List<ProviderRef> getProviderRefsByType(String providerType) {
        return microservice.getProviderRefsByType(providerType);
    }


    public OrganizationRef getResponsibleOrganizationRef(String startOrgId, String providerType) {
        return this.getProviderData(startOrgId, providerType);
    }
}
