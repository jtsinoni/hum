package logicole.gateway.services.catalog;

import logicole.apis.catalog.ICatalogChangeHistoryMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class CatalogChangeHistoryMicroserviceClient extends MicroserviceClient<ICatalogChangeHistoryMicroserviceApi> {
    public CatalogChangeHistoryMicroserviceClient() {
        super(ICatalogChangeHistoryMicroserviceApi.class, "logicole-catalog");
    }

    @Produces
    public ICatalogChangeHistoryMicroserviceApi getICatalogChangeHistoryMicroserviceApi(){
        return createClient();
    }
}
