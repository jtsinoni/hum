package logicole.gateway.services.spacemanagement;

import logicole.apis.space.ISpaceMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class SpaceManagementMicroserviceClient extends MicroserviceClient<ISpaceMicroserviceApi> {
    public SpaceManagementMicroserviceClient(){
        super(ISpaceMicroserviceApi.class, "logicole-space-management");
    }

    @Produces
    public ISpaceMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
