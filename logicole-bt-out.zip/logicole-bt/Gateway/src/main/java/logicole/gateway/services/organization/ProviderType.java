package logicole.gateway.services.organization;

public class ProviderType {
    public String displayText;
    public String value;

    public ProviderType(String displayText, String value) {
        this.displayText = displayText;
        this.value = value;
    }
}
