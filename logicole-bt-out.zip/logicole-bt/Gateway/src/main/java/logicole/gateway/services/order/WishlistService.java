package logicole.gateway.services.order;

import logicole.apis.order.IWishlistMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.order.order.Wishlist;
import logicole.common.datamodels.order.order.WishlistItem;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.QueryParam;

@ApplicationScoped
public class WishlistService extends BaseGatewayService<IWishlistMicroserviceApi> {
    public static final String CUSTOMER_NOT_FOUND_EXCEPTION = "No Customer is associated to this profile";

    @Inject
    private CurrentUserBT currentUserBT;

    @Inject
    private BuyerService buyerService;

    public WishlistService() {
        super("Wishlist");
    }

    public void addWishlist (Wishlist wishlist) {
        microservice.addWishlist(wishlist);
    }

    public Wishlist addItemToWishlist(@QueryParam("listId") String listId,
                                      WishlistItem wishlistItem) {
        return microservice.addItemToWishlist(listId, wishlistItem);

    }

    public Wishlist getWishlistByName(@QueryParam("name") String name,
                                      @QueryParam("buyerIdentifier") String buyerIdentifier,
                                      @QueryParam("userIdentifier") String userIdentifier) {
        return microservice.getWishlistByName(name, buyerIdentifier, userIdentifier);
    }

    public List<Wishlist> getWishlistByBuyer(@QueryParam("buyerIdentifier") String buyerIdentifier) {
        return microservice.getWishlistByBuyer(buyerIdentifier);
    }

    public List<Wishlist> getWishLists() {
        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if(Objects.isNull(buyer)){
            return new ArrayList<>();
        }
        return microservice.getWishLists(currentUserBT.getCurrentUser().profile.getId(), buyer.getId());
    }

    public Wishlist moveItemToWishlist(@QueryParam("listId") String listId,
                                       @QueryParam("newListId") String newListId,
                                       @QueryParam("customerItemSourcingId") String customerItemSourcingId) {
        return microservice.moveItemToWishlist(listId, newListId, customerItemSourcingId);
    }

    public Wishlist removeItemFromWishlist(@QueryParam("listId") String listId,
                                           @QueryParam("customerItemSourcingId") String customerItemSourcingId) {
        return microservice.removeItemFromWishlist(listId, customerItemSourcingId);
    }

    public Wishlist saveWishlist (Wishlist wishlist) {
        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if(Objects.isNull(buyer)){
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }
        wishlist.buyerIdentifier = buyer.getId();
        return microservice.saveWishlist(wishlist);
    }

}
