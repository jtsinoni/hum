package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceReferenceDataMicroserviceApi;
import logicole.common.datamodels.finance.ECommodityCodeUsageType;
import logicole.common.datamodels.finance.RefDataList;
import logicole.common.datamodels.finance.referencedata.AccountingClassificationRef;
import logicole.common.datamodels.finance.referencedata.CommodityCode;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.referencedata.CostCenterRef;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.organization.EProviderType;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.organization.ProviderService;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.LinkedHashMap;
import java.util.List;

@ApplicationScoped
public class FinanceReferenceDataService extends BaseGatewayService<IFinanceReferenceDataMicroserviceApi> {

    @Inject
    ProviderService providerService;
    @Inject
    OrganizationService organizationService;

    private static final String LOGICOLE_ORG_ID = "58d0581bdf121dce611b7170";

    protected FinanceReferenceDataService() {
        super("Finance Reference Data Service");
    }

    @PostConstruct
    public void postConstruct() {
        OrganizationRef defaultManagedByOrgRef = organizationService.getOrganizationRefById(LOGICOLE_ORG_ID);
        microservice.setDefaultManagedByOrgRef(defaultManagedByOrgRef);
    }

    public RefDataList getRefDataListByCollectionName(String name) {
        return microservice.getRefDataListByCollectionName(name);
    }

    public List<RefDataList> getRefDataListByModule(String module) {
        return microservice.getRefDataListByModule(module);
    }

    public List<Object> getRefDataDetail(String collectionName, String fundingSourceSubType) {
        return microservice.getRefDataDetail(collectionName, fundingSourceSubType);
    }

    public Object createReferenceData(String collectionName, Object newReferenceData) {
        return microservice.createReferenceData(collectionName, newReferenceData);
    }

    public Object updateReferenceData(String collectionName, Object referenceData) {
        String id = (String)((LinkedHashMap)referenceData).get("id");
        Object foundReferenceData = microservice.getReferenceDataItemById(id, collectionName);
        if (foundReferenceData == null) {
            throw new ApplicationException(collectionName + " does not exist");
        } else {
            return microservice.updateReferenceData(collectionName, referenceData);
        }
    }

    public boolean deleteReferenceData(String collectionName, String id) {
        Object foundReferenceData = microservice.getReferenceDataItemById(id, collectionName);
        if (foundReferenceData == null) {
            throw new ApplicationException(collectionName + " does not exist");
        } else {
            return microservice.deleteReferenceData(collectionName, id);
        }
    }

    public List<CommodityCode> getCommodityCodesByName(String financialSystemId, String commodityClassName) {
        return microservice.getCommodityCodesByName(financialSystemId, commodityClassName);
    }

    public List<CommodityCode> getFullCommodityCodesByUsage(ECommodityCodeUsageType commodityUsageType) {
        FinancialSystem financialSystem = providerService.getProviderData(currentUserBT.getCurrentNodeId(), EProviderType.FINANCE_SYSTEM_CONFIG_PROVIDER.value);
        return microservice.getFullCommodityCodesBySystemAndUsage(financialSystem.getId(), commodityUsageType);
    }

    public List<CommodityCodeRef> getCommodityCodesByUsage(ECommodityCodeUsageType commodityUsageType) {
        FinancialSystem financialSystem = providerService.getProviderData(currentUserBT.getCurrentNodeId(), EProviderType.FINANCE_SYSTEM_CONFIG_PROVIDER.value);
        return microservice.getCommodityCodesBySystemAndUsage(financialSystem.getId(), commodityUsageType);
    }

    public List<CommodityCodeRef> getCommodityCodesBySystemAndUsage(String financialSystemId, ECommodityCodeUsageType commodityUsageType) {
        return microservice.getCommodityCodesBySystemAndUsage(financialSystemId, commodityUsageType);
    }

    public CommodityCodeRef getCommodityCodeById(String commodityCodeId) {
        return microservice.getCommodityCodeById(commodityCodeId);
    }

    public List<CostCenterRef> getCostCentersFromTemplate(String financialSystemId, String fundIdentification, String fiscalYear, String acctClassCode) {
        return microservice.getCostCentersFromTemplate(financialSystemId,  fundIdentification, fiscalYear, acctClassCode);
    }

    public List<AccountingClassificationRef> getAccountingClassificationsFromTemplate(String financialSystemId, String fundIdentificationCode, String fiscalYear) {
        return microservice.getAccountingClassificationsFromTemplate(financialSystemId, fundIdentificationCode, fiscalYear);
    }
}
