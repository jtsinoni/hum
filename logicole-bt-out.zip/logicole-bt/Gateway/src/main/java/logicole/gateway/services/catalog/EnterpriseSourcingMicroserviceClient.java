package logicole.gateway.services.catalog;

import logicole.apis.catalog.IEnterpriseSourcingMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class EnterpriseSourcingMicroserviceClient extends MicroserviceClient<IEnterpriseSourcingMicroserviceApi> {
    public EnterpriseSourcingMicroserviceClient(){
        super(IEnterpriseSourcingMicroserviceApi.class, "logicole-catalog");
    }

    @Produces
    public IEnterpriseSourcingMicroserviceApi getIEnterpriseSourcingMicroserviceApi() {
        return createClient();
    }

}
