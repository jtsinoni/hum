package logicole.gateway.services.organization;

import logicole.apis.organization.IProviderMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class ProviderMicroserviceClient extends MicroserviceClient<IProviderMicroserviceApi> {
    public ProviderMicroserviceClient() {
        super(IProviderMicroserviceApi.class, "logicole-organization");
    }

    @Produces
    public IProviderMicroserviceApi getIProviderMicroserviceApi() {
        return createClient();
    }
}
