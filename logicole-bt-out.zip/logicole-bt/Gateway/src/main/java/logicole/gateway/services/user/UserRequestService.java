package logicole.gateway.services.user;

import logicole.apis.user.IUserRequestMicroserviceApi;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.notification.EmailMessage;
import logicole.common.datamodels.organization.*;
import logicole.common.datamodels.user.*;
import logicole.common.datamodels.userRequest.UserRequestInfo;
import logicole.common.datamodels.userRequest.*;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.DateUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.system.NotificationService;
import logicole.gateway.services.system.SystemFeatureFlagService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@ApplicationScoped
public class UserRequestService extends BaseGatewayService<IUserRequestMicroserviceApi> {

    @Inject
    FileManagerAdminService fileManagerAdminService;

    @Inject
    NotificationService notificationService;

    @Inject
    OrganizationService organizationService;

    @Inject
    SystemFeatureFlagService systemFeatureFlagService;

    @Inject
    UserService userService;

    @Inject
    private DateUtil dateUtil;

    private Integer maxUploadSize;

    public UserRequestService() {
        super("UserRequest");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public UserRequest getUserRequestById(String userRequestId) {
        return microservice.getUserRequestById(userRequestId);
    }

    public UserRequestDTO getUserRequestDetailsById(String userRequestId) {
        return microservice.getUserRequestDetailsById(userRequestId);
    }

    public UserRequestDTO getUserRequestDetailsByIdForCandidate(String userRequestId) {
        return microservice.getUserRequestDetailsByIdForCandidate(userRequestId);
    }

    public UserRequestDTO setUserRequestPkiDn(String userRequestId) {
        return microservice.setUserRequestPkiDn(userRequestId);
    }

    public UserRequest saveUserRequest(UserRequest userRequest){
        return microservice.saveUserRequest(userRequest);
    }

    public UserRequest saveNewUserRequest(String userRequestId, UserRequest userRequest) {
        userRequest.managedByNodeRef = organizationService.getOrganizationRefById((getCurrentUser().profile.currentNodeRef.id));
        return microservice.saveNewUserRequest(userRequestId, userRequest);
    }

    public List<UserRequest> getAllUserRequests(String state) throws IllegalAccessException {
        List<String> scopeOrgIds = getCurrentUserScopedOrgIds();
        return microservice.getAllUserRequests(state, scopeOrgIds);
    }

    public UserRequestInfo getUserRequestDashboardStats() {
        List<String> scopeOrgIds = getCurrentUserScopedOrgIds();
        return microservice.getUserRequestDashboardStats(scopeOrgIds);
    }

    private List<String> getCurrentUserScopedOrgIds() {
        List<OrganizationRef> currUserScopeNodeRefs = getCurrentUser().profile.scopeNodeRefs;
        OrganizationTypeRef currUserNodeTypeRef = getCurrentUser().profile.nodeTypeRef;

        ScopeQuery scopeQuery = new ScopeQuery();
        scopeQuery.nodeTypeId = currUserNodeTypeRef.getId();
        scopeQuery.scopeList = new ArrayList<>();

        for (OrganizationRef scopeNodeRef : currUserScopeNodeRefs) {
            scopeQuery.scopeList.add(scopeNodeRef.getId());
        }

        List<Organization> currUserScopedOrgs = organizationService.getOrganizationsInScope(scopeQuery);

        List<String> scopeOrgIds = new ArrayList<>();
        for (Organization scopeNodeRef : currUserScopedOrgs) {
            scopeOrgIds.add(scopeNodeRef.getId());
        }

        return scopeOrgIds;
    }

    public String generateUserRequestId(){
        return microservice.generateUserRequestId();
    }

    public UserRequest saveUserRequestIdentification(String userRequestId, UserRequest userRequest) {
        return microservice.saveUserRequestIdentification(userRequestId, userRequest);
    }

    public UserRequestDTO saveUserRequestIdentificationForCandidate(String userRequestId, UserRequest userRequest) {
        return microservice.saveUserRequestIdentificationForCandidate(userRequestId, userRequest);
    }

    public List<ParticipantDetailsDTO> getParticipantsForUserRequest(String userRequestId) {
        return microservice.getParticipantsForUserRequest(userRequestId);
    }

    public Boolean sendUserRequestEmail(String userRequestId, UserRequest.EState fromState, UserRequest.EState toState) {
        UserRequest userRequest = getUserRequestById(userRequestId);

        if (!dateUtil.isDateInPast(userRequest.expirationDate)) {
            UserRequestEmailWrapper userRequestEmailWrapper = new UserRequestEmailWrapper();
            userRequestEmailWrapper.userRequestEmailType = EUserRequestEmailType.getEmailTypeFromTransition(fromState, toState);
            userRequestEmailWrapper.userRequestId = userRequestId;
            String name = userRequest.firstName + " " + userRequest.lastName;
            EmailMessage emailMessage = microservice.buildUserRequestEmail(name, userRequest.email, userRequestEmailWrapper);
            notificationService.sendEmail(emailMessage);
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }

    public UserRequest saveUserRequestExpirationDate(String userRequestId, @NotNull Date expirationDate) {
        return microservice.saveUserRequestExpirationDate(userRequestId, expirationDate);
    }

    public UserRequest assignPrimaryAccessManager(String userRequestId) {
        return microservice.assignPrimaryAccessManager(userRequestId);
    }

    public UserRequest unassignPrimaryAccessManager(String userRequestId) {
        return microservice.unassignPrimaryAccessManager(userRequestId);
    }

    public UserRequest cancelUserRequest(String userRequestId, @NotNull String reason) {
        UserRequest userRequest = getUserRequestById(userRequestId);
        UserRequest.EState fromState = userRequest.state;

        UserRequest userRequestUpdate = microservice.cancelUserRequest(userRequestId, reason);

        if (!UserRequest.EState.PRESUBMITTAL.equals(userRequest.state)
                && !UserRequest.EState.SENT_TO_SUPERVISOR_FOR_REWORK.equals(userRequest.state)
                && !UserRequest.EState.WITHDRAWN_FROM_ACCESS_MANAGER.equals(userRequest.state)
                && !UserRequest.EState.SENT_TO_ACCESS_MANAGER_FOR_REVIEW.equals(userRequest.state)) {
            sendUserRequestEmail(userRequestId, fromState, UserRequest.EState.CANCELLED);
        }

        return userRequestUpdate;
    }

    public UserRequestDTO declineUserRequestByCandidate(String userRequestId, String reason) {
        return microservice.declineUserRequestByCandidate(userRequestId, reason);
    }

    public UserRequest saveUserRequestAccess(String userRequestId, UserRequest userRequest) {
        updateUserRequestNodeRefs(userRequest);
        boolean isUserRequestFeatureFlagActive = systemFeatureFlagService.checkIfUserRequestFeatureFlagIsActive();
        return microservice.saveUserRequestAccess(isUserRequestFeatureFlagActive, userRequestId, userRequest);
    }

    private void updateUserRequestNodeRefs(UserRequest userRequest) {
        List<OrganizationRef> results = new ArrayList<>();
        for(OrganizationRef nodeRef : userRequest.scopeNodeRefs){
            results.add(organizationService.getOrganizationRefById((nodeRef.id)));
        }
        userRequest.scopeNodeRefs = results;
    }

    public UserRequest saveUserRequestRoles(String userRequestId, UserRequest userRequest) {
        boolean isUserRequestFeatureFlagActive = systemFeatureFlagService.checkIfUserRequestFeatureFlagIsActive();
        return microservice.saveUserRequestRoles(isUserRequestFeatureFlagActive, userRequestId, userRequest);
    }

    public UserRequest saveUserRequestAssignableRoles(String userRequestId, UserRequest userRequest) {
        return microservice.saveUserRequestAssignableRoles(userRequestId, userRequest);
    }

    public UserRequirement saveUserRequestRequirementAttachment(String userRequestId, UserRequirement requirement) {
        UserRequest userRequest = getUserRequestById(userRequestId);
        boolean isNewRequirement = false;
        if (requirement.getId() == null) {
            isNewRequirement = true;
        }
        UserRequirement updatedRequirement = microservice.saveUserRequestRequirementAttachment(userRequestId, requirement);

        if ((UserRequest.EState.SENT_TO_CANDIDATE_FOR_COMPLETION.equals(userRequest.state)
                || UserRequest.EState.REQUIREMENT_VERIFICATION.equals(userRequest.state))
                && updatedRequirement.supplyingParty.participantType.equals(UserRequest.EParticipantType.CANDIDATE)) {
            if (isNewRequirement) {
                // Send email to candidate when a new requirement is added if it is with candidate
                sendUserRequirementEmail(userRequestId, updatedRequirement, EUserRequestEmailType.USER_REQUEST_REQUIREMENT_ADDED);
            } else {
                // Send email to candidate when a requirement is saved if it is with candidate
                sendUserRequirementEmail(userRequestId, updatedRequirement, EUserRequestEmailType.USER_REQUEST_REQUIREMENT_UPDATED);
            }
        }

        return updatedRequirement;
    }

    public UserRequirement saveUserRequestRequirementAttachmentForCandidate(String userRequestId, UserRequirement requirement) {
        return microservice.saveUserRequestRequirementAttachmentForCandidate(userRequestId, requirement);
    }

    public UserRequirement removeUserRequestRequirementAttachment(String userRequestId, String requirementId, String fileId) throws IOException {
        try {
            fileManagerAdminService.removeFile(fileId);
        } catch (FatalProcessingException | ApplicationException e) {
            throw new ApplicationException("Was not able to remove the file");
        }
        return microservice.removeUserRequestRequirementAttachment(userRequestId, requirementId, fileId);
    }

    public UserRequirement removeUserRequestRequirementAttachmentForCandidate(String userRequestId, String requirementId, String fileId) throws IOException {
        try {
            fileManagerAdminService.removeFile(fileId);
        } catch (FatalProcessingException | ApplicationException e) {
            throw new ApplicationException("Was not able to remove the file");
        }
        return microservice.removeUserRequestRequirementAttachmentForCandidate(userRequestId, requirementId, fileId);
    }

    public UserRequest sendToAccessManagerForReview(String userRequestId) {
        return microservice.sendToAccessManagerForReview(userRequestId);
    }

    public UserRequest sendToSupervisorForRework(String userRequestId) {
        return microservice.sendToSupervisorForRework(userRequestId);
    }

    public UserRequest withdrawFromAccessManagerForSupervisorRework(String userRequestId) {
        return microservice.withdrawFromAccessManagerForSupervisorRework(userRequestId);
    }

    public UserRequest sendToCandidateForCompletion(String userRequestId) {
        UserRequest userRequest = getUserRequestById(userRequestId);
        UserRequest.EState fromState = userRequest.state;

        UserRequest userRequestUpdate = microservice.sendToCandidateForCompletion(userRequestId);

        sendUserRequestEmail(userRequestId, fromState, UserRequest.EState.SENT_TO_CANDIDATE_FOR_COMPLETION);

        return userRequestUpdate;
    }

    public UserRequest withdrawFromCandidate(String userRequestId) {
        UserRequest userRequest = getUserRequestById(userRequestId);
        UserRequest.EState fromState = userRequest.state;

        UserRequest userRequestUpdate = microservice.withdrawFromCandidate(userRequestId);

        if (fromState.equals(UserRequest.EState.SENT_TO_CANDIDATE_FOR_COMPLETION)) {
            sendUserRequestEmail(userRequestId, fromState, UserRequest.EState.WITHDRAWN_FROM_CANDIDATE);
        }

        return userRequestUpdate;
    }

    public UserRequestDTO sendToAccessManagerForRequirementVerification(String userRequestId) {
        return microservice.sendToAccessManagerForRequirementVerification(userRequestId);
    }

    public UserRequest rejectByAccessManager(String userRequestId, @NotNull String reason) {
        UserRequest userRequest = getUserRequestById(userRequestId);
        UserRequest.EState fromState = userRequest.state;

        UserRequest userRequestUpdate = microservice.rejectByAccessManager(userRequestId, reason);

        if (!UserRequest.EState.PRESUBMITTAL.equals(userRequest.state)
                && !UserRequest.EState.SENT_TO_SUPERVISOR_FOR_REWORK.equals(userRequest.state)
                && !UserRequest.EState.WITHDRAWN_FROM_ACCESS_MANAGER.equals(userRequest.state)
                && !UserRequest.EState.SENT_TO_ACCESS_MANAGER_FOR_REVIEW.equals(userRequest.state)) {
            sendUserRequestEmail(userRequestId, fromState, UserRequest.EState.ACCESS_MANAGER_REJECTED);
        }

        return userRequestUpdate;
    }

    public UserRequest approveByAccessManager(String userRequestId) {
        return microservice.approveByAccessManager(userRequestId);
    }

    public UserRequest sendBackToRequirementVerification(String userRequestId) {
        return microservice.sendBackToRequirementVerification(userRequestId);
    }

    public UserRequest activateBySupervisor(String userRequestId) {
        UserRequest userRequest = getUserRequestById(userRequestId);
        UserRequest.EState fromState = userRequest.state;
        ScopeQuery scopeQuery = new ScopeQuery();
        scopeQuery.nodeTypeId = userRequest.nodeTypeRef.getId();
        scopeQuery.scopeList = new ArrayList<>();
        for (OrganizationRef scopeNodeRef : userRequest.scopeNodeRefs) {
            scopeQuery.scopeList.add(scopeNodeRef.getId());
        }
        List<Organization> scopedOrgs = organizationService.getOrganizationsInScope(scopeQuery);
        Organization firstScopedOrg = scopedOrgs.get(0);
        OrganizationRef firstScopedOrgRef = organizationService.getOrganizationRefById(firstScopedOrg.getId());

        UserRequest userRequestUpdate = microservice.activateBySupervisor(userRequestId, firstScopedOrgRef);

        if (fromState.equals(UserRequest.EState.ACCESS_MANAGER_APPROVED)) {
            sendUserRequestEmail(userRequestId, fromState, UserRequest.EState.ACTIVATED);
        }

        UserProfile userProfile = userService.getUserProfileByUserRequestId(userRequestUpdate.getId());
        userService.sendBusinessIntelligenceRoleAddedEmail(userProfile, null);

        return userRequestUpdate;
    }

    public UserRequest addUserRequestComment(String userRequestId, String comment) {
        return microservice.addUserRequestComment(userRequestId, comment);
    }

    public UserRequest removeUserRequestComment(String userRequestId, String commentId) {
        return microservice.removeUserRequestComment(userRequestId, commentId);
    }

    public Integer getMaxUploadSize() {
        if (null == maxUploadSize){
            maxUploadSize = fileManagerAdminService.getMaxPostSize();
        }

        return maxUploadSize;
    }

    public FileManager uploadFile(byte[] fileContent, String uploadedFileName) {
        FileManager uploadedFile;

        try {
            uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }

    public List<ParticipantDetailsDTO> getAvailableParticipants(String userRequestId, String participantType) throws IllegalAccessException {
        return microservice.getAvailableParticipants(userRequestId, participantType) ;
    }

    public UserRequest saveNewParticipant(String userRequestId, String participantType, String userProfileId) throws IllegalAccessException {
        return microservice.saveNewParticipant(userRequestId, participantType, userProfileId);
    }

    public List<UserRequirement> removeParticipant(String userRequestId, String userProfileId) {
        return microservice.removeParticipant(userRequestId, userProfileId);
    }

    public List<UserRequirement> reassignRequirementsToPrimaryAccessManager(String userRequestId, String userProfileId) {
        return microservice.reassignRequirementsToPrimaryAccessManager(userRequestId, userProfileId);
    }

    public List<UserRequirement> deleteRequirementsAssignedToParticipant(String userRequestId, String userProfileId) {
        return microservice.deleteRequirementsAssignedToParticipant(userRequestId, userProfileId);
    }

    public UserRequirement saveUserRequestRequirement(String userRequestId, UserRequirement userRequirement) {
        UserRequest userRequest = getUserRequestById(userRequestId);
        boolean isNewRequirement = false;

        if (userRequirement.getId() == null) {
            isNewRequirement = true;
        }
        UserRequirement updatedRequirement = microservice.saveUserRequestRequirement(userRequestId, userRequirement);

        if ((UserRequest.EState.SENT_TO_CANDIDATE_FOR_COMPLETION.equals(userRequest.state)
                || UserRequest.EState.REQUIREMENT_VERIFICATION.equals(userRequest.state))
                && updatedRequirement.supplyingParty.participantType.equals(UserRequest.EParticipantType.CANDIDATE)) {
            if (isNewRequirement) {
                // Send email to candidate when a new requirement is added if it is with candidate
                sendUserRequirementEmail(userRequestId, updatedRequirement, EUserRequestEmailType.USER_REQUEST_REQUIREMENT_ADDED);
            } else {
                // Send email to candidate when a requirement is saved if it is with candidate
                sendUserRequirementEmail(userRequestId, updatedRequirement, EUserRequestEmailType.USER_REQUEST_REQUIREMENT_UPDATED);
            }
        }

        return updatedRequirement;
    }

    public UserRequirement addUserRequestRequirement(String userRequestId, UserRequirement userRequirement) {
        UserRequest userRequest = getUserRequestById(userRequestId);
        UserRequirement requirement = microservice.addUserRequestRequirement(userRequestId, userRequirement);

        // Send email to candidate when a new requirement is added if it is with candidate
        if ((UserRequest.EState.SENT_TO_CANDIDATE_FOR_COMPLETION.equals(userRequest.state)
                || UserRequest.EState.REQUIREMENT_VERIFICATION.equals(userRequest.state))
                && requirement.supplyingParty.participantType.equals(UserRequest.EParticipantType.CANDIDATE)) {
            sendUserRequirementEmail(userRequestId, requirement, EUserRequestEmailType.USER_REQUEST_REQUIREMENT_ADDED);
        }

        return requirement;
    }

    private void sendUserRequirementEmail(String userRequestId, UserRequirement requestRequirement, EUserRequestEmailType type) {
        UserRequest userRequest = getUserRequestById(userRequestId);
        UserRequestEmailWrapper emailDetails = new UserRequestEmailWrapper();
        emailDetails.userRequestEmailType = type;
        emailDetails.userRequestId = userRequestId;
        emailDetails.requirement = requestRequirement;
        String name;
        String email;

        if (!requestRequirement.supplyingParty.participantType.equals(UserRequest.EParticipantType.CANDIDATE)) {
            UserProfile userProfile = userService.getUserProfileById(requestRequirement.supplyingParty.userProfileRef.getId());

            if (userProfile == null) {
                throw new ApplicationException("User profile not found");
            } else if (!userProfile.userProfileStatus.equals(EUserStatus.ACTIVE.toString())) {
                throw new ApplicationException("User profile not current");
            }

            email = userProfile.email;
            name = requestRequirement.supplyingParty.userProfileRef.fullName;

            if (userProfile.userProfileStatus.equals(EUserStatus.ACTIVE.toString())) {
                EmailMessage emailMessage = microservice.buildUserRequestEmail(name, email, emailDetails);
                notificationService.sendEmail(emailMessage);
            }
        } else {
            name = userRequest.firstName + " " + userRequest.lastName;
            email = userRequest.email;

            if (!dateUtil.isDateInPast(userRequest.expirationDate)) {
                EmailMessage emailMessage = microservice.buildUserRequestEmail(name, email, emailDetails);
                notificationService.sendEmail(emailMessage);
            }
        }
    }

    public UserRequest deleteUserRequestRequirement(String userRequestId, String userRequestRequirementId) {
        return microservice.deleteUserRequestRequirement(userRequestId, userRequestRequirementId);
    }

    public UserRequirement acknowledgeTextRequirement(String requirementId, boolean acknowledge) {
        return microservice.acknowledgeTextRequirement(requirementId, acknowledge);
    }

    public UserRequirement acknowledgeTextRequirementForCandidate(String userRequestId, String requirementId, boolean acknowledge) {
        return microservice.acknowledgeTextRequirementForCandidate(userRequestId, requirementId, acknowledge);
    }

    public UserRequirement completeUserRequestRequirement(String userRequestId, String requirementId) {
        return microservice.completeUserRequestRequirement(userRequestId, requirementId);
    }

    public UserRequirement completeUserRequestRequirementForCandidate(String userRequestId, String requirementId) {
        return microservice.completeUserRequestRequirementForCandidate(userRequestId, requirementId);
    }

    public UserRequirement reworkUserRequestRequirement(String userRequestId, String requirementId) {
        UserRequest userRequest = getUserRequestById(userRequestId);
        UserRequirement requirement = microservice.reworkUserRequestRequirement(userRequestId, requirementId);

        // Send email to candidate when a requirement assigned to the candidate is set to be reworked
        if ((UserRequest.EState.SENT_TO_CANDIDATE_FOR_COMPLETION.equals(userRequest.state)
                || UserRequest.EState.REQUIREMENT_VERIFICATION.equals(userRequest.state))
                && requirement.supplyingParty.participantType.equals(UserRequest.EParticipantType.CANDIDATE)) {
            sendUserRequirementEmail(userRequestId, requirement, EUserRequestEmailType.USER_REQUEST_REQUIREMENT_REWORK);
        }

        return requirement;
    }

    public UserRequirement reworkUserRequestRequirementForCandidate(String userRequestId, String requirementId) {
        return microservice.reworkUserRequestRequirementForCandidate(userRequestId, requirementId);
    }

    public UserRequirement verifyUserRequestRequirement(String userRequestId, String requirementId) {
        return microservice.verifyUserRequestRequirement(userRequestId, requirementId);
    }

    public UserRequirement addUserRequestRequirementComment(String userRequestRequirementId, String comment) {
        return microservice.addUserRequestRequirementComment(userRequestRequirementId, comment);
    }

    public UserRequirement addUserRequestRequirementCommentForCandidate(String userRequestRequirementId, String comment) {
        return microservice.addUserRequestRequirementCommentForCandidate(userRequestRequirementId, comment);
    }

    public UserRequirement removeUserRequestRequirementComment(String userRequestRequirementId, String commentId) {
        return microservice.removeUserRequestRequirementComment(userRequestRequirementId, commentId);
    }

    public UserRequirement removeUserRequestRequirementCommentForCandidate(String userRequestRequirementId, String commentId) {
        return microservice.removeUserRequestRequirementCommentForCandidate(userRequestRequirementId, commentId);
    }

    public void updateUserRequestRequirementRefs(UserRequirementRef userRequirementRef) {
        microservice.updateUserRequestRequirementRefs(userRequirementRef);
    }

    public void updateRoleRefs(RoleRef roleRef) {
        microservice.updateRoleRefs(roleRef);
    }

    public List<String> getDocumentTypes() {
        return microservice.getDocumentTypes();
    }
}
