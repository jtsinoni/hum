package logicole.gateway.services.workorder;

import logicole.apis.workorder.ICoreWorkOrderMicroserviceApi;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.workorder.validator.WorkOrderAccessValidatorFactory;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class CoreWorkOrderService extends BaseGatewayService<ICoreWorkOrderMicroserviceApi> {
    public CoreWorkOrderService() {
        super("CoreWorkOrderService");
    }

    public WorkOrder findById(String id) {
        WorkOrder workOrder = microservice.findById(id);
        WorkOrderAccessValidatorFactory.getValidator(workOrder, currentUserBT).validateUserAccess();
        return workOrder;
    }

    public List<WorkOrder> getAssociateWorkOrders(String workOrderId) {
        return microservice.getAssociateWorkOrders(workOrderId);
    }

    public List<WorkOrder> getAssociateAndNonAssociateWorkOrders(String workOrderId) {
        return microservice.getAssociateAndNonAssociateWorkOrders(workOrderId);
    }

    public WorkOrder updateAssociateWorkOrder(WorkOrder workOrder) {
        WorkOrder persisted = microservice.findById(workOrder.getId());
        WorkOrderAccessValidatorFactory.getValidator(persisted, currentUserBT)
                .validateAllowedToEditWorkOrder();
        return microservice.updateAssociateWorkOrders(workOrder);
    }

    public SearchResult<WorkOrder> getWorkOrders(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getWorkOrderSearchEngine();
        if (ESearchEngine.ELASTIC.equals(searchEngine)) {
            throw new ApplicationException("Elastic search is not supported now");
        } else {
            return microservice.getWorkOrderSearchResults(searchInput);
        }
    }
}
