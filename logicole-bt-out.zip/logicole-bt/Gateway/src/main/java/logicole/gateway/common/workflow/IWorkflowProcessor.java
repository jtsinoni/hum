package logicole.gateway.common.workflow;

import logicole.common.datamodels.user.UserProfile;
import logicole.common.datamodels.workflow.WorkflowState;
import logicole.common.servers.business.RequestWorkflowData;

public interface IWorkflowProcessor<T> {
    void process(WorkflowState workflowState, T objectToProcess, UserProfile profile, String action);

    default void process(WorkflowState workflowState, T objectToProcess, UserProfile profile, String action, RequestWorkflowData requestWorkflowData) {
        this.process(workflowState, objectToProcess, profile, action);
    }

}
