package logicole.gateway.services.assemblage;

import logicole.apis.assemblage.IAssemblageMicroserviceApi;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.abi.DestructionRef;
import logicole.common.datamodels.abi.RestrictionRef;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.assemblage.Assemblage;
import logicole.common.datamodels.assemblage.AssemblageInfo;
import logicole.common.datamodels.assemblage.AssemblageItem;
import logicole.common.datamodels.assemblage.AssemblageItemRef;
import logicole.common.datamodels.assemblage.AssemblageRef;
import logicole.common.datamodels.assemblage.AuthoritativeAssemblage;
import logicole.common.datamodels.assemblage.CommingledRef;
import logicole.common.datamodels.assemblage.CriticalCode;
import logicole.common.datamodels.assemblage.CriticalRef;
import logicole.common.datamodels.assemblage.DeferredCode;
import logicole.common.datamodels.assemblage.DeferredRef;
import logicole.common.datamodels.assemblage.EStratificationName;
import logicole.common.datamodels.catalog.CatalogItem;
import logicole.common.datamodels.catalog.CatalogRef;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.PackageBase;
import logicole.common.datamodels.general.PackageUnit;
import logicole.common.datamodels.inventory.InventoryRecord;
import logicole.common.datamodels.inventory.ItemLocation;
import logicole.common.datamodels.inventory.ItemStorage;
import logicole.common.datamodels.inventory.StorageLocation;
import logicole.common.datamodels.inventory.StorageLocationRef;
import logicole.common.datamodels.inventory.StratificationRef;
import logicole.common.datamodels.sale.seller.SellerRef;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.NumberUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.catalog.CatalogService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.inventory.InventoryService;
import logicole.gateway.services.inventory.LocationService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@ApplicationScoped
public class AssemblageShipmentService extends BaseGatewayService<IAssemblageMicroserviceApi> {

    public AssemblageShipmentService() {
        super("AllowanceShipment");
    }

    private static final String REGEX_NEWLINE = "\\n";
    private static final String REGEX_TAB = "\t";
    private static final String DATE_FORMAT = "MM/dd/yyyy";

    @Inject
    private FileManagerAdminService fileManagerAdminService;

    @Inject
    AssemblageLookupService assemblageLookupService;

    @Inject
    AssemblageService assemblageService;

    @Inject
    LocationService locationService;

    @Inject
    private StringUtil stringUtil;

    @Inject
    private InventoryService inventoryService;

    @Inject
    private CatalogService catalogService;

    @Inject
    private ItemService itemService;

    public FileManager uploadInShipmentFile(byte[] fileContent, String uploadedFileName) {
        FileManager uploadedFile;

        try {
            if (fileContent.length > 0) {
                uploadedFile = fileManagerAdminService.uploadManaged(fileContent, uploadedFileName);
            } else {
                uploadedFile = new FileManager();
                uploadedFile.uploadedFileName = uploadedFileName;
                uploadedFile.fileSize = Long.valueOf(0);
                uploadedFile.uploadDateTime = new Date();
            }
        } catch (FatalProcessingException e) {
            throw new ApplicationException("Unable to upload the file");
        }

        return uploadedFile;
    }

    public void removeInShipmentFiles(ArrayList<String> fileIds) throws IOException {
        try {
            fileManagerAdminService.removeFilesManaged(fileIds);
        } catch (FatalProcessingException | ApplicationException e) {
            throw new ApplicationException("Was not able to remove a file");
        }
    }

    public List<Assemblage> getAssemblagesForInShipmentFile(String fileId) throws IOException {
        List<Assemblage> assemblages = new ArrayList<>();

        final byte[] fileByteArray = fileManagerAdminService.getFileContentsAsPrimitiveByte(fileId);

        final String fileContents = new String(fileByteArray);

        final String[] fileLines = fileContents.split(REGEX_NEWLINE);

        for (String fileLine : fileLines) {
            Assemblage assemblage = new Assemblage();
            String[] dataValues = fileLine.split(REGEX_TAB);

            assemblage.legacyDbId = readDataValue(dataValues, 0);
            assemblage.projectCode = readDataValue(dataValues, 1);

            String equipmentReportingCode = readDataValue(dataValues, 2);

            if (!StringUtil.isBlankOrNull(equipmentReportingCode)) {
                assemblage.equipmentReportingCodeRef = assemblageLookupService.getEquipmentReportingCodeByCode(equipmentReportingCode);
            }

            assemblage.description = readDataValue(dataValues, 6);
            assemblage.instance = readDataValue(dataValues, 7);
            assemblage.identifier = readDataValue(dataValues, 9);
            assemblage.increment = readDataValue(dataValues, 10);
            assemblage.subAssemblage = readDataValue(dataValues, 11);
            assemblage.buildControlNumber = readDataValue(dataValues, 12);
            String associatedOrganizationCode = readDataValue(dataValues, 13);
            associatedOrganizationCode = "AF".equals(associatedOrganizationCode) ? "DF" : associatedOrganizationCode;

            assemblage.associatedOrganizationRef = assemblageLookupService.getAssociatedOrganizationRefByCode(associatedOrganizationCode);

            if (assemblage.managedByNodeRef == null || StringUtil.isEmptyOrNull(assemblage.managedByNodeRef.id)) {
                assemblage.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
            }

            // Determine if Authoritative Assemblage exists
            AuthoritativeAssemblage authoritativeAssemblage = new AuthoritativeAssemblage();
            authoritativeAssemblage.increment = assemblage.increment;
            authoritativeAssemblage.identifier = assemblage.identifier;
            authoritativeAssemblage.subAssemblage = assemblage.subAssemblage;

            List<AuthoritativeAssemblage> authoritativeAssemblages = assemblageService.getAuthoritativeAssemblagesByKeyFields(Arrays.asList(authoritativeAssemblage));
            if (authoritativeAssemblages != null && authoritativeAssemblages.size() > 0) {
                assemblage.type = "Standard";
                assemblage.authoritativeAssemblageRef = authoritativeAssemblages.get(0).getRef();
            } else {
                assemblage.type = "Non-Standard";
            }


            assemblage.operationalStatus = "Mobile";

            assemblages.add(assemblage);
        }

        return assemblages;
    }

    private String readDataValue(String[] dataValues, int index) {

        String dataValue = "";

        if (dataValues != null && dataValues.length > index) {
            dataValue = dataValues[index];
        }

        return dataValue == null ? "" : dataValue;
    }

    public List<Assemblage> importExternalAssemblages(@NotNull AssemblageInfo assemblageInfo) throws ParseException, IOException {
        List<Assemblage> assemblagesToImport = assemblageInfo.assemblages;
        List<AssemblageItem> assemblageItemsToImport = new ArrayList<>();
        List<ItemLocation> itemLocationsToImport = new ArrayList<>();
        List<Attachment> importFiles = assemblageInfo.importFiles;
        String buyerId = assemblagesToImport.get(0).customerNodeRef.getId();


        //Process the assm_inst_item.txt file
        Optional<Attachment> assmInstItem = importFiles.stream().filter(file -> file.fileRef.uploadedFileName.toLowerCase().equals("assm_inst_item.txt")).findFirst();
        if (assmInstItem.isPresent()) {
            assemblageItemsToImport = processAssmInstItem(buyerId, assmInstItem.get());
        }

        //Process the assm_item_dtl.txt file
        Optional<Attachment> assmItemDtl = importFiles.stream().filter(file -> file.fileRef.uploadedFileName.toLowerCase().equals("inst_item_dtl.txt")).findFirst();
        if (assmItemDtl.isPresent()) {
            itemLocationsToImport = processAssmItemDtl(assmItemDtl.get());
        }

        // Insert each assemblage, then update its items with the correct assemblage ref
        for (Assemblage assemblage : assemblagesToImport) {
            String legacyDbId = assemblage.legacyDbId;
            assemblage.setId("");

            // Get next instance for assemblage
            int lastInstance = microservice.getLastInstanceForIdentifierIncrementSubAssemblage(assemblage.identifier, assemblage.increment, assemblage.subAssemblage);
            assemblage.instance = String.valueOf(lastInstance + 1);

            // Insert Assemblage
            Assemblage assemblageAdded = microservice.addAssemblage(assemblage);

            // Get items with old assemblage id
            List<AssemblageItem> itemsForThisAssemblage = assemblageItemsToImport.stream().filter(item -> item.assemblageRef.id.equals(legacyDbId)).collect(Collectors.toList());

            // Set AssemblageRef on items for this assemblage.
            AssemblageRef assemblageRef = assemblageAdded.getRef();
            itemsForThisAssemblage.forEach(item -> item.assemblageRef = assemblageRef);

            // Insert Items
            assemblageService.addAssemblageItems(itemsForThisAssemblage);

            for (AssemblageItem assemblageItem : itemsForThisAssemblage) {
                // Get locations for this item
                List<ItemLocation> locationsForThisItem = itemLocationsToImport.stream().filter(location -> location.itemLocationIdentifier.equals(assemblageItem.id)).collect(Collectors.toList());
                if (locationsForThisItem.size() > 0) {
                    StorageLocation rootLocation = locationService.getRootStorageLocationByNodeId(buyerId);


                    for (ItemLocation itemLocation : locationsForThisItem) {
                        itemLocation.itemLocationIdentifier = stringUtil.getUUID();

                        // Get location options for customer
                        List<StorageLocationRef> locationOptions = locationService.getStorageLocationRefsByNodeId(buyerId);

                        // See if locations given in the file matches are valid in logicole
                        String locationFromFile = itemLocation.locationRef.parentId;
                        String subLocationFromFile = itemLocation.locationRef.name;
                        String hierarchyFromFile = itemLocation.locationRef.hierarchy;

                        Optional<StorageLocationRef> storageLocationHierarchyOptional = locationOptions.stream().filter(storageLocation -> storageLocation.hierarchy.equals(hierarchyFromFile)).findFirst();

                        if (storageLocationHierarchyOptional.isPresent()) {
                            itemLocation.locationRef = storageLocationHierarchyOptional.get();
                        } else {
                            Optional<StorageLocationRef> primeLocationOptional = locationOptions.stream().filter(storageLocation -> storageLocation.name.equals(locationFromFile)).findFirst();
                            StorageLocationRef primeLocationRef;

                            if (rootLocation != null) {
                                if (!primeLocationOptional.isPresent()) {
                                    // Insert primary location
                                    StorageLocation primeLocation = new StorageLocation();
                                    primeLocation.parentId = rootLocation.getId();
                                    primeLocation.hierarchy = locationFromFile;
                                    primeLocation.inventorySystemRef = rootLocation.inventorySystemRef;
                                    primeLocation.name = locationFromFile;
                                    primeLocation.allowItemStorage = true;
                                    primeLocation = locationService.createStorageLocation(primeLocation);
                                    primeLocationRef = primeLocation.getRef();
                                    locationOptions.add(primeLocationRef);
                                } else {
                                    primeLocationRef = primeLocationOptional.get();
                                }

                                if (subLocationFromFile.length() > 0) {
                                    // Insert sub location
                                    StorageLocation subLocation = new StorageLocation();
                                    subLocation.parentId = primeLocationRef.getId();
                                    subLocation.hierarchy = hierarchyFromFile;
                                    subLocation.inventorySystemRef = rootLocation.inventorySystemRef;
                                    subLocation.name = subLocationFromFile;
                                    subLocation.allowItemStorage = true;
                                    subLocation = locationService.createStorageLocation(subLocation);
                                    itemLocation.locationRef = subLocation.getRef();
                                    locationOptions.add(subLocation.getRef());
                                } else {
                                    itemLocation.locationRef = primeLocationRef;
                                }
                            }
                        }
                    }

                    InventoryRecord inventoryRecord = new InventoryRecord();
                    inventoryRecord.catalogRef = assemblageItem.catalogRef;
                    inventoryRecord.itemLocations = locationsForThisItem;
                    inventoryRecord.itemRef = assemblageItem.itemRef;
                    inventoryRecord.assemblageRef = assemblageAdded.getRef();
                    inventoryRecord.assemblageItemRef = assemblageItem.getRef();
                    inventoryRecord.unitOfInventory = new PackageUnit();
                    inventoryRecord.unitOfInventory.packageBase = new PackageBase();
                    inventoryRecord.movingAverageCost = new MonetaryValue(0);
                    if (rootLocation != null) {
                        inventoryRecord.inventorySystemRef = rootLocation.inventorySystemRef;
                    }
                    inventoryRecord.sellerRef = new SellerRef();
                    inventoryService.saveInventoryRecordForAssemblage(inventoryRecord);
                }

            }
        }

        return assemblagesToImport;
    }

    public List<AssemblageItem> processAssmInstItem(String buyerId, Attachment importFile) throws IOException {
        List<AssemblageItem> assemblageItems = new ArrayList<>();
        byte[] fileByteArray = fileManagerAdminService.getFileContentsAsPrimitiveByte(importFile.fileRef.fileId);

        final String fileContents = new String(fileByteArray);

        final String[] fileLines = fileContents.split(REGEX_NEWLINE);

        for (String fileLine : fileLines) {
            AssemblageItem assemblageItem = new AssemblageItem();
            String[] dataValues = fileLine.split(REGEX_TAB);
            assemblageItem.id = readDataValue(dataValues, 0);
            assemblageItem.commingledRef = new CommingledRef();
            assemblageItem.commingledRef.commingledCode = readDataValue(dataValues, 1);
            assemblageItem.isCommingled = StringUtil.isEmptyOrNull(assemblageItem.commingledRef.commingledCode) ? false : true;
            assemblageItem.commingledQuantity = NumberUtil.tryParseInteger(readDataValue(dataValues, 2), 0);
            assemblageItem.criticalRef = new CriticalRef();
            assemblageItem.criticalRef.criticalCode = readDataValue(dataValues, 3);
            assemblageItem.isCritical = StringUtil.isEmptyOrNull(assemblageItem.criticalRef.criticalCode) ? false : true;
            assemblageItem.commingledNote = readDataValue(dataValues, 4);
            assemblageItem.criticalQuantity = NumberUtil.tryParseInteger(readDataValue(dataValues, 5), 0);
            assemblageItem.deferredRef = new DeferredRef();
            assemblageItem.deferredRef.deferredCode = readDataValue(dataValues, 6);
            assemblageItem.isDeferred = StringUtil.isEmptyOrNull(assemblageItem.deferredRef.deferredCode) ? false : true;
            assemblageItem.deferredQuantity = NumberUtil.tryParseInteger(readDataValue(dataValues, 7), 0);
            assemblageItem.criticalNote = readDataValue(dataValues, 8);
            assemblageItem.assemblageRef = new AssemblageRef();
            assemblageItem.assemblageRef.id = readDataValue(dataValues, 9);
            assemblageItem.catalogRef = new CatalogRef();
            assemblageItem.catalogRef.catalogItemIdentifier = readDataValue(dataValues, 10);
            assemblageItem.minimumQuantityAllowance = NumberUtil.tryParseInteger(readDataValue(dataValues, 11), 0);
            assemblageItem.deferredNote = readDataValue(dataValues, 12);
            assemblageItem.previousQuantityAllowance = NumberUtil.tryParseInteger(readDataValue(dataValues, 13), 0);
            assemblageItem.onHandQuantity = NumberUtil.tryParseInteger(readDataValue(dataValues, 14), 0);
            assemblageItem.associatedSupportItemsOfEquipmentType = readDataValue(dataValues, 16);
            assemblageItem.medicalUnitAssemblageGroupCode = readDataValue(dataValues, 17);

            assemblageService.buildItem(buyerId, assemblageItem, assemblageItem.catalogRef.catalogItemIdentifier);

            assemblageItems.add(assemblageItem);
        }

        return assemblageItems;
    }

    public List<ItemLocation> processAssmItemDtl(Attachment importFile) throws ParseException, IOException {
        List<ItemLocation> itemLocations = new ArrayList<>();

        byte[] fileByteArray = fileManagerAdminService.getFileContentsAsPrimitiveByte(importFile.fileRef.fileId);

        final String fileContents = new String(fileByteArray);

        final String[] fileLines = fileContents.split(REGEX_NEWLINE);

        for (String fileLine : fileLines) {
            String[] dataValues = fileLine.split(REGEX_TAB);
            ItemLocation itemLocation = new ItemLocation();
            ItemStorage itemStorage = new ItemStorage();
            itemLocation.itemStorage = new ArrayList<>();
            itemLocation.itemLocationIdentifier = readDataValue(dataValues, 1);
            itemStorage.stratificationRef = new StratificationRef();
            itemStorage.stratificationRef.name = readDataValue(dataValues, 2);
            itemStorage.onHandQty = NumberUtil.tryParseInteger(readDataValue(dataValues, 3), 0);

            // Temporary placeholders before we process the individual assemblages selected
            itemLocation.locationRef = new StorageLocationRef();
            itemLocation.locationRef.parentId = readDataValue(dataValues, 4);
            itemLocation.locationRef.name = readDataValue(dataValues, 5);
            itemLocation.locationRef.hierarchy = itemLocation.locationRef.name.length() > 0 ? itemLocation.locationRef.parentId + "/" + itemLocation.locationRef.name : itemLocation.locationRef.parentId;


            itemStorage.incompleteFlag = readDataValue(dataValues, 7).equals("Y");
            itemStorage.expirationDate = readDataValue(dataValues, 8).length() > 0 ? new SimpleDateFormat(DATE_FORMAT).parse(readDataValue(dataValues, 8)) : null;
            itemStorage.lotNumber = readDataValue(dataValues, 9);

            itemStorage.revisedExpirationDate = readDataValue(dataValues, 12).length() > 0 ? new SimpleDateFormat(DATE_FORMAT).parse(readDataValue(dataValues, 12)) : null;
            itemStorage.authorityForExtension = readDataValue(dataValues, 13);
            itemStorage.manufacturerDate = readDataValue(dataValues, 17).length() > 0 ? new SimpleDateFormat(DATE_FORMAT).parse(readDataValue(dataValues, 17)) : null;
            itemStorage.manufacturerName = readDataValue(dataValues, 18);
            itemStorage.modelNumber = readDataValue(dataValues, 19);
            itemStorage.serialNumber = readDataValue(dataValues, 20);

            itemLocation.itemStorage.add(itemStorage);
            itemLocations.add(itemLocation);
        }

        return itemLocations;
    }

    public byte[] outShipAssemblages(@NotNull AssemblageInfo assemblageInfo) throws IOException {
        List<Assemblage> assemblagesToExport = assemblageInfo.assemblages;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ZipOutputStream exportZipOut = new ZipOutputStream(bos);

        StringBuilder assmInstanceFile = new StringBuilder();
        StringBuilder assmIntItemFile = new StringBuilder();
        StringBuilder primeSubFile = new StringBuilder();
        StringBuilder supportItemFile = new StringBuilder();
        StringBuilder instItemDtlFile = new StringBuilder();
        StringBuilder assmWeightCubeFile = new StringBuilder();
        StringBuilder itemFile = new StringBuilder();
        StringBuilder criticalFile = new StringBuilder();
        StringBuilder deferredFile = new StringBuilder();
        StringBuilder deviceFile = new StringBuilder();
        StringBuilder destructionFile = new StringBuilder();
        StringBuilder itemSpecRqmtFile = new StringBuilder();
        StringBuilder ownershipFile = new StringBuilder();
        StringBuilder projectFile = new StringBuilder();
        StringBuilder exceptFile = new StringBuilder();
        StringBuilder medEquipFile = new StringBuilder();
        StringBuilder maintDataFile = new StringBuilder();
        StringBuilder meNotesFile = new StringBuilder();
        StringBuilder mtfSosFile = new StringBuilder();
        StringBuilder maintCostFile = new StringBuilder();


        for (Assemblage assemblage : assemblagesToExport) {
            buildAssmInstanceFile(assemblage, assmInstanceFile);

            List<AssemblageItem> assemblageItems = assemblageService.getItemsByAssemblageId(assemblage.getId());

            for (AssemblageItem assemblageItem : assemblageItems) {
                CatalogItem catalogItem = !StringUtil.isBlankOrNull(assemblageItem.catalogRef.id) ? catalogService.getCatalogWithItemById(assemblageItem.catalogRef.id) : new CatalogItem();


                buildAssmInstItemFile(assemblageItem, assmIntItemFile);
                buildPrimeSubFile(assemblageItem, primeSubFile);
                buildSupportItemFile(assemblageItem, supportItemFile);
                buildItemFile(assemblageItem, catalogItem, itemFile);
                buildDestructionFile(assemblageItem, destructionFile);

                if (assemblageItem.itemRef != null && !StringUtil.isBlankOrNull(assemblageItem.itemRef.deviceCode)) {
                    buildDeviceFile(assemblageItem, deviceFile);
                }

                buildItemSpecRqmtFile(assemblageItem, catalogItem, itemSpecRqmtFile);
            }

            List<InventoryRecord> inventoryRecords = inventoryService.getInventoryRecordsForAssemblageById(assemblage.getId());

            for (InventoryRecord inventoryRecord : inventoryRecords) {
                buildInstItemDtlFile(inventoryRecord, instItemDtlFile);
            }
        }

        buildCriticalFile(criticalFile);
        buildDeferredFile(deferredFile);
        buildOwnershipFile(ownershipFile);
        buildProjectFile(projectFile);


        addFileToZip(exportZipOut, "assm_instance.txt", assmInstanceFile);
        addFileToZip(exportZipOut, "assm_inst_item.txt", assmIntItemFile);
        addFileToZip(exportZipOut, "prime_subitem.txt", primeSubFile);
        addFileToZip(exportZipOut, "support_item.txt", supportItemFile);
        addFileToZip(exportZipOut, "inst_item_dtl.txt", instItemDtlFile);
        addFileToZip(exportZipOut, "assm_weight_cube.txt", assmWeightCubeFile);
        addFileToZip(exportZipOut, "item.txt", itemFile);
        addFileToZip(exportZipOut, "critical.txt", criticalFile);
        addFileToZip(exportZipOut, "deferred.txt", deferredFile);
        addFileToZip(exportZipOut, "device.txt", deviceFile);
        addFileToZip(exportZipOut, "item_destruct.txt", destructionFile);
        addFileToZip(exportZipOut, "item_spec_rqmt.txt", destructionFile);
        addFileToZip(exportZipOut, "ownership.txt", ownershipFile);
        addFileToZip(exportZipOut, "project.txt", projectFile);
        addFileToZip(exportZipOut, "except.txt", exceptFile);
        addFileToZip(exportZipOut, "gain_grid.txt", assmInstanceFile);
        addFileToZip(exportZipOut, "med_equip.txt", medEquipFile);
        addFileToZip(exportZipOut, "maint_data.txt", maintDataFile);
        addFileToZip(exportZipOut, "me_notes.txt", meNotesFile);
        addFileToZip(exportZipOut, "mtf_sos.txt", mtfSosFile);
        addFileToZip(exportZipOut, "maint_cost.txt", maintCostFile);


        exportZipOut.close();

        return bos.toByteArray();
    }

    private void buildAssmInstanceFile(Assemblage assemblage, StringBuilder assmInstanceFile) {

        if (assmInstanceFile.length() > 0) {
            assmInstanceFile.append("\n");
        }

        List<String> fileContents = new ArrayList<>();
        fileContents.add(setSerialIdField(assemblage.getId()));
        fileContents.add(setStringValue(assemblage.projectCode));
        fileContents.add(assemblage.equipmentReportingCodeRef != null ? setStringValue(assemblage.equipmentReportingCodeRef.code) : "");
        fileContents.add("1000");
        fileContents.add(assemblage.customerNodeRef.name);
        fileContents.add(assemblage.authoritativeAssemblageRef != null ? setSerialIdField(assemblage.authoritativeAssemblageRef.id) : "");
        fileContents.add(setStringValue(assemblage.description));
        fileContents.add(setStringValue(assemblage.instance));
        fileContents.add(setStringValue(assemblage.buildControlNumber));
        fileContents.add(setStringValue(assemblage.identifier));
        fileContents.add(setStringValue(assemblage.increment));
        fileContents.add(setStringValue(assemblage.subAssemblage));
        fileContents.add(setStringValue(assemblage.buildControlNumber));
        fileContents.add(setStringValue(assemblage.associatedOrganizationRef.code));

        String ownerCode = "L";
        if(assemblage.scope.equals("Customer")) {
            if(assemblage.managed.equals("Customer")) {
                ownerCode = "C";
            } else {
                ownerCode = "O";
            }

        }
        fileContents.add(ownerCode);

        appendFileContentsToFile(fileContents, assmInstanceFile);
    }

    private void buildAssmInstItemFile(AssemblageItem assemblageItem, StringBuilder assmIntItemFile) {

        if (assmIntItemFile.length() > 0) {
            assmIntItemFile.append("\n");
        }
        String assemblageId = "";
        if (assemblageItem.assemblageRef != null) {
            assemblageId = setSerialIdField(assemblageItem.assemblageRef.id);
        }
        List<String> fileContents = new ArrayList<>();
        fileContents.add(setSerialIdField(assemblageItem.getId()));
        fileContents.add(assemblageItem.commingledRef != null ? setStringValue(assemblageItem.commingledRef.commingledCode) : "");
        fileContents.add(setIntValue(assemblageItem.commingledQuantity));
        fileContents.add(assemblageItem.criticalRef != null ? setStringValue(assemblageItem.criticalRef.criticalCode) : "");
        fileContents.add(setStringValue(assemblageItem.commingledNote));
        fileContents.add(setIntValue(assemblageItem.criticalQuantity));
        fileContents.add(assemblageItem.deferredRef != null ? setStringValue(assemblageItem.deferredRef.deferredCode) : "");
        fileContents.add(setIntValue(assemblageItem.deferredQuantity));
        fileContents.add(setStringValue(assemblageItem.criticalNote));
        fileContents.add(assemblageId);
        fileContents.add(assemblageItem.catalogRef != null ? setStringValue(assemblageItem.catalogRef.catalogItemIdentifier) : "");
        fileContents.add(setIntValue(assemblageItem.minimumQuantityAllowance));
        fileContents.add(setStringValue(assemblageItem.deferredNote));
        fileContents.add(assemblageItem.previousQuantityAllowance != null ? assemblageItem.previousQuantityAllowance.toString() : "");
        fileContents.add(setIntValue(assemblageItem.onHandQuantity));
        fileContents.add("");
        fileContents.add(setStringValue(assemblageItem.associatedSupportItemsOfEquipmentType));
        fileContents.add(setStringValue(assemblageItem.medicalUnitAssemblageGroupCode));
        fileContents.add("");
        fileContents.add(assemblageId);

        appendFileContentsToFile(fileContents, assmIntItemFile);
    }

    private void buildPrimeSubFile(AssemblageItem assemblageItem, StringBuilder primeSubFile) {
        List<String> fileContents = new ArrayList<>();

        if (assemblageItem.primeItemRef != null && assemblageItem.primeItemRef.id != null && assemblageItem.primeItemRef.id.length() > 0) {
            if (primeSubFile.length() > 0) {
                primeSubFile.append("\n");
            }

            fileContents.add(setSerialIdField(assemblageItem.primeItemRef.id));
            fileContents.add(setSerialIdField(assemblageItem.getId()));
            fileContents.add("");
            fileContents.add(setIntValue(assemblageItem.primeRatio));
            fileContents.add(setIntValue(assemblageItem.subRatio));

        }
        appendFileContentsToFile(fileContents, primeSubFile);
    }

    private void buildSupportItemFile(AssemblageItem assemblageItem, StringBuilder supportItemFile) {
        if (assemblageItem.endItemRef != null && assemblageItem.endItemRef.size() > 0) {
            for (AssemblageItemRef endItemRef : assemblageItem.endItemRef) {
                List<String> fileContents = new ArrayList<>();

                if (supportItemFile.length() > 0) {
                    supportItemFile.append("\n");
                }

                fileContents.add(setSerialIdField(assemblageItem.getId()));
                fileContents.add(setSerialIdField(endItemRef.id));
                appendFileContentsToFile(fileContents, supportItemFile);
            }
        }
    }

    private void buildInstItemDtlFile(InventoryRecord inventoryRecord, StringBuilder instItemDtlFile)  {
        int recordId = Math.abs(inventoryRecord.getId().hashCode());

        for (ItemLocation itemLocation : inventoryRecord.itemLocations) {
            List<String> fileContents = new ArrayList<>();
            ItemStorage itemStorage = itemLocation.itemStorage.get(0);

            if (instItemDtlFile.length() > 0) {
                instItemDtlFile.append("\n");
            }

            recordId = recordId + 1;

            fileContents.add(Integer.toString(recordId));
            fileContents.add(setSerialIdField(inventoryRecord.assemblageItemRef.id));
            fileContents.add("");
            fileContents.add(itemStorage.stratificationRef != null ? setStringValue(getCodeForStratificationName(itemStorage.stratificationRef.name)) : "");
            fileContents.add(setIntValue(itemStorage.onHandQty));
            String [] locations = parseLocation(itemLocation.locationRef.hierarchy);
            fileContents.add(locations[0]);
            fileContents.add(locations.length > 1 ? locations[1] : "");
            if(itemStorage.manufacturerName.length() > 40) {
                itemStorage.manufacturerName = itemStorage.manufacturerName.substring(0, 40);
            }
            fileContents.add(setStringValue(itemStorage.manufacturerName));
            fileContents.add(itemStorage.incompleteFlag ? "Y" : "N");
            fileContents.add("");
            fileContents.add(setDateValue(itemStorage.manufacturerDate));
            fileContents.add(setDateValue(itemStorage.expirationDate));
            fileContents.add(setStringValue(itemStorage.lotNumber));
            fileContents.add("");
            fileContents.add(""); // TODO Pull the product number from enterprise catalog
            fileContents.add(setDateValue(itemStorage.revisedExpirationDate));
            fileContents.add(setStringValue(itemStorage.authorityForExtension));
            fileContents.add("N");
            fileContents.add("N");
            fileContents.add("N");
            fileContents.add("");
            fileContents.add(setStringValue(itemStorage.equipmentControlNumber));
            fileContents.add(setStringValue(itemStorage.serialNumber));
            fileContents.add(!StringUtil.isBlankOrNull(itemStorage.manufacturerName) ? itemStorage.manufacturerName.substring(0, itemStorage.manufacturerName.length() - 1) : "");
            fileContents.add(setStringValue(itemStorage.modelNumber));
            fileContents.add(""); // TODO Change to Shipment Org Id
            fileContents.add("");

            appendFileContentsToFile(fileContents, instItemDtlFile);
        }
    }

    private void buildItemFile(AssemblageItem assemblageItem, CatalogItem catalogItem, StringBuilder itemFile) {

        if (itemFile.length() > 0) {
            itemFile.append("\n");
        }

        List<String> fileContents = new ArrayList<>();

        fileContents.add(setStringValue(assemblageItem.catalogRef.catalogItemIdentifier));
        fileContents.add(setStringValue(assemblageItem.catalogRef.shortDescription));
        fileContents.add(""); // TODO add logic for expiration code
        fileContents.add(setStringValue(assemblageItem.catalogRef.sellerPackageUnit));
        fileContents.add(setMonetaryValue(assemblageItem.catalogRef.price));
        fileContents.add(setIntValue(assemblageItem.catalogRef.sellerPackageQuantity));
        fileContents.add(assemblageItem.commodityCodeRef != null ? setSerialIdField(assemblageItem.commodityCodeRef.id): "");
        fileContents.add(setStringValue(catalogItem.sellerProductIdentifierType));
        fileContents.add(""); // TODO Figure out special handling
        fileContents.add(setStringValue(assemblageItem.itemRef.deviceCode));
        fileContents.add(""); // TODO Figure out ciic code
        fileContents.add(""); // TODO Figure out demil code
        fileContents.add(""); // TODO Figure out sos code
        fileContents.add(""); // TODO Figure out dsitribution code
        fileContents.add(catalogItem.sellerRef != null ? setStringValue(catalogItem.sellerRef.sellerType) : "");
        fileContents.add(""); // TODO Figure out erc code
        fileContents.add("");
        fileContents.add("");
        fileContents.add(""); // TODO Figure out acquisition advice code
        fileContents.add(assemblageItem.commodityCodeRef != null ? setStringValue(assemblageItem.commodityCodeRef.commodityClassName) : "");

        appendFileContentsToFile(fileContents, itemFile);
    }

    private void buildCriticalFile(StringBuilder criticalFile) {

        List<CriticalCode> criticalCodes = assemblageLookupService.getCriticalCodes();

        for (CriticalCode criticalCode : criticalCodes) {
            List<String> fileContents = new ArrayList<>();

            if (criticalFile.length() > 0) {
                criticalFile.append("\n");
            }

            fileContents.add(criticalCode.code);

            String description = criticalCode.description.toUpperCase();

            if(description.length() > 40) {
                description = description.substring(0, 40);
            }

            fileContents.add(description);

            appendFileContentsToFile(fileContents, criticalFile);
        }
    }

    private void buildDeferredFile(StringBuilder deferredFile) {

        List<DeferredCode> deferredCodes = assemblageLookupService.getDeferredCodes();

        for (DeferredCode deferredCode : deferredCodes) {
            List<String> fileContents = new ArrayList<>();

            if (deferredFile.length() > 0) {
                deferredFile.append("\n");
            }

            fileContents.add(deferredCode.code);

            String description = deferredCode.description.toUpperCase();

            if(description.length() > 40) {
                description = description.substring(0, 40);
            }

            fileContents.add(description);

            appendFileContentsToFile(fileContents, deferredFile);
        }
    }

    private void buildDeviceFile(AssemblageItem assemblageItem, StringBuilder deviceFile) {

        if (deviceFile.length() > 0) {
            deviceFile.append("\n");
        }

        List<String> fileContents = new ArrayList<>();
        fileContents.add(assemblageItem.itemRef.deviceCode);
        fileContents.add(""); // TODO Figure out how to build this file.  It doesn't appear Equipment is ready.
        fileContents.add("");
        fileContents.add("");
        fileContents.add("");
        fileContents.add("");
        fileContents.add("");
        fileContents.add("");
        fileContents.add("");
        fileContents.add("");
        fileContents.add("");
        fileContents.add("");

        appendFileContentsToFile(fileContents, deviceFile);
    }

    private void buildDestructionFile(AssemblageItem assemblageItem, StringBuilder destructionFile) {

        Item item = itemService.getItemByEnterpriseIdOrNsn(assemblageItem.catalogRef.catalogItemIdentifier);

        if (item != null && item.destructionRefList != null && item.destructionRefList.size() > 0) {
            for (DestructionRef destructionRef : item.destructionRefList) {
                List<String> fileContents = new ArrayList<>();

                if (destructionFile.length() > 0) {
                    destructionFile.append("\n");
                }

                fileContents.add(destructionRef.code);
                fileContents.add(item.enterpriseProductIdentifier);

                appendFileContentsToFile(fileContents, destructionFile);
            }
        }
    }

    private void buildItemSpecRqmtFile(AssemblageItem assemblageItem, CatalogItem catalogItem, StringBuilder itemSpecRqmtFile) {
        if (catalogItem.item.restrictionRefList != null && catalogItem.item.restrictionRefList.size() > 0) {
            for (RestrictionRef restrictionRef : catalogItem.item.restrictionRefList) {
                List<String> fileContents = new ArrayList<>();

                if (itemSpecRqmtFile.length() > 0) {
                    itemSpecRqmtFile.append("\n");
                }

                fileContents.add(restrictionRef.code);
                fileContents.add(assemblageItem.catalogRef.catalogItemIdentifier);
                fileContents.add(restrictionRef.code);

                appendFileContentsToFile(fileContents, itemSpecRqmtFile);
            }
        }
    }

    private void buildOwnershipFile(StringBuilder ownershipFile) {
        List<String> fileContents = new ArrayList<>();

        fileContents.add("L");
        fileContents.add("LOG OWNED & LOG MANAGED");
        appendFileContentsToFile(fileContents, ownershipFile);
        ownershipFile.append("\n");
        fileContents.clear();
        fileContents.add("C");
        fileContents.add("CUSTOMER OWNED & CUSTOMER MANAGED");
        appendFileContentsToFile(fileContents, ownershipFile);
        ownershipFile.append("\n");
        fileContents.clear();
        fileContents.add("O");
        fileContents.add("CUSTOMER OWNED & LOG MANAGED");
        appendFileContentsToFile(fileContents, ownershipFile);
    }

    private void buildProjectFile(StringBuilder projectFile) {
        List<String> fileContents = new ArrayList<>();

        fileContents.add("MMJ");
        fileContents.add("MES FWD SURG TEAM");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("IJN");
        fileContents.add("FOWARD SURGICAL TEAM");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("MMB");
        fileContents.add("1X1 BRIGADE");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("MMC");
        fileContents.add("BRIGADE SET, CAMP CARROLL, KOREA");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("PBR");
        fileContents.add("ADOP-OKINAWA (SISS)");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("MTH");
        fileContents.add("SUSTAINMENT STOCK- KOREA");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("PBT");
        fileContents.add("ADOP-OKINAWA (SC-8,TR-8)");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("PBS");
        fileContents.add("ADOP-OKINAWA (SC-4,TR-4)");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("MH5");
        fileContents.add("CBT SPT HOSP, CAMP CARROLL, KOREA");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("MTR");
        fileContents.add("TEST, MEASUREMENT, DIAGNOSTIC EQUIP");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("PYT");
        fileContents.add("MORTUARY AFFAIRS");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("PYX");
        fileContents.add("MORTUARY AFFAIRS");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("PBO");
        fileContents.add("KSN - HOT AND COLD WEATHER");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("M41");
        fileContents.add("M41 SUSTAINMENT");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("P05");
        fileContents.add("ENEMY PRISONER OF WAR");
        appendFileContentsToFile(fileContents, projectFile);
        projectFile.append("\n");
        fileContents.clear();
        fileContents.add("MTM");
        fileContents.add("SUSTAINMENT 31-60 DAYS");
        appendFileContentsToFile(fileContents, projectFile);
    }

    private void appendFileContentsToFile(List<String> fileContents, StringBuilder fileToAppendTo) {
        String format0 = fileContents.toString();
        String format1 = format0.replace("[", "");
        String format2 = format1.replace("]", "");
        String format3 = format2.replace(", ", "\t");
        fileToAppendTo.append(fileContents.toString().replace("[", "").replace("]", "").replace(", ", "\t"));
    }

    private void addFileToZip(ZipOutputStream exportZipOut, String fileName, StringBuilder fileToAdd) throws IOException {
        ZipEntry zipEntry = new ZipEntry(fileName);
        exportZipOut.putNextEntry(zipEntry);
        exportZipOut.write(fileToAdd.toString().getBytes(), 0, fileToAdd.toString().getBytes().length);
        exportZipOut.closeEntry();
    }

    private String setStringValue(String value) {
        return Optional.ofNullable(value).orElse("");
    }

    private String setDateValue(Date value) {
        DateFormat targetFormat = new SimpleDateFormat(DATE_FORMAT);

        if(value == null) {
            return "";
        } else {
            return targetFormat.format(value);
        }
    }

    private String setIntValue(Integer value) {
        if(value == null) {
            return "";
        } else {
            return value.toString();
        }
    }

    private String setMonetaryValue(MonetaryValue value) {
        if (value == null) {
            return "";
        } else {
            return value.getStringVal();
        }
    }

    private String setSerialIdField(String value) {
        if(StringUtil.isBlankOrNull(value)) {
            return "";
        } else {
            return String.valueOf(Math.abs(value.hashCode()));
        }
    }

    private String[] parseLocation(String location) {
        String[] parsedLocation;
        if(location.contains("/")) {
            parsedLocation = location.split("/");
        } else {
            parsedLocation = new String[] {location};
        }

        return parsedLocation;
    }


    private String getCodeForStratificationName(String stratificationName) {
        return EStratificationName.getCodeFromName(stratificationName);
    }
}
