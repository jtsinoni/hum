package logicole.gateway.services.delivery;

import io.swagger.annotations.Api;
import logicole.common.datamodels.delivery.DueOut;
import logicole.common.datamodels.sale.fulfillment.Fulfillment;
import logicole.common.datamodels.user.CurrentUser;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Api(tags = {"DueOut"})
@ApplicationScoped
@Path("/dueOut")
public class DueOutRestApi extends ExternalRestApi<DueOutService> {

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @POST
    @Path("/createFulfillmentDueOut")
    public List<DueOut> createFulfillmentDueOut(List<Fulfillment> fulfillmentList) {
        return service.createFulfillmentDueOut(fulfillmentList);
    }

    @GET
    @Path("/getDueOutList")
    public List<DueOut> getDueOutList(@QueryParam("inventoryOwnerId") String inventoryOwnerId) {
        return service.getDueOutList(inventoryOwnerId);
    }

    @GET
    @Path("/getDueOutListByOrgId")
    public List<DueOut> getDueOutListByOrgId(@QueryParam("orgId") String orgId) {
        return service.getDueOutListByOrgId(orgId);
    }


    @GET
    @Path("/getDueOutListbyProductId")
    public List<DueOut> getDueOutListbyProductId(@QueryParam("enterpriseProductIdentifier") String productIdentifier, @QueryParam("currentOrgId") String currentOrgId) {
        return service.getDueOutListbyProductId(productIdentifier, currentOrgId);
    }

    @GET
    @Path("/updateQueuedForPickQuantity")
    public DueOut updateQueuedForPickQuantity(@QueryParam("dueOutId") String dueOutId, @QueryParam("queuedForPickQuantity") Integer quantity, @QueryParam("backOrderqty") Integer backOrderqty) {
        return service.updateQueuedForPickQuantity(dueOutId, quantity, backOrderqty);
    }

    @GET
    @Path("/getDueOutById")
    public DueOut getDueOutById(@QueryParam("dueOutId") String dueOutId) {
        return service.getDueOutById(dueOutId);
    }

    @GET
    @Path("/deleteDueOutById")
    public void deleteDueOutById(@QueryParam("dueOutId") String dueOutId) {
        service.deleteDueOutById(dueOutId);
    }

    @GET
    @Path("/getSumBackOrderQuantityByProduct")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer getSumBackOrderQuantityByProduct(@QueryParam("enterpriseProductIdentifier") String productIdentifier, @QueryParam("organizationId") String organizationId) {
        return service.getSumBackOrderQuantityByProduct(productIdentifier, organizationId);
    }

    @POST
    @Path("/updateQueuedForDeliveryQuantity")
    public DueOut updateQueuedForDeliveryQuantity(@QueryParam("dueOutId") String dueOutId, @QueryParam("pickedQuantity") Integer pickedQuantity, @QueryParam("inPickQuantity") Integer inPickQuantity) {
        return service.updateQueuedForDeliveryQuantity(dueOutId, pickedQuantity, inPickQuantity);
    }

    @GET
    @Path("/getDueOutByDocumentNumber")
    public DueOut getDueOutByDocumentNumber(@QueryParam("documentNumber") String documentNumber, @QueryParam("backOrderInd") String backOrderInd) {
        return service.getDueOutByDocumentNumber(documentNumber, backOrderInd);
    }

    @POST
    @Path("/updateDueoutQuantity")
    public DueOut updateDueoutQuantity(@QueryParam("dueOutId") String dueOutId, @QueryParam("Quantity") Integer quantity) {
        return service.updateDueoutQuantity(dueOutId, quantity);
    }
}
