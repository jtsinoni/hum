package logicole.gateway.services.system;

import logicole.apis.system.ISystemMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class SystemMicroserviceClient extends MicroserviceClient<ISystemMicroserviceApi> {
    public SystemMicroserviceClient(){
        super(ISystemMicroserviceApi.class, "logicole-system");
    }

    @Produces
    public ISystemMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
