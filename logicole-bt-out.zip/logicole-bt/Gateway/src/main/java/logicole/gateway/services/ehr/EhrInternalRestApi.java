package logicole.gateway.services.ehr;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import logicole.common.datamodels.dmlss.EhrSiteCustomer;
import logicole.common.datamodels.ehr.product.EhrSearchCriteria;
import logicole.common.datamodels.equipment.record.EquipmentRecord;
import logicole.common.datamodels.organization.EhrCustomersBySite;
import logicole.common.datamodels.product.OfferSummary;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.rest.ExternalRestApi;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;

@Api(tags = {"EhrInternal"})
@ApplicationScoped
@Path("/ehr/internal")
public class EhrInternalRestApi extends ExternalRestApi<EhrInternalService> {

    @GET
    @Path("/getEhrSiteCustomers")
    public Collection<EhrCustomersBySite> getEhrSiteCustomers(@QueryParam("type") String type) {
        return service.getEhrSiteCustomers(type);
    }

    @GET
    @Path("/getCustomerOrgs")
    public List<EhrSiteCustomer> getCustomerOrgs() {
        return service.getCustomerOrgs();
    }

    @POST
    @Path("/saveCustomerOrg")
    public EhrSiteCustomer saveCustomerOrg(EhrSiteCustomer ehrSiteCustomer) {
        return service.saveCustomerOrg(ehrSiteCustomer);
    }

    @GET
    @Path("/getEquipmentRecordsForSiteCustomer")
    public List<EquipmentRecord> getEquipmentRecordsForSiteCustomer(@QueryParam("siteId") String siteId,
                                                                    @QueryParam("customerId") String customerId) {
        return service.getEquipmentRecordsForSiteCustomer(siteId, customerId);
    }

    @POST
    @Path("/getEhrEquipmentRecords")
    public List<EquipmentRecord> getEhrEquipmentRecords(EhrSearchCriteria ehrSearchCriteria) throws IOException, ApplicationException {
        return service.getEhrEquipmentRecords(ehrSearchCriteria);
    }

    @GET
    @Path("/resetItemCatalogSyncDate")
    public EhrSiteCustomer resetItemCatalogSyncDate(@QueryParam("id") String id) {
        return service.resetItemCatalogSyncDate(id);
    }

    @GET
    @Path("/resetEquipmentCatalogSyncDate")
    public EhrSiteCustomer resetEquipmentCatalogSyncDate(@QueryParam("id") String id) {
        return service.resetEquipmentCatalogSyncDate(id);
    }

    @GET
    @Path("/setOfferEhrEnabled")
    public OfferSummary setOfferEhrEnabled(@QueryParam("id") String id, @QueryParam("isEhrEnabled") boolean isEhrEnabled) {
        return service.setItemEhrEnabled(id, isEhrEnabled);
    }

    @GET
    @Path("/setEquipmentEhrEnabled")
    public EquipmentRecord setEquipmentEhrEnabled(@QueryParam("id") String id, @QueryParam("isEhrEnabled") boolean isEhrEnabled) {
        return service.setEquipmentEhrEnabled(id, isEhrEnabled);
    }

    @GET
    @Path("/enterpriseProductIdentifierIsEHREnabled")
    @ApiOperation(value = "Checks if enterprise product identifier is in EHR item sync")
    public Boolean enterpriseProductIdentifierIsEHREnabled(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.enterpriseProductIdentifierIsEHREnabled(enterpriseProductIdentifier);
    }

}
