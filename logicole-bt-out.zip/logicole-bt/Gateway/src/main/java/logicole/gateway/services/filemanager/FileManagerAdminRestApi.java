package logicole.gateway.services.filemanager;

import io.swagger.annotations.*;
import logicole.common.datamodels.Configuration;
import logicole.common.datamodels.filemanager.CommonUploadedFile;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.FileUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Date;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Api(tags = {"fileManagerAdmin"})
@ApplicationScoped
@Path("/fileManagerAdmin")
public class FileManagerAdminRestApi extends ExternalRestApi<FileManagerAdminService> {

    /*******************************************************
    //TODO: Anywhere that calls this will have to be updated to use the call below
    *********************************************************/
    @POST
    @Path("/uploadManaged")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file", notes = "The return value will be the file ID")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to uploadManaged",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadManaged(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) throws ApplicationException {
        return service.uploadManaged(form, null);
    }

    @POST
    @Path("/uploadManaged")
    public FileManager uploadManaged(@QueryParam("uploadedFileName") String uploadedFileName, byte[] fileContent) throws ApplicationException {
        return service.uploadManaged(fileContent, uploadedFileName);
    }

    @POST
    @Path("/uploadUnmanaged")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file", notes = "The return value will be the file ID")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to upload using the unmanaged API",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadUnmanaged(@QueryParam("relativeFilePath") String relativeFilePath,
                                  @ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form)
            throws ApplicationException {
        return service.uploadUnmanaged(relativeFilePath, null, form);
    }

    @GET
    @Path("/uploadUnmanagedFile")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file (from Server Side)",
            notes = "The return value will be a FileManager object.")
    public FileManager uploadUnmanagedFile(@QueryParam("nfsShareFileName") String nfsShareFileName,
                                      @QueryParam("relativeFilePath") String relativeFilePath) throws ApplicationException {
        return service.uploadUnmanagedFile(nfsShareFileName, relativeFilePath);
    }

    @GET
    @Path("/download")
    @ApiOperation(value = "Download a file",
            notes = "The file ID code should be the GUID returned from the uploadManaged REST API")
    public Response download(@ApiParam(value = "The file ID", required = true) @QueryParam("fileId") String fileId) throws ApplicationException, IOException {
        CommonUploadedFile commonUploadedFile = service.download(fileId);

        Response.ResponseBuilder response;

        if (commonUploadedFile != null) {
            byte[] bytes = FileUtils.readFileToByteArray(commonUploadedFile.getFile());
            String fileType = Files.probeContentType(commonUploadedFile.getFile().toPath());

            response = Response.ok()
                    .header("Content-Disposition", "attachment; filename=" + commonUploadedFile.getUploadedFilename())
                    .header("Content-Length", bytes.length)
                    .header("Content-Encoding", StandardCharsets.UTF_8)
                    .header("Access-Control-Expose-Headers", "Content-Disposition,Content-Type")
                    .header("Content-Type", fileType);

            if (fileType == null || fileType.isEmpty()) {
                response.type(MediaType.APPLICATION_OCTET_STREAM_TYPE);
            }
            response.entity(bytes);
        } else {
            response = Response.status(Response.Status.NOT_FOUND);
        }

        return response.build();
    }

    @GET
    @Path("/getFileContents")
    @Consumes(MediaType.TEXT_PLAIN)
    @ApiOperation(value = "Get the contents of a file",
            notes = "The file ID code should be the GUID returned from the uploadManaged REST API")
    public Byte[] getFileContents(@QueryParam("fileId") String fileId) throws ApplicationException, IOException {
        return service.getFileContents(fileId);
    }

    @GET
    @Path("/getFileContentsAsPrimitiveByte")
    @Consumes(MediaType.TEXT_PLAIN)
    @ApiOperation(value = "Get the contents of a file as byte[]",
            notes = "The file ID code should be the GUID returned from the uploadManaged REST API")
    public byte[] getFileContentsAsPrimitiveByte(@QueryParam("fileId") String fileId) throws ApplicationException, IOException {
        return service.getFileContentsAsPrimitiveByte(fileId);
    }

    @GET
    @Path("/removeFile")
    @ApiOperation(value = "remove a file", notes = "The file ID code should be the GUID returned from the uploadManaged REST API")
    public Boolean removeFile(@ApiParam(value = "The file ID", required = true) @QueryParam("fileId") String fileId) throws IOException, ApplicationException {
        return service.removeFile(fileId);
    }

    @GET
    @Path("/removeFileUnmanaged")
    @ApiOperation(value = "remove a file", notes = "The file ID code should be the GUID returned from the uploadUnmanaged REST API")
    public Boolean removeFileUnmanaged(@ApiParam(value = "The file ID", required = true) @QueryParam("fileId") String fileId) throws IOException, ApplicationException {
        return service.removeFileUnmanaged(fileId);
    }

    @POST
    @Path("/removeFilesManaged")
    @ApiOperation(value = "Remove 1 or more files based on a list of file ids. Hard-delete DB records. NOTE: Ref processing will NOT take place as part of this operation.")
    public Integer removeFilesManaged(
            List<String> fileIds) throws ApplicationException, IOException {
        return service.removeFilesManaged(fileIds);
    }

    @POST
    @Path("/removeFilesManagedByNodeAndDate")
    @ApiOperation(value = "Remove 1 or more files based on node id, start date, end date (optional), and list of user profile ids (optional). Example date: Jun 16 2021 15:00:00. Hard-delete DB records. NOTE: Ref processing will NOT take place as part of this operation.")
    public Integer removeFilesManagedByNodeAndDate(
            @NotNull @QueryParam("nodeId") String nodeId,
            @NotNull @QueryParam("startDate") Date startDate,
            @QueryParam("endDate") Date endDate,
            List<String> userProfileIds) throws ApplicationException, IOException {
        return service.removeFilesManagedByNodeAndDate(nodeId, startDate, endDate, userProfileIds);
    }

    @GET
    @Path("/base64Download")
    @Produces(MediaType.TEXT_PLAIN)
    @ApiOperation(value = "Download a file in Base64 format", notes = "The file ID code should be the GUID returned from the uploadManaged REST API")
    public String base64Download(@ApiParam(value = "The file ID", required = true) @QueryParam("fileId") String fileId) throws IOException, ApplicationException {
        return service.base64Download(fileId).getBase64FileString();
    }

    @GET
    @Path("/getFileInfo")
    @ApiOperation(value = "Get information for the file identified by the file ID parameter",
            notes = "The file ID code should be the GUID returned from the uploadManaged REST API")
    public FileManager getFileInfo(@ApiParam(value = "The file ID", required = true) @QueryParam("fileId") String fileId) {
        return service.getFileInfo(fileId);
    }

    @GET
    @Path("/getMaxPostSize")
    @Produces(MediaType.TEXT_PLAIN)
    @ApiOperation(value = "Retrieve the maximum data post size to the server ")
    public String getMaxPostSize() throws  ApplicationException {
        Integer maxPostSize = service.getMaxPostSize();
        return maxPostSize.toString();
    }

    @GET
    @Path("/getForbiddenFileExtensions")
    @ApiOperation(value = "Retrieve the list of forbidden file extensions")
    public List<String> getForbiddenFileExtensions() throws ApplicationException {
        return service.getForbiddenFileExtensions();
    }

    @GET
    @Path("/getAllConfigurations")
    public List<Configuration> getAllConfigurations() {
        return service.getAllConfigurations();
    }

    @POST
    @Path("/addUpdateConfiguration")
    public Configuration addUpdateConfiguration(Configuration configuration) {
        return service.addUpdateConfiguration(configuration);
    }

    @GET
    @Path("/getConfiguration")
    public Configuration getConfiguration(@QueryParam("id") String id) {
        return service.getConfiguration(id);
    }

    @GET
    @Path("/getConfigurationByName")
    public Configuration getConfigurationByName(@QueryParam("name") String name) {
        return service.getConfigurationByName(name);
    }
}
