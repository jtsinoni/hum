package logicole.gateway.services.inventory;

import io.swagger.annotations.Api;
import logicole.common.datamodels.inventory.Audit.AuditStatus;
import logicole.common.datamodels.inventory.Audit.AuditType;
import logicole.common.datamodels.inventory.Audit.InventoryAudit;
import logicole.common.datamodels.inventory.Audit.InventoryAuditCount;
import logicole.common.datamodels.product.Offer;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Audit"})
@ApplicationScoped
@Path("/audit")
public class AuditRestApi extends ExternalRestApi<AuditService> {

    @GET
    @Path("/getInventoryAuditsByInventorySystemId")
    public List<InventoryAudit> getInventoryAuditsByInventorySystemId(@QueryParam("inventorySystemId") String inventorySystemId) {
        return service.getInventoryAuditsByInventorySystemId(inventorySystemId);
    }

    @GET
    @Path("/getCountListByAudit")
    public List<InventoryAuditCount> getCountListByAudit(@QueryParam("auditId") String auditId) {
        return service.getCountListByAudit(auditId);
    }

    @GET
    @Path("/getResearchListByAudit")
    public List<InventoryAuditCount> getResearchListByAudit(@QueryParam("auditId") String auditId) {
        return service.getResearchListByAudit(auditId);
    }

    @GET
    @Path("/getInventoryAuditById")
    public InventoryAudit getInventoryAuditById(@QueryParam("inventoryAuditId") String inventoryAuditId) {
        return service.getInventoryAuditById(inventoryAuditId);
    }

    @GET
    @Path("/getCountListByStorageLocation")
    public List<InventoryAuditCount> getCountListByStorageLocation(@QueryParam("auditId") String auditId, @QueryParam("storageLocationId") String storageLocationId) {
        return service.getCountListByStorageLocation(auditId, storageLocationId);
    }

    @GET
    @Path("/getResearchListByStorageLocation")
    public List<InventoryAuditCount> getResearchListByStorageLocation(@QueryParam("auditId") String auditId, @QueryParam("storageLocationId") String storageLocationId) {
        return service.getResearchListByStorageLocation(auditId, storageLocationId);
    }

    @GET
    @Path("/getFinalizeListByAudit")
    public List<InventoryAuditCount> getFinalizeListByAudit(@QueryParam("auditId") String auditId) {
        return service.getFinalizeListByAudit(auditId);
    }

    @GET
    @Path("/getAuditTypes")
    public List<AuditType> getAuditTypes() {
        return service.getAuditTypes();
    }

    @GET
    @Path("/getAuditStatusList")
    public List<AuditStatus> getAuditStatusList() {
        return service.getAuditStatusList();
    }

    @POST
    @Path("/createSchedule")
    public InventoryAudit createSchedule(InventoryAudit inventoryAudit) {
        return service.createSchedule(inventoryAudit);
    }

    @POST
    @Path("/cancelSchedule")
    public InventoryAudit cancelSchedule(InventoryAudit inventoryAudit) {
        return service.cancelSchedule(inventoryAudit);
    }

    @POST
    @Path("/beginInventory")
    public InventoryAudit beginInventory(InventoryAudit inventoryAudit) {
        return service.beginInventory(inventoryAudit);
    }

    @POST
    @Path("/beginInventoryFromLocationManagement")
    public InventoryAudit beginInventoryFromLocationManagement(InventoryAudit inventoryAudit) {
        return service.beginInventoryFromLocationManagement(inventoryAudit);
    }

    @POST
    @Path("/completeAudit")
    public InventoryAudit completeAudit(InventoryAudit inventoryAudit) {
        return service.completeAudit(inventoryAudit);
    }

    @POST
    @Path("/saveAuditNotificationContacts")
    public InventoryAudit saveAuditNotificationContacts(InventoryAudit inventoryAudit) {
        return service.saveAuditNotificationContacts(inventoryAudit);
    }

    @POST
    @Path("/saveAuditPOCInfo")
    public InventoryAudit saveAuditPOCInfo(InventoryAudit inventoryAudit) {
        return service.saveAuditPOCInfo(inventoryAudit);
    }

    @POST
    @Path("/saveAuditScheduleInfo")
    public InventoryAudit saveAuditScheduleInfo(InventoryAudit inventoryAudit) {
        return service.saveAuditScheduleInfo(inventoryAudit);
    }

    @POST
    @Path("/saveAuditScopeInfo")
    public InventoryAudit saveAuditScopeInfo(InventoryAudit inventoryAudit) {
        return service.saveAuditScopeInfo(inventoryAudit);
    }

    @POST
    @Path("/saveCountListByAudit")
    public List<InventoryAuditCount> saveCountListByAudit(@QueryParam("auditId") String auditId, List<InventoryAuditCount> inventoryAuditCount) {
        return service.saveCountListByAudit(auditId, inventoryAuditCount);
    }

    @POST
    @Path("/saveResearchListByAudit")
    public List<InventoryAuditCount> saveResearchListByAudit(@QueryParam("auditId") String auditId, List<InventoryAuditCount> inventoryAuditCount) {
        return service.saveResearchListByAudit(auditId, inventoryAuditCount);
    }

    @POST
    @Path("/submitResearchListByAudit")
    public InventoryAudit submitResearchListByAudit(@QueryParam("auditId") String auditId, List<InventoryAuditCount> inventoryAuditCount) {
        return service.submitResearchListByAudit(auditId, inventoryAuditCount);
    }

    @POST
    @Path("/addItemToCountList")
    public List<InventoryAuditCount> addItemToCountList(@QueryParam("auditId") String auditId, Offer offer) {
        return service.addItemToCountList(auditId, offer);
    }

    @POST
    @Path("/deleteAuditCount")
    public void deleteAuditCount(InventoryAuditCount inventoryAuditCount) {
        service.deleteAuditCount(inventoryAuditCount);
    }

    @POST
    @Path("/transferAuditCount")
    public List<InventoryAuditCount> transferAuditCount(InventoryAuditCount inventoryAuditCount) {
        return service.transferAuditCount(inventoryAuditCount);
    }




}
