package logicole.gateway.services.user;

import logicole.apis.user.IPermissionMicroserviceApi;
import logicole.common.cache.EndpointCache;
import logicole.common.datamodels.featureflag.FeatureFlagRef;
import logicole.common.datamodels.user.*;
import logicole.common.general.exception.ObjectNotFoundException;
import logicole.common.general.util.JSONUtil;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class PermissionService extends BaseGatewayService<IPermissionMicroserviceApi> {

    @Inject
    RoleService roleService;

    @Inject
    private JSONUtil jsonUtil;

    @Inject
    private EndpointCache endpointCache;

    public PermissionService() {
        super("Permission");
    }

    public List<Permission> getFullPermissions() {
        return microservice.getFullPermissions();
    }

    public Permission getPermissionById(@QueryParam("id") String id) {
        return microservice.getPermissionById(id);
    }

    public Permission createPermission(Permission permission) {
        setUpdatedBy(permission);
        return microservice.createPermission(permission);
    }

    public Permission savePermissionEndpoints(Permission permission) throws ObjectNotFoundException {
        setUpdatedBy(permission);
        return microservice.savePermissionEndpoints(permission);
    }

    public Permission savePermissionStates(Permission permission) throws ObjectNotFoundException {
        setUpdatedBy(permission);
        return microservice.savePermissionStates(permission);
    }

    public Permission savePermissionElements(Permission permission) throws ObjectNotFoundException {
        setUpdatedBy(permission);
        return microservice.savePermissionElements(permission);
    }

    public Permission savePermissionReports(Permission permission) throws ObjectNotFoundException {
        setUpdatedBy(permission);
        return microservice.savePermissionReports(permission);
    }

    public Permission savePermission(Permission permission) throws ObjectNotFoundException {
        setUpdatedBy(permission);
        return microservice.savePermission(permission);
    }

    public List<String> getPermissionNamesByElement(@QueryParam("elementName") String elementName) {
        return microservice.getPermissionNamesByElement(elementName);
    }

    public List<String> getPermissionNamesByEndpoint(@QueryParam("endpointName") String endpointName) {
        return microservice.getPermissionNamesByEndpoint(endpointName);
    }

    public List<String> getPermissionNamesByState(@QueryParam("stateName") String stateName) {
        return microservice.getPermissionNamesByState(stateName);
    }

    public List<String> getPermissionNamesByReport(@QueryParam("reportName") String reportName) {
        return microservice.getPermissionNamesByReport(reportName);
    }

    // Elements
    public List<Element> getAllElements() {
        return microservice.getAllElements();
    }

    public Boolean doesElementExistByName(@QueryParam("elementName") String elementName) {
        return microservice.doesElementExistByName(elementName);
    }

    public Element saveElement(Element element) {
        return microservice.saveElement(element);
    }

    public Element createElement(Element element) {
        return microservice.createElement(element);
    }

    public Boolean deleteElement(@NotNull @QueryParam("id") String id) {
        return microservice.deleteElement(id);
    }

    // Endpoints
    public List<Endpoint> getAllEndpoints() {
        return microservice.getAllEndpoints();
    }

    public List<Endpoint> getAllEndpointsNotCached() {
        return microservice.getAllEndpointsNotCached();
    }

    public Boolean doesEndpointExistByBusinessMethod(@QueryParam("businessMethod") String businessMethod) {
        return microservice.doesEndpointExistByBusinessMethod(businessMethod);
    }

    public Endpoint createEndpoint(Endpoint endpoint) throws IOException {
        Endpoint response = microservice.createEndpoint(endpoint);
        endpointCache.putObject(response.getId(), response);
        return response;
    }

    public Endpoint saveEndpoint(Endpoint endpoint) throws IOException {
        Endpoint response = microservice.saveEndpoint(endpoint);
        endpointCache.putObject(response.getId(), response);
        return response;
    }

    public Boolean deleteEndpoint(@NotNull @QueryParam("id") String id) {
        Boolean val = microservice.deleteEndpoint(id);
        endpointCache.remove(id);
        return val;

    }

    // States
    public List<State> getAllStates() {
        return microservice.getAllStates();
    }

    public Boolean doesStateExistByName(@QueryParam("stateName") String stateName) {
        return microservice.doesStateExistByName(stateName);
    }

    public State saveState(State state) {
        return microservice.saveState(state);
    }

    public Boolean deleteState(@NotNull @QueryParam("id") String id) {
        return microservice.deleteState(id);
    }

    public State createState(State state) throws ObjectNotFoundException {
        return microservice.createState(state);
    }

    // Reports
    public List<BiReport> getAllReports() {
        return microservice.getAllReports();
    }

    public Boolean doesReportExistByName(@QueryParam("reportName") String reportName) {
        return microservice.doesReportExistByName(reportName);
    }

    public BiReport saveReport(BiReport biReport) {
        return microservice.saveReport(biReport);
    }

    public Boolean deleteReport(@NotNull @QueryParam("id") String id) {
        return microservice.deleteReport(id);
    }

    public BiReport createReport(BiReport report) {
        return microservice.createReport(report);
    }

    public List<BiReport> getReportsByReportId(String reportId) {
        return microservice.getReportsByReportId(reportId);
    }

    // Role
    public List<FunctionalArea> getRoleFunctionalAreaConfigs() {
        return roleService.getRoleFunctionalAreaConfigs();
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    private void setUpdatedBy(Permission permission) {
        CurrentUser currentUser = currentUserBT.getCurrentUser();
        permission.updatedBy = currentUser.profile.getFullName();
    }

    public Permission getPermission(@QueryParam("permissionId") String permissionId) {
        return microservice.getPermission(permissionId);
    }

    public List<Permission> getPermissionsForState(String id) {
        return microservice.getPermissionsForState(id);
    }

    public List<Permission> getPermissionsForElement(String id) {
        return microservice.getPermissionsForElement(id);
    }

    public List<Permission> getPermissionsForEndpoint(String id) {
        return microservice.getPermissionsForEndpoint(id);
    }

    public List<Permission> getPermissionsForReport(String id) {
        return microservice.getPermissionsForReport(id);
    }


    public BiReport addReportFeatureFlag(BiReport report) {
        return microservice.addReportFeatureFlag(report);
    }

    public void removeReportFeatureFlags(FeatureFlagRef featureFlagRef) {
        microservice.removeReportFeatureFlags(featureFlagRef);
    }

    public BiReport removeReportFeatureFlag(BiReport report) {
        return microservice.removeReportFeatureFlag(report);
    }

    public Boolean deletePermission(@NotNull @QueryParam("id") String id) {
        return microservice.deletePermission(id);
    }

    public void refreshEndpointCache() {
        loadCache();
    }

    public void loadCache() {
        List<Endpoint> endpoints = microservice.getAllEndpoints();
        for (Endpoint endpoint : endpoints) {
            String endpointString = null;
            try {
                endpointString = jsonUtil.serialize(endpoint);
            } catch (IOException ioe) {
                logger.warn("could not serialize endpoint - " + endpoint.businessMethod);
            }
            if (endpoint.businessMethod != null && endpointString != null) {
                endpointCache.putImmortalObject(endpoint.businessMethod, endpointString);
            }
        }
    }

    public void updateReportFeatureFlags(FeatureFlagRef featureFlagRef) {
        microservice.updateReportFeatureFlags(featureFlagRef);
    }

    public List<String> getRoleNamesRelatedToPermission(String permId) {
        List<String> roleNames = new ArrayList<>();
        List<Role> roles = roleService.getRolesForPermission(permId);
        for (Role role : roles) {
            roleNames.add(role.name);
        }
        return roleNames;
    }

    public Boolean deletePermissionById(String id) {
        Boolean wasRemoved = microservice.deletePermission(id);
        if(wasRemoved != null && wasRemoved){
            wasRemoved = roleService.removePermissionFromRoles(id);
        }
        return wasRemoved;
    }
}
