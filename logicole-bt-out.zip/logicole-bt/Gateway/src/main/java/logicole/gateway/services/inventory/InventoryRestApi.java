package logicole.gateway.services.inventory;

import io.swagger.annotations.*;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.assemblage.Assemblage;
import logicole.common.datamodels.delivery.DueOut;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.inventory.*;
import logicole.common.datamodels.inventory.Audit.InventoryAuditCount;
import logicole.common.datamodels.product.Offer;
import logicole.common.datamodels.receipt.Receipt;
import logicole.common.datamodels.inventory.PutAway;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.abi.item.Item;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Api(tags = {"Inventory"})
@ApplicationScoped
@Path("/inventory")
public class InventoryRestApi extends ExternalRestApi<InventoryService> {

    @Inject
    private MultiPartFormUtil uploadUtil;

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }


    @GET
    @Path("/getInventoryRecordById")
    public InventoryRecord getInventoryRecordById(@QueryParam("inventoryRecordId") String inventoryRecordId) {
        return service.getInventoryRecordById(inventoryRecordId);
    }

    @GET
    @Path("/getInventoryRecordsByOrgId")
    public List<InventoryRecord> getInventoryRecordsByOrgId(@QueryParam("orgId") String orgId) {
        return service.getInventoryRecordsByOrgId(orgId);
    }


    @GET
    @Path("/getInventoryLocationsByProductAndOwner")
    public List<StorageLocationRef> getInventoryLocationsByProductAndOwner(@QueryParam("enterpriseProductId") String enterpriseProductId,
                                                                           @QueryParam("organizationId") String organizationId) {
        return service.getInventoryLocationsByProductAndOwner(enterpriseProductId, organizationId);
    }


    @GET
    @Path("/getInventoryRecordsByLocation")
    public List<InventoryRecord> getInventoryRecordsByLocation(@QueryParam("locationId") String locationId) {
        return service.getInventoryRecordsByLocation(locationId);
    }

    @GET
    @Path("/getProductAvailableQuantityForResale")
    public ProductAvailableQuantity getProductAvailableQuantityForResale(@QueryParam("currentOrgId") String currentNodeId,
                                                                         @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.getProductAvailableQuantityForResale(currentNodeId, enterpriseProductIdentifier);
    }

    @GET
    @Path("/getProductsAvailableQuantityForResale")
    public List<ProductAvailableQuantity> getProductsAvailableQuantityForResale(@QueryParam("currentOrgId") String currentNodeId,
                                                                                @QueryParam("enterpriseProductIdentifiers") List<String> enterpriseProductIdentifiers) {
        return service.getProductsAvailableQuantityForResale(currentNodeId, enterpriseProductIdentifiers);
    }


    @GET
    @Path("/getStratifications")
    public List<Stratification> getStratifications() {
        return service.getStratifications();
    }

    @GET
    @Path("/getReplenishmentList")
    public List<ReplenishmentRecord> getReplenishmentList() {
        return service.getReplenishmentList();
    }

    @POST
    @Path("/updatePickRequest")
    public PickRequest updatePickRequest(PickRequest pickRequest) {
        return service.updatePickRequest(pickRequest);
    }

    @POST
    @Path("/createPickRequest")
    public PickRequest createPickRequest(PickRequest pickRequest) {
        return service.createPickRequest(pickRequest);
    }

    @POST
    @Path("/savePicklistNote")
    public PickList savePicklistNote(@QueryParam("picklistId") String picklistId, Note note) {
        return service.savePicklistNote(picklistId, note);
    }

    @POST
    @Path("/savePicklistNotes")
    public PickList savePicklistNotes(@QueryParam("picklistId") String picklistId, List<Note> notes) {
        return service.savePicklistNotes(picklistId, notes);
    }

    @POST
    @Path("/removePicklistNote")
    public PickList removePicklistNote(@QueryParam("picklistId") String picklistId,
                                                     @QueryParam("noteId") String noteId) {
        return service.removePicklistNote(picklistId, noteId);
    }

    @POST
    @Path("/removePicklistNotes")
    public PickList removePicklistNotes(@QueryParam("picklistId") String picklistId,
                                                      List<String> noteIds) {
        return service.removePicklistNotes(picklistId, noteIds);
    }

    @POST
    @Path("/saveInventoryRecordInfo")
    public InventoryRecord saveInventoryRecordInfo(InventoryRecord record) {
        return service.saveInventoryRecordInfo(record);
    }

    @POST
    @Path("/saveItemLocationInfo")
    public InventoryRecord saveItemLocationInfo(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                                ItemLocation itemLocation) {
        return service.saveItemLocationInfo(inventoryRecordId, itemLocation);
    }

    @POST
    @Path("/addNewItemLocation")
    public InventoryRecord addNewItemLocation(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                              ItemLocation itemLoc) {
        return service.addNewItemLocation(inventoryRecordId, itemLoc);
    }

    @POST
    @Path("/setItemLocationToPrimary")
    public InventoryRecord setItemLocationToPrimarysetItemLocationToPrimary(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                                                            @QueryParam("itemLocationId") String itemLocationId) {
        return service.setItemLocationToPrimary(inventoryRecordId, itemLocationId);
    }

    @POST
    @Path("/removeItemLocation")
    public InventoryRecord removeItemLocation(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                              @QueryParam("itemLocationId") String itemLocationId) {
        return service.removeItemLocation(inventoryRecordId, itemLocationId);
    }

    @POST
    @Path("/createItemStorage")
    public InventoryRecord createItemStorage(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                             @QueryParam("itemLocationId") String itemLocationId,
                                             ItemStorage itemStorage) {
        return service.createItemStorage(inventoryRecordId, itemLocationId, itemStorage);
    }

    @POST
    @Path("/deleteItemStorage")
    public InventoryRecord deleteItemStorage(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                             @QueryParam("itemLocationId") String itemLocationId,
                                             @QueryParam("itemStorageId") String itemStorageId) {
        return service.deleteItemStorage(inventoryRecordId, itemLocationId, itemStorageId);
    }

    @POST
    @Path("/updateItemStorage")
    public InventoryRecord updateItemStorage(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                             @QueryParam("itemLocationId") String itemLocationId,
                                             ItemStorage itemStorage) {
        return service.updateItemStorage(inventoryRecordId, itemLocationId, itemStorage);
    }

    @POST
    @Path("/createInventoryFromAudit")
    public InventoryRecord createInventoryFromAudit(@QueryParam("currentNodeId") String currentNodeId,
                                                    InventoryAuditCount auditCount) {
        return service.createInventoryFromAudit(currentNodeId, auditCount);

    }

    @POST
    @Path("/createInventoryFromCatalog")
    public InventoryRecord createInventoryFromCatalog(@QueryParam("currentNodeId") String currentNodeId,
                                                      Offer offerRecord) {
        return service.createInventoryFromCatalog(currentNodeId, offerRecord);

    }

    @POST
    @Path("/createInventoryFromReceipt")
    public InventoryRecord createInventoryFromReceipt(Receipt receipt) {
        return service.createInventoryFromReceipt(receipt);
    }

    @POST
    @Path("/createInventoryFromReceipts")
    public List<InventoryRecord> createInventoryFromReceipts(List<Receipt> receipts) {
        return service.createInventoryFromReceipts(receipts);
    }


    @GET
    @Path("/getStratificationCounts")
    public Integer getStratificationCounts(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                           @QueryParam("itemLocationId") String itemLocationId,
                                           @QueryParam("condition") String condition) {
        return service.getStratificationCounts(inventoryRecordId, itemLocationId, condition);
    }

    @GET
    @Path("/getRecordsForMultipleOrgs")
    public List<InventoryRecord> getRecordsForMultipleOrgs(@QueryParam("orgIds") List<String> orgIds) {
        return service.getRecordsForMultipleOrgs(orgIds);
    }

    @GET
    @Path("/getAllInventoryRecords")
    public List<InventoryRecord> getAllInventoryRecords() {
        return service.getAllInventoryRecords();
    }

    @GET
    @Path("/getInventoryRecordsByProduct")
    public List<InventoryRecord> getInventoryRecordsByProduct(@QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.getInventoryRecordsByProduct(enterpriseProductIdentifier);
    }

    @POST
    @Path("/setInventoryRecordStatus")
    public InventoryRecord setInventoryRecordStatus(@QueryParam("activeStatus") boolean activeStatus, InventoryRecord record) {
        return service.setInventoryRecordStatus(activeStatus, record);
    }

    @POST
    @Path("/deleteInventoryRecord")
    public Integer deleteInventoryRecord(@QueryParam("inventoryRecordId") String inventoryRecordId) {
        return service.deleteInventoryRecord(inventoryRecordId);
    }


    @GET
    @Path("/getRecordByOwnerAndProduct")
    public InventoryRecord getRecordByOwnerAndProduct(@QueryParam("currentNodeId") String currentNodeId,
                                                      @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.getRecordByOwnerAndProduct(currentNodeId, enterpriseProductIdentifier);
    }

    @GET
    @Path("getPutAwayRequestbyInventoryOwner")
    public List<PutAway> getPutAwayRequestbyInventoryOwner(@QueryParam("inventoryOwnerId") String inventoryOwnerId) {
        return service.getPutAwayRequestbyInventoryOwner(inventoryOwnerId);
    }


    @POST
    @Path("/saveInventoryRecordNote")
    public InventoryRecord saveInventoryRecordNote(@QueryParam("inventoryRecordId") String inventoryRecordId, Note note) {
        return service.saveInventoryRecordNote(inventoryRecordId, note);
    }

    @POST
    @Path("/saveInventoryRecordNotes")
    public InventoryRecord saveInventoryRecordNotes(@QueryParam("inventoryRecordId") String inventoryRecordId, List<Note> notes) {
        return service.saveInventoryRecordNotes(inventoryRecordId, notes);
    }

    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "Select a file to upload",
                    dataType = "java.io.File", name = "file",
                    paramType = "formData", required = true)
    })
    public FileManager uploadFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        byte[] content;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            InputStream inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new ApplicationException("Unable to upload file " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxInventoryRecordAttachmentSize();
        if (content.length > maxUploadSize) {
            throw new ApplicationException("File size exceeds max size of " + maxUploadSize + " bytes");
        }

        return service.uploadFile(content, uploadedFileName);
    }

    @POST
    @Path("/saveInventoryRecordAttachment")
    public Attachment saveInventoryRecordAttachment(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                                         Attachment attachmentToSave)
            throws IOException {
        return service.saveInventoryRecordAttachment(inventoryRecordId, attachmentToSave);
    }

    @POST
    @Path("/removeInventoryRecordNote")
    public InventoryRecord removeInventoryRecordNote(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                                     @QueryParam("noteId") String noteId) {
        return service.removeInventoryRecordNote(inventoryRecordId, noteId);
    }

    @POST
    @Path("/removeInventoryRecordNotes")
    public InventoryRecord removeInventoryRecordNotes(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                                      List<String> noteIds) {
        return service.removeInventoryRecordNotes(inventoryRecordId, noteIds);
    }

    @POST
    @Path("/removeInventoryRecordAttachment")
    public InventoryRecord removeInventoryRecordAttachment(@QueryParam("inventoryRecordId") String inventoryRecordId,
                                                           @QueryParam("fileId") String fileId)
            throws IOException {
        return service.removeInventoryRecordAttachment(inventoryRecordId, fileId);
    }

    @GET
    @Path("/getMaxInventoryRecordAttachmentSize")
    public Integer getMaxInventoryRecordAttachmentSize() {
        return service.getMaxInventoryRecordAttachmentSize();
    }

    @GET
    @Path("/findInventoryRecords")
    public List<InventoryRecord> findInventoryRecords(@QueryParam("searchString") String searchString,
                                                      @QueryParam("itemStatus") String itemStatus) {
        return service.findInventoryRecords(searchString, itemStatus);
    }

   @POST
   @Path("/getInventoryRecordsSearchResults")
   public SearchResult<InventoryRecord> getInventoryRecordsSearchResults(@QueryParam("itemStatus") String itemStatus,
                                                                         @QueryParam("nodeId") String nodeId,
                                                             SearchInput searchInput) {
       return service.getInventoryRecordsSearchResults(itemStatus, nodeId, searchInput);
   }

    @POST
    @Path("/createInventoryRecord")
    public InventoryRecord createInventoryRecord(String customerItemSourcingId) {
        return service.createInventoryRecord(customerItemSourcingId);
    }

    @GET
    @Path("/getItemById")
    public Item getItemById(@QueryParam("itemId") String itemId) {
        return service.getItemById(itemId);
    }

    @POST
    @Path("/saveInventoryRecordForAssemblage")
    public InventoryRecord saveInventoryRecordForAssemblage(InventoryRecord inventoryRecord) {
        return service.saveInventoryRecordForAssemblage(inventoryRecord);
    }

    @POST
    @Path("/transferInventoryRecordForAssemblage")
    public InventoryRecord transferInventoryRecordForAssemblage(InventoryRecord destinationInventoryRecord) {
        return service.transferInventoryRecordForAssemblage(destinationInventoryRecord);
    }

    @POST
    @Path("/updateInventoryRecords")
    public Integer updateInventoryRecords(List<InventoryRecord> inventoryRecords) {
        return service.updateInventoryRecords(inventoryRecords);
    }

    @POST
    @Path("/deleteInventoryRecordForAssemblage")
    public Integer deleteInventoryRecordForAssemblage(InventoryRecord inventoryRecord) {
        return service.deleteInventoryRecordForAssemblage(inventoryRecord);
    }

    @GET
    @Path("/getInventoryRecordByAssemblageAndItem")
    public InventoryRecord getInventoryRecordByAssemblageAndItem(@QueryParam("assemblageId") String assemblageId, @QueryParam("itemId") String itemId) {
        return service.getInventoryRecordByAssemblageAndItem(assemblageId, itemId);
    }

    @POST
    @Path("/getInventoryRecordsForAssemblages")
    public List<InventoryRecord> getInventoryRecordsForAssemblages(List<Assemblage> assemblages) {
        return service.getInventoryRecordsForAssemblages(assemblages);
    }

    @GET
    @Path("/getItemStockType")
    public String getItemStockType
           (@QueryParam("currentNodeId") String currentNodeId,
           @QueryParam("enterpriseProductIdentifier") String enterpriseProductIdentifier) {
        return service.getItemStockType(currentNodeId, enterpriseProductIdentifier);
    }

    @POST
    @Path("/createDueOut")
    public List<DueOut> createDueOut(List<ReplenishmentRecordDTO> replenishmentRecordDTOS) {
        return service.createDueOut(replenishmentRecordDTOS);
    }

    @POST
    @Path("/getCustomerReplenishmentSearchResults")
    public SearchResult<InventoryRecordDTO> getCustomerReplenishmentSearchResults(@QueryParam("nodeId") String nodeId,
                                                                                  @QueryParam("itemType") String itemType,
                                                                                   SearchInput searchInput) {
        return service.getCustomerReplenishmentSearchResults(nodeId, itemType, searchInput);
    }

}

