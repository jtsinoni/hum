package logicole.gateway.services.system;

import logicole.apis.system.IApplicationHistoryMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class ApplicationHistoryMicroserviceClient extends MicroserviceClient<IApplicationHistoryMicroserviceApi> {
    public ApplicationHistoryMicroserviceClient(){
        super(IApplicationHistoryMicroserviceApi.class, "logicole-system");
    }

    @Produces
    public IApplicationHistoryMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
