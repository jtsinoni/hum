package logicole.gateway.services.catalog;

import logicole.apis.catalog.IEnterpriseSourcingMicroserviceApi;
import logicole.common.datamodels.abi.PackageUnit;
import logicole.common.datamodels.catalog.EnterpriseSourceSummary;
import logicole.common.datamodels.catalog.EnterpriseSourcing;
import logicole.common.datamodels.general.search.SearchCriterion;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountDTO;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.abi.referencedata.PackageUnitService;
import logicole.gateway.services.order.BuyerService;
import logicole.gateway.services.sale.SellerService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@ApplicationScoped
public class EnterpriseSourcingService extends BaseGatewayService<IEnterpriseSourcingMicroserviceApi> {
    public static final String SELLER = "seller";
    public static final String CUSTOMER_NOT_FOUND_EXCEPTION = "No Customer is associated to this profile";
    public static final String SUPPLIER_NOT_FOUND_EXCEPTION = "No Authorized Supplier is associated to this customer";

    @Inject
    private BuyerService buyerService;
    @Inject
    private ItemService itemService;
    @Inject
    private PackageUnitService packageUnitService;
    @Inject
    private SellerService sellerService;

    public EnterpriseSourcingService() {
        super("Catalog");
    }

    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public EnterpriseSourcing getById(String id) {
        return microservice.getById(id);
    }

    public List<EnterpriseSourcing> findByIds(List<String> ids) {
        return microservice.findByIds(ids);
    }

    public EnterpriseSourcing saveEnterpriseSourcing(EnterpriseSourcing enterpriseSourcing) {
        if (StringUtil.isEmptyOrNull(enterpriseSourcing.itemRef.shortItemDescription)) {
            enterpriseSourcing.itemRef.shortItemDescription = itemService.getItemById(enterpriseSourcing.itemRef.id).shortItemDescription;
        }
        if (StringUtil.isEmptyOrNull(enterpriseSourcing.itemRef.longItemDescription)) {
            enterpriseSourcing.itemRef.longItemDescription = itemService.getItemById(enterpriseSourcing.itemRef.id).longItemDescription;
        }
        if (StringUtil.isEmptyOrNull(enterpriseSourcing.packageUnitDescription)) {
            enterpriseSourcing.packageUnitDescription = itemService.getItemById(enterpriseSourcing.itemRef.id).packagingDescription;
        }
        return microservice.saveEnterpriseSourcing(enterpriseSourcing);
    }

    public SearchResult<EnterpriseSourceSummary> getEnterpriseSourcingSearchResults(SearchInput searchInput) {
        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if(Objects.isNull(buyer)){
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }
        List<BuyerSellerAccountDTO> buyerSellerAccountDTOList = this.sellerService.getBuyerSellerAccountListByBuyerId(buyer.getId());
        if(Objects.isNull(buyerSellerAccountDTOList) || buyerSellerAccountDTOList.isEmpty()){
            throw new ApplicationException(SUPPLIER_NOT_FOUND_EXCEPTION);
        }

        List<String> sellerIds = new ArrayList<>();
        buyerSellerAccountDTOList.forEach(buyerSellerAccountDTO -> sellerIds.add(buyerSellerAccountDTO.sellerId));
        SearchCriterion sellerSearchCriterion = new SearchCriterion();
        sellerSearchCriterion.propName = SELLER;
        sellerSearchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
        sellerSearchCriterion.propValues = sellerIds.toArray();
        searchInput.searchCriteria.add(sellerSearchCriterion);
        return microservice.getEnterpriseSourcingSearchResults(searchInput);
    }

    public List<EnterpriseSourcing> getEnterpriseSourcingByItemId(String itemId) {
        return microservice.getEnterpriseSourcingByItemId(itemId);
    }

    public List<PackageUnit> getPackageUnitList() {
        return packageUnitService.getPackageUnitList();
    }
}
