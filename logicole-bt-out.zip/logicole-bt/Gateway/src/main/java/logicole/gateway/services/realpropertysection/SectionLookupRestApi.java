package logicole.gateway.services.realpropertysection;

import io.swagger.annotations.Api;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtype;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeHierarchy;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeRef;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeUnit;
import logicole.common.datamodels.realpropertysection.lookupdata.ComponentSubtypeUnitRef;
import logicole.common.datamodels.realpropertysection.lookupdata.ESectionConditionType;
import logicole.common.datamodels.realpropertysection.lookupdata.PaintType;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"RealPropertySection"})
@ApplicationScoped
@Path("/sectionlookup")
public class SectionLookupRestApi extends ExternalRestApi<SectionLookupService> {

    @GET
    @Path("/getAllPaintTypes")
    public List<PaintType> getAllPaintTypes() { return service.getAllPaintTypes(); }

    @GET
    @Path("/getAllSectionConditionTypes")
    public List<ESectionConditionType> getAllSectionConditionTypes() {
        return service.getAllSectionConditionTypes();
    }

    @GET
    @Path("/getAllComponentSubtypes")
    public List<ComponentSubtype> getAllComponentSubtypes() {
        return service.getAllComponentSubtypes();
    }

    @GET
    @Path("/getAllComponentSubtypesRefs")
    public List<ComponentSubtypeRef> getAllComponentSubtypesRefs() {
        return service.getAllComponentSubtypesRefs();
    }

    @GET
    @Path("/getAllComponentSubtypeUnits")
    public List<ComponentSubtypeUnit> getAllComponentSubtypeUnits() { return service.getAllComponentSubtypeUnits(); }

    @GET
    @Path("/getAllComponentSubtypeUnitRefs")
    public List<ComponentSubtypeUnitRef> getAllComponentSubtypeUnitRefs() { return service.getAllComponentSubtypeUnitRefs(); }

    @POST
    @Path("/createNewPaintType")
    public PaintType createNewPaintType(PaintType paintType) {
        return service.createNewPaintType(paintType);
    }

    @POST
    @Path("/createComponentSubtype")
    public ComponentSubtype createComponentSubtype(ComponentSubtype componentSubtype) {
        return service.createComponentSubtype(componentSubtype);
    }

    @POST
    @Path("/createComponentSubtypeUnit")
    public ComponentSubtypeUnit createComponentSubtypeUnit(ComponentSubtypeUnit componentSubtypeUnit) {
        return service.createComponentSubtypeUnit(componentSubtypeUnit);
    }

    @POST
    @Path("/updatePaintType")
    public PaintType updatePaintType(PaintType paintType) {
        return service.updatePaintType(paintType);
    }

    @POST
    @Path("/updateComponentSubtype")
    public ComponentSubtype updateComponentSubtype(ComponentSubtype componentSubtype) {
        return service.updateComponentSubtype(componentSubtype);
    }

    @POST
    @Path("/updateComponentSubtypeUnit")
    public ComponentSubtypeUnit updateComponentSubtypeUnit(ComponentSubtypeUnit componentSubtypeUnit) {
        return service.updateComponentSubtypeUnit(componentSubtypeUnit);
    }

    @GET
    @Path("/deletePaintType")
    public boolean deletePaintType(@QueryParam("id") String id) {
        return service.deletePaintType(id);
    }

    @GET
    @Path("/deleteComponentSubtype")
    public boolean deleteComponentSubtype(@QueryParam("id") String id) {
        return service.deleteComponentSubtype(id);
    }

    @GET
    @Path("/deleteComponentSubtypeUnit")
    public boolean deleteComponentSubtypeUnit(@QueryParam("id") String id) {
        return service.deleteComponentSubtypeUnit(id);
    }

    @GET
    @Path("/getComponentSubtypeHierarchies")
    public List<ComponentSubtypeHierarchy> getComponentSubtypeHierarchies() {
        return service.getComponentSubtypeHierarchies();
    }

    @GET
    @Path("/getComponentSubtypeHierarchyById")
    public ComponentSubtypeHierarchy getComponentSubtypeHierarchyById(@QueryParam("id") String id) {
        return service.getComponentSubtypeHierarchyById(id);
    }

    @POST
    @Path("/createComponentSubtypeHierarchy")
    public ComponentSubtypeHierarchy createComponentSubtypeHierarchy(ComponentSubtypeHierarchy componentSubtypeHierarchy) {
        return service.createComponentSubtypeHierarchy(componentSubtypeHierarchy);
    }

    @POST
    @Path("/updateComponentSubtypeHierarchy")
    public ComponentSubtypeHierarchy updateComponentSubtypeHierarchy(ComponentSubtypeHierarchy componentSubtypeHierarchy) {
        return service.updateComponentSubtypeHierarchy(componentSubtypeHierarchy);
    }

    @GET
    @Path("/deleteComponentSubtypeHierarchy")
    public boolean deleteComponentSubtypeHierarchy(@QueryParam("id") String id) {
        return service.deleteComponentSubtypeHierarchy(id);
    }

    @GET
    @Path("/getAllSectionInspectionTypes")
    public List<String> getAllSectionInspectionTypes() {
        return service.getAllSectionInspectionTypes();
    }
}
