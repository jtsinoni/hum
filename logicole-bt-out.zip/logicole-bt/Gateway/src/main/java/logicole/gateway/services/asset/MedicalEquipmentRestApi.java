package logicole.gateway.services.asset;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.abi.item.ItemRef;
import logicole.common.datamodels.asset.businesscontact.BusinessContactRef;
import logicole.common.datamodels.asset.classification.ManufacturerRef;
import logicole.common.datamodels.asset.classification.SoftwareNomenclatureRef;
import logicole.common.datamodels.asset.management.AccountingStatus;
import logicole.common.datamodels.asset.management.AcquisitionInformation;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.asset.management.AssetBusinessContact;
import logicole.common.datamodels.asset.management.AssetCostSummary;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.DurableItemRenewalInformation;
import logicole.common.datamodels.asset.management.DurableItemsOnLoan;
import logicole.common.datamodels.asset.management.EquipmentItemRenewalInformation;
import logicole.common.datamodels.asset.management.LocationInformation;
import logicole.common.datamodels.asset.management.MEEquipmentType;
import logicole.common.datamodels.asset.management.MELossRequest;
import logicole.common.datamodels.asset.management.MedicalEquipmentGainDTO;
import logicole.common.datamodels.asset.management.MedicalEquipmentSearchResults;
import logicole.common.datamodels.asset.management.METransferRequest;
import logicole.common.datamodels.asset.management.MedicalEquipmentAssetLoan;
import logicole.common.datamodels.asset.management.MedicalEquipmentAssetLoanSearchResults;
import logicole.common.datamodels.asset.management.MedicalEquipmentItemsOnLoan;
import logicole.common.datamodels.asset.management.MedicalEquipmentSoftware;
import logicole.common.datamodels.asset.management.OperatingSystemRef;
import logicole.common.datamodels.asset.management.Ownership;
import logicole.common.datamodels.asset.management.SoftwareCompanyRef;
import logicole.common.datamodels.asset.management.TransactionReasonRef;
import logicole.common.datamodels.asset.management.dropDownFeeders.MEConditionEntry;
import logicole.common.datamodels.catalog.CatalogRef;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.finance.referencedata.CommodityCodeRef;
import logicole.common.datamodels.finance.referencedata.FundCodeRef;
import logicole.common.datamodels.finance.referencedata.SalesCodeType;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.realproperty.SiteRef;
import logicole.common.datamodels.realproperty.facility.FacilitySummary;
import logicole.common.datamodels.space.Floor;
import logicole.common.datamodels.space.Space;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Api(tags = {"MedicalEquipment"})
@ApplicationScoped
@Path("/medicalEquipment")
public class MedicalEquipmentRestApi extends ExternalRestApi<MedicalEquipmentService> {
    @Inject
    private MultiPartFormUtil uploadUtil;

    @POST
    @Path("/addDurableItemsToLoan")
    public MedicalEquipmentAssetLoan addDurableItemsToLoan(@QueryParam("id") String loanId, List<DurableItemsOnLoan> durableItemsList) {
        service.addDurableItemsToLoan(loanId, durableItemsList);
        return getMedicalEquipmentAssetLoanRecordById(loanId);
    }

    @POST
    @Path("/addEquipmentItemsToLoan")
    public MedicalEquipmentAssetLoan addEquipmentItemsToLoan(@QueryParam("id") String loanId, List<MedicalEquipmentItemsOnLoan> equipmentItemsList) {
        service.addEquipmentItemsToLoan(loanId, equipmentItemsList);
        return getMedicalEquipmentAssetLoanRecordById(loanId);
    }

    @POST
    @Path("/addEquipmentNote")
    public Asset addEquipmentNote(@QueryParam("id") String assetId, Note note) {
        service.addEquipmentNote(assetId, note);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/addMedicalEquipmentAssetLoanNote")
    public MedicalEquipmentAssetLoan addMedicalEquipmentAssetLoanNote(@QueryParam("id") String loanId, Note note) {
        service.addMedicalEquipmentAssetLoanNote(loanId, note);
        return service.getMedicalEquipmentAssetLoanRecordById(loanId);
    }

    @GET
    @Path("/findEquipmentItems")
    public List<ItemRef> findEquipmentItems(@QueryParam("searchString") String searchString) {
        return service.findEquipmentItems(searchString);
    }

    @GET
    @Path("/getAccountingStatus")
    public List<AccountingStatus> getAccountingStatus() { return service.getAccountingStatus(); }

    @GET
    @Path("/getCurrentUser")
    public CurrentUser getCurrentUser() {
        return service.getCurrentUser();
    }

    @GET
    @Path("/getCommodityRefsByCommodityTypeAndService")
    public List<CommodityCodeRef> getCommodityRefsByCommodityTypeAndService(
            @QueryParam("commodityType") String commodityType) {
        return service.getCommodityRefsByCommodityTypeAndService(commodityType);
    }

    @GET
    @Path("/getFundCodeRefsByService")
    public List<FundCodeRef> getFundCodeRefsByService() {
        return service.getFundCodeRefsByService();
    }

    @GET
    @Path("/getFacilitiesBySiteUid")
    public List<FacilitySummary> getFacilitiesBySiteUid(@QueryParam("rpsuid") String rpsuid) {
        return service.getFacilitiesBySiteUid(rpsuid);
    }

    @GET
    @Path("/getManufacturersBySiteAndAgency")
    public List<ManufacturerRef> getManufacturersBySiteAndAgency() {
        return service.getManufacturersBySiteAndAgency();
    }

    @POST
    @Path("/getMedicalEquipmentLoanSearchResults")
    public SearchResult<MedicalEquipmentAssetLoanSearchResults> getMedicalEquipmentLoanSearchResults(SearchInput searchInput) {
        return service.getMedicalEquipmentLoanSearchResults(searchInput);
    }

    @GET
    @Path("/getMedicalEquipmentLoanToContractTypes")
    public List<String> getMedicalEquipmentLoanToContractTypes() {
        return service.getMedicalEquipmentLoanToContractTypes();
    }
    @GET
    @Path("/getMedicalEquipmentLoanToIndividualStatuses")
    public List<String> getMedicalEquipmentLoanToIndividualStatuses() {
        return service.getMedicalEquipmentLoanToIndividualStatuses();
    }

    @GET
    @Path("/getMedicalEquipmentLoanToMilitaryServices")
    public List<String> getMedicalEquipmentLoanToMilitaryServices() {
        return service.getMedicalEquipmentLoanToMilitaryServices();
    }

    @GET
    @Path("/getMedicalEquipmentLoanToTypes")
    public List<String> getMedicalEquipmentLoanToTypes() {
        return service.getMedicalEquipmentLoanToTypes();
    }

    @POST
    @Path("/getMedicalEquipmentSearchResults")
    public SearchResult<MedicalEquipmentSearchResults> getMedicalEquipmentSearchResults(SearchInput searchInput) {
        return service.getMedicalEquipmentSearchResults(searchInput);
    }

    @GET
    @Path("/getDocumentTypes")
    public List<String> getDocumentTypes() {
        return service.getDocumentTypes();
    }

    @GET
    @Path("/getDurableItemsAvailableToLoan")
    public List<CatalogRef> getDurableItemsAvailableToLoan(@QueryParam("id") String customerId) {
        return service.getDurableItemsAvailableToLoan(customerId);
    }

    @GET
    @Path("/getDurableItemsByLoanId")
    public List<DurableItemsOnLoan> getDurableItemsByLoanId(@QueryParam("id") String loanId) {
        return service.getDurableItemsByLoanId(loanId);
    }

    @GET
    @Path("/getEquipmentCustomers")
    public List<OrganizationRef> getEquipmentCustomers() {
        return service.getEquipmentCustomers();
    }

    @GET
    @Path("/getEquipmentItemsByLoanId")
    public List<MedicalEquipmentItemsOnLoan> getEquipmentItemsByLoanId(@QueryParam("id") String loanId) {
        return service.getEquipmentItemsByLoanId(loanId);
    }

    @GET
    @Path("/getEquipmentItemsWithNoLoanId")
    public List<Asset> getEquipmentItemsWithNoLoanId(@QueryParam("id") String customerId) {
        return service.getEquipmentItemsWithNoLoanId(customerId);
    }

    @GET
    @Path("/getMedicalEquipmentAssetLoanRecordById")
    public MedicalEquipmentAssetLoan getMedicalEquipmentAssetLoanRecordById(@QueryParam("id") String id) {
        return service.getMedicalEquipmentAssetLoanRecordById(id);
    }

    @GET
    @Path("/getMedicalEquipmentByECN")
    public Asset getMedicalEquipmentByECN(@QueryParam("ecn") String ecn) {
        return service.getMedicalEquipmentByECN(ecn);
    }

    @GET
    @Path("/getFloorsByFacilityId")
    public List<Floor> getFloorsByFacilityId(@QueryParam("facilityId") String facilityId) {
        return service.getFloorsByFacilityId(facilityId);
    }

    @GET
    @Path("/getItemById")
    public Item getItemById(@QueryParam("id") String id) {
        return service.getItemById(id);
    }

    @GET
    @Path("/getMaxAttachmentSize")
    public Integer getMaxAttachmentSize() {
        return service.getMaxAttachmentSize();
    }

    @GET
    @Path("getLossFormNumbers")
    public List<String> getLossFormNumbers() {
        return service.getLossFormNumbers();
    }

    @GET
    @Path("/getMEAssetRecordById")
    public Asset getMEAssetRecordById(@QueryParam("id") String id) {
        return service.getMEAssetRecordById(id);
    }

    @POST
    @Path("/getMEAssetRecordsByIds")
    public List<Asset> getMEAssetRecordById(List<String> ids) {
        return service.getMEAssetRecordsByIds(ids);
    }

    @GET
    @Path("/getMEConditions")
    public List<MEConditionEntry> getMEConditions() { return service.getMEConditions(); }

    @GET
    @Path("/getMEEquipmentTypes")
    public List<MEEquipmentType> getMEEquipmentTypes() { return service.getMEEquipmentTypes(); }

    @GET
    @Path("/getOwnership")
    public List<Ownership> getOwnership() { return service.getOwnership(); }

    @GET
    @Path("/getReceivingAgencies")
    public List<SalesCodeType> getReceivingAgencies() { return service.getReceivingAgencies(); }

    @GET
    @Path("/getSiteRefsForInstallation")
    public List<SiteRef> getSiteRefsForInstallation(@QueryParam("installationId") String installationId) {
        return service.getSiteRefsForInstallation(installationId);
    }

    @GET
    @Path("/getSitesForOrganization")
    public List<SiteRef> getSitesForOrganization(@QueryParam("organizationId") String organizationId) {
        return service.getSitesForOrganization(organizationId);
    }

    @GET
    @Path("/getSpacesByFloorId")
    public List<Space> getSpacesByFloorId(@QueryParam("floorId") String floorId) {
        return service.getSpacesByFloorId(floorId);
    }

    @GET
    @Path("/getSystemECNList")
    public List<AssetRef> getSystemECNList() {
        return service.getSystemECNList();
    }

    @GET
    @Path("/removeAttachment")
    public boolean removeAttachment(@QueryParam("id") String id, @QueryParam("fileId") String fileId) throws IOException {
        return service.removeAttachment(id, fileId);
    }

    @POST
    @Path("/renewDurableItemsOnLoan")
    public MedicalEquipmentAssetLoan renewDurableItemsOnLoan(@QueryParam("id") String loanId, DurableItemRenewalInformation durableItemRenewalInformation) {
        service.renewDurableItemsOnLoan(durableItemRenewalInformation);
        return getMedicalEquipmentAssetLoanRecordById(loanId);
    }

    @POST
    @Path("/returnDurableItemsFromLoan")
    public MedicalEquipmentAssetLoan returnDurableItemsFromLoan(@QueryParam("id") String loanId, List<DurableItemsOnLoan> durableItemsToReturnList) {
        service.returnDurableItemsFromLoan(loanId, durableItemsToReturnList);
        return getMedicalEquipmentAssetLoanRecordById(loanId);
    }

    @POST
    @Path("/renewEquipmentItemsOnLoan")
    public MedicalEquipmentAssetLoan renewEquipmentItemsOnLoan(@QueryParam("id") String loanId, EquipmentItemRenewalInformation equipmentItemRenewalInformation) {
        service.renewEquipmentItemsOnLoan(equipmentItemRenewalInformation);
        return getMedicalEquipmentAssetLoanRecordById(loanId);
    }

    @POST
    @Path("/returnEquipmentItemsFromLoan")
    public MedicalEquipmentAssetLoan returnEquipmentItemsFromLoan(@QueryParam("id") String loanId, List<MedicalEquipmentItemsOnLoan> equipmentItemsToReturnList) {
        service.returnEquipmentItemsFromLoan(loanId, equipmentItemsToReturnList);
        return getMedicalEquipmentAssetLoanRecordById(loanId);
    }

    @GET
    @Path("/setMEAssetActive")
    public Asset setMEAssetActive(@QueryParam("assetId") String assetId) {
        service.setMEAssetActive(assetId);
        return service.getMEAssetRecordById(assetId);
    }

    @GET
    @Path("/getMEBusinessContactRefs")
    public List<BusinessContactRef> getMEBusinessContactRefs(@QueryParam("isActive") String isActive) {
        return service.getMEBusinessContactRefs(isActive);
    }

    @GET
    @Path("/getMEAssetContactByBusinessContactId")
    public AssetBusinessContact getMEAssetContactByBusinessContactId(@QueryParam("businessContactId") String businessContactId) {
        return service.getMEAssetContactByBusinessContactId(businessContactId);
    }

    @GET
    @Path("/getMEAssetContactByContactId")
    public AssetBusinessContact getMEAssetContactByContactId(@QueryParam("contactId") String contactId) {
        return service.getMEAssetContactByContactId(contactId);
    }

    @GET
    @Path("/getMEAssetCostSummaryByAssetId")
    public AssetCostSummary getMEAssetCostSummaryByAssetId(@QueryParam("assetId") String assetId) {
        return service.getMEAssetCostSummaryByAssetId(assetId);
    }

    @GET
    @Path("/setMEAssetInactive")
    public Asset setMEAssetInactive(@QueryParam("assetId") String assetId) {
        service.setMEAssetInactive(assetId);
        return service.getMEAssetRecordById(assetId);
    }

    @POST
    @Path("/removeEquipmentNote")
    public Asset removeEquipmentNote(@QueryParam("id") String assetId, Note note) {
        service.removeEquipmentNote(assetId, note);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/removeMedicalEquipmentAssetLoanNote")
    public MedicalEquipmentAssetLoan removeMedicalEquipmentAssetLoanNote(@QueryParam("id") String loanId, Note note) {
        service.removeMedicalEquipmentAssetLoanNote(loanId, note);
        return service.getMedicalEquipmentAssetLoanRecordById(loanId);
    }

    @POST
    @Path("/saveAttachment")
    public Attachment saveAttachment(@QueryParam("id") String id, Attachment attachmentToSave) {
        return service.saveAttachment(id, attachmentToSave);
    }

    @POST
    @Path("/saveEquipmentNote")
    public Asset saveEquipmentNote(@QueryParam("id") String assetId, Note note) {
        service.saveEquipmentNote(assetId, note);
        return service.getAssetById(assetId);
    }

    @POST
    @Path("/saveGeneralInformation")
    public Asset saveGeneralInformation(@QueryParam("id") String id, Asset asset) {
        service.saveGeneralInformation(asset);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveLocationInformation")
    public Asset saveLocationInformation(@QueryParam("id") String id, LocationInformation locationInformation) {
        service.saveLocationInformation(id, locationInformation);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveMEAssetWarranty")
    public Asset saveMEAssetWarranty(@QueryParam("id") String id, AcquisitionInformation acquisitionInformation) {
        service.saveMEAssetWarranty(id, acquisitionInformation);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveOwnerCustodianInformation")
    public Asset saveOwnerCustodianInformation(@QueryParam("id") String id, Asset asset) {
        service.saveOwnerCustodianInformation(id, asset);
        return service.getAssetById(id);
    }

    @POST
    @Path("/saveMedicalEquipment")
    public Asset saveMedicalEquipment(Asset asset) {
        return service.saveMedicalEquipment(asset);
    }

    @POST
    @Path("/saveMedicalEquipmentAssetLoan")
    public MedicalEquipmentAssetLoan saveMedicalEquipmentAssetLoan(MedicalEquipmentAssetLoan loan) {
        return service.saveMedicalEquipmentAssetLoan(loan);
    }

    @POST
    @Path("/saveMedicalEquipmentAssetLoanNote")
    public MedicalEquipmentAssetLoan saveMedicalEquipmentAssetLoanNote(@QueryParam("id") String loanId, Note note) {
        service.saveMedicalEquipmentAssetLoanNote(loanId, note);
        return service.getMedicalEquipmentAssetLoanRecordById(loanId);
    }

    @POST
    @Path("/saveMedicalEquipmentLoanFromInformation")
    public MedicalEquipmentAssetLoan saveMedicalEquipmentLoanFromInformation(@QueryParam("id") String loanId, MedicalEquipmentAssetLoan loan) {
        service.saveMedicalEquipmentLoanFromInformation(loan);
        return service.getMedicalEquipmentAssetLoanRecordById(loanId);
    }

    @POST
    @Path("/saveMedicalEquipmentLoanToInformation")
    public MedicalEquipmentAssetLoan saveMedicalEquipmentLoanToInformation(@QueryParam("id") String loanId, MedicalEquipmentAssetLoan loan) {
        service.saveMedicalEquipmentLoanToInformation(loan);
        return service.getMedicalEquipmentAssetLoanRecordById(loanId);
    }

    @POST
    @Path("/saveMedicalEquipmentTransfer")
    public List<Asset> saveMedicalEquipmentTransfer(METransferRequest meTransferRequest) {
        return service.saveTransfer(meTransferRequest);
    }

    @POST
    @Path("/saveMedicalEquipmentLoss")
    public List<Asset> saveMedicalEquipmentLoss(MELossRequest meLossRequest) {
        return service.saveLoss(meLossRequest);
    }

    @POST
    @Path("/gainMedicalEquipment")
    public List<Asset> gainMedicalEquipment(MedicalEquipmentGainDTO medicalEquipmentGainDTO) {
        return service.gainMedicalEquipment(medicalEquipmentGainDTO);
    }

    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadFile(@ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        byte[] content;

        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            InputStream inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new ApplicationException("Unable to upload file " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxAttachmentSize();
        if (content.length > maxUploadSize) {
            throw new ApplicationException(
                    "File size exceeds max size of " + maxUploadSize + " bytes");
        }

        return service.uploadFile(content, uploadedFileName);
    }

    @GET
    @Path("/getTransactionReasonsByCode")
    public List<TransactionReasonRef> getTransactionReasonsByCode(@QueryParam("code") String code) {
        return service.getTransactionReasonsByCode(code);
    }

    @GET
    @Path("/getOrganizationRefsByCurrentUserScope")
    public List<OrganizationRef> getOrganizationRefsByCurrentUserScope() {
        return service.getOrganizationRefsByCurrentUserScope();
    }

    @GET
    @Path("/getChildOrganizationRefsById")
    public List<OrganizationRef> getOrganizationRefsByParentId(@QueryParam("id") String id) {
        return service.getChildOrganizationRefsById(id);
    }

    @POST
    @Path("/getEquipmentSoftwareSearchResults")
    public SearchResult<MedicalEquipmentSoftware> getEquipmentSoftwareSearchResults(SearchInput searchInput) {
        return service.getEquipmentSoftwareSearchResults(searchInput);
    }

    @GET
    @Path("/getEquipmentSoftwareById")
    public MedicalEquipmentSoftware getEquipmentSoftwareById(@QueryParam("id") String id) {
        return service.getEquipmentSoftwareById(id);
    }

    @GET
    @Path("/getSoftwareCompanies")
    public List<SoftwareCompanyRef> getSoftwareCompanies() {
        return service.getSoftwareCompanies();
    }

    @GET
    @Path("/getOperatingSystems")
    public List<OperatingSystemRef> getOperatingSystems() {
        return service.getOperatingSystems();
    }

    @GET
    @Path("/getSoftwareTypes")
    public List<String> getSoftwareTypes() {
        return service.getSoftwareTypes();
    }

    @GET
    @Path("/getMediumTypes")
    public List<String> getMediumTypes() {
        return service.getMediumTypes();
    }

    @POST
    @Path("/saveEquipmentSoftware")
    public MedicalEquipmentSoftware saveEquipmentSoftware(MedicalEquipmentSoftware medicalEquipmentSoftware) {
        return service.saveEquipmentSoftware(medicalEquipmentSoftware);
    }

    @POST
    @Path("/saveEquipmentSoftwareLicense")
    public MedicalEquipmentSoftware saveEquipmentSoftwareLicense(MedicalEquipmentSoftware medicalEquipmentSoftware) {
        return service.saveEquipmentSoftwareLicense(medicalEquipmentSoftware);
    }

    @GET
    @Path("/getSoftwareNomenclatures")
    public List<SoftwareNomenclatureRef> getSoftwareNomenclatures() {
        return service.getSoftwareNomenclatures();
    }

    @POST
    @Path("/addEquipmentSoftwareNote")
    public MedicalEquipmentSoftware addEquipmentSoftwareNote(@QueryParam("id") String id, Note note) {
        return service.addEquipmentSoftwareNote(id, note);
    }

    @POST
    @Path("/saveEquipmentSoftwareNote")
    public MedicalEquipmentSoftware saveEquipmentSoftwareNote(@QueryParam("id") String id, Note note) {
        return service.saveEquipmentSoftwareNote(id, note);
    }

    @POST
    @Path("/removeEquipmentSoftwareNote")
    public MedicalEquipmentSoftware removeEquipmentSoftwareNote(@QueryParam("id") String id, Note note) {
        return service.removeEquipmentSoftwareNote(id, note);
    }

    @GET
    @Path("/getMedicalEquipmentSoftwareByAssetId")
    public List<MedicalEquipmentSoftware> getMedicalEquipmentSoftwareByAssetId(@QueryParam("assetId") String assetId) {
        return service.getMedicalEquipmentSoftwareByAssetId(assetId);
    }

}
