package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.staging.AbiCatalogRecord;
import logicole.common.datamodels.ehr.product.EhrSearchCriteria;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.io.IOException;
import java.util.List;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi/catalog")
public class AbiCatalogRestApi extends ExternalRestApi<AbiCatalogService> {

    @GET
    @Path("/adjustEcriEquipmentCount")
    public int adjustEcriEquipmentCount(@QueryParam("ecriGuid") String ecriGuid, @QueryParam("adjustment") Integer adjustment) {
        return service.adjustEcriEquipmentCount(ecriGuid, adjustment);
    }

    @POST
    @Path("/findByEHRSearchCriteria")
    public List<AbiCatalogRecord> findByEHRSearchCriteria(EhrSearchCriteria ehrSearchCriteria) throws IOException, ApplicationException {
        return service.findByEHRSearchCriteria(ehrSearchCriteria);
    }
}
