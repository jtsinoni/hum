package logicole.gateway.services.catalog;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.ControlledInventoryItemCode;
import logicole.common.datamodels.abi.ControlledInventoryItemCodeRef;
import logicole.common.datamodels.assemblage.AssemblageItem;
import logicole.common.datamodels.catalog.*;
import logicole.common.datamodels.finance.referencedata.FundingCategory;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.order.CatalogPurchase;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountDTO;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import java.util.List;

@Api(tags = {"CatalogLookup"})
@ApplicationScoped
@Path("/catalogLookup")
public class CatalogLookupRestApi extends ExternalRestApi<CatalogLookupService> {

    @GET
    @Path("/getCommodityClassRefs")
    public List<CommodityClassRef> getCommodityClassRefs() {
        return service.getCommodityClassRefs();
    }

    @GET
    @Path("/getFundingCategories")
    public List<FundingCategory> getFundingCategories() {
        return service.getFundingCategories();
    }

    @GET
    @Path("/getCommodityClasses")
    public List<CommodityClass> getCommodityClasses() {
        return service.getCommodityClasses();
    }

    @POST
    @Path("/createCommodityClass")
    public List<CommodityClass> createCommodityClass(CommodityClass commodityClass) {
        return service.createCommodityClass(commodityClass);
    }

    @GET
    @Path("/getCommodityTypeList")
    public List<String> getCommodityTypeList() {
        return service.getCommodityTypeList();
    }

    @POST
    @Path("/updateCommodityClass")
    public List<CommodityClass> updateCommodityClass(CommodityClass commodityClass) {
        return service.updateCommodityClass(commodityClass);
    }

    @POST
    @Path("/deleteCommodityClass")
    public List<CommodityClass> deleteCommodityClass(CommodityClass commodityClass) {
        return service.deleteCommodityClass(commodityClass);
    }

    @GET
    @Path("/getSpecialHandling")
    public List<SpecialHandling> getSpecialHandling() {
        return service.getSpecialHandling();
    }

    @GET
    @Path("/getSpecialHandlingRefs")
    public List<SpecialHandlingRef> getSpecialHandlingRefs() {
        return service.getSpecialHandlingRefs();
    }

    @POST
    @Path("/createSpecialHandling")
    public List<SpecialHandling> createSpecialHandling(SpecialHandling specialHandling) {
        return service.createSpecialHandling(specialHandling);
    }

    @POST
    @Path("/updateSpecialHandling")
    public List<SpecialHandling> updateSpecialHandling(SpecialHandling specialHandling) {
        return service.updateSpecialHandling(specialHandling);
    }

    @POST
    @Path("/deleteSpecialHandling")
    public List<SpecialHandling> deleteSpecialHandling(SpecialHandling specialHandling) {
        return service.deleteSpecialHandling(specialHandling);
    }

    @GET
    @Path("/getControlledInventoryCodes")
    public List<ControlledInventoryItemCode> getControlledInventoryCodes() {
        return service.getControlledInventoryCodes();
    }

    @GET
    @Path("/getBuyerSellerAccountListByBuyerId")
    public List<BuyerSellerAccountDTO> getBuyerSellerAccountListByBuyerId() {
        return service.getBuyerSellerAccountListByBuyerId();
    }

    @GET
    @Path("/getControlledInventoryCodeRefs")
    public List<ControlledInventoryItemCodeRef> getControlledInventoryCodeRefs() {
        return service.getControlledInventoryCodeRefs();
    }

    @POST
    @Path("/createControlledInventoryItemCode")
    public List<ControlledInventoryItemCode> createControlledInventoryItemCode(ControlledInventoryItemCode controlledInventoryItemCode) {
        return service.createControlledInventoryItemCode(controlledInventoryItemCode);
    }

    @POST
    @Path("/updateControlledInventoryItemCode")
    public List<ControlledInventoryItemCode> updateControlledInventoryItemCode(ControlledInventoryItemCode controlledInventoryItemCode) {
        return service.updateControlledInventoryItemCode(controlledInventoryItemCode);
    }

    @POST
    @Path("/deleteControlledInventoryItemCode")
    public List<ControlledInventoryItemCode> deleteControlledInventoryItemCode(ControlledInventoryItemCode controlledInventoryItemCode) {
        return service.deleteControlledInventoryItemCode(controlledInventoryItemCode);
    }

    @POST
    @Path("/getNonCatalogPurchaseSearchResults")
    public SearchResult<CatalogDTO> getNonCatalogPurchaseSearchResults(SearchInput searchInput) {
        return service.getNonCatalogPurchaseSearchResults(searchInput);
    }

    @POST
    @Path("/getCatalogSearchResults")
    public SearchResult<CatalogDTO> getCatalogSearchResults(SearchInput searchInput) {
        return service.getCatalogSearchResults(searchInput);
    }

    @POST
    @Path("/getCatalogAndNonCatalogSearchResults")
    public SearchResult<CatalogDTO> getCatalogAndNonCatalogSearchResults(SearchInput searchInput) {
        return service.getCatalogAndNonCatalogSearchResults(searchInput);
    }

    @POST
    @Path("/getCatalogSearchResultsForAssemblage")
    public SearchResult<CatalogPurchase> getCatalogSearchResultsForAssemblage(List<AssemblageItem> items) {
        return service.getCatalogSearchResultsForAssemblage(items);
    }
}
