package logicole.gateway.services.spacemanagement;

import logicole.common.crossservice.mdb.BaseMDB;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.services.spacemanagement.cobie.COBieBackgroundRequestService;
import logicole.gateway.services.spacemanagement.cobie.COBieUtilityService;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import java.io.IOException;

@MessageDriven(name = "ProcessDrawingUploadMDB", activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "java:/queue/ProcessDrawingUploadBroker"),
        @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
        @ActivationConfigProperty(propertyName = "maxSession", propertyValue = "1"),
        @ActivationConfigProperty(propertyName = "transactionTimeout", propertyValue = "3600") })
public class ProcessDrawingUploadMDB extends BaseMDB {

    // NOTE FOR 3.0.0 FUTURE DEVELOPMENT
    // WHEN MOVING TO KAFKA, THIS QUEUE SHOULD BE RENAMED TO SOMETHING MORE GENERIC
    // LIKE 'SpaceManagementRequestQueue'
    //
    // COBIE EXPORT PROCESSING WAS ADDED TO THIS MDB BECAUSE NO NEW QUEUES ARE TO BE
    // ADDED.
    // REFACTORING TO RENAME THIS MESSAGE QUEUE WAS NOT DONE TO AVOID ISSUES FOR THE
    // LINUX SERVER CONFIGURATION
    public static final String JMS_TYPE_PROCESS_UPLOAD_DRAWING_REQUEST = "processUploadDrawingRequest";
    public static final String DRAWING_STAGING_SERVICE_BROKER = "ProcessDrawingUploadBroker";

    public static final String JMS_TYPE_COBIE_IMPORT = "processCOBieImportRequest";
    public static final String JMS_TYPE_COBIE_EXPORT = "processCOBieExportRequest";

    public static final String JMS_TYPE_PROCESS_COBIE_CONTACTS = "processCOBieContacts";
    public static final String JMS_TYPE_PROCESS_COBIE_FLOORS = "processCOBieFloors";
    public static final String JMS_TYPE_PROCESS_COBIE_SPACES = "processCOBieSpaces";
    public static final String JMS_TYPE_PROCESS_COBIE_ZONES = "processCOBieZones";
    public static final String JMS_TYPE_PROCESS_COBIE_EQUIPMENT = "processCOBieEquipment";
    public static final String JMS_TYPE_PROCESS_COBIE_ATTRIBUTES = "processCOBieAttributes";

    public static final String JMS_TYPE_DELETE_COBIE_CONTACTS = "deleteCOBieContacts";
    public static final String JMS_TYPE_DELETE_COBIE_FLOORS = "deleteCOBieFloors";
    public static final String JMS_TYPE_DELETE_COBIE_SPACES = "deleteCOBieSpaces";
    public static final String JMS_TYPE_DELETE_COBIE_ZONES = "deleteCOBieZones";
    public static final String JMS_TYPE_DELETE_COBIE_EQUIPMENT = "deleteCOBieEquipment";
    public static final String JMS_TYPE_DELETE_COBIE_ATTRIBUTES = "deleteCOBieAttributes";

    public static final String JMS_TYPE_FIND_DUPLICATE_COBIE_FLOORS = "findDuplicateCOBieFloors";
    public static final String JMS_TYPE_FIND_DUPLICATE_COBIE_SPACES = "findDuplicateCOBieSpaces";
    public static final String JMS_TYPE_FIND_DUPLICATE_COBIE_ZONES = "findDuplicateCOBieZones";
    public static final String JMS_TYPE_FIND_DUPLICATE_COBIE_EQUIPMENT = "findDuplicateCOBieEquipment";
    public static final String JMS_TYPE_FIND_DUPLICATE_COBIE_ATTRIBUTES = "findDuplicateCOBieAttributes";

    @Inject
    private FloorPlanConversionService floorPlanConversionService;
    @Inject
    private COBieService cobieService;
    @Inject
    private COBieBackgroundRequestService cobieBackgroundRequestService;
    @Inject
    private COBieUtilityService cobieUtilityService;

    @Override
    protected void processMessage(Message message) throws ApplicationException {
        if (message instanceof TextMessage) {
            TextMessage textMessage = (TextMessage) message;
            String jmsType = determineJmsType(message);
            switch (jmsType) {
                case JMS_TYPE_PROCESS_UPLOAD_DRAWING_REQUEST:
                    dispatchDrawingRequest(textMessage);
                    break;
                case JMS_TYPE_COBIE_IMPORT:
                    dispatchCOBieImportRequest(textMessage);
                    break;
                case JMS_TYPE_COBIE_EXPORT:
                    dispatchCOBieExportRequest(textMessage);
                    break;
                case JMS_TYPE_PROCESS_COBIE_CONTACTS:
                case JMS_TYPE_PROCESS_COBIE_FLOORS:
                case JMS_TYPE_PROCESS_COBIE_SPACES:
                case JMS_TYPE_PROCESS_COBIE_ZONES:
                case JMS_TYPE_PROCESS_COBIE_EQUIPMENT:
                case JMS_TYPE_PROCESS_COBIE_ATTRIBUTES:
                    dispatchCOBieProcessRequest(jmsType, textMessage);
                    break;
                case JMS_TYPE_DELETE_COBIE_CONTACTS:
                case JMS_TYPE_DELETE_COBIE_FLOORS:
                case JMS_TYPE_DELETE_COBIE_SPACES:
                case JMS_TYPE_DELETE_COBIE_ZONES:
                case JMS_TYPE_DELETE_COBIE_EQUIPMENT:
                case JMS_TYPE_DELETE_COBIE_ATTRIBUTES:
                    dispatchCOBieDeleteRequest(jmsType, textMessage);
                    break;
                case JMS_TYPE_FIND_DUPLICATE_COBIE_FLOORS:
                case JMS_TYPE_FIND_DUPLICATE_COBIE_SPACES:
                case JMS_TYPE_FIND_DUPLICATE_COBIE_ZONES:
                case JMS_TYPE_FIND_DUPLICATE_COBIE_EQUIPMENT:
                case JMS_TYPE_FIND_DUPLICATE_COBIE_ATTRIBUTES:
                    dispatchCOBieFindDuplicatesRequest(jmsType, textMessage);
                    break;
                default:
                    break;
            }
        }
    }

    protected void dispatchDrawingRequest(TextMessage textMessage) {
        try {
            String[] msgText = textMessage.getText().split(":");
            String stagingFloorPlanID = msgText[1];
            logger.info("[DXFConversion] dispatchDrawingRequest: calling floorPlanConversionService.processFloorPlanConversion().");
            floorPlanConversionService.processFloorPlanConversion(stagingFloorPlanID);

        } catch (ApplicationException | JMSException | IOException e) {
            String exMessage = "Error processing processUploadDrawingRequest:" + e.getMessage();
            throw new ApplicationException(exMessage, e);
        }
    }

    protected void dispatchCOBieImportRequest(TextMessage textMessage) {
        try {
            String[] msgText = textMessage.getText().split(":");
            String cobieFileImportId = msgText[1];
            cobieService.processCOBieImportRequest(cobieFileImportId);
        } catch (ApplicationException | JMSException e) {
            String exMessage = "Error processing processCOBieImportRequest:" + e.getMessage();
            throw new ApplicationException(exMessage, e);
        }
    }

    protected void dispatchCOBieExportRequest(TextMessage textMessage) {
        try {
            String[] msgText = textMessage.getText().split(":");
            String cobieFileExportId = msgText[1];
            cobieService.processCOBieExportRequest(cobieFileExportId);
        } catch (ApplicationException | JMSException e) {
            String exMessage = "Error processing processCOBieExportRequest:" + e.getMessage();
            throw new ApplicationException(exMessage, e);
        }
    }

    protected void dispatchCOBieProcessRequest(String jmsType, TextMessage textMessage) {
        String cobieProcessDataRequestId = null;
        try {
            String[] msgText = textMessage.getText().split(":");
            cobieProcessDataRequestId = msgText[1];
            switch (jmsType) {
                case JMS_TYPE_PROCESS_COBIE_CONTACTS:
                    cobieBackgroundRequestService.processCOBieContacts(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_PROCESS_COBIE_FLOORS:
                    cobieBackgroundRequestService.processCOBieFloors(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_PROCESS_COBIE_SPACES:
                    cobieBackgroundRequestService.processCOBieSpaces(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_PROCESS_COBIE_ZONES:
                    cobieBackgroundRequestService.processCOBieZones(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_PROCESS_COBIE_EQUIPMENT:
                    cobieBackgroundRequestService.processCOBieEquipment(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_PROCESS_COBIE_ATTRIBUTES:
                    cobieBackgroundRequestService.processCOBieAttributes(cobieProcessDataRequestId);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            String exMessage = "Error processing process COBie Request '" + jmsType + "'.";
            if (cobieProcessDataRequestId != null) {
                cobieBackgroundRequestService.addCOBieProcessDataRequestDiagnosticMessage(cobieProcessDataRequestId,
                        cobieUtilityService.createExceptionErrorMessage(e));
                cobieBackgroundRequestService.addCOBieProcessDataRequestErrorMessage(cobieProcessDataRequestId,
                        exMessage);
            }
            logger.error("ERROR in dispatchCOBieProcessRequest.");
            logger.error(e);
            throw new ApplicationException(exMessage, e);
        }
    }

    protected void dispatchCOBieDeleteRequest(String jmsType, TextMessage textMessage) {
        String cobieProcessDataRequestId = null;
        try {
            String[] msgText = textMessage.getText().split(":");
            cobieProcessDataRequestId = msgText[1];
            switch (jmsType) {
                case JMS_TYPE_DELETE_COBIE_CONTACTS:
                    cobieBackgroundRequestService.deleteCOBieContacts(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_DELETE_COBIE_FLOORS:
                    cobieBackgroundRequestService.deleteCOBieFloors(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_DELETE_COBIE_SPACES:
                    cobieBackgroundRequestService.deleteCOBieSpaces(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_DELETE_COBIE_ZONES:
                    cobieBackgroundRequestService.deleteCOBieZones(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_DELETE_COBIE_EQUIPMENT:
                    cobieBackgroundRequestService.deleteCOBieEquipment(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_DELETE_COBIE_ATTRIBUTES:
                    cobieBackgroundRequestService.deleteCOBieAttributes(cobieProcessDataRequestId);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            String exMessage = "Error processing delete COBie Request '" + jmsType + "'.";
            if (cobieProcessDataRequestId != null) {
                cobieBackgroundRequestService.addCOBieProcessDataRequestDiagnosticMessage(cobieProcessDataRequestId,
                        cobieUtilityService.createExceptionErrorMessage(e));
                cobieBackgroundRequestService.addCOBieProcessDataRequestErrorMessage(cobieProcessDataRequestId,
                        exMessage);
            }
            throw new ApplicationException(exMessage, e);
        }
    }

    protected void dispatchCOBieFindDuplicatesRequest(String jmsType, TextMessage textMessage) {
        String cobieProcessDataRequestId = null;
        try {
            String[] msgText = textMessage.getText().split(":");
            cobieProcessDataRequestId = msgText[1];
            switch (jmsType) {
                case JMS_TYPE_FIND_DUPLICATE_COBIE_FLOORS:
                    cobieBackgroundRequestService.findDuplicateCOBieFloors(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_FIND_DUPLICATE_COBIE_SPACES:
                    cobieBackgroundRequestService.findDuplicateCOBieSpaces(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_FIND_DUPLICATE_COBIE_ZONES:
                    cobieBackgroundRequestService.findDuplicateCOBieZones(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_FIND_DUPLICATE_COBIE_EQUIPMENT:
                    cobieBackgroundRequestService.findDuplicateCOBieEquipment(cobieProcessDataRequestId);
                    break;
                case JMS_TYPE_FIND_DUPLICATE_COBIE_ATTRIBUTES:
                    cobieBackgroundRequestService.findDuplicateCOBieAttributes(cobieProcessDataRequestId);
                    break;
                default:
                    break;
            }
        } catch (Exception e) {
            String exMessage = "Error processing find duplicate COBie Request '" + jmsType + "'.";
            if (cobieProcessDataRequestId != null) {
                cobieBackgroundRequestService.addCOBieProcessDataRequestDiagnosticMessage(cobieProcessDataRequestId,
                        cobieUtilityService.createExceptionErrorMessage(e));
                cobieBackgroundRequestService.addCOBieProcessDataRequestErrorMessage(cobieProcessDataRequestId,
                        exMessage);
            }
            throw new ApplicationException(exMessage, e);
        }
    }
}
