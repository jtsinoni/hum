package logicole.gateway.services.finance;

import logicole.apis.finance.IFinanceDataMigrationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class FinanceDataMigrationMicroserviceClient extends MicroserviceClient<IFinanceDataMigrationMicroserviceApi> {
    public FinanceDataMigrationMicroserviceClient(){
        super(IFinanceDataMigrationMicroserviceApi.class, "logicole-finance");
    }

    @Produces
    public IFinanceDataMigrationMicroserviceApi getMicroserviceApi() {
        return createClient();
    }

}
