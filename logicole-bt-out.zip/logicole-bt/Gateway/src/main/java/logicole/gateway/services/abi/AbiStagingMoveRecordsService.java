package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiStagingMoveRecordsMicroserviceApi;
import logicole.common.datamodels.abi.Business;
import logicole.common.datamodels.abi.staging.*;
import logicole.common.datamodels.abi.types.StagingRequestType;
import logicole.common.datamodels.product.AbiProductUpdate;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.general.util.JSONUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.referencedata.BusinessService;
import logicole.gateway.services.product.OfferService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class AbiStagingMoveRecordsService extends BaseGatewayService<IAbiStagingMoveRecordsMicroserviceApi> {

    @Inject
    AbiStagingService abiStagingService;

    @Inject
    OfferService offerService;

    @Inject
    BusinessService businessService;

    @Inject
    private JSONUtil jsonUtil;

    public AbiStagingMoveRecordsService() {
        super("AbiStaging");
    }


    public CurrentUser getCurrentUser() {
        return currentUserBT.getCurrentUser();
    }

    public MoveRecordsResponse moveStagingRecordsToProduction(List<String> idList) {

        MoveRecordsResponse response = new MoveRecordsResponse();
        idList.forEach(id -> {
            AbiCatalogStaging record = abiStagingService.findRecordById(id);
            if (record != null) {

                //handle update business
                Business business = businessService.checkManufacturerName(record.manufacturer);
                if (business != null){
                    record.businessRef = business.getRef();
                    record.manufacturer = business.businessName;
                }

                ABiCatalogRecordUpdate updatedRecord = microservice.publishRecordToProduction(record);
                markRecordAsPublished(record);
                response.aBiCatalogRecordUpdate.add(updatedRecord);
                response.idsThatWereMoved.add(id);
                publishAbiCatalogChange(response.aBiCatalogRecordUpdate);
            } else {
                response.idsThatWereNotMoved.add(id);
            }
        });
        return response;
    }

    protected void markRecordAsPublished(AbiCatalogStaging recordThatWasPublished) {
        abiStagingService.changeRecordStatus(recordThatWasPublished, RecordStatusType.PUBLISHED);
        abiStagingService.updateRecord(recordThatWasPublished);
    }

    public MoveRecordsResponse moveApprovedStagingRecordsToProduction() {
        MoveRecordsResponse response = microservice.moveApprovedStagingRecordsToProduction();
        response.idsThatWereMoved.forEach(id -> {
            AbiCatalogStaging record = abiStagingService.findRecordById(id);
            if (record != null) {
                markRecordAsPublished(record);
            }
        });
        publishAbiCatalogChange(response.aBiCatalogRecordUpdate);
        return response;
    }

    public void processMoveRecordResponses(List<MoveRecordsResponse> moveRecordsResponseList)  {
        logger.info("AbiStaginMoveRecordsService: ProcessMoveRecordResponses Size" + moveRecordsResponseList.size() );
        for (MoveRecordsResponse moveRecordsResponse : moveRecordsResponseList) {
            List<ABiCatalogRecordUpdate> aBiCatalogRecordUpdates = moveRecordsResponse.aBiCatalogRecordUpdate;
            publishAbiCatalogChange(aBiCatalogRecordUpdates);
        }
    }

    public void publishAbiCatalogChange( List<ABiCatalogRecordUpdate> aBiCatalogRecordUpdateList){
        AbiProductUpdate abiProductUpdate = new AbiProductUpdate();
        abiProductUpdate.aBiCatalogRecordUpdateList = aBiCatalogRecordUpdateList;
        logger.info("AbiStaginMoveRecordsService: publishAbiCatalogChange Size" + aBiCatalogRecordUpdateList.size() );

        String stagingRequestId = UUID.randomUUID().toString();
        List<String> argumentList = new ArrayList<>();
        try {
            argumentList.add(jsonUtil.serialize(abiProductUpdate));
            StagingRequest request = StagingRequest.create(stagingRequestId, "",
                    StagingRequestType.PROCESS_PRODUCT_SYNC, argumentList);
            abiStagingService.sendRequest(request);
        } catch (IOException e){
            logger.error("Error in sending Abi catalog update to Product sync");
        }
    }

}
