package logicole.gateway.services.asset;

import logicole.apis.asset.IMedicalEquipmentMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class MedicalEquipmentMicroserviceClient extends MicroserviceClient<IMedicalEquipmentMicroserviceApi> {
    public MedicalEquipmentMicroserviceClient(){
        super(IMedicalEquipmentMicroserviceApi.class, "logicole-asset");
    }

    @Produces
    public IMedicalEquipmentMicroserviceApi getIMedicalEquipmentMicroserviceApi() {
        return createClient();
    }

}
