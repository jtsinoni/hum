package logicole.gateway.common.Saga;

import java.util.Stack;
import java.util.function.BiFunction;
import java.util.function.Function;

public class Saga implements AutoCloseable {

    public final String name;
    private final Stack<SagaStep> reversalStack = new Stack<>();

    public Saga(String name) {
        this.name = name;
    }

    public <T, R, S> R execute(Function<T, R> function, T functionParameter) {
        return execute(function, null, null, functionParameter);
    }

    public <T, R, S> R execute(Function<T, R> function, BiFunction<T, R, S> reversalFunction, T functionParameter) {
        return execute(function, reversalFunction, null, functionParameter);
    }

    public <T, R, S> R execute(Function<T, R> function, BiFunction<T, R, S> reversalFunction, BiFunction<T, R, S> completionFunction, T functionParameter) {
        String stepName = String.format("Step%d", reversalStack.size() + 1);
        R result = defineStep(stepName, function, reversalFunction, completionFunction).execute(functionParameter);
        return result;
    }

    public <T, R, S> SagaStep<T, R, S> defineStep(String stepName, Function<T, R> forwardFunction) {
        SagaStep sagaStep = new SagaStep(this, stepName, forwardFunction);
        return sagaStep;
    }

    public <T, R, S> SagaStep<T, R, S> defineStep(String stepName, Function<T, R> forwardFunction, BiFunction<T, R, S> reversalFunction) {
        SagaStep sagaStep = new SagaStep(this, stepName, forwardFunction, reversalFunction);
        return sagaStep;
    }


    public <T, R, S> SagaStep<T, R, S> defineStep(String stepName, Function<T, R> forwardFunction, BiFunction<T, R, S> reversalFunction, BiFunction<T, R, S> completionFunction) {
        SagaStep sagaStep = new SagaStep(this, stepName, forwardFunction, reversalFunction, completionFunction);
        return sagaStep;
    }


    <T, R, S> R executeStep(SagaStep<T, R, S> sagaStep) {
        R result;
        try {
            result = sagaStep.executeForward();
            reversalStack.push(sagaStep);
            return result;
        } catch (Exception e) {
            rollbackSteps();
            throw new RuntimeException("Error executing Saga.", e);
        }
    }


    private void rollbackSteps() {
        while (reversalStack.isEmpty() == false) {
            SagaStep sagaStep = reversalStack.pop();
            sagaStep.executeReverse();
        }
    }

    private void complete() {
        while (reversalStack.isEmpty() == false) {
            SagaStep sagaStep = reversalStack.pop();
            sagaStep.executeCompletion();
        }
    }


    @Override
    public void close() {
        complete();
    }
}
