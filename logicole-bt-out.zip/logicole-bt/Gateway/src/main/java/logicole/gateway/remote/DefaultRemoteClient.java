package logicole.gateway.remote;

import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class DefaultRemoteClient extends MicroserviceClient<IDefaultRemoteApi> {
    public DefaultRemoteClient(){
        super(IDefaultRemoteApi.class, "This is a placeholder");
    }

    @Produces
    public IDefaultRemoteApi getMicroserviceApi() {
        return createClient();
    }

}
