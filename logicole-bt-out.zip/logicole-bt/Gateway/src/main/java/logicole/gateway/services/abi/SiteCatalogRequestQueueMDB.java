package logicole.gateway.services.abi;

import logicole.common.crossservice.mdb.BaseMDB;
import logicole.common.datamodels.abi.SiteCatalogRequest;
import logicole.common.general.util.JSONUtil;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.inject.Inject;
import javax.jms.*;
import java.io.IOException;

@MessageDriven(name = "SiteCatalogRequestQueueMDB", activationConfig = {
        @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "java:/queue/ABiSiteCatalogRequestBroker"),
        @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
        @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge")})

public class SiteCatalogRequestQueueMDB extends BaseMDB {

    @Inject
    private SiteCatalogRequestService siteCatalogRequestService;
    @Inject
    private JSONUtil jsonUtil;

    @Override
    protected void processMessage(Message message) {
        TextMessage textMessage = (TextMessage) message;
        String messageText = null;
        try {
            messageText = textMessage.getText();
        } catch (JMSException e) {
            throw new RuntimeException("Cannot convert queue Message to TextMessage", e);
        }

        SiteCatalogRequest siteCatalogRequest = null;
        try {
            siteCatalogRequest = jsonUtil.deserialize(messageText, SiteCatalogRequest.class);
        } catch (IOException e) {
            throw new RuntimeException("Cannot deserialize SiteCatalogRequest from json", e);
        }

        siteCatalogRequestService.processRequest(siteCatalogRequest);
    }
}

// This needs to go in standalone-full.xml <subsystem xmlns="urn:jboss:domain:messaging-activemq:1.0"> section:
// <jms-queue name="ABiSiteCatalogRequestBroker" entries="queue/ABiSiteCatalogRequestBroker java:jboss/exported/jms/queue/ABiSiteCatalogRequestBroker"/>
