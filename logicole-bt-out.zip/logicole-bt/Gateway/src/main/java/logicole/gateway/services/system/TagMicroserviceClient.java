package logicole.gateway.services.system;

import logicole.apis.system.ITagMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class TagMicroserviceClient extends MicroserviceClient<ITagMicroserviceApi> {
    public TagMicroserviceClient() {
        super(ITagMicroserviceApi.class, "logicole-system");
    }
    
    @Produces
    public ITagMicroserviceApi getITagMicroserviceApi() {
        return createClient();
    }
    
}
