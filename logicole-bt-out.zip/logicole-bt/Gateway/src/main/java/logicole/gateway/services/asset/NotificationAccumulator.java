package logicole.gateway.services.asset;

import logicole.common.datamodels.notification.ApplicationNotification;

import javax.enterprise.context.RequestScoped;
import java.util.ArrayList;
import java.util.List;

@RequestScoped
public class NotificationAccumulator {
    private int totalErrorCount = 0;
    private int maxNotifications = 100;

    private StringBuilder stringBuilder = new StringBuilder();
    private List<ApplicationNotification> notifications = new ArrayList<>();

    public void addErrors(List<String> errors) {
        stringBuilder.append(String.join(", ", errors));
        totalErrorCount += errors.size();
        checkForNewNotification();
    }

    private void createNotification() {
        ApplicationNotification notification = new ApplicationNotification();
        notification.content = stringBuilder.toString();
        notifications.add(notification);
        stringBuilder = new StringBuilder();
    }

    public void addError(String error) {
        totalErrorCount++;
        stringBuilder.append(error);
        checkForNewNotification();
    }

    public void checkForNewNotification() {
        int expectedNotifications = totalErrorCount / maxNotifications;
        if ( expectedNotifications > notifications.size())  {
            createNotification();
        }
    }

    public boolean hasErrors() {
        return this.notifications.size() > 0;
    }

    public int getTotalErrorCount() {
        return this.totalErrorCount;
    }

    public List<ApplicationNotification> getNotifications() {
        if (stringBuilder.length() > 0) {
            createNotification();
        }
        return this.notifications;
    }

    void setMaxNotifications(int newMax) {
        this.maxNotifications = newMax;
    }
}
