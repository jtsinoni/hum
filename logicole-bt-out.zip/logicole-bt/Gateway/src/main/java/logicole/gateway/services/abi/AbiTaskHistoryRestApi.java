package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.AbiTaskHistory;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.util.List;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi/taskHistory")
public class AbiTaskHistoryRestApi extends ExternalRestApi<AbiTaskHistoryService> {

    @GET
    @Path("/getTaskHistoryByCategory")
    public List<AbiTaskHistory> getTaskHistoryByCategory(@QueryParam("category") String category) {
        return service.getTaskHistoryByCategory(category);
    }

    @GET
    @Path("/getTaskHistoryByRequestIdRecordCount")
    @Produces(MediaType.TEXT_PLAIN)
    public long getTaskHistoryByRequestIdRecordCount(@QueryParam("requestId") String requestId) {
        return service.getTaskHistoryByRequestIdRecordCount(requestId);
    }

    @GET
    @Path("/getTaskHistoryByRequestId")
    public List<AbiTaskHistory> getTaskHistoryByRequestId(@QueryParam("requestId") String requestId) {
        return service.getTaskHistoryByRequestId(requestId);
    }

    @GET
    @Path("/downloadTaskHistoryFile")
    public Response downloadTaskHistoryFile(@QueryParam("requestId") String requestId) throws IOException, ApplicationException {
        return service.downloadTaskHistoryFile(requestId);
    }
}
