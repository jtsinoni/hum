package logicole.gateway.services.organization;

import logicole.apis.organization.IBusinessServiceDefinitionMicroserviceApi;
import logicole.common.datamodels.organization.BusinessServiceDefinition;
import logicole.common.datamodels.organization.BusinessServiceDefinitionRef;
import logicole.common.datamodels.organization.EEngagementModel;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.user.RoleRef;
import logicole.common.general.exception.ValidationException;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@ApplicationScoped
public class BusinessServiceDefinitionService extends BaseGatewayService<IBusinessServiceDefinitionMicroserviceApi>
{
    @Inject
    private OrganizationService organizationService;

    public BusinessServiceDefinitionService() {
        super("BusinessServiceDefinition");
    }

    public BusinessServiceDefinition addBusinessServiceDefinition(BusinessServiceDefinition businessService) {
        return microservice.addBusinessServiceDefinition(businessService);
    }

    public BusinessServiceDefinition updateBusinessServiceDefinition(BusinessServiceDefinition businessService) {
        return microservice.updateBusinessServiceDefinition(businessService);
    }

    public void deleteBusinessServiceDefinition(String id) {
        BusinessServiceDefinition definition = microservice.getBusinessServiceDefinition(id);
        if (Objects.isNull(definition)) {
            throw new ValidationException("Business Service Definition not found");
        } else {
            // TODO check if it is assigned to an org?
            // or remove it from all orgs if deleted ref update like process....
            List<Organization> organizations = organizationService.getOrganizationsWithBusinessServiceDefinition(id);
            if (!organizations.isEmpty()) {
                throw new ValidationException(String.format("Business Service Definition %s exists on one or more Organizations", definition.name));
            }
        }
        microservice.deleteBusinessServiceDefinition(id);
    }

    public BusinessServiceDefinition updateRoles(String businessServiceId, EEngagementModel engagementModel,
                                          List<RoleRef> roleRefs) {
        return microservice.updateRoles(businessServiceId, engagementModel, roleRefs);
    }

    public List<RoleRef> getBusinessServiceDefinitionRoleRefs(String businessServiceDefinitionId, EEngagementModel engagementModel) {
        BusinessServiceDefinition definition = microservice.getBusinessServiceDefinition(businessServiceDefinitionId);
        if (Objects.isNull(definition)) {
            throw new ValidationException("Business service definition not found");
        }
        return microservice.getBusinessServiceDefinitionRoleRefs(businessServiceDefinitionId, engagementModel);
    }

    public List<String> getEngagementModelSelections() {
        return EEngagementModel.getDisplayTextList();
    }

    public List<BusinessServiceDefinition> getAllBusinessServiceDefinitions() {
        return microservice.getAllBusinessServiceDefinitions();
    }

    public List<BusinessServiceDefinitionRef> getAllBusinessServiceDefinitionRefs() {
        return microservice.getAllBusinessServiceDefinitions().stream().map(BusinessServiceDefinition::getRef).collect(Collectors.toList());
    }

}
