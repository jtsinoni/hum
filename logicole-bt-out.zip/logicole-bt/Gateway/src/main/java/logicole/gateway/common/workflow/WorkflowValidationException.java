package logicole.gateway.common.workflow;

import logicole.common.general.exception.ValidationException;

public class WorkflowValidationException extends ValidationException {

    public WorkflowValidationException(Throwable t){
        this(t.getMessage(), t);
    }

    public WorkflowValidationException(String message) {
        super(message);
    }

    public WorkflowValidationException(String message, Throwable cause) {
        super(message, cause);
    }

}
