package logicole.gateway.services.system;

import logicole.apis.system.ISystemFeatureFlagMicroserviceApi;
import logicole.common.crossservice.sync.EDataReferenceEventType;
import logicole.common.datamodels.featureflag.FeatureFlag;
import logicole.common.datamodels.user.ElementRef;
import logicole.common.datamodels.user.EndpointRef;
import logicole.common.datamodels.user.PermissionRef;
import logicole.common.datamodels.user.RoleRef;
import logicole.common.datamodels.user.StateRef;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class SystemFeatureFlagService extends BaseGatewayService<ISystemFeatureFlagMicroserviceApi> {

    public SystemFeatureFlagService() {
        super("SystemFeatureFlagService");
    }

    public List<FeatureFlag> getAllFeatureFlags() {
            return microservice.getAllFeatureFlags();
    }

    public FeatureFlag createFeatureFlag(FeatureFlag featureFlag) {
        return microservice.createFeatureFlag(featureFlag);
    }

    public FeatureFlag updateFeatureFlag(FeatureFlag featureFlag) {
        return microservice.updateFeatureFlag(featureFlag);
    }

    public void deleteFeatureFlag(FeatureFlag featureFlag) {
        microservice.deleteFeatureFlag(featureFlag);
    }

    public List<FeatureFlag> getActiveFeatureFlags() {
        return microservice.getActiveFeatureFlags();
    }

    public FeatureFlag getFeatureFlagById(String id) {
        return microservice.getFeatureFlagById(id);
    }

    public Boolean isFeatureFlagActive(String name) {
        boolean isActive = false;
        List<FeatureFlag> flags = getActiveFeatureFlags();

        for (FeatureFlag flag : flags) {
            if (flag.name.equalsIgnoreCase(name)) {
                if (flag.isEnabled) {
                    isActive = true;
                    break;
                }
            }
        }
        return isActive;
    }

    public boolean checkIfUserRequestFeatureFlagIsActive() {
        String ancestry = currentUserBT.getCurrentUser().profile.currentNodeRef.ancestry;
        return microservice.checkIfUserRequestFeatureFlagIsActive(ancestry);
    }

    public FeatureFlag updateIncludeOrganizations(FeatureFlag featureFlag) {
        return microservice.updateIncludeOrganizations(featureFlag);
    }

    public FeatureFlag updateExcludeOrganizations(FeatureFlag featureFlag) {
        return microservice.updateExcludeOrganizations(featureFlag);
    }
    
	public int updateRoleRef(RoleRef roleRef, EDataReferenceEventType dataReferenceEventType) {
		return microservice.updateRoleRef(roleRef, dataReferenceEventType);
	}

	public int updatePermissionRef(PermissionRef permissionRef, EDataReferenceEventType dataReferenceEventType) {
		return microservice.updatePermissionRef(permissionRef, dataReferenceEventType);
	}

	public int updateStateRef(StateRef stateRef, EDataReferenceEventType dataReferenceEventType) {
		return microservice.updateStateRef(stateRef, dataReferenceEventType);
	}

	public int updateElementRef(ElementRef elementRef, EDataReferenceEventType dataReferenceEventType) {
		return microservice.updateElementRef(elementRef, dataReferenceEventType);
	}

	public int updateEndpointRef(EndpointRef endpointRef, EDataReferenceEventType dataReferenceEventType) {
		return microservice.updateEndpointRef(endpointRef, dataReferenceEventType);
	}

	public FeatureFlag getActiveFeatureFlagByName(String featureFlagName, String ancestry) {
        return microservice.getActiveFeatureFlagByName(featureFlagName, ancestry);
    }
}
