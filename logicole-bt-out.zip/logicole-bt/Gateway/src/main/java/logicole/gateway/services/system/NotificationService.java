package logicole.gateway.services.system;

import logicole.apis.system.IApplicationNotificationMicroserviceApi;
import logicole.common.datamodels.notification.ApplicationNotification;
import logicole.common.datamodels.notification.EmailMessage;
import logicole.common.datamodels.user.UserProfile;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.user.UserService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class NotificationService extends BaseGatewayService<IApplicationNotificationMicroserviceApi> {
    @Inject
    UserService userService;

    public NotificationService() {
        super("Notification");
    }

    public void sendEmail(EmailMessage emailMessage) {
        microservice.sendEmail(emailMessage);
    }

    public List<String> findEmailAddressesToNotify(String ... roleIds) {
        List<String> emailAddressesToNotify = new ArrayList<>();

        for (String roleId: roleIds) {
            List<UserProfile> profilesWithAssetProgramManagerRoles = userService.findActiveProfilesWithRoleRef(roleId);
            for (UserProfile activeProfile : profilesWithAssetProgramManagerRoles) {
                emailAddressesToNotify.add(activeProfile.email);
            }
        }
        return emailAddressesToNotify;
    }

    public void sendEmails(List<EmailMessage> emails) {
        for (EmailMessage email: emails) {
            sendEmail(email);
        }
    }

    public void sendEmailWithResponse(EmailMessage emailMessage) {

        microservice.sendEmailWithResponse(emailMessage);
    }

    public void createNotification(ApplicationNotification notification) {
        microservice.createNotification(notification);
    }

    public void createNotifications(List<ApplicationNotification> notifications) {
        microservice.createNotifications(notifications);
    }

    public List<ApplicationNotification> getUnreadNotifications() {
        return microservice.getUnreadNotifications();
    }

    public List<ApplicationNotification> getAllNotifications() {
        return microservice.getAllNotifications();
    }

    public List<ApplicationNotification> markNotificationAsRead(String notificationId) {
        return microservice.markNotificationAsRead(notificationId);
    }

    public Long getUnreadNotificationCount() {
        return microservice.getUnreadNotificationCount();
    }

    public List<String> findEmailAddressesToNotify(List<UserProfile> usersToNotify) {
        List<String> list = new ArrayList<>();

        for (UserProfile profile: usersToNotify){
            list.add(profile.email);
        }

        return list;
    }

    public void addApplicationNotification(ApplicationNotification applicationNotification) {
        microservice.createNotification(applicationNotification);
    }
}
