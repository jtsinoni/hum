package logicole.gateway.services.system;

import io.swagger.annotations.Api;
import logicole.common.datamodels.system.Tag;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Api(tags = {"Tag"})
@ApplicationScoped
@Path("/tag")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class TagRestApi extends ExternalRestApi<TagService> {

    @GET
    @Path("/getTagByName")
    public Tag getTagByName(@QueryParam("name") String name, @QueryParam("businessArea") String businessArea) {
        return service.getTagByName(name, businessArea);
    }

//    @GET
//    @Path("/getTagRefsForBusinessArea")
//    public List<TagRef> getTagRefsForBusinessArea(@QueryParam("businessArea") String businessArea) {
//        return service.getTagRefsForBusinessArea(businessArea);
//    }

    @POST
    @Path("/addTag")
    public Tag addTag(Tag tag) {
        return service.addTag(tag);
    }

    @POST
    @Path("/updateTag")
    public Tag updateTag(Tag tag) {
        return service.updateTag(tag);
    }

    @GET
    @Path("/getTagById")
    public Tag getTagById(@QueryParam("tagId") String tagId) {
        return service.getTagById(tagId);
    }

    @GET
    @Path("/getTagSearchResults")
    public List<Tag> getTagSearchResults(@QueryParam("searchString") String searchString) {
        return service.getTagSearchResults(searchString);
    }

    @GET
    @Path("/getAllTags")
    public List<Tag> getAllTags(@NotNull @QueryParam("businessArea") String businessArea) {
        return service.getAllTags(businessArea);
    }

    @POST
    @Path("/deleteTag")
    public void deleteTag(Tag tag) {
        service.deleteTag(tag);
    }

    @GET
    @Path("/getBusinessAreas")
    public List<String> getBusinessAreas() {
        return service.getBusinessAreas();
    }

    @GET
    @Path("/determineIfRootUser")
    public boolean determineIfRootUser() {
        return service.determineIfRootUser();
    }
}
