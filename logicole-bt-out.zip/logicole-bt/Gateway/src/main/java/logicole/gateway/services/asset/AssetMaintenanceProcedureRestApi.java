package logicole.gateway.services.asset;

import io.swagger.annotations.*;
import logicole.common.datamodels.Attachment;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.businesscontact.Skill;
import logicole.common.datamodels.asset.classification.*;
import logicole.common.datamodels.asset.maintenance.procedure.*;
import logicole.common.datamodels.asset.maintenance.procedure.bulk.BulkResponse;
import logicole.common.datamodels.asset.maintenance.procedure.dropDownFeeders.ProcedureTypeEntry;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.system.frequency.Frequency;
import logicole.common.datamodels.system.frequency.FrequencyRef;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Api(tags = {"AssetMaintenanceProcedure"})
@ApplicationScoped
@Path("/assetMaintenanceProcedure")
public class AssetMaintenanceProcedureRestApi extends ExternalRestApi<AssetMaintenanceProcedureService> {

    @Inject
    private MultiPartFormUtil uploadUtil;

    @GET
    @Path("/isManagedByNodeRPFuncEnabled")
    public boolean isManagedByNodeRPFuncEnabled(){
        return service.isManagedByNodeRPFuncEnabled();
    }

    @GET
    @Path("/startNewMaintenanceProcedure")
    public MaintenanceProcedure startNewMaintenanceProcedure(@NotNull @QueryParam("isRpss") boolean isRpss) {
        return service.startNewMaintenanceProcedure(isRpss);
    }

    @GET
    @Path("/getDocumentTypes")
    public List<String> getDocumentTypes() {
        return service.getDocumentTypes();
    }

    @POST
    @Path("/loadRpssMaintenanceProcedure")
    public void loadRpssMaintenanceProcedure(MaintenanceProcedureRpss rpss) {
        service.loadRpssMaintenanceProcedure(rpss);
    }

    @POST
    @Path("/loadRpssMaintenanceProcedures")
    public void loadRpssMaintenanceProcedures(List<MaintenanceProcedureRpss> rpssList) {
        service.loadRpssMaintenanceProcedures(rpssList);
    }

    @GET
    @Path("/deleteRpssMaintenanceProcedure")
    public void deleteRpssMaintenanceProcedure(@NotNull @QueryParam("procedureIdentifier") String procedureIdentifier) {
        service.deleteRpssMaintenanceProcedure(procedureIdentifier);
    }

    @GET
    @Path("/getProcedureCountByNomenclature")
    public long getProcedureCountByNomenclature(@NotNull @QueryParam("nomenclatureId") String nomenclatureId) {
        return service.getProcedureCountByNomenclature(nomenclatureId);
    }

    @GET
    @Path("/getCountByRegulatoryComplianceActionAndScope")
    public long getCountByRegulatoryComplianceActionAndScope(@NotNull @QueryParam("regulatoryComplianceActionId") String regulatoryComplianceActionId,
                                                             @NotNull @QueryParam("scopeOrgId") String scopeOrgId) {
        return service.getCountByRegulatoryComplianceActionAndScope(regulatoryComplianceActionId, scopeOrgId);
    }

    @GET
    @Path("/getCountByRegulatoryComplianceCodeAndScope")
    public long getCountByRegulatoryComplianceCodeAndScope(@NotNull @QueryParam("regulatoryComplianceCodeId") String regulatoryComplianceCodeId,
                                                           @NotNull @QueryParam("scopeOrgId") String scopeOrgId) {
        return service.getCountByRegulatoryComplianceCodeAndScope(regulatoryComplianceCodeId, scopeOrgId);
    }

    @POST
    @Path("/getMaintenanceProcedureDetailsList")
    public List<MaintenanceProcedure> getMaintenanceProcedureDetailsList(DetailSearchCriteria searchCriteria) {
        return service.getMaintenanceProcedureDetailsList(searchCriteria);
    }

    @POST
    @Path("/migrateAuthoritativeProcedure")
    public void migrateAuthoritativeProcedure(@QueryParam("authoritativeSourceCode") String authoritativeSourceCode, AuthoritativeProcedure authoritativeProcedure) {
        service.migrateAuthoritativeProcedure(authoritativeProcedure, authoritativeSourceCode);
    }

    @POST
    @Path("/createMaintenanceProcedure")
    public MaintenanceProcedure createMaintenanceProcedure(MaintenanceProcedure maintenanceProcedure) {
        return service.createMaintenanceProcedure(maintenanceProcedure);
    }

    @POST
    @Path("/findMaintenanceProcedures")
    public SearchResult<MaintenanceProcedureSummary> findMaintenanceProcedures(SearchInput searchInput) {
        return service.findMaintenanceProcedures(searchInput);
    }

    @GET
    @Path("/cloneProcedure")
    public MaintenanceProcedure cloneProcedure(@QueryParam("id") String id) {
        return service.cloneProcedure(id);
    }

    @POST
    @Path("/saveNewRpssProcedure")
    public MaintenanceProcedure saveNewRpssProcedure(MaintenanceProcedure maintenanceProcedure) {
        return service.saveNewRpssProcedure(maintenanceProcedure);
    }

    @POST
    @Path("/saveNewProcedure")
    public MaintenanceProcedure saveNewProcedure(MaintenanceProcedure clonedProcedure) {
        return service.saveNewProcedure(clonedProcedure);
    }

    @GET
    @Path("/setProcedureIsActive")
    public MaintenanceProcedure setProcedureIsActive(@QueryParam("id") String id, @QueryParam("isActive") boolean isActive) {
        return service.setProcedureIsActive(id, isActive);
    }

    @POST
    @Path("/bulkUpdateStatus")
    public BulkResponse bulkUpdateStatus(List<String> ids, @QueryParam("isActive") boolean isActive) {
        return service.bulkUpdateStatus(ids, isActive);
    }

    @GET
    @Path("/setProcedureIsDeleted")
    public void setProcedureIsDeleted(@QueryParam("id") String id) {
        service.setProcedureIsDeleted(id);
    }

    @GET
    @Path("/findById")
    public MaintenanceProcedure findById(@QueryParam("id") String id) {
        return service.findById(id);
    }

    @POST
    @Path("/findByIds")
    public List<MaintenanceProcedure> findByIds(List<String> ids) {
        return service.findByIds(ids);
    }

    @GET
    @Path("/getNomenclatureRef")
    public NomenclatureRef getNomenclatureRef(@NotNull @QueryParam("id") String id) {
        return service.getNomenclatureRef(id);
    }

    @POST
    @Path("/getNomenclatures")
    public List<Nomenclature> getNomenclatures(String searchInput) {
        return service.getNomenclatures(searchInput);
    }

    @GET
    @Path("/getNomenclaturesForDropdown")
    public List<NomenclatureForDropdown> getNomenclaturesForDropdown() {
        return service.getNomenclaturesForDropdown();
    }

    @POST
    @Path("/addAssemblyCategory")
    public AssemblyCategory addAssemblyCategory(AssemblyCategory assemblyCategory) {
        return service.addAssemblyCategory(assemblyCategory);
    }

    @POST
    @Path("/updateAssemblyCategory")
    public AssemblyCategory updateAssemblyCategory(AssemblyCategory assemblyCategory) {
        return service.updateAssemblyCategory(assemblyCategory);
    }

    @POST
    @Path("/deleteAssemblyCategory")
    public void deleteAssemblyCategory(String assemblyCategoryId) {
        service.deleteAssemblyCategory(assemblyCategoryId);
    }

    @GET
    @Path("/deleteAssemblyCategoryById")
    public void deleteAssemblyCategoryById(@NotNull @QueryParam("assemblyCategoryId") String assemblyCategoryId) {
        // Version to be called as part of a data load...skips scoping check
        service.deleteAssemblyCategoryById(assemblyCategoryId);
    }

    @GET
    @Path("/getAllAssemblyCategories")
    public List<AssemblyCategory> getAllAssemblyCategories() {
        return service.getAllAssemblyCategories();
    }

    @POST
    @Path("/loadAssemblyCategory")
    public void loadAssemblyCategory(AssemblyCategory assemblyCategory) {
        service.loadAssemblyCategory(assemblyCategory);
    }

    @POST
    @Path("/loadFacilitySubsystem")
    public void loadFacilitySubsystem(FacilitySubsystem facilitySubsystem) {
        service.loadFacilitySubsystem(facilitySubsystem);
    }

    @POST
    @Path("/loadFacilitySystem")
    public void loadFacilitySystem(FacilitySystem facilitySystem) {
        service.loadFacilitySystem(facilitySystem);
    }

    @POST
    @Path("/addFacilitySubsystem")
    public FacilitySubsystem addFacilitySubsystem(FacilitySubsystem facilitySubsystem) {
        return service.addFacilitySubsystem(facilitySubsystem);
    }

    @POST
    @Path("/updateFacilitySubsystem")
    public FacilitySubsystem updateFacilitySubsystem(FacilitySubsystem facilitySubsystem) {
        return service.updateFacilitySubsystem(facilitySubsystem);
    }

    @POST
    @Path("/deleteFacilitySubsystem")
    public void deleteFacilitySubsystem(String facilitySubsystemId) {
        service.deleteFacilitySubsystem(facilitySubsystemId);
    }

    @GET
    @Path("/deleteFacilitySubsystemById")
    public void deleteFacilitySubsystemById(@NotNull @QueryParam("facilitySubsystemId") String facilitySubsystemId) {
        // Version to be called as part of a data load...skips scoping check
        service.deleteFacilitySubsystemById(facilitySubsystemId);
    }

    @GET
    @Path("/getAllFacilitySubsystems")
    public List<FacilitySubsystem> getAllFacilitySubsystems() {
        return service.getAllFacilitySubsystems();
    }

    @POST
    @Path("/addFacilitySystem")
    public FacilitySystem addFacilitySystem(FacilitySystem facilitySystem) {
        return service.addFacilitySystem(facilitySystem);
    }

    @POST
    @Path("/updateFacilitySystem")
    public FacilitySystem updateFacilitySystem(FacilitySystem facilitySystem) {
        return service.updateFacilitySystem(facilitySystem);
    }

    @POST
    @Path("/deleteFacilitySystem")
    public void deleteFacilitySystem(String facilitySystemId) {
        service.deleteFacilitySystem(facilitySystemId);
    }

    @GET
    @Path("/deleteFacilitySystemById")
    public void deleteFacilitySystemById(@NotNull @QueryParam("facilitySystemId") String facilitySystemId) {
        // Version to be called as part of a data load...skips scoping check
        service.deleteFacilitySystemById(facilitySystemId);
    }

    @GET
    @Path("/getAllFacilitySystems")
    public List<FacilitySystem> getAllFacilitySystems() {
        return service.getAllFacilitySystems();
    }

    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadFile(
            @ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        InputStream inputStream;
        byte[] content;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new FatalProcessingException(
                    "Was not able to extract file from request " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxUploadSize();

        if (content.length > maxUploadSize) {
            throw new FatalProcessingException(
                    "Uploaded file size exceeds server max POST Size value  of " + maxUploadSize
                            + " bytes");
        }

        return service.uploadFile(content, uploadedFileName);
    }

    @POST
    @Path("/saveAttachment")
    public Attachment saveAttachment(@QueryParam("id") String id, Attachment attachmentToSave) {
        return service.saveAttachment(id, attachmentToSave);
    }

    @GET
    @Path("/getMaxUploadSize")
    public Integer getMaxUploadSize() {
        return service.getMaxUploadSize();
    }

    @GET
    @Path("/removeAttachment")
    public List<Attachment> removeAttachment(@QueryParam("id") String id, @QueryParam("fileId") String fileId)
            throws IOException {
        return service.removeAttachment(id, fileId);
    }

    @POST
    @Path("/saveToolsAndMaterials")
    public MaintenanceProcedure saveToolsAndMaterials(@QueryParam("id") String id, List<ToolsAndMaterial> toolsAndMaterials) {
        return service.saveToolsAndMaterials(id, toolsAndMaterials);
    }

    @POST
    @Path("/saveResources")
    public MaintenanceProcedure saveResources(@QueryParam("id") String id, List<Resource> resources) {
        return service.saveResources(id, resources);
    }

    @POST
    @Path("/saveReview")
    public MaintenanceProcedure saveReview(@QueryParam("id") String id, Review review) {
        return service.saveReview(id, review);
    }

    @POST
    @Path("/saveProcedureHeader")
    public MaintenanceProcedure saveProcedureHeader(MaintenanceProcedure procedure) {
        return service.saveProcedureHeader(procedure);
    }

    @POST
    @Path("/addFrequency")
    public Frequency addFrequency(Frequency frequency) {
        return service.addFrequency(frequency);
    }

    @POST
    @Path("/updateFrequency")
    public Frequency updateFrequency(Frequency frequency) {
        return service.updateFrequency(frequency);
    }

    @POST
    @Path("/deleteFrequency")
    public void deleteFrequency(Frequency frequency) {
        service.deleteFrequency(frequency);
    }


    @GET
    @Path("/getAllFrequencyRefs")
    public List<FrequencyRef> getAllFrequencyRefs() {
        return service.getAllFrequencyRefs();
    }

    @GET
    @Path("/getMaintenanceProcedureSummaryById")
    public MaintenanceProcedureSummary getMaintenanceProcedureSummaryById(@QueryParam("id") String id) {
        return service.getMaintenanceProcedureSummaryById(id);
    }

    @POST
    @Path("/saveTasks")
    public MaintenanceProcedure saveTasks(@QueryParam("id") String id, List<String> tasks) {
        return service.saveTasks(id, tasks);
    }

    @POST
    @Path("/saveSafety")
    public MaintenanceProcedure saveSafety(@QueryParam("id") String id, String editSafety) {
        return service.saveSafety(id, editSafety);
    }


    @POST
    @Path("/addSkill")
    public Skill addSkill(Skill skill) {
        return service.addSkill(skill);

    }

    @POST
    @Path("/updateSkill")
    public Skill updateSkill(Skill skill) {
        return service.updateSkill(skill);
    }

    @POST
    @Path("/deleteSkill")
    public void deleteSkill(String skillId) {
        service.deleteSkill(skillId);
    }

    @GET
    @Path("/deleteSkillById")
    public void deleteSkillById(@NotNull @QueryParam("skillId") String skillId) {
        // Version to be called as part of a data load...skips scoping check
        service.deleteSkillById(skillId);
    }

    @POST
    @Path("/loadSkill")
    public void loadSkill(Skill skill) {
        service.loadSkill(skill);
    }

    @GET
    @Path("/getAllSkills")
    public List<Skill> getAllSkills() {
        return service.getAllSkills();
    }

    @POST
    @Path("/saveNote")
    public MaintenanceProcedure saveNote(@QueryParam("id") String id, Note note) {
        return service.saveNote(id, note);
    }

    @POST
    @Path("/removeNote")
    public MaintenanceProcedure removeNote(@QueryParam("id") String id, Note note) {
        return service.removeNote(id, note);
    }

    @POST
    @Path("/saveInspection")
    public MaintenanceProcedure saveInspection(@QueryParam("id") String id, @QueryParam("candidate") String candidate, String notes) {
        return service.saveInspection(id, candidate, notes);
    }

    @GET
    @Path("/getItemRecipients")
    public List<ItemRecipient> getItemRecipients() {
        return service.getItemRecipients();
    }

    @GET
    @Path("/getProceduresByAuthoritativeSourceId")
    public List<MaintenanceProcedure> getProceduresByAuthoritativeSourceId(@NotNull @QueryParam("id") String id) {
        return service.getProceduresByAuthoritativeSourceId(id);
    }

    @GET
    @Path("/getProcedureTypes")
    public List<ProcedureTypeEntry> getProcedureTypes() {
        return service.getProcedureTypes();
    }

    @POST
    @Path("/addRegulatoryComplianceAction")
    public RegulatoryComplianceAction addRegulatoryComplianceAction(RegulatoryComplianceAction action) {
        return service.addRegulatoryComplianceAction(action);
    }

    @POST
    @Path("/updateRegulatoryComplianceAction")
    public RegulatoryComplianceAction updateRegulatoryComplianceAction(RegulatoryComplianceAction action) {
        return service.updateRegulatoryComplianceAction(action);
    }

    @POST
    @Path("/deleteRegulatoryComplianceAction")
    public void deleteRegulatoryComplianceAction(String actionId) {
        service.deleteRegulatoryComplianceAction(actionId);
    }

    @GET
    @Path("/getRegulatoryComplianceActions")
    public List<RegulatoryComplianceAction> getRegulatoryComplianceActions() {
        return service.getRegulatoryComplianceActions();
    }

    @POST
    @Path("/addRegulatoryComplianceCode")
    public RegulatoryComplianceCode addRegulatoryComplianceCode(RegulatoryComplianceCode code) {
        return service.addRegulatoryComplianceCode(code);
    }

    @POST
    @Path("/updateRegulatoryComplianceCode")
    public RegulatoryComplianceCode updateRegulatoryComplianceCode(RegulatoryComplianceCode code) {
        return service.updateRegulatoryComplianceCode(code);
    }

    @POST
    @Path("/deleteRegulatoryComplianceCode")
    public void deleteRegulatoryComplianceCode(String codeId) {
        service.deleteRegulatoryComplianceCode(codeId);
    }

    @GET
    @Path("/getRegulatoryComplianceCodes")
    public List<RegulatoryComplianceCode> getRegulatoryComplianceCodes() {
        return service.getRegulatoryComplianceCodes();
    }

    @GET
    @Path("/getRegulatoryComplianceSubjects")
    public List<RegulatoryComplianceSubject> getRegulatoryComplianceSubjects() {
        return service.getRegulatoryComplianceSubjects();
    }

    @GET
    @Path("/procedureIdentifierExists")
    @Produces(MediaType.TEXT_PLAIN)
    public boolean procedureIdentifierExists(@NotNull @QueryParam("procedureIdentifier") String procedureIdentifier) {
        return service.procedureIdentifierExists(procedureIdentifier);
    }

    @GET
    @Path("/schedulesExistForMaintenanceProcedure")
    public boolean schedulesExistForMaintenanceProcedure(@NotNull @QueryParam("maintenanceProcedureId") String maintenanceProcedureId) {
        return service.schedulesExistForMaintenanceProcedure(maintenanceProcedureId);
    }

    @GET
    @Path("/getEProcedureOccupancyTypes")
    public List<String> getEProcedureOccupancyTypes() {
        return service.getEProcedureOccupancyTypes();
    }

    @GET
    @Path("/getAllNomenclatureRefs")
    public List<NomenclatureRef> getAllNomenclatureRefs() {
        return service.getAllNomenclatureRefs();
    }

    @GET
    @Path("/getNomenclatureById")
    public Nomenclature getNomenclatureById(@QueryParam("id") String id) {
        return service.getNomenclatureById(id);
    }
}
