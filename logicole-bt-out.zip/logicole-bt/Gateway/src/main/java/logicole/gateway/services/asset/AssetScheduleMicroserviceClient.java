package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetScheduleMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AssetScheduleMicroserviceClient extends MicroserviceClient<IAssetScheduleMicroserviceApi> {
    public AssetScheduleMicroserviceClient() {
        super(IAssetScheduleMicroserviceApi.class, "logicole-asset");
    }

    @Produces
    public IAssetScheduleMicroserviceApi getIAssetMicroserviceApi() {
        return createClient();
    }
}
