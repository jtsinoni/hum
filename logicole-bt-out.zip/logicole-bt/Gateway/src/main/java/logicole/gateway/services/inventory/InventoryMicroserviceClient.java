package logicole.gateway.services.inventory;

import logicole.apis.inventory.IInventoryMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class InventoryMicroserviceClient extends MicroserviceClient<IInventoryMicroserviceApi> {
    public InventoryMicroserviceClient(){
        super(IInventoryMicroserviceApi.class, "logicole-inventory");
    }

    @Produces
    public IInventoryMicroserviceApi getIInventoryMicroserviceApi() {
        return createClient();
    }

}
