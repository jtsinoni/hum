package logicole.gateway.services.asset;

import logicole.apis.asset.IAssetGroupMicroserviceApi;
import logicole.common.datamodels.asset.classification.NomenclatureRef;
import logicole.common.datamodels.asset.management.AssetGroup;
import logicole.common.datamodels.asset.management.AssetGroupRef;
import logicole.common.datamodels.asset.management.EQaQcInspectionMethod;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.organization.Organization;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.realproperty.InstallationRef;
import logicole.common.datamodels.realproperty.SiteRef;
import logicole.common.datamodels.realproperty.facility.Facility;
import logicole.common.datamodels.realproperty.facility.FacilityRef;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.asset.validation.AssetGroupValidator;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.realproperty.FacilityService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import java.util.List;

@ApplicationScoped
public class AssetGroupService extends BaseGatewayService<IAssetGroupMicroserviceApi> {
    @Inject
    AssetService assetService;

    @Inject
    FacilityService facilityService;

    @Inject
    OrganizationService organizationService;

    @Inject
    AssetGroupValidator assetGroupValidator;

    @Inject
    AssetScheduleService assetScheduleService;

    public AssetGroupService() {
        super("Asset");
    }

    public List<AssetGroupRef> getMedicalEquipmentAssetGroupRefs() {
        return microservice.getMedicalEquipmentAssetGroupRefs();
    }

    public List<AssetGroupRef> getRealPropertyEquipmentAssetGroupRefs(String nomenclatureId, String facilityId) {
        return microservice.getRealPropertyEquipmentAssetGroupRefs(nomenclatureId, facilityId);
    }

    public AssetGroup getAssetGroupById(String assetGroupId) {
        return microservice.getAssetGroupById(assetGroupId);
    }

    public AssetGroupRef getAssetGroupRefById(String assetGroupId) {
        return microservice.getAssetGroupRefById(assetGroupId);
    }

    public SearchResult<AssetGroup> getAssetGroupSearchResults(SearchInput searchInput) {
        ESearchEngine searchEngine = microservice.getAssetGroupSearchEngine();
        if (searchEngine.equals(ESearchEngine.ELASTIC)) {
            throw new ApplicationException("Elastic search is not supported at this time.");
        } else {
            organizationService.setRPFuncFilterInSearch(searchInput);
            return microservice.getAssetGroupSearchResults(searchInput);
        }
    }

    private OrganizationRef getManagedByNodeRef(String facilityId) {
        Facility facility = facilityService.getFacilityById(facilityId);
        Organization node = organizationService.getOrganization(facility.managedByNodeRef.id);
        return node.getRef();
    }

    public AssetGroup saveAssetGroup(@NotNull AssetGroup assetGroup) {
        assetGroupValidator.validateFacilityAndOrganization(assetGroup);

        if (assetGroup.managedByNodeRef == null || StringUtil.isEmptyOrNull(assetGroup.managedByNodeRef.id)) {
            assetGroup.managedByNodeRef = getManagedByNodeRef(assetGroup.facilityRef.id);
        }
        if (assetGroup.qaInspectionMethod == null) {
            assetGroup.qaInspectionMethod = EQaQcInspectionMethod.RANDOM;
        }
        if (assetGroup.qcInspectionMethod == null) {
            assetGroup.qcInspectionMethod = EQaQcInspectionMethod.RANDOM;
        }

        assetGroupValidator.validate(assetGroup);

        return microservice.saveAssetGroup(assetGroup);
    }

    public void updateFacilityRefInAssetGroups(FacilityRef facilityRef) {
        microservice.updateFacilityRefInAssetGroups(facilityRef);
    }

    public void updateInstallationRefsInAssetGroups(InstallationRef installationRef) {
        microservice.updateInstallationRefsInAssetGroups(installationRef);
    }

    public void updateInstallationSiteRefsInAssetGroups(SiteRef installationSiteRef) {
        microservice.updateInstallationSiteRefsInAssetGroups(installationSiteRef);
    }

    public void updateNomenclatureRefInAssetGroups(NomenclatureRef nomenclatureRef) {
        microservice.updateNomenclatureRefInAssetGroups(nomenclatureRef);
    }

    public void updateOrganizationRefInAssetGroups(OrganizationRef organizationRef) {
        microservice.updateOrganizationRefInAssetGroups(organizationRef);
    }

    public void deleteAssetGroupById(String assetGroupId) {
        assetScheduleService.scheduleExistsForGroup(assetGroupId);
        microservice.deleteAssetGroupById(assetGroupId);
    }

    public AssetGroup addAssetsToAssetGroup(String assetGroupId, List<String> assetIdList) {
        return assetService.addAssetsToAssetGroup(assetGroupId, assetIdList);
    }

    public AssetGroup removeAssetsFromAssetGroup(String assetGroupId, List<String> assetIdList) {
        return assetService.removeAssetsFromAssetGroup(assetGroupId, assetIdList);
    }

    public List<AssetGroup> getAssetGroupsByFacilityId(String facilityId) {
        return microservice.getAssetGroupsByFacilityId(facilityId);
    }

    public List<AssetGroup> getAssetGroupsByFacilityIdAndNomenclatureId(String facilityId, String nomenclatureId) {
        return microservice.getAssetGroupsByFacilityIdAndNomenclatureId(facilityId, nomenclatureId);
    }

    public void validateUniqueIndex(AssetGroup assetGroup) {
        if (microservice.getAssetGroupCountByUniqueIndex(assetGroup) > 0) {
            throw new ApplicationException("An Equipment Group with the name " + assetGroup.assetGroupName + " in facility " + assetGroup.facilityRef.facilityNumber + " - " + assetGroup.facilityRef.name + " already exists.");
        }
    }

    public void syncFacilityManagedByNodeRef(String facilityId, OrganizationRef managedBy) {
    	microservice.syncFacilityManagedByNodeRef(facilityId, managedBy);
    }
}
