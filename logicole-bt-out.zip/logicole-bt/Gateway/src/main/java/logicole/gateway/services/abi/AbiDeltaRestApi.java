package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import logicole.common.datamodels.abi.delta.*;
import logicole.common.general.exception.ObjectNotFoundException;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.List;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi/delta")
public class AbiDeltaRestApi extends ExternalRestApi<AbiDeltaService> {

    @GET
    @Path("/getDeltaUpdateInformation")
    public DeltaUpdateInformation getDeltaUpdateInformation(@QueryParam("deltaRecordId") String deltaRecordId) {
        return service.getDeltaUpdateInformation(deltaRecordId);
    }

    @POST
    @Path("/updateRecord")
    public DeltaRecord updateRecord(DeltaRecord updatedRecord) throws ObjectNotFoundException {
        return service.updateRecord(updatedRecord);
    }

    @POST
    @Path("/insertStagingRecord")
    public boolean insertStagingRecord(DeltaRecord deltaRecord) {
        return service.insertStagingRecord(deltaRecord);
    }

    @POST
    @Path("/updateStagingRecord")
    public boolean updateStagingRecord(@QueryParam("stagingRecordId") String stagingRecordId, DeltaRecord updatedRecord) {
        return service.updateStagingRecord(stagingRecordId, updatedRecord);
    }

    @GET
    @Path("/discardDeltaRecord")
    public boolean discardDeltaRecord(@QueryParam("deltaRecordId") String deltaRecordId) {
        return service.discardDeltaRecord(deltaRecordId);
    }

    @GET
    @Path("/getDeltaRecordCounts")
    public DeltaRecordCounts getDeltaRecordCounts() {
        return service.getDeltaRecordCounts();
    }

    @GET
    @Path("/searchRecords")
    public List<DeltaRecord> searchRecords(
            @QueryParam("filterData") String filterData) {
        return service.searchRecords(filterData);
    }

    @GET
    @Path("/getDeltaRequestStatusList")
    public List<DeltaRequestStatus> getDeltaRequestStatusList() {
        return service.getDeltaRequestStatusList();
    }

    @GET
    @Path("/deleteDeltaRequest")
    public Integer deleteDeltaRequest(@QueryParam("deltaRequestId") String deltaRequestId) {
        return service.deleteDeltaRequest(deltaRequestId);
    }

    @GET
    @Path("/deletePriorDeltaRequests")
    public Long deletePriorDeltaRequests(@QueryParam("olderThanDays") Integer olderThanDays) {
        return service.deletePriorDeltaRequests(olderThanDays);
    }

    @GET
    @Path("/autoMoveDeltaToStaging")
    public DeltaRequestResponse autoMoveDeltaToStaging() {
        return service.autoMoveDeltaToStaging();
    }

    @GET
    @Path("/getPriorDeltaRequestCount")
    public Long getPriorDeltaRequestCount(@QueryParam("olderThanDays") Integer olderThanDays) {
        return service.getPriorDeltaRequestCount(olderThanDays);
    }

    @POST
    @Path("/applyFormatting")
    public DeltaRecord applyFormatting(DeltaRecord updatedRecord) {
        return (DeltaRecord) service.applyFormatting(updatedRecord);
    }

}
