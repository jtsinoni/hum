package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiConfigurationMicroserviceApi;
import logicole.gateway.rest.MicroserviceClient;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class AbiConfigurationMicroserviceClient extends MicroserviceClient<IAbiConfigurationMicroserviceApi> {
    public AbiConfigurationMicroserviceClient() {
        super(IAbiConfigurationMicroserviceApi.class, "logicole-abi");
    }

    @Produces
    public IAbiConfigurationMicroserviceApi getABiConfigurationService() {
        return createClient();
    }
}

