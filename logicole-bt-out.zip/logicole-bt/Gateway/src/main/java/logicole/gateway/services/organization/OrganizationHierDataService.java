package logicole.gateway.services.organization;

import logicole.apis.organization.IOrganizationHierDataMicroserviceApi;
import logicole.common.datamodels.general.EHDataType;
import logicole.common.datamodels.general.HDataType;
import logicole.common.datamodels.general.HierData;
import logicole.common.general.util.JSONUtil;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;

@ApplicationScoped
public class OrganizationHierDataService extends BaseGatewayService<IOrganizationHierDataMicroserviceApi> {
    @Inject
    JSONUtil jsonUtil;

    public OrganizationHierDataService() {
        super("Organization Hier Data");
    }

    public <T> void setHierDataValue(String nodeId, EHDataType dataType, List<T> t) {
        String jsonValue = jsonUtil.trySerialize(t);
        microservice.setHierDataRawValue(nodeId,dataType, jsonValue);
    }

    public void setHierDataRawValue(String nodeId, EHDataType dataType, String jsonValue) {
        microservice.setHierDataRawValue(nodeId,dataType, jsonValue);
    }

    public void clearData(String nodeId, EHDataType dataType) {
        microservice.clearData(nodeId, dataType);
    }

    public HierData getHierData(String nodeId, EHDataType dataType) {
        return microservice.getHierData(nodeId, dataType);
    }

    public <T> T getHierDataValue(String nodeId, EHDataType dataType) {
        String jsonValue = microservice.getHierDataRawValue(nodeId, dataType);
        return (T)jsonUtil.tryDeserialize(jsonValue, dataType.clazz);
    }

    public String getHierDataRawValue(String nodeId, EHDataType dataType) {
        return microservice.getHierDataRawValue(nodeId, dataType);
    }

    public void removeHierData(String nodeId, EHDataType dataType) {
        microservice.removeHierData(nodeId, dataType);
    }

    public List<HDataType> getHDataTypes() {
        return EHDataType.getValueList();
    }

}
