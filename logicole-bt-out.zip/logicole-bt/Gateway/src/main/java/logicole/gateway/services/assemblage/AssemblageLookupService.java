package logicole.gateway.services.assemblage;

import logicole.apis.assemblage.IAssemblageLookupMicroserviceApi;
import logicole.common.datamodels.assemblage.*;
import logicole.common.datamodels.inventory.Stratification;
import logicole.common.datamodels.inventory.StratificationRef;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.util.string.StringUtil;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.inventory.InventoryService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.user.UserService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@ApplicationScoped
public class AssemblageLookupService  extends BaseGatewayService<IAssemblageLookupMicroserviceApi> {

    @Inject
    OrganizationService organizationService;
    @Inject
    UserService userService;
    @Inject
    InventoryService inventoryService;

    public AssemblageLookupService() {
        super("Assemblage");
    }

    public List<CommingledCode> getCommingledCodes() {
        UserProfile currentUser = currentUserBT.getCurrentUser().profile;

        return microservice.getCommingledCodes(currentUser.currentNodeRef);
    }

    public List<CommingledCode> createCommingledCode(CommingledCode commingledCode) {
        commingledCode.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;

        return microservice.createCommingledCode(commingledCode);
    }

    public List<CommingledCode> updateCommingledCode(CommingledCode commingledCode) {
        commingledCode.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.updateCommingledCode(commingledCode);
    }

    public List<CommingledCode> deleteCommingledCode(CommingledCode commingledCode) {
        return microservice.deleteCommingledCode(commingledCode);
    }

    public List<CriticalCode> getCriticalCodes() {
        UserProfile currentUser = currentUserBT.getCurrentUser().profile;

        return microservice.getCriticalCodes(currentUser.currentNodeRef);
    }

    public List<String> getCriticalCodesAsList() {
        UserProfile currentUser = currentUserBT.getCurrentUser().profile;

        List<String> codes = new ArrayList<>();

        List<CriticalCode> criticalCodes = microservice.getCriticalCodes(currentUser.currentNodeRef);

        for (CriticalCode criticalCode : criticalCodes) {
            codes.add(criticalCode.code);
        }

        return codes;
    }

    public List<CriticalCode> createCriticalCode(CriticalCode criticalCode) {
        criticalCode.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;

        return microservice.createCriticalCode(criticalCode);
    }

    public List<CriticalCode> updateCriticalCode(CriticalCode criticalCode) {
        criticalCode.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.updateCriticalCode(criticalCode);
    }

    public List<CriticalCode> deleteCriticalCode(CriticalCode criticalCode) {
        return microservice.deleteCriticalCode(criticalCode);
    }

    public List<DeferredCode> getDeferredCodes() {
        UserProfile currentUser = currentUserBT.getCurrentUser().profile;
        return microservice.getDeferredCodes(currentUser.currentNodeRef);
    }

    public List<DeferredCode> createDeferredCode(DeferredCode deferredCode) {
        deferredCode.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.createDeferredCode(deferredCode);
    }

    public List<DeferredCode> updateDeferredCode(DeferredCode deferredCode) {
        deferredCode.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.updateDeferredCode(deferredCode);
    }

    public List<DeferredCode> deleteDeferredCode(DeferredCode deferredCode) {
        return microservice.deleteDeferredCode(deferredCode);
    }

    public List<OperationalStatus> getOperationalStatuses() {
        return microservice.getOperationalStatuses();
    }

    public List<EquipmentReportingCodeRef> getEquipmentReportingCodes() {
        return microservice.getEquipmentReportingCodes().stream().map(EquipmentReportingCode::getRef).collect(Collectors.toList());
    }

    public List<Scope> getScopes() {
        return microservice.getScopes();
    }

    public List<Managed> getManaged() {
        return microservice.getManaged();
    }

    public List<Customer> getCustomers() {
        return microservice.getCustomers();
    }

    public List<ExpenseCenter> getExpenseCenters() {
        return microservice.getExpenseCenters();
    }

    public List<EquipmentReportingCode> getEquipmentReportingCodesAll() {
        UserProfile currentUser = currentUserBT.getCurrentUser().profile;
        return microservice.getEquipmentReportingCodesAll(currentUser.currentNodeRef);
    }

    public EquipmentReportingCodeRef getEquipmentReportingCodeByCode(String equipmentReportingLookupCode) {
        EquipmentReportingCode equipmentReportingCode  = microservice.getEquipmentReportingCodeByCode(equipmentReportingLookupCode);

        return equipmentReportingCode != null ?  equipmentReportingCode.getRef() : null;
    }

    public List<EquipmentReportingCode> createEquipmentReportingCode(EquipmentReportingCode equipmentReportingCode) {
        equipmentReportingCode.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.createEquipmentReportingCode(equipmentReportingCode);
    }

    public List<EquipmentReportingCode> updateEquipmentReportingCode(EquipmentReportingCode equipmentReportingCode) {
        equipmentReportingCode.managedByNodeRef = currentUserBT.getCurrentUser().profile.currentNodeRef;
        return microservice.updateEquipmentReportingCode(equipmentReportingCode);
    }

    public List<EquipmentReportingCode> deleteEquipmentReportingCode(EquipmentReportingCode equipmentReportingCode) {
        return microservice.deleteEquipmentReportingCode(equipmentReportingCode);
    }

    public AssociatedOrganizationRef getAssociatedOrganizationRefByCode(String associatedOrganizationCode) {
        AssociatedOrganization associatedOrganization = microservice.getAssociatedOrganizationByCode(associatedOrganizationCode);
        if (null == associatedOrganization) {
            associatedOrganization = microservice.getAssociatedOrganizationByCode("OT");
        }
        return associatedOrganization.getRef();
    }

    public List<AssociatedOrganizationRef> getAssociatedOrganizationRefs() {
        return microservice.getAssociatedOrganizationRefs();
    }

    public List<OrganizationRef> getOrganizationRefByAgencyAndType(String targetTypeName) {
        return organizationService.getOrganizationRefByAgencyAndType(targetTypeName);
    }

    public List<String> getAllowanceStandardManagerInformation(String name) {
        return userService.getUserEmailAndPhoneByName(name);
    }

    public List<StratificationRef> getStratificationRefs() {
        return inventoryService.getStratificationsByModule("Assemblage").stream().map(Stratification::getRef).collect(Collectors.toList());
    }

    public List<Priority> getPriorityOptions() {
        return microservice.getPriorityOptions();
    }

    public List<Shipper> getShipperOptions() {
        return microservice.getShipperOptions();
    }

    public List<Status> getStatusOptions() {
        return microservice.getStatusOptions();
    }

    public List<Capability> getCapabilityOptions() {
        return microservice.getCapabilityOptions();
    }

    public List<RoleOfCare> getRoleOfCareOptions() {
        return microservice.getRoleOfCareOptions();
    }

    public List<AssemblageType> getAssemblageTypeOptions() {
        return microservice.getAssemblageTypeOptions();
    }

    public List<PackType> getPackTypeOptions() {
        return microservice.getPackTypeOptions();
    }
}
