package logicole.gateway.services.user;

import io.swagger.annotations.*;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.userRequest.*;
import logicole.common.datamodels.user.UserRequirement;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.FatalProcessingException;
import logicole.common.general.util.MultiPartFormUtil;
import logicole.gateway.rest.ExternalRestApi;
import org.apache.commons.io.IOUtils;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.InputPart;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

@Api(tags = {"UserRequest"})
@ApplicationScoped
@Path("/userRequest")
public class UserRequestRestApi extends ExternalRestApi<UserRequestService> {

    @Inject
    private MultiPartFormUtil uploadUtil;
    @Inject
    private UserRequestService userRequestService;

    @POST
    @Path("/saveUserRequest")
    public UserRequest saveUserRequest(UserRequest userRequest){
        return service.saveUserRequest(userRequest);
    }

    @POST
    @Path("/saveNewUserRequest")
    public UserRequest saveNewUserRequest(@QueryParam("userRequestId") String userRequestId, UserRequest userRequest) {
        return service.saveNewUserRequest(userRequestId, userRequest);
    }

    @GET
    @Path("/getUserRequestById")
    public UserRequest getUserRequestById(@QueryParam("userRequestId") String userRequestId) {
        return service.getUserRequestById(userRequestId);
    }

    @GET
    @Path("/getUserRequestDetailsById")
    public UserRequestDTO getUserRequestDetailsById(@QueryParam("userRequestId") String userRequestId) {
        return service.getUserRequestDetailsById(userRequestId);
    }

    @GET
    @Path("/getUserRequestDetailsByIdForCandidate")
    public UserRequestDTO getUserRequestDetailsByIdForCandidate(@QueryParam("userRequestId") String userRequestId) {
        return service.getUserRequestDetailsByIdForCandidate(userRequestId);
    }

    @GET
    @Path("/setUserRequestPkiDn")
    public UserRequestDTO setUserRequestPkiDn(@QueryParam("userRequestId") String userRequestId) {
        return service.setUserRequestPkiDn(userRequestId);
    }

    @GET
    @Path("/getAllUserRequests")
    public List<UserRequest> getAllUserRequests(@QueryParam("userRequestState") String userRequestState) throws IllegalAccessException {
        return service.getAllUserRequests(userRequestState);
    }

    @GET
    @Path("/getUserRequestDashboardStats")
    public UserRequestInfo getUserRequestDashboardStats() {
        return service.getUserRequestDashboardStats();
    }

    @GET
    @Path("/generateUserRequestId")
    @Produces(MediaType.TEXT_PLAIN)
    public String generateUserRequestId() {
        return service.generateUserRequestId();
    }

    @POST
    @Path("/saveUserRequestIdentification")
    public UserRequest saveUserRequestIdentification(@QueryParam("userRequestId") String userRequestId, UserRequest userRequest) {
        return service.saveUserRequestIdentification(userRequestId, userRequest);
    }

    @POST
    @Path("/saveUserRequestIdentificationForCandidate")
    public UserRequestDTO saveUserRequestIdentificationForCandidate(@QueryParam("userRequestId") String userRequestId, UserRequest userRequest) {
        return service.saveUserRequestIdentificationForCandidate(userRequestId, userRequest);
    }

    @GET
    @Path("/getParticipantsForUserRequest")
    public List<ParticipantDetailsDTO> getParticipantsForUserRequest(@QueryParam("userRequestId") String userRequestId) {
        return service.getParticipantsForUserRequest(userRequestId);
    }

    @GET
    @Path("/sendUserRequestEmail")
    public Boolean sendUserRequestEmail(@QueryParam("userRequestId") String userRequestId,
                                        @QueryParam("fromState") UserRequest.EState fromState,
                                        @QueryParam("toState") UserRequest.EState toState) {
        return service.sendUserRequestEmail(userRequestId, fromState, toState);
    }

    @POST
    @Path("/saveUserRequestExpirationDate")
    public UserRequest saveUserRequestExpirationDate(@QueryParam("userRequestId") String userRequestId, @NotNull Date expirationDate) {
        return service.saveUserRequestExpirationDate(userRequestId, expirationDate);
    }

    @GET
    @Path("/assignPrimaryAccessManager")
    public UserRequest assignPrimaryAccessManager(@QueryParam("userRequestId") String userRequestId) {
        return service.assignPrimaryAccessManager(userRequestId);
    }

    @GET
    @Path("/unassignPrimaryAccessManager")
    public UserRequest unassignPrimaryAccessManager(@QueryParam("userRequestId") String userRequestId) {
        return service.unassignPrimaryAccessManager(userRequestId);
    }

    @GET
    @Path("/declineUserRequestByCandidate")
    public UserRequestDTO declineUserRequestByCandidate(@QueryParam("userRequestId") String userRequestId, @QueryParam("reason") String reason) {
        return service.declineUserRequestByCandidate(userRequestId, reason);
    }

    @GET
    @Path("/cancelUserRequest")
    public UserRequest cancelUserRequest(@QueryParam("userRequestId") String userRequestId, @NotNull @QueryParam("reason") String reason) {
        return userRequestService.cancelUserRequest(userRequestId, reason);
    }

    @POST
    @Path("/saveUserRequestAccess")
    public UserRequest saveUserRequestAccess(@QueryParam("userRequestId") String userRequestId, UserRequest userRequest) {
        return userRequestService.saveUserRequestAccess(userRequestId, userRequest);
    }

    @POST
    @Path("/saveUserRequestRoles")
    public UserRequest saveUserRequestRoles(@QueryParam("userRequestId") String userRequestId, UserRequest userRequest) {
        return userRequestService.saveUserRequestRoles(userRequestId, userRequest);
    }

    @POST
    @Path("/saveUserRequestAssignableRoles")
    public UserRequest saveUserRequestAssignableRoles(@QueryParam("userRequestId") String userRequestId, UserRequest userRequest) {
        return userRequestService.saveUserRequestAssignableRoles(userRequestId, userRequest);
    }

    @POST
    @Path("/saveUserRequestRequirementAttachment")
    public UserRequirement saveUserRequestRequirementAttachment(@QueryParam("userRequestId") String userRequestId, UserRequirement requirement) {
        return userRequestService.saveUserRequestRequirementAttachment(userRequestId, requirement);
    }

    @POST
    @Path("/saveUserRequestRequirementAttachmentForCandidate")
    public UserRequirement saveUserRequestRequirementAttachmentForCandidate(@QueryParam("userRequestId") String userRequestId, UserRequirement requirement) {
        return userRequestService.saveUserRequestRequirementAttachmentForCandidate(userRequestId, requirement);
    }

    @GET
    @Path("/removeUserRequestRequirementAttachment")
    public UserRequirement removeUserRequestRequirementAttachment(@QueryParam("userRequestId") String userRequestId, @QueryParam("requirementId") String requirementId, @QueryParam("fileId") String fileId) throws IOException {
        return service.removeUserRequestRequirementAttachment(userRequestId, requirementId, fileId);
    }

    @GET
    @Path("/removeUserRequestRequirementAttachmentForCandidate")
    public UserRequirement removeUserRequestRequirementAttachmentForCandidate(@QueryParam("userRequestId") String userRequestId, @QueryParam("requirementId") String requirementId, @QueryParam("fileId") String fileId) throws IOException {
        return service.removeUserRequestRequirementAttachmentForCandidate(userRequestId, requirementId, fileId);
    }

    @GET
    @Path("/sendToAccessManagerForReview")
    public UserRequest sendToAccessManagerForReview(@QueryParam("userRequestId") String userRequestId) {
        return userRequestService.sendToAccessManagerForReview(userRequestId);
    }

    @GET
    @Path("/sendToSupervisorForRework")
    public UserRequest sendToSupervisorForRework(@QueryParam("userRequestId") String userRequestId) {
        return userRequestService.sendToSupervisorForRework(userRequestId);
    }

    @GET
    @Path("/withdrawFromAccessManagerForSupervisorRework")
    public UserRequest withdrawFromAccessManagerForSupervisorRework(@QueryParam("userRequestId") String userRequestId) {
        return userRequestService.withdrawFromAccessManagerForSupervisorRework(userRequestId);
    }

    @GET
    @Path("/sendToCandidateForCompletion")
    public UserRequest sendToCandidateForCompletion(@QueryParam("userRequestId") String userRequestId) {
        return userRequestService.sendToCandidateForCompletion(userRequestId);
    }

    @GET
    @Path("/withdrawFromCandidate")
    public UserRequest withdrawFromCandidate(@QueryParam("userRequestId") String userRequestId) {
        return userRequestService.withdrawFromCandidate(userRequestId);
    }

    @GET
    @Path("/sendToAccessManagerForRequirementVerification")
    public UserRequestDTO sendToAccessManagerForRequirementVerification(@QueryParam("userRequestId") String userRequestId) {
        return userRequestService.sendToAccessManagerForRequirementVerification(userRequestId);
    }

    @GET
    @Path("/rejectByAccessManager")
    public UserRequest rejectByAccessManager(@QueryParam("userRequestId") String userRequestId, @NotNull @QueryParam("reason") String reason) {
        return userRequestService.rejectByAccessManager(userRequestId, reason);
    }

    @GET
    @Path("/activateBySupervisor")
    public UserRequest activateBySupervisor(@QueryParam("userRequestId") String userRequestId) {
        return userRequestService.activateBySupervisor(userRequestId);
    }

    @GET
    @Path("/approveByAccessManager")
    public UserRequest approveByAccessManager(@QueryParam("userRequestId") String userRequestId) {
        return userRequestService.approveByAccessManager(userRequestId);
    }

    @GET
    @Path("/sendBackToRequirementVerification")
    public UserRequest sendBackToRequirementVerification(@QueryParam("userRequestId") String userRequestId) {
        return userRequestService.sendBackToRequirementVerification(userRequestId);
    }

    @POST
    @Path("/addUserRequestComment")
    public UserRequest addUserRequestComment(@QueryParam("userRequestId") String userRequestId,
                                             String comment) {
        return userRequestService.addUserRequestComment(userRequestId, comment);
    }

    @GET
    @Path("/removeUserRequestComment")
    public UserRequest removeUserRequestComment(@QueryParam("userRequestId") String userRequestId,
                                                @QueryParam("commentId") String commentId) {
        return userRequestService.removeUserRequestComment(userRequestId, commentId);
    }

    @GET
    @Path("/getMaxUploadSize")
    public Integer getMaxUploadSize() {
        return userRequestService.getMaxUploadSize();
    }

    @POST
    @Path("/uploadFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Upload a file")
    @ApiImplicitParams(
            {
                    @ApiImplicitParam(value = "Select a file to upload",
                            dataType = "java.io.File", name = "file",
                            paramType = "formData", required = true)
            })
    public FileManager uploadFile(
            @ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form)
            throws ApplicationException {
        InputStream inputStream;
        byte[] content;
        InputPart inputPart = uploadUtil.getInputPart(form, "file");
        String uploadedFileName = uploadUtil.getFileName(inputPart.getHeaders());

        try {
            inputStream = inputPart.getBody(InputStream.class, null);
            content = IOUtils.toByteArray(inputStream);
        } catch (IOException ioe) {
            throw new FatalProcessingException(
                    "Was not able to extract file from request " + uploadedFileName);
        }

        Integer maxUploadSize = service.getMaxUploadSize();

        if (content.length > maxUploadSize) {
            throw new FatalProcessingException(
                    "Uploaded file size exceeds server max POST Size value  of " + maxUploadSize
                            + " bytes");
        }

        return service.uploadFile(content, uploadedFileName);
    }

    @GET
    @Path("/getAvailableParticipants")
    public List<ParticipantDetailsDTO> getAvailableParticipants(@QueryParam("userRequestId") String userRequestId,
                                                                @QueryParam("participantType") String participantType) throws IllegalAccessException {
        return service.getAvailableParticipants(userRequestId, participantType);
    }

    @GET
    @Path("/saveNewParticipant")
    public UserRequest saveNewParticipant(@QueryParam("userRequestId") String userRequestId,
                                          @QueryParam("participantType") String participantType,
                                          @QueryParam("userProfileId") String userProfileId) throws IllegalAccessException {
        return service.saveNewParticipant(userRequestId, participantType, userProfileId);
    }

    @GET
    @Path("/removeParticipant")
    public List<UserRequirement> removeParticipant(@QueryParam("userRequestId") String userRequestId,
                                                   @QueryParam("userProfileId") String userProfileId) {
        return service.removeParticipant(userRequestId, userProfileId);
    }

    @GET
    @Path("/reassignRequirementsToPrimaryAccessManager")
    public List<UserRequirement> reassignRequirementsToPrimaryAccessManager(@QueryParam("userRequestId") String userRequestId,
                                                                            @QueryParam("userProfileId") String userProfileId) {
        return service.reassignRequirementsToPrimaryAccessManager(userRequestId, userProfileId);
    }

    @GET
    @Path("/deleteRequirementsAssignedToParticipant")
    public List<UserRequirement> deleteRequirementsAssignedToParticipant(@QueryParam("userRequestId") String userRequestId,
                                                                         @QueryParam("userProfileId") String userProfileId) {
        return service.deleteRequirementsAssignedToParticipant(userRequestId, userProfileId);
    }

    @POST
    @Path("/addUserRequestRequirement")
    public UserRequirement addUserRequestRequirement(@QueryParam("userRequestId") String userRequestId, UserRequirement userRequirement) {
        return userRequestService.addUserRequestRequirement(userRequestId, userRequirement);
    }

    @POST
    @Path("/saveUserRequestRequirement")
    public UserRequirement saveUserRequestRequirement(@QueryParam("userRequestId") String userRequestId, UserRequirement userRequirement) {
        return userRequestService.saveUserRequestRequirement(userRequestId, userRequirement);
    }


    @GET
    @Path("/deleteUserRequestRequirement")
    public UserRequest deleteUserRequestRequirement(@QueryParam("userRequestId") String userRequestId, @QueryParam("requirementId") String requirementId) {
        return userRequestService.deleteUserRequestRequirement(userRequestId, requirementId);
    }

    @GET
    @Path("/acknowledgeTextRequirement")
    public UserRequirement acknowledgeTextRequirement(@QueryParam("requirementId") String requirementId,
                                                      @QueryParam("acknowledge") boolean acknowledge) {
        return userRequestService.acknowledgeTextRequirement(requirementId, acknowledge);
    }

    @GET
    @Path("/acknowledgeTextRequirementForCandidate")
    public UserRequirement acknowledgeTextRequirementForCandidate(@QueryParam("userRequestId") String userRequestId,
                                                                  @QueryParam("requirementId") String requirementId, @QueryParam("acknowledge") boolean acknowledge) {
        return userRequestService.acknowledgeTextRequirementForCandidate(userRequestId, requirementId, acknowledge);
    }

    @GET
    @Path("/completeUserRequestRequirement")
    public UserRequirement completeUserRequestRequirement(@QueryParam("userRequestId") String userRequestId,
                                                          @QueryParam("requirementId") String requirementId) {
        return userRequestService.completeUserRequestRequirement(userRequestId, requirementId);
    }

    @GET
    @Path("/completeUserRequestRequirementForCandidate")
    public UserRequirement completeUserRequestRequirementForCandidate(@QueryParam("userRequestId") String userRequestId,
                                                                      @QueryParam("requirementId") String requirementId) {
        return userRequestService.completeUserRequestRequirementForCandidate(userRequestId, requirementId);
    }

    @GET
    @Path("/reworkUserRequestRequirement")
    public UserRequirement reworkUserRequestRequirement(@QueryParam("userRequestId") String userRequestId,
                                                        @QueryParam("requirementId") String requirementId) {
        return userRequestService.reworkUserRequestRequirement(userRequestId, requirementId);
    }

    @GET
    @Path("/reworkUserRequestRequirementForCandidate")
    public UserRequirement reworkUserRequestRequirementForCandidate(@QueryParam("userRequestId") String userRequestId,
                                                                    @QueryParam("requirementId") String requirementId) {
        return userRequestService.reworkUserRequestRequirementForCandidate(userRequestId, requirementId);
    }

    @GET
    @Path("/verifyUserRequestRequirement")
    public UserRequirement verifyUserRequestRequirement(@QueryParam("userRequestId") String userRequestId,
                                                        @QueryParam("requirementId") String requirementId) {
        return userRequestService.verifyUserRequestRequirement(userRequestId, requirementId);
    }

    @POST
    @Path("/addUserRequestRequirementComment")
    public UserRequirement addUserRequestRequirementComment(@QueryParam("userRequestRequirementId") String userRequestRequirementId,
                                                            String comment) {
        return userRequestService.addUserRequestRequirementComment(userRequestRequirementId, comment);
    }

    @POST
    @Path("/addUserRequestRequirementCommentForCandidate")
    public UserRequirement addUserRequestRequirementCommentForCandidate(@QueryParam("userRequestRequirementId") String userRequestRequirementId,
                                                                        String comment) {
        return userRequestService.addUserRequestRequirementCommentForCandidate(userRequestRequirementId, comment);
    }

    @GET
    @Path("/removeUserRequestRequirementComment")
    public UserRequirement removeUserRequestRequirementComment(@QueryParam("userRequestRequirementId") String userRequestRequirementId,
                                                               @QueryParam("commentId") String commentId) {
        return userRequestService.removeUserRequestRequirementComment(userRequestRequirementId, commentId);
    }

    @GET
    @Path("/removeUserRequestRequirementCommentForCandidate")
    public UserRequirement removeUserRequestRequirementCommentForCandidate(@QueryParam("userRequestRequirementId") String userRequestRequirementId,
                                                                           @QueryParam("commentId") String commentId) {
        return userRequestService.removeUserRequestRequirementCommentForCandidate(userRequestRequirementId, commentId);
    }

    @GET
    @Path("/getDocumentTypes")
    public List<String> getDocumentTypes() {
        return service.getDocumentTypes();
    }
}
