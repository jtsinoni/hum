package logicole.gateway.services.inventory;

import logicole.apis.inventory.IReturnsMicroserviceApi;
import logicole.common.datamodels.inventory.Return.InventoryReturn;
import logicole.common.datamodels.inventory.Return.ReturnType;
import logicole.gateway.common.BaseGatewayService;

import javax.enterprise.context.ApplicationScoped;
import java.util.List;

@ApplicationScoped
public class ReturnsService extends BaseGatewayService<IReturnsMicroserviceApi>  {

    public ReturnsService() {
        super("Returns");
    }

    public InventoryReturn getInventoryReturnById(String inventoryReturnId) {
        return microservice.getReturnRecordById(inventoryReturnId);
    }

    public List<InventoryReturn> getInventoryReturnsByOrgId(String orgId) {
        return microservice.getReturnRecordsByOrgId(orgId);
    }

    public List<ReturnType> getReturnTypes() {
        return microservice.getReturnTypes();
    }

    public InventoryReturn saveReturnInfo(InventoryReturn returnRecord) {
        return microservice.saveReturnInfo(returnRecord);
    }

    public InventoryReturn saveReturnPickupInfo(InventoryReturn returnRecord) {
        return microservice.saveReturnPickupInfo(returnRecord);
    }

    public InventoryReturn saveReturnDispositionInfo(String dispositionType, InventoryReturn returnRecord) {
        return microservice.saveReturnDispositionInfo(dispositionType, returnRecord);
    }

    public InventoryReturn completeReturn(InventoryReturn returnRecord) {
        return microservice.completeReturn(returnRecord);
    }

    public InventoryReturn cancelReturn(InventoryReturn returnRecord) {
        return microservice.cancelReturn(returnRecord);
    }



}
