package logicole.gateway.services.catalog;

import logicole.apis.catalog.ICatalogLookupMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.assemblage.AssemblageItem;
import logicole.common.datamodels.catalog.*;
import logicole.common.datamodels.abi.ControlledInventoryItemCode;
import logicole.common.datamodels.abi.ControlledInventoryItemCodeRef;
import logicole.common.datamodels.abi.Destruction;
import logicole.common.datamodels.abi.item.ItemSummary;
import logicole.common.datamodels.finance.referencedata.FinancialSystem;
import logicole.common.datamodels.finance.referencedata.FundingCategory;
import logicole.common.datamodels.general.search.SearchCategory;
import logicole.common.datamodels.general.search.SearchCategoryItem;
import logicole.common.datamodels.general.search.SearchCriterion;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.order.CatalogPurchase;
import logicole.common.datamodels.order.buyer.Buyer;
import logicole.common.datamodels.sale.seller.BuyerSellerAccountDTO;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.util.ObjectMapper;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.services.abi.AbiStagingLookupService;
import logicole.gateway.services.finance.FinanceAdminService;
import logicole.gateway.services.sale.SellerService;
import logicole.gateway.services.order.BuyerService;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@ApplicationScoped
public class CatalogLookupService extends BaseGatewayService<ICatalogLookupMicroserviceApi> {
    public static final String BUYER = "buyer";
    public static final String SELLER = "seller";
    public static final String CUSTOMER_NOT_FOUND_EXCEPTION = "No Customer is associated to this profile";
    public static final String SUPPLIER_NOT_FOUND_EXCEPTION = "No Authorized Supplier is associated to this customer";

    @Inject
    private CatalogService catalogService;

    @Inject
    private EnterpriseSourcingService enterpriseSourcingService;

    @Inject
    private CurrentUserBT currentUserBT;

    @Inject
    private AbiStagingLookupService abiStagingLookupService;

    @Inject
    private BuyerService buyerService;

    @Inject
    private SellerService sellerService;

    @Inject
    private FinanceAdminService financeAdminService;

    @Inject
    private ObjectMapper mapper;

    public CatalogLookupService() {
        super("Catalog");
    }

    public List<CommodityClassRef> getCommodityClassRefs() {
        List<CommodityClass> commodityClasses = getCommodityClasses();
        List<CommodityClassRef> commodityClassRefs = new ArrayList<>();
        for (CommodityClass commodityClass : commodityClasses) {
            commodityClassRefs.add((CommodityClassRef) commodityClass.getRef());
        }
        return commodityClassRefs;
    }

    public List<FundingCategory> getFundingCategories() {

        FinancialSystem financialSystem = financeAdminService.getFinancialSystemByNodeId(currentUserBT.getCurrentNodeId());

        List<FundingCategory> fundingCategories = financeAdminService.getCommodityCodesByFinancialSystem(financialSystem.getId());

        return fundingCategories;
    }

    public List<CommodityClass> getCommodityClasses() {
        return microservice.getCommodityClasses();
    }

    public List<String> getCommodityTypeList() {
        return abiStagingLookupService.getCommodityTypeList();
    }

    public List<CommodityClass> createCommodityClass(CommodityClass commodityClass) {
        return microservice.createCommodityClass(commodityClass);
    }

    public List<CommodityClass> updateCommodityClass(CommodityClass commodityClass) {
        return microservice.updateCommodityClass(commodityClass);
    }

    public List<CommodityClass> deleteCommodityClass(CommodityClass commodityClass) {
        return microservice.deleteCommodityClass(commodityClass);
    }

    public Destruction getItemDestruction(String code, String description) {
        return microservice.getItemDestruction(code, description);
    }

    public List<SpecialHandling> getSpecialHandling() {
        return microservice.getSpecialHandlings();
    }

    public List<SpecialHandlingRef> getSpecialHandlingRefs() {
        List<SpecialHandling> specialHandlings = microservice.getSpecialHandlings();
        List<SpecialHandlingRef> specialHandlingRefs = new ArrayList<>();
        for (SpecialHandling specialHandling : specialHandlings) {
            specialHandlingRefs.add(specialHandling.getRef());
        }
        return specialHandlingRefs;
    }

    public List<SpecialHandling> createSpecialHandling(SpecialHandling specialHandling) {
        return microservice.createSpecialHandling(specialHandling);
    }

    public List<SpecialHandling> updateSpecialHandling(SpecialHandling specialHandling) {
        return microservice.updateSpecialHandling(specialHandling);
    }

    public List<SpecialHandling> deleteSpecialHandling(SpecialHandling specialHandling) {
        return microservice.deleteSpecialHandling(specialHandling);
    }

    public List<ControlledInventoryItemCode> getControlledInventoryCodes() {
        return microservice.getControlledInventoryCodes();
    }

    public List<BuyerSellerAccountDTO> getBuyerSellerAccountListByBuyerId() {
        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if (Objects.isNull(buyer)) {
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }

        List<BuyerSellerAccountDTO> buyerSellerAccountDTOList = this.sellerService.getBuyerSellerAccountListByBuyerId(buyer.getId());
        if (Objects.isNull(buyerSellerAccountDTOList) || buyerSellerAccountDTOList.isEmpty()) {
            throw new ApplicationException(SUPPLIER_NOT_FOUND_EXCEPTION);
        }

        return buyerSellerAccountDTOList;
    }

    public List<ControlledInventoryItemCodeRef> getControlledInventoryCodeRefs() {
        List<ControlledInventoryItemCode> controlledInventoryItemCodes = microservice.getControlledInventoryCodes();
        List<ControlledInventoryItemCodeRef> controlledInventoryItemCodeRefs = new ArrayList<>();
        controlledInventoryItemCodes.forEach((f) -> controlledInventoryItemCodeRefs.add(f.getRef()));
        return controlledInventoryItemCodeRefs;
    }

    public ControlledInventoryItemCode getItemControlledInventoryCode(String code) {
        return microservice.getItemControlledInventoryCode(code);
    }


    public List<ControlledInventoryItemCode> createControlledInventoryItemCode(ControlledInventoryItemCode controlledInventoryItemCode) {
        return microservice.createControlledInventoryItemCode(controlledInventoryItemCode);
    }

    public List<ControlledInventoryItemCode> updateControlledInventoryItemCode(ControlledInventoryItemCode controlledInventoryItemCode) {
        return microservice.updateControlledInventoryItemCode(controlledInventoryItemCode);
    }

    public List<ControlledInventoryItemCode> deleteControlledInventoryItemCode(ControlledInventoryItemCode controlledInventoryItemCode) {
        return microservice.deleteControlledInventoryItemCode(controlledInventoryItemCode);
    }

    public SearchResult<CatalogDTO> getNonCatalogPurchaseSearchResults(SearchInput searchInput) {
        SearchCriterion itemSearchCriterion = new SearchCriterion();
        itemSearchCriterion.propName = "enterpriseProductIdentifier";
        itemSearchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
        List<Object> propValues = new ArrayList<>();
        propValues.add("");
        itemSearchCriterion.propValues = propValues.toArray();
        searchInput.searchCriteria.add(itemSearchCriterion);

        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);

        SearchCriterion buyerSearchCriterion = new SearchCriterion();
        buyerSearchCriterion.propName = BUYER;
        buyerSearchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
        ArrayList<String> buyerIds = new ArrayList<>();
        buyerIds.add(buyer.getId());
        buyerSearchCriterion.propValues = buyerIds.toArray();
        searchInput.searchCriteria.add(buyerSearchCriterion);

        SearchResult<CatalogDTO> catalogSearchResult = catalogService.getNonCatalogPurchaseSearchResults(searchInput);
        return catalogSearchResult;
    }

    public SearchResult<CatalogDTO> getCatalogSearchResults(SearchInput searchInput) {
        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if (Objects.isNull(buyer)) {
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }

        List<BuyerSellerAccountDTO> buyerSellerAccountDTOList = this.sellerService.getBuyerSellerAccountListByBuyerId(buyer.getId());
        if (Objects.isNull(buyerSellerAccountDTOList) || buyerSellerAccountDTOList.isEmpty()) {
            throw new ApplicationException(SUPPLIER_NOT_FOUND_EXCEPTION);
        }
        SearchCriterion buyerSearchCriterion = new SearchCriterion();
        buyerSearchCriterion.propName = BUYER;
        buyerSearchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
        ArrayList<String> buyerIds = new ArrayList<>();
        buyerIds.add(buyer.getId());
        buyerSearchCriterion.propValues = buyerIds.toArray();
        searchInput.searchCriteria.add(buyerSearchCriterion);

        List<String> sellerIds = new ArrayList<>();
        buyerSellerAccountDTOList.forEach(buyerSellerAccountDTO -> sellerIds.add(buyerSellerAccountDTO.sellerId));
        SearchCriterion sellerSearchCriterion = new SearchCriterion();
        sellerSearchCriterion.propName = SELLER;
        sellerSearchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
        sellerSearchCriterion.propValues = sellerIds.toArray();
        searchInput.searchCriteria.add(sellerSearchCriterion);

        SearchResult<CatalogDTO> catalogSearchResults = catalogService.getCatalogSearchResults(searchInput);
        return catalogSearchResults;
    }

    public SearchResult<CatalogDTO> getCatalogAndNonCatalogSearchResults(SearchInput searchInput) {
        SearchResult<CatalogDTO> entireCatalogResults;
        SearchResult<EnterpriseSourceSummary> enterpriseSourcingResults;
        SearchResult<ItemSummary> itemResults;
        List<String> itemIds = new ArrayList<>();

        Buyer buyer = buyerService.getBuyerForNodeId(currentUserBT.getCurrentUser().profile.currentNodeRef.id);
        if (Objects.isNull(buyer)) {
            throw new ApplicationException(CUSTOMER_NOT_FOUND_EXCEPTION);
        }

        List<BuyerSellerAccountDTO> buyerSellerAccountDTOList = this.sellerService.getBuyerSellerAccountListByBuyerId(buyer.getId());
        if (Objects.isNull(buyerSellerAccountDTOList) || buyerSellerAccountDTOList.isEmpty()) {
            throw new ApplicationException(SUPPLIER_NOT_FOUND_EXCEPTION);
        }
        SearchCriterion buyerSearchCriterion = new SearchCriterion();
        buyerSearchCriterion.propName = BUYER;
        buyerSearchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
        ArrayList<String> buyerIds = new ArrayList<>();
        buyerIds.add(buyer.getId());
        buyerSearchCriterion.propValues = buyerIds.toArray();
        searchInput.searchCriteria.add(buyerSearchCriterion);

        List<String> sellerIds = new ArrayList<>();
        buyerSellerAccountDTOList.forEach(buyerSellerAccountDTO -> sellerIds.add(buyerSellerAccountDTO.sellerId));
        SearchCriterion sellerSearchCriterion = new SearchCriterion();
        sellerSearchCriterion.propName = SELLER;
        sellerSearchCriterion.method = SearchCriterion.SEARCH_METHOD_IN;
        sellerSearchCriterion.propValues = sellerIds.toArray();
        searchInput.searchCriteria.add(sellerSearchCriterion);

        entireCatalogResults = catalogService.getCatalogSearchResults(searchInput);
        if (!Objects.isNull(entireCatalogResults) && !Objects.isNull(entireCatalogResults.results)) {
            entireCatalogResults.results.forEach((entry) -> {
                itemIds.add(entry.itemRef.id);
            });
        }

        searchInput.searchCriteria.remove(buyerSearchCriterion);
        searchInput.searchCriteria.remove(sellerSearchCriterion);
        enterpriseSourcingResults = enterpriseSourcingService.getEnterpriseSourcingSearchResults(searchInput);
        List<String> sellers = new ArrayList<>();
        List<String> commodityCodes = new ArrayList<>();
        List<String> manufacturers = new ArrayList<>();
        List<String> packageUnitDescriptions = new ArrayList<>();
        List<String> productNouns = new ArrayList<>();
        List<String> productTypes = new ArrayList<>();
        if (enterpriseSourcingResults != null && enterpriseSourcingResults.results != null && !enterpriseSourcingResults.results.isEmpty()) {
            SearchResult<CatalogDTO> tempItemSourcings = entireCatalogResults;
            enterpriseSourcingResults.results.forEach((itemSourcingSearchResult) -> {
                CatalogDTO catalog = new CatalogDTO();
                catalog.itemRef = itemSourcingSearchResult.itemRef;
                catalog.sellerRef = itemSourcingSearchResult.sellerRef;
                catalog.sellerPackageUnit = itemSourcingSearchResult.packageUnit;
                catalog.sellerPackageQuantity = itemSourcingSearchResult.packageQuantity;
                catalog.sellerProductIdentifier = itemSourcingSearchResult.sellerProductIdentifier;
                catalog.price = itemSourcingSearchResult.price;
                tempItemSourcings.results.add(catalog);
                sellers.add(itemSourcingSearchResult.sellerRef.sellerName);
                commodityCodes.add(itemSourcingSearchResult.itemRef.commodityType);
                manufacturers.add(itemSourcingSearchResult.itemRef.manufacturer);
                packageUnitDescriptions.add(itemSourcingSearchResult.packageUnitDescription);
                productNouns.add(itemSourcingSearchResult.itemRef.productNoun);
                productTypes.add(itemSourcingSearchResult.itemRef.productType);
            });
            entireCatalogResults = tempItemSourcings;
        }

        if (enterpriseSourcingResults != null) {
            enterpriseSourcingResults.results.forEach((entry) -> {
                String id = entry.itemRef.id;
                if (!itemIds.contains(id)) {
                    itemIds.add(id);
                }
            });
        }

        Iterator<SearchCriterion> searchCriterionIterator = searchInput.searchCriteria.iterator();
        while (searchCriterionIterator.hasNext()) {
            SearchCriterion criteria = searchCriterionIterator.next();
            if (criteria.propName.equalsIgnoreCase("seller")) {
                searchCriterionIterator.remove();
            }
            // checking if the seller search criteria is coming from the facet
            if (criteria.propName.equalsIgnoreCase("sellerRef.sellerName")) {
                searchCriterionIterator.remove();
            }
        }

        return populateSearchResultsItemSummary(entireCatalogResults);
    }

    private SearchResult<CatalogDTO> populateSearchResultsItemSummary(SearchResult<CatalogDTO> searchResult) {
        if (Objects.nonNull(searchResult) && Objects.nonNull(searchResult.results) && !searchResult.results.isEmpty()) {
            for (CatalogDTO catalog : searchResult.results) {
                if (Objects.nonNull(catalog.itemRef)) {
                    catalog.itemSummary = mapper.getObject(ItemSummary.class, catalog.itemRef);
                }
            }
        }
        return searchResult;
    }

    private SearchCategory getSearchCategoryItemCount(SearchCategory aggregations, List<String> facetValues) {
        for (SearchCategoryItem aggregation : aggregations.values) {
            if (!aggregation.value.toString().isBlank()) {
                List<String> values = facetValues.stream().filter(facetValue -> Objects.nonNull(facetValue) && facetValue.equals(aggregation.value.toString())).collect(Collectors.toList());
                aggregation.count = aggregation.count + values.size();
            }
        }

        return aggregations;
    }

    public SearchResult<CatalogPurchase> getCatalogSearchResultsForAssemblage(List<AssemblageItem> items) {
        return catalogService.getCatalogSearchResultsForAssemblage(items);
    }

}
