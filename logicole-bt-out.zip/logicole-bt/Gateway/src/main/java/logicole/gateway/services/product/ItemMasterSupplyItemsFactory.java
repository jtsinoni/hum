package logicole.gateway.services.product;

import logicole.common.datamodels.abi.PackagingDetail;
import logicole.common.datamodels.ehr.equipment.*;
import logicole.common.datamodels.product.Offer;
import logicole.common.datamodels.product.Product;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.logging.ILogger;
import logicole.common.general.util.DateUtil;
import logicole.common.general.util.string.StringUtil;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@ApplicationScoped
public class ItemMasterSupplyItemsFactory {
    @Inject
    private ILogger logger;

    public List<ItemMasterSupplyCatalogItem> convert(List<Offer> offers, EItemMasterSupplyCatalogType catType,
                                                     Date lastCatalogRequestDates,
                                                     String siteId, String customerId) {
        List<ItemMasterSupplyCatalogItem> items = new ArrayList<>();
        for (Offer offer : offers) {
            ItemMasterSupplyCatalogItem item;
            try {
                item = create(offer, catType, lastCatalogRequestDates);
                items.add(item);
            } catch (ApplicationException e) {
                logger.error("Error creating ItemMasterSupplyCatalogItem from Offer ID" + offer.getId() +"error message" +  e.getMessage());
            }
        }
        return items;
    }

    ItemMasterSupplyCatalogItem create(Offer offer, EItemMasterSupplyCatalogType catType,
                                       Date lastCatalogRequestDate) throws ApplicationException {
        ItemMasterSupplyCatalogItem item = new ItemMasterSupplyCatalogItem();

        Product prod = offer.product;

        if (prod == null) {
            throw new ApplicationException("Product information is missing for offer ID" + offer.getId());
        }

        item.itemId = prod.enterpriseProductIdentifier;

        if (StringUtil.isEmptyOrNull(prod.enterpriseProductIdentifier)) {
            throw new ApplicationException("The Enterprise Product Identifier is missing in the product for offer ID" + offer.getId());
        }

        if (StringUtil.isEmptyOrNull(offer.previousEnterpriseProductIdentifier)) {
            item.previousItemId = item.itemId;
        } else {
            item.previousItemId = offer.previousEnterpriseProductIdentifier;
        }
        item.longDescription = StringUtil.truncate(prod.longItemDescription, 255);
        item.shortDescription = StringUtil.truncate(prod.shortItemDescription, 40);
        item.manufacturer = StringUtil.truncate(prod.manufacturer, 40);
        item.manufacturerPartNo = StringUtil.truncate(prod.manufacturerCatalogNumber, 32);

        if (StringUtil.isEmptyOrNull(item.manufacturerPartNo)) {
            item.manufacturerPartNo = StringUtil.truncate(prod.ndc, 32);
        }

        item.implant = "Yes".equalsIgnoreCase(prod.implant);
        item.latexInd = "Latex".equalsIgnoreCase(prod.latexCode);

        item.hcpcsCode = StringUtil.truncate(prod.hcpcsCode, 5);

        if (prod.unspscCode != null) {
            item.unspscCode = prod.unspscCode.toString();
        } else {
            item.unspscCode = null;
        }

        item.packaging = getPackaging(prod.packaging);

        if (item.packaging == null) {
            throw new ApplicationException("Packaging information is missing within the product for offer ID" + offer.getId());
        }

        item.siteInfoList = getSiteInfoList(offer, catType, lastCatalogRequestDate);
        return item;
    }

    List<ItemMasterSupplyItemSiteInfo> getSiteInfoList(Offer offer, EItemMasterSupplyCatalogType catType,
                                                       Date lastCatalogRequestDate) {
        List<ItemMasterSupplyItemSiteInfo> list = new ArrayList<>();
        //  NOTE: This is the siteCatalog packaging. In latest 1.8 it only has one packaging level per record, not all site packaging.
        ItemMasterSupplyItemSiteInfo item = new ItemMasterSupplyItemSiteInfo();
        item.catalogSiteDodaac = offer.organizationIdentifier;
        item.customerAccountId = offer.customerIdentifier;

        item.packCd = offer.ehrPackageUnit;
        item.packQty = offer.ehrPackageQuantity;
        item.price = offer.ehrPrice;

        if (catType == EItemMasterSupplyCatalogType.ITEM_DELTA) {
            item.siteInfoDeltaType = determineSiteInfoDeltaType(offer, lastCatalogRequestDate);
        } else {
            item.siteInfoDeltaType = null;
        }
        list.add(item);
        return list;
    }

    EItemMasterSupplyItemSiteInfoDeltaType determineSiteInfoDeltaType(Offer offer,
                                                                      Date lastCatRequestDate) {
        EItemMasterSupplyItemSiteInfoDeltaType type = EItemMasterSupplyItemSiteInfoDeltaType.ADD;
        if (lastCatRequestDate != null) {
            if (DateUtil.safeDateCompare(lastCatRequestDate, offer.ehrAddedDate) < 0) {
                type = EItemMasterSupplyItemSiteInfoDeltaType.ADD;
            } else if (DateUtil.safeDateCompare(lastCatRequestDate, offer.ehrDeletedDate) < 0) {
                type = EItemMasterSupplyItemSiteInfoDeltaType.DELETE;
            } else if (DateUtil.safeDateCompare(lastCatRequestDate, offer.ehrModifiedDate) < 0) {
                type = EItemMasterSupplyItemSiteInfoDeltaType.UPDATE;
            }
        }
        return type;
    }

    List<ItemMasterSupplyItemPackaging> getPackaging(List<PackagingDetail> packaging) {
        List<ItemMasterSupplyItemPackaging> items = new ArrayList<>();

        for (PackagingDetail dtl : packaging) {
            ItemMasterSupplyItemPackaging item = new ItemMasterSupplyItemPackaging();
            item.enterprisePackageIdentifier = dtl.enterprisePackageIdentifier;
            item.gtinUpn = dtl.gtin;
            item.basePackCd = packaging.get(0).packageUnit;
            if (dtl.otherPackageIdentifiers != null && dtl.otherPackageIdentifiers.size() > 0) {
                item.gtinUpn2 = dtl.otherPackageIdentifiers.get(0);
            }
            item.packCd = dtl.packageUnit;
            item.packQty = dtl.packageQuantity;
            items.add(item);
        }

        return items;
    }
}
