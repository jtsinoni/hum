package logicole.gateway.services.abi;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import logicole.common.datamodels.abi.staging.EABiUploadType;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.gateway.rest.ExternalRestApi;
import org.jboss.resteasy.annotations.providers.multipart.PartType;
import org.jboss.resteasy.plugins.providers.multipart.MultipartFormDataInput;

import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Api(tags = {"Abi"})
@ApplicationScoped
@Path("/abi/filemanager")
public class AbiFileManagerRestApi extends ExternalRestApi<AbiFileManagerService> {

    @GET
    @Path("/deleteUploadHistory")
    @Produces(MediaType.TEXT_PLAIN)
    public Integer deleteUploadHistory() {
        return service.deleteUploadHistory();
    }

    @POST
    @Path("/uploadABiFile")
    @PartType("form")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    public FileManager uploadABiFile(@QueryParam("abiUploadType") EABiUploadType abiUploadType,
                                @ApiParam(name = "body", hidden = true, required = true) MultipartFormDataInput form) {
        return service.uploadABiFile(abiUploadType, form);
    }
}
