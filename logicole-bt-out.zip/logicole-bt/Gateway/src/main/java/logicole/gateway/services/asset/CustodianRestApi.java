package logicole.gateway.services.asset;

import io.swagger.annotations.Api;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.asset.management.Custodian;
import logicole.common.datamodels.asset.management.CustomerCustodian;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.user.UserProfile;
import logicole.gateway.rest.ExternalRestApi;

import javax.enterprise.context.ApplicationScoped;
import javax.validation.constraints.NotNull;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import java.util.Date;
import java.util.List;

@Api(tags = {"Custodian"})
@ApplicationScoped
@Path("/custodian")
public class CustodianRestApi extends ExternalRestApi<CustodianService> {
    @GET
    @Path("/doesCustomerHaveAccountableEquipment")
    public boolean doesCustomerHaveAccountableEquipment(@NotNull @QueryParam("id") String id) {
        return service.doesCustomerHaveAccountableEquipment(id);
    }

    @GET
    @Path("/getCustomerCustodiansBySite")
    public List<CustomerCustodian> getCustomerCustodiansBySite() {
        return service.getCustomerCustodiansBySite();
    }

    @GET
    @Path("/getCustomersBySite")
    public List<OrganizationRef> getCustomersBySiteId(@NotNull @QueryParam("siteId") String siteId) {
        return service.getCustomersBySiteId(siteId);
    }

    @POST
    @Path("/createCustodian")
    public Custodian createCustodian(Custodian custodian) {
        return service.createCustodian(custodian);
    }

    @GET
    @Path("/getPotentialCustodianUserProfiles")
    public List<UserProfile> getPotentialCustodianUserProfiles() {
        return service.getPotentialCustodianUserProfiles();
    }

    @GET
    @Path("/getCustomersWithoutCustodianAtOrg")
    public List<OrganizationRef> getCustomersWithoutCustodianAtOrg() {
        return service.getCustomersWithoutCustodianAtOrg();
    }

    @GET
    @Path("/getCustodianRecordById")
    public Custodian getCustodianRecordById(@QueryParam("id") String id) {
        return service.getCustodianRecordById(id);
    }

    @POST
    @Path("/saveCustodianInformation")
    public Custodian saveCustodianInformation(Custodian custodian) {
        return service.saveCustodianInformation(custodian);
    }

    @POST
    @Path("/saveInventoryInformation")
    public Custodian saveInventoryInformation(@QueryParam("id") String id, Date nextInventoryDate) {
        return service.saveInventoryInformation(id, nextInventoryDate);
    }

    @POST
    @Path("/removeCustodianNote")
    public Custodian removeCustodianNote(@QueryParam("id") String id, Note note) {
        return service.removeCustodianNote(id, note);
    }

    @POST
    @Path("/saveCustodianNote")
    public Custodian saveCustodianNote(@QueryParam("id") String id, Note note) {
        return service.saveCustodianNote(id, note);
    }

    @GET
    @Path("/removeCustodian")
    public boolean removeCustodian(@QueryParam("id") String id) {
        return service.removeCustodian(id);
    }

    @GET
    @Path("/removeSubcustodian")
    public boolean removeSubcustodian(@QueryParam("id") String id) {
        return service.removeSubcustodian(id);
    }

    @GET
    @Path("/checkIfSubcustodianAssignedToCustomer")
    public boolean checkIfSubcustodianAssignedToCustomer(@QueryParam("id") String id) {
        return service.checkIfSubcustodianAssignedToCustomer(id);
    }

    @POST
    @Path("/createSubcustodian")
    public Custodian createSubcustodian(@QueryParam("id") String custodianId, Custodian subcustodian) {
        return service.createSubcustodian(custodianId, subcustodian);
    }

    @POST
    @Path("/saveSubcustodian")
    public Custodian saveSubcustodian(Custodian subcustodian) {
        return service.saveSubcustodian(subcustodian);
    }

    @GET
    @Path("/removeAllSubcustodiansAtCustomer")
    public boolean removeAllSubcustodiansAtCustomer(@QueryParam("id") String id) {
        return service.removeAllSubcustodiansAtCustomer(id);
    }

    @GET
    @Path("/getSubCustodiansByCustomerId")
    public List<Custodian> getSubCustodiansByCustomerId(@QueryParam("customerId") String customerId) {
        return service.getSubCustodiansByCustomerId(customerId);
    }

    @GET
    @Path("/getAssignedEquipmentForSubcustodian")
    public List<Asset> getAssignedEquipmentForSubcustodian(@QueryParam("subcustodianId") String subcustodianId) {
        return service.getAssignedEquipmentForSubcustodian(subcustodianId);
    }

    @GET
    @Path("/getAssignableEquipmentByCustomerId")
    public List<Asset> getAssignableEquipmentByCustomerId(@QueryParam("customerId") String customerId) {
        return service.getAssignableEquipmentByCustomerId(customerId);
    }

    @POST
    @Path("/saveAssignedEquipmentForSubcustodian")
    public List<Asset> saveAssignedEquipmentForSubcustodian(List<String> ids, @QueryParam("subcustodianId") String subcustodianId) {
        return service.saveAssignedEquipmentForSubcustodian(ids, subcustodianId);
    }

}
