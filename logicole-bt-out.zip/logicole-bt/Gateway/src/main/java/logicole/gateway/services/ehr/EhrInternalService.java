package logicole.gateway.services.ehr;


import logicole.common.datamodels.communications.ehr.EEhrRequestType;
import logicole.common.datamodels.communications.ehr.EhrRequest;
import logicole.common.datamodels.communications.ehr.EhrRequestResponse;
import logicole.common.datamodels.dmlss.EhrSiteCustomer;
import logicole.common.datamodels.ehr.product.EhrSearchCriteria;
import logicole.common.datamodels.equipment.record.EquipmentRecord;
import logicole.common.datamodels.organization.EhrCustomer;
import logicole.common.datamodels.organization.EhrCustomersBySite;
import logicole.common.datamodels.product.OfferSummary;
import logicole.common.general.exception.ApplicationException;
import logicole.gateway.common.BaseGatewayService;
import logicole.gateway.remote.IDefaultRemoteApi;
import logicole.gateway.services.communications.DmlssCommunicationsService;
import logicole.gateway.services.communications.EhrRequestFactoryService;
import logicole.gateway.services.communications.EhrTaskHistoryService;
import logicole.gateway.services.equipment.EquipmentRecordService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.product.OfferService;

import java.io.IOException;
import java.util.*;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

@ApplicationScoped
public class EhrInternalService extends BaseGatewayService<IDefaultRemoteApi> {
    @Inject
    EquipmentRecordService equipmentRecordService;

    @Inject
    OfferService offerService;

    @Inject
    OrganizationService organizationService;

    @Inject
    EhrTaskHistoryService ehrTaskHistoryService;

    @Inject
    EhrRequestFactoryService ehrRequestFactoryService;

    @Inject
    DmlssCommunicationsService dmlssCommunicationsService;

    private static String REFRESH_SITE_CUSTOMERS_CATEGORY = "RefreshSitesAndCustomers";


    public EhrInternalService() {
        super("Ehr");
    }

    public Collection<EhrCustomersBySite> getEhrSiteCustomers(String type) {
        List<EhrSiteCustomer> customers = organizationService.getEhrSiteCustomers("");

        return buildCustomersBySite(customers);
    }

    Collection<EhrCustomersBySite> buildCustomersBySite(List<EhrSiteCustomer> customers) {
        Map<String, EhrCustomersBySite> map = new HashMap<>();

        for (EhrSiteCustomer sc : customers) {
            String siteOrgId = sc.siteOrgId;
            EhrCustomer ehrCustomer = new EhrCustomer();
            ehrCustomer.customerOrgId = sc.customerOrgId;
            ehrCustomer.customerOrgName = sc.customerName;
            if (map.containsKey(siteOrgId)) {
                EhrCustomersBySite entry = map.get(siteOrgId);
                entry.customers.add(ehrCustomer);
            } else {
                EhrCustomersBySite entry = new EhrCustomersBySite();
                entry.siteOrgId = siteOrgId;
                entry.siteOrgName = sc.siteName;
                entry.customers.add(ehrCustomer);
                map.put(siteOrgId, entry);
            }
        }

        return map.values();
    }

    public List<EhrSiteCustomer> getCustomerOrgs() {
        return organizationService.getCustomerOrgs();
    }

    public EhrSiteCustomer saveCustomerOrg(EhrSiteCustomer ehrSiteCustomer) {
        return organizationService.saveCustomerOrg(ehrSiteCustomer);
    }

    public List<EquipmentRecord> getEquipmentRecordsForSiteCustomer(String siteId, String customerId) {
        return equipmentRecordService.getEquipmentRecordsForSiteCustomer(siteId, customerId);
    }

    public List<EquipmentRecord> getEhrEquipmentRecords(EhrSearchCriteria ehrSearchCriteria) throws IOException, ApplicationException {
        return equipmentRecordService.getEhrEquipmentRecords(ehrSearchCriteria);
    }

    public EquipmentRecord setEquipmentEhrEnabled(String id, boolean isEhrEnabled) {
        return equipmentRecordService.setEquipmentEhrEnabled(id, isEhrEnabled);
    }

    public EhrSiteCustomer resetItemCatalogSyncDate(String id) {
        return organizationService.resetItemCatalogSyncDate(id);
    }

    public EhrSiteCustomer resetEquipmentCatalogSyncDate(String id) {
        return organizationService.resetEquipmentCatalogSyncDate(id);
    }

    public OfferSummary setItemEhrEnabled(String id, boolean isEhrEnabled) {
        return offerService.setItemEhrEnabled(id, isEhrEnabled);
    }

    public Boolean enterpriseProductIdentifierIsEHREnabled(String enterpriseProductIdentifier) {
        return offerService.enterpriseProductIdentifierIsEHREnabled(enterpriseProductIdentifier);
    }


    public void processEhrCustomerPull(String dodaac) {
        String requestId = UUID.randomUUID().toString();

        EhrRequest request = ehrRequestFactoryService.createRequest(requestId, EEhrRequestType.REFRESH_SITE_CUSTOMERS, List.of(dodaac));
        EhrRequestResponse response = new EhrRequestResponse();
        response.stagingRequestId = requestId;
        response.notes = "Request to refresh selected Site Customers from DMLSS started";

        processEhrCustomerPullRequest(request);
    }

    public void processEhrCustomerPullRequest(EhrRequest request) {

        List<String> dodaacs = request.argumentList;
        for (String dodaac : dodaacs) {
            try {
                logger.info("Processing Requested Customers for dodaac {}", dodaac);
                ehrTaskHistoryService.logInfoMessage(
                        REFRESH_SITE_CUSTOMERS_CATEGORY,
                        request.requestId,
                        "Processing Requested Customers for dodaac " + dodaac,
                        request.getCurrentUserPkiDn());
                List<EhrSiteCustomer> customers = dmlssCommunicationsService.getCustomerOrgData(dodaac);

                if (customers.size() > 0) {
                    organizationService.addEhrDmlssCustomers(customers);
                    ehrTaskHistoryService.logInfoMessage(
                            REFRESH_SITE_CUSTOMERS_CATEGORY,
                            request.requestId,
                            "Refresh Sites and Customers complete for dodaac " + dodaac,
                            request.getCurrentUserPkiDn());
                } else {
                    ehrTaskHistoryService.logWarningMessage(
                            REFRESH_SITE_CUSTOMERS_CATEGORY,
                            request.requestId,
                            "No Customers found for dodaac " + dodaac,
                            request.getCurrentUserPkiDn());
                }
            } catch (Exception e) {
                // Fortify Note: Using broad catch of Exception on purpose because of the for loop processing.
                logger.error("Failed to retrieve customers from {} due to {}", dodaac, e);
                ehrTaskHistoryService.logExceptionMessage(
                        REFRESH_SITE_CUSTOMERS_CATEGORY,
                        request.requestId,
                        "Failed to retrieve customers from " + dodaac,
                        e,
                        request.getCurrentUserPkiDn());
            }
        }

    }
}
