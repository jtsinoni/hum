package logicole.gateway.services.ehr;


import static junit.framework.TestCase.assertNull;
import static junit.framework.TestCase.assertNotNull;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.assertTrue;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.when;

import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.communications.ehr.EhrPurchaseOrderHistory;
import logicole.common.datamodels.communications.ehr.EhrRequest;
import logicole.common.datamodels.communications.ehr.EhrRequestResponse;
import logicole.common.datamodels.communications.ehr.EEhrRequestType;
import logicole.common.datamodels.communications.transmitproperty.LogiColeAuthToken;
import logicole.common.datamodels.dmlss.EhrSiteCustomer;
import logicole.common.datamodels.ehr.equipment.*;
import logicole.common.datamodels.ehr.product.EhrPurchaseOrder;
import logicole.common.datamodels.ehr.product.PurchaseOrderResponse;
import logicole.common.datamodels.ehr.product.EPurchaseOrderResponseStatusType;
import logicole.common.datamodels.organization.DmlssHost;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.LoginCredential;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.ObjectNotFoundException;
import logicole.common.general.logging.ILogger;
import logicole.common.general.util.JSONUtil;
import logicole.common.restserver.http.RequestUtil;
import logicole.gateway.services.communications.*;
import logicole.gateway.services.equipment.EquipmentRecordService;
import logicole.gateway.services.organization.OrganizationService;
import logicole.gateway.services.product.OfferService;
import logicole.gateway.services.user.UserService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;


@RunWith(MockitoJUnitRunner.class)
public class EhrExternalServiceTest {

    @Mock
    private RequestUtil requestUtil;
    @Mock
    private JSONUtil jsonUtil;
    @Mock
    private EhrIncomingTrafficService ehrIncomingTrafficService;
    @Mock
    private DmlssElectronicHealthRecordsService dmlssElectronicHealthRecordsService;
    @Mock
    private OrganizationService organizationService;
    @Mock
    private EquipmentRecordService equipmentRecordService;
    @Mock
    private OfferService offerService;
    @Mock
    private Collection<ItemMasterSupplyCatalogItem> itemRecords;
    @Mock
    private ItemMasterSupplyItemSiteInfo info;
    @Mock
    private EquipmentItemSiteInfo infoEquipment;
    @Mock
    private List<ItemMasterSupplyCatalogItem> items;
    @Mock
    private ILogger logger;
    @Mock
    private EhrRequestFactoryService ehrRequestFactoryService;
    @Mock
    private EquipmentCatalogItemAccumulator equipmentCatalogItemAccumulator;
    @Mock
    private ItemMasterSupplyCatalogAccumulator supplyItemAccumulator;
    @Mock
    private EhrMessagesService ehrMessagesService;
    @Mock
    private CurrentUserBT currentUserBT;
    @Mock
    private EhrRequestQueueService ehrRequestQueueService;
    @Mock
    private UserService userService;

    List<EhrSiteCustomer> customers = new ArrayList<EhrSiteCustomer>();
    EhrSiteCustomer customer1 = new EhrSiteCustomer();
    EhrSiteCustomer customer2 = new EhrSiteCustomer();

    String itemId1 = "5c3653cb93f521351a777003";
    String itemId2 = "5c3653cb93f521351a777004";
    String itemId3 = "5c3653cb93f521351a777005";
    String itemId4 = "5c3653cb93f521351a777006";
    String itemId5 = "5c3653cb93f521351a777003"; //check dup testing
    String itemId6 = "5c3653cb93f521351a777007"; //check dup testing
    String itemId7 = "5c3653cb93f521351a777008"; //check dup testing

    List<ItemMasterSupplyCatalogItem> itemsA = new ArrayList<ItemMasterSupplyCatalogItem>();
    ItemMasterSupplyCatalogItem item1 = new ItemMasterSupplyCatalogItem();
    ItemMasterSupplyCatalogItem item2 = new ItemMasterSupplyCatalogItem();

    List<ItemMasterSupplyCatalogItem> itemsB = new ArrayList<ItemMasterSupplyCatalogItem>();
    ItemMasterSupplyCatalogItem item3 = new ItemMasterSupplyCatalogItem();
    ItemMasterSupplyCatalogItem item4 = new ItemMasterSupplyCatalogItem();
    ItemMasterSupplyCatalogItem item5 = new ItemMasterSupplyCatalogItem();

    List<EquipmentCatalogItem> itemsEquipment = new ArrayList<EquipmentCatalogItem>();
    EquipmentCatalogItem item6 = new EquipmentCatalogItem();
    EquipmentCatalogItem item7 = new EquipmentCatalogItem();

    List<ItemMasterSupplyCatalogItem> itemsResult = new ArrayList<ItemMasterSupplyCatalogItem>();
    List<ItemMasterSupplyCatalogItem> itemsEmpty = new ArrayList<ItemMasterSupplyCatalogItem>();

    EhrPurchaseOrder purchaseOrder;
    EhrRequest request;
    EhrPurchaseOrderHistory history;
    List<String> dodaacs = new ArrayList<String>();
    EquipmentCatalog cat;

    @Spy
    @InjectMocks
    private EhrExternalService spy;

    @Before
    public void before() {
        setup();
    }

    private void setup() {

        customers = new ArrayList<EhrSiteCustomer>();
        customer1 = new EhrSiteCustomer();
        customer2 = new EhrSiteCustomer();

        itemsA = new ArrayList<ItemMasterSupplyCatalogItem>();
        item1 = new ItemMasterSupplyCatalogItem();
        item2 = new ItemMasterSupplyCatalogItem();

        itemsB = new ArrayList<ItemMasterSupplyCatalogItem>();
        item3 = new ItemMasterSupplyCatalogItem();
        item4 = new ItemMasterSupplyCatalogItem();
        item5 = new ItemMasterSupplyCatalogItem();

        itemsEquipment = new ArrayList<EquipmentCatalogItem>();
        item6 = new EquipmentCatalogItem();
        item7 = new EquipmentCatalogItem();

        customer1.siteOrgId = "5c3653cb93f521351a7770ee";
        customer1.customerOrgId = "5c3653cb93f521351a7770ef";
        customer1.ehrLastItemSyncDate = new Date();
        customer2.siteOrgId = "5c3653cb93f521351a777000";
        customer2.customerOrgId = "5c3653cb93f521351a777001";
        customer2.ehrLastItemSyncDate = new Date();

        customers.add(customer1);
        customers.add(customer2);

        itemId1 = "5c3653cb93f521351a777003";
        itemId2 = "5c3653cb93f521351a777004";
        itemId3 = "5c3653cb93f521351a777005";
        itemId4 = "5c3653cb93f521351a777006";
        itemId5 = "5c3653cb93f521351a777003";
        itemId6 = "5c3653cb93f521351a777007";
        itemId7 = "5c3653cb93f521351a777008";

        item1.itemId = itemId1;
        item1.siteInfoList = new ArrayList<ItemMasterSupplyItemSiteInfo>();
        item1.siteInfoList.add(info);

        item2.itemId = itemId2;
        item2.siteInfoList = new ArrayList<ItemMasterSupplyItemSiteInfo>();
        item2.siteInfoList.add(info);

        itemsA.add(item1);
        itemsA.add(item2);

        item3.itemId = itemId3;
        item3.siteInfoList = new ArrayList<ItemMasterSupplyItemSiteInfo>();
        item3.siteInfoList.add(info);

        item4.itemId = itemId4;
        item4.siteInfoList = new ArrayList<ItemMasterSupplyItemSiteInfo>();
        item4.siteInfoList.add(info);

        item5.itemId = itemId5;
        item5.siteInfoList = new ArrayList<ItemMasterSupplyItemSiteInfo>();
        item5.siteInfoList.add(info);

        itemsB.add(item3);
        itemsB.add(item4);
        itemsB.add(item5);

        item6.itemID = itemId6;
        item6.siteInfoList = new ArrayList<EquipmentItemSiteInfo>();
        item6.siteInfoList.add(infoEquipment);

        item7.itemID = itemId7;
        item7.siteInfoList = new ArrayList<EquipmentItemSiteInfo>();
        item7.siteInfoList.add(infoEquipment);

        itemsEquipment.add(item6);
        itemsEquipment.add(item7);

        purchaseOrder = new EhrPurchaseOrder();
        purchaseOrder.dodaac = "A";
        purchaseOrder.customerAccountId = "001";
        purchaseOrder.purchaseOrderNumber = "00A";

        dodaacs.add("A");
        dodaacs.add("B");
        dodaacs.add("C");

        cat = new EquipmentCatalog();
        itemsResult = new ArrayList<ItemMasterSupplyCatalogItem>();
        itemsResult.add(item1);
        itemsResult.add(item2);
        itemsResult.add(item3);
        itemsResult.add(item4);

    }

    @Test
    public void testGetItemMasterSupplyCatalog() throws ObjectNotFoundException {

        // Setup expected behavior
        when(organizationService.getEhrSiteCustomers(anyString())).thenReturn(customers);
        when(offerService.getCatalogItemsForSiteCustomer(eq("5c3653cb93f521351a7770ee"), anyString(), isNull(), eq(EItemMasterSupplyCatalogType.ITEM_COMPLETE))).thenReturn(itemsA);
        when(offerService.getCatalogItemsForSiteCustomer(eq("5c3653cb93f521351a777000"), anyString(), isNull(), eq(EItemMasterSupplyCatalogType.ITEM_COMPLETE))).thenReturn(itemsB);
        when(supplyItemAccumulator.getItems()).thenReturn(itemsResult);
        // Run the method
        ItemMasterSupplyCatalog catalog = spy.getItemMasterSupplyCatalog();

        // Verify
        assertEquals(catalog.itemRecords.size(), 4);

        return;

    }
    @Test
    public void testGetItemMasterSupplyCatalogNull() throws ObjectNotFoundException {

        // Setup expected behavior

        when(organizationService.getEhrSiteCustomers(anyString())).thenReturn(customers);
        when(offerService.getCatalogItemsForSiteCustomer(anyString(), anyString(), isNull(), eq(EItemMasterSupplyCatalogType.ITEM_COMPLETE))).thenThrow(new NullPointerException());
        when(supplyItemAccumulator.getItems()).thenReturn(itemsEmpty);
        // Run the Method
        ItemMasterSupplyCatalog catalog = spy.getItemMasterSupplyCatalog();

        // Verify
        assertEquals(catalog.itemRecords.size(), 0);

        return;

    }

    @Test
    public void testGetItemMasterSupplyCatalogDelta() throws ObjectNotFoundException {

        // Setup expected behavior
        when(organizationService.getItemMasterEnabledCustomerOrgs()).thenReturn(customers);
        when(offerService.getCatalogItemsForSiteCustomer(eq("5c3653cb93f521351a7770ee"), anyString(), any(Date.class), eq(EItemMasterSupplyCatalogType.ITEM_DELTA))).thenReturn(itemsA);
        when(offerService.getCatalogItemsForSiteCustomer(eq("5c3653cb93f521351a777000"), anyString(), any(Date.class), eq(EItemMasterSupplyCatalogType.ITEM_DELTA))).thenReturn(itemsB);
        //when(itemRecords.addAll(any())).thenReturn(true);

         // Run the method
        ItemMasterSupplyCatalog catalog = spy.getItemMasterSupplyCatalogDelta();

        // Verify
        assertNotNull(catalog.itemRecords);
    }

    @Test
    public void testGetEquipmentCatalog() throws ObjectNotFoundException {

        // Setup expected behavior
        when(organizationService.getEhrSiteCustomers(anyString())).thenReturn(customers);
        //when(equipmentRecordService.getEquipmentCatalogItemsComplete(any(EhrSiteCustomer.class))).thenReturn(itemsEquipment);

        // Run the method
        EquipmentCatalog catalog = spy.getEquipmentCatalog();

        // Verify
        assertNotNull(catalog.equipmentItems);
    }

    @Test
    public void testGetEquipmentCatalogNull() throws ObjectNotFoundException {

        // Setup expected behavior
        when(organizationService.getEhrSiteCustomers(anyString())).thenReturn(customers);
        when(equipmentRecordService.getEquipmentCatalogItemsComplete(any(EhrSiteCustomer.class))).thenThrow(new NullPointerException());

        // Run the method
        EquipmentCatalog catalog = spy.getEquipmentCatalog();

        // Verify
        assertNotNull(catalog);
        assertEquals(catalog.equipmentItems.size(), 0);
    }

    @Test
    public void testGetEquipmentCatalogDelta() throws ObjectNotFoundException {


        // Setup expected behavior
        when(organizationService.getEhrSiteCustomers(anyString())).thenReturn(customers);
        when(equipmentRecordService.getEquipmentCatalogItemsDelta(any(EhrSiteCustomer.class))).thenReturn(itemsEquipment);
        when(equipmentCatalogItemAccumulator.getItems()).thenReturn(itemsEquipment);

        // Run the method
        EquipmentCatalog catalogRet = spy.getEquipmentCatalogDelta();

        // Verify
        assertNotNull(catalogRet);
        assertEquals(2 , catalogRet.equipmentItems.size());
    }

    @Test
    public void testGetEquipmentCatalogDeltaNull() throws ObjectNotFoundException {

        // Setup expected behavior
        when(organizationService.getEhrSiteCustomers(anyString())).thenReturn(customers);
        when(equipmentRecordService.getEquipmentCatalogItemsDelta(any(EhrSiteCustomer.class))).thenThrow(new NullPointerException());

        // Run the method
        EquipmentCatalog catalog = spy.getEquipmentCatalogDelta();

        // Verify
        assertNotNull(catalog);
        assertEquals(catalog.equipmentItems.size(), 0);
    }

    @Test
    public void testPlaceOrder() throws ObjectNotFoundException {
        try {

            // Setup data
            String pkiDn = "pkiDn";
            CurrentUser currentUser = new CurrentUser();
            currentUser.profile = new UserProfile();
            currentUser.profile.pkiDn = pkiDn;

            // Setup expected behavior
            when(ehrRequestFactoryService.createRequest(any(EhrPurchaseOrder.class), anyString())).thenReturn(request);
//            when(ehrMessagesService.createEhrPurchaseOrderHistory(history)).thenReturn(history);
            when(organizationService.isSiteAndCustomerOrgIdValid(anyString(),anyString())).thenReturn(true);
            when(ehrMessagesService.isPONumberUnique(anyString(),anyString(),anyString())).thenReturn(true);
            when(organizationService.getDmlssHostByDodaac(anyString())).thenReturn(new DmlssHost());
            when(currentUserBT.getCurrentUser()).thenReturn(currentUser);

             // Run the method
            PurchaseOrderResponse response = spy.placeOrder(purchaseOrder);

            // Verify
            assertNotNull(response);
            assertEquals(response.responseStatus, EPurchaseOrderResponseStatusType.ACCEPTED.toString());

        } catch (ApplicationException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testPlaceOrderNull() throws ObjectNotFoundException {
        try {

            // Setup data
            purchaseOrder = null;

            // Setup expected behavior
            when(ehrRequestFactoryService.createRequest(isNull(), anyString())).thenReturn(request);
//            when(ehrMessagesService.createEhrPurchaseOrderHistory(history)).thenReturn(history);

            // Run the method
            PurchaseOrderResponse response = spy.placeOrder(purchaseOrder);

            // Verify
            assertEquals(response.responseStatus, EPurchaseOrderResponseStatusType.REJECTED_INVALID_PURCHASE_ORDER_STRUCTURE.toString());

        } catch (ApplicationException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testPlaceOrderDodaacNull() throws ObjectNotFoundException {
        try {

            // Setup data
            purchaseOrder.dodaac = null;

            // Setup expected behavior
            when(ehrRequestFactoryService.createRequest(any(EhrPurchaseOrder.class), anyString())).thenReturn(request);
         //   when(ehrMessagesService.createEhrPurchaseOrderHistory(history)).thenReturn(history);

            // Run the method
            PurchaseOrderResponse response = spy.placeOrder(purchaseOrder);

            // Verify
            assertEquals(response.responseStatus, EPurchaseOrderResponseStatusType.REJECTED_MISSING_OR_UNKNOWN_DODAAC.toString());

        } catch (ApplicationException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void testPlaceOrderAccountIdNull() throws ObjectNotFoundException {
        try {

            // Setup data
            purchaseOrder.customerAccountId = null;

            // Setup expected behavior
            when(ehrRequestFactoryService.createRequest(any(EhrPurchaseOrder.class), anyString())).thenReturn(request);
//            when(ehrMessagesService.createEhrPurchaseOrderHistory(history)).thenReturn(history);


            // Run the method
            PurchaseOrderResponse response = spy.placeOrder(purchaseOrder);

            // Verify
            assertEquals(response.responseStatus, EPurchaseOrderResponseStatusType.REJECTED_MISSING_OR_UNKNOWN_CUSTOMER_ACCOUNT_ID.toString());

        } catch (ApplicationException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testPlaceOrderDmlssHostNull() throws ObjectNotFoundException {
        try {

            // Setup expected behavior
            when(ehrRequestFactoryService.createRequest(any(EhrPurchaseOrder.class), anyString())).thenReturn(request);
//            when(ehrMessagesService.createEhrPurchaseOrderHistory(history)).thenReturn(history);
            when(organizationService.getDmlssHostByDodaac(anyString())).thenReturn(null);

            // Run the method
            PurchaseOrderResponse response = spy.placeOrder(purchaseOrder);

            // Verify
            assertEquals(response.responseStatus, EPurchaseOrderResponseStatusType.REJECTED_MISSING_OR_UNKNOWN_DODAAC.toString());

        } catch (ApplicationException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testPlaceOrderNotUnique() throws ObjectNotFoundException {
        try {

            // Setup expected behavior
            when(ehrRequestFactoryService.createRequest(any(EhrPurchaseOrder.class), anyString())).thenReturn(request);
//            when(ehrMessagesService.createEhrPurchaseOrderHistory(history)).thenReturn(history);
            when(organizationService.getDmlssHostByDodaac(anyString())).thenReturn(new DmlssHost());

            // Run the method
            PurchaseOrderResponse response = spy.placeOrder(purchaseOrder);

            // Verify
            assertEquals(response.responseStatus, EPurchaseOrderResponseStatusType.REJECTED_PO_NUMBER_IS_NOT_UNIQUE.toString());

        } catch (ApplicationException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testPlaceOrderNotValid() throws ObjectNotFoundException {
        try {

            // Setup expected behavior
            when(ehrRequestFactoryService.createRequest(any(EhrPurchaseOrder.class), anyString())).thenReturn(request);
//            when(ehrMessagesService.createEhrPurchaseOrderHistory(history)).thenReturn(history);
            when(organizationService.getDmlssHostByDodaac(anyString())).thenReturn(new DmlssHost());
            when(ehrMessagesService.isPONumberUnique(anyString(),anyString(),anyString())).thenReturn(true);

            // Run the method
            PurchaseOrderResponse response = spy.placeOrder(purchaseOrder);

            // Verify
            assertEquals(response.responseStatus, EPurchaseOrderResponseStatusType.REJECTED_MISSING_OR_UNKNOWN_CUSTOMER_ACCOUNT_ID.toString());

        } catch (ApplicationException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testGetLogicoleAuthToken() throws ObjectNotFoundException {

        String jsonWebtoken = "jsonWebToken";

        // Setup expected behavior
        when(userService.logIn()).thenReturn(new LoginCredential(new CurrentUser(), jsonWebtoken));

        // Run the method
        LogiColeAuthToken logiColeAuthToken = spy.getLogicoleAuthToken();

        // Verify
        assertEquals(logiColeAuthToken.authctoken, jsonWebtoken);

    }

}
