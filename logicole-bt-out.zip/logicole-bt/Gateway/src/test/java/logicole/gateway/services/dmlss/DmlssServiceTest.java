package logicole.gateway.services.dmlss;

import logicole.common.datamodels.dmlss.DmlssServerFunction;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class DmlssServiceTest {

    @InjectMocks
    private DmlssService service;

    @Test
    public void getLastTransactionComplete1Test() {
        List<DmlssServerFunction.Transaction.Ref> transactions = new ArrayList<>();
        DmlssServerFunction.Transaction.Ref t1 = new DmlssServerFunction.Transaction.Ref();
        t1.completionDate = new Date();
        transactions.add(t1);
        DmlssServerFunction.Transaction.Ref t2 = new DmlssServerFunction.Transaction.Ref();
        transactions.add(t2);

        Date result = service.getLastTransactionCompleted(transactions);

        Assert.assertEquals(t1.completionDate, result);
    }

    @Test
    public void getLastTransactionComplete2Test() {
        List<DmlssServerFunction.Transaction.Ref> transactions = new ArrayList<>();

        Date result = service.getLastTransactionCompleted(transactions);

        Assert.assertNull(result);
    }


    @Test
    public void getLastTransactionComplete3Test() {
        List<DmlssServerFunction.Transaction.Ref> transactions = new ArrayList<>();
        DmlssServerFunction.Transaction.Ref t1 = new DmlssServerFunction.Transaction.Ref();
        transactions.add(t1);
        DmlssServerFunction.Transaction.Ref t2 = new DmlssServerFunction.Transaction.Ref();
        transactions.add(t2);

        Date result = service.getLastTransactionCompleted(transactions);

        Assert.assertNull(result);
    }

    @Test
    public void getLastTransactionComplete4Test() {
        List<DmlssServerFunction.Transaction.Ref> transactions = new ArrayList<>();
        DmlssServerFunction.Transaction.Ref t1 = new DmlssServerFunction.Transaction.Ref();
        t1.completionDate = new Date();
        transactions.add(t1);
        DmlssServerFunction.Transaction.Ref t2 = new DmlssServerFunction.Transaction.Ref();
        t2.completionDate = new Date();
        transactions.add(t2);

        Date result = service.getLastTransactionCompleted(transactions);

        Assert.assertEquals(t2.completionDate, result);
    }

}
