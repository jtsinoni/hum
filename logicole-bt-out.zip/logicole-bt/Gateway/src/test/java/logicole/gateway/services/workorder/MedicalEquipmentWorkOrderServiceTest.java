package logicole.gateway.services.workorder;

import logicole.apis.workorder.IMedicalEquipmentWorkOrderMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.datamodels.workorder.EWorkflowName;
import logicole.common.datamodels.workorder.EWorkflowStepName;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.gateway.services.asset.BusinessContactService;
import logicole.gateway.services.asset.MedicalEquipmentService;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.user.UserService;
import logicole.gateway.services.workorder.validator.MedicalEquipmentWorkOrderGainValidator;
import logicole.gateway.services.workorder.workflow.MedicalEquipmentWorkOrderWorkflowService;
import org.bson.types.ObjectId;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MedicalEquipmentWorkOrderServiceTest {

    @Mock
    private IMedicalEquipmentWorkOrderMicroserviceApi microservice;
    @Mock
    private CurrentUserBT currentUserBT;
    @Mock
    private CurrentUser currentUser;
    @Mock
    private UserService userService;
    @Mock
    private MedicalEquipmentWorkOrderGainValidator medicalEquipmentWorkOrderGainValidator;
    @Mock
    private MedicalEquipmentWorkOrderWorkflowService workflowService;
    @Mock
    private WorkOrderService workOrderService;
    @Mock
    private FileManagerAdminService fileManagerAdminService;
    @Mock
    private BusinessContactService businessContactService;
    @Mock
    private MedicalEquipmentService medicalEquipmentService;

    @Spy
    @InjectMocks
    private MedicalEquipmentWorkOrderService medicalEquipmentWorkOrderService;

    private UserProfile userProfile;
    private WorkOrder workOrder;
    private OrganizationRef currentNodeRef;

    @Before
    public void setUp() {
        populateUserProfile();
        whenGetCurrentUserThenReturnCurrentUser();
        populateWorkOrder();
    }

    private void populateUserProfile() {
        userProfile = new UserProfile();
        userProfile._id = new ObjectId();
        currentNodeRef = new OrganizationRef();
        userProfile.currentNodeRef = currentNodeRef;
        currentUser.profile = userProfile;
    }

    private void whenGetCurrentUserThenReturnCurrentUser() {
        when(currentUserBT.getCurrentUser()).thenReturn(currentUser);
    }

    private void populateWorkOrder() {
        workOrder = new WorkOrder();
        workOrder._id = new ObjectId();
    }

    @Test
    public void shouldStartUnscheduledWorkOrderWorkflowAtSubmitted() {
        when(microservice.createWorkOrder(workOrder)).thenAnswer(AdditionalAnswers.returnsFirstArg());
        medicalEquipmentWorkOrderService.createWorkOrder(workOrder);
        verify(workflowService)
                .startAction(workOrder, EWorkflowName.STANDARD_MEDICAL_EQUIPMENT_WORK_ORDER.displayText,
                             EWorkflowStepName.SUBMITTED.position, currentUserBT.getCurrentUser().profile.managedByNodeRef);
    }

    @Test
    public void shouldSetManagedByOrganizationWhenCreatingUnscheduledWorkOrder() {
        when(microservice.createWorkOrder(workOrder)).thenAnswer(AdditionalAnswers.returnsFirstArg());
        WorkOrder actual = medicalEquipmentWorkOrderService.createWorkOrder(workOrder);
        assertSame(currentUserBT.getCurrentUser().profile.currentNodeRef, actual.managedByOrganizationRef);
    }

    @Test
    public void shouldSetCreatedByToCurrentUserWhenCreatingUnscheduledWorkOrder() {
        when(microservice.createWorkOrder(workOrder)).thenAnswer(AdditionalAnswers.returnsFirstArg());
        WorkOrder actual = medicalEquipmentWorkOrderService.createWorkOrder(workOrder);
        assertEquals(currentUserBT.getCurrentUser().profile.getRef() , actual.createdByRef);
    }

    @Test
    public void shouldReturnAvailableEquipment() {
        List<Asset> expected = new ArrayList<>();
        String customerId = "testCustomerId";
        when(medicalEquipmentService.getAvailableEquipment(customerId)).thenReturn(expected);
        List<Asset> actual = medicalEquipmentWorkOrderService.getAvailableEquipment(customerId);
        assertSame(expected, actual);
    }

    @Test
    public void shouldReturnEquipmentCustomers() {
        List<OrganizationRef> expected = new ArrayList<>();
        when(medicalEquipmentService.getEquipmentCustomers()).thenReturn(expected);
        List<OrganizationRef> actual = medicalEquipmentWorkOrderService.getEquipmentCustomers();
        assertSame(expected, actual);
    }

    @Test
    public void shouldReturnOpenWorkOrdersForCustomer() {
        String customerId = "testCustomerId";
        String ecn = "testEcn";
        List<WorkOrder> expected = new ArrayList<>();
        when(microservice.getOpenWorkOrders(customerId, ecn)).thenReturn(expected);
        List<WorkOrder> actual = medicalEquipmentWorkOrderService.getOpenWorkOrders(customerId, ecn);
        assertSame(expected, actual);
    }
}
