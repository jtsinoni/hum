package logicole.gateway.services.workorder;

import logicole.apis.workorder.ICoreWorkOrderMicroserviceApi;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.general.exception.ApplicationException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CoreWorkOrderServiceTest {

    @Mock
    private ICoreWorkOrderMicroserviceApi microservice;

    @Spy
    @InjectMocks
    private CoreWorkOrderService coreWorkOrderService;

    @Test
    public void getWorkOrders_withElasticSearchEngine_thenThrowApplicationException() {
        when(microservice.getWorkOrderSearchEngine()).thenReturn(ESearchEngine.ELASTIC);
        Exception exception = assertThrows(ApplicationException.class, () -> coreWorkOrderService.getWorkOrders(new SearchInput()));
        assertEquals("Elastic search is not supported now", exception.getMessage());
    }

    @Test
    public void getWorkOrders_withMongoSearchEngine_thenReturnSearchResult() {
        SearchResult<WorkOrder> expected = new SearchResult<>();
        expected.total = 1L;
        when(microservice.getWorkOrderSearchEngine()).thenReturn(ESearchEngine.MONGO);
        when(microservice.getWorkOrderSearchResults(Mockito.any())).thenReturn(expected);
        SearchResult<WorkOrder> actual = coreWorkOrderService.getWorkOrders(new SearchInput());
        assertEquals(expected.total, actual.total);
    }
}