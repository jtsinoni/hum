package logicole.gateway.services.product;

import static org.mockito.Mockito.*;

import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.ehr.equipment.*;
import logicole.common.datamodels.product.Offer;
import logicole.common.datamodels.product.Product;
import logicole.common.general.exception.ApplicationException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

@RunWith(MockitoJUnitRunner.class)
public class ItemMasterSupplyCatalogFactoryTest {

    @Spy
    @InjectMocks
    private ItemMasterSupplyItemsFactory spy;

    @Test
    public void createCatalogListTest()  throws ApplicationException {
        List<Offer> offers = new ArrayList<>();
        Offer offer = new Offer();
        offer.product = new Product();
        offer.price = new MonetaryValue(0);
        offers.add(offer);

        ItemMasterSupplyCatalogItem item = new ItemMasterSupplyCatalogItem();
        item.deltaType = EItemMasterSupplyItemDeltaType.FULL;
        Date date = new Date();
        doReturn(item).when(spy).create(any(Offer.class), eq(EItemMasterSupplyCatalogType.ITEM_COMPLETE), eq(date));
        String siteId = "siteId";
        String cust = "cust";

        spy.convert(offers, EItemMasterSupplyCatalogType.ITEM_COMPLETE, date, siteId, cust);

        verify(spy).create(any(Offer.class), eq(EItemMasterSupplyCatalogType.ITEM_COMPLETE), eq(date));
    }

    @Test
    public void createCatalogItemTest() throws ApplicationException {
        Offer offer = new Offer();

        ItemMasterSupplyCatalogItem item = new ItemMasterSupplyCatalogItem();
        offer.product = new Product();
        offer.product.implant = "false";
        offer.product.packaging = new ArrayList<>();
        offer.product.unspscCode = 1;
        offer.product.enterpriseProductIdentifier = "Bogus";

        List<ItemMasterSupplyItemPackaging> list = mock(List.class);

        doReturn(list).when(spy).getPackaging(any(List.class));

        spy.create(offer, EItemMasterSupplyCatalogType.ITEM_COMPLETE, new Date());

        verify(spy).getPackaging(any(List.class));
    }
}
