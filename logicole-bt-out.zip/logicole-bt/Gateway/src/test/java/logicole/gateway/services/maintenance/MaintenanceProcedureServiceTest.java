package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.IMaintenanceProcedureMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.maintenance.plan.EMaintenanceIntervalType;
import logicole.common.datamodels.maintenance.plan.MaintenancePlan;
import logicole.common.datamodels.maintenance.procedure.CalibrationTask;
import logicole.common.datamodels.maintenance.procedure.CloneMaintenanceProcedure;
import logicole.common.datamodels.maintenance.procedure.GenericPart;
import logicole.common.datamodels.maintenance.procedure.MaintenanceProcedure;
import logicole.common.datamodels.maintenance.procedure.MaintenanceProcedureCatalogedPart;
import logicole.common.datamodels.maintenance.procedure.MaintenanceProcedureGenericPart;
import logicole.common.datamodels.maintenance.procedure.MaintenanceProcedureMiscellaneousSupply;
import logicole.common.datamodels.maintenance.procedure.MiscellaneousSupply;
import logicole.common.datamodels.maintenance.procedure.MiscellaneousSupplyRef;
import logicole.common.datamodels.maintenance.procedure.SpecialCharacter;
import logicole.common.datamodels.maintenance.procedure.Task;
import logicole.common.datamodels.maintenance.procedure.TestEquipmentSpecialTool;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationTypeRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.gateway.services.organization.OrganizationService;
import org.bson.types.ObjectId;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MaintenanceProcedureServiceTest {
    @Spy
    @InjectMocks
    private MaintenanceProcedureService maintenanceProcedureService;
    @Mock
    private IMaintenanceProcedureMicroserviceApi microservice;
    @Mock
    private CurrentUserBT currentUserBT;
    @Mock
    private CurrentUser currentUser;
    @Mock
    private UserProfile userProfile;
    @Mock
    private MaintenancePlanService maintenancePlanService;
    @Mock
    private OrganizationService organizationService;
    private OrganizationRef currentNodeRef;

    private MaintenanceProcedure maintenanceProcedure;
    private String ancestry;

    @Before
    public void setup() {
        maintenanceProcedure = new MaintenanceProcedure();
        maintenanceProcedure._id = new ObjectId();
        whenGetCurrentUserThenReturnCurrentUser();
        whenGetCurrentNodeIdThenReturnCurrentUserNodeId();
        maintenanceProcedure.managedByNodeRef = new OrganizationRef();
        maintenanceProcedure.managedByNodeRef.id = currentNodeRef.id;
        maintenanceProcedure.managedByNodeRef.ancestry = currentNodeRef.ancestry;
        whenFindByIdThenReturnMaintenanceProcedure();
    }

    private void whenGetCurrentUserThenReturnCurrentUser() {
        currentNodeRef = new OrganizationRef();
        currentNodeRef.id = "testId";
        ancestry = "test,ancestry," + currentNodeRef.id;
        currentNodeRef.ancestry = ancestry;
        userProfile.currentNodeRef = currentNodeRef;
        userProfile.nodeTypeRef = new OrganizationTypeRef();
        userProfile.nodeTypeRef.level = 100;
        currentUser.profile = userProfile;
        when(currentUserBT.getCurrentUser()).thenReturn(currentUser);
    }

    private void whenGetCurrentNodeIdThenReturnCurrentUserNodeId() {
        when(currentUserBT.getCurrentNodeId()).thenReturn(currentUser.profile.currentNodeRef.id);
    }

    private void whenFindByIdThenReturnMaintenanceProcedure() {
        when(microservice.findById(anyString())).thenReturn(maintenanceProcedure);
    }

    @Test
    public void whenCreatingMaintenanceProcedureDraft_shouldReturnMaintenanceProcedure() {
        when(microservice.createMaintenanceProcedureDraft(any(MaintenanceProcedure.class))).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actualMaintenanceProcedureDraft = maintenanceProcedureService.createMaintenanceProcedureDraft(maintenanceProcedure);
        assertSame(maintenanceProcedure, actualMaintenanceProcedureDraft);
    }

    @Test
    public void whenFindById_shouldReturnMaintenanceProcedure() {
        when(microservice.findById(anyString())).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.findById(maintenanceProcedure.getId());
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenSavingHeaderInfo_shouldReturnMaintenanceProcedure() {
        when(microservice.saveMaintenanceProcedureHeaderInformation(any())).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.saveMaintenanceProcedureHeaderInformation(maintenanceProcedure);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenSavingGeneralInfo_shouldReturnMaintenanceProcedure() {
        when(microservice.saveMaintenanceProcedureHeaderInformation(any())).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.saveMaintenanceProcedureHeaderInformation(maintenanceProcedure);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenSearching_shouldReturnMaintenanceProcedureSearchResults() {
        SearchInput searchInput = new SearchInput();
        SearchResult<MaintenanceProcedure> expected = new SearchResult<>();
        when(microservice.getMaintenanceProcedureSearchResults(searchInput, currentNodeRef.ancestry, 100)).thenReturn(expected);
        SearchResult<MaintenanceProcedure> actual = maintenanceProcedureService.getMaintenanceProcedureSearchResults(searchInput);
        assertSame(expected, actual);
    }

    @Test
    public void whenAddingGenericPart_shouldSetManagedBy() {
        GenericPart genericPart = new GenericPart();
        when(microservice.addGenericPart(genericPart)).thenAnswer(AdditionalAnswers.returnsFirstArg());
        GenericPart actual = maintenanceProcedureService.addGenericPart(genericPart);
        assertSame(currentNodeRef, actual.managedByNodeRef);
    }

    @Test
    public void whenAddingPreventiveMaintenanceTask_shouldReturnMaintenanceProcedure() {
        when(microservice.addPreventiveMaintenanceTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.addPreventiveMaintenanceTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenUpdatingPreventiveMaintenanceTask_shouldReturnMaintenanceProcedure() {
        when(microservice.updatePreventiveMaintenanceTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.updatePreventiveMaintenanceTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenDeletingPreventiveMaintenanceTask_shouldReturnMaintenanceProcedure() {
        when(microservice.deletePreventiveMaintenanceTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.deletePreventiveMaintenanceTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenAddingNewMiscellaneousSupply_shouldSetManagedBy() {
        MiscellaneousSupply miscellaneousSupply = new MiscellaneousSupply();
        when(microservice.addMiscellaneousSupply(miscellaneousSupply)).thenAnswer(AdditionalAnswers.returnsFirstArg());
        MiscellaneousSupply actual = maintenanceProcedureService.addMiscellaneousSupply(miscellaneousSupply);
        assertSame(currentNodeRef, actual.managedByNodeRef);
    }

    @Test
    public void whenAddingNewGenericPart_shouldReturnMaintenanceProcedure() {
        when(microservice.addGenericPart(any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
        when(microservice.addMaintenanceProcedureGenericPart(anyString(), any(MaintenanceProcedureGenericPart.class))).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.newMaintenanceProcedureGenericPart(this.maintenanceProcedure.getId(), 1, EMaintenanceIntervalType.INSPECTION.toString(), new GenericPart());
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenUpdatingGenericPart_shouldReturnGenericPart() {
        when(microservice.updateGenericPart(any())).thenAnswer(AdditionalAnswers.returnsFirstArg());
        GenericPart genericPart = new GenericPart();
        GenericPart actualGenericPart = maintenanceProcedureService.updateGenericPart(genericPart);
        assertSame(genericPart, actualGenericPart);
    }

    @Test
    public void whenDeletingGenericPart_shouldReturnBooleanWhenDeletingGenericPart() {
        when(microservice.deleteGenericPart(anyString())).thenReturn(true);
        boolean deleted = maintenanceProcedureService.deleteGenericPart("testId");
        assertTrue(deleted);
    }

    @Test
    public void whenAddingMaintenanceProcedureGenericPart_shouldReturnMaintenanceProcedure() {
        when(microservice.addMaintenanceProcedureGenericPart(anyString(), any(MaintenanceProcedureGenericPart.class))).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.addMaintenanceProcedureGenericPart(this.maintenanceProcedure.getId(), new MaintenanceProcedureGenericPart());
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenUpdatingMaintenanceProcedureGenericPart_shouldReturnMaintenanceProcedure() {
        when(microservice.updateMaintenanceProcedureGenericPart(anyString(), any(MaintenanceProcedureGenericPart.class))).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.updateMaintenanceProcedureGenericPart(this.maintenanceProcedure.getId(), new MaintenanceProcedureGenericPart());
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenDeletingMaintenanceProcedureGenericPart_shouldReturnMaintenanceProcedure() {
        when(microservice.deleteMaintenanceProcedureGenericPart(anyString(), any(MaintenanceProcedureGenericPart.class))).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.deleteMaintenanceProcedureGenericPart(this.maintenanceProcedure.getId(), new MaintenanceProcedureGenericPart());
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenUpdatingGeneralInfo_shouldReturnMaintenanceProcedure() {
        when(microservice.updateGeneralInformation(any(MaintenanceProcedure.class))).thenAnswer(AdditionalAnswers.returnsFirstArg());
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.updateGeneralInformation(this.maintenanceProcedure);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenFindingMaintenancePlansForProcedure_shouldReturnListOfMaintenancePlans() {
        when(maintenancePlanService.getMaintenancePlansForMaintenanceProcedure(anyString())).thenReturn(new ArrayList<>());
        List<MaintenancePlan> maintenancePlans = maintenanceProcedureService.getMaintenancePlansForMaintenanceProcedure(maintenanceProcedure.getId());
        assertNotNull(maintenancePlans);
    }

    @Test
    public void whenDelete_shouldReturnMaintenanceProcedure() {
        when(microservice.deleteById(anyString())).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.deleteById(this.maintenanceProcedure.getId());
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenGettingGenericParts_shouldReturnGenericParts() {
        when(microservice.getGenericParts()).thenReturn(new ArrayList<>());
        List<GenericPart> genericParts = maintenanceProcedureService.getGenericParts();
        assertNotNull(genericParts);
    }

    @Test
    public void whenGettingMaintenanceIntervalTypes_shouldReturnListOfMaintenanceIntervalTypes() {
        List<EMaintenanceIntervalType> maintenanceIntervalTypes = maintenanceProcedureService.getMaintenanceIntervalTypes();
        assertFalse(maintenanceIntervalTypes.isEmpty());
    }

    @Test
    public void whenGettingTestEquipmentSpecialTools_shouldReturnListOfTestEquipmentSpecialTools() {
        when(microservice.getTestEquipmentSpecialTools()).thenReturn(new ArrayList<>());
        List<TestEquipmentSpecialTool> testEquipmentSpecialTools = maintenanceProcedureService.getTestEquipmentSpecialTools();
        assertNotNull(testEquipmentSpecialTools);
    }

    @Test
    public void whenAddingNewTestEquipmentSpecialTool_shouldSetManagedBy() {
        TestEquipmentSpecialTool testEquipmentSpecialTool = new TestEquipmentSpecialTool();
        when(microservice.createTestEquipmentSpecialTool(testEquipmentSpecialTool)).thenAnswer(AdditionalAnswers.returnsFirstArg());
        TestEquipmentSpecialTool actual = maintenanceProcedureService.createTestEquipmentSpecialTool(testEquipmentSpecialTool);
        assertSame(currentNodeRef, actual.managedByNodeRef);
    }

    @Test
    public void whenAddingNewTestEquipmentSpecialTool_shouldReturnTestEquipmentSpecialTool() {
        TestEquipmentSpecialTool testEquipmentSpecialTool = new TestEquipmentSpecialTool();
        when(microservice.createTestEquipmentSpecialTool(testEquipmentSpecialTool)).thenAnswer(AdditionalAnswers.returnsFirstArg());
        TestEquipmentSpecialTool actual = maintenanceProcedureService.createTestEquipmentSpecialTool(testEquipmentSpecialTool);
        assertSame(testEquipmentSpecialTool, actual);
    }

    @Test
    public void whenUpdatingNewTestEquipmentSpecialTool_shouldReturnTestEquipmentSpecialTool() {
        TestEquipmentSpecialTool testEquipmentSpecialTool = new TestEquipmentSpecialTool();
        when(microservice.updateTestEquipmentSpecialTool(testEquipmentSpecialTool)).thenAnswer(AdditionalAnswers.returnsFirstArg());
        TestEquipmentSpecialTool actual = maintenanceProcedureService.updateTestEquipmentSpecialTool(testEquipmentSpecialTool);
        assertSame(testEquipmentSpecialTool, actual);
    }

    @Test
    public void whenDeletingTestEquipmentSpecialTool_shouldReturnNothing() {
        doNothing().when(microservice).deleteTestEquipmentSpecialToolById(anyString());
        maintenanceProcedureService.deleteTestEquipmentSpecialToolById("testId");
        assertTrue(true);
    }

    @Test
    public void shouldReturnListOfSpecialCharacters() {
        when(microservice.getSpecialCharacters()).thenReturn(new ArrayList<>());
        List<SpecialCharacter> specialCharacters = maintenanceProcedureService.getSpecialCharacters();
        assertNotNull(specialCharacters);
    }

    @Test
    public void whenAddingInspectionTask_shouldReturnMaintenanceProcedure() {
        when(microservice.addInspectionTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.addInspectionTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenUpdatingInspectionTask_shouldReturnMaintenanceProcedure() {
        when(microservice.updateInspectionTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.updateInspectionTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenDeletingInspectionTask_shouldReturnMaintenanceProcedure() {
        when(microservice.deleteInspectionTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.deleteInspectionTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenAddingProcedureMiscellaneousSupply_shouldReturnMaintenanceProcedure() {
        String id = maintenanceProcedure.getId();
        MaintenanceProcedureMiscellaneousSupply miscellaneousSupply = new MaintenanceProcedureMiscellaneousSupply();
        when(microservice.addMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply)).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actual = maintenanceProcedureService.addMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply);
        assertSame(maintenanceProcedure, actual);
    }

    @Test
    public void whenUpdatingProcedureMiscellaneousSupply_shouldReturnMaintenanceProcedure() {
        String id = maintenanceProcedure.getId();
        MaintenanceProcedureMiscellaneousSupply miscellaneousSupply = new MaintenanceProcedureMiscellaneousSupply();
        when(microservice.updateMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply)).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actual = maintenanceProcedureService.updateMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply);
        assertSame(maintenanceProcedure, actual);
    }

    @Test
    public void whenDeletingProcedureMiscellaneousSupply_shouldReturnMaintenanceProcedure() {
        String id = maintenanceProcedure.getId();
        MaintenanceProcedureMiscellaneousSupply miscellaneousSupply = new MaintenanceProcedureMiscellaneousSupply();
        when(microservice.deleteMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply)).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actual = maintenanceProcedureService.deleteMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply);
        assertSame(maintenanceProcedure, actual);
    }

    @Test
    public void whenCreatingProcedureMiscellaneousSupply_shouldReturnMaintenanceProcedure() {
        String id = maintenanceProcedure.getId();
        MaintenanceProcedureMiscellaneousSupply miscellaneousSupply = new MaintenanceProcedureMiscellaneousSupply();
        when(microservice.createMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply)).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actual = maintenanceProcedureService.createMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply);
        assertSame(maintenanceProcedure, actual);
    }

    @Test
    public void whenCreatingProcedureMiscellaneousSupply_shouldSetManagedBy() {
        String id = maintenanceProcedure.getId();
        MaintenanceProcedureMiscellaneousSupply miscellaneousSupply = new MaintenanceProcedureMiscellaneousSupply();
        miscellaneousSupply.miscellaneousSupplyRef = new MiscellaneousSupplyRef();
        when(microservice.createMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply)).thenAnswer((parameters) -> {
            maintenanceProcedure.miscellaneousSupplies = new ArrayList<>();
            maintenanceProcedure.miscellaneousSupplies.add(parameters.getArgument(1));
            return maintenanceProcedure;
        });
        MaintenanceProcedure actual = maintenanceProcedureService.createMaintenanceProcedureMiscellaneousSupply(id, miscellaneousSupply);
        assertSame(currentNodeRef, actual.miscellaneousSupplies.get(0).miscellaneousSupplyRef.managedByNodeRef);
    }

    @Test
    public void whenAddingCatalogedPart_shouldReturnMaintenanceProcedure() {
        when(microservice.addMaintenanceProcedureCatalogPart(anyString(), any(MaintenanceProcedureCatalogedPart.class))).thenReturn(maintenanceProcedure);
        MaintenanceProcedureCatalogedPart part = new MaintenanceProcedureCatalogedPart();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.addMaintenanceProcedureCatalogPart(this.maintenanceProcedure.getId(), part);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenUpdatingCatalogedPart_shouldReturnMaintenanceProcedure() {
        when(microservice.updateMaintenanceProcedureCatalogPart(anyString(), any(MaintenanceProcedureCatalogedPart.class))).thenReturn(maintenanceProcedure);
        MaintenanceProcedureCatalogedPart part = new MaintenanceProcedureCatalogedPart();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.updateMaintenanceProcedureCatalogPart(this.maintenanceProcedure.getId(), part);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenDeletingCataloged_shouldReturnMaintenanceProcedure() {
        when(microservice.deleteMaintenanceProcedureCatalogPart(anyString(), any(MaintenanceProcedureCatalogedPart.class))).thenReturn(maintenanceProcedure);
        MaintenanceProcedureCatalogedPart part = new MaintenanceProcedureCatalogedPart();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.deleteMaintenanceProcedureCatalogPart(this.maintenanceProcedure.getId(), part);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenAddingCalibrationTask_shouldReturnMaintenanceProcedure() {
        when(microservice.addCalibrationTask(anyString(), any(CalibrationTask.class))).thenReturn(maintenanceProcedure);
        CalibrationTask task = new CalibrationTask();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.addCalibrationTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenUpdatingCalibrationTask_shouldReturnMaintenanceProcedure() {
        when(microservice.updateCalibrationTask(anyString(), any(CalibrationTask.class))).thenReturn(maintenanceProcedure);
        CalibrationTask task = new CalibrationTask();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.updateCalibrationTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenDeletingCalibrationTask_shouldReturnMaintenanceProcedure() {
        when(microservice.deleteCalibrationTask(anyString(), any(CalibrationTask.class))).thenReturn(maintenanceProcedure);
        CalibrationTask task = new CalibrationTask();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.deleteCalibrationTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenAddingSprTask_shouldReturnMaintenanceProcedure() {
        when(microservice.addScheduledPartsReplacementTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.addScheduledPartsReplacementTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenUpdatingSprTask_shouldReturnMaintenanceProcedure() {
        when(microservice.updateScheduledPartsReplacementTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.updateScheduledPartsReplacementTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenDeletingSprTask_shouldReturnMaintenanceProcedure() {
        when(microservice.deleteScheduledPartsReplacementTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.deleteScheduledPartsReplacementTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenAddingAcceptanceInspectionTask_shouldReturnMaintenanceProcedure() {
        when(microservice.addAcceptanceInspectionTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.addAcceptanceInspectionTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenUpdatingAcceptanceInspectionTask_shouldReturnMaintenanceProcedure() {
        when(microservice.updateAcceptanceInspectionTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.updateAcceptanceInspectionTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenDeletingAcceptanceInspectionTask_shouldReturnMaintenanceProcedure() {
        when(microservice.deleteAcceptanceInspectionTask(anyString(), any(Task.class))).thenReturn(maintenanceProcedure);
        Task task = new Task();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.deleteAcceptanceInspectionTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenAddingAcceptanceCalibrationTask_shouldReturnMaintenanceProcedure() {
        when(microservice.addAcceptanceCalibrationTask(anyString(), any(CalibrationTask.class))).thenReturn(maintenanceProcedure);
        CalibrationTask task = new CalibrationTask();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.addAcceptanceCalibrationTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenUpdatingAcceptanceCalibrationTask_shouldReturnMaintenanceProcedure() {
        when(microservice.updateAcceptanceCalibrationTask(anyString(), any(CalibrationTask.class))).thenReturn(maintenanceProcedure);
        CalibrationTask task = new CalibrationTask();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.updateAcceptanceCalibrationTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenDeletingAcceptanceCalibrationTask_shouldReturnMaintenanceProcedure() {
        when(microservice.deleteAcceptanceCalibrationTask(anyString(), any(CalibrationTask.class))).thenReturn(maintenanceProcedure);
        CalibrationTask task = new CalibrationTask();
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.deleteAcceptanceCalibrationTask(this.maintenanceProcedure.getId(), task);
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }

    @Test
    public void whenPromotingMaintenanceProcedureToAgencyLevel_shouldReturnMaintenanceProcedure() {
        when(microservice.clone(any(CloneMaintenanceProcedure.class))).thenReturn(maintenanceProcedure);
        MaintenanceProcedure actualMaintenanceProcedure = maintenanceProcedureService.promoteMaintenanceProcedureToAgencyLevel(this.maintenanceProcedure.getId());
        assertSame(maintenanceProcedure, actualMaintenanceProcedure);
    }
}
