package logicole.gateway.services.ehr;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import logicole.common.datamodels.ehr.equipment.*;

import logicole.common.general.exception.ObjectNotFoundException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class SupplyItemAccumulatorTest {
    @Mock
    private ItemMasterSupplyItemSiteInfo info;

    @Spy
    @InjectMocks
    private ItemMasterSupplyCatalogAccumulator spy;

    @Before
    public void before() {
        setup();
    }

    private void setup() {
    
        EItemMasterSupplyCatalogType catType;
    }

    @Test
    public void testAddAllAndGetItems() throws ObjectNotFoundException {
        String itemId1 = "5c3653cb93f521351a7770ee";
        String itemId2 = "5c3653cb93f521351a7770ef";
        String itemId3 = "5c3653cb93f521351a7770ee";
        EItemMasterSupplyCatalogType catType = null;

        List<ItemMasterSupplyCatalogItem> items= new ArrayList<ItemMasterSupplyCatalogItem>();
        ItemMasterSupplyCatalogItem item1 = new ItemMasterSupplyCatalogItem();
        ItemMasterSupplyCatalogItem item2 = new ItemMasterSupplyCatalogItem();
        ItemMasterSupplyCatalogItem item3 = new ItemMasterSupplyCatalogItem();

        item1.itemId = itemId1;
        item1.siteInfoList = new ArrayList<ItemMasterSupplyItemSiteInfo>();
        item1.siteInfoList.add(info);

        item2.itemId = itemId2;
        item2.siteInfoList = new ArrayList<ItemMasterSupplyItemSiteInfo>();
        item2.siteInfoList.add(info);

        item3.itemId = itemId3;
        item3.siteInfoList = new ArrayList<ItemMasterSupplyItemSiteInfo>();
        item3.siteInfoList.add(info);

        items.add(item1);
        items.add(item2);
        items.add(item3);


        //Run the Method
        spy.accumulate(items, new Date(), EItemMasterSupplyCatalogType.ITEM_COMPLETE);

        //verify the items were added and returned
        Collection<ItemMasterSupplyCatalogItem> itemsReturned = spy.getItems();

        assertTrue(itemsReturned.contains(item1));
        assertTrue(itemsReturned.contains(item2));
        assertFalse(itemsReturned.contains(item3));
        assertTrue(item1.siteInfoList.size() == 1);
        assertTrue(item2.siteInfoList.size() == 1);
        assertTrue(item3.siteInfoList.size() == 1);

        return;
    }

}
