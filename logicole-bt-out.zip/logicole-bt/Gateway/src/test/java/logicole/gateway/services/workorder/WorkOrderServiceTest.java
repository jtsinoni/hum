package logicole.gateway.services.workorder;

import logicole.common.datamodels.asset.maintenance.procedure.MaintenanceProcedureRef;
import logicole.common.datamodels.asset.schedule.Schedule;
import logicole.common.datamodels.communications.maximo.MaximoWorkRequest;
import logicole.common.datamodels.system.frequency.FrequencyRef;
import logicole.common.datamodels.workflow.WorkflowState;
import logicole.common.datamodels.workflow.WorkflowStep;
import logicole.common.datamodels.workflow.WorkflowStepDefinition;
import logicole.common.datamodels.workorder.EWorkflowStepName;
import logicole.common.datamodels.workorder.WorkOrder;
import logicole.common.datamodels.workorder.WorkOrderSummary;
import logicole.common.general.util.DateUtil;
import logicole.common.general.util.EDateTimeFormat;
import logicole.common.datamodels.workorder.CmmsConstants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doCallRealMethod;
import static org.mockito.Mockito.doReturn;

@RunWith(MockitoJUnitRunner.class)
public class WorkOrderServiceTest {

    @Spy
    @InjectMocks
    private WorkOrderService workOrderService;

    @Test
    public void isStartDateCoveredFalseWhenNoHigherPriorityWorkOrdersExist() {
        WorkOrder workOrder = workOrdersForPriorityTests().get(0);
        List<WorkOrder> higherPriorityWorkOrders = new ArrayList<>();
        assertFalse(workOrderService.isCoveredByHigherPriorityWorkOrder(workOrder, higherPriorityWorkOrders));
    }

    @Test
    public void isCoveredTrueWhenHigherPriorityWorkOrderExistsInSameMonth() {
        WorkOrder newWorkOrder = new WorkOrder();
        newWorkOrder.maintenanceProcedureRef = new MaintenanceProcedureRef();
        newWorkOrder.maintenanceProcedureRef.frequencyRef = new FrequencyRef();
        newWorkOrder.maintenanceProcedureRef.frequencyRef.rollupPriority = 3;
        newWorkOrder.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 5, 5));
        assertTrue(workOrderService.isCoveredByHigherPriorityWorkOrder(newWorkOrder, workOrdersForPriorityTests()));
    }

    @Test
    public void isCoveredFalseWhenHigherPriorityWorkOrderDontExistInSameMonth() {
        WorkOrder newWorkOrder = new WorkOrder();
        newWorkOrder.maintenanceProcedureRef = new MaintenanceProcedureRef();
        newWorkOrder.maintenanceProcedureRef.frequencyRef = new FrequencyRef();
        newWorkOrder.maintenanceProcedureRef.frequencyRef.rollupPriority = 3;
        newWorkOrder.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 7, 5));
        assertFalse(workOrderService.isCoveredByHigherPriorityWorkOrder(newWorkOrder, workOrdersForPriorityTests()));
    }

    @Test
    public void isCoveredFalseWhenNoPrioritySet() {
        WorkOrder newWorkOrder = new WorkOrder();
        newWorkOrder.maintenanceProcedureRef = new MaintenanceProcedureRef();
        newWorkOrder.maintenanceProcedureRef.frequencyRef = new FrequencyRef();
        newWorkOrder.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 7, 5));
        assertFalse(workOrderService.isCoveredByHigherPriorityWorkOrder(newWorkOrder, workOrdersForPriorityTests()));
    }

    @Test
    public void getHigherPriorityWorkOrdersShouldBeTwo() {
        int priorityToBeHigherThan = 2;
        List<WorkOrder> workOrders = workOrdersForPriorityTests();
        List<WorkOrder> higherPriorityWorkOrders = workOrderService.getHigherPriorityWorkOrders(priorityToBeHigherThan, workOrders);
        assertEquals(2, higherPriorityWorkOrders.size());
    }

    @Test
    public void getHigherPriorityWorkOrdersShouldBeZero() {
        int priorityToBeHigherThan = 1;
        List<WorkOrder> workOrders = workOrdersForPriorityTests();
        List<WorkOrder> higherPriorityWorkOrders = workOrderService.getHigherPriorityWorkOrders(priorityToBeHigherThan, workOrders);
        assertEquals(0, higherPriorityWorkOrders.size());
    }

    private List<WorkOrder> workOrdersForPriorityTests() {
        List<WorkOrder> workOrders = new ArrayList<>();
        WorkOrder workOrder1 = new WorkOrder();
        workOrder1.maintenanceProcedureRef = new MaintenanceProcedureRef();
        workOrder1.maintenanceProcedureRef.frequencyRef = new FrequencyRef();
        workOrder1.maintenanceProcedureRef.frequencyRef.rollupPriority = 1;
        workOrder1.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 5, 5));
        workOrders.add(workOrder1);
        WorkOrder workOrder2 = new WorkOrder();
        workOrder2.maintenanceProcedureRef = new MaintenanceProcedureRef();
        workOrder2.maintenanceProcedureRef.frequencyRef = new FrequencyRef();
        workOrder2.maintenanceProcedureRef.frequencyRef.rollupPriority = 1;
        workOrder2.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 6, 5));
        workOrders.add(workOrder2);
        WorkOrder workOrder3 = new WorkOrder();
        workOrder3.maintenanceProcedureRef = new MaintenanceProcedureRef();
        workOrder3.maintenanceProcedureRef.frequencyRef = new FrequencyRef();
        workOrder3.maintenanceProcedureRef.frequencyRef.rollupPriority = 2;
        workOrder3.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 5, 5));
        workOrders.add(workOrder3);
        return workOrders;
    }

    @Test
    public void scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder_DifferentMonth_True() {
        Schedule schedule = new Schedule();
        WorkOrder workOrder1 = new WorkOrder();
        workOrder1.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 5, 5));
        workOrder1.workflowState = new WorkflowState();
        workOrder1.workflowState.currentStep = new WorkflowStep();
        workOrder1.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder1.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;
        WorkOrder workOrder2 = new WorkOrder();
        workOrder2.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 6, 5));
        workOrder2.workflowState = new WorkflowState();
        workOrder2.workflowState.currentStep = new WorkflowStep();
        workOrder2.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder2.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;

        List<WorkOrderSummary> workOrderSummaries = new ArrayList<>();
        workOrderSummaries.add(workOrder1.getSummary());
        workOrderSummaries.add(workOrder2.getSummary());

        doReturn(workOrderSummaries).when(workOrderService).getSortedWorkOrderSummariesBySchedule(schedule.getId());

        assertTrue(workOrderService.scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder(schedule, workOrder2));
    }

    @Test
    public void scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder_DifferentMonth_False() {
        Schedule schedule = new Schedule();
        WorkOrder workOrder1 = new WorkOrder();
        workOrder1.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 5, 5));
        workOrder1.workflowState = new WorkflowState();
        workOrder1.workflowState.currentStep = new WorkflowStep();
        workOrder1.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder1.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;
        WorkOrder workOrder2 = new WorkOrder();
        workOrder2.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 6, 5));
        workOrder2.workflowState = new WorkflowState();
        workOrder2.workflowState.currentStep = new WorkflowStep();
        workOrder2.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder2.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;

        List<WorkOrderSummary> workOrderSummaries = new ArrayList<>();
        workOrderSummaries.add(workOrder1.getSummary());
        workOrderSummaries.add(workOrder2.getSummary());

        doReturn(workOrderSummaries).when(workOrderService).getSortedWorkOrderSummariesBySchedule(schedule.getId());

        assertFalse(workOrderService.scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder(schedule, workOrder1));
    }

    @Test
    public void scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder_SameMonth_True() {
        Schedule schedule = new Schedule();
        WorkOrder workOrder1 = new WorkOrder();
        workOrder1.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 5, 5));
        workOrder1.workflowState = new WorkflowState();
        workOrder1.workflowState.currentStep = new WorkflowStep();
        workOrder1.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder1.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;
        WorkOrder workOrder2 = new WorkOrder();
        workOrder2.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 5, 20));
        workOrder2.workflowState = new WorkflowState();
        workOrder2.workflowState.currentStep = new WorkflowStep();
        workOrder2.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder2.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;
        WorkOrder workOrder3 = new WorkOrder();
        workOrder3.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 5, 28));
        workOrder3.workflowState = new WorkflowState();
        workOrder3.workflowState.currentStep = new WorkflowStep();
        workOrder3.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder3.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;

        List<WorkOrderSummary> workOrderSummaries = new ArrayList<>();
        workOrderSummaries.add(workOrder1.getSummary());
        workOrderSummaries.add(workOrder2.getSummary());
        workOrderSummaries.add(workOrder3.getSummary());

        doReturn(workOrderSummaries).when(workOrderService).getSortedWorkOrderSummariesBySchedule(schedule.getId());

        assertTrue(workOrderService.scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder(schedule, workOrder2));
        assertTrue(workOrderService.scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder(schedule, workOrder3));
    }

    @Test
    public void scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder_SameMonth_False() {
        Schedule schedule = new Schedule();
        WorkOrder workOrder1 = new WorkOrder();
        workOrder1.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 5, 5));
        workOrder1.workflowState = new WorkflowState();
        workOrder1.workflowState.currentStep = new WorkflowStep();
        workOrder1.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder1.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;
        WorkOrder workOrder2 = new WorkOrder();
        workOrder2.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 5, 20));
        workOrder2.workflowState = new WorkflowState();
        workOrder2.workflowState.currentStep = new WorkflowStep();
        workOrder2.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder2.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;
        WorkOrder workOrder3 = new WorkOrder();
        workOrder3.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 5, 28));
        workOrder3.workflowState = new WorkflowState();
        workOrder3.workflowState.currentStep = new WorkflowStep();
        workOrder3.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder3.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;

        List<WorkOrderSummary> workOrderSummaries = new ArrayList<>();
        workOrderSummaries.add(workOrder1.getSummary());
        workOrderSummaries.add(workOrder2.getSummary());
        workOrderSummaries.add(workOrder3.getSummary());

        doReturn(workOrderSummaries).when(workOrderService).getSortedWorkOrderSummariesBySchedule(schedule.getId());

        assertFalse(workOrderService.scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder(schedule, workOrder1));
    }

    @Test
    public void scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder_DifferentYear_True() {
        Schedule schedule = new Schedule();
        WorkOrder workOrder1 = new WorkOrder();
        workOrder1.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 12, 5));
        workOrder1.workflowState = new WorkflowState();
        workOrder1.workflowState.currentStep = new WorkflowStep();
        workOrder1.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder1.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;
        WorkOrder workOrder2 = new WorkOrder();
        workOrder2.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2021, 1, 5));
        workOrder2.workflowState = new WorkflowState();
        workOrder2.workflowState.currentStep = new WorkflowStep();
        workOrder2.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder2.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;

        List<WorkOrderSummary> workOrderSummaries = new ArrayList<>();
        workOrderSummaries.add(workOrder1.getSummary());
        workOrderSummaries.add(workOrder2.getSummary());

        doReturn(workOrderSummaries).when(workOrderService).getSortedWorkOrderSummariesBySchedule(schedule.getId());

        assertTrue(workOrderService.scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder(schedule, workOrder2));
    }

    @Test
    public void scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder_DifferentYear_False() {
        Schedule schedule = new Schedule();
        WorkOrder workOrder1 = new WorkOrder();
        workOrder1.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2020, 12, 5));
        workOrder1.workflowState = new WorkflowState();
        workOrder1.workflowState.currentStep = new WorkflowStep();
        workOrder1.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder1.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;
        WorkOrder workOrder2 = new WorkOrder();
        workOrder2.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2021, 1, 5));
        workOrder2.workflowState = new WorkflowState();
        workOrder2.workflowState.currentStep = new WorkflowStep();
        workOrder2.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder2.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;

        List<WorkOrderSummary> workOrderSummaries = new ArrayList<>();
        workOrderSummaries.add(workOrder1.getSummary());
        workOrderSummaries.add(workOrder2.getSummary());

        doReturn(workOrderSummaries).when(workOrderService).getSortedWorkOrderSummariesBySchedule(schedule.getId());

        assertFalse(workOrderService.scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder(schedule, workOrder1));
    }

    @Test
    public void scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder_ManyYrsAgo_True() {
        Schedule schedule = new Schedule();
        WorkOrder workOrder1 = new WorkOrder();
        workOrder1.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(1979, 12, 5));
        workOrder1.workflowState = new WorkflowState();
        workOrder1.workflowState.currentStep = new WorkflowStep();
        workOrder1.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder1.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;
        WorkOrder workOrder2 = new WorkOrder();
        workOrder2.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2021, 1, 5));
        workOrder2.workflowState = new WorkflowState();
        workOrder2.workflowState.currentStep = new WorkflowStep();
        workOrder2.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder2.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;

        List<WorkOrderSummary> workOrderSummaries = new ArrayList<>();
        workOrderSummaries.add(workOrder1.getSummary());
        workOrderSummaries.add(workOrder2.getSummary());

        doReturn(workOrderSummaries).when(workOrderService).getSortedWorkOrderSummariesBySchedule(schedule.getId());

        assertTrue(workOrderService.scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder(schedule, workOrder2));
    }

    @Test
    public void scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder_ManyYrsAgo_False() {
        Schedule schedule = new Schedule();
        WorkOrder workOrder1 = new WorkOrder();
        workOrder1.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(1979, 12, 5));
        workOrder1.workflowState = new WorkflowState();
        workOrder1.workflowState.currentStep = new WorkflowStep();
        workOrder1.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder1.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;
        WorkOrder workOrder2 = new WorkOrder();
        workOrder2.estimatedStartDate = DateUtil.dateFromLocalDate(LocalDate.of(2021, 1, 5));
        workOrder2.workflowState = new WorkflowState();
        workOrder2.workflowState.currentStep = new WorkflowStep();
        workOrder2.workflowState.currentStep.workflowStepDefinition = new WorkflowStepDefinition();
        workOrder2.workflowState.currentStep.workflowStepDefinition.position = EWorkflowStepName.SCHEDULED.position;

        List<WorkOrderSummary> workOrderSummaries = new ArrayList<>();
        workOrderSummaries.add(workOrder1.getSummary());
        workOrderSummaries.add(workOrder2.getSummary());

        doReturn(workOrderSummaries).when(workOrderService).getSortedWorkOrderSummariesBySchedule(schedule.getId());

        assertFalse(workOrderService.scheduleContainsUnopenedWorkOrdersBeforeDesiredWorkOrder(schedule, workOrder1));
    }

    @Test
    public void isQualityControlSamplingRequired_True() {
        WorkOrder workOrder = new WorkOrder();
        workOrder.isQualityControlRequired = false;
        workOrder.isQualityControlSampled = false;
        Integer percent = 10;
        boolean qualityControlSamplingRequired = workOrderService.isQualityControlSamplingRequired(workOrder, percent);
        assertTrue(qualityControlSamplingRequired);
    }

    @Test
    public void isQualityControlSamplingRequired_False() {
        WorkOrder workOrder = new WorkOrder();
        workOrder.isQualityControlRequired = true;
        workOrder.isQualityControlSampled = false;
        Integer percent = 10;
        boolean qualityControlSamplingRequired = workOrderService.isQualityControlSamplingRequired(workOrder, percent);
        assertFalse(qualityControlSamplingRequired);
        workOrder.isQualityControlRequired = false;
        workOrder.isQualityControlSampled = true;
        qualityControlSamplingRequired = workOrderService.isQualityControlSamplingRequired(workOrder, percent);
        assertFalse(qualityControlSamplingRequired);
        workOrder.isQualityControlRequired = false;
        workOrder.isQualityControlSampled = false;
        percent = null;
        qualityControlSamplingRequired = workOrderService.isQualityControlSamplingRequired(workOrder, percent);
        assertFalse(qualityControlSamplingRequired);
    }

    @Test
    public void isQualityAssuranceSamplingRequired_True() {
        WorkOrder workOrder = new WorkOrder();
        workOrder.isQualityAssuranceRequired = false;
        workOrder.isQualityAssuranceSampled = false;
        Integer percent = 10;
        boolean qualityAssuranceSamplingRequired = workOrderService.isQualityAssuranceSamplingRequired(workOrder, percent);
        assertTrue(qualityAssuranceSamplingRequired);
    }

    @Test
    public void isQualityAssuranceSamplingRequired_False() {
        WorkOrder workOrder = new WorkOrder();
        workOrder.isQualityAssuranceRequired = true;
        workOrder.isQualityAssuranceSampled = false;
        Integer percent = 10;
        boolean qualityAssuranceSamplingRequired = workOrderService.isQualityAssuranceSamplingRequired(workOrder, percent);
        assertFalse(qualityAssuranceSamplingRequired);
        workOrder.isQualityAssuranceRequired = false;
        workOrder.isQualityAssuranceSampled = true;
        qualityAssuranceSamplingRequired = workOrderService.isQualityAssuranceSamplingRequired(workOrder, percent);
        assertFalse(qualityAssuranceSamplingRequired);
        workOrder.isQualityAssuranceRequired = false;
        workOrder.isQualityAssuranceSampled = false;
        percent = null;
        qualityAssuranceSamplingRequired = workOrderService.isQualityAssuranceSamplingRequired(workOrder, percent);
        assertFalse(qualityAssuranceSamplingRequired);
    }

    @Test
    public void maximoUpdateCompletionDate_test1() throws ParseException {
        // Ensures that WO completionDate will NOT get updated for scenarios other than MAX_CAN, MAX_COMP, MAX_CLOSE
        Date cannedCompDate = EDateTimeFormat.FRIENDLY.parse("2021-01-01 12:30:00");
        String cannedCompTime = "12:30";
        Date otherCannedCompDate = EDateTimeFormat.FRIENDLY.parse("2020-06-01 00:00:00");

        // MAX_INSERT, with completionDate and completionTime passed in, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_INSERT, cannedCompDate, cannedCompTime, null));
        // MAX_INSERT, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_INSERT, cannedCompDate, null, null));
        // MAX_INSERT, with completionDate and completionTime passed in, and existing WO completionDate is populated with DIFFERENT value
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_INSERT, cannedCompDate, cannedCompTime, otherCannedCompDate));
        // MAX_INSERT, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is populated with DIFFERENT value
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_INSERT, cannedCompDate, null, otherCannedCompDate));
        // MAX_INSERT, with completionDate and completionTime passed in, and existing WO completionDate is identical
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_INSERT, cannedCompDate, cannedCompTime, cannedCompDate));
        // MAX_INSERT, with null completionDate and null completionTime passed in, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_INSERT, null, null, cannedCompDate));
        // MAX_INSERT, with null completionDate and null completionTime passed in, and existing WO completionDate is populated
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_INSERT, null, null, cannedCompDate));

        // MAX_UPDATE, with completionDate and completionTime passed in, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_UPDATE, cannedCompDate, cannedCompTime, null));
        // MAX_UPDATE, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_UPDATE, cannedCompDate, null, null));
        // MAX_UPDATE, with completionDate and completionTime passed in, and existing WO completionDate is populated with DIFFERENT value
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_UPDATE, cannedCompDate, cannedCompTime, otherCannedCompDate));
        // MAX_UPDATE, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is populated with DIFFERENT value
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_UPDATE, cannedCompDate, null, otherCannedCompDate));
        // MAX_UPDATE, with completionDate and completionTime passed in, and existing WO completionDate is identical
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_UPDATE, cannedCompDate, cannedCompTime, cannedCompDate));
        // MAX_UPDATE, with null completionDate and null completionTime passed in, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_UPDATE, null, null, cannedCompDate));
        // MAX_UPDATE, with null completionDate and null completionTime passed in, and existing WO completionDate is populated
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_UPDATE, null, null, cannedCompDate));

        // MAX_APPR, with completionDate and completionTime passed in, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_APPR, cannedCompDate, cannedCompTime, null));
        // MAX_APPR, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_APPR, cannedCompDate, null, null));
        // MAX_APPR, with completionDate and completionTime passed in, and existing WO completionDate is populated with DIFFERENT value
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_APPR, cannedCompDate, cannedCompTime, otherCannedCompDate));
        // MAX_APPR, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is populated with DIFFERENT value
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_APPR, cannedCompDate, null, otherCannedCompDate));
        // MAX_APPR, with completionDate and completionTime passed in, and existing WO completionDate is identical
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_APPR, cannedCompDate, cannedCompTime, cannedCompDate));
        // MAX_APPR, with null completionDate and null completionTime passed in, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_APPR, null, null, cannedCompDate));
        // MAX_APPR, with null completionDate and null completionTime passed in, and existing WO completionDate is populated
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_APPR, null, null, cannedCompDate));

        // MAX_WSCH, with completionDate and completionTime passed in, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_WSCH, cannedCompDate, cannedCompTime, null));
        // MAX_WSCH, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_WSCH, cannedCompDate, null, null));
        // MAX_WSCH, with completionDate and completionTime passed in, and existing WO completionDate is populated with DIFFERENT value
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_WSCH, cannedCompDate, cannedCompTime, otherCannedCompDate));
        // MAX_WSCH, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is populated with DIFFERENT value
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_WSCH, cannedCompDate, null, otherCannedCompDate));
        // MAX_WSCH, with completionDate and completionTime passed in, and existing WO completionDate is identical
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_WSCH, cannedCompDate, cannedCompTime, cannedCompDate));
        // MAX_WSCH, with null completionDate and null completionTime passed in, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_WSCH, null, null, cannedCompDate));
        // MAX_WSCH, with null completionDate and null completionTime passed in, and existing WO completionDate is populated
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_WSCH, null, null, cannedCompDate));
    }

    @Test
    public void maximoUpdateCompletionDate_test2() throws ParseException {
        // Ensures that WO completionDate will get updated appropriately for MAX_CAN, MAX_COMP, MAX_CLOSE scenarios
        Date cannedCompDate = EDateTimeFormat.FRIENDLY.parse("2021-01-01 12:30:00");
        String cannedCompTime = "12:30";
        Date otherCannedCompDate = EDateTimeFormat.FRIENDLY.parse("2020-06-01 00:00:00");

        // MAX_CAN, with completionDate and completionTime passed in, and existing WO completionDate is null
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CAN, cannedCompDate, cannedCompTime, null));
        // MAX_CAN, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is null
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CAN, cannedCompDate, null, null));
        // MAX_CAN, with completionDate and completionTime passed in, and existing WO completionDate is populated with DIFFERENT value
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CAN, cannedCompDate, cannedCompTime, otherCannedCompDate));
        // MAX_CAN, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is populated with DIFFERENT value
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CAN, cannedCompDate, null, otherCannedCompDate));

        // MAX_CAN, with completionDate and completionTime passed in, and existing WO completionDate is identical
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CAN, cannedCompDate, cannedCompTime, cannedCompDate));
        // MAX_CAN, with null completionDate and null completionTime passed in, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CAN, null, null, cannedCompDate));
        // MAX_CAN, with null completionDate and null completionTime passed in, and existing WO completionDate is populated
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CAN, null, null, cannedCompDate));

        // MAX_COMP, with completionDate and completionTime passed in, and existing WO completionDate is null
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_COMP, cannedCompDate, cannedCompTime, null));
        // MAX_COMP, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is null
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_COMP, cannedCompDate, null, null));
        // MAX_COMP, with completionDate and completionTime passed in, and existing WO completionDate is populated with DIFFERENT value
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_COMP, cannedCompDate, cannedCompTime, otherCannedCompDate));
        // MAX_COMP, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is populated with DIFFERENT value
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_COMP, cannedCompDate, null, otherCannedCompDate));

        // MAX_COMP, with completionDate and completionTime passed in, and existing WO completionDate is identical
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_COMP, cannedCompDate, cannedCompTime, cannedCompDate));
        // MAX_COMP, with null completionDate and null completionTime passed in, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_COMP, null, null, cannedCompDate));
        // MAX_COMP, with null completionDate and null completionTime passed in, and existing WO completionDate is populated
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_COMP, null, null, cannedCompDate));

        // MAX_CLOSE, with completionDate and completionTime passed in, and existing WO completionDate is null
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CLOSE, cannedCompDate, cannedCompTime, null));
        // MAX_CLOSE, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is null
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CLOSE, cannedCompDate, null, null));
        // MAX_CLOSE, with completionDate and completionTime passed in, and existing WO completionDate is populated with DIFFERENT value
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CLOSE, cannedCompDate, cannedCompTime, otherCannedCompDate));
        // MAX_CLOSE, with completionDate passed in, but NOT completionDTime, and existing WO completionDate is populated with DIFFERENT value
        assertTrue(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CLOSE, cannedCompDate, null, otherCannedCompDate));

        // MAX_CLOSE, with completionDate and completionTime passed in, and existing WO completionDate is identical
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CLOSE, cannedCompDate, cannedCompTime, cannedCompDate));
        // MAX_CLOSE, with null completionDate and null completionTime passed in, and existing WO completionDate is null
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CLOSE, null, null, cannedCompDate));
        // MAX_CLOSE, with null completionDate and null completionTime passed in, and existing WO completionDate is populated
        assertFalse(completionDateUpdatedFromMaximo(CmmsConstants.MAX_CLOSE, null, null, cannedCompDate));
    }

    private boolean completionDateUpdatedFromMaximo(String maximoWorkReqStat,
                                                    Date maximoCompletionDate,
                                                    String maximoCompletionTime,
                                                    Date existingWoCompletionDate) {
        // helper method
        doCallRealMethod().when(workOrderService).
                completionDateUpdatedFromCmms(any(MaximoWorkRequest.class), any(WorkOrder.class));

        doCallRealMethod().when(workOrderService).getCmmsCompletionDate(any(MaximoWorkRequest.class));

        WorkOrder workOrder = new WorkOrder();
        workOrder.completionDate = existingWoCompletionDate;

        MaximoWorkRequest maximoWorkRequest = new MaximoWorkRequest();
        maximoWorkRequest.workReqStat = maximoWorkReqStat;
        maximoWorkRequest.completionDate = maximoCompletionDate;
        maximoWorkRequest.completionTime = maximoCompletionTime;

        return workOrderService.completionDateUpdatedFromCmms(maximoWorkRequest, workOrder);
    }

    @Test
    public void getMaximoCompletionDate_test1() throws ParseException {
        // Granular test of getMaximoCompletionDate() method for scenarios OTHER THAN MAX_CAN, MAX_COMP and MAX_CLOSE
        // Should always return null
        Date cannedCompDate = EDateTimeFormat.FRIENDLY.parse("2021-01-01 12:30:00");
        String cannedCompTime = "12:30";

        Date MAX_INSERT_withDateAndTime = getMaximoCompletionDate(CmmsConstants.MAX_INSERT, cannedCompDate, cannedCompTime);
        assertNull(MAX_INSERT_withDateAndTime);

        Date MAX_INSERT_withDateButNotTime = getMaximoCompletionDate(CmmsConstants.MAX_INSERT, cannedCompDate, null);
        assertNull(MAX_INSERT_withDateButNotTime);

        Date MAX_INSERT_withoutDateOrTime = getMaximoCompletionDate(CmmsConstants.MAX_INSERT, null, null);
        assertNull(MAX_INSERT_withoutDateOrTime);

        Date MAX_UPDATE_withDateAndTime = getMaximoCompletionDate(CmmsConstants.MAX_UPDATE, cannedCompDate, cannedCompTime);
        assertNull(MAX_UPDATE_withDateAndTime);

        Date MAX_UPDATE_withDateButNotTime = getMaximoCompletionDate(CmmsConstants.MAX_UPDATE, cannedCompDate, null);
        assertNull(MAX_UPDATE_withDateButNotTime);

        Date MAX_UPDATE_withoutDateOrTime = getMaximoCompletionDate(CmmsConstants.MAX_UPDATE, null, null);
        assertNull(MAX_UPDATE_withoutDateOrTime);

        Date MAX_APPR_withDateAndTime = getMaximoCompletionDate(CmmsConstants.MAX_APPR, cannedCompDate, cannedCompTime);
        assertNull(MAX_APPR_withDateAndTime);

        Date MAX_APPR_withDateButNoTime = getMaximoCompletionDate(CmmsConstants.MAX_APPR, cannedCompDate, null);
        assertNull(MAX_APPR_withDateButNoTime);

        Date MAX_APPR_withoutDateOrTime = getMaximoCompletionDate(CmmsConstants.MAX_APPR, null, null);
        assertNull(MAX_APPR_withoutDateOrTime);

        Date MAX_WSCH_withDateAndTime = getMaximoCompletionDate(CmmsConstants.MAX_WSCH, cannedCompDate, cannedCompTime);
        assertNull(MAX_WSCH_withDateAndTime);

        Date MAX_WSCH_withDateButNoTime = getMaximoCompletionDate(CmmsConstants.MAX_WSCH, cannedCompDate, null);
        assertNull(MAX_WSCH_withDateButNoTime);

        Date MAX_WSCH_withoutDateOrTime = getMaximoCompletionDate(CmmsConstants.MAX_WSCH, null, null);
        assertNull(MAX_WSCH_withoutDateOrTime);
    }

    @Test
    public void getMaximoCompletionDate_test2() throws ParseException {
        // Granular test of getMaximoCompletionDate() method for MAX_CAN, MAX_COMP and MAX_CLOSE
        Date cannedCompDate = EDateTimeFormat.FRIENDLY.parse("2021-01-01 12:30:00");
        String cannedCompTime = "12:30";
        Date cannedCompDateTrunc = EDateTimeFormat.FRIENDLY.parse("2021-01-01 00:00:00");

        Date MAX_CAN_withDateAndTime = getMaximoCompletionDate(CmmsConstants.MAX_CAN, cannedCompDate, cannedCompTime);
        assertEquals(cannedCompDate, MAX_CAN_withDateAndTime);

        Date MAX_CAN_withDateButNotTime = getMaximoCompletionDate(CmmsConstants.MAX_CAN, cannedCompDate, null);
        assertEquals(cannedCompDateTrunc, MAX_CAN_withDateButNotTime);

        Date MAX_CAN_withoutDateOrTime = getMaximoCompletionDate(CmmsConstants.MAX_CAN, null, null);
        assertNull(MAX_CAN_withoutDateOrTime);

        Date MAX_COMP_withDateAndTime = getMaximoCompletionDate(CmmsConstants.MAX_COMP, cannedCompDate, cannedCompTime);
        assertEquals(cannedCompDate, MAX_COMP_withDateAndTime);

        Date MAX_COMP_withDateButNotTime = getMaximoCompletionDate(CmmsConstants.MAX_COMP, cannedCompDate, null);
        assertEquals(cannedCompDateTrunc, MAX_COMP_withDateButNotTime);

        Date MAX_COMP_withoutDateOrTime = getMaximoCompletionDate(CmmsConstants.MAX_COMP, null, null);
        assertNull(MAX_COMP_withoutDateOrTime);

        Date MAX_CLOSE_withDateAndTime = getMaximoCompletionDate(CmmsConstants.MAX_CLOSE, cannedCompDate, cannedCompTime);
        assertEquals(cannedCompDate, MAX_CLOSE_withDateAndTime);

        Date MAX_CLOSE_withDateButNoTime = getMaximoCompletionDate(CmmsConstants.MAX_CLOSE, cannedCompDate, null);
        assertEquals(cannedCompDateTrunc, MAX_CLOSE_withDateButNoTime);

        Date MAX_CLOSE_withoutDateOrTime = getMaximoCompletionDate(CmmsConstants.MAX_CLOSE, null, null);
        assertNull(MAX_CLOSE_withoutDateOrTime);
    }

    private Date getMaximoCompletionDate(String maximoWorkReqStat, Date maximoCompletionDate, String maximoCompletionTime) {
        // helper method
        doCallRealMethod().when(workOrderService).getCmmsCompletionDate(any(MaximoWorkRequest.class));

        MaximoWorkRequest maximoWorkRequest = new MaximoWorkRequest();
        maximoWorkRequest.workReqStat = maximoWorkReqStat;
        maximoWorkRequest.completionDate = maximoCompletionDate;
        maximoWorkRequest.completionTime = maximoCompletionTime;

        return workOrderService.getCmmsCompletionDate(maximoWorkRequest);
    }

}