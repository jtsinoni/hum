
package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.ITechnicianMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.Note;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.maintenance.technician.EEmployeeType;
import logicole.common.datamodels.maintenance.technician.JobClassRef;
import logicole.common.datamodels.maintenance.technician.Technician;
import logicole.common.datamodels.maintenance.technician.TechnicianCreationWrapper;
import logicole.common.datamodels.maintenance.technician.TechnicianNode;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.PhoneNumber;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.UnauthorizedException;
import logicole.common.general.exception.ValidationException;
import logicole.gateway.services.user.UserService;
import org.bson.types.ObjectId;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TechnicianServiceTest {

    @Mock
    private ITechnicianMicroserviceApi microservice;
    @Mock
    private CurrentUserBT currentUserBT;
    @Mock
    private CurrentUser currentUser;
    @Mock
    private UserService userService;
    @Mock
    private TechnicianCreationWrapper technicianCreationWrapper;

    private Technician technician;
    private UserProfile technicianUserProfile;
    private List<UserProfile> technicianUserProfiles;
    private OrganizationRef currentUserNodeRef;

    private static final String TECHNICIAN_PKI_DN = "CN=PETTIGREW.PETER.A.9999999999,OU=CONTRACTOR,OU=PKI,OU=DoD,O=U.S. Government,C=US";
    private static final String TECHNICIAN_FIRST_NAME = "PETER";
    private static final String TECHNICIAN_LAST_NAME = "PETTIGREW";
    private static final String TECHNICIAN_FULL_NAME = String.format("%s, %s", TECHNICIAN_LAST_NAME, TECHNICIAN_FIRST_NAME);
    private static final String TECHNICIAN_EMAIL = "technician@mail.mil";
    private static final String TECHNICIAN_PHONE_NUMBER = "999-999-9999";

    @Spy
    @InjectMocks
    private TechnicianService technicianService;

    @Before
    public void setUp() {
        setCurrentUserProfile();
        setTechnicianDetails();
        setTechnicianUserProfiles();
        setTechnicianNodes();

        whenGetCurrentUserThenReturnCurrentUser();
        whenGetCurrentNodeIdThenReturnCurrentUserNodeId();
        whenFindByIdReturnTechnician();
    }

    private void whenFindByIdReturnTechnician() {
        when(microservice.findById(technician.getId())).thenReturn(technician);
    }

    private void setCurrentUserProfile() {
        currentUser.profile = new UserProfile();
        currentUser.profile._id = new ObjectId();

        currentUserNodeRef = new OrganizationRef();
        currentUserNodeRef.id = new ObjectId().toString();
        currentUserNodeRef.ancestry = currentUserNodeRef.id;
        currentUser.profile.currentNodeRef = currentUserNodeRef;
    }

    private void setTechnicianDetails() {
        technician = new Technician();
        technician._id = new ObjectId();
        technician.fullName = TECHNICIAN_FULL_NAME;
        technician.pkiDn = TECHNICIAN_PKI_DN;
        technician.email = TECHNICIAN_EMAIL;
        technician.workPhoneNumber = TECHNICIAN_PHONE_NUMBER;
        technician.jobClassRef = new JobClassRef();
        technician.jobClassRef.id = new ObjectId().toString();
        technician.employeeType = EEmployeeType.CONTRACTOR;
        technician.rankGrade = "Contractor";
        technician.title = "Chief";
    }

    private void setTechnicianUserProfiles() {
        technicianUserProfile = new UserProfile();
        technicianUserProfile._id = new ObjectId();
        technicianUserProfile.pkiDn = TECHNICIAN_PKI_DN;
        technicianUserProfile.email = TECHNICIAN_EMAIL;
        technicianUserProfile.firstName = TECHNICIAN_FIRST_NAME;
        technicianUserProfile.lastName = TECHNICIAN_LAST_NAME;
        technicianUserProfile.currentNodeRef = currentUserNodeRef;
        PhoneNumber phoneNumber = new PhoneNumber();
        phoneNumber.value = TECHNICIAN_PHONE_NUMBER;
        technicianUserProfile.phoneNumbers = List.of(phoneNumber);

        technicianUserProfiles = List.of(technicianUserProfile);
        technician.userProfileRefs = technicianUserProfiles.stream().map(UserProfile::getRef).collect(Collectors.toList());
    }

    private void setTechnicianNodes() {
        TechnicianNode technicianNode = new TechnicianNode();
        technicianNode.arrivalDate = new Date(new Date().getTime() - 10000L); // 10 seconds ago
        technicianNode.isPrimary = true;
        technicianNode.isActive = true;
        technicianNode.nodeRef = currentUserNodeRef;
        technician.technicianNodes = List.of(technicianNode);
    }

    private void whenGetCurrentUserThenReturnCurrentUser() {
        when(currentUserBT.getCurrentUser()).thenReturn(currentUser);
    }

    private void whenGetCurrentNodeIdThenReturnCurrentUserNodeId() {
        when(currentUserBT.getCurrentNodeId()).thenReturn(currentUser.profile.currentNodeRef.id);
    }

    @Test
    public void shouldReturnTechnicianWhenUsingId() {
        Technician actual = technicianService.findById(technician.getId());
        assertSame(technician, actual);
    }

    @Test(expected = ApplicationException.class)
    public void shouldThrowExceptionWhenTechnicianNotFound() {
        when(microservice.findById(technician.getId())).thenReturn(null);
        technicianService.findById(technician.getId());
    }

    @Test(expected = UnauthorizedException.class)
    public void shouldThrowExceptionWhenNotAuthorizedToAccessTechnician() {
        when(currentUserBT.getCurrentNodeId()).thenReturn("unauthId");
        technicianService.findById(technician.getId());
    }

    @Test
    public void shouldReturnCreatedTechnicianWhenSuccessfullyCreated() {
        when(userService.getUserProfileById(any())).thenReturn(technicianUserProfile);
        when(userService.getActiveUserProfiles(any())).thenReturn(technicianUserProfiles);
        when(microservice.createTechnician(any())).thenReturn(technician);
        Technician actual = technicianService.createTechnician(technician);
        assertSame(technician, actual);
    }

    @Test(expected = ValidationException.class)
    public void shouldFailIfUserProfileIdIsNull() {
        when(userService.getUserProfileById(any())).thenReturn(null);
        technicianService.createTechnician(technician);
    }

    @Test(expected = ValidationException.class)
    public void shouldFailIfNoValidUserProfilesFound() {
        when(userService.getUserProfileById(any())).thenReturn(technicianUserProfile);
        when(userService.getActiveUserProfiles(any())).thenReturn(new ArrayList<>());
        technicianService.createTechnician(technician);
    }

    @Test(expected = ValidationException.class)
    public void shouldFailIfNoValidUserProfilesFound_ver2() {
        when(userService.getUserProfileById(any())).thenReturn(technicianUserProfile);
        when(userService.getActiveUserProfiles(any())).thenReturn(null);
        technicianService.createTechnician(technician);
    }

    @Test
    public void shouldIncludeAdditionalUserProfilesWhenGeneratingTechnicianWrapper() {
        // Add 2 new UserProfiles and generateTechnicianCreationWrapper
        UserProfile technicianUserProfile2 = new UserProfile();
        technicianUserProfile2.setId(new ObjectId().toString());

        UserProfile technicianUserProfile3 = new UserProfile();
        technicianUserProfile3.setId(new ObjectId().toString());

        List<UserProfile> allUserProfiles = Arrays.asList(technicianUserProfile, technicianUserProfile2, technicianUserProfile3);

        TechnicianCreationWrapper wrapper = technicianService.generateTechnicianWrapper(technician, allUserProfiles);
        assertEquals(technician, wrapper.technician);
        assertEquals(currentUserNodeRef.getId(), wrapper.createdByNodeRef.getId());
        assertEquals(3, wrapper.userProfiles.size());
    }

    @Test(expected = ValidationException.class)
    public void shouldThrowExceptionWhenTechnicianIsNull() {
        technicianService.createTechnician(null);
    }

    @Test(expected = ValidationException.class)
    public void shouldThrowExceptionWhenTechnicianProfilesIsEmpty() {
        technician.userProfileRefs = new ArrayList<>();
        technicianService.createTechnician(technician);
    }

    @Test(expected = ValidationException.class)
    public void shouldThrowExceptionWhenUserProfileRefsIsNull() {
        technician.userProfileRefs = null;
        technicianService.createTechnician(technician);
    }

    @Test(expected = ValidationException.class)
    public void shouldThrowExceptionWhenTechnicianNodesIsNull() {
        technician.technicianNodes = new ArrayList<>();
        technicianService.createTechnician(technician);
    }

    @Test
    public void shouldReturnEmployeeTypes() {
        List<EEmployeeType> employeeTypes = technicianService.getEmployeeTypes();
        expectEmployeeTypesToContainValue(employeeTypes, "Local National");
        expectEmployeeTypesToContainValue(employeeTypes, "Civilian");
        expectEmployeeTypesToContainValue(employeeTypes, "Military");
        expectEmployeeTypesToContainValue(employeeTypes, "Contractor");
    }

    private void expectEmployeeTypesToContainValue(List<EEmployeeType> employeeTypes, String value) {
        boolean found = employeeTypes.stream().anyMatch(employeeType -> employeeType.displayText.equals(value));
        assertTrue(found);
    }

    @Test
    public void shouldReturnJobClassRefs() {
        List<JobClassRef> expected = new ArrayList<>();
        when(microservice.getJobClassRefs()).thenReturn(expected);
        List<JobClassRef> actual = technicianService.getJobClassRefs();
        assertSame(expected, actual);
    }

    @Test
    public void shouldReturnPotentialUserProfiles() {
        List<UserProfile> userProfiles = List.of(new UserProfile());
        when(userService.getUsersAtNodeWithRole(any(), any())).thenReturn(userProfiles);
        List<UserProfile> potentialTechnicianUserProfiles = technicianService.getPotentialTechnicianUserProfiles();
        assertEquals(userProfiles.size(), potentialTechnicianUserProfiles.size());
    }

    @Test
    public void shouldReturnListOfTechniciansWhenSearchingForTechnicians() {
        SearchResult<Technician> expected = new SearchResult<>();
        SearchInput searchInput = new SearchInput();
        when(microservice.getTechnicianSearchResults(searchInput)).thenReturn(expected);
        SearchResult<Technician> actual = technicianService.getTechnicianSearchResults(searchInput);
        assertSame(actual, expected);
    }

    @Test
    public void shouldReturnTechnicianWithNewNote() {
        Note note = new Note();
        note.noteId = "note1";
        note.noteText = "Note Text Updated";
        technician.notes.add(note);
        when(microservice.addNote(any(), any())).thenReturn(technician);
        Technician actual = technicianService.addNote(technician.getId(), note);
        assertSame(technician, actual);
    }

    @Test
    public void shouldReturnTechnicianWithUpdatedNote() {
        Note note = new Note();
        note.noteId = "note1";
        note.noteText = "Note Text Updated";
        technician.notes.add(note);
        when(microservice.saveNote(any(), any())).thenReturn(technician);
        Technician actual = technicianService.saveNote(technician.getId(), note);
        assertSame(technician, actual);
    }

    @Test
    public void shouldReturnTechnicianWithRemovedNote() {
        Note note = new Note();
        note.noteId = "note1";
        note.noteText = "Note Text Updated";
        when(microservice.removeNote(any(), any())).thenReturn(technician);
        Technician actual = technicianService.removeNote(technician.getId(), note);
        assertSame(technician, actual);
    }

    @Test
    public void shouldReturnTechnicianAfterUpdate() {
        when(microservice.updateTechnician(any(Technician.class))).thenAnswer(AdditionalAnswers.returnsFirstArg());
        Technician actual = technicianService.updateTechnician(technician);
        assertSame(technician, actual);
    }
}
