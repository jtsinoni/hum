package logicole.gateway.services.ehr;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import logicole.common.datamodels.ehr.equipment.EquipmentCatalogItem;
import logicole.common.datamodels.ehr.equipment.EquipmentItemSiteInfo;

import logicole.common.general.exception.ObjectNotFoundException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;


import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class EquipmentCatalogItemAccumulatorTest {

    @Mock
    private EquipmentItemSiteInfo info;

    @Spy
    @InjectMocks
    private EquipmentCatalogItemAccumulator spy;

    @Before
    public void before() {
            setup();
        }

    private void setup() {

    }

    @Test
    public void testAddAllAndGetItems() throws ObjectNotFoundException {
        String itemId1 = "5c3653cb93f521351a7770ee";
        String itemId2 = "5c3653cb93f521351a7770ef";
        String itemId3 = "5c3653cb93f521351a7770ee";

        List<EquipmentCatalogItem> items= new ArrayList<EquipmentCatalogItem>();
        EquipmentCatalogItem item1 = new EquipmentCatalogItem();
        EquipmentCatalogItem item2 = new EquipmentCatalogItem();
        EquipmentCatalogItem item3 = new EquipmentCatalogItem();

        item1.itemID = itemId1;
        item1.siteInfoList = new ArrayList<EquipmentItemSiteInfo>();
        item1.siteInfoList.add(info);

        item2.itemID = itemId2;
        item2.siteInfoList = new ArrayList<EquipmentItemSiteInfo>();
        item2.siteInfoList.add(info);

        item3.itemID = itemId3;
        item3.siteInfoList = new ArrayList<EquipmentItemSiteInfo>();
        item3.siteInfoList.add(info);

        items.add(item1);
        items.add(item2);
        items.add(item3);

        //Run the Method
        spy.accumulate(items);

        //verify the items were added and returned
        Collection<EquipmentCatalogItem> itemsReturned = spy.getItems();

        assertTrue(itemsReturned.contains(item1));
        assertTrue(itemsReturned.contains(item2));
        assertFalse(itemsReturned.contains(item3));
        assertTrue(item1.siteInfoList.size() == 1);
        assertTrue(item2.siteInfoList.size() == 1);
        assertTrue(item3.siteInfoList.size() == 1);

        return;
    }
}

