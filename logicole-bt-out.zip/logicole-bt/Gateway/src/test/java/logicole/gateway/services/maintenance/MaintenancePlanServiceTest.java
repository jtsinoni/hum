package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.IMaintenancePlanMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.abi.item.ItemRef;
import logicole.common.datamodels.asset.classification.Nomenclature;
import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.EAssetType;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.maintenance.plan.EMaintenanceIntervalType;
import logicole.common.datamodels.maintenance.plan.EMaintenanceResponsibility;
import logicole.common.datamodels.maintenance.plan.MaintenanceInterval;
import logicole.common.datamodels.maintenance.plan.MaintenancePlan;
import logicole.common.datamodels.maintenance.plan.MaintenancePlanUpdateWrapper;
import logicole.common.datamodels.maintenance.procedure.MedicalEquipmentMaintenanceProcedureSummary;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationTypeRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.asset.AssetClassificationService;
import logicole.gateway.services.asset.AssetService;
import org.bson.types.ObjectId;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MaintenancePlanServiceTest {

    @Mock
    private AssetClassificationService assetClassificationService;
    @Mock
    private IMaintenancePlanMicroserviceApi microservice;
    @Mock
    private CurrentUserBT currentUserBT;
    @Mock
    private CurrentUser currentUser;
    @Mock
    private UserProfile userProfile;
    @Mock
    private AssetService assetService;
    @Mock
    private ItemService itemService;
    @Mock
    private MaintenanceProcedureService maintenanceProcedureService;

    @Spy
    @InjectMocks
    private MaintenancePlanService maintenancePlanService;

    private MaintenancePlan maintenancePlan;
    private List<Nomenclature> nomenclatures;
    private List<Asset> assets;
    private List<MaintenancePlan> maintenancePlans;
    private OrganizationRef currentNodeRef;

    @Before
    public void setup() {
        maintenancePlan = new MaintenancePlan();
        maintenancePlan._id = new ObjectId();
        maintenancePlan.managedByNodeRef = new OrganizationRef();
        nomenclatures = new ArrayList<>();
        assets = new ArrayList<>();
        maintenancePlans = new ArrayList<>();
        whenGetCurrentUserThenReturnCurrentUser();
        whenGetCurrentNodeIdThenReturnCurrentUserNodeId();
        when(microservice.createMaintenancePlan(maintenancePlan)).thenAnswer(AdditionalAnswers.returnsFirstArg());
        maintenancePlan.managedByNodeRef.id = currentNodeRef.id;
        maintenancePlan.managedByNodeRef.ancestry = currentNodeRef.ancestry;
    }

    private void whenGetCurrentUserThenReturnCurrentUser() {
        currentNodeRef = new OrganizationRef();
        currentNodeRef.id = "testId";
        currentNodeRef.ancestry = currentNodeRef.id;
        userProfile.currentNodeRef = currentNodeRef;
        userProfile.nodeTypeRef = new OrganizationTypeRef();
        userProfile.nodeTypeRef.level = 100;
        userProfile.pkiDn = "testpkidn";
        currentUser.profile = userProfile;
        when(currentUserBT.getCurrentUser()).thenReturn(currentUser);
    }

    private void whenGetCurrentNodeIdThenReturnCurrentUserNodeId() {
        when(currentUserBT.getCurrentNodeId()).thenReturn(currentUser.profile.currentNodeRef.id);
    }

    @Test
    public void shouldReturnMaintenancePlanWhenCreateMaintenancePlan() {
        MaintenancePlan actual = maintenancePlanService.createMaintenancePlan(maintenancePlan);
        assertSame(maintenancePlan, actual);
    }

    @Test
    public void shouldAssociatePlanToProcedureWhenCreating_ifApplicable() {
        String maintenancePlanId = "61dc79ba6ee832a62f9d8fc5";
        maintenancePlan.setId(maintenancePlanId);

        String localProcedureSummaryId = "61dc79c14250fa5a021320ef";
        maintenancePlan.localProcedureSummary = new MedicalEquipmentMaintenanceProcedureSummary();
        maintenancePlan.localProcedureSummary.id = localProcedureSummaryId;

        when(currentUserBT.getCurrentUser()).thenReturn(currentUser);
        when(maintenanceProcedureService.associateMaintenancePlan(localProcedureSummaryId, maintenancePlan.getRef())).thenReturn(null);

        MaintenancePlan actual = maintenancePlanService.createMaintenancePlan(maintenancePlan);

        assertSame(maintenancePlan, actual);
        verify(maintenanceProcedureService,
                times(1)).associateMaintenancePlan(localProcedureSummaryId, maintenancePlan.getRef());
    }

    @Test
    public void shouldNotAssociatePlanToProcedureWhenCreating_ifApplicable() {
        String maintenancePlanId = "61dc79ba6ee832a62f9d8fc5";
        maintenancePlan.setId(maintenancePlanId);
        maintenancePlan.localProcedureSummary = null;

        String localProcedureSummaryId = "61dc79c14250fa5a021320ef";  // but will NOT get associated

        when(currentUserBT.getCurrentUser()).thenReturn(currentUser);

        MaintenancePlan actual = maintenancePlanService.createMaintenancePlan(maintenancePlan);

        assertSame(maintenancePlan, actual);
        verify(maintenanceProcedureService,
                times(0)).associateMaintenancePlan(localProcedureSummaryId, maintenancePlan.getRef());
    }

    @Test
    public void shouldSetManagedByWhenCreateMaintenancePlan() {
        MaintenancePlan actual = maintenancePlanService.createMaintenancePlan(maintenancePlan);
        assertSame(currentNodeRef, actual.managedByNodeRef);
    }

    @Test
    public void shouldPopulateItemRefIfNeededWhenCreateMaintenancePlan() {
        Asset asset = new Asset();
        asset._id = new ObjectId();
        ItemRef item = new ItemRef();
        item.id = (new ObjectId()).toString();
        asset.itemRef = item;

        maintenancePlan.assetRef = new AssetRef();
        maintenancePlan.assetRef.id = asset.getId();
        when(assetService.getAssetById(asset.getId())).thenReturn(asset);

        MaintenancePlan actual = maintenancePlanService.createMaintenancePlan(maintenancePlan);
        assertEquals(item.getId(), actual.itemRef.id);
    }

    @Test
    public void whenUpdatingDetails_shouldReturnMaintenancePlan() {
        MaintenancePlanUpdateWrapper updateWrapper = new MaintenancePlanUpdateWrapper();
        updateWrapper.maintenancePlan = this.maintenancePlan;
        when(microservice.updateMaintenancePlanDetail(maintenancePlan)).thenReturn(updateWrapper);

        whenFindByIdReturnMaintenancePlan(maintenancePlan.getId());
        MaintenancePlan updatedMaintenancePlan = maintenancePlanService.updateMaintenancePlanDetail(this.maintenancePlan);

        assertSame(maintenancePlan, updatedMaintenancePlan);
    }

    @Test
    public void whenUpdatingDetails_shouldAssociateAndUnassociatePlanToProcedureIfAppropriate() {
        String localProcedureId = "61dc7f1a7ae054247624936c";
        maintenancePlan.localProcedureSummary = new MedicalEquipmentMaintenanceProcedureSummary();
        maintenancePlan.localProcedureSummary.id = localProcedureId;

        String oldLocalProcedureId = "61dc8024d1aa98375499c846";
        MedicalEquipmentMaintenanceProcedureSummary oldProcedureSummary = new MedicalEquipmentMaintenanceProcedureSummary();
        oldProcedureSummary.id = oldLocalProcedureId;

        MaintenancePlanUpdateWrapper updateWrapper = new MaintenancePlanUpdateWrapper();
        updateWrapper.maintenancePlan = this.maintenancePlan;
        updateWrapper.isLocalProcedureChanged = true;
        updateWrapper.oldLocalProcedure = oldProcedureSummary;

        when(microservice.updateMaintenancePlanDetail(maintenancePlan)).thenReturn(updateWrapper);
        whenFindByIdReturnMaintenancePlan(maintenancePlan.getId());
        MaintenancePlan actualUpdatedMaintenancePlan = maintenancePlanService.updateMaintenancePlanDetail(this.maintenancePlan);

        assertSame(maintenancePlan, actualUpdatedMaintenancePlan);
        verify(maintenanceProcedureService,
                times(1)).associateMaintenancePlan(localProcedureId, maintenancePlan.getRef());
        verify(maintenanceProcedureService,
                times(1)).unassociateMaintenancePlan(oldLocalProcedureId, maintenancePlan.getRef());
    }

    @Test
    public void whenUpdatingDetails_should_NOT_AssociateAndUnassociatePlanToProcedure_ifAppropriate() {
        String localProcedureId = "61dc7f1a7ae054247624936c";
        maintenancePlan.localProcedureSummary = new MedicalEquipmentMaintenanceProcedureSummary();
        maintenancePlan.localProcedureSummary.id = localProcedureId;

        String oldLocalProcedureId = "61dc8024d1aa98375499c846";
        MedicalEquipmentMaintenanceProcedureSummary oldProcedureSummary = new MedicalEquipmentMaintenanceProcedureSummary();
        oldProcedureSummary.id = oldLocalProcedureId;

        MaintenancePlanUpdateWrapper updateWrapper = new MaintenancePlanUpdateWrapper();
        updateWrapper.maintenancePlan = this.maintenancePlan;
        updateWrapper.isLocalProcedureChanged = false;    // KEY POINT HERE...SETTING TO FALSE
        updateWrapper.oldLocalProcedure = oldProcedureSummary;

        when(microservice.updateMaintenancePlanDetail(maintenancePlan)).thenReturn(updateWrapper);
        whenFindByIdReturnMaintenancePlan(maintenancePlan.getId());

        MaintenancePlan actualUpdatedMaintenancePlan = maintenancePlanService.updateMaintenancePlanDetail(maintenancePlan);

        assertSame(maintenancePlan, actualUpdatedMaintenancePlan);
        verify(maintenanceProcedureService,
                times(0)).associateMaintenancePlan(localProcedureId, maintenancePlan.getRef());
        verify(maintenanceProcedureService,
                times(0)).unassociateMaintenancePlan(oldLocalProcedureId, maintenancePlan.getRef());
    }

    @Test
    public void shouldReturnClonedMaintenancePlan() {
        when(microservice.cloneMaintenancePlan(maintenancePlan.getId(), 100)).thenReturn(maintenancePlan);
        MaintenancePlan clonedMaintenancePlan = maintenancePlanService.cloneMaintenancePlan(maintenancePlan.getId());
        assertSame(maintenancePlan, clonedMaintenancePlan);
    }

    @Test
    public void shouldReturnMedicalEquipmentNomenclatures() {
        SearchInput searchInput = new SearchInput();
        whenGetNomenclaturesByMedicalEquipmentThenReturnNomenclatures(searchInput);
        SearchResult<Nomenclature> actual = maintenancePlanService.getNomenclatures(searchInput);
        assertSame(nomenclatures, actual.results);
    }

    private void whenGetNomenclaturesByMedicalEquipmentThenReturnNomenclatures(SearchInput searchInput) {
        SearchResult<Nomenclature> searchResult = new SearchResult<>();
        searchResult.results = nomenclatures;
        when(assetClassificationService.getMedicalEquipmentNomenclatures(searchInput)).thenReturn(searchResult);
    }

    @Test
    public void shouldReturnMedicalEquipmentAssets() {
        SearchInput searchInput = new SearchInput();
        whenGetAssetsByMedicalEquipmentThenReturnAssets(searchInput);
        SearchResult<Asset> actual = maintenancePlanService.getMedicalEquipmentAssets(searchInput);
        assertSame(assets, actual.results);
    }

    private void whenGetAssetsByMedicalEquipmentThenReturnAssets(SearchInput searchInput) {
        SearchResult<Asset> searchResult = new SearchResult<>();
        searchResult.results = assets;
        when(assetService.getMedicalEquipmentAssets(searchInput)).thenReturn(searchResult);
    }

    @Test
    public void shouldReturnAssetRefsByNomenclatureIdAndDeviceCode() {
        String nomenclatureId = "nomenclatureId";
        List<AssetRef> expected = new ArrayList<>();
        when(assetService.getMedicalAssetRefsByNomenclatureId(nomenclatureId)).thenReturn(expected);
        List<AssetRef> actual = maintenancePlanService.getMedicalAssetRefsByNomenclatureId(nomenclatureId);
        assertSame(expected, actual);
    }

    @Test
    public void shouldReturnMaintenancePlanSearchResults() {
        SearchInput searchInput = new SearchInput();
        SearchResult<MaintenancePlan> expected = new SearchResult<>();
        when(microservice.getMaintenancePlanSearchResults(searchInput, currentNodeRef.ancestry, 100)).thenReturn(expected);
        SearchResult<MaintenancePlan> actual = maintenancePlanService.getMaintenancePlanSearchResults(searchInput);
        assertSame(expected, actual);
    }

    @Test
    public void shouldReturnMaintenanceResponsibilities() {
        List<EMaintenanceResponsibility> responsibilities = maintenancePlanService.getMaintenanceResponsibilities();
        assertResponsibilityIsInList("Calibration Lab", responsibilities);
        assertResponsibilityIsInList("Contract", responsibilities);
        assertResponsibilityIsInList("Depot", responsibilities);
        assertResponsibilityIsInList("General Support", responsibilities);
        assertResponsibilityIsInList("Intermediate DS", responsibilities);
        assertResponsibilityIsInList("Operator", responsibilities);
        assertResponsibilityIsInList("Organizational/Unit", responsibilities);
        assertResponsibilityIsInList("Other", responsibilities);
    }

    private void assertResponsibilityIsInList(String responsibilityText, List<EMaintenanceResponsibility> responsibilities) {
        boolean found = responsibilities.stream().anyMatch((responsibility) -> responsibility.displayText.equals(responsibilityText));
        assertTrue(found);
    }

    @Test
    public void shouldReturnMaintenancePlanWhenFindingById() {
        whenFindByIdReturnMaintenancePlan(maintenancePlan.getId());
        MaintenancePlan maintenancePlanFound = maintenancePlanService.findById(maintenancePlan.getId());
        assertSame(maintenancePlan, maintenancePlanFound);
    }

    public void whenFindByIdReturnMaintenancePlan(String id) {
        when(microservice.findById(id)).thenReturn(maintenancePlan);
    }

    @Test
    public void shouldReturnNomenclatureWhenUsingId() {
        Nomenclature expected = new Nomenclature();
        expected._id = new ObjectId();
        whenGetNomenclatureByIdThenReturnNomenclature(expected);
        Nomenclature actual = maintenancePlanService.getNomenclatureById(expected.getId());
        assertSame(expected, actual);
    }

    private void whenGetNomenclatureByIdThenReturnNomenclature(Nomenclature nomenclature) {
        when(assetClassificationService.getNomenclatureById(nomenclature.getId())).thenReturn(nomenclature);
    }

    @Test
    public void shouldReturnNomenclatureWhenUsingCode() {
        Nomenclature expected = new Nomenclature();
        expected._id = new ObjectId();
        expected.nomenclatureCode = "nomenclatureCode";
        whenGetNomenclatureByCodeThenReturnNomenclature(expected);
        Nomenclature actual = maintenancePlanService.getNomenclatureByCode(expected.nomenclatureCode);
        assertSame(expected, actual);
    }

    private void whenGetNomenclatureByCodeThenReturnNomenclature(Nomenclature nomenclature) {
        when(assetClassificationService.getNomenclatureByCodeTypeAndOrg(nomenclature.nomenclatureCode, EAssetType.MEDICAL_EQUIPMENT.toString(),currentNodeRef)).thenReturn(nomenclature);
    }

    @Test
    public void shouldReturnMaintenanceIntervalTypes() {
        List<EMaintenanceIntervalType> intervalTypes = maintenancePlanService.getMaintenanceIntervalTypes();
        assertMaintenanceIntervalIsInList("Inspection", intervalTypes);
        assertMaintenanceIntervalIsInList("Preventative Maintenance", intervalTypes);
        assertMaintenanceIntervalIsInList("Calibration", intervalTypes);
        assertMaintenanceIntervalIsInList("Scheduled Parts Replacement", intervalTypes);
    }

    private void assertMaintenanceIntervalIsInList(String maintenanceIntervalType, List<EMaintenanceIntervalType> maintenanceIntervalTypes) {
        boolean found = maintenanceIntervalTypes.stream().anyMatch((intervalType) -> intervalType.displayText.equals(maintenanceIntervalType));
        assertTrue(found);
    }

    @Test
    public void shouldReturnMaintenanceIntervalsForId() {
        List<MaintenanceInterval> expected = new ArrayList<>();
        when(microservice.getMaintenanceIntervals()).thenReturn(expected);
        List<MaintenanceInterval> actual = maintenancePlanService.getMaintenanceIntervals();
        assertSame(expected, actual);
    }

    @Test
    public void shouldDeleteMaintenancePlanById() {
        when(microservice.deleteById(maintenancePlan.getId())).thenReturn(maintenancePlan);
        maintenancePlanService.deleteById(maintenancePlan.getId());
        verify(microservice).deleteById(maintenancePlan.getId());
    }

    @Test
    public void shouldReturnItemRefsUsingSearchInput() {
        SearchInput searchInput = new SearchInput();
        List<ItemRef> itemRefs = new ArrayList<>();
        SearchResult<ItemRef> expected = new SearchResult<>();
        expected.results = itemRefs;
        when(itemService.getItemRefs(searchInput)).thenReturn(expected);

        SearchResult<ItemRef> actual = maintenancePlanService.getItemRefs(searchInput);
        assertSame(itemRefs, actual.results);
    }

    @Test
    public void shouldReturnItemRefForValidAssetId() {
        Asset asset = new Asset();
        asset._id = new ObjectId();
        asset.itemRef = new ItemRef();
        asset.itemRef.id = "itemId";
        when(assetService.getAssetById(anyString())).thenReturn(asset);
        ItemRef actualItemRefForAsset = maintenancePlanService.getItemRefForAsset(asset.getId());
        assertSame(asset.itemRef, actualItemRefForAsset);
    }

    @Test
    public void shouldReturnNullForInvalidAssetId() {
        when(assetService.getAssetById(anyString())).thenReturn(null);
        ItemRef actualItemRefForAsset = maintenancePlanService.getItemRefForAsset("invalidId");
        assertNull(actualItemRefForAsset);
    }

    @Test
    public void shouldReturnMaintenancePlansForMaintenanceProcedureId() {
        when(microservice.getMaintenancePlansForMaintenanceProcedure(anyString())).thenReturn(maintenancePlans);
        List<MaintenancePlan> actualMaintenancePlans = maintenancePlanService.getMaintenancePlansForMaintenanceProcedure("testId");
        assertSame(maintenancePlans, actualMaintenancePlans);
    }
}
