package logicole.gateway.services.abi;

import io.jsonwebtoken.lang.Assert;
import logicole.apis.abi.item.IItemMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.abi.item.Item;
import logicole.common.datamodels.abi.item.ItemPackaging;
import logicole.common.datamodels.abi.item.ItemRef;
import logicole.common.datamodels.abi.item.ItemSummary;
import logicole.common.datamodels.abi.PackagingDetail;
import logicole.common.datamodels.abi.Restriction;
import logicole.common.datamodels.abi.staging.ABiCatalogRecordUpdate;
import logicole.common.datamodels.abi.staging.CommodityClass;
import logicole.common.datamodels.general.search.ESearchEngine;
import logicole.common.datamodels.general.search.SearchInput;
import logicole.common.datamodels.general.search.SearchResult;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.logging.ILogger;
import logicole.common.servers.history.BusinessMethodExecutioner;
import logicole.common.servers.history.MessageFactory;
import logicole.gateway.common.EndpointAccessFilter;
import logicole.gateway.services.abi.item.ItemService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ItemServiceTest {
    @Mock
    private EnterpriseCatalogLookupService enterpriseCatalogLookupService;
    @Mock
    protected ILogger logger;
    @Mock
    protected CurrentUserBT currentUserBT;
    @Mock
    private MessageFactory logMessageFactory;
    @Mock
    protected EndpointAccessFilter endpointAccessFilter;
    @Mock
    private BusinessMethodExecutioner businessMethodExecutioner;
    @Mock
    private IItemMicroserviceApi microservice;

    @InjectMocks
    private ItemService svc;

    @Before
    public void setup() {
        CurrentUser currentUser = mock(CurrentUser.class);
        currentUser.profile = mock(UserProfile.class);
        when (currentUserBT.getCurrentUser()).thenReturn(currentUser);
    }

    @Test
    public void testGetCurrentUser() {
        CurrentUser result = svc.getCurrentUser();
        Assert.notNull(result);
    }

    @Test
    public void testSyncItemWithAbiCatalog() {
        ABiCatalogRecordUpdate aBiCatalogRecordUpdate = mock(ABiCatalogRecordUpdate.class);
        svc.syncItemWithAbiCatalog(aBiCatalogRecordUpdate);
    }

    @Test
    public void testGetItemById() {
        String id = "111222";
        Item result = svc.getItemById(id);
    }

    @Test
    public void testGetItemsByDeviceCode() {
        String deviceCode = "Spanky";
        List<Item> result = svc.getItemsByDeviceCode(deviceCode);
    }

    @Test
    public void testGetItemByEnterpriseIdOrNsn() {
        String productId = "McFardle";
        Item result = svc.getItemByEnterpriseIdOrNsn(productId);
    }

    @Test
    public void testGetByEnterpriseProductIdentifier() {
        String enterpriseProductIdentifier = "112342";
        Item result = svc.getByEnterpriseProductIdentifier(enterpriseProductIdentifier);
    }

    @Test
    public void testGetByEnterpriseProductIdOrDescription() {
        String searchText = "Spanky McFardle";
        List<Item> result = svc.getByEnterpriseProductIdOrDescription(searchText);
    }

    @Test
    public void testGetItemByBarcode() {
        String barcode = "2234222";
        ItemPackaging itemPackaging = mock(ItemPackaging.class);
        itemPackaging.itemRef = new ItemRef();
        when(microservice.getItemByBarcode(barcode)).thenReturn(itemPackaging);
        ItemPackaging result = svc.getItemByBarcode(barcode);
    }
/*  Need to handle the getOrganization in getItemSearchResults()
    @Test
    public void testGetItemSearchResults1() {
        SearchInput searchInput = mock(SearchInput.class);
        when(microservice.getItemSearchEngine()).thenReturn(ESearchEngine.MONGO);
        SearchResult<ItemSummary> result = svc.getItemSearchResults(searchInput);
     }

    @Test(expected = ApplicationException.class)
    public void testGetItemSearchResults2() {
        SearchInput searchInput = mock(SearchInput.class);
        when(microservice.getItemSearchEngine()).thenReturn(ESearchEngine.ELASTIC);
        SearchResult<ItemSummary> result = svc.getItemSearchResults(searchInput);
    }
*/
    @Test
    public void testGetCommodityClassByName() {
        String commodityClsNm = "Spanky";
        String commType = "McFardle";
        String milServiceId = "DA";
        CommodityClass result = svc.getCommodityClassByName(commodityClsNm, commType, milServiceId);
    }

    @Test
    public void testGetItemRestriction() {
        String code = "Spanky";
        String type = "McFardle";
        String description = "Spanky and Our Gang";
        Restriction result = svc.getItemRestriction(code, type, description);
    }

    @Test
    public void testUpdateItem() {
        Item item = mock(Item.class);
        item.managedByNodeRef = new OrganizationRef();
        Item result = svc.updateItem(item);
    }

    @Test
    public void testSaveItem() {
        Item item = mock(Item.class);
        item.managedByNodeRef = new OrganizationRef();
        Item result = svc.saveItem(item);
    }

    @Test
    public void testGetPackagingFromItem() {
        Item item = mock(Item.class);
        item.packaging = new ArrayList<>();
        PackagingDetail packagingDetail = mock(PackagingDetail.class);
        packagingDetail.packageQuantity = 30;
        packagingDetail.packageUnit = "EA";
        packagingDetail.packageUnitDescription = "box of 30";
        packagingDetail.nsn = new ArrayList<>();
        packagingDetail.gtin = "111222";
        packagingDetail.enterprisePackageIdentifier = "EPI1234";
        item.packaging.add(packagingDetail);
        Integer packageQuantity = 30;
        PackagingDetail result = svc.getPackagingFromItem(item, packageQuantity);
    }

    @Test
    public void testGetProvisionalEPI() {
        String manufacturerName = "Spanky McFardle, Inc.";
        String manufacturerPartNumber = "ABC-112-ZZZQ";
        String result = svc.getProvisionalEPI(manufacturerName, manufacturerPartNumber);
    }
}
