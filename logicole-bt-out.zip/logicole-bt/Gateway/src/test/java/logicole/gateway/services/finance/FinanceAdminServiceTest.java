package logicole.gateway.services.finance;

import logicole.common.datamodels.finance.AuthorizedOrg;
import logicole.common.datamodels.finance.FundingNodeChild;
import logicole.common.datamodels.finance.FundingSourceField;
import logicole.common.datamodels.finance.fundingsource.EFundingSourceFieldName;
import logicole.common.datamodels.finance.fundingsource.EFundingSourceSubType;
import logicole.common.datamodels.finance.fundingsource.FundingSource;
import logicole.common.general.exception.ApplicationException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class FinanceAdminServiceTest {


    @InjectMocks
    FinanceAdminService financeAdminService;

    @Test
    public void validateWbsCostCenterTest1() {
        String costCenter = "111";

        FundingSource fundingSource = new FundingSource();
        FundingNodeChild child = new FundingNodeChild();

        fundingSource.subType = EFundingSourceSubType.WBS;
        fundingSource.financialSystemFields.add(new FundingSourceField(EFundingSourceFieldName.RESPONSIBLE_COST_CENTER.displayText, costCenter));
        fundingSource.sloa.costCenter = costCenter;
        AuthorizedOrg aorg = new AuthorizedOrg();
        aorg.costCenter = costCenter;
        child.authorizedOrgs.add(aorg);

        financeAdminService.validateWbsCostCenter(fundingSource, child);
        //expect no exception
    }

    @Test
    public void validateWbsCostCenterTest2() {
        String costCenter = "111";
        String costCenter2 = "222";

        FundingSource fundingSource = new FundingSource();
        FundingNodeChild child = new FundingNodeChild();

        fundingSource.subType = EFundingSourceSubType.WBS;
        fundingSource.financialSystemFields.add(new FundingSourceField(EFundingSourceFieldName.RESPONSIBLE_COST_CENTER.displayText, costCenter2));
        fundingSource.sloa.costCenter = costCenter;
        AuthorizedOrg aorg = new AuthorizedOrg();
        aorg.costCenter = costCenter;
        child.authorizedOrgs.add(aorg);

        financeAdminService.validateWbsCostCenter(fundingSource, child);
        //expect no exception
    }


    @Test(expected = ApplicationException.class)
    public void validateWbsCostCenterTest3() {
        String costCenter = "111";
        String costCenter2 = "222";

        FundingSource fundingSource = new FundingSource();
        FundingNodeChild child = new FundingNodeChild();

        fundingSource.subType = EFundingSourceSubType.WBS;
        fundingSource.financialSystemFields.add(new FundingSourceField(EFundingSourceFieldName.RESPONSIBLE_COST_CENTER.displayText, costCenter2));
        fundingSource.sloa.costCenter = costCenter;
        AuthorizedOrg aorg = new AuthorizedOrg();
        aorg.costCenter = costCenter2;
        child.authorizedOrgs.add(aorg);

        financeAdminService.validateWbsCostCenter(fundingSource, child);
        //expect no exception
    }

}
