package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.IMaintenanceActivityMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.MonetaryValue;
import logicole.common.datamodels.maintenance.activity.LaborRate;
import logicole.common.datamodels.maintenance.activity.MaintenanceActivity;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationTypeRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.ApplicationException;
import logicole.common.general.exception.UnauthorizedException;
import org.bson.types.ObjectId;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MaintenanceActivityServiceTest {

    @Spy
    @InjectMocks
    private MaintenanceActivityService maintenanceActivityService;
    @Mock
    private IMaintenanceActivityMicroserviceApi microservice;
    @Mock
    private CurrentUserBT currentUserBT;
    @Mock
    private CurrentUser currentUser;
    @Mock
    private UserProfile userProfile;

    private MaintenanceActivity maintenanceActivity;
    private OrganizationRef currentNodeRef;

    @Before
    public void setup() {
        whenGetCurrentUserThenReturnCurrentUser();
        maintenanceActivity = new MaintenanceActivity();
        maintenanceActivity._id = new ObjectId();
        maintenanceActivity.isActive = true;
        maintenanceActivity.managedByNodeRef = currentNodeRef;
        maintenanceActivity.serviceName = "Service Name";
        maintenanceActivity.serviceId = "ServiceId";
        maintenanceActivity.laborRate = new LaborRate();
        maintenanceActivity.laborRate.isShop = true;
        maintenanceActivity.laborRate.shopRate = new MonetaryValue(15);
        whenFindByIdReturnMaintenanceActivity();
    }

    private void whenGetCurrentUserThenReturnCurrentUser() {
        currentNodeRef = new OrganizationRef();
        currentNodeRef.id = "testId";
        currentNodeRef.ancestry = currentNodeRef.id;
        userProfile.currentNodeRef = currentNodeRef;
        userProfile.nodeTypeRef = new OrganizationTypeRef();
        userProfile.nodeTypeRef.level = 100;
        userProfile.pkiDn = "testpkidn";
        currentUser.profile = userProfile;
        when(currentUserBT.getCurrentUser()).thenReturn(currentUser);
    }

    private void whenFindByIdReturnMaintenanceActivity() {
        when(microservice.findById(anyString())).thenReturn(maintenanceActivity);
    }

    @Test
    public void shouldReturnMaintenanceActivityWhenAllowedToAccess() {
        MaintenanceActivity actual = maintenanceActivityService.findById(maintenanceActivity.getId());
        assertSame(maintenanceActivity, actual);
    }

    @Test(expected = ApplicationException.class)
    public void shouldThrowExceptionWhenMaintenanceActivityNotFound() {
        when(microservice.findById(anyString())).thenReturn(null);
        maintenanceActivityService.findById(maintenanceActivity.getId());
    }

    @Test(expected = UnauthorizedException.class)
    public void shouldThrowExceptionWhenNotAuthorizedToAccessMaintenanceActivity() {
        currentNodeRef.ancestry = "unauthAncestry";
        maintenanceActivityService.findById(maintenanceActivity.getId());
    }

    @Test
    public void shouldReturnMaintenanceActivityAfterCreating() {
        when(microservice.createMaintenanceActivity(any(MaintenanceActivity.class))).thenAnswer(AdditionalAnswers.returnsFirstArg());
        MaintenanceActivity actual = maintenanceActivityService.createMaintenanceActivity(this.maintenanceActivity);
        assertSame(maintenanceActivity, actual);
    }

    @Test
    public void shouldReturnMaintenanceActivitiesWhenGettingRecords() {
        List<MaintenanceActivity> maintenanceActivities = new ArrayList<>();
        maintenanceActivities.add(maintenanceActivity);
        when(microservice.getMaintenanceActivities()).thenReturn(maintenanceActivities);
        List<MaintenanceActivity> actual = maintenanceActivityService.getMaintenanceActivities();
        assertEquals(1L, actual.size());
    }
}