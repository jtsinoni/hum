package logicole.gateway.services.communications;

import logicole.common.datamodels.communications.response.CommunicationResponse;
import logicole.common.datamodels.order.order.OrderDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CommunicationsSubmitRequestServiceTest {

    @Mock
    private CommunicationsSubmitRequestService communicationsSubmitRequestService;
    private CommunicationsSubmitRequestService spy;

    @Before
    public void setup() {
        spy = Mockito.spy(communicationsSubmitRequestService);
    }

    @Test
    public void submitEdiPurchaseOrderRequest() throws IOException {
        OrderDTO order = new OrderDTO();
        CommunicationResponse response = new CommunicationResponse();

        when(spy.submitPurchaseOrderRequest(order)).thenReturn(response);

        spy.submitPurchaseOrderRequest(order);

        verify(spy).submitPurchaseOrderRequest(any(OrderDTO.class));
    }
}