package logicole.gateway.services.asset;

import logicole.common.datamodels.notification.ApplicationNotification;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class NotificationAccumulatorTest {

    private NotificationAccumulator notificationAccumulator = new NotificationAccumulator();

    @Test
    public void addErrorsTest() {

        List<String> errors = new ArrayList<>();
        errors.add("a");
        errors.add("b");
        notificationAccumulator.setMaxNotifications(4);

        notificationAccumulator.addErrors(errors);
        notificationAccumulator.addErrors(errors);
        notificationAccumulator.addErrors(errors);
        notificationAccumulator.addErrors(errors);

        List<ApplicationNotification> list = notificationAccumulator.getNotifications();
        Assert.assertEquals(2, list.size());
    }
}
