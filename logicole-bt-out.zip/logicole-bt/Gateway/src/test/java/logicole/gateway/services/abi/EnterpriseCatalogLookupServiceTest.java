package logicole.gateway.services.abi;

import logicole.apis.abi.IEnterpriseCatalogLookupMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.general.logging.ILogger;
import logicole.gateway.services.user.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;


@RunWith(MockitoJUnitRunner.class)
public class EnterpriseCatalogLookupServiceTest {
    @Mock
    private ILogger logger;
    @Mock
    private CurrentUserBT currentUserBT;
    @Mock
    private UserService userService;
    @Mock
    private IEnterpriseCatalogLookupMicroserviceApi microservice;

    @InjectMocks
    private EnterpriseCatalogLookupService mgr;

    @Test
    public void testGetBusinessByName() {
        String manufacturerName = "Spanky McFardle, Inc.";
        mgr.getBusinessByName(manufacturerName);
    }
}
