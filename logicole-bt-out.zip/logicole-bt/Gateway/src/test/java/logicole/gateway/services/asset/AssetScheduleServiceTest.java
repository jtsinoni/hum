package logicole.gateway.services.asset;

import logicole.common.datamodels.asset.management.Asset;
import logicole.common.datamodels.asset.management.AssetRef;
import logicole.common.datamodels.asset.management.MaintenanceInformation;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AssetScheduleServiceTest {

    @Spy
    @InjectMocks
    private AssetScheduleService spy;

    private void runOnCreateAsset(Asset asset, int expectedAddRemoveAssetInvocations) {
        doNothing().when(spy).addRemoveAsset(asset, AssetScheduleService.EAssetScheduleUpdateOption.ADD);
        boolean exceptionThrown = false;
        try {
            spy.onCreateAsset(asset);
            verify(spy, times(expectedAddRemoveAssetInvocations)).addRemoveAsset(asset, AssetScheduleService.EAssetScheduleUpdateOption.ADD);
        } catch (Exception e) {
            exceptionThrown = true;
        }
        assertFalse(exceptionThrown);
    }

    @Test
    public void onCreateAssetTest() {
        Asset asset_with_nothing = new Asset();

        Asset asset_with_badParentRef = new Asset();
        asset_with_badParentRef.parentAssetRef = new AssetRef();

        Asset asset_with_goodParentRef_noMaintenanceInformation = new Asset();
        asset_with_goodParentRef_noMaintenanceInformation.parentAssetRef = new AssetRef();
        asset_with_goodParentRef_noMaintenanceInformation.parentAssetRef.id = "60c15bef2bb59294843b3d71";

        Asset asset_with_goodParentRef_goodMaintenanceInformation_performedFalse = new Asset();
        asset_with_goodParentRef_goodMaintenanceInformation_performedFalse.parentAssetRef = new AssetRef();
        asset_with_goodParentRef_goodMaintenanceInformation_performedFalse.parentAssetRef.id = "60c15bef2bb59294843b3d71";
        asset_with_goodParentRef_goodMaintenanceInformation_performedFalse.maintenanceInformation = new MaintenanceInformation();
        asset_with_goodParentRef_goodMaintenanceInformation_performedFalse.maintenanceInformation.isMaintenancePerformedOnParentAsset = false;

        Asset asset_with_goodParentRef_goodMaintenanceInformation_performedTrue = new Asset();
        asset_with_goodParentRef_goodMaintenanceInformation_performedTrue.parentAssetRef = new AssetRef();
        asset_with_goodParentRef_goodMaintenanceInformation_performedTrue.parentAssetRef.id = "60c15bef2bb59294843b3d71";
        asset_with_goodParentRef_goodMaintenanceInformation_performedTrue.maintenanceInformation = new MaintenanceInformation();
        asset_with_goodParentRef_goodMaintenanceInformation_performedTrue.maintenanceInformation.isMaintenancePerformedOnParentAsset = true;

        runOnCreateAsset(asset_with_nothing, 0);
        runOnCreateAsset(asset_with_badParentRef, 0);
        runOnCreateAsset(asset_with_goodParentRef_noMaintenanceInformation, 0);
        runOnCreateAsset(asset_with_goodParentRef_goodMaintenanceInformation_performedFalse, 0);
        runOnCreateAsset(asset_with_goodParentRef_goodMaintenanceInformation_performedTrue, 1);
    }

}
