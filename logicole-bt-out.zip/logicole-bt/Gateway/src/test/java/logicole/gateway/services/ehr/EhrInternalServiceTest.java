package logicole.gateway.services.ehr;

import logicole.common.datamodels.dmlss.EhrSiteCustomer;
import logicole.common.datamodels.ehr.product.EhrSearchCriteria;
import logicole.common.datamodels.equipment.record.EquipmentRecord;
import logicole.common.datamodels.organization.EhrCustomersBySite;
import logicole.common.general.exception.ObjectNotFoundException;
import logicole.gateway.services.equipment.EquipmentRecordService;
import logicole.gateway.services.organization.OrganizationService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;



@RunWith(MockitoJUnitRunner.class)
public class EhrInternalServiceTest {

    @Mock
    private OrganizationService organizationService;
    @Mock
    private EquipmentRecordService equipmentRecordService;


    List<EhrSiteCustomer> customers = new ArrayList<EhrSiteCustomer>();
    EhrSiteCustomer customer1 = new EhrSiteCustomer();
    EhrSiteCustomer customer2 = new EhrSiteCustomer();
    EhrSiteCustomer customer3 = new EhrSiteCustomer();

    // setup Test Strings
    String type = "test";
    String siteId = "A";
    String customerId = "B";
    String id = "C";
    boolean isEhrEnabled = true;

    List<EquipmentRecord> equipmentRecords = new ArrayList<EquipmentRecord>();
    EhrSearchCriteria ehrSearchCriteria = new EhrSearchCriteria();
    EquipmentRecord equipmentRecord = new EquipmentRecord();


    @Spy
    @InjectMocks
    private EhrInternalService spy;

    @Before
    public void before() {
        setup();
    }

    private void setup() {

        // Setup test customer data
        customers = new ArrayList<EhrSiteCustomer>();
        customer1 = new EhrSiteCustomer();
        customer2 = new EhrSiteCustomer();
        customer3 = new EhrSiteCustomer();

        customer1.siteOrgId = "5c3653cb93f521351a7770ee";
        customer1.customerOrgId = "5c3653cb93f521351a7770ef";
        customer1.ehrLastItemSyncDate = new Date();
        customer2.siteOrgId = "5c3653cb93f521351a777000";
        customer2.customerOrgId = "5c3653cb93f521351a777001";
        customer2.ehrLastItemSyncDate = new Date();
        customer3.siteOrgId = "5c3653cb93f521351a777000";
        customer3.customerOrgId = "5c3653cb93f521351a777001";
        customer3.ehrLastItemSyncDate = new Date();

        customers.add(customer1);
        customers.add(customer2);
        customers.add(customer3);

        // Setup Equipment record data
        equipmentRecords = new ArrayList<EquipmentRecord>();

        ehrSearchCriteria = new EhrSearchCriteria();

    }

    @Test
    public void testGetEhrSiteCustmers() throws ObjectNotFoundException {

        // Setup expected behavior
        when(organizationService.getEhrSiteCustomers(anyString())).thenReturn(customers);

        // Run the method
        Collection<EhrCustomersBySite> customersBySite = spy.getEhrSiteCustomers(type);

        // Verify
        assertEquals(customersBySite.size(), 2);

    }

    @Test
    public void testGetCustomerOrgs() throws ObjectNotFoundException {
        // Setup expected behavior
        when(organizationService.getCustomerOrgs()).thenReturn(customers);

        // Run the method
        List<EhrSiteCustomer> orgs = spy.getCustomerOrgs();

        // Verify
        assertNotNull(orgs);
    }

    @Test
    public void testSaveCustomerOrg() throws ObjectNotFoundException {
        // Setup expected behavior
        when(organizationService.saveCustomerOrg(any(EhrSiteCustomer.class))).thenReturn(customer1);

        // Run the method
        EhrSiteCustomer customer = spy.saveCustomerOrg(customer1);

        // Verify
        assertNotNull(customer);
    }

    @Test
    public void testGetEquipmentRecordsForSiteCustomer() throws ObjectNotFoundException {

        // Setup expected behavior
        when(equipmentRecordService.getEquipmentRecordsForSiteCustomer(anyString(), anyString())).thenReturn(equipmentRecords);

        // Run the method
        List<EquipmentRecord> equipmentRecords = spy.getEquipmentRecordsForSiteCustomer(siteId, customerId);

        // Verify
        assertNotNull(equipmentRecords);
    }

    @Test
    public void testGetEhrEquipmentRecords() throws Exception {

        // Setup expected behavior
        when(equipmentRecordService.getEhrEquipmentRecords(any(EhrSearchCriteria.class))).thenReturn(equipmentRecords);

        // Run the method
        List<EquipmentRecord> equipmentRecords = spy.getEhrEquipmentRecords(ehrSearchCriteria);

        // Verify
        assertNotNull(equipmentRecords);
    }

    @Test
    public void testSetEquipmentEhrEnabled() throws ObjectNotFoundException {

        // Setup expected behavior
        when(equipmentRecordService.setEquipmentEhrEnabled(anyString(), anyBoolean())).thenReturn(equipmentRecord);

        // Run the method
        EquipmentRecord equipmentRecord = spy.setEquipmentEhrEnabled(id, isEhrEnabled);

        // Verify
        assertNotNull(equipmentRecord);
    }

    @Test
    public void testResetItemCatalogSyncDate() throws ObjectNotFoundException {

        // Setup expected behavior
        when(organizationService.resetItemCatalogSyncDate(anyString())).thenReturn(customer1);

        // Run the method
        EhrSiteCustomer customer = spy.resetItemCatalogSyncDate(id);

        // Verify
        assertNotNull(customer);
    }

    @Test
    public void testResetEquipmentCatalogSyncDate() throws ObjectNotFoundException {

        // Setup expected behavior
        when(organizationService.resetEquipmentCatalogSyncDate(anyString())).thenReturn(customer1);

        // Run the method
        EhrSiteCustomer customer = spy.resetEquipmentCatalogSyncDate(id);

        // Verify
        assertNotNull(customer);
    }





}
