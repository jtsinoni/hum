package logicole.gateway.services.maintenance;

import logicole.apis.maintenance.IMaintenanceTeamMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.maintenance.team.MaintenanceTeam;
import logicole.common.datamodels.maintenance.technician.TechnicianRef;
import logicole.common.datamodels.maintenance.technician.TechnicianTeamAssignment;
import logicole.common.datamodels.organization.OrganizationRef;
import logicole.common.datamodels.organization.OrganizationTypeRef;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.exception.UnauthorizedException;
import org.bson.types.ObjectId;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.AdditionalAnswers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MaintenanceTeamServiceTest {

    @Spy
    @InjectMocks
    private MaintenanceTeamService maintenanceTeamService;
    @Mock
    private IMaintenanceTeamMicroserviceApi microservice;
    @Mock
    private TechnicianService technicianService;
    @Mock
    private CurrentUserBT currentUserBT;
    @Mock
    private CurrentUser currentUser;
    @Mock
    private UserProfile userProfile;
    private MaintenanceTeam maintenanceTeam;
    private OrganizationRef currentNodeRef;

    @Before
    public void setup() {
        whenGetCurrentUserThenReturnCurrentUser();
        whenGetCurrentNodeIdThenReturnCurrentUserNodeId();
        maintenanceTeam = new MaintenanceTeam();
        maintenanceTeam._id = new ObjectId();
        maintenanceTeam.name = "Test Team";
        maintenanceTeam.managedByNodeRef = currentNodeRef;
        maintenanceTeam.managedByNodeRef.ancestry = currentNodeRef.ancestry;
        whenFindByIdThenReturnMaintenanceTeam();
    }

    private void whenGetCurrentUserThenReturnCurrentUser() {
        currentNodeRef = new OrganizationRef();
        currentNodeRef.id = "testId";
        currentNodeRef.ancestry = "test,ancestry," + currentNodeRef.id;
        userProfile.currentNodeRef = currentNodeRef;
        userProfile.nodeTypeRef = new OrganizationTypeRef();
        userProfile.nodeTypeRef.level = 100;
        userProfile.pkiDn = "testPKIDN";
        currentUser.profile = userProfile;
        when(currentUserBT.getCurrentUser()).thenReturn(currentUser);
    }

    private void whenGetCurrentNodeIdThenReturnCurrentUserNodeId() {
        when(currentUserBT.getCurrentNodeId()).thenReturn(currentUser.profile.currentNodeRef.id);
    }

    private void whenFindByIdThenReturnMaintenanceTeam() {
        when(microservice.findById(anyString())).thenReturn(maintenanceTeam);
    }

    @Test
    public void shouldReturnMaintenanceTeamWhenFindById() {
        MaintenanceTeam actual = maintenanceTeamService.findById(maintenanceTeam.getId());
        assertSame(maintenanceTeam, actual);
    }

    @Test
    public void shouldReturnMaintenanceTeamWhenCreateMaintenanceTeam() {
        when(microservice.createMaintenanceTeam(any(MaintenanceTeam.class))).thenAnswer(AdditionalAnswers.returnsFirstArg());
        MaintenanceTeam actual = maintenanceTeamService.createMaintenanceTeam(maintenanceTeam);
        assertSame(maintenanceTeam, actual);
    }

    @Test
    public void shouldReturnMaintenanceTeamWhenUpdateMaintenanceTeam() {
        when(microservice.updateMaintenanceTeam(any(MaintenanceTeam.class))).thenAnswer(AdditionalAnswers.returnsFirstArg());
        MaintenanceTeam actual = maintenanceTeamService.updateMaintenanceTeam(maintenanceTeam);
        assertSame(maintenanceTeam, actual);
    }

    @Test(expected = UnauthorizedException.class)
    public void shouldThrowExceptionWhenUpdateMaintenanceTeamWhenNoAccess() {
        maintenanceTeam.managedByNodeRef = new OrganizationRef();
        maintenanceTeam.managedByNodeRef.id = "anotherId";
        maintenanceTeamService.updateMaintenanceTeam(maintenanceTeam);
    }

    @Test
    public void shouldReturnListOfTeamsWhenGetMaintenanceTeams() {
        when(microservice.getMaintenanceTeams()).thenReturn(new ArrayList<>());
        List<MaintenanceTeam> actual = maintenanceTeamService.getMaintenanceTeams();
        assertTrue(actual.isEmpty());
    }

    @Test
    public void shouldReturnListOfTechRefsWhenGettingAvailableTechsForAssignment() {
        List<TechnicianRef> sourceTechRefs = new ArrayList<>();
        TechnicianRef techRef1 = new TechnicianRef();
        techRef1.id = "testId1";
        sourceTechRefs.add(techRef1);
        when(technicianService.getAvailableTechniciansByOrganizationId(anyString())).thenReturn(sourceTechRefs);
        List<TechnicianTeamAssignment> technicianTeamAssignments = new ArrayList<>();
        TechnicianTeamAssignment technicianTeamAssignment = new TechnicianTeamAssignment();
        technicianTeamAssignment.maintenanceTeamRef = maintenanceTeam.getRef();
        technicianTeamAssignment.technicianRef = techRef1;
        technicianTeamAssignments.add(technicianTeamAssignment);
        when(microservice.getTechnicianTeamAssignments(anyString())).thenReturn(technicianTeamAssignments);
        List<TechnicianRef> actual = maintenanceTeamService.getAvailableTechniciansForAssignment(maintenanceTeam.getId());
        assertTrue(actual.isEmpty());
    }

    @Test
    public void shouldReturnMaintenanceTeamWhenMakingTechnicianAssignment() {
        when(technicianService.addTechnicianTeamAssignment(any(TechnicianTeamAssignment.class))).thenAnswer(AdditionalAnswers.returnsFirstArg());
        TechnicianTeamAssignment actual = maintenanceTeamService.addTechnicianTeamAssignment(maintenanceTeam.getId(), true, new TechnicianRef());
        assertNotNull(actual);
    }

    @Test
    public void shouldReturnMaintenanceTeamWhenUpdatingTechnicianAssignment() {
        when(technicianService.updateTechnicianTeamAssignment(anyString(), any(TechnicianTeamAssignment.class))).thenAnswer(AdditionalAnswers.returnsLastArg());
        TechnicianTeamAssignment technicianTeamAssignment = new TechnicianTeamAssignment();
        technicianTeamAssignment.technicianRef = new TechnicianRef();
        technicianTeamAssignment.technicianRef.id = "test";
        TechnicianTeamAssignment actual = maintenanceTeamService.updateTechnicianTeamAssignment(maintenanceTeam.getId(), technicianTeamAssignment);
        assertSame(technicianTeamAssignment, actual);
    }

    @Test
    public void shouldReturnMaintenanceTeamWhenRemovingTechnicianAssignment() {
        TechnicianTeamAssignment technicianAssignment = new TechnicianTeamAssignment();
        technicianAssignment.technicianRef = new TechnicianRef();
        maintenanceTeamService.removeTechnicianTeamAssignment(maintenanceTeam.getId(), technicianAssignment);
        assertTrue(true);
    }
}