package logicole.gateway.common.workflow;

import logicole.common.crossservice.workflow.IWorkFlowMicroserviceApi;
import logicole.common.datamodels.PersistedEntity;
import logicole.common.datamodels.workflow.WorkflowAction;
import logicole.common.datamodels.workflow.WorkflowState;
import logicole.common.datamodels.workflow.WorkflowStepDefinition;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class BaseWorkflowServiceTest {

    @Spy
    private BaseWorkflowService<PersistedEntity, IWorkFlowMicroserviceApi> service;

    @Test
    public void handleStatePropertiesTest() {
        WorkflowState workflowState = new WorkflowState();
        List<String> addStateProperties = new ArrayList<>();
        String a = "a";
        String b = "b";
        addStateProperties.add(a);
        addStateProperties.add(b);
        List<String> removeStateProperties = new ArrayList<>();

        service.handleStateProperties(workflowState, addStateProperties, removeStateProperties);

        assertNotNull(workflowState.stateProperties);
        assertEquals(2, workflowState.stateProperties.size());

        addStateProperties = new ArrayList<>();
        removeStateProperties = new ArrayList<>();
        removeStateProperties.add(b);
        service.handleStateProperties(workflowState, addStateProperties, removeStateProperties);

        assertNotNull(workflowState.stateProperties);
        assertEquals(1, workflowState.stateProperties.size());

    }

    @Test
    public void handleStatePropertiesDuplicateTest() {
        WorkflowState workflowState = new WorkflowState();
        List<String> addStateProperties = new ArrayList<>();
        String a = "a";
        String b = "b";
        addStateProperties.add(a);
        addStateProperties.add(b);
        List<String> removeStateProperties = new ArrayList<>();

        service.handleStateProperties(workflowState, addStateProperties, removeStateProperties);

        assertNotNull(workflowState.stateProperties);
        assertEquals(2, workflowState.stateProperties.size());

        removeStateProperties = new ArrayList<>();
        service.handleStateProperties(workflowState, addStateProperties, removeStateProperties);

        assertNotNull(workflowState.stateProperties);
        assertEquals(2, workflowState.stateProperties.size());

    }

    @Test
    public void getNextPositionTestDefault() {
        int currentPosition = 0;
        WorkflowStepDefinition step = new WorkflowStepDefinition();
        step.workflowActions = new ArrayList<>();
        WorkflowAction a1 = new WorkflowAction();
        step.workflowActions.add(a1);
        a1.isDefault = true;
        a1.nextStepPosition = 1;

        int retval = service.getNextPosition(currentPosition, step);

        assertEquals(1, retval);
    }

    @Test
    public void getNextPositionTestNoDefault() {

    }
}
