package logicole.gateway.services.abi;

import logicole.apis.abi.IAbiStagingMicroserviceApi;
import logicole.common.datamodels.CurrentUserBT;
import logicole.common.datamodels.abi.ABiCatalogRecordRef;
import logicole.common.datamodels.abi.CriticalItemCategoryRef;
import logicole.common.datamodels.abi.staging.*;
import logicole.common.datamodels.abi.types.StagingRequestType;
import logicole.common.datamodels.filemanager.FileManager;
import logicole.common.datamodels.filemanager.FileRef;
import logicole.common.datamodels.product.AbiProductUpdate;
import logicole.common.datamodels.user.CurrentUser;
import logicole.common.datamodels.user.UserProfile;
import logicole.common.general.logging.ILogger;
import logicole.common.general.util.DateUtil;
import logicole.common.general.util.JSONUtil;
import logicole.common.general.util.string.StringUtil;
import logicole.common.servers.history.BusinessMethodExecutioner;
import logicole.common.servers.history.MessageFactory;
import logicole.gateway.common.EndpointAccessFilter;
import logicole.gateway.services.abi.item.ItemService;
import logicole.gateway.services.abi.stagingrequest.ABiStagingRequestUtil;
import logicole.gateway.services.abi.stagingrequest.LogAccumulator;
import logicole.gateway.services.abi.stagingrequest.PackagingWorksheetUploadUpdateProcessor;
import logicole.gateway.services.filemanager.FileManagerAdminService;
import logicole.gateway.services.product.OfferService;
import logicole.gateway.services.product.ProductService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.util.*;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ABiStagingServiceTest {

    @Mock
    protected ILogger logger;
    @Mock
    protected CurrentUserBT currentUserBT;
    @Mock
    private MessageFactory logMessageFactory;
    @Mock
    protected EndpointAccessFilter endpointAccessFilter;
    @Mock
    private BusinessMethodExecutioner businessMethodExecutioner;

    @Mock
    private DateUtil dateUtil;

    @Mock
    private StringUtil stringUtil;

    @Mock
    private ABiStagingRequestUtil aBiStagingRequestUtil;

    @Mock
    private LogAccumulator logAccumulator;

    @Mock
    private PackagingWorksheetUploadUpdateProcessor packagingWorksheetUploadUpdateProcessor;

    @Mock
    private JSONUtil jsonUtil;

    @Mock
    private AbiConfigurationService configurationService;

    @Mock
    private AbiCatalogService abiCatalogService;

    @Mock
    private AbiStagingMoveRecordsService abiStagingMoveRecordsService;

    @Mock
    private FileManagerAdminService fileManagerAdminService;

    @Mock
    private ItemService itemService;

    @Mock
    private OfferService offerService;

    @Mock
    private ProductService productService;

    @Mock
    private SiteCatalogRequestService siteCatalogRequestService;

    @Mock
    private IAbiStagingMicroserviceApi microservice;

    @InjectMocks
    private AbiStagingService mgr;

    @Before
    public void setup() {
        CurrentUser currentUser = mock(CurrentUser.class);
        currentUser.profile = mock(UserProfile.class);
        when (currentUserBT.getCurrentUser()).thenReturn(currentUser);
    }

    @Test
    public void testGetCurrentUser() {
        CurrentUser result = mgr.getCurrentUser();
    }

    @Test
    public void testGetStatistics() {
        AbiCatalogStatistics result = mgr.getStatistics();
    }

    // TODO: FIX THIS WHEN THERE IS TIME
//    @Test
//    public void testSearchRecords() {
//        String mode = "All";
//        String matchOption = "Ending";
//        String filterData = "glove";
//        List<AbiCatalogStagingRecord> result = mgr.searchRecords(mode, matchOption, filterData);
//    }

    @Test
    public void testValidateRecord() {
        AbiCatalogStaging record = mock(AbiCatalogStaging.class);
        FieldValidationStatus result = mgr.validateRecord(record);
    }

    // TODO: FIX THIS WHEN THERE IS TIME
//    @Test
//    public void testRequestApprovalForRecord() {
//        AbiCatalogStagingRecord recordRequestingApproval = mock(AbiCatalogStagingRecord.class);
//        ApprovalRequestResult approvalRequestResult = mock(ApprovalRequestResult.class);
//        approvalRequestResult.recordHasValidationErrors = false;
//        approvalRequestResult.recordRequestingApproval = recordRequestingApproval;
//        approvalRequestResult.approvalCanBeRequested = true;
//        when(microservice.requestApprovalForRecord(recordRequestingApproval)).thenReturn(approvalRequestResult);
//
//        ApprovalRequestResult result = mgr.requestApprovalForRecord(recordRequestingApproval);
//    }

    // TODO: FIX THIS WHEN THERE IS TIME
//    @Test
//    public void testApproveRecord() {
//        AbiCatalogStagingRecord recordToApprove = mock(AbiCatalogStagingRecord.class);
//        ApprovalResult result = mgr.approveRecord(recordToApprove);
//    }

    @Test
    public void testUpdateRecord() {
        AbiCatalogStaging recordToUpdate = mock(AbiCatalogStaging.class);
        AbiCatalogStaging result = mgr.updateRecord(recordToUpdate);
    }

    @Test
    public void testFindRecordById() {
        String recordId = "111";
        AbiCatalogStaging result = mgr.findRecordById(recordId);
    }

    @Test
    public void testChangeRecordStatus() {
        AbiCatalogStaging recordToUpdate = mock(AbiCatalogStaging.class);
        String recordStatusType = "Incomplete";
        mgr.changeRecordStatus(recordToUpdate, recordStatusType);
    }

    @Test
    public void testUpdateStagingRecord() {
        AbiCatalogStaging updatedRecord = mock(AbiCatalogStaging.class);
        AbiCatalogStaging result = mgr.updateRecord(updatedRecord);
    }

    // TODO: FIX THIS WHEN THERE IS TIME
//    @Test
//    public void testMarkRecordIncomplete() {
//        String id = "1111";
//        AbiCatalogStagingRecord result = mgr.markRecordIncomplete(id);
//    }

    @Test
    public void testDeleteRecord() {
        AbiCatalogStaging recordToDelete = mock(AbiCatalogStaging.class);
        Integer result = mgr.deleteRecord(recordToDelete);
    }

    @Test
    public void testGetStagingRequests() {
        Boolean showSubtasks = true;
        List<StagingRequestQueueRecord> result = mgr.getStagingRequests(showSubtasks);
    }

    @Test
    public void testGetDownloadFiles() {
        List<AbiDownloadFile> result = mgr.getDownloadFiles();
    }

    // TODO: FIX THIS WHEN THERE IS TIME
//    @Test
//    public void testDownloadAbiFile() {
//        boolean exceptionThrown = false;
//        try {
//            String id = "1111";
//            AbiDownloadFile file = mock(AbiDownloadFile.class);
//            file.id = "1112222333";
//            file.fileManagerId = "222333444";
//            when(microservice.getDownloadFileInfo(id)).thenReturn(file);
//            Response result = mgr.downloadABiFile(id);
//        } catch (IOException ex) {
//            exceptionThrown = true;
//        }
//        Assert.assertFalse(exceptionThrown);
//    }

    // TODO: FIX THIS WHEN THERE IS TIME
//    @Test
//    public void testGetDownloadedFileData() {
//        boolean exceptionThrown = false;
//        try {
//            AbiDownloadFile file = mock(AbiDownloadFile.class);
//            byte[] result = mgr.getDownloadFileData(file);
//        } catch (IOException ex) {
//            exceptionThrown = true;
//        }
//        Assert.assertFalse(exceptionThrown);
//    }

    @Test
    public void testGenerateGhxItemMasterSpreadsheet() {
        StagingRequestResponse result = mgr.generateGHXItemMasterSpreadsheet();
    }

    @Test
    public void testGetMaxUploadSize() {
        Integer result = mgr.getMaxUploadSize();
    }

    @Test
    public void testUploadFile() {
        byte[] fileContent = new byte[1024];
        String uploadedFilename = "SpankyMcFardle.txt";
        FileManager result = mgr.uploadFile(fileContent, uploadedFilename);
    }

    @Test
    public void testGenerateStagingEditingSpreadsheet() {
        String mode = "All";
        String matchOption = "Starting";
        String filterData = "syringe";
        StagingRequestResponse result = mgr.generateStagingEditingSpreadsheet(mode, matchOption, filterData);
    }

    @Test
    public void testProcessAllStagingRequest() {
        boolean exceptionThrown = false;
        StagingRequest request = createTestStagingRequest(StagingRequestType.PROCESS_PRODUCT_SYNC);
        try {
            AbiProductUpdate abiProductUpdateList = mock(AbiProductUpdate.class);
            abiProductUpdateList.aBiCatalogRecordUpdateList = new ArrayList<>();
            when(jsonUtil.deserialize("arg1", AbiProductUpdate.class)).thenReturn(abiProductUpdateList);

            ABiManagerUploadFileBuilder result = mgr.processAllStagingRequest(request);
        } catch (IOException e) {
            exceptionThrown = true;
        }
        Assert.assertFalse(exceptionThrown);
    }

    // TODO: FIX THIS WHEN THERE IS TIME
//    @Test
//    public void testProcessStagingRequest() {
//        boolean exceptionThrown = false;
//        try {
//            StagingRequest request = createTestStagingRequest(StagingRequestType.BUILD_GHX_ITEM_MASTER_SPREADSHEET);
//            ABiManagerUploadFileBuilder result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.BUILD_SITE_CATALOG_NO_ABI_RECORD_WORKSHEET);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.RUN_APPLY_STAGING_CHANGES_TO_PRODUCTION);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.PROCESS_ITEM_RESEARCH_UPLOAD);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.BUILD_STAGING_EDITING_SPREADSHEET);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.PROCESS_STAGING_FILE_UPLOAD);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.UPDATE_COMMODITY_TYPE_ATTRIBUTES);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.UPDATE_STAGING_IMPLANT_ATTRIBUTES);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.APPLY_NSNS_TO_PACKAGING_RECORDS);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.BUILD_MMC_EXCEPTION_REPORT);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.BUILD_PACKAGING_WORKSHEET);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.PROCESS_HCPCS_IMPLANT_UPLOAD);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.PROCESS_MMC_NSN_MAP_UPLOAD);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.PROCESS_PACKAGING_WORKSHEET_UPLOAD);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.UPDATE_GENERIC_ID_UNSPSC_MAP_ATTRIBUTE);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.UPDATE_UNSPSC_CRITICAL_ITEM_CATEGORY_MAP_ATTRIBUTE);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.PROCESS_ECRI_UPLOAD);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.APPLY_STAGING_CHANGES_TO_PRODUCTION_SUBTASK);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.PROCESS_COMMODITY_TYPE_UPLOAD);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.APPLY_CASING_EXCEPTIONS);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.PROCESS_GENERIC_ID_UNSPSC_MAP_UPLOAD);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.UPLOAD_ABI_FILE);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.PROCESS_PRODUCT_SYNC);
//            result = mgr.processStagingRequest(request);
//
//            request = createTestStagingRequest(StagingRequestType.PROCESS_GHX_UPLOAD);
//            result = mgr.processStagingRequest(request);
//        } catch (ApplicationException | IOException ex) {
//            exceptionThrown = true;
//        }
//        Assert.assertFalse(exceptionThrown);
//    }

    @Test
    public void testGetRecordsInIdList() {
        ESearchAndReplaceType searchType = ESearchAndReplaceType.ManufacturerName;
        List<String> idList = new ArrayList<>();
        idList.add("111222");
        List<AbiCatalogStaging> result = mgr.getRecordsInIdList(searchType, idList);
    }

    @Test
    public void testSearchForWordInStagingRecords() {
        ESearchAndReplaceType searchType = ESearchAndReplaceType.ProductType;
        String searchString = "Spanky";
        Boolean matchEntireAttribute = true;
        List<AbiCatalogStaging> result = mgr.searchForWordInStagingRecords(searchType, searchString, matchEntireAttribute);
    }

    @Test
    public void testReplaceWordInStagingRecords() {
        ESearchAndReplaceType searchType = ESearchAndReplaceType.Descriptions;
        String oldString = "Banky";
        String newString = "Spanky";
        Boolean matchEntireAttribute = true;

        List<String> result = mgr.replaceWordInStagingRecords(searchType, oldString, newString, matchEntireAttribute);
    }

    @Test
    public void testGenerateMmcExceptionReport() {
        StagingRequestResponse result = mgr.generateMmcExceptionReport();
    }

    @Test
    public void testApplyStagingChangesToProduction() {
        Integer startIndex = 1;
        Integer finalEndIndex = 500;
        Integer chunkSize = 50;
        StagingRequestResponse result = mgr.applyStagingChangesToProduction(startIndex, finalEndIndex, chunkSize);
    }

    @Test
    public void testUpdateCommodityTypeAttributes() {
        StagingRequestResponse result = mgr.updateCommodityTypeAttributes();
    }

    @Test
    public void testUpdateGenericIdUnspscMapAttributes() {
        StagingRequestResponse result = mgr.updateGenericIdUnspscMapAttributes();
    }

    @Test
    public void testUpdateUnspscCriticalItemCategoryMapAttributes() {
        StagingRequestResponse result = mgr.updateUnspscCriticalItemCategoryMapAttributes();
    }

    @Test
    public void testApplyNsnsToPackagingRecords() {
        StagingRequestResponse result = mgr.applyNsnsToPackagingRecords();
    }

    @Test
    public void testPromoteApprovalCandidates() {
        String catalogSource = "GHX";
        StagingRequestResponse result = mgr.promoteApprovalCandidates(catalogSource);
    }

// TODO: FIX THIS WHEN THERE IS TIME
//    @Test
//    public void testApplyCasingExceptions() {
//        StagingRequestResponse result = mgr.applyCasingExceptions();
//    }

    @Test
    public void testUPdateStagingImplantAttributes() {
        StagingRequestResponse result = mgr.updateStagingImplantAttributes();
    }

    @Test
    public void testGeneratePackagingWorksheet() {
        String mode = "All";
        String matchOption = "All";
        String filterData = "gauze";
        StagingRequestResponse result = mgr.generatePackagingWorksheet(mode, matchOption, filterData);
    }

    @Test
    public void testGenerateSiteCatalogNoAbiRecordWorksheet() {
        Integer minimumGroupSize = 10;
        Integer minimumOrderSum = 1000;
        Boolean mmcExists = true;
        String manufacturerNameRange = "A-L";
        StagingRequestResponse result = mgr.generateSiteCatalogNoABiRecordWorksheet(minimumGroupSize,
                minimumOrderSum, mmcExists, manufacturerNameRange);
    }

    @Test
    public void testGetFileRefsByIds() {
        List<String> fileIds = new ArrayList<>();
        fileIds.add("11111");
        List<FileRef> results = mgr.getFileRefsByIds(fileIds);

    }

    @Test
    public void testDeleteStagingRequest() {
        String stagingRequestId = "11111";
        boolean result = mgr.deleteStagingRequest(stagingRequestId);
    }

    @Test
    public void testDeleteAbiFile() {
        boolean exceptionThrown = false;
        try {
            String id = "11111";
            AbiDownloadFile record = mock(AbiDownloadFile.class);
            record.id = id;
            record.fileManagerId = "111222";
            when(microservice.getDownloadFileInfo(id)).thenReturn(record);
            Integer result = mgr.deleteABiFile(id);
        } catch (IOException ex) {
            exceptionThrown = true;
        }
        Assert.assertFalse(exceptionThrown);
    }

    @Test
    public void testDoesEnterpriseProductIdentifierExist() {
        String enterpriseProductIdentifier = "11112222";
        boolean result = mgr.doesEnterpriseProductIdentifierExist(enterpriseProductIdentifier);

    }

    @Test
    public void testGetPriorStagingRequestCount() {
        Integer olderThanDays = 10;
        Long result = mgr.getPriorStagingRequestCount(olderThanDays);
    }

    @Test
    public void testDeletePriorStagingRequests() {
        Integer olderThanDays = 10;
        Long result = mgr.deletePriorStagingRequests(olderThanDays);

    }

    @Test
    public void testAdjustEcriEquipmentCount() {
        String ecriGuid = UUID.randomUUID().toString();
        Integer adjustment = 3;
        mgr.adjustEcriEquipmentCount(ecriGuid, adjustment);
    }

    @Test
    public void testSyncEquipmentRecordCounts() {
        Map<String, Integer> ecriProductCounts = new HashMap<>();
        ecriProductCounts.put("key", 111);
        List<String> result = mgr.syncEquipmentRecordCounts(ecriProductCounts);

    }

    @Test
    public void testGetInUseRecordsCount() {
        Long result = mgr.getInUseRecordsCount();
    }

    @Test
    public void testSendRequest() {
        StagingRequest request = mock(StagingRequest.class);
        mgr.sendRequest(request);

    }

    @Test
    public void testGetABiCatalogStagingRecordByEnterpriseProductIdentifer() {
        String enterpriseProductIdentifier = "1111";
        AbiCatalogStaging result = mgr.getAbiCatalogStagingRecordByEnterpriseProductIdentifier(enterpriseProductIdentifier);
    }

    @Test
    public void testGetAbiStagingCatalogRecordRefListForCriticalItems() {
        List<ABiCatalogRecordRef> result = mgr.getAbiStagingCatalogRecordRefListforCriticalItems();
    }

    @Test
    public void testUpdateCriticalItemCategoryRefs() {
        CriticalItemCategoryRef ref = mock(CriticalItemCategoryRef.class);
        mgr.updateCriticalItemCategoryRefs(ref);

    }

    private StagingRequest createTestStagingRequest(String stagingRequestType) {
        StagingRequest request = mock(StagingRequest.class);
        request.requestType = stagingRequestType;
        request.argumentList = new ArrayList<>();
        request.argumentList.add("arg1");
        request.argumentList.add("arg2");
        request.argumentList.add("arg3");
        return request;
    }
}
