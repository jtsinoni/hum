'use strict'

const fs = require('fs');
const recursive = require("recursive-readdir");
const HTMLParser = require('node-html-parser');

const tags = ['button', 'input', 'canvas', 'datagrid', 'datalist', 'form',
  'img', 'select', 'li', 'option', 'tr', 'div'];

const iterableTags = ['li', 'option', 'tr', 'div'];

const tagIds = [{tag: 'lc-button', idType: 'buttonId'}, {tag: '-input', idType: 'inputId'},
  {tag: 'lc-message-box', idType: 'messageBoxId'}, {tag: 'lc-switch', idType: 'switchId'},
  {tag: 'lc-print-notes', idType: 'notesId'}, {tag: 'lc-notes', idType: 'notesId'}, {
    tag: 'lc-string-list',
    idType: 'slId'
  },
  {tag: 'lc-barcode-entry-control', idType: 'becId'}, {tag: 'lc-delta-update-string-list', idType: 'duslId'},
  {tag: 'lc-delta-update-string', idType: 'dusId'}, {tag: 'lc-file-upload-list', idType: 'fulId'},
  {tag: 'lc-join-string-picker', idType: 'spId'}, {tag: 'lc-join-packaging-details-detail-grid', idType: 'pgId'},
  {tag: 'lc-abi-purge-requests-control', idType: 'prcId'}, {tag: 'lc-join-object-picker', idType: 'opId'},
  {tag: 'lc-join-typeahead-picker', idType: 'tapId'}, {tag: 'lc-join-product-identifier-list-picker', idType: 'pilpId'},
  {tag: 'lc-join-drop-down-list-picker', idType: 'ddlId'}, {
    tag: 'lc-join-product-documentation-list-picker',
    idType: 'pdlpId'
  },
  {tag: 'lc-join-string-list-picker', idType: 'slpId'}
];


function findHtml(path) {
  recursive(path, function (err, files) {
    if (files) {
      for (const file of files.filter(file => file.endsWith('.html'))) {
        readFile(file);
      }
    }
  });

}

function readFile(filename) {
  fs.readFile(filename, 'utf-8', (err, content) => {
    if (err) throw err;
    const root = HTMLParser.parse(content);
    parseHtml(root, filename, false);
  });

}


function parseHtml(root, filename, setFileName) {
  if (root === null || root === undefined) {
    return;
  } else {
    for (let i = 0; i < root.childNodes.length; i++) {
      let tagName = root.childNodes[i].tagName;
      if (tagName !== undefined) {
        let iterableTag = isIterableTag(tagName);
        let keyValue = getKeyValueMatching(tagName);
        if (keyValue != null) {
          let attributes = root.childNodes[i].rawAttrs;
          if (iterableTag && attributeDoesNotHaveNgFor(attributes)) {
              setFileName = false; // can't use continue - setting meaningless value
          } else if (attributes.indexOf(keyValue.idType) < 0) {
            if (attributes.indexOf('trackBy') < 0) {
              if (!setFileName) {
                console.log(filename);
                setFileName = true;
              }
              console.log(`***** No id for: -> Tag: ${tagName} ****`);
              console.log(attributes);
              console.log('');
            }
          }
        }
      }
      parseHtml(root.childNodes[i], filename, setFileName)
    }
  }
}

function isExactMatch(tag, tagsStr) {
  let match = tag.match(tagsStr);
  return match && tag === match[0];
}

function hasListedTag(nodeTag) {
  let hasTag = false;
  if (nodeTag !== undefined) {
    for (let i = 0; i < tags.length; i++) {
      if (isExactMatch(nodeTag, tags[i])) {
        hasTag = true;
        break;
      }
    }
  }
  return hasTag;
}

function isIterableTag(tagName) {
  let hasTag = false;
  if (tagName !== undefined) {
    for (let i = 0; i < iterableTags.length; i++) {
      if (isExactMatch(tagName, iterableTags[i])) {
        hasTag = true;
        break;
      }
    }
  }
  return hasTag;

}


function getKeyValueMatching(tagName) {
  let keyValue = null;

  if (hasListedTag(tagName)) {
    keyValue = {};
    keyValue.tag = tagName;
    keyValue.idType = 'id';
  } else {
    for (let i = 0; i < tagIds.length; i++) {
      if (tagIds[i].tag === tagName || tagName.endsWith(tagIds[i].tag)) {
        keyValue = tagIds[i];
        break;
      }
    }
  }
  return keyValue;

}

function attributeDoesNotHaveNgFor(attributes) {
  return attributes.indexOf('*ngFor') < 0;

}


// console.log(findHtml());
module.exports = findHtml;
// console.log(getKeyValueMatching('input'));


