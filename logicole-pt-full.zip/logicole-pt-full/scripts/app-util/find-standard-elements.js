'use strict'

const fs = require('fs');
const recursive = require("recursive-readdir");
const HTMLParser = require('node-html-parser');

const tags = ['button', 'input', 'select'];


function findStandardElements(path) {
  recursive(path, function (err, files) {
    if (files) {
      for (const file of files.filter(file => file.endsWith('.html'))) {
        readFile(file);
      }
    }
  });

}

function readFile(filename) {
  fs.readFile(filename, 'utf-8', (err, content) => {
    if (err) throw err;
    const root = HTMLParser.parse(content);
    parseHtml(root, filename, false);
  });

}


function parseHtml(root, filename, setFileName) {
  if (root === null || root === undefined) {
    return;
  } else {
    setFileName = false;
    for (let i = 0; i < root.childNodes.length; i++) {
      let tagName = root.childNodes[i].tagName;
      if (tagName !== undefined && isStandardTag(tagName)) {
        let attributes = root.childNodes[i].rawAttrs;
        if (!setFileName) {
          console.log(filename);
          setFileName = true;
        }
        console.log(`***** Standard Tag Used: ${tagName} ****`);
        console.log(attributes);
        console.log('');

      }
      parseHtml(root.childNodes[i], filename, setFileName)
    }
  }
}

function isExactMatch(tag, tagsStr) {
  let match = tag.match(tagsStr);
  return match && tag === match[0];
}


function isStandardTag(tagName) {
  let hasTag = false;
  if (tagName !== undefined) {
    for (let i = 0; i < tags.length; i++) {
      if (isExactMatch(tagName, tags[i])) {
        hasTag = true;
        break;
      }
    }
  }
  return hasTag;

}

module.exports = findStandardElements;
