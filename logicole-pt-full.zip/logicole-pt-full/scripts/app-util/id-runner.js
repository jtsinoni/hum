'use strict'


const findIds = require('./findMissingElementIds');
const findStandardItems = require('./find-standard-elements');

const projectAreas = [{area: 'abi-management', path: './src/app/home/jmlfdc-admin/abi-management'},
  {area: 'abi-search', path: './src/app/home/abi-search'},
  {area: 'access', path: './src/app/home/access'},
  {area: 'common-components', path: './src/app/common-components'},
  {area: 'communications', path: './src/app/home/communications'},
  {area: 'dashboard', path: './src/app/home/dashboard'},
  {area: 'dmlss-host', path: './src/app/home/jmlfdc-admin/dmlss-host'},
  {area: 'email-check', path: './src/app/home/jmlfdc-admin/email-check'},
  {area: 'equipment', path: './src/app/home/equipment'},
  {area: 'equipment-records', path: './src/app/home/equipment/equipment-records'},
  {area: 'equipment-requests', path: './src/app/home/equipment/equipment-requests'},
  {area: 'feature-flag', path: './src/app/home/jmlfdc-admin/feature-flag'},
  {area: 'finance', path: './src/app/home/finance'},
  {area: 'fulfillment', path: './src/app/home/fulfillment'},
  {area: 'health-status', path: './src/app/home/jmlfdc-admin/health-status'},
  {area: 'help', path: './src/app/home/help'},
  {area: 'home-components', path: './src/app/home/home-components'},
  {area: 'home-header', path: './src/app/home/home-header'},
  {area: 'inventory', path: './src/app/home/inventory'},
  {area: 'jmlfdc-admin', path: './src/app/home/jmlfdc-admin'},
  {area: 'login', path: './src/app/login'},
  {area: 'order', path: './src/app/home/order'},
  {area: 'organization', path: './src/app/home/organization'},
  {area: 'pull-facility-records', path: './src/app/home/jmlfdc-admin/pull-facility-records'},
  {area: 'real-property', path: './src/app/home/real-property'},
  {area: 'receiving', path: './src/app/home/receiving'},
  {area: 'report', path: './src/app/home/report'},
  {area: 'services', path: './src/app/services'},
  {area: 'slep', path: './app/home/slep'},
  {area: 'system-configuration', path: './src/app/home/jmlfdc-admin/system-configuration'},
  {area: 'system-notification', path: './src/app/home/jmlfdc-admin/system-notification'},


];


function run() {
  let projectArea = '';
  let stdItems = null;
  if (process.argv.length > 2) {
    projectArea = process.argv[2];

    if (process.argv.length > 3) {
      stdItems = process.argv[3];
    }
    let path = getProjectAreaPath(projectArea);
    if (stdItems) {
      findStandardItems(path);
    } else {
      findIds(path);
    }
  } else {
    console.log('Please include one of the following project areas in the command:');
    console.log('npm run missing-ids [project area]');
    console.log('*******************');

    for (let i = 0; i < projectAreas.length; i++) {
      if (projectAreas[i]) {
        console.log(projectAreas[i].area);
      }
    }

  }


}

function getProjectAreaPath(projectArea) {
  return projectAreas.find(p => p.area === projectArea).path;
}

console.log(run());







