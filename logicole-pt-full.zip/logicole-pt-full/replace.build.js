let replace = require('replace-in-file');
// let package = require("./package.json");
// let buildVersion = package.version;
let buildVersion = process.argv[2];
let buildDate = process.argv[3];
const options = {
  files: 'src/environments/environment.prod.ts',
  from: /version: '(.*)'/g,
  to: "version: '"+ buildVersion + "'",
  allowEmptyPaths: false,
};

try {
  let changedFiles = replace.sync(options);
  if (changedFiles == 0) {
    throw "Please make sure that file '" + options.files + "' has \"version: ''\"";
  }
  console.log('Build version set: ' + buildVersion);
}
catch (error) {
  console.error('Error occurred:', error);
  throw error
}

const options2 = {
  files: 'src/environments/environment.prod.ts',
  from: /date: '(.*)'/g,
  to: "date: '"+ buildDate + "'",
  allowEmptyPaths: false,
};

try {
  let changedFiles2 = replace.sync(options2);
  if (changedFiles2 == 0) {
    throw "Please make sure that file '" + options2.files + "' has \"buildDate: ''\"";
  }
  console.log('Build date set: ' + buildDate);
}
catch (error) {
  console.error('Error occurred:', error);
  throw error
}
