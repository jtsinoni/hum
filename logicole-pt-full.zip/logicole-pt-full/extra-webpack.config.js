module.exports = {
  optimization: {
    concatenateModules: false
  }
};
