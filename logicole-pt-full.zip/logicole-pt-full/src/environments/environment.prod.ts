export const environment = {
  production: true,
  version: '1.9.0',
  date: '0'
};
