import {Observable, of} from 'rxjs';
import {FloorPlanLayer} from '../models/floor-plan/floor-plan-layer.model';
import {DepartmentFill} from '../models/floor-plan/department-fill.model';

export class DrawingLookupApiServiceMock {

  public serviceName: string = 'Drawing Lookup Api Service';

  constructor() {
  }

  public getDepartmentFills(): Observable<Array<DepartmentFill>> {
    return of([new DepartmentFill()]);
  }

  public updateDepartmentFill(departmentFill: DepartmentFill): Observable<DepartmentFill> {
    return of(new DepartmentFill());
  }

  public getFloorPlanLayers(): Observable<Array<FloorPlanLayer>> {
    return of([new FloorPlanLayer()]);
  }

  public createFloorPlanLayer(floorPlanLayer: FloorPlanLayer): Observable<FloorPlanLayer> {
    return of(new FloorPlanLayer());
  }

  public updateFloorPlanLayer(floorPlanLayer: FloorPlanLayer): Observable<FloorPlanLayer> {
    return of(new FloorPlanLayer());
  }

  public deleteFloorPlanLayer(floorPlanLayerId: string): Observable<FloorPlanLayer> {
    return of(new FloorPlanLayer());
  }
}
