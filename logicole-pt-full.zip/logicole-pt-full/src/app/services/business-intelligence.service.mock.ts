import {Injectable} from '@angular/core';
import {HttpHeaders} from '@angular/common/http';

@Injectable()
export class BusinessIntelligenceServiceMock {

  public businessIntelligenceWindow: any;
  public jmarHomePageURL: string = '/jmar/portal/web/jmar/home';
  public jmarLogoutURL: string = '/jmar/portal/c/portal/logout';
  public headers: HttpHeaders = new HttpHeaders({
    'callerHandlesError': 'callerHandlesError'
  });

  constructor() {
  }

  public isJmarUser(): Promise<boolean> {
    return null;
  }

  public openBusinessIntelligenceTab(): void {
    return null;
  }

  public logout(): void {
    return null;
  }

  public hasBusinessIntelligenceWindow(): boolean {
    return true;
  }

}
