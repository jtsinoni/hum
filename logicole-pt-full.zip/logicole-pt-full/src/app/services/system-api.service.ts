import {ApiService} from './api.service';
import {LoggerService} from '@lc-logger-service';
import {HttpClient} from '@angular/common/http';
import {AuthenticationService} from '@lc-services/*';
import {LoaderService} from './loader.service';
import {ApiConstants} from '@lc-constants/*';
import {VersionInformation} from '../home/home-components/models/version-information';
import {Observable} from 'rxjs';
import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SystemApiService extends ApiService {

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
    super(ApiConstants.SYSTEM_API, logger, http, authenticationService, loaderService);
  }

  public getSystemVersionInformation(): Observable<VersionInformation[]> {
    return this.get('getAllSystemVersionInformation');
  }

  public getDatabaseVersionInformation(): Observable<VersionInformation> {
    return this.get('getDatabaseVersionInformation');
  }

  public updateEnumCollections(): Observable<Boolean> {
    return this.get('updateEnumCollections');
  }

  public getBusinessEventHistoryServices(): Observable<string[]> {
    return this.get('getBusinessEventHistoryServices');
  }
}
