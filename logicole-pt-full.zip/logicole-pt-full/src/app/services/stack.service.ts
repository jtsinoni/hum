import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StackService<T> {

  private serviceStack: Array<T>;

  constructor() {
    this.serviceStack = [];
  }

  public push(item: T) {
    const index = this.serviceStack.indexOf(item);
    if (index < 0) {
      this.serviceStack.push(item);
    }
  }

  public pop(): T {
    return this.serviceStack.pop();
  }

  public getTop(): T {
    const stackCount = this.getStackCount();
    if (stackCount > 0) {
      return this.serviceStack[(stackCount - 1)];
    } else {
      return null;
    }
  }

  public getStackCount(): number {
    return this.serviceStack.length;
  }

  public getAll() {
    return this.serviceStack;
  }

  public clearAll() {
    this.serviceStack = [];
  }

  public removeSelected(item: T) {
    const index = this.serviceStack.indexOf(item);
    if (index > -1) {
      this.serviceStack.splice(index, 1);
    }
  }

  public showStack() {
    let itemString: String = '';
    for (const item of this.serviceStack) {
      itemString += item.toString();
    }
    return itemString;

  }
}
