import {Injectable} from '@angular/core';
import {Organization, OrganizationRef, ScopeQuery} from '@lc-app-models';
import {OrganizationService} from '../home/organization/services/organization.service';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ScopeCoversService {

  constructor(private organizationService: OrganizationService) {
  }

  public getScopeCoversByOrganizationRefs(organizationTypeId: string, scopeOrganizationRefs: Array<OrganizationRef>): Observable<Array<Organization>> {
    const scopeIdList: string[] = [];
    scopeOrganizationRefs.forEach(organizationRef => {
      scopeIdList.push(organizationRef.id);
    });

    return this.getScopeCoversByOrganizationIds(organizationTypeId, scopeIdList);
  }

  public getScopeCoversByOrganizationIds(organizationTypeId: string, organizationIds: Array<string>): Observable<Array<Organization>> {
    const scopeQuery: ScopeQuery = new ScopeQuery(organizationTypeId, organizationIds);
    return this.organizationService.getOrganizationsInScope(scopeQuery);
  }
}
