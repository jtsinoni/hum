import {Injectable} from '@angular/core';
import {ApiService} from 'app/services/api.service';
import {AuthenticationService, LoggerService} from '@lc-services/*';
import {HttpClient} from '@angular/common/http';
import {LoaderService} from 'app/services/loader.service';
import {ApiConstants} from '@lc-constants/*';
import {Observable} from 'rxjs';
import {SearchInput} from '../models/search-input.model';
import {SearchResult} from '../models/search-result.model';
import {Floor} from '../home/real-property/space/models/floor.model';
import {DrawingDashboardInfo} from '../home/dashboard/models/drawing-dashboard-info';
import {FloorPlanDiscrepancy} from '../home/real-property/space/models/floor-plan-discrepancy.model';
import {DrawingSummary} from '../home/real-property/space/models/drawing-summary.model';

@Injectable()
export class FloorPlanApiService extends ApiService {

  public serviceName: string = 'Floor Plan Api Service';

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
    super(ApiConstants.DRAWING_API, logger, http, authenticationService, loaderService);
    this.logger.debug(`${this.serviceName} - Start`);
  }

  public getDrawingSummarySearchResultsAndAggregations(searchInput: SearchInput): Observable<SearchResult<DrawingSummary>> {
    return this.post('getDrawingSummarySearchResults', searchInput);
  }

  public removeDrawingFromFloor(floorId: string): Observable<Floor> {
    return this.get('removeDrawingFromFloor?floorId=' + floorId);
  }

  public updateDrawingName(floorId: string, drawingName: string): Observable<Floor> {
    return this.post('updateDrawingName?floorId=' + floorId, drawingName);
  }

  public downloadFloorPlan(floorPlanId: string): Observable<any> {
    const query = 'downloadFloorPlan?floorPlanId=' + floorPlanId;
    return this.getArrayBuffer(query);
  }

  public getDrawingDashboardCounts(): Observable<DrawingDashboardInfo> {
    return this.get('getDrawingDashboardCounts');
  }

  public getDiscrepanciesForFloor(floorId: string, discrepancyType: string): Observable<FloorPlanDiscrepancy> {
    return this.get('getDiscrepanciesForFloor?floorId=' + floorId + '&discrepancyType=' + discrepancyType);
  }

  public findDiscrepanciesForFloor(floorId: string): Observable<FloorPlanDiscrepancy> {
    return this.get('findDiscrepanciesForFloor?floorId=' + floorId);
  }

  public acceptSizeDiscrepancies(floorPlanDiscrepancy: FloorPlanDiscrepancy): Observable<FloorPlanDiscrepancy> {
    return this.post('acceptSizeDiscrepancies', floorPlanDiscrepancy);
  }

  public getDrawingSummariesWithFloorPlans(): Observable<Array<DrawingSummary>> {
    return this.get('getDrawingSummariesWithFloorPlans');
  }

  public getDrawingSummariesWithoutFloorPlans(): Observable<Array<DrawingSummary>> {
    return this.get('getDrawingSummariesWithoutFloorPlans');
  }

  public getDrawingSummariesWithOutdatedDiscrepancies(): Observable<Array<DrawingSummary>> {
    return this.get('getDrawingSummariesWithOutdatedDiscrepancies');
  }

  public getDrawingSummariesWithDiscrepancyTypes(discrepancyTypes: Array<string>): Observable<Array<DrawingSummary>> {
    return this.post('getDrawingSummariesWithDiscrepancyTypes', discrepancyTypes);
  }

  public getMaxDrawingAttachmentSize(): Observable<number> {
    return this.get('getMaxDrawingAttachmentSize');
  }

  public getDocumentTypes(): Observable<string[]> {
    return this.get('getDocumentTypes');
  }
}
