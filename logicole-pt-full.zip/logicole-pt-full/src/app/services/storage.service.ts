import {Injectable} from '@angular/core';
import {LoggerService} from './logger/logger.service';
import {UtilService} from './util.service';
import {WindowService} from './window.service';
import {ApiConstants} from '@lc-constants/*';

@Injectable()
export class StorageService {
  private serviceName = 'StorageService';
  private windowRef: any;

  constructor(private logger: LoggerService, private windowService: WindowService, private utilService: UtilService ) {
    this.logger.debug(`${this.serviceName} - Start`);
    this.windowRef = windowService.window;
  }

  public clearData() {
    this.windowRef.sessionStorage.clear();
    this.removeData(ApiConstants.LC_ROUTE_KEY);
    this.removeData(ApiConstants.LC_USER_KEY);
    this.removeData(ApiConstants.AUTH_NONCE);
    this.removeData(ApiConstants.AUTH_STATE);
    this.removeData(ApiConstants.IAS_TOKEN_KEY);
    this.logger.debug('%s - Cache data cleared', this.serviceName);
  }

  public getData(key: string): any {
    let value: any;
    try {
      value = this.windowRef.sessionStorage.getItem(key);
    } catch (err) {
      this.logger.error('Unable to get item from session storage');
    }

    if (!value || 'undefined' === value || 'null' === value) {
      return null;
    }
    // assume it is an object that has been stringified
    if (value[0] === '{') {
      value = JSON.parse(value);
    }
    return value;
  }

  public removeData(key: string) {
    this.windowRef.sessionStorage.removeItem(key);
  }

  public storeData(key: string, data: any, stringify: boolean) {
    if (stringify && !this.utilService.isObjectEmpty(data)) {
      data = JSON.stringify(data);
    }
    try {
      this.windowRef.sessionStorage.setItem(key, data);
    } catch (err) {
      this.logger.error('Unable to save data in session storage');
    }
  }
}
