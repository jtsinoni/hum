import {Injectable} from '@angular/core';
import {Subject} from 'rxjs';

export interface LoaderState {
  show: boolean;
}

@Injectable()
export class LoaderService {

  private loaderSubject = new Subject<LoaderState>();
  public loaderState = this.loaderSubject.asObservable();

  constructor() {
  }

  public show(): void {
    this.loaderSubject.next(<LoaderState>{show: true});
  }

  public hide(): void {
    this.loaderSubject.next(<LoaderState>{show: false});
  }

}
