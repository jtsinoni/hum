import {ApiConstants} from '@lc-constants/*';
import {of} from 'rxjs';
import {FileRef} from '@lc-app-models';

export class FileManagerServiceMock {

    public forbiddenFileExtensions: string[] = [];

    constructor() {
    }

  public download(fileId: string) {
    return of('file contents');
  }

  public base64Download(fileId: string) {
    return of('file contents');
  }

  public getFileInfo(fileId: string) {
    return of(new FileRef());
  }

  public getUploadConfiguration() {
    const uploadUrl: string = 'baseApiUrl' + ApiConstants.FILE_MANAGER_API + 'uploadManaged';

    return {
      url: uploadUrl,
      headers: {
        'authorization': 'Token ' + 'authenticationService.getToken()',
        'ClientId': 'dmles',
      }
    };
  }

  public getMaxPostSize() {
    return of('maxPostSize');
  }

  public getForbiddenFileExtensions() {
    return of(['forbiddenExtension']);
  }

    public formatBytes(bytes, decimals = 2) {
        return of('formatBytes');
    }
    
  public removeFile(fileId: string) {
    return of('void');
  }

  public removeFileUnmanaged(fileId: string) {
    return of('void');
  }

  public retrieveFileId(input: string): string {
    return '';
  }

}
