import {Injectable} from '@angular/core';

export const ProjectDetailsTabs = {
  detailsTab: {
    id: 'detailsTab',
    tabName: 'Details',
    paneName: 'detailsPane'
  } as Tab,
  equipmentTab: {
    id: 'equipmentTab',
    tabName: 'Equipment',
    paneName: 'equipmentPane'
  } as Tab,
  spaceTab: {
    id: 'spaceTab',
    tabName: 'Space',
    paneName: 'spacePane'
  } as Tab,
  estimateTab: {
    id: 'estimateTab',
    tabName: 'Estimate',
    paneName: 'estimatePane'
  } as Tab,
  fundingTab: {
    id: 'fundingTab',
    tabName: 'Funding',
    paneName: 'fundingPane'
  },
  contractTab: {
    id: 'contractTab',
    tabName: 'Contract',
    paneName: 'contractPane'
  } as Tab,
  assignTab: {
    id: 'assignTab',
    tabName: 'Assign',
    paneName: 'assignPane'
  } as Tab,
  impactsTab: {
    id: 'impactsTab',
    tabName: 'Impacts',
    paneName: 'impactsPane'
  } as Tab,
  businessContactsTab: {
    id: 'businessContactsTab',
    tabName: 'Business Contacts',
    paneName: 'businessContactsPane'
  } as Tab,
  associatedRecordsTab: {
    id: 'associatedRecordsTab',
    tabName: 'Associated Records',
    paneName: 'associatedRecordsPane'
  } as Tab,
  journalsTab: {
    id: 'journalsTab',
    tabName: 'Journals',
    paneName: 'journalsPane'
  } as Tab,
  attachmentsTab: {
    id: 'attachmentsTab',
    tabName: 'Attachments',
    paneName: 'attachmentsPane'
  } as Tab,
  workflowTab: {
    id: 'workflowTab',
    tabName: 'Workflow',
    paneName: 'workflowPane'
  } as Tab,
} as const;

export const RequirementsTabs = {
  detailsTab: {
    id: 'detailsTab',
    tabName: 'Details',
    paneName: 'detailsPane'
  } as Tab,
  equipmentTab: {
    id: 'equipmentTab',
    tabName: 'Equipment',
    paneName: 'equipmentPane'
  } as Tab,
  spaceTab: {
    id: 'spaceTab',
    tabName: 'Space',
    paneName: 'spacePane'
  } as Tab,
  analysisTab: {
    id: 'analysisTab',
    tabName: 'Analysis',
    paneName: 'analysisPane'
  } as Tab,
  estimateTab: {
    id: 'estimateTab',
    tabName: 'Estimate',
    paneName: 'estimatePane'
  } as Tab,
  journalsTab: {
    id: 'journalsTab',
    tabName: 'Journals',
    paneName: 'journalsPane'
  } as Tab,
  attachmentsTab: {
    id: 'attachmentsTab',
    tabName: 'Attachments',
    paneName: 'attachmentsPane'
  } as Tab,
  associatedRequirementsTab: {
    id: 'associatedRequirementsTab',
    tabName: 'Associated Requirements',
    paneName: 'associatedRequirementsPane'
  } as Tab,
  fundingTab: {
    id: 'fundingTab',
    tabName: 'Funding',
    paneName: 'fundingPane'
  } as Tab,
  workflowTab: {
    id: 'workflowTab',
    tabName: 'Workflow',
    paneName: 'workflowPane'
  } as Tab,
} as const;

export enum TabGroups {
  RP_PROJECTS = 'Projects',
  RP_REQUIREMENTS = 'Requirements',
}

export interface Tab {
  id: string;
  tabName: string;
  paneName: string
  active?: boolean;
  shown?: boolean;
}

export interface TabGroup {
  tabGroupName: string;
  selectedTab: Tab;
  previousTab: Tab;
  tabs: Tab[];
}

@Injectable({
  providedIn: 'root'
})
export class TabManagerService {
  private tabGroups: TabGroup[] = [];

  constructor() {
    this.initialize();
  }

  private initialize() {
    // Projects
    this.initializeProjectsTabGroup();

    // Requirements
    this.initializeRequirementsTabGroup();
  }

  private initializeProjectsTabGroup() {
    this.tabGroups.push({
      tabGroupName: TabGroups.RP_PROJECTS,
      selectedTab: {
        id: ProjectDetailsTabs.detailsTab.id,
        tabName: ProjectDetailsTabs.detailsTab.tabName,
        active: true,
        shown: true,
      },
      previousTab: null,
      tabs: this.getTabsForTabGroup(ProjectDetailsTabs),
    } as TabGroup);
  }

  private initializeRequirementsTabGroup() {
    this.tabGroups.push({
      tabGroupName: TabGroups.RP_REQUIREMENTS,
      selectedTab: {
        id: RequirementsTabs.detailsTab.id,
        tabName: RequirementsTabs.detailsTab.tabName,
        active: true,
        shown: true,
      },
      previousTab: null,
      tabs: this.getTabsForTabGroup(RequirementsTabs),
    } as TabGroup);
  }

  private getTabsForTabGroup(tabs): Tab[] {
    return  Object.keys(tabs).map(tab => ({id: tabs[tab].id, tabName: tabs[tab].tabName, active: true, shown: true} as Tab));
  }


  public getTabGroup(tabGroupName: string): TabGroup {
    return this.findTabGroup(tabGroupName);
  }

  private findTabGroup(tabGroupName: string): TabGroup {
    return this.tabGroups.find(tabGroup => tabGroup.tabGroupName === tabGroupName);
  }

  public setSelectedTab(tabGroupName: string, id: string) {
    // Check to see if tabGroup already exists
    const tabGroup = this.findTabGroup(tabGroupName);
    if (tabGroup) {
      tabGroup.previousTab = tabGroup.selectedTab;

      // Get tab
      const tab = tabGroup.tabs.find(tab => tab.id === id);
      tabGroup.selectedTab = tab;
    }
  }

  public setTabGroupToDefaults(tabGroupName: string) {
    const tabGroup = this.findTabGroup(tabGroupName);
    if (tabGroup) {
      tabGroup.previousTab = null;
      tabGroup.selectedTab = ProjectDetailsTabs.detailsTab;
    }
  }
}
