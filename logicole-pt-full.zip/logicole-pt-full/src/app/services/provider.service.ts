import { Injectable } from '@angular/core';
import {ProviderApiService} from './provider-api.service';
import { Observable } from 'rxjs';
import {Provider} from '../models/provider.model';
import {ProviderRef} from '../models/provider-ref.model';
import {ProviderType} from '../models/provider-type.model';

@Injectable({
  providedIn: 'root'
})
export class ProviderService {

  public selectedProvider: Provider;

  public selectedProviderTypeName: string;

  constructor(private providerApiService: ProviderApiService) { }

  public getFinancialServiceProviders(): Observable<Array<Provider>> {
    return this.providerApiService.getFinancialServiceProviders();
  }

  public getAllProviders(): Observable<Array<Provider>> {
    return this.providerApiService.getAllProviders();
  }

  public findProviderById(providerId: string): Observable<Provider> {
    return this.providerApiService.findProviderById(providerId);
  }

  public saveProvider(provider: Provider): Observable<Provider> {
    return this.providerApiService.saveProvider(provider);
  }

  public deleteProvider(provider: Provider) {
    return this.providerApiService.deleteProvider(provider);
  }

  public getProviderTypes(): Observable<Array<ProviderType>> {
    return this.providerApiService.getProviderTypes();
  }
  public getProviderRefsByType(providerType: string): Observable<Array<ProviderRef>> {
    return this.providerApiService.getProviderRefsByType(providerType);
  }

}
