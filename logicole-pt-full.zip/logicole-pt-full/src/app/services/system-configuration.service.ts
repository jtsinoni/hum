import {LoggerService} from '@lc-logger-service';
import {Observable} from 'rxjs';
import {Configuration} from '@lc-app-models';
import {Injectable} from '@angular/core';
import {SystemConfigurationApiService} from './system-configuration-api.service';
import {ConfigurationCollection} from '../models/configuration-collection.model';

@Injectable({
  providedIn: 'root',
})
export class SystemConfigurationService {

  constructor(
    private logger: LoggerService,
    private systemConfigurationApiService: SystemConfigurationApiService) {
  }

  public getAllConfigurations(): Observable<ConfigurationCollection> {
    return this.systemConfigurationApiService.getAllConfigurations();
  }

  public addUpdateConfiguration(configuration: Configuration): Observable<Configuration> {
    return this.systemConfigurationApiService.addUpdateConfiguration(configuration);
  }

  public getConfiguration(id: string, owner: string): Observable<Configuration> {
    return this.systemConfigurationApiService.getConfiguration(id, owner);
  }

  public getConfigurationByName(name: string, owner: string): Observable<Configuration> {
    return this.systemConfigurationApiService.getConfigurationByName(name, owner);
  }


}
