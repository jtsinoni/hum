import {Aggregation} from '../models/aggregation.model';
import {AggregationElasticsearch} from '../models/aggregation-elasticsearch.model';
import {SearchCriterion} from '../models/search-criterion.model';

export class SearchUtilityServiceMock {

  constructor() {
  }

  public convertAggregationsInBtResponseToLcSearchFiltersFormat(aggregations): AggregationElasticsearch[] {
    return [];
  }

  public convertAggregationToLcSearchFiltersFormat(aggregations: Array<Aggregation>): AggregationElasticsearch {
    return new AggregationElasticsearch();
  }

  public convertLcSearchFiltersToNewFilterFormat(lcSearchFilters): SearchCriterion[] {
    return [];
  }
}
