import {VersionInformation} from '../home/home-components/models/version-information';
import {Observable, of} from 'rxjs';

export class SystemApiServiceMock {

  constructor() {
  }

  public getSystemVersionInformation(): Observable<VersionInformation[]> {
    return of([new VersionInformation()]);
  }

  public getDatabaseVersionInformation(): Observable<VersionInformation> {
    return of(new VersionInformation());
  }
}
