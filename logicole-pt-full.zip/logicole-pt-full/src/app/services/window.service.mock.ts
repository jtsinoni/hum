
export class WindowServiceMock {
  constructor() {
  }

  public shiftKeySelected(): boolean {
    return true;
  }

  public ctrlKeySelected(): boolean {
    return true;
  }

  public ctrlAndOrShiftKeysSelected(): boolean {
    return true;
  }

  public getDocument() {
    return null;
  }

  public getElements(name: String) {
    return null;
  }

  public getElementsByClassName(name: String) {
    return null;
  }

  public getElementsByIdPrefix(prefix: String) {
    return null;
  }

  public isTouchScreenDevice(): boolean {
    return false;
  }

  public back() {
    return null;
  }

}
