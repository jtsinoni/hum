import {Injectable} from '@angular/core';
import {LoggerService} from './logger/logger.service';
import {RawParams, StateService, TransitionOptions} from '@uirouter/angular';
import {TransitionPromise} from '@uirouter/core';
import {RouteInfo} from '@lc-constants/*';
import {BreadcrumbService} from './breadcrumb.service';
import {WindowService} from './window.service';

@Injectable()
export class StateNavigationService {

  private _returnRoute: RouteInfo = null;
  private _data = { };

  private get returnRouteInfo (): RouteInfo  {
    return this._returnRoute;
  }
  private set returnRouteInfo (routeInfo: RouteInfo) {
    this._returnRoute = routeInfo;
  }

  constructor(private logger: LoggerService, private windowService: WindowService,
              private stateService: StateService, private breadcrumbService: BreadcrumbService) {
    this.logger.debug('in StateNav service');
  }

  public isCurrentState(stateName: string): boolean{
    let found = false;
    if (this.stateService.current){
      found = this.stateService.current.name === stateName;
    }
    return found;
  }

  public isPreviousState(stateName: string): boolean {
    if (this.returnRouteInfo) {
      return this.returnRouteInfo.name === stateName;
    } else if (this.breadcrumbService.getPreviousRoute()) {
      const returnRoute = this.breadcrumbService.getPreviousRoute();
      return returnRoute.name === stateName;
    } else {
      return false;
    }
  }

  public navigateTo(routeInfo: RouteInfo, returnRoute?: RouteInfo): TransitionPromise {
    // this.logger.debug(`route info is: ${routeInfo.name} return route is ${returnRoute.name}`);
    this.returnRouteInfo = returnRoute;
    const state = routeInfo.name;
    return this.stateService.go(state);
  }

  public navigateToState(routeInfo: RouteInfo, reload?: boolean): TransitionPromise {
    // this.logger.debug(`route info is: ${routeInfo.name} return reload is ${reload}`);
    if (!reload){
      return this.stateService.go(routeInfo.name, null, null);
    }else{
      return this.stateService.go(routeInfo.name, null, { reload : reload });
    }
  }

  // data is a key : value pair {thing: 'value'}
  public navigateToStateWithDataParameters(routeInfo: RouteInfo, data: any, reload?: boolean): TransitionPromise {
    this.logger.debug(`route info is: ${routeInfo.name} data is ${JSON.stringify(data)}`);
    if (!reload) {
      return this.stateService.go(routeInfo.name, data, null);
    } else {
      return this.stateService.go(routeInfo.name, data, {reload: reload});
    }
  }

  public navigateToStateWithOptions(routeInfo: RouteInfo, options: any): TransitionPromise {
    this.logger.debug(`route info is: ${routeInfo.name} options are ${JSON.stringify(options)}`);
    return this.stateService.go(routeInfo.name, null, options);
  }

  public navigateToStateWithDataAndOptions(routeInfo: RouteInfo, data?: RawParams, options?: TransitionOptions) {
    this.logger.debug(`route info is: ${routeInfo.name} data is ${JSON.stringify(data)} options are ${JSON.stringify(options)}`);
    return this.stateService.go(routeInfo.name, data, options);
  }

  public back() {
    this.windowService.back();
  }

  // if the return route is set go there, else go to the previous route
  public previous(data?: any) {
    const returnRoute = this.getReturnRoute();
    this.returnRouteInfo = null;
    if (data) {
      return this.stateService.go(returnRoute.name, data, null);
    } else {
      return this.stateService.go(returnRoute.name);
    }

  }

  public getReturnRoute(): RouteInfo {
    let returnRoute = null;
    if (this.returnRouteInfo) {
      returnRoute = this.returnRouteInfo;
    } else if (this.breadcrumbService.getPreviousRoute()) { // had to store in the breadcrumb service else I get an
      returnRoute = this.breadcrumbService.getPreviousRoute(); // infinite loop using StateNavigationService -- ?
    } else {
      this.logger.error('cant find return route');
      returnRoute = null;
    }
    return returnRoute;
  }
}

