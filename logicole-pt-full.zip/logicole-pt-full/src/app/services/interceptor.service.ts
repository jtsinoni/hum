import {Injectable} from '@angular/core';
import {HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest, HttpResponse} from '@angular/common/http';
import {Observable} from 'rxjs';
import {tap} from 'rxjs/operators';
import {LoggerService, NotificationService} from '@lc-services/*';
import {StorageService} from './storage.service';
import {ApiConstants, RouteConstants} from '@lc-constants/*';
import {StateNavigationService} from './state-navigation.service';

@Injectable()
export class InterceptorService implements HttpInterceptor {

  constructor(public notificationService: NotificationService,
              public storageService: StorageService,
              private navigationService: StateNavigationService,
              private logger: LoggerService) {
  }

  public displayNotification(error: any) {
    let errorMsg: string = 'An error has occurred';
    if (error.status && error.status === 470) {
      errorMsg = this.findCustomMessage(error.error);
    }

    if ((error.status && error.status === 471)) {
      errorMsg = 'Unauthorized request';
      this.logger.error(this.findCustomMessage(error.error));
    }

    if (error.status && error.status === 500) {
      errorMsg = this.findCustomMessage(error.error);
    }

    if (!error.status || error.status === 0) {
      errorMsg = 'An end point or business method cannot be found';
    }

    let isWarning: boolean = this.isWarningMessage(errorMsg);
    if (isWarning) {
      const warningMsg: string = this.findWarningMessage(errorMsg);
      this.notificationService.warningMsg(warningMsg);
    } else {
      this.notificationService.errorMsg(errorMsg);
    }

  }

  public findCustomMessage(fullMessage: string) {
    let message: string = 'An error occurred';
    const messageParts: string[] = fullMessage.toString().split('*');
    if (messageParts.length === 3){
      message = messageParts[1];
    }
    return message;
  }

  public isWarningMessage(message: string) {
    let isWarning: boolean;
    const messageParts: string[] = message.toString().split('WARN:');
    if (messageParts.length === 2){
      isWarning = true;
    }
    return isWarning;
  }

  public findWarningMessage(message: string) {
    const messageParts: string[] = message.toString().split('WARN:');
    if (messageParts.length === 2){
      message = messageParts[1];
    }
    return message;
  }

  private goToLogin() {
    this.navigationService.navigateTo(RouteConstants.LOGIN);
  }

  // intercept http request, add headers and token
  public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const myToken = this.storageService.getData(ApiConstants.LC_TOKEN_KEY);
    const iasToken = this.storageService.getData(ApiConstants.IAS_TOKEN_KEY);

    // Add on the standard headers being careful to leave the existing headers intact
    let headers: HttpHeaders = request.headers;
    headers = headers.set('Authorization', `Bearer ${myToken}`);
    headers = headers.set('ClientId', ApiConstants.LC_CLIENT_ID);

    if (!request.headers.get(ApiConstants.LC_CONTENT_TYPE_HEADER_KEY)) {
      headers = headers.set(ApiConstants.LC_CONTENT_TYPE_HEADER_KEY, ApiConstants.LC_CONTENT_TYPE_HEADER_JSON_VALUE);
    }

    if (iasToken && !myToken){
      headers = headers.append(ApiConstants.X_IAS_JWT_HEADER, iasToken);
    }

    headers = headers.set('Pragma',  'no-cache');
    headers = headers.set('Content-Type', 'application/json');

    request = request.clone({
      headers: headers
    });

    const h =headers.keys()
    // this.logger.debug(`headers:` + h);

    return next.handle(request)
      .pipe(
        tap(event => {
          if (event instanceof HttpResponse) {
            // console.log(' all looks good');
            // http response status code
            // console.log(event.status);
          }
        }, error => {
          const callerHandlesErrorHeader: string = request.headers.get(ApiConstants.LC_CALLER_HANDLES_ERR);
          if (error.status === 401) {
            this.goToLogin();
          } else {
          if (!callerHandlesErrorHeader) {
            this.displayNotification(error);
          } else {
            return error;
          }
          }

        })
      );

  }

}
