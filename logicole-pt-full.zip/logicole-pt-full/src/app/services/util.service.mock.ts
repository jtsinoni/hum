import {Injectable} from '@angular/core';
import {FormGroup, NgForm} from '@angular/forms';

@Injectable()
export class UtilServiceMock {
  constructor() {
  }

  public addZero(i) {
    return 0;
  }

  public convertCamelCaseToText(camelCaseText) {
    return '';
  }

  public convertCurrencyToFloat(currency) {
    return '0.00';
  }

  public convertFloatToCurrency(amount) {
    return '$0.00';
  }

  public convertHashToList(hash: any, fieldName?: string): Array<any> {
    const resultList: Array<any> = [];
    return resultList;
  }

  public convertStringToInteger(value: string) {
    return 0;
  }

  public getPastDate(numberOfDaysToSubtract: number): Date {
    const offset = 24 * 60 * 60 * 1000 * numberOfDaysToSubtract;
    const date = new Date();
    date.setTime(date.getTime() - offset);
    return date;
  }

  public detectIE(): number {
    return 0;
  }

  public esBuildSearchStatsStr(numResults: string, time: string) {
    return '';
  }

  /**
   * Escape special characters that might be embedded in the user-input search string(s)
   * not doing this causes issues for elasticsearch
   */
  public esEscapeSpecialChars(searchInput: string) {
    return '';
  }

  public getDate(d: Date) {
    return '';
  }

  public getDateTime(dateVar) {
    return '';
  }

  public getFutureDate(addYears: number, addMonths: number, addDays: number) {
    return '';
  }

  public getFiscalYear(dateValue: Date = new Date()): number {
    return 2020;
  }

  public formatDatetimeDuration(milliseconds: number): string {
    return '';
  }

  public calculateDatetimeDuration(startDate: Date, endDate: Date): number {
    return 0;
  }

  public getHashLength(hash) {
    return '';
  }

  public getTime(d) {
    return '';
  }

  public isStringFound(searchFor, searchWithin) {
    return true;
  }

  public isObjectEmpty(obj: any) {
    return true;
  }

  public sortResults(jList, prop, isAsc) {
    return '';
  }

  public isNullOrEmpty(obj: any): boolean {
    return true;
  }

  public isArrayNullOrEmpty(arr: Array<any>): boolean {
    return true;
  }

  public isStringNullOrEmpty(str: string): boolean {
    return true;
  }

  public isNullOrUndefined(obj: any): boolean {
    return true;
  }

  public listContainsString(stringList: Array<string>, stringToCheck: string): boolean {
    return true;
  }

  public doesArrayContainString(searchString: string, sourceArray: string[]): boolean {
    return true;
  }

  public findTheNthOccurrenceInString(sourceString: string, pattern: string, occurrence: number): number {
    const pos = -1;
    return pos;
  }

  public formatValueDashValue(valueOne, valueTwo): string {
    return '';
  }

  public randomStringGenerator(length: number, includeNumbers: boolean) {
    return '';
  }

  public replacePeriodsWithSlashes(sourceString: string): string {
    return '';
  }

  public removeSubstring(sourceString: string, subString: string): string {
    return '';
  }

  public sortByName(arrayOfObjects, nameToCompare) {
    return arrayOfObjects;
  }

  public formatDate(date: Date): string {
    return '';
  }

  // formatDateToCompare() Used to format date for comparison. Not recommended to be used for display purpose.
  public formatDateToCompare(date: Date): string {
    return '';
  }

  public convertToPaddedString(value: number, length: number, padChar: string) {
    return '';
  }

  // Pass in an object that you want to deep copy, meaning the copy is completely separate from the original
  // and updating values in the copy does not update values in the original object
  public deepCopy(obj: any): any {
    return obj;
  }

  // Pass in a form and it will return the first validation error from the form. If the form is valid, it will return null.
  public getFormValidationError(form: NgForm): string {
    return '';
  }

  public isValidDate(date: any) {
    return true;
  }

  public defaultIfNullOrUndefined<T>(value: T, defaultValue: T): T {
    return value;
  }

  public getActiveFormatted(isActive: boolean): string {
    return 'Active';
  }

  public subscribeToRefresh() {
  }

  public compareObjectsById(o1: any, o2: any): boolean {
    return true;
  }

  public compareObjectArraysById(o1: any[], o2: any[]): boolean {
    return true;
  }

  // Return a regex where you specify how many digits to allow before the decimal point, and after the decimal point
  // if allowZeroValue is true, then zero is a valid entry, otherwise it is not
  // null is valid if the input is not required
  public getDecimalRegex(maxDigitsBeforeDecimalPoint: number, maxDigitsAfterDecimalPoint: number, allowZeroValue?: boolean): string | RegExp {
    const allowDigitStart: number = allowZeroValue ? 0 : 1;
    return '^(?=.*[' + allowDigitStart + '-9])\\d{0,' + maxDigitsBeforeDecimalPoint + '}(?:\\.\\d{0,' + maxDigitsAfterDecimalPoint + '})?$';
  }

  public getFormGroupValidationError(formGroup: FormGroup) {
    return '';
  }

  public dateStringCheckAndConvert(date: any) {
    return '';
  }
}
