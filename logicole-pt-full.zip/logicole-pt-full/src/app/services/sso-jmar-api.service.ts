import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {ApiConstants} from '@lc-constants/*';
import {ApiService} from './api.service';
import {AuthenticationService} from './core/authentication.service';
import {LoaderService} from './loader.service';
import {LoggerService} from './logger/logger.service';
import {SsoJmarService} from './sso-jmar.service';

@Injectable()
export class SsoJmarApiService extends ApiService {

  public jmarHomePageURL: string = '/jmar/portal/web/jmar/home';

  public jmarUser: boolean = false;

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService,
              private ssoJmarService: SsoJmarService) {
    super(ApiConstants.BUSINESS_INTELLIGENCE_API, logger, http, authenticationService, loaderService);
  }

  public getJmarUser() {
    this.isJmarUser().then((isJmarUser: boolean) => { this.jmarUser = isJmarUser; });
    if (this.jmarUser === undefined || !this.jmarUser) {
      this.jmarUser = false;
    }
  }

  public isJmarUser(): Promise<boolean> {
    return this.ssoJmarService.isJmarUser().then(result => {
      return result;
    }, error => {
      if (error.status !== 403) {
        this.logger.debug('Unable to determine Reporting & Analytics status. (Error status ' + error.status + ')');
      }
      return false;
    });
  }

  public redirectToJmar(): void {
    window.document.location.href = this.jmarHomePageURL;
  }
}
