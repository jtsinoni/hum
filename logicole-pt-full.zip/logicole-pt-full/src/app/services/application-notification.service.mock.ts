import {ApplicationNotification} from '../home/jmlfdc-admin/system-notification/models/application-notification';

export class ApplicationNotificationServiceMock {

  public allNotifications: ApplicationNotification[];

  public getAllNotifications() {
    this.allNotifications  = [];
  }

  public getUnreadNotificationCount() {
    return 1;
  }

}
