import {Injectable} from '@angular/core';
import {AuthenticationService, LoggerService} from '@lc-services/*';
import {HttpClient} from '@angular/common/http';
import {LoaderService} from './loader.service';
import {ApiConstants} from '@lc-constants/*';
import {ApiService} from './api.service';
import {Observable} from 'rxjs';
import {PermissionDetailed} from '../models/permission-detailed.model';

@Injectable({
  providedIn: 'root'
})
export class PermissionApiService extends ApiService {

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
    super(ApiConstants.PERMISSION_API, logger, http, authenticationService, loaderService);
  }

  public getPermission(permissionId: string): Observable<PermissionDetailed> {
    return this.get(`getPermission?permissionId=${permissionId}`);
  }
}
