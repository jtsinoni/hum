import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {LoaderService} from './loader.service';
import {LoggerService} from '@lc-logger-service';

@Injectable()
export class SsoJmarService {

  public headers: HttpHeaders = new HttpHeaders({
    'callerHandlesError': 'callerHandlesError'
  });

  constructor(private http: HttpClient,
              private loaderService: LoaderService) { }

  public isJmarUser(): Promise<boolean> {
    return this.http.get('/jmar/jmarservices/integrated/isJmarUser', {
      headers: this.headers,
      responseType: 'text'
    }).toPromise().then(() => {
      this.loaderService.hide();
      return true;
    });
  }
}
