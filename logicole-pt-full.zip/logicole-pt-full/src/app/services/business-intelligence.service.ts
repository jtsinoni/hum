import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {LoggerService} from './logger/logger.service';
import {LoaderService} from './loader.service';
import {AuthenticationService} from './core/authentication.service';
import {BusinessIntelligenceApiService} from './business-intelligence-api.service';

@Injectable()
export class BusinessIntelligenceService {

  public businessIntelligenceWindow: any;
  public jmarHomePageURL: string = '/jmar/portal/web/jmar/home';
  public jmarLogoutURL: string = '/jmar/portal/c/portal/logout';
  public headers: HttpHeaders = new HttpHeaders({
    'callerHandlesError': 'callerHandlesError'
  });

  public bcsToken: string;
  public bcsWindow: Window;

  private serviceName: string = 'BusinessIntelligenceService';

  constructor(private authenticationService: AuthenticationService,
              private businessIntelligenceApiService: BusinessIntelligenceApiService,
              private http: HttpClient,
              private loaderService: LoaderService,
              private logger: LoggerService) {
    this.logger.debug(`${this.serviceName} - Start`);
  }

  public isJmarUser(): Promise<boolean> {
    return this.http.get('/jmar/jmarservices/integrated/isJmarUser', {
      headers: this.headers,
      responseType: 'text'
    }).toPromise().then(() => {
      this.loaderService.hide();
      return true;
    });
  }

  public openBusinessIntelligenceTab(): void {
    let url: string = this.jmarHomePageURL + '?isLogicoleUser=true&tokenVersion=B';
    const logicoleToken: string = this.authenticationService.getToken();

    if (!this.hasBusinessIntelligenceWindow()) {
      this.businessIntelligenceWindow = window.open('', '_blank');

      this.businessIntelligenceApiService.getJmarToken().subscribe(jmarToken => {
        if (jmarToken) {
          url += '&jmarToken=' + jmarToken;
        }

        if (logicoleToken) {
          url += '&logicoleToken=' + logicoleToken;
        }

        this.businessIntelligenceWindow.location.href = url;
      });
    } else {
      this.businessIntelligenceWindow.focus();
    }
  }

  public logout(): void {
    if (this.hasBusinessIntelligenceWindow()) {
      this.businessIntelligenceWindow.location.href = this.jmarLogoutURL;
    }
  }

  public hasBusinessIntelligenceWindow(): boolean {
    if (this.businessIntelligenceWindow == null || this.businessIntelligenceWindow.closed) {
      return false;
    }
    try {
      return this.businessIntelligenceWindow.document.URL.indexOf('/jmar/portal') > -1;
    } catch {
      return false;
    }
  }
}
