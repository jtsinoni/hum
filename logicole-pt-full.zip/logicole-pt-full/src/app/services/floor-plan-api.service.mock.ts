import {Observable, of} from 'rxjs';
import {SearchInput} from '../models/search-input.model';
import {SearchResult} from '../models/search-result.model';
import {Floor} from '../home/real-property/space/models/floor.model';
import {DrawingDashboardInfo} from '../home/dashboard/models/drawing-dashboard-info';
import {DrawingSummary} from '../home/real-property/space/models/drawing-summary.model';
import {FloorPlanDiscrepancy} from '../home/real-property/space/models/floor-plan-discrepancy.model';

export class FloorPlanApiServiceMock {

  public serviceName: string = 'Floor Plan Api Service';

  constructor() {
  }

  public getDrawingSummarySearchResultsAndAggregations(searchInput: SearchInput): Observable<SearchResult<DrawingSummary>> {
    return of(new SearchResult());
  }

  public updateDrawingActive(floorId: string, isActive: boolean): Observable<Floor> {
    return of(new Floor());
  }

  public removeDrawingFromFloor(floorId: string): Observable<Floor> {
    return of(new Floor());
  }

  public updateDrawingName(floorId: string, drawingName: string): Observable<Floor> {
    return of(new Floor());
  }

  public downloadFloorPlan(floorPlanId: string): Observable<any> {
    return of('');
  }

  public getDrawingDashboardCounts(): Observable<DrawingDashboardInfo> {
    return of(new DrawingDashboardInfo());
  }

  public getDiscrepanciesForFloor(floorId: string, discrepancyTypes: Array<string>): Observable<FloorPlanDiscrepancy> {
    return of(new FloorPlanDiscrepancy());
  }

  public findDiscrepanciesForFloor(floorId: string): Observable<FloorPlanDiscrepancy> {
    return of(new FloorPlanDiscrepancy());
  }

  public getDrawingSummariesWithFloorPlans(): Observable<Array<DrawingSummary>> {
    return of([new DrawingSummary()]);
  }

  public getDrawingSummariesWithoutFloorPlans(): Observable<Array<DrawingSummary>> {
    return of([new DrawingSummary()]);
  }

  public getDrawingSummariesWithOutdatedDiscrepancies(): Observable<Array<DrawingSummary>> {
    return of([new DrawingSummary()]);
  }

  public getDrawingSummariesWithDiscrepancyTypes(): Observable<Array<DrawingSummary>> {
    return of([new DrawingSummary()]);
  }

  public getMaxDrawingAttachmentSize(): Observable<number> {
    return of(1);
  }

  public getDocumentTypes(): Observable<string[]> {
    return of();
  }
}
