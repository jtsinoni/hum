import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {ApiConstants} from '@lc-constants/*';
import {ApiService} from './api.service';
import {AuthenticationService} from './core/authentication.service';
import {LoaderService} from './loader.service';
import {LoggerService} from './logger/logger.service';
import {finalize, takeUntil} from 'rxjs/operators';
import {Subject} from 'rxjs';

@Injectable()
export class SsoSapTewlsApiService extends ApiService {

  public tewlsWindow: any;
  public tewlsUrl: string;
  private tewlsToken: string;

  private destroy$: Subject<boolean> = new Subject<boolean>();

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
    super(ApiConstants.SSO_API, logger, http, authenticationService, loaderService);
  }

  public hasTewlsUrl(): boolean {
    return this.tewlsUrl && this.tewlsUrl.length > 0;
  }

  public getTewlsUrl(lcAccess: boolean): Promise<string>{
    if (lcAccess) {
      this.tewlsToken = this.authenticationService.getToken();
    } else {
      this.getSapTewlsToken();
    }

    const headers: HttpHeaders = new HttpHeaders({
      'Authorization': `Bearer ${this.tewlsToken}`,
      'ClientId': ApiConstants.LC_CLIENT_ID
    });

    return this.getText(`getTewlsUrl`, true, headers).toPromise().then(
      result => {
        this.tewlsUrl = result;
        return result;
      }, error => {
        this.logger.error('Error retrieving URL from TEWLS: ' + error.message);
        return '';
      });
  }

  public getSapTewlsToken() {
    this.getText(`getSapTewlsToken`, true)
      .pipe(
        takeUntil(this.destroy$),
        finalize(() => {
        })
      )
      .subscribe(tewlsToken => {
        if (tewlsToken) {
          this.tewlsToken = tewlsToken;
        }
      });
  }

  public openTewlsTab(): void {
    if (!this.hasTewlsWindow()) {
      this.tewlsWindow = window.open(this.tewlsUrl, '_blank');
    } else {
      this.tewlsWindow.focus();
    }
  }

  public logout(): void {
    if (this.hasTewlsWindow()) {
      this.tewlsWindow.close();
    }
  }

  public hasTewlsWindow(): boolean {
    return !(this.tewlsWindow == null || this.tewlsWindow.closed);
  }
}
