import {Injectable} from '@angular/core';
import {ApiService} from './api.service';
import {AuthenticationService, LoggerService} from '@lc-services/*';
import {HttpClient} from '@angular/common/http';
import {LoaderService} from './loader.service';
import {ApiConstants} from '@lc-constants/*';
import {Role, RoleRef} from '@lc-app-models';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RoleApiService extends ApiService {

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
    super(ApiConstants.ROLE_API, logger, http, authenticationService, loaderService);
  }

  public getRoles(roleIds: string[]): Observable<Role[]> {
    return this.post('getRoles', roleIds);
  }

  public getAllRoleRefs(): Observable<RoleRef[]> {
    return this.get('getAllRoleRefs');
  }



}
