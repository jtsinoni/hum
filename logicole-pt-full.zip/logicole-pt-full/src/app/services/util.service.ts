import {Injectable} from '@angular/core';
import {CurrencyPipe} from '@angular/common';
import {FormArray, FormControl, FormGroup, NgForm, ValidationErrors} from '@angular/forms';
import {BehaviorSubject, Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import {cloneDeep} from 'lodash';
import {FormGroupError} from '../models/form-group-error.model';

@Injectable()
export class UtilService {
  constructor(private currencyPipe: CurrencyPipe) {
  }

  public addZero(i) {
    if (i < 10) {
      i = '0' + i;
    }
    return i;
  }

  public convertCamelCaseToText(camelCaseText) {
    const result = camelCaseText.replace(/([A-Z])/g, ' $1');
    return (result.charAt(0).toUpperCase() + result.slice(1)).trim();
  }

  public convertTextToTitleCase(text) {
    return text.replace(
      /\w\S*/g,
      function(subtext) {
        return subtext.charAt(0).toUpperCase() + subtext.substr(1).toLowerCase();
      }
    );
  }

  public convertCurrencyToFloat(currency) {
    if (!currency) {
      currency = '$0.00';
    }
    return Number(currency.replace(/[^0-9\.]+/g, ''));
  }

  public convertFloatToCurrency(amount) {
    if (!amount) {
      amount = 0;
    }
    const currency = this.currencyPipe.transform(amount, 'USD');
    return currency;
  }

  public convertHashToList(hash: any, fieldName?: string): Array<any> {
    const resultList: Array<any> = [];

    for (const key in hash) {
      if (hash.hasOwnProperty(key)) {
        const value = hash[key];
        if (fieldName) {
          resultList.push(value[fieldName]);
        } else {
          resultList.push(value);
        }
      }
    }

    return resultList;
  }

  public detectIE(): number {
    const ua = window.navigator.userAgent;

    const msie = ua.indexOf('MSIE ');
    if (msie > 0) {
      // IE 10 or older => return version number
      return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
    }

    const trident = ua.indexOf('Trident/');
    if (trident > 0) {
      // IE 11 => return version number
      const rv = ua.indexOf('rv:');
      return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
    }

    const edge = ua.indexOf('Edge/');
    if (edge > 0) {
      // Edge (IE 12+) => return version number
      return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
    }

    // other browser
    return 0;
  }

  public getHeaderDivClass(isInnerComponent?: boolean): string {
    if (isInnerComponent) {
      return 'card-header lc-card-header';
    } else {
      return 'card-header bg-gradient-secondary lc-card-header text-white';
    }
  }

  public dynamicSort(property: string) {
    let sortOrder = 1;
    if (property[0] === '-') {
      sortOrder = -1;
      property = property.substr(1);
    }
    return (a, b) => {
      const result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
      return result * sortOrder;
    };
  }

  public esBuildSearchStatsStr(numResults: string, time: string) {
    const searchStatsStr: string = numResults + ' item(s) found ( ' + time + ' milliseconds )';
    return searchStatsStr;
  }

  /**
   * Escape special characters that might be embedded in the user-input search string(s)
   * not doing this causes issues for elasticsearch
   */
  public esEscapeSpecialChars(searchInput: string) {
    const escapedInput: string = searchInput.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, '\\$&');
    return escapedInput;
  }

  public getDate(d: Date) {
    const yr = d.getFullYear();
    const mn = this.addZero(d.getMonth());
    const dy = this.addZero(d.getDay());
    return yr + '-' + mn + '-' + dy;
  }

  public getDateTime(dateVar) {
    let d = new Date();
    if (dateVar) {
      d = dateVar;
    }
    const nowDateStr = this.getDate(d);
    const nowTimeStr = this.getTime(d);
    const currFullStr = nowDateStr + ' ' + nowTimeStr;
    return currFullStr;
  }

  public getFutureDate(addYears: number, addMonths: number, addDays: number) {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();
    const day = today.getDate();
    return new Date(year + addYears, month + addMonths, day + addDays);
  }

  public isFutureDate(date: Date): boolean {
    if (date) {
      return new Date(date).getTime() > new Date().getTime();
    }
    return false;
  }

  public getFiscalYear(dateValue: Date = new Date()): number {
    if (dateValue.getMonth() >= 9) {
      return dateValue.getFullYear() + 1;
    }
    return dateValue.getFullYear();
  }

  public formatDatetimeDuration(milliseconds: number): string {
    let duration: string = '';
    if (!isNaN(milliseconds)) {
      const diffDays = Math.floor(milliseconds / 86400000); // days
      const diffHours = Math.floor((milliseconds % 86400000) / 3600000); // hours
      const diffMinutes = Math.round(((milliseconds % 86400000) % 3600000) / 60000); // minutes
      duration = diffDays + ' day' + (diffDays !== 1 ? 's' : '') + ', ' + diffHours + ' hour' + (diffHours !== 1 ? 's' : '') + ', ' + diffMinutes + ' minute' + (diffMinutes !== 1 ? 's' : '');
    }
    return duration;
  }

  public calculateDatetimeDuration(startDate: Date, endDate: Date): number {
    let milliseconds: number = 0;
    if (!this.isNullOrEmpty(startDate) && !this.isNullOrEmpty(endDate)) {
      const startDateTimeToDate: Date = new Date(startDate);
      const endDateTimeToDate: Date = new Date(endDate);
      // this feels a little hacky, but the utilService.isValidDate method didn't catch all invalid dates.
      if (startDateTimeToDate.toString() !== 'Invalid Date' && endDateTimeToDate.toString() !== 'Invalid Date') {
        milliseconds = (endDateTimeToDate.getTime() - startDateTimeToDate.getTime()); // milliseconds
      }
    }
    return milliseconds;
  }

  public getHashLength(hash) {
    return Object.keys(hash).length;
  }

  public getTime(d) {
    const h = this.addZero(d.getHours());
    const m = this.addZero(d.getMinutes());
    const s = this.addZero(d.getSeconds());
    const ms = d.getMilliseconds();
    return h + ':' + m + ':' + s + '.' + ms;
  }

  public isStringFound(searchFor, searchWithin) {
    let isFound = false;
    if (searchWithin.indexOf(searchFor) > -1) {
      isFound = true;
    }
    return isFound;
  }

  public isObjectEmpty(obj: any) {
    let isEmpty = false;
    if (null === obj || '' === obj || this.getHashLength(obj) === 0) {
      isEmpty = true;
    }
    return isEmpty;
  }

  public sortResults(jList, prop, isAsc) {
    const jListSorted = jList.sort((a, b) => {
      if (isAsc) {
        return (a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
      } else {
        return (b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);
      }
    });
    return jListSorted;
  }

  public isAlphaNumeric(textToValidate: string){
    const alphaNumericRegex = /^[A-Za-z0-9]+$/;
    return alphaNumericRegex.test(textToValidate);
  }

  public isNullOrEmpty(obj: any): boolean {
    let isNullOrEmpty: boolean = false;
    if ((obj === null) || (typeof (obj) === 'undefined')) {
      isNullOrEmpty = true;
    } else if ((typeof (obj) === 'string') && (obj.trim() === '')) {
      isNullOrEmpty = true;
    }
    return isNullOrEmpty;
  }

  public isArrayNullOrEmpty(arr: Array<any>): boolean {
    let isArrayNullOrEmpty: boolean = false;
    if ((arr === null) || (arr === undefined) || (arr.length === 0)) {
      isArrayNullOrEmpty = true;
    }
    return isArrayNullOrEmpty;
  }

  public isStringNullOrEmpty(str: string): boolean {
    let isStringNullOrEmpty: boolean = false;
    if (str === null || str === undefined) {
      isStringNullOrEmpty = true;
    } else if (typeof (str) === 'string' && str.trim() === '') {
      isStringNullOrEmpty = true;
    }
    return isStringNullOrEmpty;
  }

  public isNullOrUndefined(obj: any): boolean {
    let isNullOrUndefined: boolean = false;
    if ((obj === null) || (typeof (obj) === 'undefined')) {
      isNullOrUndefined = true;
    }
    return isNullOrUndefined;
  }

  public listContainsString(stringList: Array<string>, stringToCheck: string): boolean {
    let listContainsString: boolean;
    let strIndex: number;
    strIndex = stringList.indexOf(stringToCheck);
    listContainsString = (strIndex !== -1);
    return listContainsString;
  }

  public listContainsSomeOfString(stringList: Array<string>, stringToCheck: string): boolean {
    let doesListContainsString: boolean = false;
    const found = stringList.find(v => v.includes(stringToCheck));
    if(found){
      doesListContainsString = true;
    }
    return doesListContainsString;
  }

  public listContainsNumber(stringList: Array<number>, numberToCheck: number): boolean {
    let listContainsNumber: boolean;
    let strIndex: number;
    strIndex = stringList.indexOf(numberToCheck);
    listContainsNumber = (strIndex !== -1);
    return listContainsNumber;
  }

  public doesArrayContainString(searchString: string, sourceArray: string[]): boolean {
    let hasElement: boolean = false;
    if (sourceArray.indexOf(searchString) > -1) {
      hasElement = true;
    }
    return hasElement;
  }

  public findTheNthOccurrenceInString(sourceString: string, pattern: string, occurrence: number): number {
    const location = sourceString.length;
    let pos = -1;
    while (occurrence-- && pos++ < location) {
      pos = sourceString.indexOf(pattern, pos);
      if (pos < 0) {
        break;
      }
    }
    return pos;
  }

  public formatValueDashValue(valueOne, valueTwo): string {
    let returnValue = '';
    let valueOneExists: boolean = false;
    let valueTwoExists: boolean = false;
    if (!this.isNullOrEmpty(valueOne)) {
      valueOneExists = true;
    }
    if (!this.isNullOrEmpty(valueTwo)) {
      valueTwoExists = true;
    }
    if (valueOneExists && valueTwoExists) {
      returnValue = valueOne + ' - ' + valueTwo;
    } else if (valueOneExists) {
      returnValue = valueOne;
    } else if (valueTwoExists) {
      returnValue = valueTwo;
    } else {
      returnValue = '';
    }
    return returnValue;
  }

  public randomStringGenerator(length: number, includeNumbers: boolean) {
    let text = '';
    let possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const possibleWithoutNumber = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

    if(!includeNumbers){
      possible = possibleWithoutNumber;
    }

    for(let i = 0; i < length; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
  }

  public replacePeriodsWithSlashes(sourceString: string): string {
    return sourceString.toString().replace(/\./g, '/');
  }

  public removeSubstring(sourceString: string, subString: string): string {
    return sourceString.toString().replace(subString, '');
  }

  public sortByName(arrayOfObjects, nameToCompare) {
    if (arrayOfObjects && arrayOfObjects.length > 0 && nameToCompare) {
      return arrayOfObjects.sort((a, b) => {
        const lowerA = a[nameToCompare].toLocaleLowerCase();
        const lowerB = b[nameToCompare].toLocaleLowerCase();
        if (lowerA < lowerB) {
          return -1;
        } else if (lowerA > lowerB) {
          return 1;
        } else {
          return 0;
        }
      });
    } else {
      return arrayOfObjects;
    }
  }

  public formatDate(date: Date): string {
    const utilDate = new Date(date);
    const padChar = '0';
    if (utilDate) {
      const nDay = utilDate.getDate();
      const day = this.leftPad(nDay, padChar);
      const month = utilDate.toLocaleString('en-us', {month: 'short'});
      const year = utilDate.getFullYear();

      // return day + ' ' + month + ' ' + year;
      return year + ' ' + month + ' ' + day;
    } else {
      return '';
    }
  }

  public formatDatePretty(date: Date): string {
    const utilDate = new Date(date);
    const padChar = '0';
    if (utilDate) {
      const nDay = utilDate.getDate();
      const day = this.leftPad(nDay, padChar);
      const month = utilDate.toLocaleString('en-us', {month: 'short'});
      const year = utilDate.getFullYear();
      return month + ' ' + day + ', ' + year;
    } else {
      return '';
    }
  }

  // formatDateToCompare() Used to format date for comparison. Not recommended to be used for display purpose.
  public formatDateToCompare(date: Date): string {
    const utilDate = new Date(date);
    const padChar = '0';
    if (utilDate) {
      const year = utilDate.getFullYear();
      const month = this.leftPad(utilDate.getMonth() + 1, padChar);
      const day = this.leftPad(utilDate.getDate(), padChar);
      const hours = this.leftPad(utilDate.getHours(), padChar);
      const minutes = this.leftPad(utilDate.getMinutes(), padChar);
      const seconds = this.leftPad(utilDate.getSeconds(), padChar);

      // return yyyyMMddHHmmss (example: 20190619132031)
      return year + month + day + hours + minutes + seconds;
    } else {
      return '';
    }
  }

  public convertToPaddedString(value: number, length: number, padChar: string) {
    const fullPad = this.constructPad(length, padChar);
    return String(fullPad + value).slice((length * -1));
  }

  private constructPad(length: number, padChar: string) {
    let result = '';
    for (let i = 0; i < length; i++) {
      result += padChar;
    }
    return result;
  }

  private leftPad(value: number, padChar): string {
    if (value < 10) {
      return padChar + value;
    } else {
      return value.toString();
    }
  }

  // Pass in an object that you want to deep copy, meaning the copy is completely separate from the original
  // and updating values in the copy does not update values in the original object
  public deepCopy(obj: any): any {
    return cloneDeep(obj);
  }

  // Pass in a form and it will return the first validation error from the form. If the form is valid, it will return null.
  public getFormValidationError(form: NgForm, asHTML: boolean = true): string {
    return this.formatErrorMessages(this.getValidationError(form.form), asHTML);
  }

  public getFormGroupValidationError(formGroup: FormGroup, asHTML: boolean = true): string{
    return this.formatErrorMessages(this.getValidationError(formGroup), asHTML);
  }

  public formatErrorMessages(errorMessages: string[], asHTML: boolean = true): string {
    if (!asHTML) {
      return errorMessages.length > 0 ? errorMessages.toString() : null;
    }

    const messages = errorMessages
      // remove '<ul><li>' from nested FormGroups
      .map(errorMessage => errorMessage.replace('<ul><li>', '').replace('</li></ul>', ''))
      .map(errorMessage => `<li>${errorMessage}</li>`);

    return messages.length > 0 ? `<ul>${messages.join('')}</ul>` : null;  // remove unwanted "," with join
  }

  private getValidationError(formGroup: FormGroup): string[] {
    const errorMessages: string[] = [];
    this.getValidationErrorArray(formGroup).forEach(formGroupError => {
      errorMessages.push(formGroupError.errorMessage);
    });
    return errorMessages;
  }

  public getValidationErrorArray(formGroup: FormGroup, formErrors?: FormGroupError[]): FormGroupError[] {
    const formControls = formGroup.controls;
    let validationError: ValidationErrors = null;
    const errorMessages: FormGroupError[] = (formErrors) ? formErrors : [];

    if (formControls != null) {
      for (const key in formControls) {
        if (formControls.hasOwnProperty(key)) {
          const control = formControls[key];
          control.markAsTouched();

          if (control instanceof FormControl && control.errors != null) {
            validationError = control.errors;
            // There may be many validations, loop thru each one and find the one that has the property 'errorMsg'
            for (const validationKey of Object.keys(validationError)) {
              if (validationKey === 'required') {
                continue;
              }
              const errorMsg = validationError[validationKey].errorMsg;
              if (errorMsg) {
                errorMessages.push({
                  controlName: key,
                  errorMessage: errorMsg
                });
              }
            }
          }

          // Also check for FormGroup
          if (control instanceof FormGroup && control.invalid) {
            if (control.errors && control.errors.errorMsg) {
              errorMessages.push({
                controlName: key,
                errorMessage: control.errors.errorMsg,
              });
            }
            return this.getValidationErrorArray(control, errorMessages);
          }

          // Also check for FormArray -> FormGroups
          if (control instanceof FormArray && control.invalid) {
            control.controls.forEach(formArrayControl => {
              if (formArrayControl instanceof FormGroup && formArrayControl.invalid) {
                // Pass in the errorMessages, if not, when rewinding the stack the errors get cleared.
                return this.getValidationErrorArray(formArrayControl, errorMessages);
              }
            });
          }
        }
      }
    }
    return errorMessages;
  }

  public convertListToCsv(valuesList: Array<any>): string {
    let valuesString: string = '';
    const size = valuesList.length;
    let index = 0;
    valuesList.forEach((t) => {
      const addComma: boolean = index < (size - 1);
      const tValue = addComma ? t + ',' : t;
      valuesString = valuesString.concat(tValue);
      index++;
    });

    return valuesString;
  }

  public convertStringToInteger(value: string) {
    return parseInt(value, 10);
  }

  public isValidDate(date: any): boolean {
    return date instanceof Date && !isNaN(new Date(date).getTime());
  }

  public defaultIfNullOrUndefined<T>(value: T, defaultValue: T): T {
    if (value === undefined || value === null) {
      return defaultValue;
    }

    return value;
  }

  public getActiveFormatted(isActive: boolean): string {
    return (isActive ? 'Active' : 'Inactive');
  }

  public subscribeToRefresh(
    destroy$: Subject<boolean>,
    refresh$: BehaviorSubject<boolean>,
    callback: () => void
  ) {
    refresh$
      .pipe(
        takeUntil(destroy$)
      )
      .subscribe((value) => {
        if (value && callback) {
          callback();
          refresh$.next(false);
        }
      });
  }

  // Return a regex where you specify how many digits to allow before the decimal point, and after the decimal point
  // if allowZeroValue is true, then zero is a valid entry, otherwise it is not
  // null is valid if the input is not required
  public getDecimalRegex(maxDigitsBeforeDecimalPoint: number, maxDigitsAfterDecimalPoint: number, allowZeroValue?: boolean): string | RegExp {
    const allowDigitStart: number = allowZeroValue ? 0 : 1;
    return '^(?=.*[' + allowDigitStart + '-9])\\d{0,' + maxDigitsBeforeDecimalPoint + '}(?:\\.\\d{0,' + maxDigitsAfterDecimalPoint + '})?$';
  }

  public setTimeToZero(dateValue: Date): void {
    dateValue.setHours(0, 0, 0, 0);
  }

  public isDateOrderCorrect(startDate: Date, endDate: Date): boolean {
    let retVal = false;
    if (startDate != null && endDate == null) {
      retVal = true;
    } else if (startDate != null && endDate != null) {
      const startDateForCompare = new Date(startDate);
      const endDateForCompare = new Date(endDate);
      if (startDateForCompare.getTime() <= endDateForCompare.getTime()) {
        retVal = true;
      }
    }
    return retVal;
  }

  public areDatesEqual(date1: Date, date2: Date): boolean {
    let retVal = false;
    const date1ForCompare = new Date(date1);
    const date2ForCompare = new Date(date2);
    if (date1ForCompare.getTime() === date2ForCompare.getTime()) {
      retVal = true;
    }
    return retVal;
  }

  public dateIsLessThanNNDaysFromToday(date: Date, numberOfDays: number): boolean {
    let retVal = false;

    const startingDate = new Date(Number(date));
    this.setTimeToZero(startingDate);
    const futureCutoffDate = new Date();
    futureCutoffDate.setDate(new Date().getDate() + numberOfDays);
    this.setTimeToZero(futureCutoffDate);

    if (date.getTime() < futureCutoffDate.getTime()) {
      retVal = true;
    }
    return retVal;
  }

  public compareObjectsByCode(o1: any, o2: any) {
    return o1 && o2 ? o1.code === o2.code : o1 === o2;
  }

  public compareObjectsById(o1: any, o2: any): boolean {
    return o1 && o2 ? o1.id === o2.id : o1 === o2;
  }

  public compareObjectArraysById(o1: any[], o2: any[]): boolean {
    if (this.isNullOrEmpty(o1)) {
      o1 = [];
    }
    if (this.isNullOrEmpty(o2)) {
      o2 = [];
    }

    if (o1.length !== o2.length) {
      return false;
    }

    for (let i = 0; i < o1.length; i++) {
      if (o2.findIndex(o2 => o2.id === o1[i].id) < 0) {
        return false;
      }
    }

    return true;
  }

  public getPastDate(numberOfDaysToSubtract: number): Date {
    const offset = 24 * 60 * 60 * 1000 * numberOfDaysToSubtract;
    const date = new Date();
    date.setTime(date.getTime() - offset);
    return date;
  }

  public dateStringCheckAndConvert(date: any) {
    if (typeof date === 'string'){
      try {
        return new Date(date);
      } catch (err) {
        throw (err);
      }
    } else {
      return date;
    }
  }

  public getEnumKey(enumValue: number | string, enumType: any)  {
    const keys = Object.keys(enumType).filter((t) => enumType[t] === enumValue);
    return keys.length > 0 ? keys[0] : null;
  }


}
