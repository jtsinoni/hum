import {ModuleWithProviders, NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import {LoggerModule} from './logger/logger.module';
import {HttpClient} from '@angular/common/http';
import {Base64Service} from './base64.service';
import {StorageService} from './storage.service';
import {UtilService} from './util.service';
import {LoggerService} from '@lc-logger-service';
import {WindowService} from './window.service';
import {AuthenticationService} from '@lc-services/*';

@NgModule({
  imports: [
    CommonModule, LoggerModule
  ],
  declarations: []
})
export class HttpApiModule {

  public static forRoot(): ModuleWithProviders {
    return {
      ngModule: HttpApiModule,
      providers: [
        HttpClient,
        Base64Service,
        StorageService,
        UtilService,
        LoggerService,
        WindowService,
        AuthenticationService
      ]
    };
  }

}
