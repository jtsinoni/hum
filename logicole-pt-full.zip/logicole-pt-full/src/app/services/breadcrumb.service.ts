import {Injectable, Optional, SkipSelf} from '@angular/core';
import {Ng2StateDeclaration} from '@uirouter/angular';
import {CheckMultipleGuard} from '@lc-guards/*';
import {LoggerService} from './logger/logger.service';
import {RouteInfo} from '../constants/route.constants';

@Injectable()
export class BreadcrumbService extends CheckMultipleGuard<BreadcrumbService>{

  private static readonly ROUTE: string = 'route';
  private previousState: Ng2StateDeclaration;

  public breadcrumbs: Array<RouteInfo>;

  constructor(private logger: LoggerService,
              @Optional() @SkipSelf() breadcrumbService: BreadcrumbService) {
    super(breadcrumbService);
    this.logger.debug('BreadcrumbService - Started');
    this.breadcrumbs = [];
  }

  public setCurrentState(toState: Ng2StateDeclaration) {
    this.breadcrumbs = this.buildBreadcrumbs(toState);
  }

  public setPreviousState(fromState: Ng2StateDeclaration) {
    this.previousState = fromState;
  }

  public getPreviousRoute(): RouteInfo {
    if (this.previousState && this.previousState.data) {
      return this.previousState.data[BreadcrumbService.ROUTE];
    } else {
      return null;
    }
  }

  private buildBreadcrumbs(stateDeclaration: Ng2StateDeclaration): Array<RouteInfo> {
    const routeInfo: RouteInfo = stateDeclaration.data[BreadcrumbService.ROUTE];
    return this.constructBreadcrumbs(routeInfo);
  }

  private constructBreadcrumbs(routeInfo: RouteInfo, breadcrumbs: Array<RouteInfo> = []) {
    let newBreadcrumbs: Array<RouteInfo> = [];
    // if (routeInfo.parent === undefined) {
    if (routeInfo.parent === undefined || routeInfo.parent.name === 'home') {
      const rootCrumb: RouteInfo = this.createBreadcrumb(routeInfo);
      newBreadcrumbs = [...breadcrumbs, rootCrumb];
      return newBreadcrumbs.reverse();
    } else {

      const crumb: RouteInfo = this.createBreadcrumb(routeInfo, routeInfo.parent.url);
      if (crumb) {
        newBreadcrumbs = [...breadcrumbs, crumb];
      } else {
        newBreadcrumbs = [...breadcrumbs];
      }
      return this.constructBreadcrumbs(routeInfo.parent, newBreadcrumbs);
    }
  }

  private createBreadcrumb(routeInfo: RouteInfo, priorUrl?: string) {
      const breadcrumb: RouteInfo = {
        breadcrumb: routeInfo.breadcrumb,
        url: priorUrl ? priorUrl + routeInfo.url : routeInfo.url,
        name: routeInfo.name,
        parent: routeInfo.parent
      };
      return breadcrumb;
    }

}
