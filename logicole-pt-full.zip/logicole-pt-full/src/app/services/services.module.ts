import {ModuleWithProviders, NgModule} from '@angular/core';
import {Base64Service} from './base64.service';
import {LoggerModule} from './logger/logger.module';
import {UtilService} from './util.service';
import {PermissionService} from './permission.service';
import {StorageService} from './storage.service';
import {WindowService} from './window.service';
import {AuthenticationService, LoggerService, LoginService, MainNavService, NotificationService, ProfileApiService, ProfileService, StateNavigationService} from '@lc-services/*';
import {CurrencyPipe, DatePipe} from '@angular/common';
import {SidePanelService} from './side-panel.service';
import {BreadcrumbService} from './breadcrumb.service';
import {LoaderService} from './loader.service';
import {HTTP_INTERCEPTORS} from '@angular/common/http';
import {InterceptorService} from './interceptor.service';
import {BusinessIntelligenceService} from './business-intelligence.service';
import {BusinessIntelligenceApiService} from './business-intelligence-api.service';
import {ApplicationNotificationApiService} from './application-notification-api.service';
import {ApplicationNotificationService} from './application-notification-service';
import {SearchUtilityService} from './search-utility.service';
import {FloorPlanApiService} from './floor-plan-api.service';
import {DrawingLookupApiService} from './drawing-lookup-api.service';
import {WorkflowService} from './workflow.service';
import {SsoSapTewlsApiService} from './sso-sap-tewls-api.service';
import {SsoJmarService} from './sso-jmar.service';
import {SsoJmarApiService} from './sso-jmar-api.service';

@NgModule({
  imports: [LoggerModule],
})
export class ServicesModule {

  public static forRoot(): ModuleWithProviders<ServicesModule> {
    return {
      ngModule: ServicesModule,
      providers: [
        Base64Service,
        BusinessIntelligenceApiService,
        BusinessIntelligenceService,
        BreadcrumbService,
        DatePipe,
        DrawingLookupApiService,
        LoginService,
        PermissionService,
        StorageService,
        UtilService,
        LoggerService,
        WindowService,
        AuthenticationService,
        CurrencyPipe,
        ProfileApiService,
        ProfileService,
        NotificationService,
        SidePanelService,
        StateNavigationService,
        MainNavService,
        LoaderService,
        InterceptorService,
        ApplicationNotificationApiService,
        ApplicationNotificationService,
        SearchUtilityService,
        SsoSapTewlsApiService,
        SsoJmarService,
        SsoJmarApiService,
        FloorPlanApiService,
        WorkflowService,
        {
          provide: HTTP_INTERCEPTORS,
          useClass: InterceptorService,
          multi: true
        }
      ]
    };
  }
}
