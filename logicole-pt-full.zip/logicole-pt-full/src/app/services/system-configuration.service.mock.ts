import {Configuration, ConfigurationCollection} from '@lc-app-models';
import {of} from 'rxjs';

export class SystemConfigurationServiceMock {

  public getAllConfigurations() {
    const config = new ConfigurationCollection();
    return of([config]);
  }

}
