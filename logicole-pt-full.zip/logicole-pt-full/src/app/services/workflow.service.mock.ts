import {Observable, of, Subject} from 'rxjs';
import {WorkflowItem} from '../common-components/lc-workflow/models/workflow-item';
import {WorkflowState} from '../common-components/lc-workflow/models/workflow-state.model';
import {WorkflowApiService} from '../common-components/lc-workflow/models/workflow-api.service';
import {WorkflowStepSummary} from '../common-components/lc-workflow/models/workflow-step-summary.model';
import {WorkflowAction} from '../common-components/lc-workflow/models/workflow-action.model';

export class WorkflowServiceMock {
  public workflowItem: WorkflowItem = {
    getWorkflowState(): WorkflowState {
      return new WorkflowState();
    }
  };
  public workflowState: WorkflowState;
  public workflowItemName: string;
  public $update: Subject<void> = new Subject<void>();
  public onUpdate: Observable<void> = this.$update.asObservable();

  public $actionError: Subject<string> = new Subject<string>();
  public onError: Observable<string> = this.$actionError.asObservable();
  public $actionSuccess: Subject<WorkflowItem> = new Subject<WorkflowItem>();
  public onSuccess: Observable<WorkflowItem> = this.$actionSuccess.asObservable();
  public workflowApiService: WorkflowApiService;
  public workflowSteps: WorkflowStepSummary[] = [];
  public currentStep: WorkflowStepSummary;
  public currentStepPosition: number;
  public $refreshWorkflowActions: Subject<WorkflowAction> = new Subject<WorkflowAction>();

  public getStepMessage(position: number, workflowStep: WorkflowStepSummary): string {
    return '';
  }

  public isApprovedLastStep(): boolean {
    return false;
  }

  public getStepStatusClass(position: number, workflowStepSummary: WorkflowStepSummary): string {
    return '';
  }

  public getStatus(): string {
    return '';
  }

  public performAction(action: WorkflowAction, hideMessage?: boolean): Observable<WorkflowItem> {
    return of();
  }

  public buildWorkflowStepSummary(): Observable<WorkflowStepSummary[]> {
    return of();
  }
}
