import { Injectable } from '@angular/core';
import {ApiService} from './api.service';
import {LoggerService} from '@lc-logger-service';
import {HttpClient} from '@angular/common/http';
import {AuthenticationService} from '@lc-services/*';
import {LoaderService} from './loader.service';
import {ApiConstants} from '@lc-constants/*';
import {VersionInformation} from '../home/home-components/models/version-information';
import {Observable} from 'rxjs';
import {ApplicationNotification} from '../home/jmlfdc-admin/system-notification/models/application-notification';

@Injectable()
export class ApplicationNotificationApiService extends ApiService {

  private serviceName: string = 'ApplicationNotificationApiService';

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
    super(ApiConstants.APPLICATION_NOTIFICATION_API, logger, http, authenticationService, loaderService);
    this.logger.debug(`${this.serviceName} - Start`);
  }

  public getUnreadNotificationCount(): Observable<number> {
    return this.get('getUnreadNotificationCount');
  }

  public getUnreadNotifications(): Observable<ApplicationNotification[]> {
    return this.get('getUnreadNotifications');
  }

  public markAsRead(id: string): Observable<ApplicationNotification[]> {
    return this.get('markNotificationAsRead?id=' + id);
  }

  public getAllNotifications(): Observable<ApplicationNotification[]> {
    return this.get('getAllNotifications');
  }
}
