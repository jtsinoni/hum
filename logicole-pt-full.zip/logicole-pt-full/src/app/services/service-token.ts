import {InjectionToken} from '@angular/core';

export class ServiceToken extends InjectionToken<string> {

  public getDescription() {
    return this._desc;
  }

}
