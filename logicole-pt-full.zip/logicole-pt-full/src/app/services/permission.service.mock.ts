export class PermissionServiceMock {

  constructor(
  ) { }

  private isStateFound(stateName: string, userStates: string[]): boolean {
    return true;
  }

  private isAssignedPermissionFound(elementName: string, userElements: string[]): boolean {
    return true;
  }

  public checkElements(elementName: string): boolean {
    return true;
  }

  public checkStates(stateName: string): boolean {
    return true;
  }

}
