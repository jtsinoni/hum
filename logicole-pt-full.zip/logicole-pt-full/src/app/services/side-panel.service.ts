import { Injectable } from '@angular/core';
import { WidthPaddingStyle } from '../models/width-padding-style.interface';
import { LoggerService } from './logger/logger.service';

@Injectable()
export class SidePanelService {

  private serviceName: string = 'SidePanelService';

  private closedStyle: WidthPaddingStyle = { 'width': '20px', 'padding': '5px' };
  private openStyle: WidthPaddingStyle = { 'width': '20px', 'padding': '5px' };
  private iconRightOpen: string = 'fa fa-angle-double-right';
  private iconRightClosed: string = 'fa fa-angle-double-left';
  private iconLeftOpen: string = 'fa fa-angle-double-left';
  private iconLeftClosed: string = 'fa fa-angle-double-right';

  public defaultPanelWidth: string = '25%';

  public isLeftPanelButtonShown: boolean = false;
  public isLeftPanelShown: boolean = false;
  public leftOuterStyle: any = {};
  public leftPanelIcon: string;
  public leftPanelStyle: any = {};
  public leftPanelWidthOpened: string;

  public isRightPanelButtonShown: boolean = false;
  public isRightPanelShown: boolean = false;
  public rightOuterStyle: any = {};
  public rightPanelIcon: string;
  public rightPanelStyle: any = {};
  public rightPanelWidthOpened: string;

  constructor(private logger: LoggerService) {
    this.resetLeftPanel();
    this.resetRightPanel();
  }

      private resetLeftPanel(){
        this.leftPanelIcon = this.iconLeftClosed;
        this.leftPanelWidthOpened = this.defaultPanelWidth;
        this.leftPanelStyle = this.closedStyle;  
        this.leftOuterStyle = { 'margin-left' : '5px' };
    }

    private resetRightPanel(){
        this.rightPanelIcon = this.iconRightClosed;
        this.rightPanelWidthOpened = this.defaultPanelWidth;
        this.rightPanelStyle = this.closedStyle;
        this.rightOuterStyle = { 'margin-right' : 0 };
    }

    public showLeftPanel(): void {
      this.isLeftPanelButtonShown = true;
    }

    public showRightPanel(): void {
      this.isRightPanelButtonShown = true;
    }

    public toggleLeftPanel(){
        if (this.isLeftPanelShown){
            this.logger.info(`${this.serviceName}: Toggle to closed`);
            this.leftPanelStyle = this.openStyle;
            this.leftOuterStyle = { 'margin-left' : '15px' };
            this.leftPanelIcon = this.iconLeftClosed;
        }else{
            this.logger.info(`${this.serviceName}: Toggle to open`);
            this.logger.info(`${this.serviceName}: Toggle to opened ${this.leftPanelWidthOpened}`);
            this.leftPanelStyle = { 'width' : this.leftPanelWidthOpened,
                                    'padding-left' : '10px',
                                    'padding-right' : '10px',
                                    'padding-top' : '0px',
                                    'padding-bottom' : '50px'};
            this.leftOuterStyle = { 'margin-left' : this.leftPanelWidthOpened };
            this.leftPanelIcon = this.iconLeftOpen;
        }
        this.isLeftPanelShown = !this.isLeftPanelShown;
    }

    public toggleRightPanel(){
        if (this.isRightPanelShown){
            this.logger.info(`${this.serviceName}: Toggle to closed`);
            this.rightPanelStyle = this.openStyle;
            this.rightOuterStyle = { 'margin-right' : '15px' };
            this.rightPanelIcon = this.iconRightClosed;
        }else{
            this.logger.info(`${this.serviceName}: Toggle to open`);
            this.logger.info(`${this.serviceName}: Toggle to opened ${this.rightPanelWidthOpened}`);
            this.rightPanelStyle = { 'width' : this.leftPanelWidthOpened,
                                      'padding-left' : '10px',
                                      'padding-right' : '10px',
                                      'padding-top' : '0px',
                                      'padding-bottom' : '50px'};
            this.rightOuterStyle = { 'margin-right' : this.rightPanelWidthOpened };
            this.rightPanelIcon = this.iconRightOpen;
        }
        this.isRightPanelShown = !this.isRightPanelShown;
    }

}
