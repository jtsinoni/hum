import {Observable, of} from 'rxjs';
import {Provider} from '../models/provider.model';
import {ProviderRef} from '../models/provider-ref.model';

export class ProviderApiServiceMock {

  constructor() {
  }

  public getFinancialServiceProviders(): Observable<Array<Provider>> {
    return of([]);
  }

  public getAllProviders(): Observable<Array<Provider>> {
    return of([]);
  }

  public findProviderById(providerId: string): Observable<Provider> {
    return of();
  }

  public saveProvider(provider: Provider): Observable<Provider> {
    return of();
  }

  public deleteProvider(provider: Provider) {
    return of();
  }

  public getProviderTypes(): Observable<Array<string>> {
    return of([]);
  }

  public getProvider(startOrgId: string, providerType: string): Observable<ProviderRef> {
    return of();
  }

}
