import {ApiService} from './api.service';
import {LoggerService} from '@lc-logger-service';
import {HttpClient} from '@angular/common/http';
import {AuthenticationService} from '@lc-services/*';
import {LoaderService} from './loader.service';
import {ApiConstants} from '@lc-constants/*';
import {VersionInformation} from '../home/home-components/models/version-information';
import {Observable} from 'rxjs';
import {Injectable} from '@angular/core';
import {DmlssFunctionRecurrenceStatus} from '../home/abi-search/models/dmlss-function-recurrence-status.model';
import {RecurringFunctionStatus} from '../home/jmlfdc-admin/dmlss-live-data-management/models/recurring-function-status.model';
import {DmlssFunction} from '../home/jmlfdc-admin/dmlss-live-data-management/models/dmlss-function.model';
import {RecurringFunction} from '../home/jmlfdc-admin/dmlss-live-data-management/models/recurring-function.model';
import {RecurringFunctionConfiguration} from '../home/jmlfdc-admin/dmlss-live-data-management/models/recurring-function-configuration.model';

@Injectable({
  providedIn: 'root'
})
export class SystemRecurringFunctionApiService extends ApiService {

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
    super(ApiConstants.SYSTEM_RECURRING_FUNCTION_API, logger, http, authenticationService, loaderService);
  }

  public ensureRecurrenceHealth(): Observable<void>{
    return this.get('ensureRecurrenceHealth');
  }

  // ****************************************************** //
  // Configuration Settings
  // ****************************************************** //

  public setIsEnabled(recurringFunctionId: String, isEnabled: boolean): Observable<RecurringFunctionConfiguration>{
    return this.get('setIsEnabled?recurringFunctionId=' + recurringFunctionId + '&isEnabled=' + isEnabled);
  }

  public setFrequency(recurringFunctionId: String, frequency: number): Observable<RecurringFunctionConfiguration>{
    return this.get('setFrequency?recurringFunctionId=' + recurringFunctionId + '&frequency=' + frequency);
  }

  public setTimeout(recurringFunctionId: String, timeout: number): Observable<RecurringFunctionConfiguration>{
    return this.get('setTimeout?recurringFunctionId=' + recurringFunctionId + '&timeout=' + timeout);
  }

  public setUseMock(recurringFunctionId: String, useMock: boolean): Observable<RecurringFunctionConfiguration>{
    return this.get('setUseMock?recurringFunctionId=' + recurringFunctionId + '&useMock=' + useMock);
  }

  public setMockDuration(recurringFunctionId: String, mockDuration: number): Observable<RecurringFunctionConfiguration>{
    return this.get('setMockDuration?recurringFunctionId=' + recurringFunctionId + '&mockDuration=' + mockDuration);
  }

  // ****************************************************** //
  // Recurrence
  // ****************************************************** //


  public startRecurrence(recurringFunctionId: String): Observable<RecurringFunctionStatus>{
    return this.get('startRecurrence?recurringFunctionId=' + recurringFunctionId);
  }

  public stopRecurrence(recurringFunctionId: String): Observable<RecurringFunctionStatus>{
    return this.get('stopRecurrence?recurringFunctionId=' + recurringFunctionId);
  }

  // endregion


  public getAllRecurringFunctions(): Observable<Array<RecurringFunction>> {
    return this.get('getAllRecurringFunctions');
  }

  public executeRecurringFunction(recurringFunctionId: String): Observable<string> {
    return this.get('executeRecurringFunction?recurringFunctionId=' + recurringFunctionId);
  }



}
