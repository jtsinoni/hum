import { Injectable } from '@angular/core';
import {LoggerService} from './logger/logger.service';

declare var window: any;

@Injectable()
export class WindowService {
  private serviceName = 'WindowService';
  public window = window;
  constructor(private logger: LoggerService) {
    this.logger.debug(`${this.serviceName} - Start`);
  }

  public shiftKeySelected(): boolean {
     return this.window.event.shiftKey;
  }

  public ctrlKeySelected(): boolean {
    return this.window.event.ctrlKey;
  }

  public ctrlAndOrShiftKeysSelected(): boolean {
    return ((this.window.event.ctrlKey && this.window.event.shiftKey) || (this.window.event.shiftKey));
  }

  public getDocument() {
    return this.window.document;
  }

  public getElements(name: String) {
    return this.window.document.getElementsByName(name);
  }

  public getElementsByClassName(name: String) {
    return this.window.document.getElementsByClassName(name);
  }

  public getElementsByIdPrefix(prefix: String) {
    return this.window.document.querySelectorAll(`*[id^="${prefix}"]`);
  }

  public back() {
    this.window.history.back();
  }

  public scrollToTop() {
    this.window.scrollTo(0, 0);
  }

  public open(url) {
    this.window.open((url));
  }

  public isTouchScreenDevice(): boolean {
    return ('ontouchstart' in this.window) || (navigator.maxTouchPoints > 0);
  }
}
