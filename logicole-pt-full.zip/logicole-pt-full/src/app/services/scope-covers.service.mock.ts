import {Observable, of} from 'rxjs';

import {Organization, OrganizationRef} from '@lc-app-models';

export class ScopeCoversServiceMock {

  constructor() {
  }

  public getScopeCoversByOrganizationRefs(organizationTypeId: string, scopeOrganizationRefs: Array<OrganizationRef>): Observable<Array<Organization>> {
    return of([]);
  }

  public getScopeCoversByOrganizationIds(organizationTypeId: string, organizationIds: Array<string>): Observable<Array<Organization>> {
    return of([]);
  }
}
