import { Injectable } from '@angular/core';
import {LoggerService} from '@lc-logger-service';
import {HttpClient} from '@angular/common/http';
import {AuthenticationService} from '@lc-services/*';
import {LoaderService} from './loader.service';
import {ApiService} from './api.service';
import {ApiConstants} from '@lc-constants/*';
import {Observable} from 'rxjs';
import {Configuration} from '@lc-app-models';
import {ConfigurationCollection} from '../models/configuration-collection.model';

@Injectable({
  providedIn: 'root'
})
export class SystemConfigurationApiService extends ApiService{

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
    super(ApiConstants.SYSTEM_CONFIGURATION_API, logger, http, authenticationService, loaderService);

  }

  public getAllConfigurations(): Observable<ConfigurationCollection> {
    return this.get(`getAllConfigurations`);
  }

  public getMicroServiceConfigurations(): Observable<ConfigurationCollection> {
    return this.get(`getMicroServiceConfigurations`);
  }

  public getServerConfigurations(): Observable<ConfigurationCollection> {
    return this.get(`getServerConfigurations`);
  }

  public addUpdateConfiguration(configuration: Configuration): Observable<Configuration> {
    return this.post(`addUpdateConfiguration`, configuration);
  }

  public getConfiguration(id: string, owner: string): Observable<Configuration> {
    return this.get(`getConfiguration?id=${id}&${owner}`);
  }

  public getConfigurationByName(name: string, owner: string): Observable<Configuration> {
    return this.get(`getConfigurationByName?name=${name}&${owner}`);
  }


}
