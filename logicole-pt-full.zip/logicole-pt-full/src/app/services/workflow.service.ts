import {Injectable} from '@angular/core';
import {Observable, Subject} from 'rxjs';
import {tap} from 'rxjs/operators';
import {WorkflowItem} from '../common-components/lc-workflow/models/workflow-item';
import {WorkflowState} from '../common-components/lc-workflow/models/workflow-state.model';
import {WorkflowApiService} from '../common-components/lc-workflow/models/workflow-api.service';
import {WorkflowStepSummary} from '../common-components/lc-workflow/models/workflow-step-summary.model';
import {NotificationService} from './core';
import {WorkflowActionType} from '../common-components/lc-workflow/constants/workflow-action-type.enum';
import {WorkflowAction} from '../common-components/lc-workflow/models/workflow-action.model';
import {PermissionService} from './permission.service';

@Injectable({
  providedIn: 'root'
})
export class WorkflowService {
  public workflowItem: WorkflowItem;
  public workflowState: WorkflowState;
  public workflowItemName: string;

  public $actionError: Subject<string> = new Subject<string>();
  public onError: Observable<string> = this.$actionError.asObservable();
  public $actionSuccess: Subject<WorkflowItem> = new Subject<WorkflowItem>();
  public onSuccess: Observable<WorkflowItem> = this.$actionSuccess.asObservable();
  public workflowApiService: WorkflowApiService;
  public workflowSteps: WorkflowStepSummary[] = [];
  public currentStep: WorkflowStepSummary;
  public currentStepPosition: number;
  public $refreshWorkflowDependentButtons: Subject<boolean> = new Subject<boolean>();
  public $refreshWorkflowActions: Subject<WorkflowAction[]> = new Subject<WorkflowAction[]>();

  constructor(private notificationService: NotificationService,
              private permissionService: PermissionService) {
  }

  private stepInHistory(workflowStep: WorkflowStepSummary): boolean {
    return workflowStep.workflowActionName != null;
  }

  private isCurrentWorkflowStep(workflowStep: WorkflowStepSummary): boolean {
    return workflowStep.stepName === this.workflowState.currentStep.workflowStepDefinition.name;
  }

  private workflowStepInError(workflowStep: WorkflowStepSummary): boolean {
    return this.stepInHistory(workflowStep)
      && workflowStep.workflowActionType === WorkflowActionType.ERROR;
  }

  private workflowStepSuccess(position: number, workflowStep: WorkflowStepSummary): boolean {
    return this.isCurrentLastStep() || (this.stepInHistory(workflowStep)
      && position <= this.currentStepPosition
      && workflowStep.workflowActionType === WorkflowActionType.SUCCESS);
  }

  private workflowStepComplete(position: number, workflowStep: WorkflowStepSummary): boolean {
    return this.stepInHistory(workflowStep)
      && position < this.currentStepPosition
      && workflowStep.workflowActionType === WorkflowActionType.COMPLETE;
  }

  private workflowStepCancelled(position: number, workflowStep: WorkflowStepSummary): boolean {
    return this.stepInHistory(workflowStep)
      && position < this.currentStepPosition
      && workflowStep.workflowActionType === WorkflowActionType.CANCEL;
  }

  public isCurrentLastStep(): boolean {
    return this.currentStep && this.workflowState.currentStep.workflowStepDefinition.isEndOfWorkflow;
  }

  public getStepStatusClass(position: number, workflowStepSummary: WorkflowStepSummary): string {
    if (this.isCurrentWorkflowStep(workflowStepSummary) &&
      !this.isCurrentLastStep()) {
      return 'active fas fa-map-marker';
    } else if (this.workflowStepInError(workflowStepSummary)) {
      return 'red fas fa-times-circle';
    } else if (this.workflowStepSuccess(position, workflowStepSummary)) {
      return 'green fas fa-check-circle';
    } else if (this.workflowStepComplete(position, workflowStepSummary)) {
      return 'active fas fa-circle';
    } else if (this.workflowStepCancelled(position, workflowStepSummary)) {
      return 'gray fas fa-circle';
    } else {
      return 'far fa-circle';
    }
  }

  public getStatus(): string {
    return this.workflowState.currentStep.workflowStepDefinition.name;
  }

  public performAction(action: WorkflowAction, hideMessage?: boolean): Observable<WorkflowItem> {
    return this.workflowApiService.takeAction(this.workflowItem, action)
      .pipe(tap(workflowItem => {
        if (!hideMessage) {
          this.showSuccessfulActionMessage(action.message, action);
        }

        this.$actionSuccess.next(workflowItem);
      }));
  }

  private showSuccessfulActionMessage(message: string, action: WorkflowAction): void {
    const currentStep = this.workflowItem.getWorkflowState().currentStep.name;

    if (this.workflowItemName && message) {
      this.notificationService.successMsg('The ' + this.workflowItemName + ' has been successfully ' + message + '.');
    } else if (message) {
      this.notificationService.successMsg('The ' + currentStep + ' step has been ' + message + '.');
    } else {
      this.notificationService.successMsg('The ' + action.name + ' action has been taken for the ' + currentStep + ' step.');
    }
  }

  public buildWorkflowStepSummary(): Observable<WorkflowStepSummary[]> {
    this.currentStep = null;

    return this.workflowApiService.buildWorkflowStepSummary(this.workflowItem).pipe(
      tap(steps => {
        this.workflowSteps = steps;

        for (let i = 0; i < steps.length; i++) {
          const workflowStep = steps[i];

          if (workflowStep.isCurrentStep) {
            this.currentStep = workflowStep;
            this.currentStepPosition = i;
          }
        }

        if (!this.currentStep) {
          this.currentStepPosition = steps.length;
        } else {
          for (const action of this.currentStep.stepActions) {
            action.isAllowed = this.permissionService.checkElements(action.element);
          }
        }
      }),
      tap(() => this.$refreshWorkflowDependentButtons.next(true)),
      tap(() => {
        if (this.currentStep) {
          this.$refreshWorkflowActions.next(this.currentStep.stepActions);
        }
      }),
    );
  }
}
