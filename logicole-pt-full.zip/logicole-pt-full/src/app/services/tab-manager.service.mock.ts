import {Injectable} from '@angular/core';
import {TabGroup} from './tab-manager.service';

@Injectable()
export class TabManagerServiceMock {
  public getTabGroup(tabGroupName: string): TabGroup {
    return {} as TabGroup;
  }
  public setSelectedTab(tabGroupName: string, tabName: string) { }
  public setTabGroupToDefaults(tabGroupName: string) { }
}
