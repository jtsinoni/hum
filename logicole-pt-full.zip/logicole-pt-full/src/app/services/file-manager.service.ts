import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { HttpClient } from '@angular/common/http';
import { ApiConstants } from '@lc-constants/*';
import { AuthenticationService, LoggerService } from '@lc-services/*';
import { LoaderService } from './loader.service';
import { AppConfigService } from './app-config.service';
import { UtilService } from './util.service';

@Injectable(
    { providedIn: 'root' }
)
export class FileManagerService extends ApiService {
    private serviceName: string = 'FileManagerService';

    public file: any;
    public fileURL: any;
    public embedContentToDisplay: any;
    public embedContentToDisplayFileName: string;
    public lastSearchFilter: String = null;
    public forbiddenFileExtensions: string[] = [];

    constructor(http: HttpClient, logger: LoggerService, authenticationService: AuthenticationService,
        protected loaderService: LoaderService, private utilService: UtilService) {
        super(ApiConstants.FILE_MANAGER_API, logger, http, authenticationService, loaderService);
        this.logger.debug(`${this.serviceName} - Start`);
        this.getForbiddenFileExtensions();
    }

    public download(fileId: string) {
        this.logger.debug(`${this.serviceName} - Calling getImage(${fileId}) REST service.`);
        const query = 'download?fileId=' + fileId;
        return this.getArrayBuffer(query);
    }

    public base64Download(fileId: string) {
        this.logger.debug(`${this.serviceName} - Calling base64Download(${fileId}) REST service.`);
        const query = 'base64Download?fileId=' + fileId;
        return this.getText(query);
    }

    public getFileInfo(fileId: string) {
        this.logger.debug(`${this.serviceName} - Calling getFileInfo(${fileId}) REST service.`);
        const query = 'getFileInfo?fileId=' + fileId;
        return this.get(query);
    }

    public getUploadConfiguration() {
        this.logger.debug(`${this.serviceName} - called getUploadConfigurations) API.`);
        const uploadUrl: string = AppConfigService.settings.baseApiUrl + ApiConstants.FILE_MANAGER_API + 'uploadManaged';

        return {
            url: uploadUrl,
            headers: {
                'authorization': 'Token ' + this.authenticationService.getToken(),
                'ClientId': 'dmles',
            }
        };
    }

    public getMaxPostSize() {
        this.logger.debug(`${this.serviceName} - called getMaxPostSize) API.`);
        const query = 'getMaxPostSize';
        return this.get(query);
    }

    public getForbiddenFileExtensions() {
        this.logger.debug(`${this.serviceName} - called getForbiddenFileExtensions) API.`);
        const query = 'getForbiddenFileExtensions';
        this.get(query).subscribe(result => {
            this.forbiddenFileExtensions = result;
        });
    }

    public formatBytes(bytes, decimals = 2) {
        if (bytes === 0) { return '0 Bytes'; }

        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    public removeFile(fileId: string) {
        this.logger.debug(`${this.serviceName} - called removeFile(${fileId}) API.`);
        const query = 'removeFile?fileId=' + fileId;
        return this.get(query);
    }

    public removeFileUnmanaged(fileId: string) {
      this.logger.debug(`${this.serviceName} - called removeFileUnmanaged(${fileId}) API.`);
      const query = 'removeFileUnmanaged?fileId=' + fileId;
      return this.get(query);
    }

    public verifyFile(fileName: string) {
      let forbiddenFound = false;
      for (let i = 0; i < this.forbiddenFileExtensions.length; i++) {
        if (fileName.indexOf(this.forbiddenFileExtensions[i]) !== -1){
          forbiddenFound = true;
          break;
        }
      }
      return forbiddenFound;
    }

    public retrieveFileId(input: string): string {
      let fileId = '';
      if (this.utilService.isNullOrEmpty(input) && typeof input === 'string' && input.substr(0, 4) === 'http') {
        // input is a URL
        const fileIdPos = input.lastIndexOf('fileId=');
        if (fileIdPos >= 0) {
          fileId = input.substring(fileIdPos + 7);
        }
      } else {
        fileId = input;
      }
      return fileId;
    }

}
