import {Observable, of} from 'rxjs';
import {HttpHeaders} from '@angular/common/http';
import {AppConfigService} from './app-config.service';
import {ServiceToken} from './service-token';

export class ApiServiceMock {
  private methodPath: ServiceToken;

  constructor() {
  }

  protected determineUrl(action: string) {
    return AppConfigService.settings.baseApiUrl + this.methodPath.getDescription() + action;
  }

  public getArrayBuffer(action: string): Observable<any> {
    return of();
  }

  public getText(action: string): Observable<any> {
    return of();
  }

  public get(action: string, callerHandlesError?: boolean): Observable<any> {
    return of();
  }

  public post(action: string, data: any, callerHandlesError?: boolean): Observable<any> {
    return of();
  }

  protected getHeader(verb: string): HttpHeaders {
    const headers: HttpHeaders = new HttpHeaders({
      'ClientId': 'dmles'
    });
    return headers;
  }
}
