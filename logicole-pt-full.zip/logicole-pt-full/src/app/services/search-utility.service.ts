import {Injectable} from '@angular/core';
import {Aggregation} from '../models/aggregation.model';
import {AggregationElasticsearch} from '../models/aggregation-elasticsearch.model';
import {AggregationElasticsearchBucket} from '../models/aggregation-elasticsearch-bucket.model';
import {SearchCriterion} from '../models/search-criterion.model';
import {SearchCategoryModel} from '../models/search-category.model';
import {WorkOrder} from '../home/work-orders/models/work-order.model';
import {SearchCategoryItemModel} from '../models/search-category-item.model';

@Injectable()
export class SearchUtilityService {

  constructor() {
  }

  public convertAggregationsInBtResponseToLcSearchFiltersFormat(aggregations): AggregationElasticsearch[] {
    const aggregationsElasticsearch: AggregationElasticsearch[] = [];
    for (let i = 0; i < aggregations.length; i++) {
      const aggregationName = aggregations[i].name;
      aggregationsElasticsearch[aggregationName] = this.convertAggregationToLcSearchFiltersFormat(aggregations[i].values);
    }
    return aggregationsElasticsearch;
  }

  public convertAggregationToLcSearchFiltersFormat(aggregations: Array<Aggregation>): AggregationElasticsearch {

    // convert the aggregations in the BT response to the format used by lc-search-filters (which is ElasticSearch oriented)
    const aggregationInLcSearchFiltersFormat: AggregationElasticsearch = new AggregationElasticsearch();
    aggregationInLcSearchFiltersFormat.doc_count_error_upper_bound = 0;
    aggregationInLcSearchFiltersFormat.sum_other_doc_count = 0;
    if (aggregations) {
      for (let i = 0; i < aggregations.length; i++) {
        const bucket: AggregationElasticsearchBucket = new AggregationElasticsearchBucket();
        bucket.key = (aggregations[i].value === null ? '' : aggregations[i].value);
        bucket.doc_count = aggregations[i].count;
        aggregationInLcSearchFiltersFormat.buckets.push(bucket);
      }
    }
    return aggregationInLcSearchFiltersFormat;
  }

  public convertLcSearchFiltersToNewFilterFormat(lcSearchFilters): SearchCriterion[] {
    const convertedFilters: SearchCriterion[] = [];

    // reformat the lc-search-filters output to the filter format of the new BT search API
    if (lcSearchFilters.length > 0) {
      for (let i = 0; i < lcSearchFilters.length; i++) {
        if (lcSearchFilters[i].operator === 'or') { // facet filter
          let propertyName: string = '';
          const propertyValues: string[] = [];
          for (let j = 0; j < lcSearchFilters[i].fieldValues.length; j++) {
            const field: string = lcSearchFilters[i].fieldValues[j].field;
            const value: string = lcSearchFilters[i].fieldValues[j].value;
            propertyName = field;
            propertyValues.push(value);
          }
          const searchCriterion: SearchCriterion = {
            propName: propertyName,
            propValues: propertyValues,
            method: 'in'
          };
          convertedFilters.push(searchCriterion);
        } else if (lcSearchFilters[i].operator === 'and') { // browse category filter
          let propertyName: string = '';
          const propertyValues: string[] = [];
          for (let j = 0; j < lcSearchFilters[i].fieldValues.length; j++) {
            const field: string = lcSearchFilters[i].fieldValues[j].field;
            const value: string = lcSearchFilters[i].fieldValues[j].value;
            propertyName = field;
            propertyValues.push(value);
            const searchCriterion: SearchCriterion = {
              propName: propertyName,
              propValues: propertyValues,
              method: 'in'
            };
            convertedFilters.push(searchCriterion);
          }
        }
      }
    }
    return convertedFilters;
  }

  public collapseFacet(aggregations: SearchCategoryModel<any>[], aggregationName: string, values: string[], newValue: string) {
    const i: number = aggregations.findIndex(aggregation => aggregation.name === aggregationName);
    if (i >= 0 && aggregations[i].values.length > 0) {
      const items: SearchCategoryItemModel<any>[] = aggregations[i].values.filter(item => values.includes(item.value?.toString() || ''));
      if (items.length > 0) {
        const newCount = items.reduce((previousValue, currentValue) => previousValue + currentValue.count, 0);
        const combinedItem: SearchCategoryItemModel<any> = new SearchCategoryItemModel<any>({
          value: newValue,
          count: newCount
        });
        aggregations[i].values = aggregations[i].values.filter( item => !values.includes(item.value?.toString() || ''));
        aggregations[i].values.push(combinedItem);
      }
    }
  }

  public expandFacet(searchCriterion: SearchCriterion[], aggregationName: string, newValues: string[], method?: string) {
    const i: number = searchCriterion.findIndex(criterion => criterion.propName === aggregationName && (!method || criterion.method === method));
    if (i >= 0) {
      const propValues: string[] = [];
      searchCriterion[i].propValues.forEach(item => {
        propValues.push(item.toString());
      });
      if (propValues.findIndex(item => newValues.includes(item.toString())) >= 0) {
        newValues.forEach(value => {
          if (propValues.findIndex(item => item === value) < 0) {
            propValues.push(value);
          }
        });
        searchCriterion[i].propValues = propValues;
      }
    }
  }
}
