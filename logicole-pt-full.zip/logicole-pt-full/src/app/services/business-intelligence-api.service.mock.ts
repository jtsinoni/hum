import {Observable, of} from 'rxjs';

export class BusinessIntelligenceApiServiceMock {

  constructor() {
  }

  public getJmarToken(): Observable<string> {
    return of('jmarToken');
  }

  public getBcsToken(): Observable<string> {
    return of('bcsToken');
  }

  public getBcsSsoEnabled(): Observable<string> {
    return of('true');
  }

  public getBcsSsoUrl(): Observable<string> {
    return of('bcsSsoUrl');
  }

  public getBcsLandingUrl(): Observable<string> {
    return of('bcsLandingUrl');
  }
}
