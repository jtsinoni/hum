import {Role} from '../models/role.model';
import {Observable, of} from 'rxjs';
import {RoleRef} from '@lc-app-models';

export class RoleApiServiceMock {

    constructor() {
    }

  public getRoles(roleIds: string[]): Observable<Role[]> {
    return of([new Role()]);
  }

  public getAllRoleRefs(): Observable<RoleRef[]> {
    return of([new RoleRef()]);
  }
}
