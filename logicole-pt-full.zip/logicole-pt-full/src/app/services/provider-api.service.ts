import { Injectable } from '@angular/core';
import {LoggerService} from '@lc-logger-service';
import {AuthenticationService} from '@lc-services/*';
import {LoaderService} from './loader.service';
import {ApiConstants} from '@lc-constants/*';
import { HttpClient } from '@angular/common/http';
import {ApiService} from './api.service';
import { Observable } from 'rxjs';
import {Provider} from '../models/provider.model';
import {ProviderRef} from '../models/provider-ref.model';
import {ProviderType} from '../models/provider-type.model';

@Injectable({
  providedIn: 'root'
})
export class ProviderApiService extends ApiService{

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
    super(ApiConstants.PROVIDER_API, logger, http, authenticationService, loaderService);
  }

  public getFinancialServiceProviders(): Observable<Array<Provider>> {
    return this.get(`getFinancialServiceProviders`);
  }

  public getAllProviders(): Observable<Array<Provider>> {
    return this.get(`getAllProviders`);
  }

  public findProviderById(providerId: string): Observable<Provider> {
    return this.get(`findProviderById?id=${providerId}`);
  }

  public saveProvider(provider: Provider): Observable<Provider> {
    return this.post(`saveProvider`, provider);
  }

  public deleteProvider(provider: Provider) {
    return this.post('deleteProvider', provider.id);
  }

  public getProviderTypes(): Observable<Array<ProviderType>> {
    return this.get(`getProviderTypes`);
  }

  public getProviderRefsByType(providerType: string): Observable<Array<ProviderRef>> {
    return this.get(`getProviderRefsByType?providerType=${providerType}`);
  }

  public getResponsibleOrganizationRef(startOrgId: string, providerType: string): Observable<ProviderRef> {
    return this.get(`getResponsibleOrganizationRef?startOrgId=${startOrgId}&providerType=${providerType}`);
  }

  public getProviderData(startNode: string, providerType: string): Observable<any> {
    return this.get(`getProviderData?startNode=${startNode}&providerType=${providerType}`);
  }
}
