import {Observable, of} from 'rxjs';

import {HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {NotificationService} from './core/notification.service';

export class InterceptorServiceMock  {
  public notificationService: NotificationService;

  constructor() {
  }

  public displayNotification(error: any){
    const errorMsg: string = 'An error has occurred';
    this.notificationService.errorMsg(errorMsg);
  }

  public findCustomMessage(fullMessage: string){
    const message: string = 'An error occurred';
    return message;
  }

  // intercept request and add token
  public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return of();
  }

}
