import {TransitionPromise} from '@uirouter/core';
import {RouteInfo} from '@lc-constants/*';
import {RawParams, TransitionOptions} from '@uirouter/angular';

export class StateNavigationServiceMock {

  private _returnRoute: RouteInfo = null;

  private get returnRouteInfo(): RouteInfo {
    return this._returnRoute;
  }

  private set returnRouteInfo(routeInfo: RouteInfo) {
    this._returnRoute = routeInfo;
  }

  constructor() {
  }

  public isCurrentState(stateName: string): boolean {
    return true;
  }

  public isPreviousState(stateName: string): boolean {
    return true;
  }

  public navigateTo(routeInfo: RouteInfo, returnRoute?: RouteInfo): TransitionPromise {
    return null;
  }

  public navigateToState(routeInfo: RouteInfo, reload?: boolean): TransitionPromise {
    return null;
  }

  public navigateToStateWithDataParameters(routeInfo: RouteInfo, data: any, reload?: boolean): TransitionPromise {
    return null;
  }

  public navigateToStateWithOptions(routeInfo: RouteInfo, options: any): TransitionPromise {
    return null;
  }

  public navigateToStateWithDataAndOptions(routeInfo: RouteInfo, data?: RawParams, options?: TransitionOptions) {
    return null;
  }

  public back() {
    return null;
  }

  public previous(data?: any) {
    return null;
  }

  public getReturnRoute(): RouteInfo {
    return null;
  }

}

