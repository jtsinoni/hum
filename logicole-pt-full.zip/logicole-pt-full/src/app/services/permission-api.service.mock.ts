import {Observable, of} from 'rxjs';
import {PermissionDetailed} from '../models/permission-detailed.model';

export class PermissionApiServiceMock {

    constructor() {
    }

    public getPermission(permissionId: string): Observable<PermissionDetailed> {
        return of (new PermissionDetailed());
    }
}
