import { of } from 'rxjs';
import {Provider} from '../models/provider.model';

export class ProviderServiceMock {

  public selectedProvider: Provider = new Provider();

  public getAllProviders() {
    return of(new Array<Provider>());
  }

  public getProviderTypes() {
   return of(new Array<string>());
  }

  public getProvidersByType(providerType: string) {
    return of(new Array<Provider>());
  }

}
