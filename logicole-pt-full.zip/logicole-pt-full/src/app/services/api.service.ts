import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import {LoggerService} from '../services/logger/logger.service';
import {AuthenticationService} from './core/authentication.service';
import {finalize} from 'rxjs/operators';
import {LoaderService} from './loader.service';
import {Injectable} from '@angular/core';
import {ServiceToken} from './service-token';
import {AppConfigService} from './app-config.service';
import {ApiConstants} from '@lc-constants/*';

@Injectable()
export class ApiService {
  private apiServiceName: string = 'Api Service';

  constructor(private methodPath: ServiceToken,
              protected logger: LoggerService,
              private http: HttpClient,
              protected authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
  }

  protected determineUrl(action: string) {
    return AppConfigService.settings.baseApiUrl + this.methodPath.getDescription() + action;
    // Future use to allow the PT to be dropped on any server without needing to change the baseURL
    // const baseURL: string = '/logicole-gateway/';
    // return baseURL + this.methodPath.getDescription() + action;
  }

  public getArrayBuffer(action: string): Observable<any> {
    const url: string = this.determineUrl(action);
    const headers: HttpHeaders = new HttpHeaders();
    return this.http.get(url, {headers: headers, responseType: 'arraybuffer'});
  }

  public getText(action: string, callerHandlesError?: boolean, customHeaders?: HttpHeaders): Observable<any> {
    this.loaderService.show();

    const url: string = this.determineUrl(action);
    let headers: HttpHeaders = new HttpHeaders();

    if (customHeaders) {
      headers = customHeaders;
    }

    if (callerHandlesError) {
      headers = this.addCallerHandlesErrorHeader(headers);
    }

    this.logger.debug(`${this.apiServiceName} - BT Get URL: ${url}`);
    return this.http.get(url, {headers: headers, responseType: 'text'}).pipe(
      finalize(() => {
        this.loaderService.hide();
      })
    );
  }

  public get(action: string, callerHandlesError?: boolean, customHeaders?: HttpHeaders): Observable<any> {
    this.loaderService.show();

    const url: string = this.determineUrl(action);
    let headers: HttpHeaders = new HttpHeaders();

    if (customHeaders) {
      headers = customHeaders;
      headers.keys().forEach(key => {
        if (!headers.has(key)) {
          this.logger.debug(`customHeaders:` + headers.get(key));
        }
      })
    }

    if (callerHandlesError) {
      headers = this.addCallerHandlesErrorHeader(headers);
    }

    this.logger.debug(`${this.apiServiceName} - BT Get URL: ${url}`);
    return this.http.get(url, {headers: headers})
      .pipe(
        finalize(() => {
          this.loaderService.hide();
        })
      );
  }

  public post(action: string, data: any, callerHandlesError?: boolean,  responseTypeStr?: string, customHeaders?: HttpHeaders): Observable<any> {
    this.loaderService.show();

    const url: string = this.determineUrl(action);
    let headers: HttpHeaders = new HttpHeaders();

    if ( customHeaders ) {
      headers = customHeaders;
    }

    if (callerHandlesError) {
      headers = this.addCallerHandlesErrorHeader(headers);
    }

    this.logger.debug(`${this.apiServiceName} - BT Post URL: ${url}`);
    let options;
    if ( responseTypeStr ) {
      options = {headers: headers, responseType: responseTypeStr};
    } else {
      options = {headers: headers};
    }
    return this.http.post(url, data, options)
      .pipe(
        finalize(() => {
          this.loaderService.hide();
        })
      );
  }

  private addCallerHandlesErrorHeader(headers: HttpHeaders): HttpHeaders {
    headers = headers.append(ApiConstants.LC_CALLER_HANDLES_ERR, ApiConstants.LC_CALLER_HANDLES_ERR);
    return headers;
  }

}
