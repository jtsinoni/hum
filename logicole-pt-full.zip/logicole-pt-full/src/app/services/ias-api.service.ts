import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import {LoggerService} from '../services/logger/logger.service';
import {Injectable} from '@angular/core';
import {AppConfigService} from './app-config.service';
import {ApiConstants} from '@lc-constants/*';

@Injectable()
export class IasApiService {

  constructor(private logger: LoggerService,
              private http: HttpClient) {
  }

  protected determineUrl(action: string) {
    // return AppConfigService.settings.iasUrl + this.methodPath.getDescription() + action;
    return AppConfigService.settings.iasUrl;
  }

  public get(action: string, customHeaders?: HttpHeaders): Observable<any> {

    const url: string = this.determineUrl(action);
    let headers: HttpHeaders = new HttpHeaders();

    if (customHeaders) {
      headers = customHeaders;
    }

    headers = this.addCallerHandlesErrorHeader(headers);

    this.logger.debug(`IAS Get URL: ${url}`);
    return this.http.get(url, {headers: headers});
  }

  public post(action: string, data: any, callerHandlesError?: boolean, responseTypeStr?: string, customHeaders?: HttpHeaders): Observable<any> {

    const url: string = this.determineUrl(action);
    let headers: HttpHeaders = new HttpHeaders();

    if (customHeaders) {
      headers = customHeaders;
    }

    if (callerHandlesError) {
      headers = this.addCallerHandlesErrorHeader(headers);
    }

    this.logger.debug(`IAS Post URL: ${url}`);
    let options;
    if (responseTypeStr) {
      options = {headers: headers, responseType: responseTypeStr};
    } else {
      options = {headers: headers};
    }
    return this.http.post(url, data, options);
  }

  private addCallerHandlesErrorHeader(headers: HttpHeaders): HttpHeaders {
    headers = headers.append(ApiConstants.LC_CALLER_HANDLES_ERR, ApiConstants.LC_CALLER_HANDLES_ERR);
    return headers;
  }

}
