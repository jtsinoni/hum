import {LoggerService} from '@lc-logger-service';
import {ApplicationNotificationApiService} from './application-notification-api.service';
import {Injectable} from '@angular/core';
import {ApplicationNotification} from '../home/jmlfdc-admin/system-notification/models/application-notification';

@Injectable()
export class ApplicationNotificationService {
  private serviceName: string = 'ApplicationNotificationService';

  constructor(protected logger: LoggerService,
              public applicationNotificationApiService: ApplicationNotificationApiService) {

    this.logger.debug(`${this.serviceName} - Start`);
  }

  public notificationCount: Number = 0;
  public unreadNotifications: ApplicationNotification[] = [];
  public allNotifications: ApplicationNotification[] = [];
  public isVisibleUnreadNotifications: boolean = false;
  public profileSearchText: string = '';
  public loadingNotifications: boolean = false;

  public getUnreadNotificationCount() {
    return this.applicationNotificationApiService.getUnreadNotificationCount().subscribe(count => {
      this.notificationCount = count;
      }
    );
  }

  public getUnreadNotifications() {
    this.loadingNotifications = true;
    return this.applicationNotificationApiService.getUnreadNotifications().subscribe(notifications  => {
      if (notifications != null) {
      this.unreadNotifications = notifications;
      }
      this.loadingNotifications = false;
    });
  }

  public toggleUnreadNotifications() {
    this.getUnreadNotifications();
    this.isVisibleUnreadNotifications = !this.isVisibleUnreadNotifications;
  }

  public hideUnreadNotifications() {
    this.isVisibleUnreadNotifications = false;
  }

  public markAsRead(id: string) {
    this.applicationNotificationApiService.markAsRead(id).subscribe(notifications  => {
      this.getUnreadNotificationCount();
      if (notifications != null) {
        this.unreadNotifications = notifications;
        if (notifications.length === 0) {
          this.isVisibleUnreadNotifications = false;
        }
      }
    });
  }

  public getAllNotifications() {
    return this.applicationNotificationApiService.getAllNotifications().subscribe(notifications  => {
      if (notifications != null) {
        this.allNotifications = notifications;
      }
    });
  }
}
