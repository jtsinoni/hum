import {Injectable} from '@angular/core';
import {ApiService} from 'app/services/api.service';
import {AuthenticationService, LoggerService} from '@lc-services/*';
import {HttpClient} from '@angular/common/http';
import {LoaderService} from 'app/services/loader.service';
import {ApiConstants} from '@lc-constants/*';
import {Observable} from 'rxjs';
import {FloorPlanLayer} from '../models/floor-plan/floor-plan-layer.model';
import {DepartmentFill} from '../models/floor-plan/department-fill.model';

@Injectable({
  providedIn: 'root'
})
export class DrawingLookupApiService extends ApiService {

  public serviceName: string = 'Drawing Lookup Api Service';

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
    super(ApiConstants.DRAWING_LOOKUP_API, logger, http, authenticationService, loaderService);
    this.logger.debug(`${this.serviceName} - Start`);
  }

  // DepartmentFill functions
  public getDepartmentFills(): Observable<Array<DepartmentFill>> {
    return this.get('getDepartmentFills');
  }

  public updateDepartmentFill(departmentFill: DepartmentFill): Observable<DepartmentFill> {
    return this.post('updateDepartmentFill', departmentFill);
  }

  // FloorPlanLayer functions
  public getFloorPlanLayers(): Observable<Array<FloorPlanLayer>> {
    return this.get('getFloorPlanLayers');
  }

  public createFloorPlanLayer(floorPlanLayer: FloorPlanLayer): Observable<FloorPlanLayer> {
    return this.post('createFloorPlanLayer', floorPlanLayer);
  }

  public updateFloorPlanLayer(floorPlanLayer: FloorPlanLayer): Observable<FloorPlanLayer> {
    return this.post('updateFloorPlanLayer', floorPlanLayer);
  }

  public deleteFloorPlanLayer(floorPlanLayerId: string): Observable<FloorPlanLayer>  {
    return this.get(`deleteFloorPlanLayer?floorPlanLayerId=${floorPlanLayerId}`);
  }
}
