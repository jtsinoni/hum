import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {AuthenticationService} from './core/authentication.service';
import {LoggerService} from './logger/logger.service';
import {LoaderService} from './loader.service';
import {ApiService} from './api.service';
import {ApiConstants} from '@lc-constants/*';

@Injectable()
export class BusinessIntelligenceApiService extends ApiService {

  private serviceName: string = 'BusinessIntelligenceApiService';

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              protected loaderService: LoaderService) {
    super(ApiConstants.BUSINESS_INTELLIGENCE_API, logger, http, authenticationService, loaderService);

    this.logger.debug(`${this.serviceName} - Start`);
  }

  public getJmarToken(): Observable<string> {
    return this.getText('getJmarToken');
  }

  public getBcsToken(bcsToken: string): Observable<string> {
    if (bcsToken) {
      return this.getText('getBcsToken?bcsToken=' + bcsToken);
    } else {
      return this.getText('getBcsToken');
    }
  }

  public getBcsSsoEnabled(): Observable<string> {
    return this.getText('getBcsSsoEnabled');
  }

  public getBcsSsoUrl(): Observable<string> {
    return this.getText('getBcsSsoUrl');
  }

  public getBcsLandingUrl(): Observable<string> {
    return this.getText('getBcsLandingUrl');
  }
}
