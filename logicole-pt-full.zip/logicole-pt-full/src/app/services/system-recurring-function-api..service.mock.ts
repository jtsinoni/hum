import {Observable, of} from 'rxjs';
import {RecurringFunctionConfiguration} from '../home/jmlfdc-admin/dmlss-live-data-management/models/recurring-function-configuration.model';
import {RecurringFunctionStatus} from '../home/jmlfdc-admin/dmlss-live-data-management/models/recurring-function-status.model';
import {RecurringFunction} from '../home/jmlfdc-admin/dmlss-live-data-management/models/recurring-function.model';

export class SystemRecurringFunctionApiServiceMock {

  constructor() {
  }

  public ensureRecurrenceHealth(): Observable<void>{
    return of();
  }

  // ****************************************************** //
  // Configuration Settings
  // ****************************************************** //

  public setIsEnabled(recurringFunctionId: String, isEnabled: boolean): Observable<RecurringFunctionConfiguration>{
    return of(new RecurringFunctionConfiguration());
  }

  public setFrequency(recurringFunctionId: String, frequency: number): Observable<RecurringFunctionConfiguration>{
    return of(new RecurringFunctionConfiguration());
  }

  public setTimeout(recurringFunctionId: String, timeout: number): Observable<RecurringFunctionConfiguration>{
    return of(new RecurringFunctionConfiguration());
  }

  public setUseMock(recurringFunctionId: String, useMock: boolean): Observable<RecurringFunctionConfiguration>{
    return of(new RecurringFunctionConfiguration());
  }

  public setMockDuration(recurringFunctionId: String, mockDuration: number): Observable<RecurringFunctionConfiguration>{
    return of(new RecurringFunctionConfiguration());
  }

  // ****************************************************** //
  // Recurrence
  // ****************************************************** //


  public startRecurrence(recurringFunctionId: String): Observable<RecurringFunctionStatus>{
    return of(new RecurringFunctionStatus());
  }

  public stopRecurrence(recurringFunctionId: String): Observable<RecurringFunctionStatus>{
    return of(new RecurringFunctionStatus());
  }

  // endregion


  public getAllRecurringFunctions(): Observable<Array<RecurringFunction>> {
    return of([]);  }

  public executeRecurringFunction(recurringFunctionId: String): Observable<string> {
    return of('');
  }


}
