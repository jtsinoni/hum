import {Component, OnInit} from '@angular/core';
import {LoggerService} from './services/logger/logger.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {


  constructor(private loggerService: LoggerService) {
    this.loggerService.debug('in app component constructor');
  }

  public ngOnInit() {}


}
