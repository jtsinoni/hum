///<reference path='../../../node_modules/ngx-bootstrap/accordion/accordion.module.d.ts'/>
import {ModuleWithProviders, NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {TypeaheadModule} from 'ngx-bootstrap/typeahead';
import {NgSelectModule} from '@ng-select/ng-select';

import {LcLeftSidePanelComponent} from './panels/lc-left-side-panel/lc-left-side-panel.component';
import {LcRightSidePanelComponent} from './panels/lc-right-side-panel/lc-right-side-panel.component';
import {CommonModule} from '@angular/common';

import {DmlesSimpleTreeService} from './tree/dmles-simple-tree.service';
import {LcTextInputComponent} from './form-inputs/lc-text-input/lc-text-input.component';
import {LcTextAreaInputComponent} from './form-inputs/lc-text-area-input/lc-text-area-input.component';
import {LcSelectInputComponent} from './form-inputs/lc-select-input/lc-select-input.component';
import {LcEmailInputComponent} from './form-inputs/lc-email-input/lc-email-input.component';
import {LcCurrencyInputComponent} from './form-inputs/lc-currency-input/lc-currency-input.component';
import {ChangeProfileAccessComponent} from './dropdown/change-profile-access.component';
import {LcReadonlyLabelValueComponent} from './form-other/lc-readonly-label-value/lc-readonly-label-value.component';
import {LcNavigatorComponent} from './form-other/lc-navigator/lc-navigator.component';
import {LcMessageBoxComponent} from './panels/lc-message-box/lc-message-box.component';
import {PipesModule} from '../pipes/pipes.module';
import {LcNotesComponent} from './lc-notes/lc-notes.component';
import {LcTextInputButtonComponent} from './form-inputs/lc-text-input-button/lc-text-input-button.component';
import {LcNumberInputComponent} from './form-inputs/lc-number-input/lc-number-input.component';
import {NgxBootstrapModule} from './ngx-bootstrap/ngx-bootstrap.module';
import {LcLoaderComponent} from './lc-loader/lc-loader.component';
import {LcProductComponent} from './lc-product/lc-product.component';
import {LcButtonComponent} from './lc-button/lc-button.component';
import {LcSubmitButtonComponent} from './lc-submit-button/lc-submit-button.component';
import {LcDataWrapperComponent} from './lc-data-wrapper/lc-data-wrapper.component';
import {LcTypeaheadComponent} from './form-other/lc-typeahead/lc-typeahead.component';
import {LcClipboardCopyComponent} from './lc-clipboard-copy/lc-clipboard-copy.component';
import {LcDateInputComponent} from './form-inputs/lc-date-input/lc-date-input.component';
import {LcStatusBarComponent} from './lc-status-bar/lc-status-bar.component';
import {NgxUploaderModule} from 'ngx-uploader';
import {ServicesModule} from '../services/services.module';
import {FileManagerService} from '../services/file-manager.service';
import {SectionFilterPipe} from './file-management/lc-attachments/lc-section-filter.pipe';
import {AttachmentFilterPipe} from './file-management/lc-attachments/lc-attachment-filter.pipe';
import {LcExportFileComponent} from './lc-export-file/lc-export-file.component';
import {LcPaginationComponent} from './lc-pagination/lc-pagination.component';
import {LcSortByComponent} from './lc-sort-by/lc-sort-by.component';
import {LcQuantityTickerComponent} from './lc-quantity-ticker/lc-quantity-ticker.component';
import {LcLoadingIconComponent} from './lc-loading-icon/lc-loading-icon.component';
import {OrganizationService} from '../home/organization/services/organization.service';
import {LoggerService} from '@lc-services/*';
import {LcCategoryComponent} from './lc-search/lc-category/lc-category.component';
import {LcFacetComponent} from './lc-search/lc-facet/lc-facet.component';
import {LcSearchFiltersComponent} from './lc-search/lc-search-filters/lc-search-filters.component';
import {LcOrgFinderComponent} from './lc-org-finder/lc-org-finder.component';
import {LcDateCellComponent} from './lc-table/lc-date-cell/lc-date-cell.component';
import {LcCheckboxCellComponent} from './lc-table/lc-checkbox-cell/lc-checkbox-cell.component';
import {LcCheckboxDisplayOnlyCellComponent} from './lc-table/lc-checkbox-display-only-cell/lc-checkbox-display-only-cell.component';
import {LcButtonCellComponent} from './lc-table/lc-button-cell/lc-button-cell.component';
import {LcBadgeLinkCellComponent} from './lc-table/lc-badge-link-cell/lc-badge-link-cell.component';
import {LcLinkCellComponent} from './lc-table/lc-link-cell/lc-link-cell.component';
import {LcCurrencyCellComponent} from './lc-table/lc-currency-cell/lc-currency-cell.component';
import {LcNumberCardComponent} from './lc-number-card/lc-number-card.component';
import {LcAttachmentsComponent} from './file-management/lc-attachments/lc-attachments.component';
import {LcSingleAttachmentComponent} from './file-management/lc-single-attachment/lc-single-attachment.component';
import {LcFileUploadComponent} from './file-management/lc-file-upload/lc-file-upload.component';
import {LcSwitchComponent} from './lc-switch/lc-switch.component';
import {LcTextValueComponent} from './form-other/lc-text-value/lc-text-value.component';
import {LcTextInputButtonInteractiveComponent} from './form-inputs/lc-text-input-button-interactive/lc-text-input-button-interactive.component';
import {LcTreeComponent} from './tree/lc-tree.component';
import {TreeModule} from '@circlon/angular-tree-component';
import {LcDateRangeInputComponent} from './form-inputs/lc-date-range-input/lc-date-range-input.component';
import {LcSideNavComponent} from './lc-side-nav/lc-side-nav.component';
import {LcSideNavItemComponent} from './lc-side-nav/lc-side-nav-item/lc-side-nav-item.component';
import {UIRouterModule} from '@uirouter/angular';
import {LcDeleteButtonSetComponent} from './lc-delete-button-set/lc-delete-button-set.component';
import {LcBarChartHorizontalComponent} from './charts/lc-bar-chart-horizontal/lc-bar-chart-horizontal.component';
import {NgxChartsModule} from '@swimlane/ngx-charts';
import {LcPieChartComponent} from './charts/lc-pie-chart/lc-pie-chart.component';
import {LcBarChartVerticalComponent} from './charts/lc-bar-chart-vertical/lc-bar-chart-vertical.component';
import {LcButtonGroupComponent} from './lc-button-group/lc-button-group.component';
import {LcBarChartHorizontal2dComponent} from './charts/lc-bar-chart-horizontal-2d/lc-bar-chart-horizontal-2d.component';
import {LcSvgViewerControlComponent} from './lc-svg-viewer-control/lc-svg-viewer-control.component';
import {LcDetailDataPagerComponent} from './lc-detail-data-pager/lc-detail-data-pager.component';
import {LcDataReplacementComponent} from './data-replacement/lc-data-replacement.component';
import {LcSensitiveDataInputComponent} from './form-inputs/lc-sensitive-data-input/lc-sensitive-data-input.component';
import {LcDualListboxComponent} from './lc-dual-listbox/lc-dual-listbox.component';
import {LcContextMenuComponent} from './lc-context-menu/lc-context-menu.component';
import {LcRecurrenceInputComponent} from './form-inputs/lc-recurrence-input/lc-recurrence-input.component';
import {LcNotes2Component} from './lc-notes2/lc-notes2.component';
import {LcCheckboxComponent} from './form-inputs/lc-checkbox/lc-checkbox.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {LcStatusFilterComponent} from './lc-search/lc-status-filter/lc-status-filter.component';
import {LcYesNoFilterComponent} from './lc-search/lc-yes-no-filter/lc-yes-no-filter.component';
import {LcDateRangeFilterComponent} from './lc-search/lc-date-range-filter/lc-date-range-filter.component';
import {LcMessageBox2Component} from './panels/lc-message-box2/lc-message-box2.component';
import {LcBusinessContactFinderComponent} from './lc-business-contact-finder/lc-business-contact-finder.component';
import {LcContactSelectedDirective} from './lc-business-contact-finder/lc-contact-selected.directive';
import {LcFloorPlanInformationComponent} from './lc-floor-plan-viewer/lc-floor-plan-information/lc-floor-plan-information.component';
import {LcFloorPlanSvgComponent} from './lc-floor-plan-viewer/lc-floor-plan-svg/lc-floor-plan-svg.component';
import {LcFloorPlanViewerComponent} from './lc-floor-plan-viewer/lc-floor-plan-viewer.component';
import {LcExpandCollapseComponent} from './lc-expand-collapse/lc-expand-collapse.component';
import {LcNumberFormattedInputComponent} from './form-inputs/lc-number-formatted-input/lc-number-formatted-input.component';
import {LcDropdownComponent} from './form-inputs/lc-dropdown/lc-dropdown.component';
import {LcSearchInputComponent} from './lc-search-input/lc-search-input.component';
import {LcFloorPlanPatternsComponent} from './lc-floor-plan-viewer/lc-floor-plan-patterns/lc-floor-plan-patterns.component';
import {LcColorPickerComponent} from './form-other/lc-color-picker/lc-color-picker.component';
import {LcWorkflowStepsComponent} from './lc-workflow/lc-workflow-steps/lc-workflow-steps.component';
import {LcWorkflowActionsComponent} from './lc-workflow/lc-workflow-actions/lc-workflow-actions.component';
import {LcWorkflowHistoryComponent} from './lc-workflow/lc-workflow-history/lc-workflow-history.component';
import {LcCustomFieldValuesComponent} from './lc-custom-field-values/lc-custom-field-values.component';
import {LcJournalComponent} from './lc-journal/lc-journal.component';
import {LcDatetimeInputComponent} from './form-inputs/lc-datetime-input/lc-datetime-input.component';
import {LcDataWrapperHelperService} from './lc-data-wrapper/services/lc-data-wrapper-helper.service';
import {LcGraphicalSearchComponent} from './lc-graphical-search/lc-graphical-search.component';
import {LcLocationHierachyComponent} from '../home/real-property/components/lc-location-hierachy/lc-location-hierachy.component';
import {LcApplyAllLinkComponent} from './lc-apply-all-link/lc-apply-all-link.component';
import {LcPrintComponent} from './print/lc-print/lc-print.component';
import {LcPrintWrapperComponent} from './print/lc-print-wrapper/lc-print-wrapper.component';
import {SkillComponent} from './lc-reference-data/skill/skill.component';
import {LcDataWrapperTableComponent} from './lc-data-wrapper/lc-data-wrapper-table/lc-data-wrapper-table.component';
import {LcNumberInputNoArrowsComponent} from './form-inputs/lc-number-input-no-arrows/lc-number-input-no-arrows.component';
import {LcHtmlReportComponent} from './lc-html-report/lc-html-report.component';
import {LcHtmlReportCellComponent} from './lc-html-report/lc-html-report-cell/lc-html-report-cell.component';
import {LcHtmlReportFooterComponent} from './lc-html-report/lc-html-report-footer/lc-html-report-footer.component';
import {LcHtmlReportHeaderComponent} from './lc-html-report/lc-html-report-header/lc-html-report-header.component';
import {LcHtmlReportPrintComponent} from './lc-html-report/lc-html-report-print/lc-html-report-print.component';
import {LcHtmlReportSectionComponent} from './lc-html-report/lc-html-report-section/lc-html-report-section.component';
import {LcHtmlReportService} from './lc-html-report/services/lc-html-report.service';
import {LcTabsComponent} from './lc-tabs/lc-tabs.component';
import {LcTabComponent} from './lc-tabs/lc-tab/lc-tab.component';
import {LcTabFooterComponent} from './lc-tabs/lc-tab-footer/lc-tab-footer.component';
import {ProductDocumentationListComponent} from 'app/home/jmlfdc-admin/abi-management/components/product-documentation-list/product-documentation-list.component';
import {FileUploadListComponent} from 'app/home/jmlfdc-admin/abi-management/components/file-upload-list/file-upload-list.component';
import {ProductIdentifierListComponent} from 'app/home/jmlfdc-admin/abi-management/components/product-identifier-list/product-identifier-list.component';
import {LcUtcDateTimeComponent} from './lc-utc-date-time/lc-utc-date-time.component';
import {LcUtcDateComponent} from './lc-utc-date/lc-utc-date.component';
import {LcNumberRangeInputComponent} from './form-inputs/lc-number-range-input/lc-number-range-input.component';
import {LcMaintenanceProcedureDomainSelectorComponent} from './lc-maintenance-procedure-domain-selector/lc-maintenance-procedure-domain-selector.component';
import {A11yModule} from '@angular/cdk/a11y';
import {LcPrintHtmlReportComponent} from './print/printable-forms/lc-print-html-report/lc-print-html-report.component';
import {LcPrintHtmlReportSectionComponent} from './print/printable-forms/lc-print-html-report/lc-print-html-report-section/lc-print-html-report-section.component';
import {LcPrintHtmlReportCellComponent} from './print/printable-forms/lc-print-html-report/lc-print-html-report-cell/lc-print-html-report-cell.component';
import {LcPrintHtmlReportFooterComponent} from './print/printable-forms/lc-print-html-report/lc-print-html-report-footer/lc-print-html-report-footer.component';
import {LcPrintHtmlReportHeaderComponent} from './print/printable-forms/lc-print-html-report/lc-print-html-report-header/lc-print-html-report-header.component';
import {LcPrintHtmlReportPrintComponent} from './print/printable-forms/lc-print-html-report/lc-print-html-report-print/lc-print-html-report-print.component';
import {ValueExtractorPipe} from './lc-data-wrapper/lc-data-wrapper-table/value-extractor.pipe';
import {LcPagination2Component} from './lc-pagination2/lc-pagination2.component';
import {LcScopedSearchInputComponent} from './lc-scoped-search-input/lc-scoped-search-input.component';
import {LcInlineEditDeleteButtonsComponent} from './lc-inline-edit-delete-buttons/lc-inline-edit-delete-buttons.component';
import {ClipboardModule} from '@angular/cdk/clipboard';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        NgxBootstrapModule.forRoot(),
        PipesModule.forRoot(),
        TypeaheadModule.forRoot(),
        NgxUploaderModule,
        ServicesModule,
        TreeModule,
        UIRouterModule.forChild(),
        NgxChartsModule,
        MatCheckboxModule,
        ReactiveFormsModule,
        NgSelectModule,
        A11yModule,
        ClipboardModule
    ],
  declarations: [
    LcLeftSidePanelComponent,
    LcRightSidePanelComponent,
    ChangeProfileAccessComponent,
    LcNavigatorComponent,
    LcMessageBoxComponent,
    LcNotesComponent,
    LcNotes2Component,
    LcLoaderComponent,
    LcProductComponent,
    LcButtonComponent,
    LcSubmitButtonComponent,
    LcDataWrapperComponent,
    LcTypeaheadComponent,
    LcClipboardCopyComponent,
    LcDateInputComponent,
    LcStatusBarComponent,
    LcFileUploadComponent,
    LcAttachmentsComponent,
    LcSingleAttachmentComponent,
    SectionFilterPipe,
    AttachmentFilterPipe,
    LcCurrencyInputComponent,
    LcEmailInputComponent,
    LcNumberInputComponent,
    LcNumberFormattedInputComponent,
    LcSelectInputComponent,
    LcTextAreaInputComponent,
    LcTextInputComponent,
    LcTextInputButtonComponent,
    LcReadonlyLabelValueComponent,
    LcExportFileComponent,
    LcPaginationComponent,
    LcDataReplacementComponent,
    LcSortByComponent,
    LcQuantityTickerComponent,
    LcLoadingIconComponent,
    LcCategoryComponent,
    LcFacetComponent,
    LcSearchFiltersComponent,
    LcStatusFilterComponent,
    LcYesNoFilterComponent,
    LcDateRangeFilterComponent,
    LcOrgFinderComponent,
    LcDateCellComponent,
    LcCheckboxCellComponent,
    LcCheckboxDisplayOnlyCellComponent,
    LcButtonCellComponent,
    LcBadgeLinkCellComponent,
    LcLinkCellComponent,
    LcCurrencyCellComponent,
    LcNumberCardComponent,
    LcSwitchComponent,
    LcTextValueComponent,
    LcTreeComponent,
    LcTextValueComponent,
    LcTextInputButtonInteractiveComponent,
    LcDateRangeInputComponent,
    LcSideNavComponent,
    LcSideNavItemComponent,
    LcDeleteButtonSetComponent,
    LcBarChartHorizontalComponent,
    LcPieChartComponent,
    LcBarChartVerticalComponent,
    LcButtonGroupComponent,
    LcDropdownComponent,
    LcBarChartHorizontal2dComponent,
    LcSvgViewerControlComponent,
    LcDetailDataPagerComponent,
    LcSensitiveDataInputComponent,
    LcDualListboxComponent,
    LcContextMenuComponent,
    LcRecurrenceInputComponent,
    LcCheckboxComponent,
    LcMessageBox2Component,
    LcBusinessContactFinderComponent,
    LcContactSelectedDirective,
    LcFloorPlanInformationComponent,
    LcFloorPlanSvgComponent,
    LcFloorPlanPatternsComponent,
    LcFloorPlanViewerComponent,
    LcExpandCollapseComponent,
    LcSearchInputComponent,
    LcScopedSearchInputComponent,
    LcColorPickerComponent,
    LcDropdownComponent,
    LcWorkflowStepsComponent,
    LcWorkflowActionsComponent,
    LcWorkflowHistoryComponent,
    LcCustomFieldValuesComponent,
    LcJournalComponent,
    LcDatetimeInputComponent,
    LcGraphicalSearchComponent,
    LcLocationHierachyComponent,
    LcApplyAllLinkComponent,
    LcPrintComponent,
    LcPrintWrapperComponent,
    LcDataWrapperTableComponent,
    SkillComponent,
    LcNumberInputNoArrowsComponent,
    LcDataWrapperTableComponent,
    LcNumberInputNoArrowsComponent,
    LcHtmlReportComponent,
    LcHtmlReportCellComponent,
    LcHtmlReportFooterComponent,
    LcHtmlReportHeaderComponent,
    LcHtmlReportPrintComponent,
    LcHtmlReportSectionComponent,
    LcTabsComponent,
    LcTabComponent,
    LcTabFooterComponent,
    FileUploadListComponent,
    ProductDocumentationListComponent,
    ProductIdentifierListComponent,
    LcUtcDateTimeComponent,
    LcUtcDateComponent,
    LcMaintenanceProcedureDomainSelectorComponent,
    LcNumberRangeInputComponent,
    LcNumberInputNoArrowsComponent,
    LcDataWrapperTableComponent,
    LcPrintHtmlReportComponent,
    LcPrintHtmlReportCellComponent,
    LcPrintHtmlReportFooterComponent,
    LcPrintHtmlReportHeaderComponent,
    LcPrintHtmlReportPrintComponent,
    LcPrintHtmlReportSectionComponent,
    ValueExtractorPipe,
    LcPagination2Component,
    LcInlineEditDeleteButtonsComponent
  ],
  // Since this is shared module we need to export modules or components (without forRoot())
    exports: [
        NgxBootstrapModule,
        LcLeftSidePanelComponent,
        LcRightSidePanelComponent,
        LcCurrencyInputComponent,
        LcTextInputComponent,
        LcNumberInputComponent,
        LcNumberFormattedInputComponent,
        LcTextInputButtonComponent,
        LcTextAreaInputComponent,
        LcSelectInputComponent,
        LcEmailInputComponent,
        ChangeProfileAccessComponent,
        LcReadonlyLabelValueComponent,
        LcNavigatorComponent,
        LcMessageBoxComponent,
        LcNotesComponent,
        LcNotes2Component,
        LcLoaderComponent,
        LcProductComponent,
        LcButtonComponent,
        LcSubmitButtonComponent,
        LcDataWrapperComponent,
        LcTypeaheadComponent,
        LcClipboardCopyComponent,
        LcDateInputComponent,
        LcStatusBarComponent,
        LcAttachmentsComponent,
        LcSingleAttachmentComponent,
        LcFileUploadComponent,
        SectionFilterPipe,
        AttachmentFilterPipe,
        LcExportFileComponent,
        LcPaginationComponent,
        LcDataReplacementComponent,
        LcSortByComponent,
        LcQuantityTickerComponent,
        LcLoadingIconComponent,
        LcSearchFiltersComponent,
        LcStatusFilterComponent,
        LcYesNoFilterComponent,
        LcDateRangeFilterComponent,
        LcOrgFinderComponent,
        LcDateCellComponent,
        LcCheckboxCellComponent,
        LcCheckboxDisplayOnlyCellComponent,
        LcButtonCellComponent,
        LcBadgeLinkCellComponent,
        LcLinkCellComponent,
        LcCurrencyCellComponent,
        LcNumberCardComponent,
        LcNumberRangeInputComponent,
        LcSwitchComponent,
        LcTextValueComponent,
        LcTreeComponent,
        LcTextValueComponent,
        LcTextInputButtonInteractiveComponent,
        LcDateRangeInputComponent,
        LcSideNavComponent,
        LcSideNavItemComponent,
        LcDeleteButtonSetComponent,
        LcBarChartHorizontalComponent,
        LcPieChartComponent,
        LcBarChartVerticalComponent,
        LcButtonGroupComponent,
        LcBarChartHorizontal2dComponent,
        LcSvgViewerControlComponent,
        LcDetailDataPagerComponent,
        LcSensitiveDataInputComponent,
        LcDualListboxComponent,
        LcContextMenuComponent,
        LcRecurrenceInputComponent,
        LcCheckboxComponent,
        LcMessageBox2Component,
        LcBusinessContactFinderComponent,
        LcFloorPlanInformationComponent,
        LcFloorPlanSvgComponent,
        LcFloorPlanPatternsComponent,
        LcFloorPlanViewerComponent,
        LcExpandCollapseComponent,
        LcSearchInputComponent,
        LcScopedSearchInputComponent,
        LcColorPickerComponent,
        LcDropdownComponent,
        LcWorkflowStepsComponent,
        LcWorkflowActionsComponent,
        LcWorkflowHistoryComponent,
        LcCustomFieldValuesComponent,
        LcJournalComponent,
        LcDatetimeInputComponent,
        LcGraphicalSearchComponent,
        LcDatetimeInputComponent,
        LcLocationHierachyComponent,
        LcApplyAllLinkComponent,
        LcPrintComponent,
        LcApplyAllLinkComponent,
        SkillComponent,
        LcNumberInputNoArrowsComponent,
        LcNumberInputNoArrowsComponent,
        LcHtmlReportComponent,
        LcHtmlReportCellComponent,
        LcHtmlReportFooterComponent,
        LcHtmlReportHeaderComponent,
        LcHtmlReportPrintComponent,
        LcHtmlReportSectionComponent,
        LcTabsComponent,
        LcTabComponent,
        LcTabFooterComponent,
        FileUploadListComponent,
        ProductDocumentationListComponent,
        ProductIdentifierListComponent,
        LcUtcDateTimeComponent,
        LcUtcDateComponent,
        LcMaintenanceProcedureDomainSelectorComponent,
        LcPrintHtmlReportComponent,
        LcPrintHtmlReportPrintComponent,
        LcPrintHtmlReportHeaderComponent,
        LcPrintHtmlReportSectionComponent,
        LcPrintHtmlReportCellComponent,
        LcPrintHtmlReportFooterComponent,
        LcPagination2Component,
        LcInlineEditDeleteButtonsComponent,
        ValueExtractorPipe
    ],
  providers: [FileManagerService, LcDataWrapperHelperService]
})
export class CommonComponentsModule {
  public static forRoot(): ModuleWithProviders<CommonComponentsModule> {
    return {
      ngModule: CommonComponentsModule,
      providers: [
        DmlesSimpleTreeService,
        OrganizationService,
        LoggerService,
        LcDataWrapperHelperService,
        LcHtmlReportService
      ]
    };
  }
}
