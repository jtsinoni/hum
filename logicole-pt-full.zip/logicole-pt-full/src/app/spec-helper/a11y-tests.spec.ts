import {a11yTests, prettyPrintA11Y} from '../accessibility';
import {LoggerService} from '@lc-logger-service';
import {RunOptions} from 'axe-core';
export function runA11yTests(nativeElement, loggerService: LoggerService, options?: RunOptions) {
  a11yTests(nativeElement, options)
    .then((results) => {
      expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
    })
    .catch((error) => {
      loggerService.error(`${error}`);
    });
}
