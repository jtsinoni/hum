import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderBy',
  pure: true
})
export class ArraySortPipePipe implements PipeTransform {

  /*
   This is account for nested fields.
   ie "user.name"
   */
  private getProperty (value: { [key: string]: any}, key: string): number|string {
    if (value == null || typeof value !== 'object') {
      return undefined;
    }

    const keys: string[] = key.split('.');
    let result: any = value[keys.shift()];

    for (const key of keys) {
      if (result == null) { // check null or undefined
        return undefined;
      }

      result = result[key];
    }

    return result;
  }

  public transform(array: any[], field: string): any[] {
    /*
     If you want the sort order to be revers add a '-' to the beginning of the field
     ie. "-name"
     */
    let backward = false;
    if (field.charAt(0).match('-')) {
      backward = true;
      field = field.slice(1, field.length);
    }


    if (array){
      array.sort((a: any, b: any) => {
        /*
         This is account for nested fields.
         ie "user.name"
         */
        let propertyA: number|string|boolean = this.getProperty(a, field);
        let propertyB: number|string|boolean = this.getProperty(b, field);

        if (propertyA === null) {
          propertyA = '';
        }

        if (propertyB === null) {
          propertyB = '';
        }

        if (!backward) {
          if (propertyA < propertyB) {
            return -1;
          } else if (propertyA > propertyB) {
            return 1;
          } else {
            return 0;
          }
        }else{
          if (propertyA > propertyB) {
            return -1;
          } else if (propertyA < propertyB) {
            return 1;
          } else {
            return 0;
          }
        }
      });
    }
    return array;
  }

}
