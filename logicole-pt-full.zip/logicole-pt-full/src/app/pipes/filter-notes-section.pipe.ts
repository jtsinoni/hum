import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterNotesSection',
  pure: false
})
export class FilterNotesSectionPipe implements PipeTransform {

  public transform(input: Array<any>, section: string, doFilter: boolean): any {
    if (!input || input.length === 0) {
      return [];
    }

    if (section === null || !doFilter) {
      return input;
    }

    const output: Array<any> = new Array();

    for (const f of input) {
      if (f.section === section) {
        output.push(f);
      }
    }
    return output;
  }
}


