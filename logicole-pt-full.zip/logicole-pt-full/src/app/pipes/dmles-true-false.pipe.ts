import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dmlesTrueFalse'
})
export class DmlesTrueFalsePipe implements PipeTransform {

  public transform(value: any, args?: any): any {
    let retVal: string = 'Yes';
    if (value === null || value === '') {
        retVal = '';
    } else if (value === false || value === 'N') {
        retVal = 'No';
    }
    return retVal;
  }

}
