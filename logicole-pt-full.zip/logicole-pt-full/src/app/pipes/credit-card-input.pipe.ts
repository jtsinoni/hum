import {Pipe, PipeTransform} from '@angular/core';

@Pipe( {
  name: 'creditCardInputPipe'
})
export class CreditCardInputPipe implements PipeTransform {
  public transform(value: string): any {
    if (!value) {
      return '';
    }
    let newVal = value.replace(/[\s-]/g, '');
    if (newVal.length > 4) {
      newVal = newVal.match(/.{1,4}/g).join('-');
    }

    return newVal;
  }

}
