import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pluck'
})
export class PluckPipe implements PipeTransform {

  public transform(input: Array<any>, key: string): any {
    return input.map(value => value[key]);
  }

}
