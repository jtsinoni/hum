import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'lcTextReplace'
})
export class DmlesTextReplacePipe implements PipeTransform {

  public transform(value: string, from: string, to: string): string {

    if (value !== undefined && value !== null) {

      return value.toString().replace(from, to);
    } else {
      return '';
    }
  }
}
