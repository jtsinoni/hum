import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'removeTandZ'
})
export class RemoveTandZPipe implements PipeTransform {

  public REMOVE_T: string = "RemoveT";
  public REMOVE_TIME: string = "RemoveTime";
  public REMOVE_Z: string = "RemoveZ";
  public REMOVE_ZONE: string = "RemoveZone";

  public transform(value: String, ...args: String[]): String {

    if(!value){
      return value;
    }

    const arg1 = args[0];
    if(arg1){
     if(arg1 == this.REMOVE_T){
       value = value.replace('T', ' ');
     }
      if(arg1 == this.REMOVE_TIME){
        const t = value.indexOf('T');
        value = value.substring(0, t != -1 ? t : value.length);
      }
    }

    const arg2 = args[1];
    if(arg2){
      if(arg2 == this.REMOVE_Z){
        value = value.replace('Z', '');
      }
      if(arg2 == this.REMOVE_ZONE){
        const z = value.indexOf('.');
        value = value.substring(0, z != -1 ? z : value.length);
      }
    }

    return value;
  }

}
