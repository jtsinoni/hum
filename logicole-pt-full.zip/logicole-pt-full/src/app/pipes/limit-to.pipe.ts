import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'limitTo',
  pure: false
})
export class LimitToPipe implements PipeTransform {

  public transform(items: any[], startIndex: number, endIndex?: number): any {
    if (!items || items.length === 0) {
      return [];
    }
    if (startIndex == null) {
      return items;
    }
    if (startIndex >= items.length) {
      let newEndIndex = endIndex;
      if (endIndex) {
        newEndIndex = endIndex - startIndex;
      }
      return items.slice(0, newEndIndex);
    }
    return items.slice(startIndex, endIndex);
  }

}
