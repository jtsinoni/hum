import { Pipe, PipeTransform } from '@angular/core';
import {DatePipe} from '@angular/common';
import {ContentConstants} from '../constants';

@Pipe({
  name: 'dmlesDate'
})
export class DmlesDatePipe extends DatePipe implements PipeTransform {

  public transform(value: any, args?: any): any {
    return super.transform(value, ContentConstants.FORMAT_DATE);
  }

}
