import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'join'
})
export class JoinPipe implements PipeTransform {

  public transform(input: Array<any>, separator: string = ' '): any {
    return input.join(separator);
  }

}
