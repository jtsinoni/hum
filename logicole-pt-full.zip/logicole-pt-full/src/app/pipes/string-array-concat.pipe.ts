import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'stringArrayConcat'
})
export class StringArrayConcatPipe implements PipeTransform {

  public transform(strings: string[], delimiter?: string): string {
    let returnStr: string = '';
    if ((strings?.length || 0) > 0) {
      if (!delimiter) {
        delimiter = '';
      }
      strings.forEach(str => {
        if ((str?.length || 0) > 0) {
          returnStr += ((returnStr?.length || 0) > 0) ? delimiter : '';
          returnStr += str;
        }
      });
      return returnStr;
    }
  }
}
