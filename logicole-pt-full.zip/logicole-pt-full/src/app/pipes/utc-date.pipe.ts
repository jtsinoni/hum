import { Pipe, PipeTransform } from '@angular/core';
import {ContentConstants} from '@lc-constants/*';
import {DatePipe} from '@angular/common';

@Pipe({
  name: 'utcDatePipe'
})
export class UtcDatePipe extends DatePipe implements PipeTransform {

  public transform(value: any, args?: any): any {
    return super.transform(value, ContentConstants.FORMAT_DATE, '+0000');
  }

}
