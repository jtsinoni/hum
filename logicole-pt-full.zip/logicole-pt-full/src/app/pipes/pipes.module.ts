import {ModuleWithProviders, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {DmlesDateTimePipe} from './dmles-date-time.pipe';
import {DmlesDatePipe} from './dmles-date.pipe';
import {FilterNotesSectionPipe} from './filter-notes-section.pipe';
import {DmlesServicePipe} from './dmles-service.pipe';
import {DmlesTitleCasePipe} from './dmles-title-case.pipe';
import {DmlesTrueFalsePipe} from './dmles-true-false.pipe';
import {ArraySortPipePipe} from './array-sort-pipe.pipe';
import {DmlesFilterPipe} from './dmles-filter.pipe';
import {FilterOnPipe} from './filter-on.pipe';
import {GroupByPipe} from './group-by.pipe';
import {LimitToPipe} from './limit-to.pipe';
import {NoCommasPipe} from './no-commas.pipe';
import {SafeHtmlPipe} from './safe-html.pipe';
import {DmlesTextReplacePipe} from './dmles-text-replace.pipe';
import {StringArrayCaseInsensitiveSortPipe} from './string-array-case-insensitive-sort.pipe';
import {SumPipe} from './sum.pipe';
import {LcActiveInactivePipe} from './lc-active-inactive.pipe';
import {PluckPipe} from './pluck.pipe';
import {JoinPipe} from './join.pipe';
import {CreditCardInputPipe} from './credit-card-input.pipe';
import {UtcDateTimePipe} from './utc-date-time.pipe';
import {UtcDatePipe} from './utc-date.pipe';
import {StringArrayConcatPipe} from './string-array-concat.pipe';
import {EvenOddPipe} from './even-odd.pipe';
import { RemoveTandZPipe } from './remove-tand-z.pipe';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [
    DmlesDateTimePipe,
    DmlesDatePipe,
    FilterNotesSectionPipe,
    DmlesServicePipe,
    DmlesTitleCasePipe,
    DmlesTextReplacePipe,
    DmlesTrueFalsePipe,
    ArraySortPipePipe,
    DmlesFilterPipe,
    FilterOnPipe,
    GroupByPipe,
    LimitToPipe,
    NoCommasPipe,
    SafeHtmlPipe,
    StringArrayCaseInsensitiveSortPipe,
    StringArrayConcatPipe,
    SumPipe,
    LcActiveInactivePipe,
    JoinPipe,
    PluckPipe,
    CreditCardInputPipe,
    UtcDateTimePipe,
    UtcDatePipe,
    EvenOddPipe,
    RemoveTandZPipe
  ],
  exports: [
    DmlesDateTimePipe,
    DmlesDatePipe,
    FilterNotesSectionPipe,
    DmlesServicePipe,
    DmlesTitleCasePipe,
    DmlesTextReplacePipe,
    DmlesTrueFalsePipe,
    ArraySortPipePipe,
    DmlesFilterPipe,
    FilterOnPipe,
    GroupByPipe,
    LimitToPipe,
    NoCommasPipe,
    SafeHtmlPipe,
    StringArrayCaseInsensitiveSortPipe,
    StringArrayConcatPipe,
    SumPipe,
    LcActiveInactivePipe,
    JoinPipe,
    PluckPipe,
    CreditCardInputPipe,
    UtcDateTimePipe,
    UtcDatePipe,
    EvenOddPipe,
    RemoveTandZPipe
  ]
})
export class PipesModule {

  public static forRoot(): ModuleWithProviders<PipesModule> {
    return {
      ngModule: PipesModule,
      providers: [
        DmlesTitleCasePipe,
        FilterOnPipe,
        GroupByPipe,
        ArraySortPipePipe,
        DmlesDatePipe,
        DmlesDateTimePipe,
        DmlesTextReplacePipe,
        DmlesTrueFalsePipe,
        StringArrayCaseInsensitiveSortPipe,
        StringArrayConcatPipe,
        JoinPipe,
        PluckPipe,
        UtcDateTimePipe,
        LcActiveInactivePipe,
        RemoveTandZPipe
      ],
    };
  }

}
