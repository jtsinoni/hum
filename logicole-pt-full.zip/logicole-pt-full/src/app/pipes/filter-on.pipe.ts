import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterOn',
  pure: false
})
export class FilterOnPipe implements PipeTransform {

  private isString(arg: any): arg is string {
    return arg.toLowerCase !== undefined;
  }

  private isNumber(arg: any): arg is number {
    return arg.isNaN;
  }

  /*
   This is account for nested fields.
   ie "user.name"
   */
  private getProperty (value: { [key: string]: any}, key: string): number|string {
    if (value == null || typeof value !== 'object') {
      return undefined;
    }
    const keys: string[] = key.split('.');
    let result: any = value[keys.shift()];
    for (const key of keys) {
      if (result === null || result === undefined) { // check null or undefined
        return undefined;
      }

      result = result[key];
    }

    return result;
  }

  public transform(items: any[], field: any, filteredValue: any): any[] {
    if (!items || items.length === 0) {
      return [];
    }
    if (field == null || filteredValue == null || field === '') {
      return items;
    }
    /*
     If you want the value to be everything except the filtered value add a '!' to the beginning of the field
     ie. "!quantity"
     if the filteredValue is 0
     then this will return a list of everything NOT a quantity of 0.
     */
    let notMatch = false;
    if (field.charAt(0).match('!')) {
      notMatch = true;
      field = field.slice(1, field.length);
    }
    return items.filter(item => {
      const property: number|string|boolean = this.getProperty(item, field);
      if (property !== null && property !== undefined) {
        if (this.isString(property)) {
          if (!notMatch) {
            return (property as string).toLowerCase().match(new RegExp(filteredValue.toLowerCase().replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'))); // escape chars for regex
          } else{
            return !((property as string).toLowerCase().match(new RegExp(filteredValue.toLowerCase().replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')))); // escape chars for regex
          }
        }
        if (!isNaN(property)) {
          if (!notMatch) {
            if (typeof property === 'boolean') {
              return (property === filteredValue);
            } else {
              return (property === +filteredValue);
            }
          } else {
            if (typeof property === 'boolean') {
              return (property !== filteredValue);
            } else {
              return (property !== +filteredValue);
            }
          }
        }
      }
    });
  }
}
