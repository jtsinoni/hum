import {Pipe, PipeTransform} from '@angular/core';
import {UserProfile} from '../models/user-profile.model';
import {Organization} from '../models/organization.model';
import {LcNodeTree} from '../models/lc-NodeTree.model';
import {ServiceProvider} from '../models/service-provider.model';
import {ServiceProviderRef} from '../models/service-provider-ref.model';

@Pipe({
  name: 'filter'
})
export class DmlesFilterPipe implements PipeTransform {
  private isUserProfile(arg: any): arg is UserProfile {
    return arg.profileName !== undefined;
  }

  private isString(arg: any): arg is string {
    return arg.toLowerCase !== undefined;
  }

  private isServiceProviderRef(arg: ServiceProviderRef): arg is ServiceProviderRef {
    return arg.name !== undefined;
  }

  private isServiceProvider(arg: any): arg is ServiceProvider {
    return arg.consumer !== undefined;
  }

  private isOrganizationNodeTree(arg: any): arg is LcNodeTree<Organization> {
    return arg.data.organizationTypeRef !== undefined;
  }

  public transform(items: any[], searchText: string): any[] {
    if (!items || items.length === 0) {
      return [];
    }
    if (!searchText) {
      return items;
    }
    searchText = searchText.toLowerCase();

    return items.filter(item => {
      if (this.isString(item)) {
        return (item as string).toLowerCase().includes(searchText);
      }

      if (this.isUserProfile(item)) {
        return (item as UserProfile).profileName.toLowerCase().includes(searchText);
      }

      if (this.isServiceProvider(item)) {
        return (item as ServiceProvider).name.toLowerCase().includes(searchText);
      }

      if (this.isServiceProviderRef(item)) {
        return (item as ServiceProviderRef).name.toLowerCase().includes(searchText);
      }

      if (this.isOrganizationNodeTree(item)) {
        return this.findMatchingOrganization(item as LcNodeTree<Organization>, searchText);
      }

    });
  }

  private findMatchingOrganization(organization: LcNodeTree<Organization>, searchText: string) {
    if (organization.data.name.toLowerCase().includes(searchText)) {
      return true;
    } else {
      for (const child of organization.children) {
        return this.findMatchingOrganization(child, name);
      }
    }
  }

}
