import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'lcActiveInactive'
})
export class LcActiveInactivePipe implements PipeTransform {

  public transform(value: any, args?: any): any {
    let retVal: string = 'Active';
    if (value === null || value === '') {
      retVal = 'Unknown';
    } else if (value === false || value === 'N') {
      retVal = 'Inactive';
    }
    return retVal;
  }

}
