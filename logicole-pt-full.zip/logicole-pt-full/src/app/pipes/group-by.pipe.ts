import {Pipe, PipeTransform} from '@angular/core';

/***************************************************
 * Helpful Guide
 *
 * This will group and array based on a common attribute some of the data shares.
 * You tell the pipe the field to want to group the data by.
 * For example
 *
 * *ngFor="let group of peopleList | groupBy: 'lastName'"
 *
 * This produces an array of objects {key, value[key]}
 *
 * Where the key is the value of the field you wanted to groupBy and the value[] is the list of items that
 * are in the group.
 *
 * Sample data:
 * [{firstName:Jane,lastName:Doe},
 * {firstName:John, lastName:Doe},
 * {firstName:Sara, lastName:Smith},
 * {firstName:Larry, lastName:Smith}]
 *
 * example:
 * <div *ngFor="let group of peopleList | groupBy: 'lastName'">
 *     {{group.key}}   <----This will display the last name of the group
 *     <ul>
 *         <li *ngFor="let person of group.value">  <-----This loops through each person in the group that has the same last name
 *             {{person.firstName}}
 *          </li>
 *     </ul>
 * </div>
 *
 * ***Note: the groupBy can also handle nested fields.
 * For example
 * *ngFor="let group of peopleList | groupBy: 'address.city'"
 */

@Pipe({
  name: 'groupBy'
})
export class GroupByPipe implements PipeTransform {

  /*
   This is account for nested fields.
   ie "user.name"
   */
  private getProperty (value: { [key: string]: any}, key: string): number|string {
    if (value == null || typeof value !== 'object') {
      return undefined;
    }

    const keys: string[] = key.split('.');
    let result: any = value[keys.shift()];

    for (const key of keys) {
      if (result == null) { // check null or undefined
        return undefined;
      }

      result = result[key];
    }

    return result;
  }

  public transform(input: any, prop: string):  Array<any> {
    if (!input || input.length === 0) {
      return [];
    }

    const arr: { [key: string]: Array<any> } = {};

    for (const value of input) {
      const field: any = this.getProperty(value, prop);

      if (arr[field] === undefined || arr[field].length === 0) {
        arr[field] = [];
      }

      arr[field].push(value);
    }

    return Object.keys(arr).map(key => ({ key, 'value': arr[key] }));
  }

}
