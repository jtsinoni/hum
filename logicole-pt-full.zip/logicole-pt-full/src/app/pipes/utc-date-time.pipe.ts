import { Pipe, PipeTransform } from '@angular/core';
import {ContentConstants} from '@lc-constants/*';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'utcDateTimePipe'
})
export class UtcDateTimePipe extends DatePipe implements PipeTransform {

  public transform(value: any, args?: any): any {
    return super.transform(value, ContentConstants.FORMAT_DATE_TIME, '+0000');
  }

}
