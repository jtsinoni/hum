export class OrganizationConstants {
  public static readonly DEV: string = 'DEV';
  public static readonly ROOT: string = 'Root';
  public static readonly LOGICOLE: string = 'LogiCole';
  public static readonly DEV_ID: string = '5a0b41773eb8774c5d2328cc';
  public static readonly ROOT_ID: string = '58d0581bdf121dce611b7170';

}
