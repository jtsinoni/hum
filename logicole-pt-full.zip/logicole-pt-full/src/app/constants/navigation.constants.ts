export class NavigationConstants {

  public static readonly ASSEMBLAGE_NAV_ID: string = 'assemblage';
  public static readonly ORDERING_NAV_ID: string = 'ordering';
  public static readonly FULFILLMENT_NAV_ID: string = 'fulfillment';
  public static readonly RECEIVING_NAV_ID: string = 'receiving';
  public static readonly INVENTORY_NAV_ID: string = 'inventory';
  public static readonly FINANCE_NAV_ID: string = 'finance';

  public static readonly SSO_SAP_TEWLS_NAV_ID = 'sso-sap-tewls';

  public static readonly ABI_NAV_ID: string = 'abi';
  public static readonly CATALOG_NAV_ID: string = 'catalog';
  public static readonly COMMUNICATIONS_NAV_ID: string = 'communications';
  public static readonly EQUIPMENT_MANAGEMENT_NAV_ID: string = 'equipmentManagement';
  public static readonly REAL_PROPERTY_NAV_ID: string = 'property';
  public static readonly ORGANIZATION_NAV_ID: string = 'organization';
  public static readonly ACCESS_NAV_ID: string = 'access';
  public static readonly ADMIN_NAV_ID: string = 'jmlfdcAdmin';
  public static readonly REALESTATE_NAV_ID: string = 'realEstate';
  public static readonly SLEP_NAV_ID: string = 'slep';
  public static readonly BUSINESS_INTELLIGENCE_NAV_ID: string = 'businessIntelligence';
  public static readonly HELP_DEV_ID: string = 'helpDev';
  public static readonly MAINTENANCE_NAV_ID: string = 'maintenance';
  public static readonly WORK_ORDERS_NAV_ID: string = 'workOrders';
  public static readonly NOTIFICATIONS_NAV_ID: string = 'notifications';
  public static readonly UTIL_NAV_ID: string = 'utilities';
}
