
export class SearchConstants {

    public static readonly EVENT_MODULE_ABI: string = 'ABi';
    public static readonly EVENT_MODULE_BASE: string = 'BaseModule';
    public static readonly EVENT_MODULE_EQUIPMENT_RECORD: string = 'EquipmentRecord';

    // components that potentially have many specific instances
    public static readonly EVENT_TARGET_COMPONENT_CATEGORY: string = ' Category';
    public static readonly EVENT_TARGET_COMPONENT_CATEGORY_BREADCRUMB: string = ' CategoryBreadcrumb';
    public static readonly EVENT_TARGET_COMPONENT_FACET: string = ' Facet';

    // breadbox component
    public static readonly EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX: string = ' SelectedFacetOptionsBreadbox';

    // parent search component
    public static readonly EVENT_TARGET_COMPONENT_SEARCH: string = ' Search';

    // Category component methods
    public static readonly EVENT_TARGET_METHOD_CLEAR_ALL_CATEGORY_OPTION_SELECTIONS: string = 'clearCategoryOptionSelections';
    public static readonly EVENT_TARGET_METHOD_UPDATE_CATEGORY_OPTION_SELECTIONS_PER_BREADCRUMB_CLICK: string = 'updateCategoryOptionSelectionsPerBreadcrumbClick';

    // Category Breadcrumb component methods
    public static readonly EVENT_TARGET_METHOD_UPDATE_BREADCRUMB_PER_CATEGORY_OPTION_SELECTION: string = 'updateBreadcrumbPerCategoryOptionSelection';

    // Facet component methods
    public static readonly EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION: string = 'clearSelectedFacetOption';
    public static readonly EVENT_TARGET_METHOD_CLEAR_FILTERING_MATCH_STRING: string = 'clearFilteringMatchString';

    // Selected Facet Options Breadbox component methods
    public static readonly EVENT_TARGET_METHOD_CLEAR_ALL_SELECTED_FACET_OPTIONS: string = 'clearAllSelectedFacetOptions';
    public static readonly EVENT_TARGET_METHOD_REMOVE_SELECTED_FACET_OPTION: string = 'removeSelectedFacetOption';
    public static readonly EVENT_TARGET_METHOD_UPDATE_SELECTED_FACET_OPTIONS: string = 'updateSelectedFacetOptions';

    // Search component methods
    public static readonly EVENT_TARGET_METHOD_EXECUTE_SEARCH: string = 'executeSearch';
    public static readonly EVENT_TARGET_METHOD_INIT_SEARCH: string = 'initSearch';

    public static readonly NO_VALUE: string = '--- No Value ---';

    constructor() {
    }
}
