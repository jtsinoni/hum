export class ServiceLongName {

    public static readonly AIR_FORCE_LONG_NAME: string = 'Air Force';
    public static readonly ARMY_LONG_NAME: string = 'Army';
    public static readonly NAVY_LONG_NAME: string = 'Navy';
    constructor(){}
}
