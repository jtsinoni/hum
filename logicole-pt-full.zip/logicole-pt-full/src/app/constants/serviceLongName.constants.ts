
export class ServiceLongName {

    public static AIR_FORCE_LONG_NAME: string = 'Air Force';
    public static ARMY_LONG_NAME: string = 'Army';
    public static NAVY_LONG_NAME: string = 'Navy';
    constructor() {}
}
