export class ProfileStatusConstants {

  public static readonly STATUS_ACTIVE: string = 'ACTIVE';
  public static readonly STATUS_INACTIVE: string = 'INACTIVE';
  public static readonly STATUS_DELETED: string = 'DELETED';
  public static readonly STATUS_EXPIRED: string = 'EXPIRED';
  public static readonly STATUS_LOCKED: string = 'LOCKED';
  public static readonly STATUS_RELOCKED: string = 'RELOCKED';
  public static readonly STATUS_PENDING: string = 'PENDING';
  public static readonly STATUS_SUSPENDED: string = 'SUSPENDED';

  public static readonly STATUS_DENIED: string = 'DENIED';
  public static readonly STATUS_REJECTED: string = 'REJECTED';
  public static readonly STATUS_CANCELLED: string = 'CANCELLED';

  constructor() {
  }
}
