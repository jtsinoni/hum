
export class ServiceShortName {

    public static AIR_FORCE_SHORT_NAME: string = 'DF';
    public static ARMY_SHORT_NAME: string = 'DA';
    public static NAVY_SHORT_NAME: string = 'NV';
    constructor() {}
}
