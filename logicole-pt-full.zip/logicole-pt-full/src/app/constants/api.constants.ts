import {ServiceToken} from '../services/service-token';

export class ApiConstants {

  // Note: Keep these lines sorted to avoid merge conflicts
  // Injectable tokens

  public static readonly DUE_IN_API = new ServiceToken('dueIn/');
  public static readonly FINANCE_ADMIN_API = new ServiceToken('financeAdmin/');
  public static readonly FINANCE_REFERENCE_DATA_API = new ServiceToken('financeReferenceData/');
  public static readonly FINANCE_VALIDATION_API = new ServiceToken('financeValidation/');
  public static readonly FINANCE_ROLLOVER_API = new ServiceToken('financeRollover/');
  public static readonly PURCHASE_CARD_API = new ServiceToken('purchaseCard/');
  public static readonly PURCHASE_CARD_REGISTER_API = new ServiceToken('purchaseCardRegister/');
  public static readonly INVENTORY_API = new ServiceToken('inventory/');
  public static readonly LOCATION_API = new ServiceToken('location/');
  public static readonly EXCESS_API = new ServiceToken('excess/');
  public static readonly ACCOUNTABILITY_API = new ServiceToken('accountability/');
  public static readonly AUDIT_API = new ServiceToken('audit/');
  public static readonly RETURNS_API = new ServiceToken('returns/');
  public static readonly TRANSPORTATION_API = new ServiceToken('transportation/');
  public static readonly PLANNING_API = new ServiceToken('planning/');

  public static readonly FULFILLMENT_API = new ServiceToken('fulfillment/');
  public static readonly DELIVERY_API = new ServiceToken('delivery/');
  public static readonly CART_API = new ServiceToken('cart/');
  public static readonly ORDER_API = new ServiceToken('order/');
  public static readonly BUYER_API = new ServiceToken('buyer/');
  public static readonly RECEIPT_API = new ServiceToken('receipt/');
  public static readonly RECEIPT_DETAIL_API = new ServiceToken('receiptDetail/');
  public static readonly SELLER_API = new ServiceToken('seller/');
  public static readonly SERVICE_PROVIDER_API = new ServiceToken('organization/');
  public static readonly SITE_API = new ServiceToken('site/');
  public static readonly WISHLIST_API = new ServiceToken('wishlist/');


  public static readonly APPLICATION_NOTIFICATION_API = new ServiceToken('notification/');
  public static readonly ABI_API = new ServiceToken('abi/');
  public static readonly ABI_DELTA_API = new ServiceToken('abi/delta/');
  public static readonly ABI_FILE_MANAGER_API = new ServiceToken('abi/filemanager/');
  public static readonly ABI_PRODUCTION_API = new ServiceToken('production/');
  public static readonly ABI_SITE_CATALOG_API = new ServiceToken('sitecatalog/');
  public static readonly ABI_CATALOG_API = new ServiceToken('abi/catalog/');
  public static readonly ABI_ITEM_API = new ServiceToken('abi/item/');
  public static readonly ABI_ITEM_CHANGE_HISTORY_API = new ServiceToken('abi/itemChangeHistory/');
  public static readonly ABI_COLLECTION_MANAGER_API = new ServiceToken('abi/collectionManager/');
  public static readonly ABI_STAGING_API = new ServiceToken('abi/staging/');
  public static readonly ABI_STAGING_JOIN_API = new ServiceToken('abi/staging/join/');
  public static readonly ABI_STAGING_LOOKUP_API = new ServiceToken('abi/staging/lookup/');
  public static readonly ABI_TASK_HISTORY_MANAGER_API = new ServiceToken('abi/taskHistory/');
  public static readonly ABI_TAXONOMY_API = new ServiceToken('abi/taxonomy/');
  public static readonly ABI_STAGING_MOVE_RECORDS_API = new ServiceToken('abi/staging/moveRecords/');
  public static readonly ABI_CONFIGURATION_MANAGER_API = new ServiceToken('abi/configurationManager/');
  public static readonly ABI_TO_SITE_RECORD_LINK_MANAGER_API = new ServiceToken('abi/abiToSiteRecordLinkManager/');
  public static readonly ASSEMBLAGE_API = new ServiceToken('assemblage/');
  public static readonly ASSEMBLAGE_LOOKUP_API = new ServiceToken('assemblageLookup/');
  public static readonly ASSEMBLAGE_STAGING_API = new ServiceToken('assemblageStaging/');
  public static readonly ASSEMBLAGE_ALLOWANCE_API = new ServiceToken('allowance/');
  public static readonly ASSEMBLAGE_ALLOWANCE_IMPORT_API = new ServiceToken('allowanceImport/');
  public static readonly ASSEMBLAGE_SHIPMENT_API = new ServiceToken('assemblageShipment/');


  public static readonly ASSET_CLASSIFICATION_API = new ServiceToken('assetClassification/');
  public static readonly ASSET_DATA_IMPORT_PROCEDURES_API = new ServiceToken('assetDataImport/');
  public static readonly ASSET_GROUP_API = new ServiceToken('assetGroup/');
  public static readonly ASSET_MEC_API = new ServiceToken('assetMec/');
  public static readonly ASSET_RECORD_API = new ServiceToken('asset/');
  public static readonly ASSET_MAINTENANCE_PROCEDURES_API = new ServiceToken('assetMaintenanceProcedure/');
  public static readonly ASSET_MAINTENANCE_SCHEDULE_API = new ServiceToken('assetSchedule/');
  public static readonly ASSET_BUSINESS_CONTACT_API = new ServiceToken('businessContact/');
  public static readonly ASSET_LOOKUP_API = new ServiceToken('assetLookup/');
  public static readonly BUSINESS_INTELLIGENCE_API = new ServiceToken('businessintelligence/');
  public static readonly CATALOG_DATALOAD_API = new ServiceToken('catalogDataLoad/');
  public static readonly CATALOG_ITEM_IMPORT_DATA_API = new ServiceToken('abi/item/catalogdata');
  public static readonly ITEM_TASK_REQUEST_API = new ServiceToken('abi/item/taskrequests');
  public static readonly TRANSACTION_HISTORY_API = new ServiceToken('businessEventHistory/');
  public static readonly MAINTENANCE_PLAN_API = new ServiceToken('maintenancePlan/');
  public static readonly TECHNICIAN_API = new ServiceToken('technician/');
  public static readonly MAINTENANCE_TEAM_API = new ServiceToken('maintenanceTeam/');
  public static readonly MAINTENANCE_PROCEDURE_API = new ServiceToken('maintenanceProcedure/');
  public static readonly MAINTENANCE_ACTIVITY_API = new ServiceToken('maintenanceActivity/');

  public static readonly COBIE_API = new ServiceToken('cobie/');
  public static readonly COMMUNICATIONS_ADMIN_API = new ServiceToken('communicationsAdmin/');
  public static readonly COMMUNICATIONS_TRANSMIT_API = new ServiceToken('communicationsTransmit/');
  public static readonly COMMUNICATIONS_SUBMIT_REQUEST_API = new ServiceToken('communicationsSubmitRequest/');
  public static readonly COMMUNICATIONS_EHR_API = new ServiceToken('communicationsEhr/');
  public static readonly CUSTODIAN_API = new ServiceToken('custodian/');
  public static readonly CUSTOM_FIELD_API = new ServiceToken('customField/');
  public static readonly CATALOG_API = new ServiceToken('catalog/');
  public static readonly CATALOG_CHANGE_HISTORY_API = new ServiceToken('catalogChangeHistory/');
  public static readonly CATALOG_NOTES_API = new ServiceToken('catalogNotes/');
  public static readonly DMLSS_API = new ServiceToken('dmlss/');
  public static readonly DRAWING_API = new ServiceToken('drawing/');
  public static readonly DRAWING_LOOKUP_API = new ServiceToken('drawinglookup/');
  public static readonly EHR_EXTERNAL_API = new ServiceToken('ehr/external/');
  public static readonly EHR_INTERNAL_API = new ServiceToken('ehr/internal/');
  public static readonly EQUIPMENT_REQUEST_API = new ServiceToken('equipmentRequest/');
  public static readonly EQUIPMENT_API = new ServiceToken('equipment/');
  public static readonly FACILITY_API = new ServiceToken('facility/');
  public static readonly FILE_MANAGER_API = new ServiceToken('fileManagerAdmin/');
  public static readonly HELP_API = new ServiceToken('help/');
  public static readonly INSTALLATION_API = new ServiceToken('realProperty/');
  public static readonly ITEM_NOTES_API = new ServiceToken('itemNotes/');
  public static readonly LEGACY_DMLSS_HISTORY_API = new ServiceToken('legacyDmlssHistory/');
  public static readonly MAXIMO_EXTERNAL_API = new ServiceToken('maximo/external/');
  public static readonly MEDICAL_EQUIPMENT_API = new ServiceToken('medicalEquipment/');
  public static readonly OFFER_API = new ServiceToken('offer/');
  public static readonly ORG_API = new ServiceToken('organization/');
  public static readonly ORG_HIER_API = new ServiceToken('organizationHierdata/')
  public static readonly ORG_TREE_STRUCTURE_API = new ServiceToken('organizationTreeStructure/');
  public static readonly BUSINESS_SERVICE_DEFINITION_API = new ServiceToken('businessServiceDefinition/');
  public static readonly ROLE_API = new ServiceToken('role/');
  public static readonly PERMISSION_API = new ServiceToken('permission/');
  public static readonly PROVIDER_API = new ServiceToken('provider/');
  public static readonly SLEP_API = new ServiceToken('slep/');
  public static readonly SYSTEM_API = new ServiceToken('system/');
  public static readonly SYSTEM_CONFIGURATION_API = new ServiceToken('systemConfiguration/');
  public static readonly SYSTEM_RECURRING_FUNCTION_API = new ServiceToken('recurringFunction/');
  public static readonly SYSTEM_APP_HISTORY = new ServiceToken('appHistory/');
  public static readonly SYSTEM_NOTIFICATION_API = new ServiceToken('systemNotification/');
  public static readonly UNREGISTERED_USER = new ServiceToken('UnregisteredUser');
  public static readonly USER_API = new ServiceToken('user/');
  public static readonly INVITATION_API = new ServiceToken('invitation/');
  public static readonly PRODUCT_API = new ServiceToken('product/');
  public static readonly PROJECT_API = new ServiceToken('project/');
  public static readonly PROJECT_LOOKUP = new ServiceToken('projectlookup/');
  public static readonly REALPROPERTY_AUTHORITATIVE_DATA_API = new ServiceToken('realPropertyAuthoritativeData/');
  public static readonly REALPROPERTY_API = new ServiceToken('realProperty/');
  public static readonly REPORT_API = new ServiceToken('report/');
  public static readonly REQUIREMENTS_API = new ServiceToken('requirement/');
  public static readonly REQUIREMENTS_LOOKUP_API = new ServiceToken('requirementlookup/');
  public static readonly SECTION_API = new ServiceToken('section/');
  public static readonly SPACE_API = new ServiceToken('spacemanagement/');
  public static readonly SPACE_LOOKUP_API = new ServiceToken('spacelookup/');
  public static readonly COMMUNICATIONS_TRANSLATION = new ServiceToken('communicationsTranslation/');
  public static readonly SYSTEM_FEATURE_FLAG_API = new ServiceToken('systemFeatureFlag/');
  public static readonly TAG_MANAGEMENT_API = new ServiceToken('tag/');
  public static readonly USER_REQUEST_API = new ServiceToken('userRequest/');
  public static readonly USER_FEATURE_FLAG_API = new ServiceToken('userFeatureFlag/');
  public static readonly CORE_WORK_ORDERS_API = new ServiceToken('coreWorkOrder/');
  public static readonly WORK_ORDERS_API = new ServiceToken('workOrder/');
  public static readonly MEDICAL_EQUIPMENT_WORK_ORDERS_API = new ServiceToken('medicalEquipmentWorkOrder/');
  public static readonly SERVICE_REQUESTS_API = new ServiceToken('serviceRequest/');
  public static readonly SECTIONS_LOOKUP_API = new ServiceToken('sectionlookup/');

  public static readonly CATALOG_LOOKUP_API = new ServiceToken('catalogLookup/');

  public static readonly LC_CLIENT_ID: string = 'LogiCole';
  public static readonly LC_CALLER_HANDLES_ERR: string = 'CallerHandlesError';
  public static readonly LC_USER_KEY: string = 'lc-user';
  public static readonly LC_TOKEN_KEY: string = 'lc-token-key';

  public static readonly IAS_TOKEN_KEY: string = 'ias-token-key';
  public static readonly IAS_TOKEN_ID: string = 'id_token=';
  public static readonly IAS_STATE_URL_PARAM: string = '&state=';
  public static readonly AUTH_NONCE: string = 'auth-nonce';
  public static readonly AUTH_STATE: string = 'auth-state';

  public static readonly LC_ROUTE_KEY: string = 'lc-route-key';

  public static readonly LC_CONTENT_TYPE_HEADER_KEY: string = 'Content-Type';
  public static readonly LC_ACCEPT_HEADER_KEY: string = 'Accept';
  public static readonly LC_ACCEPT_TEXT_PLAIN_VALUE: string  = 'text/plain';
  public static readonly LC_CONTENT_TYPE_HEADER_XML_VALUE: string = 'application/xml';
  public static readonly LC_CONTENT_TYPE_HEADER_JSON_VALUE: string = 'application/json';
  public static readonly X_IAS_JWT_HEADER: string = 'X-IAS-JWT';

  public static readonly DAAS_EXTERNAL_API = new ServiceToken('daas/external/');

  public static readonly SSO_API = new ServiceToken('sso/');
}
