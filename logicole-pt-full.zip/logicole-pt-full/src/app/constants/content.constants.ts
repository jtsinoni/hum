export class ContentConstants {
  public static readonly COMMENT_SUCCESSFULL_DELETE: string = 'Comment Successfully deleted.';
  public static readonly ERR_MSG: string = 'An error occurred, please try again later. If this error persists, contact the system admin.';

  // Format for date pipes
  public static readonly FORMAT_DATE: string = 'yyyy-MM-dd';
  public static readonly FORMAT_DATE_TIME: string = 'yyyy-MM-dd HH:mm:ss';

  public static readonly FORMAT_UTC_DATE: string = 'yyyy-MM-dd: UTC ';
  public static readonly FORMAT_UTC_DATE_TIME: string = 'date: yyyy-MM-dd hh:mm:ss';


  // Format for datepicker inputs
  public static readonly STANDARD_DATE_FORMAT: string = 'YYYY-MM-DD';
  public static readonly STANDARD_DATE_PLACEHOLDER: string = 'yyyy-mm-dd';

  public static readonly ACTIVE: string = 'ACTIVE';
  public static readonly LOCKED: string = 'Locked';
  public static readonly PENDING: string = 'Pending';
  public static readonly SUSPENDED: string = 'Suspended';
  public static readonly EMAIL_SENT_TO_MANAGER: string = 'An email notification has been sent to the access manager.';
  public static readonly EMAIL_SENT_TO_USER: string = 'An email notification has been sent to the user.';
  public static readonly UNABLE_TO_EMAIL_USER: string = 'Unable send email notification to the user.';
  public static readonly UNABLE_TO_SEND_EMAIL_TO_MANAGER: string = 'Unable to send an email notification to the Access Manager.';
}
