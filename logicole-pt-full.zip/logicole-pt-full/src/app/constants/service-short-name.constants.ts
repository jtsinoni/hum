export class ServiceShortName {

    public static readonly AIR_FORCE_SHORT_NAME: string = 'DF';
    public static readonly ARMY_SHORT_NAME: string = 'DA';
    public static readonly NAVY_SHORT_NAME: string = 'NV';
    constructor(){}
}
