import {NavigationConstants} from './navigation.constants';
import {ElementConstants} from './element.constants';
import {Injectable} from '@angular/core';

export interface RouteInfo {
  url: string;
  name: string; // dotted state
  perm?: string; // permission string
  breadcrumb?: string; // should have this unless in login area
  navigationId?: string; // dropdown parent area (NavigationConstant Order, Inventory, etc)
  shown?: boolean; // show or hide dropdown
  selectionText?: string; // dropdown text TODO use breadcrumb text ?
  dividerFollows?: boolean; // dropdown divider
  parent?: RouteInfo; // previous page: all except HOME_ROOT should have one
  clickEvent?: any; // a function name that is called on click (must reside in main-nav-selector.component.ts),
}

@Injectable()
export class RouteConstants {

  public static readonly LOGIN_ROOT: RouteInfo = {
    url: '/login',
    name: 'login'
  };
  public static readonly LOGIN: RouteInfo = {
    url: '/loginForm',
    name: 'login.loginForm',
    breadcrumb: 'Login',
    parent: RouteConstants.LOGIN_ROOT
  };
  public static readonly CHOOSE_PROFILE: RouteInfo = {
    url: '/chooseProfile',
    name: 'login.chooseProfile',
    breadcrumb: 'Choose Profile',
    parent: RouteConstants.LOGIN_ROOT
  };
  public static readonly SINGLE_SIGN_ON: RouteInfo = {
    url: '/singleSignOn',
    name: 'login.singleSignOn',
    breadcrumb: 'Single Sign On',
    parent: RouteConstants.LOGIN_ROOT,
  };
  public static readonly REQUEST_PKI_DN_UPDATE: RouteInfo = {
    url: '/requestPkiDnUpdate',
    name: 'login.updateCAC',
    breadcrumb: 'Update CAC',
    parent: RouteConstants.LOGIN_ROOT
  };
  public static readonly UPDATE_PKI_DN: RouteInfo = {
    url: '/updatePkiDn/?updateId',
    name: 'login.updatePkiDN',
    breadcrumb: 'Update PKIDN',
    parent: RouteConstants.LOGIN_ROOT
  };
  public static readonly ACCESSIBILITY: RouteInfo = {
    url: '/accessibility',
    name: 'login.accessibility',
    breadcrumb: 'Accessibility',
    parent: RouteConstants.LOGIN_ROOT
  };
  public static readonly USER_AGREEMENT: RouteInfo = {
    url: '/userAgreement',
    name: 'login.user-agreement',
    breadcrumb: 'User Agreement',
    parent: RouteConstants.LOGIN_ROOT
  };
  public static readonly INVITATION: RouteInfo = {
    url: '/invitation/?invitationId',
    name: 'login.invitation',
    breadcrumb: 'Invitation',
    parent: RouteConstants.LOGIN_ROOT
  };
  public static readonly GROUP_INVITATION: RouteInfo = {
    url: '/groupInvitation/?invitationId',
    name: 'login.groupInvitation',
    breadcrumb: 'Group Invitation',
    parent: RouteConstants.LOGIN_ROOT
  };
  public static readonly INVITATION_INFO: RouteInfo = {
    url: '/invitationInformation',
    name: 'login.invitationInfo',
    breadcrumb: 'Invitation Information',
    parent: RouteConstants.LOGIN_ROOT
  };
  public static readonly USER_REQUEST_CANDIDATE_PORTAL: RouteInfo = {
    url: '/user-request-candidate-portal/?userRequestId',
    name: 'login.userRequest',
    breadcrumb: 'User Request Candidate Portal',
    parent: RouteConstants.LOGIN_ROOT
  };
  public static readonly USER_REQUEST_INFO: RouteInfo = {
    url: '/userRequestInformation',
    name: 'login.userRequestInfo',
    breadcrumb: 'User Request Information',
    parent: RouteConstants.LOGIN_ROOT
  };

  public static readonly HOME_ROOT: RouteInfo = {
    url: '/home',
    name: 'home',
    breadcrumb: 'Home',
    shown: true
  };
  public static readonly MY_DASHBOARD: RouteInfo = {
    url: '/dashboard',
    name: 'home.myDashboard',
    breadcrumb: 'Dashboard',
    parent: RouteConstants.HOME_ROOT
  };
  public static readonly ABOUT: RouteInfo = {
    url: '/about',
    name: 'home.about',
    breadcrumb: 'About',
    parent: RouteConstants.HOME_ROOT
  };
  public static readonly HELP: RouteInfo = {
    url: '/help',
    name: 'home.help',
    breadcrumb: 'Help',
    parent: RouteConstants.HOME_ROOT
  };
  public static readonly HELP_ROOT: RouteInfo = {
    url: '/helpDev',
    name: 'home.helpDev',
    breadcrumb: 'Help Development',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.HELP_DEV_ID
  };
  public static readonly HELP_BUILDER: RouteInfo = {
    url: '/helpBuilderView',
    name: 'home.helpDev.helpBuilder',
    breadcrumb: 'Context Map Editor',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.HELP_DEV_ID,
    perm: ElementConstants.HELP_BUILDER_VIEW,
    selectionText: 'Context Map Editor',
    shown: false
  };
  public static readonly HELP_TOC_EDITOR: RouteInfo = {
    url: '/helpTocEditorView',
    name: 'home.helpDev.tocEditor',
    breadcrumb: 'TOC Editor',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.HELP_DEV_ID,
    perm: ElementConstants.HELP_TOC_EDITOR_VIEW,
    selectionText: 'TOC Editor',
    shown: false
  };
  public static readonly HELP_CONTENT_REPORT: RouteInfo = {
    url: '/helpContentReportView',
    name: 'home.helpDev.helpContentReport',
    breadcrumb: 'Help Content Report',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.HELP_DEV_ID,
    perm: ElementConstants.HELP_CONTENT_REPORT_VIEW,
    selectionText: 'Help Content Report',
    shown: false
  };
  public static readonly HELP_CONTEXT_MAP_REPORT: RouteInfo = {
    url: '/helpContextMapReportView',
    name: 'home.helpDev.helpContextMapReport',
    breadcrumb: 'Help Context Map Report',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.HELP_DEV_ID,
    perm: ElementConstants.HELP_CONTEXT_MAP_REPORT_VIEW,
    selectionText: 'Help Context Map Report',
    shown: false
  };
  public static readonly HELP_CENTER_IMPORT_EXPORT: RouteInfo = {
    url: '/helpCenterImportExportView',
    name: 'home.helpDev.importExport',
    breadcrumb: 'Help Center Import/Export',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.HELP_DEV_ID,
    perm: ElementConstants.HELP_CENTER_IMPORT_EXPORT,
    selectionText: 'Help Center Import/Export',
    shown: false
  };
  public static readonly HELP_CONTENT_UPLOAD: RouteInfo = {
    url: '/contentUploadView',
    name: 'home.helpDev.contentUpload',
    breadcrumb: 'Help Content Upload',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.HELP_DEV_ID,
    perm: ElementConstants.HELP_UPLOAD_FILE_VIEW,
    selectionText: 'Help Content Upload',
    shown: false
  };
  public static readonly HELP_ASSET_EDIT: RouteInfo = {
    url: '/assetEditView',
    name: 'home.helpDev.assetEdit',
    breadcrumb: 'Help Asset Edit',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.HELP_DEV_ID,
    perm: ElementConstants.HELP_ASSET_EDITOR_VIEW,
    selectionText: 'Help Asset Edit',
    shown: false
  };
  public static readonly HELP_RELEASE_EDITOR: RouteInfo = {
    url: '/releaseEditView',
    name: 'home.helpDev.releaseEdit',
    breadcrumb: 'Help Release Edit',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.HELP_DEV_ID,
    perm: ElementConstants.HELP_RELEASE_EDITOR_VIEW,
    selectionText: 'Help Release Edit',
    shown: false
  };
  public static readonly HELP_PACKAGE_UPLOAD: RouteInfo = {
    url: '/packageUploadView',
    name: 'home.helpDev.packageUpload',
    breadcrumb: 'Help Package Upload',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.HELP_DEV_ID,
    perm: ElementConstants.HELP_UPLOAD_FILE_VIEW,
    selectionText: 'Help Package Upload',
    shown: false
  };

  public static readonly MY_PROFILE: RouteInfo = {
    url: '/myProfile',
    name: 'home.myProfile',
    breadcrumb: 'My Profile',
    parent: RouteConstants.HOME_ROOT
  };

  public static readonly SERVICE_REQUEST_SEARCH: RouteInfo = {
    url: '/serviceRequests',
    name: 'home.serviceRequests',
    breadcrumb: 'Service Requests',
    parent: RouteConstants.HOME_ROOT
  };
  public static readonly SERVICE_REQUEST_NEW: RouteInfo = {
    url: '/new',
    name: 'home.serviceRequests.new',
    breadcrumb: 'New Service Request',
    parent: RouteConstants.SERVICE_REQUEST_SEARCH
  };
  public static readonly SERVICE_REQUEST_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.serviceRequests.details',
    breadcrumb: 'Service Request Details',
    parent: RouteConstants.SERVICE_REQUEST_SEARCH
  };

  public static readonly LOADING: RouteInfo = {
    url: '/loading',
    name: 'home.loading',
    parent: RouteConstants.HOME_ROOT
  };

  public static readonly ACCESS_ROOT: RouteInfo = {
    url: '/access',
    name: 'home.access',
    breadcrumb: 'Access Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ACCESS_NAV_ID
  };
  public static readonly ACCESS_USER_REQUEST_MANAGEMENT: RouteInfo = {
    url: '/userRequestManagement',
    name: 'home.access.userRequestManagement',
    parent: RouteConstants.ACCESS_ROOT,
    breadcrumb: 'User Request Management',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_REQUEST_VIEW,
    selectionText: 'User Request Management'
  };
  public static readonly ACCESS_USER_REQUEST: RouteInfo = {
    url: '/userRequest',
    name: 'home.access.userRequestManagement.userRequest',
    parent: RouteConstants.ACCESS_USER_REQUEST_MANAGEMENT,
    breadcrumb: 'User Request',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_REQUEST_VIEW,
    selectionText: 'User Request'
  };
  public static readonly ACCESS_PROFILE_MANAGEMENT: RouteInfo = {
    url: '/profileManagement',
    name: 'home.access.profileManagement',
    parent: RouteConstants.ACCESS_ROOT,
    breadcrumb: 'Profile Management',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Profile Management'
  };
  public static readonly ACCESS_NEW_INVITATION: RouteInfo = {
    url: '/newInvitation',
    name: 'home.access.profileManagement.newInvitation',
    parent: RouteConstants.ACCESS_PROFILE_MANAGEMENT,
    breadcrumb: 'New Invitation',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'New Invitation'
  };
  public static readonly ACCESS_NEW_INVITATION_ACCESS: RouteInfo = {
    url: '/access',
    name: 'home.access.profileManagement.newInvitation.access',
    parent: RouteConstants.ACCESS_NEW_INVITATION,
    breadcrumb: 'Access',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Access'
  };
  public static readonly ACCESS_NEW_INVITATION_ROLES: RouteInfo = {
    url: '/roles',
    name: 'home.access.profileManagement.newInvitation.roles',
    parent: RouteConstants.ACCESS_NEW_INVITATION_ACCESS,
    breadcrumb: 'Roles',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Roles'
  };
  public static readonly ACCESS_NEW_INVITATION_CONFIRM: RouteInfo = {
    url: '/confirmation',
    name: 'home.access.profileManagement.newInvitation.confirm',
    parent: RouteConstants.ACCESS_NEW_INVITATION_ROLES,
    breadcrumb: 'Confirmation',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Confirmation'
  };
  public static readonly ACCESS_NEW_GROUP_INVITATION: RouteInfo = {
    url: '/newGroupInvitation',
    name: 'home.access.profileManagement.newGroupInvitation',
    parent: RouteConstants.ACCESS_PROFILE_MANAGEMENT,
    breadcrumb: 'New Group Invitation',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'New Group Invitation'
  };
  public static readonly ACCESS_NEW_GROUP_INVITATION_ACCESS: RouteInfo = {
    url: '/access',
    name: 'home.access.profileManagement.newGroupInvitation.access',
    parent: RouteConstants.ACCESS_NEW_GROUP_INVITATION,
    breadcrumb: 'Access',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Access'
  };
  public static readonly ACCESS_NEW_GROUP_INVITATION_ROLES: RouteInfo = {
    url: '/roles',
    name: 'home.access.profileManagement.newGroupInvitation.roles',
    parent: RouteConstants.ACCESS_NEW_GROUP_INVITATION_ACCESS,
    breadcrumb: 'Roles',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Roles'
  };
  public static readonly ACCESS_NEW_GROUP_INVITATION_CONFIRM: RouteInfo = {
    url: '/confirmation',
    name: 'home.access.profileManagement.newGroupInvitation.confirm',
    parent: RouteConstants.ACCESS_NEW_GROUP_INVITATION_ROLES,
    breadcrumb: 'Confirmation',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Confirmation'
  };
  public static readonly ACCESS_NEW_GROUP_INVITATION_URL: RouteInfo = {
    url: '/newGroupInvitationUrl',
    name: 'home.access.profileManagement.newGroupInvitationUrl',
    parent: RouteConstants.ACCESS_PROFILE_MANAGEMENT,
    breadcrumb: 'Group Invitation URL',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Group Invitation URL'
  };
  public static readonly ACCESS_PROFILE: RouteInfo = {
    url: '/profile',
    name: 'home.access.profileManagement.profile',
    parent: RouteConstants.ACCESS_PROFILE_MANAGEMENT,
    breadcrumb: 'Profile',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Profile'
  };
  public static readonly ACCESS_PROFILE_IDENTIFICATION: RouteInfo = {
    url: '/identification',
    name: 'home.access.profileManagement.profile.identification',
    parent: RouteConstants.ACCESS_PROFILE,
    breadcrumb: 'Identification',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Identification'
  };
  public static readonly ACCESS_PROFILE_ACCESS: RouteInfo = {
    url: '/access',
    name: 'home.access.profileManagement.profile.access',
    parent: RouteConstants.ACCESS_PROFILE,
    breadcrumb: 'Access',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Access'
  };
  public static readonly ACCESS_PROFILE_ROLES: RouteInfo = {
    url: '/roles',
    name: 'home.access.profileManagement.profile.roles',
    parent: RouteConstants.ACCESS_PROFILE,
    breadcrumb: 'Roles',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Roles'
  };
  public static readonly ACCESS_PROFILE_STATUS: RouteInfo = {
    url: '/status',
    name: 'home.access.profileManagement.profile.status',
    parent: RouteConstants.ACCESS_PROFILE,
    breadcrumb: 'Status',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Status'
  };
  public static readonly ACCESS_PROFILE_INVITATION: RouteInfo = {
    url: '/invitation',
    name: 'home.access.profileManagement.profile.invitation',
    parent: RouteConstants.ACCESS_PROFILE,
    breadcrumb: 'Invitation',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Invitation'
  };
  public static readonly ACCESS_GROUP_INVITATION: RouteInfo = {
    url: '/groupInvitation',
    name: 'home.access.profileManagement.groupInvitation',
    parent: RouteConstants.ACCESS_PROFILE_MANAGEMENT,
    breadcrumb: 'Group Invitation',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Group Invitation'
  };
  public static readonly ACCESS_GROUP_INVITATION_INFORMATION: RouteInfo = {
    url: '/information',
    name: 'home.access.profileManagement.groupInvitation.information',
    parent: RouteConstants.ACCESS_GROUP_INVITATION,
    breadcrumb: 'Information',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Information'
  };
  public static readonly ACCESS_GROUP_INVITATION_ACCESS: RouteInfo = {
    url: '/access',
    name: 'home.access.profileManagement.groupInvitation.access',
    parent: RouteConstants.ACCESS_GROUP_INVITATION,
    breadcrumb: 'Access',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Access'
  };
  public static readonly ACCESS_GROUP_INVITATION_ROLES: RouteInfo = {
    url: '/roles',
    name: 'home.access.profileManagement.groupInvitation.roles',
    parent: RouteConstants.ACCESS_GROUP_INVITATION,
    breadcrumb: 'Roles',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'Roles'
  };
  public static readonly ACCESS_GROUP_PROFILE: RouteInfo = {
    url: '/userProfile',
    name: 'home.access.profileManagement.groupInvitation.userProfile',
    parent: RouteConstants.ACCESS_GROUP_INVITATION,
    breadcrumb: 'User Profile',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.USER_PROFILE_MANAGEMENT,
    selectionText: 'User Profile'
  };
  public static readonly ACCESS_PERMISSION_MANAGEMENT: RouteInfo = {
    url: '/permissionManagement',
    name: 'home.access.permissionManagement',
    parent: RouteConstants.ACCESS_ROOT,
    breadcrumb: 'Permission Management',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.PERMISSION_MANAGEMENT
  };
  public static readonly ACCESS_PERMISSIONS: RouteInfo = {
    url: '/permissions',
    name: 'home.access.permissionManagement.permissions',
    parent: RouteConstants.ACCESS_PERMISSION_MANAGEMENT,
    breadcrumb: 'Permissions',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.PERMISSION_MANAGEMENT,
    selectionText: 'Permission Management',
  };
  public static readonly ACCESS_NEW_PERMISSION: RouteInfo = {
    url: '/newPermission',
    name: 'home.access.permissionManagement.permissions.newPermission',
    parent: RouteConstants.ACCESS_PERMISSIONS,
    breadcrumb: 'New Permission',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.PERMISSION_MANAGEMENT
  };
  public static readonly ACCESS_PERMISSION_DETAILS: RouteInfo = {
    url: '/permissionDetails',
    name: 'home.access.permissionManagement.permissions.permissionDetails',
    parent: RouteConstants.ACCESS_PERMISSIONS,
    breadcrumb: 'Permission Details',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.PERMISSION_MANAGEMENT
  };
  public static readonly ACCESS_STATES: RouteInfo = {
    url: '/states',
    name: 'home.access.permissionManagement.states',
    parent: RouteConstants.ACCESS_PERMISSION_MANAGEMENT,
    breadcrumb: 'States',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.PERMISSION_MANAGEMENT
  };
  public static readonly ACCESS_ENDPOINTS: RouteInfo = {
    url: '/endpoints',
    name: 'home.access.permissionManagement.endpoints',
    parent: RouteConstants.ACCESS_PERMISSION_MANAGEMENT,
    breadcrumb: 'Endpoints',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.PERMISSION_MANAGEMENT
  };
  public static readonly ACCESS_ELEMENTS: RouteInfo = {
    url: '/elements',
    name: 'home.access.permissionManagement.elements',
    parent: RouteConstants.ACCESS_PERMISSION_MANAGEMENT,
    breadcrumb: 'Elements',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.PERMISSION_MANAGEMENT,
    selectionText: 'Elements',
  };

  public static readonly ACCESS_REPORTS: RouteInfo = {
    url: '/bireports',
    name: 'home.access.permissionManagement.bireports',
    parent: RouteConstants.ACCESS_PERMISSION_MANAGEMENT,
    breadcrumb: 'BI Reports',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.PERMISSION_MANAGEMENT,
    selectionText: 'Reports',
  };

  public static readonly ACCESS_ROLE_MANAGEMENT: RouteInfo = {
    url: '/roleManagement',
    name: 'home.access.roleManagement',
    parent: RouteConstants.ACCESS_ROOT,
    breadcrumb: 'Role Management',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.ROLE_MANAGEMENT,
    selectionText: 'Role Management',
  };
  public static readonly ACCESS_ROLE_DETAILS: RouteInfo = {
    url: '/roleDetails',
    name: 'home.access.roleManagement.details',
    parent: RouteConstants.ACCESS_ROLE_MANAGEMENT,
    breadcrumb: 'Role Details',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.ROLE_MANAGEMENT,
    selectionText: 'Role Details',
  };
  public static readonly ACCESS_NEW_ROLE: RouteInfo = {
    url: '/newRole',
    name: 'home.access.roleManagement.newRole',
    parent: RouteConstants.ACCESS_ROLE_MANAGEMENT,
    breadcrumb: 'New Role',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.ROLE_MANAGEMENT,
    selectionText: 'New Role',
  };
  public static readonly ACCESS_ROLE_SERVICE_MANAGEMENT: RouteInfo = {
    url: '/roleServiceManagement',
    name: 'home.access.roleServiceManagement',
    parent: RouteConstants.ACCESS_ROOT,
    breadcrumb: 'Role Service Management',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.ROLE_SERVICE_MANAGEMENT,
    selectionText: 'Role Service Management'
  };
  public static readonly ACCESS_NEW_ROLE_SERVICE: RouteInfo = {
    url: '/newRoleService',
    name: 'home.access.roleServiceManagement.newRoleService',
    parent: RouteConstants.ACCESS_ROLE_SERVICE_MANAGEMENT,
    breadcrumb: 'New Role Service',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.ROLE_SERVICE_MANAGEMENT,
    selectionText: 'New Role Service',
  };
  public static readonly ACCESS_ROLE_SERVICE_DETAILS: RouteInfo = {
    url: '/roleServiceDetails',
    name: 'home.access.roleServiceManagement.details',
    parent: RouteConstants.ACCESS_ROLE_SERVICE_MANAGEMENT,
    breadcrumb: 'Role Service Details',
    navigationId: NavigationConstants.ACCESS_NAV_ID,
    shown: false,
    perm: ElementConstants.ROLE_SERVICE_MANAGEMENT,
    selectionText: 'Role Service Details',
  };

  public static readonly ABI_SEARCH: RouteInfo = {
    url: '/abiSearch',
    name: 'home.abiSearch',
    breadcrumb: 'ABi Search',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ABI_NAV_ID,
    perm: ElementConstants.ABI,
    selectionText: 'ABi Search',
    shown: false
  };
  public static readonly ABI_PRODUCT_COMPARISON: RouteInfo = {
    url: '/productComparison',
    name: 'home.abiSearch.productComparison',
    breadcrumb: 'Product Comparison',
    parent: RouteConstants.ABI_SEARCH,
    navigationId: NavigationConstants.ABI_NAV_ID
  };
  public static readonly ABI_RELATED_SITE_RECORDS: RouteInfo = {
    url: '/relatedSiteRecords',
    name: 'home.abiSearch.relatedSiteRecords',
    breadcrumb: 'Related Site Records',
    parent: RouteConstants.ABI_SEARCH,
    navigationId: NavigationConstants.ABI_NAV_ID
  };
  public static readonly ABI_SITE_EQUIPMENT: RouteInfo = {
    url: '/siteEquipment',
    name: 'home.abiSearch.siteEquipment',
    breadcrumb: 'Site Equipment',
    parent: RouteConstants.ABI_SEARCH,
    navigationId: NavigationConstants.ABI_NAV_ID
  };
  public static readonly ABI_RELATED_PRODUCTS: RouteInfo = {
    url: '/relatedProducts',
    name: 'home.abiSearch.relatedProducts',
    breadcrumb: 'Related Products',
    parent: RouteConstants.ABI_SEARCH,
    navigationId: NavigationConstants.ABI_NAV_ID
  };
  public static readonly ABI_EQUIVALENT_PRODUCTS: RouteInfo = {
    url: '/equivalentProducts',
    name: 'home.abiSearch.equivalentProducts',
    breadcrumb: 'Equivalent Products',
    parent: RouteConstants.ABI_SEARCH,
    navigationId: NavigationConstants.ABI_NAV_ID
  };
  public static readonly ABI_PRODUCT_DETAILS: RouteInfo = {
    url: '/productDetails',
    name: 'home.abiSearch.productDetails',
    breadcrumb: 'Abi Product Details',
    parent: RouteConstants.ABI_SEARCH,
    navigationId: NavigationConstants.ABI_NAV_ID
  };
  public static readonly ABI_PREFERRED_PRODUCT: RouteInfo = {
    url: '/preferredProduct',
    name: 'home.abiSearch.preferredProduct',
    breadcrumb: 'Preferred Product',
    parent: RouteConstants.ABI_SEARCH,
    navigationId: NavigationConstants.ABI_NAV_ID
  };


  public static readonly FINANCE_ROOT: RouteInfo = {
    url: '/finance',
    name: 'home.finance',
    breadcrumb: 'Finance',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    shown: true,
    dividerFollows: false,
    perm: ElementConstants.FINANCE_MANAGEMENT,
    selectionText: 'Funding Dashboard'
  };
  public static readonly FINANCE_FUNDING_SEARCH: RouteInfo = {
    url: '/fundingSearch',
    name: 'home.finance.fundingSearch',
    breadcrumb: 'Funding Search',
    parent: RouteConstants.FINANCE_ROOT,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ElementConstants.FINANCE_MANAGEMENT,
    selectionText: 'Funding Search',
  };
  public static readonly FINANCE_FUNDING_SOURCE_SEARCH: RouteInfo = {
    url: '/fundingSourceSearch',
    name: 'home.finance.fundingSourceSearch',
    breadcrumb: 'Funding Source Search',
    parent: RouteConstants.FINANCE_ROOT,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ElementConstants.FINANCE_MANAGEMENT,
    selectionText: 'Funding Source Search',
  };
  public static readonly FINANCE_DETAIL: RouteInfo = {
    url: '/detail',
    name: 'home.finance.fundingSearch.detail',
    breadcrumb: 'Detail',
    parent: RouteConstants.FINANCE_FUNDING_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  public static readonly FINANCE_FUNDING_SOURCE_ADD: RouteInfo = {
    url: '/fundingSource/:fundingSourceId/:isEditing',
    name: 'home.finance.fundingSearch.detail.fundingSource',
    breadcrumb: 'Funding Source',
    parent: RouteConstants.FINANCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  public static readonly FINANCE_FUNDING_CHILD_EDIT: RouteInfo = {
    url: '/fundingChild',
    name: 'home.finance.fundingSearch.detail.fundingChild',
    breadcrumb: 'Funding Child',
    parent: RouteConstants.FINANCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  public static readonly FINANCE_FUNDING_NODE_ADD: RouteInfo = {
    url: '/fundingNode',
    name: 'home.finance.fundingSearch.detail.fundingNode',
    breadcrumb: 'Funding Node',
    parent: RouteConstants.FINANCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  public static readonly FINANCE_REF_DATA_SEARCH: RouteInfo = {
    url: '/financeRefDataSearch',
    name: 'home.finance.financeRefDataSearch',
    breadcrumb: 'Reference Data Search',
    parent: RouteConstants.FINANCE_ROOT,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Reference Data Search',
    dividerFollows: true,
  };

  public static readonly FINANCE_REF_DATA_ACCOUNTING_CLASSIFICATION: RouteInfo = {
    url: '/accountingClassification',
    name: 'home.finance.financeRefDataSearch.accountingClassification',
    breadcrumb: 'Accounting Classification',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Accounting Classification',
  };

  public static readonly FINANCE_ROLLOVER: RouteInfo = {
    url: '/financeRollover',
    name: 'home.finance.financeRollover',
    breadcrumb: 'Appropriation-LOA Rollover',
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ElementConstants.FINANCE_ROLLOVER,
    selectionText: 'Appropriation-LOA Rollover',
  };

  public static readonly FINANCE_REF_DATA_BILLED_SERVICE_CODE: RouteInfo = {
    url: '/billedServiceCode',
    name: 'home.finance.financeRefDataSearch.billedServiceCode',
    breadcrumb: 'Billed Service Code',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Billed Service Code',
  };

  public static readonly FINANCE_REF_DATA_BUDGET_LINE_ITEM: RouteInfo = {
    url: '/budgetLineItem',
    name: 'home.finance.financeRefDataSearch.budgetLineItem',
    breadcrumb: 'Budget Line Item',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Budget Line Item',
  };

  public static readonly FINANCE_REF_DATA_COMMODITY_CODE: RouteInfo = {
    url: '/commodityCode',
    name: 'home.finance.financeRefDataSearch.commodityCode',
    breadcrumb: 'Commodity Code',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Commodity Code',
  };

  public static readonly FINANCE_REF_DATA_COST_CENTER: RouteInfo = {
    url: '/costCenter',
    name: 'home.finance.financeRefDataSearch.costCenter',
    breadcrumb: 'Cost Center',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Cost Center',
  };

  public static readonly FINANCE_REF_DATA_FINANCIAL_SYSTEM: RouteInfo = {
    url: '/financialSystem',
    name: 'home.finance.financeRefDataSearch.financialSystem',
    breadcrumb: 'Financial System',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Financial System',
  };

  public static readonly FINANCE_REF_DATA_FOREIGN_CURRENCY: RouteInfo = {
    url: '/foreignCurrency',
    name: 'home.finance.financeRefDataSearch.foreignCurrency',
    breadcrumb: 'Foreign Currency',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Foreign Currency',
  };

  public static readonly FINANCE_REF_DATA_FUND_CODE: RouteInfo = {
    url: '/fundCode',
    name: 'home.finance.financeRefDataSearch.fundCode',
    breadcrumb: 'Fund Code',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Fund Code',
  };

  public static readonly FINANCE_REF_DATA_FUND_IDENTIFICATION: RouteInfo = {
    url: '/fundIdentification',
    name: 'home.finance.financeRefDataSearch.fundIdentification',
    breadcrumb: 'Fund Identification',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Fund Identification',
  };

  public static readonly FINANCE_REF_DATA_FUND_USAGE_TYPE: RouteInfo = {
    url: '/fundUsageType',
    name: 'home.finance.financeRefDataSearch.fundUsageType',
    breadcrumb: 'Fund Usage Type',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Fund Usage Type',
  };

  public static readonly FINANCE_REF_DATA_LINE_OF_ACCOUNTING_TEMPLATE: RouteInfo = {
    url: '/lineOfAccountingTemplate',
    name: 'home.finance.financeRefDataSearch.lineOfAccountingTemplate',
    breadcrumb: 'Line of Accounting Template',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Line of Accounting Template',
  };

  public static readonly FINANCE_REF_DATA_MAIN_ACCOUNT_CODE: RouteInfo = {
    url: '/mainAccountCode',
    name: 'home.finance.financeRefDataSearch.mainAccountCode',
    breadcrumb: 'Main Account Code',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Main Account Code',
  };

  public static readonly FINANCE_REF_DATA_MAIN_ACCOUNT_TYPE: RouteInfo = {
    url: '/mainAccountType',
    name: 'home.finance.financeRefDataSearch.mainAccountType',
    breadcrumb: 'Main Account Type',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Main Account Type',
  };

  public static readonly FINANCE_REF_DATA_MAIN_ACCOUNT_TEMPLATE: RouteInfo = {
    url: '/mainAccountTemplate',
    name: 'home.finance.financeRefDataSearch.mainAccountTemplate',
    breadcrumb: 'Main Account Template',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Main Account Template',
  };

  public static readonly FINANCE_REF_DATA_SALES_CODE_TYPE: RouteInfo = {
    url: '/salesCodeType',
    name: 'home.finance.financeRefDataSearch.salesCodeType',
    breadcrumb: 'Sales Code Type',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Sales Code Type',
  };

  public static readonly FINANCE_REF_DATA_SUB_ALLOCATION_HOLDER: RouteInfo = {
    url: '/subAllocationHolder',
    name: 'home.finance.financeRefDataSearch.subAllocationHolder',
    breadcrumb: 'Sub Allocation Holder',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Sub Allocation Holder',
  };

  public static readonly FINANCE_REF_DATA_SUB_CLASS: RouteInfo = {
    url: '/subClass',
    name: 'home.finance.financeRefDataSearch.subClass',
    breadcrumb: 'Sub Class',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Sub Class',
  };

  public static readonly FINANCE_REF_DATA_TREASURY_DEPARTMENT: RouteInfo = {
    url: '/treasuryDepartment',
    name: 'home.finance.financeRefDataSearch.treasuryDepartment',
    breadcrumb: 'Treasury Department',
    parent: RouteConstants.FINANCE_REF_DATA_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID,
    perm: ElementConstants.FINANCE_REFERENCE_DATA_VIEW,
    selectionText: 'Treasury Department',
  };


  public static readonly FINANCE_FUNDING_SOURCE_DETAIL: RouteInfo = {
    url: '/detail/:fundingSourceId/:fundingNodesFundingNodeId',
    name: 'home.finance.fundingSourceSearch.detail',
    breadcrumb: 'Detail',
    parent: RouteConstants.FINANCE_FUNDING_SOURCE_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  public static readonly FINANCE_FUNDING_CHILD_ADD: RouteInfo = {
    url: '/fundingChildAdd',
    name: 'home.finance.fundingSearch.detail.fundingChildAdd',
    breadcrumb: 'Funding Child Add',
    parent: RouteConstants.FINANCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  public static readonly FINANCE_FUNDING_SOURCE: RouteInfo = {
    url: '/fundingSource/:fundingSourceId/:isEditing',
    name: 'home.finance.fundingSourceSearch.fundingSource',
    breadcrumb: 'Funding Source',
    parent: RouteConstants.FINANCE_FUNDING_SOURCE_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  public static readonly FINANCE_FUNDING_SOURCE_EDIT: RouteInfo = {
    url: '/fundingSource/:fundingSourceId/:isEditing',
    name: 'home.finance.fundingSourceSearch.detail.fundingSource',
    breadcrumb: 'Funding Source',
    parent: RouteConstants.FINANCE_FUNDING_SOURCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  public static readonly FINANCE_CONTINUING_RESOLUTION: RouteInfo = {
    url: '/continuingResolution',
    name: 'home.finance.fundingSourceSearch.continuingResolution',
    breadcrumb: 'Continuing Resolution',
    parent: RouteConstants.FINANCE_FUNDING_SOURCE_SEARCH,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  public static readonly FINANCE_FUNDING_SOURCE_FUNDING_CHILD: RouteInfo = {
    url: '/fundingChild',
    name: 'home.finance.fundingSourceSearch.detail.fundingChild',
    breadcrumb: 'Funding Child',
    parent: RouteConstants.FINANCE_FUNDING_SOURCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  public static readonly FINANCE_FUNDING_SOURCE_FUNDING_NODE: RouteInfo = {
    url: '/fundingNode',
    name: 'home.finance.fundingSourceSearch.detail.fundingNode',
    breadcrumb: 'Funding Node',
    parent: RouteConstants.FINANCE_FUNDING_SOURCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID
  };
  public static readonly FINANCE_FUNDING_SOURCE_FUNDING_CHILD_ADD: RouteInfo = {
    url: '/fundingChildAdd',
    name: 'home.finance.fundingSourceSearch.detail.fundingChildAdd',
    breadcrumb: 'Funding Child Add',
    parent: RouteConstants.FINANCE_FUNDING_SOURCE_DETAIL,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
  };

  public static readonly FINANCE_PURCHASE_CARDS: RouteInfo = {
    url: '/purchaseCards',
    name: 'home.finance.purchaseCards',
    breadcrumb: 'Purchase Cards',
    parent: RouteConstants.FINANCE_ROOT,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ElementConstants.FINANCE_PURCHASE_CARDS,
    selectionText: 'Purchase Cards',
  };

  public static readonly FINANCE_PURCHASE_CARD_NEW: RouteInfo = {
    url: '/purchaseCardNew',
    name: 'home.finance.purchaseCards.purchaseCardNew',
    breadcrumb: 'New Purchase Card',
    parent: RouteConstants.FINANCE_PURCHASE_CARDS,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ElementConstants.FINANCE_MANAGEMENT,
    selectionText: 'New Purchase Card',
  };

  public static readonly FINANCE_PURCHASE_CARD_DETAILS: RouteInfo = {
    url: '/purchaseCardDetails',
    name: 'home.finance.purchaseCards.purchaseCardDetails',
    breadcrumb: 'Purchase Card Details',
    parent: RouteConstants.FINANCE_PURCHASE_CARDS,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ElementConstants.FINANCE_MANAGEMENT,
    selectionText: 'Purchase Card Details',
  };

  public static readonly FINANCE_PURCHASE_CARD_RECONCILIATION_DETAILS: RouteInfo = {
    url: '/purchaseCardReconciliationDetails',
    name: 'home.finance.purchaseCards.purchaseCardReconciliationDetails',
    breadcrumb: 'Purchase Card Reconciliation Details',
    parent: RouteConstants.FINANCE_PURCHASE_CARDS,
    navigationId: NavigationConstants.FINANCE_NAV_ID, shown: true,
    perm: ElementConstants.FINANCE_MANAGEMENT,
    selectionText: 'Purchase Card Reconciliation Details',
  };

  public static readonly INVENTORY_ROOT: RouteInfo = {
    url: '/inventory',
    name: 'home.inventory',
    breadcrumb: 'Inventory',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_SYSTEMS: RouteInfo = {
    url: '/invSystems', // todo rename and change perms
    name: 'home.inventory.Owners',
    breadcrumb: 'Inventory Systems',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Inventory Systems',
    shown: false
  };
  public static readonly ORGANIZATION_DETAILS_INVENTORY_OWNER_MANAGEMENT: RouteInfo = {
    url: '/invSystemDetails',
    name: 'home.customer.customerDetails',
    breadcrumb: 'Details',
    parent: RouteConstants.INVENTORY_SYSTEMS, navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_OWNER_DETAILS: RouteInfo = {
    url: '/invSystemDetails',
    name: 'home.inventory.Owners.OwnerDetails',
    breadcrumb: 'Inventory System Details',
    parent: RouteConstants.INVENTORY_SYSTEMS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_MANAGEMENT: RouteInfo = {
    url: '/invManagement',
    name: 'home.inventory.Management',
    breadcrumb: 'Location Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Location Management'
  };
  public static readonly INVENTORY_DETAILS: RouteInfo = {
    url: '/inventoryDetails',
    name: 'home.inventory.InventoryDetails',
    breadcrumb: 'Inventory Details',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Inventory Details'
  };
  // public static readonly INVENTORY_OWNER_DETAILS_FROM_INVENTORY_MANAGEMENT: RouteInfo = {
  //   url: '/invOwnerDetailsFromInvManagement',
  //   name: 'home.inventory.Management.OwnerDetailsFromInvManagement',
  //   breadcrumb: 'Owner Details',
  //   parent: RouteConstants.INVENTORY_MANAGEMENT,
  //   navigationId: NavigationConstants.INVENTORY_NAV_ID
  // };
  public static readonly INVENTORY_STORAGE_LOCATION_ADD_UPDATE: RouteInfo = {
    url: '/invStorageLocationAddUpdate',
    name: 'home.inventory.Management.StorageLocationAddUpdate',
    breadcrumb: 'Add Update Storage Location',
    parent: RouteConstants.INVENTORY_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };

  public static readonly INVENTORY_REC_SEARCH: RouteInfo = {
    url: '/invItemSearch',
    name: 'home.inventory.ItemSearch',
    breadcrumb: 'Item Search',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Item Search',
  };

  public static readonly INVENTORY_REPLENISHMENT: RouteInfo = {
    url: '/invReplenishment',
    name: 'home.inventory.Replenishment',
    breadcrumb: 'Replenishment',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Manual Replenishment',
    dividerFollows: true,
  };

  public static readonly INVENTORY_REC_ACCOUNTABILITY: RouteInfo = {
    url: '/invItemAccountability',
    name: 'home.inventory.Accountability',
    breadcrumb: 'Accountability',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Accountability',
    dividerFollows: true
  };
  public static readonly INVENTORY_REC_ACCOUNTABILITY_DETAILS: RouteInfo = {
    url: '/invRecAccountabilityDetails?id',
    name: 'home.inventory.Accountability.RecAccountabilityDetails',
    breadcrumb: 'Locations',
    parent: RouteConstants.INVENTORY_REC_ACCOUNTABILITY,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    perm: ElementConstants.INVENTORY_VIEW,
  };
  public static readonly INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS: RouteInfo = {
    url: '/invRecLocAccountabilityDetails',
    name: 'home.inventory.Accountability.RecAccountabilityDetails.RecLocAccountabilityDetails',
    breadcrumb: 'Accountability Location Details',
    parent: RouteConstants.INVENTORY_REC_ACCOUNTABILITY_DETAILS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_REC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT: RouteInfo = {
    url: '/invItemDetailsFromInvManagement',
    name: 'home.inventory.Accountability.ItemDetailsFromInvManagement',
    breadcrumb: 'Item Details',
    parent: RouteConstants.INVENTORY_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT: RouteInfo = {
    url: '/invItemLocAccountabilityDetailsFromInvManagement',
    name: 'home.inventory.Accountability.ItemDetailsFromInvManagement.ItemLocDetailsFromInvManagement',
    breadcrumb: 'Accountability Location Details',
    parent: RouteConstants.INVENTORY_REC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_REC_ADD: RouteInfo = {
    url: '/invItemAdd',
    name: 'home.inventory.ItemSearch.ItemAdd',
    breadcrumb: 'Add an Inventory Item',
    parent: RouteConstants.INVENTORY_REC_SEARCH,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_REC_DETAILS: RouteInfo = {
    url: '/invItemDetails',
    name: 'home.inventory.ItemSearch.ItemDetails',
    breadcrumb: 'Item Details',
    parent: RouteConstants.INVENTORY_REC_SEARCH,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_REC_NEW_LOCATION: RouteInfo = {
    url: '/createNewLocation',
    name: 'home.inventory.ItemSearch.ItemDetails.CreateNewLocation',
    breadcrumb: 'Create New Storage Location',
    parent: RouteConstants.INVENTORY_REC_DETAILS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_REC_DETAILS_FROM_INVENTORY_MANAGEMENT: RouteInfo = {
    url: '/invItemDetailsFromInvManagement',
    name: 'home.inventory.Management.ItemDetailsFromInvManagement',
    breadcrumb: 'Item Details',
    parent: RouteConstants.INVENTORY_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_REC_LOC_DETAILS: RouteInfo = {
    url: '/invItemLocDetails',
    name: 'home.inventory.ItemSearch.ItemDetails.ItemLocDetails',
    breadcrumb: 'Item Location Details',
    parent: RouteConstants.INVENTORY_REC_DETAILS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_REC_LOC_DETAILS_FROM_INVENTORY_MANAGEMENT: RouteInfo = {
    url: '/invItemLocDetailsFromInvManagement',
    name: 'home.inventory.Management.ItemDetailsFromInvManagement.ItemLocDetailsFromInvManagement',
    breadcrumb: 'Item Location Details',
    parent: RouteConstants.INVENTORY_REC_DETAILS_FROM_INVENTORY_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_POTENTIAL_EXCESS: RouteInfo = {
    url: '/invPotentialExcess',
    name: 'home.inventory.PotentialExcess',
    breadcrumb: 'Potential Excess',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Potential Excess',
  };
  public static readonly INVENTORY_POTENTIAL_EXCESS_DETAILS: RouteInfo = {
    url: '/invPotentialExcessDetails',
    name: 'home.inventory.PotentialExcess.PotentialExcessDetails',
    breadcrumb: 'Potential Excess Details',
    parent: RouteConstants.INVENTORY_POTENTIAL_EXCESS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_MY_EXCESS_REPORT_DETAILS: RouteInfo = {
    url: '/invMyExcessReportDetails',
    name: 'home.inventory.PotentialExcess.MyExcessReportDetails',
    breadcrumb: 'My Organization\'s Excess Report Details',
    parent: RouteConstants.INVENTORY_POTENTIAL_EXCESS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_SITE_EXCESS_MANAGEMENT: RouteInfo = {
    url: '/invSiteExcessManagement',
    name: 'home.inventory.SiteExcessManagement',
    breadcrumb: 'Site Excess Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Site Excess Management',
  };
  public static readonly INVENTORY_SITE_EXCESS_MANAGEMENT_DETAILS: RouteInfo = {
    url: '/invSiteExcessManagementDetails',
    name: 'home.inventory.SiteExcessManagement.SiteExcessManagementDetails',
    breadcrumb: 'Site Excess Management Details',
    parent: RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
  };
  public static readonly INVENTORY_SITE_EXCESS_MANAGEMENT_STATUS: RouteInfo = {
    url: '/invSiteExcessManagementStatus',
    name: 'home.inventory.SiteExcessManagement.SiteExcessManagementStatus',
    breadcrumb: 'Site Excess Management Status',
    parent: RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
  };
  public static readonly INVENTORY_CUSTOMER_EXCESS_MANAGEMENT_DETAILS: RouteInfo = {
    url: '/invCustomerExcessManagementDetails',
    name: 'home.inventory.SiteExcessManagement.CustomerExcessManagementDetails',
    breadcrumb: 'Customer Excess Management Details',
    parent: RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
  };
  public static readonly INVENTORY_ENTERPRISE_EXCESS_SEARCH: RouteInfo = {
    url: '/invEnterpriseExcessSearch',
    name: 'home.inventory.EnterpriseExcessSearch',
    breadcrumb: 'Enterprise Excess Search',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Enterprise Excess Search',
  };
  public static readonly INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_SEARCH: RouteInfo = {
    url: '/invEnterpriseExcessAvailableItemDetailsFromSearch',
    name: 'home.inventory.EnterpriseExcessSearch.EnterpriseExcessAvailableItemDetailsFromSearch',
    breadcrumb: 'Enterprise Excess Available Item Details',
    parent: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_SEARCH,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_ENTERPRISE_EXCESS_MANAGEMENT: RouteInfo = {
    url: '/invEnterpriseExcessManagement',
    name: 'home.inventory.EnterpriseExcessManagement',
    breadcrumb: 'Enterprise Excess Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Enterprise Excess Management'
  };
  public static readonly INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_MANAGER: RouteInfo = {
    url: '/invEnterpriseExcessAvailableItemDetailsFromMgr',
    name: 'home.inventory.EnterpriseExcessManagement.EnterpriseExcessAvailableItemDetailsFromMgr',
    breadcrumb: 'Enterprise Excess Available Item Details',
    parent: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_ENTERPRISE_EXCESS_SHIPMENT_STATUS_DETAILS_FROM_MANAGER: RouteInfo = {
    url: '/invEnterpriseExcessShipmentStatusDetailsFromMgr',
    name: 'home.inventory.EnterpriseExcessManagement.EnterpriseExcessShipmentStatusDetailsFromMgr',
    breadcrumb: 'Enterprise Excess Shipment Status Details',
    parent: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_ENTERPRISE_EXCESS_DELINQUENT_ITEM_DETAILS_FROM_MANAGER: RouteInfo = {
    url: '/invEnterpriseExcessDelinquentItemDetailsFromMgr',
    name: 'home.inventory.EnterpriseExcessManagement.EnterpriseExcessDelinquentItemDetailsFromMgr',
    breadcrumb: 'Enterprise Excess Delinquent Item Details',
    parent: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_ENTERPRISE_EXCESS_ITEM_HISTORY_DETAILS_FROM_MANAGER: RouteInfo = {
    url: '/invEnterpriseExcessItemHistoryDetailsFromMgr',
    name: 'home.inventory.EnterpriseExcessManagement.EnterpriseExcessItemHistoryDetailsFromMgr',
    breadcrumb: 'Enterprise Excess Item History Details',
    parent: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_MANAGEMENT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_AUDIT: RouteInfo = {
    url: '/invPhysical',
    name: 'home.inventory.Physical',
    breadcrumb: 'Physical Inventory',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Physical Inventory',
  };
  public static readonly INVENTORY_AUDIT_SCHEDULED_CREATE: RouteInfo = {
    url: '/invPhysicalScheduleCreate',
    name: 'home.inventory.Physical.PhysicalScheduledCreate',
    breadcrumb: 'Create a Scheduled Physical Inventory',
    parent: RouteConstants.INVENTORY_AUDIT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_AUDIT_SCHEDULED_DETAILS: RouteInfo = {
    url: '/invPhysicalScheduledDetails',
    name: 'home.inventory.Physical.PhysicalScheduledDetails',
    breadcrumb: 'Scheduled Physical Inventory Details',
    parent: RouteConstants.INVENTORY_AUDIT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_AUDIT_INPROGRESS_DETAILS: RouteInfo = {
    url: '/invPhysicalInProgressDetails',
    name: 'home.inventory.Physical.PhysicalProgressDetails',
    breadcrumb: 'In Progress Physical Inventory Details',
    parent: RouteConstants.INVENTORY_AUDIT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_AUDIT_RESEARCH_DETAILS: RouteInfo = {
    url: '/invPhysicalResearchDetails',
    name: 'home.inventory.Physical.PhysicalResearchDetails',
    breadcrumb: 'Research Physical Inventory Details',
    parent: RouteConstants.INVENTORY_AUDIT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_AUDIT_FINALIZE_DETAILS: RouteInfo = {
    url: '/invPhysicalFinalizeDetails',
    name: 'home.inventory.Physical.PhysicalFinalizeDetails',
    breadcrumb: 'Finalize Physical Inventory Details',
    parent: RouteConstants.INVENTORY_AUDIT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_AUDIT_COMPLETED_DETAILS: RouteInfo = {
    url: '/invPhysicalCompletedDetails',
    name: 'home.inventory.Physical.PhysicalCompletedDetails',
    breadcrumb: 'Completed Physical Inventory Details',
    parent: RouteConstants.INVENTORY_AUDIT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_AUDIT_CANCELLED_DETAILS: RouteInfo = {
    url: '/invPhysicalCancelledDetails',
    name: 'home.inventory.Physical.PhysicalCancelledDetails',
    breadcrumb: 'Cancelled Physical Inventory Details',
    parent: RouteConstants.INVENTORY_AUDIT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_PLANNING: RouteInfo = {
    url: '/invPlanning',
    name: 'home.inventory.Planning',
    breadcrumb: 'Inventory Planning',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Inventory Planning',
  };
  public static readonly INVENTORY_PLANNING_DETAILS: RouteInfo = {
    url: '/invPlanningDetails',
    name: 'home.inventory.Planning.PlanningDetails',
    breadcrumb: 'Recommended Level Change',
    parent: RouteConstants.INVENTORY_PLANNING,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_SHIPPING: RouteInfo = {
    url: '/invShipping',
    name: 'home.inventory.Shipping',
    breadcrumb: 'Transportation',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Transportation',
  };
  public static readonly INVENTORY_SHIPMENT_DETAILS: RouteInfo = {
    url: '/invShipmentDetails',
    name: 'home.inventory.Shipping.ShipmentDetails',
    breadcrumb: 'Shipment Details',
    parent: RouteConstants.INVENTORY_SHIPPING,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
  };
  public static readonly INVENTORY_SHIPPERS: RouteInfo = {
    url: '/invShippers',
    name: 'home.inventory.Shipping.Shippers',
    breadcrumb: 'Manage Shippers',
    parent: RouteConstants.INVENTORY_SHIPPING,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_SHIPPER_ADD: RouteInfo = {
    url: '/invShipperAdd',
    name: 'home.inventory.Shipping.Shippers.ShipperAdd',
    breadcrumb: 'Add a new Shipper',
    parent: RouteConstants.INVENTORY_SHIPPERS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_SHIPPER_DETAILS: RouteInfo = {
    url: '/invShipperDetails',
    name: 'home.inventory.Shipping.Shippers.ShipperDetails',
    breadcrumb: 'Shipper Details',
    parent: RouteConstants.INVENTORY_SHIPPERS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_RETURNS: RouteInfo = {
    url: '/invReturns',
    name: 'home.inventory.Returns',
    breadcrumb: 'Return Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.INVENTORY_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Return Management',
    dividerFollows: true
  };
  public static readonly INVENTORY_RETURN_PICKUP_DETAILS: RouteInfo = {
    url: '/invReturnPickupDetails',
    name: 'home.inventory.Returns.ReturnPickupDetails',
    breadcrumb: 'Pickup Details',
    parent: RouteConstants.INVENTORY_RETURNS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_RETURN_ACTION_TYPE_DETAILS: RouteInfo = {
    url: '/invReturnActionTypeDetails',
    name: 'home.inventory.Returns.ReturnActionTypeDetails',
    breadcrumb: 'Provide Disposition Details',
    parent: RouteConstants.INVENTORY_RETURNS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_RETURN_FINAL_REVIEW: RouteInfo = {
    url: '/invReturnFinalReview',
    name: 'home.inventory.Returns.ReturnFinalReview',
    breadcrumb: 'Final Review',
    parent: RouteConstants.INVENTORY_RETURNS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
  public static readonly INVENTORY_RETURN_COMPLETE: RouteInfo = {
    url: '/invReturnComplete',
    name: 'home.inventory.Returns.ReturnComplete',
    breadcrumb: 'Complete - Review Only',
    parent: RouteConstants.INVENTORY_RETURNS,
    navigationId: NavigationConstants.INVENTORY_NAV_ID
  };
// --------------CATALOG Management ---------------------
  public static readonly CATALOG_ROOT: RouteInfo = {
    url: '/catalog',
    name: 'home.catalog',
    breadcrumb: 'Catalog',
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    parent: RouteConstants.HOME_ROOT
  };

  public static readonly CUSTOMER_ITEM_SOURCING_SEARCH: RouteInfo = {
    url: '/customerCatalog',
    name: 'home.catalog.customerItemSourcingSearch',
    breadcrumb: 'Catalog Search',
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    parent: RouteConstants.CATALOG_ROOT,
    perm: ElementConstants.CATALOG_VIEW,
    selectionText: 'Catalog Search',
    shown: true
  };
  public static readonly NON_CATALOG_SEARCH: RouteInfo = {
    url: '/nonCatalogSearch',
    name: 'home.catalog.nonCatalogSearch',
    breadcrumb: 'Non-Catalog Purchase Search',
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    parent: RouteConstants.CATALOG_ROOT,
    perm: ElementConstants.NON_CATALOG_SEARCH_VIEW,
    selectionText: 'Non-Catalog Purchase Search',
    dividerFollows: true,
    shown: true
  };
  public static readonly ORDER_ADD_ITEM_TO_CATALOG: RouteInfo = {
    url: '/addItemToCatalog',
    name: 'home.catalog.nonCatalogSearch.addItemToCatalog',
    breadcrumb: 'Add Item To Catalog',
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    parent: RouteConstants.NON_CATALOG_SEARCH,
    perm: ElementConstants.NON_CATALOG_SEARCH_VIEW,
    shown: false
  };
  public static readonly ENTERPRISE_ITEM_SEARCH: RouteInfo = {
    url: '/enterpriseItemSearch',
    name: 'home.catalog.enterpriseItemSearch',
    breadcrumb: 'Enterprise Item Search',
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    parent: RouteConstants.CATALOG_ROOT,
    perm: ElementConstants.ENTERPRISE_ITEM_MENU_VIEW,
    selectionText: 'Enterprise Item Search',
    shown: true
  };
  public static readonly NEW_ITEM_SEARCH_VIEW: RouteInfo = {
    url: '/newItemSearchView',
    name: 'home.catalog.enterpriseItemSearch.newItemSearchView',
    breadcrumb: 'Create New Enterprise Item',
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    parent: RouteConstants.ENTERPRISE_ITEM_SEARCH,
    perm: ElementConstants.ITEM_VIEW,
    shown: false
  };
  public static readonly ITEM_DETAILS: RouteInfo = {
    url: '/itemDetails',
    name: 'home.catalog.enterpriseItemSearch.itemDetails',
    breadcrumb: 'Item Details',
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    parent: RouteConstants.ENTERPRISE_ITEM_SEARCH,
    perm: ElementConstants.ITEM_VIEW,
    shown: false
  };
  public static readonly ITEM_SOURCING_SEARCH: RouteInfo = {
    url: '/itemSourcingSearch',
    name: 'home.catalog.itemSourcingSearch',
    breadcrumb: 'Enterprise Sourcing',
    parent: RouteConstants.CATALOG_ROOT,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    shown: true,
    selectionText: 'Enterprise Sourcing',
    perm: ElementConstants.ITEM_SOURCING_VIEW,
    dividerFollows: true
  };
  public static readonly ITEM_SOURCING_DETAILS: RouteInfo = {
    url: '/itemSourcingDetails',
    name: 'home.catalog.itemSourcingSearch.itemSourcingDetails',
    breadcrumb: 'Enterprise Sourcing',
    parent: RouteConstants.ITEM_SOURCING_SEARCH,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
  };
  public static readonly ADD_TO_CUSTOMER_CATALOG: RouteInfo = {
    url: '/addToCustomerCatalog',
    name: 'home.catalog.itemSourcingSearch.addToCustomerCatalog',
    breadcrumb: 'Add To Catalog',
    parent: RouteConstants.ITEM_SOURCING_SEARCH,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
  };
  public static readonly ADD_ITEM_TO_CUSTOMER_CATALOG: RouteInfo = {
    url: '/addItemToCustomerCatalog',
    name: 'home.catalog.addItemToCustomerCatalog',
    breadcrumb: 'Add Item To Catalog',
    parent: RouteConstants.ITEM_SOURCING_SEARCH,
    navigationId: NavigationConstants.CATALOG_NAV_ID
  };
  public static readonly CATALOG_REFERENCE_DATA: RouteInfo = {
    url: '/catalogReferenceData',
    name: 'home.catalog.catalogReferenceData',
    breadcrumb: 'Reference Data',
    parent: RouteConstants.CATALOG_ROOT,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    shown: true,
    selectionText: 'Reference Data',
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW,
    dividerFollows: false
  };
  public static readonly CATALOG_ENTERPRISE_PRODUCT_IDENTIFIER_TYPE: RouteInfo = {
    url: '/catalogEnterpriseProductIdentifierType',
    name: 'home.catalog.catalogReferenceData.enterpriseProductIdentifierType',
    breadcrumb: 'Enterprise Product Identifier Type',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    shown: false,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW,
    dividerFollows: false
  };
  public static readonly CATALOG_BUSINESS_NAME: RouteInfo = {
    url: '/catalogBusinessName',
    name: 'home.catalog.catalogReferenceData.businessName',
    breadcrumb: 'Business',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    shown: false,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW,
    dividerFollows: false
  };
  public static readonly CATALOG_PACKAGING_UNIT: RouteInfo = {
    url: '/catalogPackagingUnit',
    name: 'home.catalog.catalogReferenceData.packagingUnit',
    breadcrumb: 'Packaging Units',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    shown: false,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW,
    dividerFollows: false
  };
  public static readonly CATALOG_CRITICAL_ITEM_CATEGORY: RouteInfo = {
    url: '/catalogCriticalItemCategory',
    name: 'home.catalog.catalogReferenceData.criticalItemCategory',
    breadcrumb: 'Critical Item Category',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    shown: false,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW,
    dividerFollows: false
  };
  public static readonly CATALOG_HCPCS_IMPLANT: RouteInfo = {
    url: '/catalogHcpcsImplant',
    name: 'home.catalog.catalogReferenceData.hcpcsImplant',
    breadcrumb: 'Healthcare Common Procedure Coding System (HCPCS) Implant List',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    shown: false,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW,
    dividerFollows: false
  };
  public static readonly CATALOG_UNSPSC_CRITICAL_ITEM_CATEGORY_MAP: RouteInfo = {
    url: '/catalogUnspscCriticalItemCategoryMap',
    name: 'home.catalog.catalogReferenceData.unspscCriticalItemCategoryMap',
    breadcrumb: 'United Nations Standard Products and Services Code (UNSPSC) Critical Item Category Map',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW
  };
  public static readonly CATALOG_ATTRIBUTE_CASING: RouteInfo = {
    url: '/catalogAttributeCasing',
    name: 'home.catalog.catalogReferenceData.attributeCasing',
    breadcrumb: 'Attribute Casing',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW
  };
  public static readonly CATALOG_PRODUCT_NOUN: RouteInfo = {
    url: '/catalogProductNoun',
    name: 'home.catalog.catalogReferenceData.productNoun',
    breadcrumb: 'Product Noun',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW
  };
  public static readonly CATALOG_PRODUCT_TYPE: RouteInfo = {
    url: '/catalogProductType',
    name: 'home.catalog.catalogReferenceData.productType',
    breadcrumb: 'Product Type',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW
  };
  public static readonly CATALOG_NET_CONTENT: RouteInfo = {
    url: '/catalogNetContent',
    name: 'home.catalog.catalogReferenceData.netContent',
    breadcrumb: 'Net Content',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW
  };
  public static readonly CATALOG_GENERIC_ID_UNSPSC_MAP: RouteInfo = {
    url: '/catalogGenericIdUnspscMap',
    name: 'home.catalog.catalogReferenceData.genericIdUnspscMap',
    breadcrumb: 'United Nations Standard Products and Services Code (UNSPSC) Generic Drug Map',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW
  };
  public static readonly CATALOG_MANUFACTURER_PREFIX: RouteInfo = {
    url: '/catalogManufacturerPrefix',
    name: 'home.catalog.catalogReferenceData.manufacturerPrefix',
    breadcrumb: 'Manufacturer Enterprise Product Identifier Prefix',
    parent: RouteConstants.CATALOG_REFERENCE_DATA,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    perm: ElementConstants.CATALOG_REFERENCE_DATA_VIEW
  };
  public static readonly NEW_CATALOG_ITEM_SEARCH_VIEW: RouteInfo = {
    url: '/newCatalogItemSearchView',
    name: 'home.catalog.enterpriseItemSearch.newCatalogItemSearchView',
    breadcrumb: 'Create New Catalog Record',
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    parent: RouteConstants.CUSTOMER_ITEM_SOURCING_SEARCH,
    perm: ElementConstants.CATALOG_VIEW,
    shown: false
  };
  public static readonly CATALOG_DETAILS: RouteInfo = {
    url: '/catalogDetails',
    name: 'home.catalog.catalogDetails',
    breadcrumb: 'Catalog Details',
    parent: RouteConstants.CUSTOMER_ITEM_SOURCING_SEARCH,
    navigationId: NavigationConstants.CATALOG_NAV_ID,
    perm: ElementConstants.CATALOG_CREATE
  };

  // END  --------------CATALOG Management ---------------------

  public static readonly JMLFDC_ADMIN: RouteInfo = {
    url: '/admin',
    name: 'home.admin',
    breadcrumb: 'Admin',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID
  };
  public static readonly ABI_MANAGEMENT: RouteInfo = {
    url: '/abiManagement',
    name: 'home.admin.abiManagement',
    breadcrumb: 'ABi Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID
  };
  public static readonly ABI_VIEW_STAGING_RECORDS: RouteInfo = {
    url: '/viewStagingRecords',
    name: 'home.admin.abiManagement.abiStaging',
    breadcrumb: 'View Staging Records',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING,
    selectionText: 'ABi Management'
  };
  public static readonly ABI_EDIT_STAGING_RECORD: RouteInfo = {
    url: '/editStagingRecord',
    name: 'home.admin.abiManagement.abiStaging.edit',
    breadcrumb: 'Edit ABi Staging Record',
    parent: RouteConstants.ABI_VIEW_STAGING_RECORDS,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_SET_UNSPSC: RouteInfo = {
    url: '/setUnspscCode',
    name: 'home.admin.abiManagement.abiStaging.setUnspsc',
    breadcrumb: 'Bulk Set UNSPSC',
    parent: RouteConstants.ABI_VIEW_STAGING_RECORDS,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_SET_ATTRS: RouteInfo = {
    url: '/setAttributes',
    name: 'home.admin.abiManagement.abiStaging.setAttributes',
    breadcrumb: 'Bulk Set Attributes',
    parent: RouteConstants.ABI_VIEW_STAGING_RECORDS,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_MERGE_RECORDS: RouteInfo = {
    url: '/mergeRecords',
    name: 'home.admin.abiManagement.mergeRecords',
    breadcrumb: 'Merge ABi Staging Catalog Records',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_MERGE_BY_MMC: RouteInfo = {
    url: '/mergeByMmc',
    name: 'home.admin.abiManagement.abiStagingMergeByMmc',
    breadcrumb: 'Merge Records by MMC Product Identifier',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_MANAGE_MERGED_RECORDS: RouteInfo = {
    url: '/manageMergedRecords',
    name: 'home.admin.abiManagement.manageMergedRecords',
    breadcrumb: 'Manage Merged Records',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_VIEW_MERGED_DETAILS: RouteInfo = {
    url: '/viewMergedDetails',
    name: 'home.admin.abiManagement.manageMergedRecords.viewMergedDetails',
    breadcrumb: 'View Merged Details',
    parent: RouteConstants.ABI_STAGING_MANAGE_MERGED_RECORDS,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_EDIT_MERGED_RECORDS: RouteInfo = {
    url: '/editMergedRecords',
    name: 'home.admin.abiManagement.manageMergedRecords.editMergedRecords',
    breadcrumb: 'Edit Merged Records',
    parent: RouteConstants.ABI_STAGING_MANAGE_MERGED_RECORDS,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_MANAGE_STAGING_REQUESTS_UTILITY: RouteInfo = {
    url: '/manageStagingRequestsUtility',
    name: 'home.admin.abiManagement.manageStagingRequestsUtility',
    breadcrumb: 'Manage Staging Requests',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_MANAGE_DOWNLOADS_UTILITY: RouteInfo = {
    url: '/manageDownloadsUtility',
    name: 'home.admin.abiManagement.manageDownloadsUtility',
    breadcrumb: 'Manage Downloads',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_MANAGE_UPLOADS_UTILITY: RouteInfo = {
    url: '/manageUploadsUtility',
    name: 'home.admin.abiManagement.manageUploadsUtility',
    breadcrumb: 'Manage Uploads',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_MANAGE_DATA_COLLECTIONS_UTILITY: RouteInfo = {
    url: '/manageDataCollectionsUtility',
    name: 'home.admin.abiManagement.manageDataCollectionsUtility',
    breadcrumb: 'Manage Data Collections',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };

  public static readonly ABI_STAGING_DATA_COLLECTION: RouteInfo = {
    url: '/dataCollection',
    name: 'home.admin.abiManagement.manageDataCollectionsUtility.dataCollection',
    breadcrumb: 'Data Collection',
    parent: RouteConstants.ABI_STAGING_MANAGE_DATA_COLLECTIONS_UTILITY,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING: RouteInfo = {
    url: '/unspscCriticalItemCategoryMapping',
    name: 'home.admin.abiManagement.unspscCriticalItemCategoryMapping',
    breadcrumb: 'Unspsc Critical Item Category Mapping',
    parent: RouteConstants.ABI_STAGING_MANAGE_DATA_COLLECTIONS_UTILITY,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly EDIT_UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING: RouteInfo = {
    url: '/editUnspscCriticalItemCategoryMapping',
    name: 'home.admin.abiManagement.unspscCriticalItemCategoryMap.editUnspscCriticalItemCategoryMapping',
    breadcrumb: 'Unspsc Critical Item Category Map Collection',
    parent: RouteConstants.UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_SEARCH_REPLACE_UTILITY: RouteInfo = {
    url: '/searchReplaceUtility',
    name: 'home.admin.abiManagement.searchReplaceUtility',
    breadcrumb: 'Search and Replace',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_VIEW_DELTA_RECORDS: RouteInfo = {
    url: '/viewDeltaRecords',
    name: 'home.admin.abiManagement.abiDelta',
    breadcrumb: 'Manage ABi Delta',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_DELTA_RECORD_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.admin.abiManagement.abiDelta.details',
    breadcrumb: 'Delta Records Details',
    parent: RouteConstants.ABI_STAGING_VIEW_DELTA_RECORDS,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_MOVE_TO_PRODUCTION: RouteInfo = {
    url: '/moveRecordsToProduction',
    name: 'home.admin.abiManagement.moveRecordsToProduction',
    breadcrumb: 'Move Staging Records To Production',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_MANAGE_SITE_RECORD_LINKAGE: RouteInfo = {
    url: '/manageSiteRecordLinkage',
    name: 'home.admin.abiManagement.manageSiteRecordLinkage',
    breadcrumb: 'Manage ABi to Site Record Linkage',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly ABI_STAGING_MANAGE_CONFIGURATION: RouteInfo = {
    url: '/manageConfiguration',
    name: 'home.admin.abiManagement.manageConfiguration',
    breadcrumb: 'Manage ABi Configuration',
    parent: RouteConstants.ABI_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.MANAGE_ABI_STAGING
  };
  public static readonly NOTIFICATIONS_VIEW: RouteInfo = {
    url: '/viewNotifications',
    name: 'home.admin.notifications',
    breadcrumb: 'System Notifications',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.VIEW_SYSTEM_NOTIFICATIONS,
    selectionText: 'System Notifications',
  };
  public static readonly NOTIFICATIONS_ADD: RouteInfo = {
    url: '/createNotification',
    name: 'home.admin.notifications.createNotification',
    breadcrumb: 'Add',
    parent: RouteConstants.NOTIFICATIONS_VIEW,
    navigationId: NavigationConstants.ADMIN_NAV_ID
  };
  public static readonly NOTIFICATIONS_EDIT: RouteInfo = {
    url: '/editNotification',
    name: 'home.admin.notifications.editNotification',
    breadcrumb: 'Edit',
    parent: RouteConstants.NOTIFICATIONS_VIEW,
    navigationId: NavigationConstants.ADMIN_NAV_ID
  };

  public static readonly UPDATE_SELLER_IN_OFFERS_VIEW: RouteInfo = {
    url: '/updateSuppliersAndOffers',
    name: 'home.admin.updateSuppliersAndOffers',
    breadcrumb: 'Update Suppliers and Offers',
    parent: RouteConstants.JMLFDC_ADMIN, navigationId: NavigationConstants.ADMIN_NAV_ID, shown: true,
    perm: ElementConstants.VIEW_SYSTEM_NOTIFICATIONS,
    selectionText: 'Update Suppliers and Offers',
  };

  public static readonly ORDER_EQUIPMENT_REQUEST: RouteInfo = { // TODO Define this route
    url: '', name: '',
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    breadcrumb: 'Equipment Request',
    parent: RouteConstants.HOME_ROOT, shown: false,
    perm: '',
    selectionText: 'Equipment Request',
    dividerFollows: true,
  };


  public static readonly ORDER_ROOT: RouteInfo = {
    url: '/purchasing',
    name: 'home.order',
    breadcrumb: 'Purchasing',
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    parent: RouteConstants.HOME_ROOT
  };

  public static readonly ORDER_CATALOG: RouteInfo = {
    url: '/catalog',
    name: 'home.order.catalogSearch',
    breadcrumb: 'Search Catalog',
    parent: RouteConstants.ORDER_ROOT,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    shown: true, selectionText: 'Search Catalog',
    perm: ElementConstants.ORDERS_CATALOG_SEARCH_VIEW,
  };

  public static readonly ORDER_CATALOG_ITEM_DETAILS: RouteInfo = {
    url: '/catalogItemDetails',
    name: 'home.order.catalogSearch.catalogItemDetails',
    breadcrumb: 'Catalog Item Details',
    parent: RouteConstants.ORDER_CATALOG,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
  };

  public static readonly ORDER_CART: RouteInfo = {
    url: '/cart',
    name: 'home.order.cart',
    breadcrumb: 'Cart',
    parent: RouteConstants.ORDER_ROOT,
    perm: ElementConstants.ORDERS_CART_VIEW,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    shown: true, selectionText: 'Cart'
  };

  public static readonly ORDER_CART_ITEM_DETAILS: RouteInfo = {
    url: '/cartItemDetails',
    name: 'home.order.cart.details',
    breadcrumb: 'Cart Item Details',
    parent: RouteConstants.ORDER_CART,
    navigationId: NavigationConstants.ORDERING_NAV_ID
  };

  public static readonly CART_CATALOG_ITEM_DETAILS: RouteInfo = {
    url: '/cartCatalogItemDetails',
    name: 'home.order.cart.cartCatalogItemDetails',
    breadcrumb: 'Catalog Item Details',
    parent: RouteConstants.ORDER_CART,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
  };

  public static readonly ORDER_CART_CHECKOUT: RouteInfo = {
    url: '/checkout',
    name: 'home.order.cart.checkout',
    breadcrumb: 'Checkout',
    parent: RouteConstants.ORDER_CART,
    navigationId: NavigationConstants.ORDERING_NAV_ID
  };
  public static readonly ORDER_CART_SUMMARY: RouteInfo = {
    url: '/summary',
    name: 'home.order.cart.orderSummary',
    breadcrumb: 'Order Summary',
    parent: RouteConstants.ORDER_CART,
    navigationId: NavigationConstants.ORDERING_NAV_ID
  };
  public static readonly ORDER_CART_SUMMARY_FORM_GENERATION: RouteInfo = {
    url: '/formGeneration',
    name: 'home.order.cart.orderSummary.formGeneration',
    breadcrumb: 'Form Generation',
    parent: RouteConstants.ORDER_CART_SUMMARY,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
  };

  public static readonly ORDER_REVIEW: RouteInfo = {
    url: '/orderReview',
    name: 'home.order.orderReview',
    breadcrumb: 'Distribution Review',
    parent: RouteConstants.ORDER_ROOT,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    perm: ElementConstants.ORDERS_REVIEW,
    shown: true, selectionText: 'Distribution Review'
  };

  public static readonly ORDER_REVIEW_ITEM_DETAILS: RouteInfo = {
    url: '/orderReviewCatalogItemDetails',
    name: 'home.order.orderReview.orderReviewCatalogItemDetails',
    breadcrumb: 'Catalog Item Details',
    parent: RouteConstants.ORDER_REVIEW,
    navigationId: NavigationConstants.ORDERING_NAV_ID
  };

  // public static readonly ORDER_LISTS: RouteInfo = {
  //   url: '/lists',
  //   name: 'home.order.lists',
  //   breadcrumb: 'Item Lists',
  //   parent: RouteConstants.ORDER_ROOT,
  //   navigationId: NavigationConstants.ORDERING_NAV_ID, shown: true,
  //   perm: ElementConstants.ORDERS_ROUTINE_LISTS_VIEW,
  //   selectionText: 'Customer Lists'
  // };
  public static readonly ORDER_VIEW: RouteInfo = {
    url: '/dueins',
    name: 'home.order.dueIn',
    breadcrumb: 'Due-In',
    parent: RouteConstants.ORDER_ROOT,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    shown: true,
    selectionText: 'Due-In',
    perm: ElementConstants.ORDERS_VIEW,
    dividerFollows: true
  };
  public static readonly ORDER_VIEW_DETAIL: RouteInfo = {
    url: '/details',
    name: 'home.order.dueIn.dueInDetail',
    breadcrumb: 'Due-In Details',
    parent: RouteConstants.ORDER_VIEW,
    navigationId: NavigationConstants.ORDERING_NAV_ID
  };
  public static readonly ORDER_VIEW_DETAIL_FORM_GENERATION: RouteInfo = {
    url: '/formGeneration',
    name: 'home.order.dueIn.dueInDetail.formGeneration',
    breadcrumb: 'Form Generation',
    parent: RouteConstants.ORDER_VIEW_DETAIL,
    navigationId: NavigationConstants.ORDERING_NAV_ID
  };

  public static readonly ORDER_SELLER: RouteInfo = {
    url: '/supplier',
    name: 'home.order.supplier',
    breadcrumb: 'Suppliers',
    parent: RouteConstants.ORDER_ROOT,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    perm: ElementConstants.ORDERS_SELLER_VIEW,
    shown: true,
    selectionText: 'Suppliers',
    dividerFollows: false
  };
  public static readonly ORDER_SELLER_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.order.supplier.supplierDetails',
    breadcrumb: 'Supplier Details',
    parent: RouteConstants.ORDER_SELLER,
    navigationId: NavigationConstants.ORDERING_NAV_ID
  };

  public static readonly ORDER_CATALOG_NON_CATALOG_PURCHASE: RouteInfo = {
    url: '/nonCatalogPurchase',
    name: 'home.order.nonCatalogPurchase',
    breadcrumb: 'Non-Catalog Purchase',
    parent: RouteConstants.ORDER_ROOT,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    shown: true, selectionText: 'Non-Catalog Purchase',
    perm: ElementConstants.ORDERS_NON_CATALOG_PURCHASE_VIEW,
    dividerFollows: true
  };

  public static readonly ORDER_CATALOG_NEW_SUPPLIER: RouteInfo = {
    url: '/createNewSupplier',
    name: 'home.order.nonCatalogPurchase.createNewSupplier',
    breadcrumb: 'Create New Supplier',
    parent: RouteConstants.ORDER_CATALOG_NON_CATALOG_PURCHASE,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    shown: false,
    perm: ElementConstants.ORDERS_VIEW,
  };

  public static readonly RECEIVING_ROOT: RouteInfo = {
    url: '/receiving',
    name: 'home.receiving',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.RECEIVING_NAV_ID,
  };

  public static readonly RECEIVE_DUEIN: RouteInfo = {
    url: '/inboundItems',
    name: 'home.receiving.inboundItems',
    breadcrumb: 'Inbound Items',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.RECEIVING_NAV_ID,
    shown: true,
    selectionText: 'Inbound Items',
    perm: ElementConstants.RECEIVE_ORDERS,
    dividerFollows: false
  };

  public static readonly RECEIVE_RECEIPT_DETAILS: RouteInfo = {
    url: '/receiptDetails',
    name: 'home.receiving.inboundItems.receiptDetail',
    breadcrumb: 'Receipt Details',
    parent: RouteConstants.RECEIVE_DUEIN,
    navigationId: NavigationConstants.RECEIVING_NAV_ID,
    perm: ElementConstants.RECEIVE_ORDERS_DETAILS,
    selectionText: 'Receipt Details',
    shown: true
  };

  public static readonly RECEIVE_HISTORY: RouteInfo = {
    url: '/receiptHistory',
    name: 'home.receiving.receiptHistory',
    breadcrumb: 'Receipt History',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.RECEIVING_NAV_ID,
    shown: true,
    selectionText: 'Receipt History',
    perm: ElementConstants.RECEIVE_ORDERS,
    dividerFollows: false
  };
  // ToDo: restore if we decide to implement PutAway Inventory functionality
  // public static readonly RECEIVE_PUT_AWAY: RouteInfo = {
  //   url: '/putAwayItems',
  //   name: 'home.receiving.putAwayItems',
  //   breadcrumb: 'Put-Away Items',
  //   parent: RouteConstants.HOME_ROOT,
  //   navigationId: NavigationConstants.RECEIVING_NAV_ID,
  //   shown: true,
  //   selectionText: 'Put-Away Items',
  //   perm: ElementConstants.RECEIVE_ORDERS
  // };
  public static readonly RECEIVE_STOCK_LISTS: RouteInfo = {
    url: '/stockLists',
    name: 'home.receiving.stockLists',
    breadcrumb: 'Stock Lists',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.RECEIVING_NAV_ID,
    shown: true,
    selectionText: 'Stock Lists',
    perm: ElementConstants.RECEIVE_ORDERS,
    dividerFollows: false
  };

  public static readonly FULFILLMENT_ORDER_FULFILLMENT: RouteInfo = {
    url: '/orderFulfillment',
    name: 'home.fulfillment.orderFulfillment',
    breadcrumb: 'Process Fulfillment',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Process Fulfillment',
  };
  public static readonly FULFILLMENT_FULFILLMENT_ACTIVITY: RouteInfo = {
    url: '/fulfillmentActivity',
    name: 'home.fulfillment.fulfillmentActivity',
    breadcrumb: 'Fulfillment Activity',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: true,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Fulfillment Activity',
  };
  public static readonly FULFILLMENT_PICKLIST_MANAGEMENT: RouteInfo = {
    url: '/picklistManagement',
    name: 'home.fulfillment.picklistManagement',
    breadcrumb: 'Picklist Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: false,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Picklist Management',
  };
  public static readonly PICKLIST_NOTES: RouteInfo = {
    url: '/picklistNotes',
    name: 'home.fulfillment.picklistManagement.picklistNotes',
    breadcrumb: 'Picklist Notes',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: false,
    selectionText: 'Picklist Notes',
  };
  public static readonly FULFILLMENT_DELIVERY_LIST_REPORT: RouteInfo = {
    url: '/deliveryListPrint',
    name: 'home.fulfillment.deliveryListPrint',
    breadcrumb: 'Delivery List Report',
    parent: RouteConstants.FULFILLMENT_ORDER_FULFILLMENT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: true,
    selectionText: 'Delivery List Report',
  };
  public static readonly FULFILLMENT_STAGED_ITEMS: RouteInfo = {
    url: '/stagedItems',
    name: 'home.fulfillment.stagedItems',
    breadcrumb: 'Staged Items',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: false,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Staged Items',
  };
  public static readonly FULFILLMENT_PICKLIST_REPORT: RouteInfo = {
    url: '/picklistPrint',
    name: 'home.fulfillment.picklistManagement.picklistPrint',
    breadcrumb: 'Picklist Report',
    parent: RouteConstants.FULFILLMENT_ORDER_FULFILLMENT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: true, perm: ElementConstants.ORDERS_VIEW,
    selectionText: 'Picklist Report',
  };

  public static readonly ORDER_DELIVERY_LIST: RouteInfo = {
    url: '/processDeliverList',
    name: 'home.fulfillment.processDeliveryList',
    breadcrumb: 'Delivery List',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID
  };


  public static readonly ORGANIZATION_DETAILS_SUPPLIER_MANAGEMENT: RouteInfo = {
    url: '/details',
    name: 'home.customer.customerDetails',
    breadcrumb: 'Details',
    parent: RouteConstants.ORDER_SELLER, navigationId: NavigationConstants.INVENTORY_NAV_ID
  };

  public static readonly FULFILLMENT: RouteInfo = {
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.FULFILLMENT_NAV_ID,
    shown: true,
    dividerFollows: false,
    perm: ElementConstants.INVENTORY_VIEW,
    selectionText: 'Fulfillment',
    url: '/fulfillment',
    name: 'home.fulfillment',
    breadcrumb: 'Fulfillment',
  };

  public static readonly ORDER_REQUISITION: RouteInfo = { // TODO confirm order requisition route
    url: '/requisition',
    name: 'home.requisition',
    breadcrumb: 'Requisition',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ORDERING_NAV_ID,
    shown: true, selectionText: 'Requisition',
    perm: ''
  };

  public static readonly EMAIL_CHECK: RouteInfo = {
    url: '/emailCheck',
    name: 'home.admin.emailCheck',
    breadcrumb: 'Email Check',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.EMAIL_CHECK,
    selectionText: 'Email Check',
  };
  public static readonly DATA_MANAGEMENT: RouteInfo = {
    url: '/dataManagement',
    name: 'home.admin.dataManagement',
    breadcrumb: 'Data Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.DATA_MANAGEMENT,
    selectionText: 'Data Management',
  };
  public static readonly DMLSS_HOST: RouteInfo = {
    url: '/dmlssHost',
    name: 'home.admin.dmlssHost',
    breadcrumb: 'DMLSS Host',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.DMLSS_HOST,
    selectionText: 'DMLSS Host',
  };
  public static readonly DMLSS_LIVE_DATA_MANAGEMENT: RouteInfo = {
    url: '/dmlssLiveDataManagement',
    name: 'home.admin.dmlssLiveDataManagement',
    breadcrumb: 'DMLSS Live Data Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.DMLSS_LIVE_DATA_MANAGEMENT,
    selectionText: 'DMLSS Live Data Management',
  };
  public static readonly HEALTH_STATUS: RouteInfo = {
    url: '/healthStatus',
    name: 'home.admin.healthStatus',
    breadcrumb: 'Health Status',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.HEALTH_STATUS,
    selectionText: 'Health Status',
  };
  public static readonly LEGACY_DMLSS_HISTORY_SEARCH: RouteInfo = {
    url: '/legacyDmlssHistory',
    name: 'home.admin.legacyDmlssHistory',
    breadcrumb: 'Legacy DMLSS History',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.LEGACY_DMLSS_HISTORY,
    selectionText: 'Legacy DMLSS History',
  };
  public static readonly LEGACY_DMLSS_HISTORY_DETAILS: RouteInfo = {
    url: '/legacyDmlssHistoryDetails?id',
    name: 'home.admin.legacyDmlssHistory.details',
    breadcrumb: 'Legacy DMLSS History Details',
    parent: RouteConstants.LEGACY_DMLSS_HISTORY_SEARCH,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.LEGACY_DMLSS_HISTORY_DETAILS,
    selectionText: 'Legacy DMLSS History Details',
  };
  public static readonly MMC_TEST: RouteInfo = {
    url: '/mmcTest',
    name: 'home.admin.mmcTest',
    breadcrumb: 'MMC Test',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.MMC_TEST,
    selectionText: 'MMC Test',
  };
  public static readonly EQUIPMENT_TESTING: RouteInfo = {
    url: '/equipment-testing',
    name: 'home.admin.equipmentTesting',
    breadcrumb: 'Equipment Testing',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.EQUIPMENT_TESTING,
    selectionText: 'Equipment Testing',
  };
  public static FEATURE_FLAG_VIEW: RouteInfo = {
    url: '/viewFeatureFlags',
    name: 'home.admin.featureFlags',
    breadcrumb: 'Feature Flags',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: true,
    perm: ElementConstants.FEATURE_FLAG_VIEW,
    selectionText: 'Feature Flags',
  };
  public static readonly FEATURE_FLAG_CREATE: RouteInfo = {
    url: '/createFeatureFlag',
    name: 'home.admin.featureFlags.createFeatureFlag',
    breadcrumb: 'Create Feature Flag',
    parent: RouteConstants.FEATURE_FLAG_VIEW,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.FEATURE_FLAG_CREATE,
    selectionText: 'Create Feature Flag',
  };
  public static readonly FEATURE_FLAG_EDIT: RouteInfo = {
    url: '/editFeatureFlag',
    name: 'home.admin.featureFlags.editFeatureFlag',
    breadcrumb: 'Edit Feature Flag',
    parent: RouteConstants.FEATURE_FLAG_VIEW,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    perm: ElementConstants.FEATURE_FLAG_EDIT,
    selectionText: 'Edit Feature Flag'
  };

  public static readonly CONFIGURATIONS_VIEW: RouteInfo = {
    url: '/viewConfigurations',
    name: 'home.admin.configurations',
    breadcrumb: 'Configuration Data',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.VIEW_SYSTEM_CONFIGURATIONS,
    selectionText: 'Configuration Data'
  };

  public static readonly CONFIGURATIONS_SERVER: RouteInfo = {
    url: '/serverConfigurations',
    name: 'home.admin.configurations.server',
    breadcrumb: 'Server Configurations',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.SERVER_CONFIGURATIONS,
    selectionText: 'Server Configurations'
  };

  public static FACILITY_RECORDS_DMLSS_MANAGEMENT: RouteInfo = {
    url: '/facilityRecordsDmlssManagement',
    name: 'home.admin.facilityRecordsDmlssManagement',
    breadcrumb: 'DMLSS Facility Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: true,
    perm: ElementConstants.FACILITY_RECORDS_DMLSS_MANAGEMENT,
    selectionText: 'DMLSS Facility Management',
  };

  public static readonly COMMUNICATIONS_TRANSLATIONS: RouteInfo = {
    url: '/communicationsTranslations',
    name: 'home.admin.communicationsTranslations',
    breadcrumb: 'Communications Translations',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.COMMUNICATIONS_EDI_TRANSLATIONS,
    selectionText: 'Communication Translations'
  };

  public static readonly INBOUND_TRANSLATION: RouteInfo = {
    url: '/inboundTranslation',
    name: 'home.admin.communicationsTranslations.inbound',
    parent: RouteConstants.COMMUNICATIONS_TRANSLATIONS,
    breadcrumb: 'Inbound',
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.COMMUNICATIONS_EDI_TRANSLATIONS,
    selectionText: 'Inbound Translation',
  };

  public static readonly OUTBOUND_TRANSLATION: RouteInfo = {
    url: '/outboundTranslation',
    name: 'home.admin.communicationsTranslations.outbound',
    parent: RouteConstants.COMMUNICATIONS_TRANSLATIONS,
    breadcrumb: 'Outbound',
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.COMMUNICATIONS_EDI_TRANSLATIONS,
    selectionText: 'Outbound Translation',
  };

  public static readonly MAXIMO_MANAGEMENT: RouteInfo = {
    url: '/maximoManagement',
    name: 'home.admin.maximoManagement',
    breadcrumb: 'CMMS Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID
  };
  public static readonly MAXIMO_WORK_ORDER: RouteInfo = {
    url: '/maximWorkOrder',
    name: 'home.admin.maximoManagement.maximoWorkOrder',
    breadcrumb: 'CMMS Work Order',
    parent: RouteConstants.MAXIMO_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.MAXIMO_WORK_ORDER,
    selectionText: 'CMMS Management'
  };

  public static readonly EHR_MANAGEMENT: RouteInfo = {
    url: '/ehrManagement',
    name: 'home.admin.ehrManagement',
    breadcrumb: 'EHR Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ADMIN_NAV_ID
  };
  public static readonly EHR_SITE_CUSTOMER_MANAGEMENT: RouteInfo = {
    url: '/ehrSiteCustomerManagement',
    name: 'home.admin.ehrManagement.ehrSiteCustomerManagement',
    breadcrumb: 'Site Customer Management',
    parent: RouteConstants.EHR_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.EHR_SITE_CUSTOMER_MANAGEMENT,
    selectionText: 'EHR Management'
  };
  public static readonly EHR_ITEM_SYNC: RouteInfo = {
    url: '/ehrItemSync',
    name: 'home.admin.ehrManagement.ehrItemSync',
    breadcrumb: 'Item Synchronization',
    parent: RouteConstants.EHR_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
  };
  public static readonly EHR_ITEM_SYNC_ITEM_SEARCH: RouteInfo = {
    url: '/itemSearch',
    name: 'home.admin.ehrManagement.ehrItemSync.itemSearch',
    breadcrumb: 'Item Search',
    parent: RouteConstants.EHR_ITEM_SYNC,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.EHR_ITEM_SYNC,
    selectionText: 'Item Search',
  };
  public static readonly EHR_ITEM_SYNC_ITEM_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.admin.ehrManagement.ehrItemSync.itemSearch.details',
    breadcrumb: 'Item Details',
    parent: RouteConstants.EHR_ITEM_SYNC_ITEM_SEARCH,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.EHR_ITEM_SYNC,
    selectionText: 'Item Details',
  };
  public static readonly EHR_ITEM_SYNC_ABI_SEARCH: RouteInfo = {
    url: '/abiSearch',
    name: 'home.admin.ehrManagement.ehrItemSync.abiSearch',
    breadcrumb: 'ABi Search',
    parent: RouteConstants.EHR_ITEM_SYNC,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.EHR_ITEM_SYNC,
    selectionText: 'ABi Search',
  };
  public static readonly EHR_ITEM_SYNC_ABI_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.admin.ehrManagement.ehrItemSync.abiSearch.details',
    breadcrumb: 'EHR ABi Details',
    parent: RouteConstants.EHR_ITEM_SYNC_ABI_SEARCH,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.EHR_ITEM_SYNC,
    selectionText: 'ABi Details',
  };
  public static readonly EHR_MANAGE_CLIENT_URLS: RouteInfo = {
    url: '/ehrManageClientUrls',
    name: 'home.admin.ehrManagement.ehrManageClientUrls',
    breadcrumb: 'Manage Client URLs',
    parent: RouteConstants.EHR_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.EHR_MANAGE_CLIENT_URLS,
    selectionText: 'Manage Client URLs',
  };

  public static readonly EHR_EQUIPMENT_SYNC: RouteInfo = {
    url: '/ehrEquipmentSync',
    name: 'home.admin.ehrManagement.ehrEquipmentSync',
    breadcrumb: 'Equipment Synchronization',
    parent: RouteConstants.EHR_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.EHR_EQUIPMENT_SYNC,
    selectionText: 'Equipment Synchronization'
  };
  public static readonly EHR_TESTING: RouteInfo = {
    url: '/ehrTesting',
    name: 'home.admin.ehrManagement.ehrTesting',
    breadcrumb: 'EHR Testing',
    parent: RouteConstants.EHR_MANAGEMENT,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.EHR_TESTING,
    selectionText: 'EHR Testing'
  };
  public static readonly CATALOG_MANAGEMENT: RouteInfo = {
    url: '/catalogManagement',
    name: 'home.admin.catalogManagement',
    breadcrumb: 'Catalog Management',
    parent: RouteConstants.JMLFDC_ADMIN,
    navigationId: NavigationConstants.ADMIN_NAV_ID,
    shown: false,
    perm: ElementConstants.CATALOG_MANAGEMENT,
    selectionText: 'Catalog Management'
  };

  public static readonly ORGANIZATION_ROOT: RouteInfo = {
    breadcrumb: 'Organization',
    url: '/organization',
    name: 'home.organization',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID
  };
  public static readonly ORGANIZATION_VIEW: RouteInfo = {
    url: '/organizationView',
    name: 'home.organization.organizationView',
    breadcrumb: 'Organization View',
    parent: RouteConstants.ORGANIZATION_ROOT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: false,
    perm: ElementConstants.ORGANIZATION_VIEW,
    selectionText: 'Organization View'
  };
  public static readonly ORGANIZATION_MANAGEMENT: RouteInfo = {
    url: '/organizationManagement',
    name: 'home.organization.organizationManagement',
    breadcrumb: 'Organization Management',
    parent: RouteConstants.ORGANIZATION_ROOT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: false,
    perm: ElementConstants.ORGANIZATION_MANAGEMENT,
    selectionText: 'Organization Management'
  };

  public static readonly ORGANIZATION_DATA_UPLOAD: RouteInfo = {
    url: '/organizationDataUpload',
    name: 'home.organization.organizationDataUpload',
    breadcrumb: 'Organization Data Upload',
    parent: RouteConstants.ORGANIZATION_ROOT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: false,
    perm: ElementConstants.ORGANIZATION_DATA_UPLOAD,
    selectionText: 'Organization Data Upload'
  };

  public static readonly ORGANIZATION_SERVICES: RouteInfo = {
    url: '/organizationServices',
    name: 'home.organization.organizationManagement.organizationRoleServicesManagement',
    breadcrumb: 'Organization Configuration',
    parent: RouteConstants.ORGANIZATION_MANAGEMENT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: false,
    perm: ElementConstants.ORGANIZATION_MANAGEMENT,
    selectionText: 'Organization Configuration'
  };
  public static readonly ORGANIZATION_SERVICES_CUSTOMER_SUPPLIER_ACCOUNTS: RouteInfo = {
    url: '/customerSupplierAccounts',
    name: 'home.organization.organizationManagement.organizationRoleServicesManagement.manageCustomerSupplierAccounts',
    breadcrumb: 'Supplier Accounts',
    parent: RouteConstants.ORGANIZATION_SERVICES,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: false,
    perm: ElementConstants.ORGANIZATION_SERVICES_CUSTOMER_SUPPLIER_ACCOUNTS,
    selectionText: 'Organization Configuration'
  };
  public static readonly ORGANIZATION_SERVICES_CUSTOMER_SELECT_NEW_SUPPLIER: RouteInfo = {
    url: '/selectSupplier',
    name: 'home.organization.organizationManagement.organizationRoleServicesManagement.manageCustomerSupplierAccounts.selectSupplier',
    breadcrumb: 'New Supplier Selection',
    parent: RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_SUPPLIER_ACCOUNTS,
    perm: ElementConstants.CUSTOMER_CREATE,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID
  };
  public static readonly ORGANIZATION_SERVICES_CUSTOMER_NEW_SUPPLIER_ACCOUNT: RouteInfo = {
    url: '/newSupplierAccount',
    name: 'home.organization.organizationManagement.organizationRoleServicesManagement.manageCustomerSupplierAccounts.newSupplierAccount',
    breadcrumb: 'New Supplier Account',
    parent: RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_SELECT_NEW_SUPPLIER,
    perm: ElementConstants.CUSTOMER_CREATE,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID
  };
  public static readonly ORGANIZATION_SERVICES_CUSTOMER_NEW_CUSTOMER: RouteInfo = {
    url: '/customerAccountCreate',
    name: 'home.organization.organizationManagement.organizationRoleServicesManagement.manageCustomerSupplierAccounts.newCustomer',
    breadcrumb: 'Create Customer Account',
    parent: RouteConstants.ORGANIZATION_SERVICES,
    perm: ElementConstants.CUSTOMER_CREATE,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID
  };
  public static readonly ORGANIZATION_CONSUMER_ADD_UPDATE: RouteInfo = {
    url: '/addUpdateConsumer',
    name: 'home.organization.organizationManagement.addUpdateConsumer',
    breadcrumb: 'Add Update Consumer',
    parent: RouteConstants.ORGANIZATION_MANAGEMENT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: false,
    perm: ElementConstants.ORGANIZATION_CONSUMER_ADD_UPDATE,
    selectionText: 'Organization Management'
  };
  public static readonly BUSINESS_SERVICE_DEFINITION_MANAGEMENT: RouteInfo = {
    url: '/businessServiceDefinitionManagement',
    name: 'home.organization.businessServiceDefinitionManagement',
    breadcrumb: 'Business Service Definition Management',
    parent: RouteConstants.ORGANIZATION_ROOT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: false,
    perm: ElementConstants.ORGANIZATION_BUSINESS_SERVICE_DEFINITIONS,
    selectionText: 'Business Service Definition Management'
  };
  public static readonly BUSINESS_SERVICE_DEFINITION_ADD_UPDATE: RouteInfo = {
    url: '/businessServiceDefinitionAddUpdate',
    name: 'home.organization.businessServiceDefinitionManagement.businessServiceDefinitionAddUpdate',
    breadcrumb: 'Business Service Definition',
    parent: RouteConstants.BUSINESS_SERVICE_DEFINITION_MANAGEMENT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: false,
    perm: ElementConstants.ORGANIZATION_BUSINESS_SERVICE_DEFINITIONS,
    selectionText: 'Business Service Definition'
  };
  public static readonly PROVIDER_MANAGEMENT: RouteInfo = {
    url: '/providerManagement',
    name: 'home.organization.providerManagement',
    breadcrumb: 'Service Provider Management',
    parent: RouteConstants.ORGANIZATION_ROOT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: false,
    perm: ElementConstants.PROVIDER_MANAGEMENT,
    selectionText: 'Service Provider Management'
  };
  public static readonly PROVIDER_ADD_UPDATE: RouteInfo = {
    url: '/addUpdateProvider',
    name: 'home.organization.providerManagement.addUpdateProvider',
    breadcrumb: 'Service Provider Add Update',
    parent: RouteConstants.PROVIDER_MANAGEMENT,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: false,
    selectionText: 'Service Provider Add Update'
  };
  public static readonly ORGANIZATION_TESTING: RouteInfo = {
    url: '/organizationTesting',
    name: 'home.organization.organizationTesting',
    breadcrumb: 'Organization Testing',
    parent: RouteConstants.ORGANIZATION_ROOT,
    perm: ElementConstants.ORGANIZATION_TESTING,
    navigationId: NavigationConstants.ORGANIZATION_NAV_ID,
    shown: false,
    selectionText: 'Organization Testing'
  };

  public static readonly COMMUNICATIONS_ROOT: RouteInfo = {
    breadcrumb: 'Communications',
    url: '/communications',
    name: 'home.communications',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID
  };
  public static readonly COMMUNICATION_TRANSACTIONS: RouteInfo = {
    url: '/communicationTransactions',
    name: 'home.communications.communicationTransactions',
    breadcrumb: 'Communication Transactions',
    parent: RouteConstants.COMMUNICATIONS_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_RESPONSE_VIEW,
    selectionText: 'Communication Transactions'
  };
  public static readonly COMMUNICATION_TRANSACTION_DETAILS: RouteInfo = {
    url: '/communicationTransactionDetails',
    name: 'home.communications.communicationTransactions.communicationTransactionDetails',
    breadcrumb: 'Transaction Details',
    parent: RouteConstants.COMMUNICATION_TRANSACTIONS,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_RESPONSE_DETAILS,
    selectionText: 'Communication Transaction Details'
  };
  public static readonly COMMUNICATIONS_OUTBOUND_CONFIG: RouteInfo = {
    url: '/viewCommunicationsOutboundConfig',
    name: 'home.communications.manageCommunicationsOutboundConfig',
    breadcrumb: 'Manage Outbound Transmission Configurations',
    parent: RouteConstants.COMMUNICATIONS_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: false,
    perm: ElementConstants.COMMUNICATIONS_OUTBOUND_TRANSMISSION_CONFIG_VIEW,
    selectionText: 'Manage Outbound Transmission Configurations'
  };
  public static readonly DAAS_TESTING: RouteInfo = {
    url: '/daasTesting',
    name: 'home.communications.daasTesting',
    breadcrumb: 'DAAS Testing',
    parent: RouteConstants.COMMUNICATIONS_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: false,
    perm: ElementConstants.COMMUNICATIONS_DAAS_TESTING,
    selectionText: 'DAAS Testing'
  };
  public static readonly EDI_TESTING: RouteInfo = {
    url: '/ediTesting',
    name: 'home.communications.ediTesting',
    breadcrumb: 'EDI Testing',
    parent: RouteConstants.COMMUNICATIONS_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    shown: false,
    perm: ElementConstants.COMMUNICATIONS_EDI_TESTING,
    selectionText: 'EDI Testing'
  };
  public static readonly EHR_MESSAGES: RouteInfo = {
    url: '/messages',
    name: 'home.communications.ehrMessages',
    breadcrumb: 'EHR Messages',
    parent: RouteConstants.COMMUNICATIONS_ROOT,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW,
    selectionText: 'EHR Messages'
  };
  public static readonly EHR_INCOMING_TRAFFIC_VIEW: RouteInfo = {
    url: '/incomingTraffic',
    name: 'home.communications.ehrMessages.incomingTraffic',
    breadcrumb: 'Incoming Traffic',
    parent: RouteConstants.EHR_MESSAGES,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW,
    selectionText: 'EHR Messages'
  };
  public static readonly EHR_INCOMING_TRAFFIC_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.communications.ehrMessages.incomingTraffic.details',
    breadcrumb: 'Incoming Traffic Details',
    parent: RouteConstants.EHR_INCOMING_TRAFFIC_VIEW,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW,
  };
  public static readonly EHR_OUTGOING_TRAFFIC_VIEW: RouteInfo = {
    url: '/outgoingTraffic',
    name: 'home.communications.ehrMessages.outgoingTraffic',
    breadcrumb: 'Outgoing Traffic',
    parent: RouteConstants.EHR_MESSAGES,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW,
  };
  public static readonly EHR_OUTGOING_TRAFFIC_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.communications.ehrMessages.outgoingTraffic.details',
    breadcrumb: 'Outgoing Traffic Details',
    parent: RouteConstants.EHR_OUTGOING_TRAFFIC_VIEW,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW,
  };
  public static readonly EHR_REQUEST_QUEUE_VIEW: RouteInfo = {
    url: '/requestQueue',
    name: 'home.communications.ehrMessages.requestQueue',
    breadcrumb: 'Request Queue',
    parent: RouteConstants.EHR_MESSAGES,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW,
  };
  public static readonly EHR_REQUEST_QUEUE_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.communications.ehrMessages.requestQueue.details',
    breadcrumb: 'Request Queue Details',
    parent: RouteConstants.EHR_REQUEST_QUEUE_VIEW,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW,
  };
  public static readonly EHR_OUTGOING_ORDER_VIEW: RouteInfo = {
    url: '/outgoingOrders',
    name: 'home.communications.ehrMessages.outgoingOrders',
    breadcrumb: 'Outgoing Orders',
    parent: RouteConstants.EHR_MESSAGES,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW,
  };
  public static readonly EHR_OUTGOING_ORDER_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.communications.ehrMessages.outgoingOrders.details',
    breadcrumb: 'Outgoing Order Details',
    parent: RouteConstants.EHR_OUTGOING_ORDER_VIEW,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW,
  };
  public static readonly EHR_OUTGOING_STATUS_MESSAGE_VIEW: RouteInfo = {
    url: '/outgoingStatusMessages',
    name: 'home.communications.ehrMessages.outgoingStatusMessages',
    breadcrumb: 'Outgoing Status Messages',
    parent: RouteConstants.EHR_MESSAGES,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW
  };
  public static readonly EHR_OUTGOING_STATUS_MESSAGE_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.communications.ehrMessages.outgoingStatusMessages.details',
    breadcrumb: 'Outgoing Status Message Details',
    parent: RouteConstants.EHR_OUTGOING_STATUS_MESSAGE_VIEW,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW,
  };
  public static readonly EHR_TASK_HISTORY_VIEW: RouteInfo = {
    url: '/taskHistory',
    name: 'home.communications.ehrMessages.taskHistory',
    breadcrumb: 'Task History',
    parent: RouteConstants.EHR_MESSAGES,
    navigationId: NavigationConstants.COMMUNICATIONS_NAV_ID,
    perm: ElementConstants.COMMUNICATIONS_EHR_VIEW,
  };

  public static readonly EQUIPMENT_ROOT: RouteInfo = {
    url: '/equipment',
    name: 'home.equipment',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID
  };
  public static readonly DMLSS_EQUIPMENT_RECORDS: RouteInfo = {
    url: '/records',
    name: 'home.equipment.dmlssRecords',
    breadcrumb: 'DMLSS Equipment Records',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.DMLES_EQUIP_RECORDS_VIEW,
    selectionText: 'DMLSS Equipment Records',
    shown: false
  };
  public static readonly EQUIPMENT_RECORD_DETAILS: RouteInfo = {
    url: '/:dodaac/:meId',
    name: 'home.equipment.dmlssRecords.details',
    breadcrumb: 'DMLSS Equipment Record Details',
    parent: RouteConstants.DMLSS_EQUIPMENT_RECORDS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID
  };
  public static readonly EQUIPMENT_REQUESTS: RouteInfo = {
    url: '/requests',
    name: 'home.equipment.requests',
    breadcrumb: 'Equipment Requests',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.EQUIP_REQUESTS_VIEW,
    selectionText: 'Equipment Requests',
    shown: false
  };
  public static readonly EQUIPMENT_REQUEST: RouteInfo = {
    url: '/request',
    name: 'home.equipment.requests.request',
    breadcrumb: 'Equipment Request',
    parent: RouteConstants.EQUIPMENT_REQUESTS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID
  };
  public static readonly EQUIPMENT_REQUEST_PRINT: RouteInfo = {
    url: '/print',
    name: 'home.equipment.requests.request.print',
    breadcrumb: 'Print Equipment Request',
    parent: RouteConstants.EQUIPMENT_REQUEST,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID
  };
  public static readonly EQUIPMENT_PRIORITIZATION: RouteInfo = {
    url: '/requestPrioritization',
    name: 'home.equipment.requestPrioritization',
    breadcrumb: 'Equipment Request Prioritization',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.EQUIP_REQUEST_PRIORITIZATION,
    selectionText: 'Equipment Request Prioritization',
    dividerFollows: true
  };
  public static readonly EQUIPMENT_MANUFACTURER: RouteInfo = {
    url: '/manufacturer',
    name: 'home.asset.manufacturer',
    breadcrumb: 'Manufacturer',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_MANUFACTURER_VIEW,
    selectionText: 'Manufacturer'
  };
  public static readonly EQUIPMENT_MANUFACTURER_DETAILS: RouteInfo = {
    url: '/:id',
    name: 'home.asset.manufacturer.details',
    breadcrumb: 'Manufacturer Details',
    parent: RouteConstants.EQUIPMENT_MANUFACTURER,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID
  };
  public static readonly EQUIPMENT_MANUFACTURER_NEW: RouteInfo = {
    url: '/new',
    name: 'home.asset.manufacturer.new',
    breadcrumb: 'New Manufacturer',
    parent: RouteConstants.EQUIPMENT_MANUFACTURER,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'New Manufacturer'
  };
  public static readonly EQUIPMENT_NOMENCLATURE: RouteInfo = {
    url: '/nomenclature',
    name: 'home.asset.nomenclature',
    breadcrumb: 'Nomenclature',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_NOMENCLATURE_VIEW,
    selectionText: 'Nomenclature',
  };
  public static readonly EQUIPMENT_NOMENCLATURE_NEW: RouteInfo = {
    url: '/new',
    name: 'home.asset.nomenclature.new',
    breadcrumb: 'New Nomenclature',
    parent: RouteConstants.EQUIPMENT_NOMENCLATURE,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'New Nomenclature'
  };
  public static readonly EQUIPMENT_NOMENCLATURE_DETAILS: RouteInfo = {
    url: '/:id',
    name: 'home.asset.nomenclature.details',
    breadcrumb: 'Nomenclature Details',
    parent: RouteConstants.EQUIPMENT_NOMENCLATURE,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID
  };
  public static readonly EQUIPMENT_CLASSIFICATION_REQUEST: RouteInfo = {
    url: '/classificationRequest',
    name: 'home.asset.classificationRequest',
    breadcrumb: 'Classification Requests',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.EQUIPMENT_CLASSIFICATION_REQUEST,
    selectionText: 'Classification Requests'
  };
  public static readonly EQUIPMENT_NEW_CLASSIFICATION_REQUEST: RouteInfo = {
    url: '/newClassificationRequest',
    name: 'home.asset.classificationRequest.newClassificationRequest',
    breadcrumb: 'New Manufacturer/Nomenclature Request',
    parent: RouteConstants.EQUIPMENT_CLASSIFICATION_REQUEST,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'New Manufacturer/Nomenclature Request'
  };
  public static readonly EQUIPMENT_MANUFACTURER_REQUEST_MANAGEMENT: RouteInfo = {
    url: '/manufacturerDetails',
    name: 'home.asset.classificationRequest.manufacturerDetails',
    breadcrumb: 'Manufacturer Request Details',
    parent: RouteConstants.EQUIPMENT_CLASSIFICATION_REQUEST,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Manufacturer Request Details'
  };
  public static readonly EQUIPMENT_NOMENCLATURE_REQUEST_MANAGEMENT: RouteInfo = {
    url: '/nomenclatureDetails',
    name: 'home.asset.classificationRequest.nomenclatureDetails',
    breadcrumb: 'Nomenclature Request Details',
    parent: RouteConstants.EQUIPMENT_CLASSIFICATION_REQUEST,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Nomenclature Request Details'
  };

  public static readonly REAL_PROPERTY_ROOT: RouteInfo = {
    url: '/realProperty',
    name: 'home.realProperty',
    breadcrumb: 'Real Property',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID
  };
  public static readonly REAL_PROPERTY_DRAWING_SPACE_FILL: RouteInfo = {
    url: '/drawingSpaceFill',
    name: 'home.realProperty.drawingSpaceFill',
    breadcrumb: 'Drawing - Space Fill',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_DRAWING_SPACE_FILL_VIEW,
    selectionText: 'Drawing - Space Fill ',
    shown: false
  };
  public static readonly REAL_PROPERTY_DATA_MANAGER: RouteInfo = {
    url: '/dataManager',
    name: 'home.realProperty.dataManager',
    breadcrumb: 'Data Manager',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_DATA_MANAGER_VIEW,
    selectionText: 'Data Manager',
    shown: false
  };
  public static readonly REAL_PROPERTY_INSTALLATIONS: RouteInfo = {
    url: '/installationManagement',
    name: 'home.realProperty.installationManagement',
    breadcrumb: 'Installations',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_INSTALLATIONS_MANAGEMENT,
    selectionText: 'Installations',
    shown: false
  };
  public static readonly REAL_PROPERTY_INSTALLATION_MANAGEMENT: RouteInfo = {
    url: '/installationDetails',
    name: 'home.realProperty.installationManagement.installationDetails',
    parent: RouteConstants.REAL_PROPERTY_INSTALLATIONS,
    breadcrumb: 'Installation Details',
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    shown: false,
    perm: ElementConstants.REAL_PROPERTY_INSTALLATIONS_MANAGEMENT,
    selectionText: 'Installation Details'
  };
  public static readonly REAL_PROPERTY_NEW_INSTALLATION: RouteInfo = {
    url: '/newInstallation',
    name: 'home.realProperty.installationManagement.newInstallation',
    parent: RouteConstants.REAL_PROPERTY_INSTALLATIONS,
    breadcrumb: 'New Installation',
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    shown: false,
    perm: ElementConstants.REAL_PROPERTY_INSTALLATION_CREATE,
    selectionText: 'New Installation'
  };

  public static readonly REAL_PROPERTY_SITES: RouteInfo = {
    url: '/siteManagement',
    name: 'home.realProperty.siteManagement',
    breadcrumb: 'Sites',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SITES_MANAGEMENT,
    selectionText: 'Sites',
    shown: false
  };
  public static readonly REAL_PROPERTY_SITE_MANAGEMENT: RouteInfo = {
    url: '/siteDetails',
    name: 'home.realProperty.siteManagement.siteDetails',
    parent: RouteConstants.REAL_PROPERTY_SITES,
    breadcrumb: 'Site Details',
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    shown: false,
    perm: ElementConstants.REAL_PROPERTY_SITES_MANAGEMENT,
    selectionText: 'Site Details'
  };
  public static readonly REAL_PROPERTY_NEW_SITE: RouteInfo = {
    url: '/newSite',
    name: 'home.realProperty.siteManagement.newSite',
    parent: RouteConstants.REAL_PROPERTY_SITES,
    breadcrumb: 'New Site',
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    shown: false,
    perm: ElementConstants.REAL_PROPERTY_SITE_CREATE,
    selectionText: 'New Site'
  };

  public static readonly REAL_PROPERTY_FACILITY_MANAGEMENT: RouteInfo = {
    url: '/facilityManagement',
    name: 'home.realProperty.facilityManagement',
    breadcrumb: 'Buildings and Structures',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_FACILITY_MANAGEMENT,
    selectionText: 'Buildings and Structures (Facilities)',
    shown: false
  };

  public static readonly REAL_PROPERTY_FACILITY_REPORTS: RouteInfo = {
    url: '/facilityReports',
    name: 'home.realProperty.facilityReports',
    breadcrumb: 'Facility Reports',
    parent: RouteConstants.MY_DASHBOARD,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_FACILITY_VIEW,
    selectionText: 'Pre-defined Facility Report',
    shown: false
  };

  public static readonly REAL_PROPERTY_NEW_FACILITY: RouteInfo = {
    url: '/newFacility',
    name: 'home.realProperty.facilityManagement.newFacility',
    breadcrumb: 'New Facility',
    parent: RouteConstants.REAL_PROPERTY_FACILITY_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_FACILITY_CREATE,
    selectionText: 'New Facility',
    shown: false
  };
  public static readonly REAL_PROPERTY_FACILITY_VIEW: RouteInfo = {
    url: '/facilityDetails',
    name: 'home.realProperty.facilityManagement.facilityDetails',
    breadcrumb: 'Facility Details',
    parent: RouteConstants.REAL_PROPERTY_FACILITY_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_FACILITY_VIEW,
    selectionText: 'Facility Details',
    shown: false
  };
  public static readonly REAL_PROPERTY_FACILITY_BULK_UPDATE_CONFIRM: RouteInfo = {
    url: '/facilityBulkUpdateConfirm',
    name: 'home.realProperty.facilityManagement.facilityBulkUpdateConfirm',
    breadcrumb: 'Facilities Bulk Update - Confirm',
    parent: RouteConstants.REAL_PROPERTY_FACILITY_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_FACILITY_BULK_UPDATE_CONFIRM,
    selectionText: 'Bulk Update - Confirm',
    shown: false
  };
  public static readonly REAL_PROPERTY_FACILITY_BULK_UPDATE_RESULTS: RouteInfo = {
    url: '/facilityBulkUpdateResults',
    name: 'home.realProperty.facilityManagement.facilityBulkUpdateResults',
    breadcrumb: 'Facilities Bulk Update - Results',
    parent: RouteConstants.REAL_PROPERTY_FACILITY_BULK_UPDATE_CONFIRM,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_FACILITY_BULK_UPDATE_RESULTS,
    selectionText: 'Bulk Update - Results',
    shown: false
  };
  public static readonly REAL_PROPERTY_FACILITY_COBIE_IMPORT: RouteInfo = {
    url: '/facilityCobieImport',
    name: 'home.realProperty.facilityManagement.facilityCobieImport',
    breadcrumb: 'COBie Import',
    parent: RouteConstants.REAL_PROPERTY_FACILITY_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_FACILITY_COBIE_IMPORT,
    selectionText: 'COBie Import',
    shown: false
  };

  public static readonly SPACE_ROOT: RouteInfo = {
    url: '/space',
    name: 'home.space',
    breadcrumb: 'Rooms and Spaces',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID
  };
  public static readonly REAL_PROPERTY_SPACE_MANAGEMENT: RouteInfo = {
    url: '/spaceManagement',
    name: 'home.space.spaceManagement',
    breadcrumb: 'Rooms and Spaces',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_MANAGEMENT,
    selectionText: 'Rooms and Spaces',
    shown: false
  };
  public static readonly REAL_PROPERTY_SPACE_VIEW: RouteInfo = {
    url: '/spaceDetails',
    name: 'home.space.spaceManagement.spaceDetails',
    breadcrumb: 'Space Details',
    parent: RouteConstants.REAL_PROPERTY_SPACE_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_VIEW,
    selectionText: 'Space Details',
    shown: false
  };

  public static readonly REAL_PROPERTY_SPACE_REPORTS: RouteInfo = {
    url: '/spaceReports',
    name: 'home.space.spaceReports',
    breadcrumb: 'Space Reports',
    parent: RouteConstants.MY_DASHBOARD,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_VIEW,
    selectionText: 'Pre-defined Space Report',
    shown: false
  };
  public static readonly REAL_PROPERTY_SPACE_REPORTS_VIEW: RouteInfo = {
    url: '/spaceDetails',
    name: 'home.space.spaceReports.spaceDetails',
    breadcrumb: 'Space Details',
    parent: RouteConstants.REAL_PROPERTY_SPACE_REPORTS,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_VIEW,
    selectionText: 'Space Details',
    shown: false
  };

  public static readonly REAL_PROPERTY_NEW_SPACE: RouteInfo = {
    url: '/newSpace',
    name: 'home.space.spaceManagement.newSpace',
    breadcrumb: 'New Space',
    parent: RouteConstants.REAL_PROPERTY_SPACE_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_CREATE,
    selectionText: 'New Space',
    shown: false
  };
  public static readonly REAL_PROPERTY_SPACE_BULK_UPDATE_SELECT_FIELDS: RouteInfo = {
    url: '/spaceBulkUpdateSelectFields',
    name: 'home.space.spaceManagement.spaceBulkUpdateSelectFields',
    breadcrumb: 'Rooms and Spaces Bulk Update - Select Field',
    parent: RouteConstants.REAL_PROPERTY_SPACE_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_BULK_UPDATE_SELECT_FIELDS,
    selectionText: 'Rooms and Spaces Space Bulk Update - Select Field',
    shown: false
  };
  public static readonly REAL_PROPERTY_SPACE_BULK_UPDATE_CONFIRM: RouteInfo = {
    url: '/spaceBulkUpdateConfirm',
    name: 'home.space.spaceManagement.spaceBulkUpdateConfirm',
    breadcrumb: 'Rooms and Spaces Bulk Update - Confirm',
    parent: RouteConstants.REAL_PROPERTY_SPACE_BULK_UPDATE_SELECT_FIELDS,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_BULK_UPDATE_CONFIRM,
    selectionText: 'Rooms and Spaces Bulk Update - Confirm',
    shown: false
  };
  public static readonly REAL_PROPERTY_SPACE_BULK_UPDATE_RESULTS: RouteInfo = {
    url: '/spaceBulkUpdateResults',
    name: 'home.space.spaceManagement.spaceBulkUpdateResults',
    breadcrumb: 'Rooms and Spaces Bulk Update - Results',
    parent: RouteConstants.REAL_PROPERTY_SPACE_BULK_UPDATE_CONFIRM,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_BULK_UPDATE_RESULTS,
    selectionText: 'Rooms and Spaces Bulk Update - Results',
    shown: false
  };
  public static readonly REAL_PROPERTY_SPACE_GRAPHICAL_SEARCH: RouteInfo = {
    url: '/graphicalSearch',
    name: 'home.space.spaceManagement.graphicalSearch',
    breadcrumb: 'Rooms and Spaces Graphical Search',
    parent: RouteConstants.REAL_PROPERTY_SPACE_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_GRAPHICAL_SEARCH,
    selectionText: 'Rooms and Spaces Graphical Search',
    shown: false
  };
  public static readonly REAL_PROPERTY_SPACE_OCCUPANTS: RouteInfo = {
    url: '/spaceOccupants',
    name: 'home.space.spaceOccupants',
    breadcrumb: 'Occupants',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_OCCUPANTS,
    selectionText: 'Occupants',
    shown: false
  };
  public static readonly REAL_PROPERTY_SPACE_OCCUPANTS_VIEW: RouteInfo = {
    url: '/spaceOccupantDetails',
    name: 'home.space.spaceOccupants.spaceOccupantDetails',
    breadcrumb: 'Occupant Details',
    parent: RouteConstants.REAL_PROPERTY_SPACE_OCCUPANTS,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_OCCUPANTS_VIEW,
    selectionText: 'Occupant Details',
    shown: false
  };
  public static readonly REAL_PROPERTY_NEW_SPACE_OCCUPANT: RouteInfo = {
    url: '/newSpaceOccupant',
    name: 'home.space.spaceOccupants.newSpaceOccupant',
    breadcrumb: 'New Occupant',
    parent: RouteConstants.REAL_PROPERTY_SPACE_OCCUPANTS,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_OCCUPANT_CREATE,
    selectionText: 'New Occupant',
    shown: false
  };
  public static readonly REAL_PROPERTY_SPACE_OCCUPANT_GRAPHICAL_SEARCH: RouteInfo = {
    url: '/graphicalSearch',
    name: 'home.space.spaceOccupants.graphicalSearch',
    breadcrumb: 'Occupants Graphical Search',
    parent: RouteConstants.REAL_PROPERTY_SPACE_OCCUPANTS,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SPACE_OCCUPANT_GRAPHICAL_SEARCH,
    selectionText: 'Occupants Graphical Search',
    shown: false
  };

  public static readonly REAL_PROPERTY_DRAWING_MANAGEMENT: RouteInfo = {
    url: '/drawingManagement',
    name: 'home.space.drawingManagement',
    breadcrumb: 'Drawings',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_DRAWING_MANAGEMENT,
    selectionText: 'Drawings',
    dividerFollows: true
  };
  public static readonly REAL_PROPERTY_DRAWING_VIEW: RouteInfo = {
    url: '/drawingDetails',
    name: 'home.space.drawingManagement.drawingDetails',
    breadcrumb: 'Drawing Details',
    parent: RouteConstants.REAL_PROPERTY_DRAWING_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_DRAWING_VIEW,
    selectionText: 'Drawing Details',
    shown: false
  };
  public static readonly REAL_PROPERTY_DRAWING_ADD_ROOMS: RouteInfo = {
    url: '/addRooms',
    name: 'home.space.drawingManagement.drawingDetails.addRooms',
    breadcrumb: 'Add Rooms',
    parent: RouteConstants.REAL_PROPERTY_DRAWING_VIEW,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_DRAWING_ADD_ROOMS,
    selectionText: 'Add Rooms',
    shown: false
  };
  public static readonly REAL_PROPERTY_DRAWING_ADD_ROOMS_RESULTS: RouteInfo = {
    url: '/addRoomsResults',
    name: 'home.space.drawingManagement.drawingDetails.addRooms.results',
    breadcrumb: 'Add Rooms - Results',
    parent: RouteConstants.REAL_PROPERTY_DRAWING_ADD_ROOMS,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_DRAWING_ADD_ROOMS_RESULTS,
    selectionText: 'Add Rooms - Results',
    shown: false
  };
  public static readonly REAL_PROPERTY_DRAWING_BULK_UPLOAD: RouteInfo = {
    url: '/bulkUpload',
    name: 'home.space.drawingManagement.bulkUpload',
    breadcrumb: 'Bulk Upload',
    parent: RouteConstants.REAL_PROPERTY_DRAWING_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_DRAWING_BULK_UPLOAD,
    selectionText: 'Bulk Upload',
    shown: false
  };
  public static readonly REAL_PROPERTY_DRAWING_DASHBOARD: RouteInfo = {
    url: '/dashboard',
    name: 'home.space.drawingManagement.dashboard',
    breadcrumb: 'Drawing Dashboard',
    parent: RouteConstants.MY_DASHBOARD,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID
  };
  public static readonly REAL_PROPERTY_DRAWING_DASHBOARD_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.space.drawingManagement.dashboard.details',
    breadcrumb: 'Drawing Details',
    parent: RouteConstants.REAL_PROPERTY_DRAWING_DASHBOARD,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID
  };

  public static readonly REQUIREMENTS_ROOT: RouteInfo = {
    url: '/requirements',
    name: 'home.requirements',
    breadcrumb: 'Requirements',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID
  };

  public static readonly REAL_PROPERTY_REQUIREMENTS_MANAGEMENT: RouteInfo = {
    url: '/requirementsManagement',
    name: 'home.requirements.requirementsManagement',
    breadcrumb: 'Requirements',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REQUIREMENTS_MANAGEMENT,
    selectionText: 'Requirements',
    shown: false
  };
  public static readonly REAL_PROPERTY_REQUIREMENTS_PRIORITIZATION: RouteInfo = {
    url: '/prioritization',
    name: 'home.requirements.requirementPrioritization',
    breadcrumb: 'Requirements Prioritization',
    parent: RouteConstants.REAL_PROPERTY_REQUIREMENTS_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REQUIREMENTS_PRIORITIZATION,
    selectionText: 'Requirements Prioritization',
    shown: false
  };
  public static readonly REAL_PROPERTY_REQUIREMENTS_DETAILS: RouteInfo = {
    url: '/requirementDetails/:id',
    name: 'home.requirements.requirementsManagement.requirementDetails',
    breadcrumb: 'Requirement Details',
    parent: RouteConstants.REAL_PROPERTY_REQUIREMENTS_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REQUIREMENTS_VIEW,
    shown: false
  };
  public static readonly REAL_PROPERTY_NEW_REQUIREMENT: RouteInfo = {
    url: '/newRequirement',
    name: 'home.requirements.requirementsManagement.newRequirement',
    breadcrumb: 'New Requirement',
    parent: RouteConstants.REAL_PROPERTY_REQUIREMENTS_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REQUIREMENT_CREATE,
    selectionText: 'New Requirement',
    shown: false
  };
  public static readonly REAL_PROPERTY_REQUIREMENT_BULK_UPDATE_CONFIRM: RouteInfo = {
    url: '/requirementBulkUpdateConfirm',
    name: 'home.requirements.requirementsManagement.requirementBulkUpdateConfirm',
    breadcrumb: 'Requirements Bulk Update - Confirm',
    parent: RouteConstants.REAL_PROPERTY_REQUIREMENTS_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REQUIREMENT_BULK_UPDATE_CONFIRM,
    selectionText: 'Requirements Bulk Update - Confirm',
    shown: false
  };
  public static readonly REAL_PROPERTY_REQUIREMENT_BULK_UPDATE_RESULTS: RouteInfo = {
    url: '/requirementBulkUpdateResults',
    name: 'home.requirements.requirementsManagement.requirementBulkUpdateResults',
    breadcrumb: 'Requirements Bulk Update - Confirm',
    parent: RouteConstants.REAL_PROPERTY_REQUIREMENTS_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REQUIREMENT_BULK_UPDATE_CONFIRM,
    selectionText: 'Requirements Bulk Update - Results',
    shown: false
  };

  public static readonly REAL_PROPERTY_REQUIREMENT_JOURNAL_ACTION_INFO: RouteInfo = {
    url: '/requirementJournalActionInfo',
    name: 'home.requirements.requirementJournalActionInfo',
    breadcrumb: 'Requirement Journal Action Info',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
  };

  public static readonly REAL_PROPERTY_REQUIREMENT_REQUEST_ACTION_INFO: RouteInfo = {
    url: '/requirementsRequestActionInfo',
    name: 'home.requirements.requirementsRequestActionInfo',
    breadcrumb: 'Requirement Request Action Info',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
  };

  public static readonly REAL_PROPERTY_REQUIREMENT_GRAPHICAL_SEARCH: RouteInfo = {
    url: '/graphicalSearch',
    name: 'home.requirements.requirementsManagement.graphicalSearch',
    breadcrumb: 'Requirements Graphical Search',
    parent: RouteConstants.REAL_PROPERTY_REQUIREMENTS_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REQUIREMENT_GRAPHICAL_SEARCH,
    selectionText: 'Requirements Graphical Search',
    shown: false
  };

  public static readonly REAL_PROPERTY_REQUIREMENT_FORM_GENERATION: RouteInfo = {
    url: '/formGeneration',
    name: 'home.requirements.requirementsManagement.formGeneration',
    breadcrumb: 'Requirements Form Generation',
    parent: RouteConstants.REAL_PROPERTY_REQUIREMENTS_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REQUIREMENT_GENERATE_FORMS
  };

  public static readonly PROJECT_ROOT: RouteInfo = {
    url: '/project',
    name: 'home.project',
    breadcrumb: 'Projects',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID
  };

  public static readonly REAL_PROPERTY_PROJECT_MANAGEMENT: RouteInfo = {
    url: '/projectManagement',
    name: 'home.project.projectManagement',
    breadcrumb: 'Projects',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_PROJECT_MANAGEMENT,
    selectionText: 'Projects',
    dividerFollows: true,
    shown: false
  };
  public static readonly REAL_PROPERTY_PROJECT_BULK_UPDATE_CONFIRM: RouteInfo = {
    url: '/projectBulkUpdateConfirm',
    name: 'home.project.projectManagement.projectBulkUpdateConfirm',
    breadcrumb: 'Projects Bulk Update - Confirm',
    parent: RouteConstants.REAL_PROPERTY_PROJECT_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_PROJECT_BULK_UPDATE_CONFIRM,
    selectionText: 'Projects Bulk Update - Confirm',
    shown: false
  };
  public static readonly REAL_PROPERTY_PROJECT_BULK_UPDATE_RESULTS: RouteInfo = {
    url: '/projectBulkUpdateResults',
    name: 'home.project.projectManagement.projectBulkUpdateResults',
    breadcrumb: 'Projects Bulk Update - Results',
    parent: RouteConstants.REAL_PROPERTY_PROJECT_BULK_UPDATE_CONFIRM,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_PROJECT_BULK_UPDATE_RESULTS,
    selectionText: 'Projects Bulk Update - Results',
    shown: false
  };

  public static readonly REAL_PROPERTY_PROJECT_DETAILS: RouteInfo = {
    url: '/projectsDetails/:id',
    name: 'home.project.projectManagement.projectDetails',
    breadcrumb: 'Project Details',
    parent: RouteConstants.REAL_PROPERTY_PROJECT_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_PROJECT_VIEW,
    selectionText: 'Project Details',
    shown: false
  };

  public static readonly REAL_PROPERTY_NEW_PROJECT: RouteInfo = {
    url: '/newProject',
    name: 'home.project.projectManagement.newProject',
    breadcrumb: 'New Project',
    parent: RouteConstants.REAL_PROPERTY_PROJECT_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_PROJECT_CREATE,
    selectionText: 'New Project',
    shown: false
  };

  public static readonly REAL_PROPERTY_PROJECT_JOURNAL_ACTION_INFO: RouteInfo = {
    url: '/projectJournalActionInfo',
    name: 'home.project.projectJournalActionInfo',
    breadcrumb: 'Project Journal Action Info',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
  };

  public static readonly REAL_PROPERTY_PROJECT_MILESTONE_DUE_INFO: RouteInfo = {
    url: '/projectMilestoneDueInfo',
    name: 'home.project.projectMilestoneDueInfo',
    breadcrumb: 'Project Milestone Due Info',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
  };

  public static readonly REAL_PROPERTY_PROJECT_GRAPHICAL_SEARCH: RouteInfo = {
    url: '/graphicalSearch',
    name: 'home.project.projectManagement.graphicalSearch',
    breadcrumb: 'Projects Graphical Search',
    parent: RouteConstants.REAL_PROPERTY_PROJECT_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_PROJECT_GRAPHICAL_SEARCH,
    selectionText: 'Projects Graphical Search',
    shown: false
  };

  public static readonly REAL_PROPERTY_REFERENCE_DATA: RouteInfo = {
    url: '/referenceData',
    name: 'home.referenceData',
    breadcrumb: 'Real Property Reference Data',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA,
    selectionText: 'Real Property Reference Data',
    shown: false
  };


  public static readonly REAL_PROPERTY_DRAWING_MANAGEMENT_LOOKUP_FLOOR_PLAN_LAYER: RouteInfo = {
    url: '/layerCategory',
    name: 'home.referenceData.floorPlanLayer',
    breadcrumb: 'Layer Element',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_DRAWING_MANAGEMENT_VIEW,
    selectionText: 'Layer Element Lookup',
    shown: false
  };

  public static readonly REAL_PROPERTY_FACILITY_MANAGEMENT_LOOKUP_DMIS_ID: RouteInfo = {
    url: '/dmisId',
    name: 'home.referenceData.dmisId',
    breadcrumb: 'DMIS ID',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_FACILITY_MANAGEMENT_VIEW,
    selectionText: 'DMIS ID Lookup',
    shown: false
  };

  public static readonly REAL_PROPERTY_FACILITY_MANAGEMENT_LOOKUP_FACILITY_ATTRIBUTE: RouteInfo = {
    url: '/facilityAttribute',
    name: 'home.referenceData.facilityAttribute',
    breadcrumb: 'Facility Attribute',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_FACILITY_MANAGEMENT_VIEW,
    selectionText: 'Facility Attribute Lookup',
    shown: false
  };
  public static readonly REAL_PROPERTY_PLAN_MANAGEMENT_LOOKUP_CAPITAL_IMPROVEMENT: RouteInfo = {
    url: '/capitalImprovement',
    name: 'home.referenceData.capitalImprovement',
    breadcrumb: 'Capital Improvement',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_PLAN_MANAGEMENT_VIEW,
    selectionText: 'Capital Improvement Lookup',
    shown: false
  };

  public static readonly REAL_PROPERTY_PLAN_MANAGEMENT_LOOKUP_PROJECT_MILESTONE: RouteInfo = {
    url: '/projectMilestone',
    name: 'home.referenceData.projectMilestone',
    breadcrumb: 'Project Milestone',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_PLAN_MANAGEMENT_VIEW,
    selectionText: 'Project Milestone',
    shown: false
  };

  public static readonly REAL_PROPERTY_PLAN_MANAGEMENT_LOOKUP_PROJECT_CODE: RouteInfo = {
    url: '/projectCode',
    name: 'home.referenceData.projectCode',
    breadcrumb: 'Project Code',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_PLAN_MANAGEMENT_VIEW,
    selectionText: 'Project Code',
    shown: false
  };

  public static readonly REAL_PROPERTY_PLAN_MANAGEMENT_LOOKUP_PROJECT_TYPE: RouteInfo = {
    url: '/projectType',
    name: 'home.referenceData.projectType',
    breadcrumb: 'Project Type',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_PLAN_MANAGEMENT_VIEW,
    selectionText: 'Project Type',
    shown: false
  };

  public static readonly REAL_PROPERTY_PLAN_MANAGEMENT_LOOKUP_RPIR_PROJECT_TYPE: RouteInfo = {
    url: '/rpirProjectType',
    name: 'home.referenceData.rpirProjectType',
    breadcrumb: 'Government Agency Project Type',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_PLAN_MANAGEMENT_VIEW,
    selectionText: 'Government Agency Project Type',
    shown: false
  };

  public static readonly REAL_PROPERTY_SECTIONS_LOOKUP_PAINT_TYPE: RouteInfo = {
    url: '/paintType',
    name: 'home.referenceData.paintType',
    breadcrumb: 'Paint Type',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_SECTIONS_VIEW,
    selectionText: 'Paint Type',
    shown: false
  };

  public static readonly REAL_PROPERTY_SECTIONS_LOOKUP_COMPONENT_SUBTYPE: RouteInfo = {
    url: '/componentSubtype',
    name: 'home.referenceData.componentSubtype',
    breadcrumb: 'Component Subtype',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_SECTIONS_VIEW,
    selectionText: 'Component Subtype',
    shown: false
  };

  public static readonly REAL_PROPERTY_SECTIONS_LOOKUP_COMPONENT_SUBTYPE_UNIT: RouteInfo = {
    url: '/componentSubtypeUnit',
    name: 'home.referenceData.componentSubtypeUnit',
    breadcrumb: 'Component Subtype Unit',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_SECTIONS_VIEW,
    selectionText: 'Component Subtype Unit',
    shown: false
  };

  public static readonly REAL_PROPERTY_SECTIONS_LOOKUP_COMPONENT_SUBTYPE_HIERARCHY: RouteInfo = {
    url: '/componentSubtypeHierarchy',
    name: 'home.referenceData.componentSubtypeHierarchy',
    breadcrumb: 'Component Subtype Hierarchy',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_SECTIONS_VIEW,
    selectionText: 'Component Subtype Hierarchy',
    shown: false
  };

  public static readonly REAL_PROPERTY_SPACE_MANAGEMENT_LOOKUP_CLEANING_REQUIREMENTS: RouteInfo = {
    url: '/cleaningRequirements',
    name: 'home.referenceData.cleaningRequirements',
    breadcrumb: 'Cleaning Requirements',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_SPACE_MANAGEMENT_VIEW,
    selectionText: 'Space Management Lookup',
    shown: false
  };

  public static readonly REAL_PROPERTY_SPACE_MANAGEMENT_LOOKUP_SPACE_HAZARD_TYPES: RouteInfo = {
    url: '/spaceHazardType',
    name: 'home.referenceData.spaceHazardTypes',
    breadcrumb: 'Space Hazard Types',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_SPACE_MANAGEMENT_VIEW,
    shown: false
  };

  public static readonly REAL_PROPERTY_SPACE_MANAGEMENT_LOOKUP_ZONE_TYPES: RouteInfo = {
    url: '/zoneTypes',
    name: 'home.referenceData.zoneTypes',
    breadcrumb: 'Zone Types',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_SPACE_MANAGEMENT_VIEW,
    shown: false
  };

  public static readonly REAL_PROPERTY_SPACE_MANAGEMENT_LOOKUP_SPACE_TYPES: RouteInfo = {
    url: '/roomTypes',
    name: 'home.referenceData.roomTypes',
    breadcrumb: 'Space Types',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_SPACE_MANAGEMENT_VIEW,
    shown: false
  };

  public static readonly REAL_PROPERTY_SPACE_MANAGEMENT_LOOKUP_ATTRIBUTE_TYPES: RouteInfo = {
    url: '/attributeTypes',
    name: 'home.referenceData.attributeTypes',
    breadcrumb: 'Attribute Types',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_SPACE_MANAGEMENT_VIEW,
    shown: false
  };

  public static readonly REAL_PROPERTY_REQUIREMENTS_LOOKUP_REQUIREMENT_CATEGORY: RouteInfo = {
    url: '/requirementCategory',
    name: 'home.referenceData.requirementCategory',
    breadcrumb: 'Requirement Category',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_REQUIREMENTS_VIEW,
    selectionText: 'Requirement Category',
    shown: false
  };

  public static readonly REAL_PROPERTY_REQUIREMENTS_LOOKUP_REQUIREMENT_CODE: RouteInfo = {
    url: '/requirementCode',
    name: 'home.referenceData.requirementCode',
    breadcrumb: 'Requirement Code',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_REQUIREMENTS_VIEW,
    selectionText: 'Requirement Code',
    shown: false
  };

  public static readonly REAL_PROPERTY_REQUIREMENTS_LOOKUP_REQUIREMENT_EXECUTION_METHOD: RouteInfo = {
    url: '/requirementExecutionMethod',
    name: 'home.referenceData.requirementExecutionMethod',
    breadcrumb: 'Requirement Execution Method',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_REQUIREMENTS_VIEW,
    selectionText: 'Requirement Execution Method',
    shown: false
  };

  public static readonly REAL_PROPERTY_REQUIREMENTS_LOOKUP_REQUIREMENT_TYPE: RouteInfo = {
    url: '/requirementType',
    name: 'home.referenceData.requirementType',
    breadcrumb: 'Requirement Type',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_REQUIREMENTS_VIEW,
    selectionText: 'Requirement Type',
    shown: false
  };

  public static readonly REAL_PROPERTY_REQUIREMENTS_LOOKUP_REQUIREMENT_WORK_METHOD: RouteInfo = {
    url: '/requirementWorkMethod',
    name: 'home.referenceData.requirementWorkMethod',
    breadcrumb: 'Requirement Work Method',
    parent: RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_REFERENCE_DATA_REQUIREMENTS_VIEW,
    selectionText: 'Requirement Work Method',
    shown: false
  };

  public static readonly SECTION_ROOT: RouteInfo = {
    url: '/section',
    name: 'home.section',
    breadcrumb: 'Sections',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID
  };

  public static readonly REAL_PROPERTY_SECTION_MANAGEMENT: RouteInfo = {
    url: '/sectionManagement',
    name: 'home.section.sectionManagement',
    breadcrumb: 'Sections',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SECTION_MANAGEMENT,
    selectionText: 'Sections',
    shown: false
  };

  public static readonly REAL_PROPERTY_SECTION_REPORTS: RouteInfo = {
    url: '/sectionReports',
    name: 'home.section.sectionReports',
    breadcrumb: 'Sections Reports',
    parent: RouteConstants.MY_DASHBOARD,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SECTION_VIEW,
    selectionText: 'Sections Reports',
    shown: false
  };

  public static readonly REAL_PROPERTY_SECTION_VIEW: RouteInfo = {
    url: '/sectionDetails?id',
    name: 'home.section.sectionManagement.sectionDetails',
    breadcrumb: 'Section Details',
    parent: RouteConstants.REAL_PROPERTY_SECTION_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SECTION_VIEW
  };
  public static readonly REAL_PROPERTY_SECTION_BULK_UPDATE_CONFIRM: RouteInfo = {
    url: '/sectionBulkUpdateConfirm',
    name: 'home.section.sectionManagement.sectionBulkUpdateConfirm',
    breadcrumb: 'Sections Bulk Update - Confirm',
    parent: RouteConstants.REAL_PROPERTY_SECTION_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SECTION_BULK_UPDATE_CONFIRM,
    selectionText: 'Sections Bulk Update - Confirm',
    shown: false
  };
  public static readonly REAL_PROPERTY_SECTION_BULK_UPDATE_RESULTS: RouteInfo = {
    url: '/sectionBulkUpdateResults',
    name: 'home.section.sectionManagement.sectionBulkUpdateResults',
    breadcrumb: 'Sections Bulk Update - Results',
    parent: RouteConstants.REAL_PROPERTY_SECTION_BULK_UPDATE_CONFIRM,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SECTION_BULK_UPDATE_RESULTS,
    selectionText: 'Sections Bulk Update - Results',
    shown: false
  };

  public static readonly COBIE_ROOT: RouteInfo = {
    url: '/cobie',
    name: 'home.cobie',
    breadcrumb: 'COBie',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID
  };

  public static readonly REAL_PROPERTY_COBIE_ADMINISTRATION: RouteInfo = {
    url: '/administration',
    name: 'home.cobie.administration',
    breadcrumb: 'COBie Administration',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_COBIE_ADMINISTRATION,
    selectionText: 'COBie Administration',
    shown: false
  };
  public static readonly REAL_PROPERTY_COBIE_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.cobie.administration.details',
    breadcrumb: 'COBie Details',
    parent: RouteConstants.REAL_PROPERTY_COBIE_ADMINISTRATION,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_COBIE_DETAILS,
    selectionText: 'COBie Details',
    shown: false
  };

  public static readonly REAL_PROPERTY_NEW_SECTION: RouteInfo = {
    url: '/newSection',
    name: 'home.section.sectionManagement.newSection',
    breadcrumb: 'New Section',
    parent: RouteConstants.REAL_PROPERTY_SECTION_MANAGEMENT,
    navigationId: NavigationConstants.REAL_PROPERTY_NAV_ID,
    perm: ElementConstants.REAL_PROPERTY_SECTION_CREATE,
    selectionText: 'New Section',
    shown: false
  };

  public static readonly SLEP_ROOT: RouteInfo = {
    url: '/slep',
    name: 'home.slep',
    breadcrumb: 'SLEP',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.SLEP_NAV_ID
  };
  public static readonly SLEP_ACCESS_CONTROL: RouteInfo = {
    url: '/accessControl',
    name: 'home.slep.accessControl',
    breadcrumb: 'SLEP Access Control',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    shown: false,
    selectionText: 'SLEP Access Control',
    perm: ElementConstants.SLEP_USER_MANAGER_VIEW
  };
  public static readonly SLEP_INVENTORY_MANAGEMENT: RouteInfo = {
    url: '/inventoryManagement',
    name: 'home.slep.inventoryManagement',
    breadcrumb: 'SLEP Inventory Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    shown: true,
    selectionText: 'SLEP Inventory',
    perm: ElementConstants.SLEP_INVENTORY_VIEW
  };
  public static readonly SLEP_EDIT_INVENTORY: RouteInfo = {
    url: '/editInventory',
    name: 'home.slep.inventoryManagement.editInventory',
    breadcrumb: 'SLEP Edit Inventory',
    parent: RouteConstants.SLEP_INVENTORY_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_EDIT_INVENTORY_VIEW
  };
  public static readonly SLEP_INVENTORY_ADD_LOTS: RouteInfo = {
    url: '/addLotsToInventory',
    name: 'home.slep.inventoryManagement.editInventory.addLotsToInventory',
    breadcrumb: 'SLEP Add Lots to Inventory',
    parent: RouteConstants.SLEP_EDIT_INVENTORY,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_ADD_LOTS_TO_INVENTORY_VIEW
  };

  public static readonly SLEP_LOT_MANAGEMENT: RouteInfo = {
    url: '/lotManagement',
    name: 'home.slep.lotManagement',
    breadcrumb: 'SLEP Lot Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    shown: true,
    selectionText: 'Lot Management',
    perm: ElementConstants.SLEP_LOT_NUMBER_VIEW
  };
  public static readonly SLEP_ADD_LOT: RouteInfo = {
    url: '/addLot',
    name: 'home.slep.lotManagement.addLot',
    breadcrumb: 'SLEP Add Lot',
    parent: RouteConstants.SLEP_LOT_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_ADD_LOT_VIEW
  };
  public static readonly SLEP_EDIT_LOT: RouteInfo = {
    url: '/editLot',
    name: 'home.slep.lotManagement.editLot',
    breadcrumb: 'SLEP Edit Lot',
    parent: RouteConstants.SLEP_LOT_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_EDIT_LOT_VIEW
  };
  public static readonly SLEP_VIEW_LOT: RouteInfo = {
    url: '/viewLot',
    name: 'home.slep.lotManagement.viewLot',
    breadcrumb: 'SLEP View Lot',
    parent: RouteConstants.SLEP_LOT_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_VIEW_LOT_VIEW
  };
  public static readonly SLEP_APPROVE_DISAPPROVE_LOT: RouteInfo = {
    url: '/approveDisapproveLot',
    name: 'home.slep.lotManagement.approveDisapproveLot',
    breadcrumb: 'SLEP Approve / Disapprove Lot',
    parent: RouteConstants.SLEP_LOT_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_APPROVE_LOT_VIEW
  };
  public static readonly SLEP_BULK_UPDATE_LOT: RouteInfo = {
    url: 'bulkUpdateLot',
    name: 'home.slep.lotManagement.bulkUpdateLot',
    breadcrumb: 'SLEP Bulk Update - Lot',
    parent: RouteConstants.SLEP_LOT_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_MASS_UPDATE_LOTS
  };

  public static readonly SLEP_PROJECT_MANAGEMENT: RouteInfo = {
    url: '/projectManagement',
    name: 'home.slep.projectManagement',
    breadcrumb: 'SLEP Project Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    shown: true,
    selectionText: 'FDA Project Management',
    perm: ElementConstants.SLEP_PROJECT_VIEW
  };
  public static readonly SLEP_ADD_PROJECT: RouteInfo = {
    url: '/addProject',
    name: 'home.slep.projectManagement.addProject',
    breadcrumb: 'SLEP Add Project',
    parent: RouteConstants.SLEP_PROJECT_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_ADD_PROJECT_VIEW
  };
  public static readonly SLEP_ADD_LOTS_TO_NEW_PROJECT: RouteInfo = {
    url: '/addLotsToNewProject',
    name: 'home.slep.projectManagement.addProject.addLotsToNewProject',
    breadcrumb: 'SLEP Add Lots to New Project',
    parent: RouteConstants.SLEP_ADD_PROJECT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_ADD_LOTS_NEW_PROJECT_VIEW
  };
  public static readonly SLEP_EDIT_PROJECT: RouteInfo = {
    url: '/editProject',
    name: 'home.slep.projectManagement.editProject',
    breadcrumb: 'SLEP Edit Project',
    parent: RouteConstants.SLEP_PROJECT_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_EDIT_PROJECT_VIEW
  };
  public static readonly SLEP_ADD_LOTS_TO_EXISTING_PROJECT: RouteInfo = {
    url: '/addLotsToExistingProject',
    name: 'home.slep.projectManagement.editProject.addLotsToExistingProject',
    breadcrumb: 'SLEP Add Lots to Existing Project',
    parent: RouteConstants.SLEP_EDIT_PROJECT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_ADD_LOTS_EXISTING_PROJECT_VIEW
  };
  public static readonly SLEP_VERIFY_PROJECT: RouteInfo = {
    url: '/verifyProject',
    name: 'home.slep.projectManagement.verifyProject',
    breadcrumb: 'SLEP Verify Project',
    parent: RouteConstants.SLEP_PROJECT_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_VERIFY_PROJECT_VIEW
  };
  public static readonly SLEP_VIEW_PROJECT: RouteInfo = {
    url: '/viewProject',
    name: 'home.slep.projectManagement.viewProject',
    breadcrumb: 'SLEP View Project',
    parent: RouteConstants.SLEP_PROJECT_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_VIEW_PROJECT_VIEW
  };
  public static readonly SLEP_BULK_UPDATE_PROJECT_LOTS: RouteInfo = {
    url: '/bulkUpdateProjectLots',
    name: 'home.slep.projectManagement.bulkUpdateProjectLots',
    breadcrumb: 'SLEP Bulk Update Lots for Project',
    parent: RouteConstants.SLEP_PROJECT_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_EDIT_PROJECT_VIEW
  };
  public static readonly SLEP_NSN_MANAGEMENT: RouteInfo = {
    url: '/nsnManagement',
    name: 'home.slep.nsnManagement',
    breadcrumb: 'SLEP NSN Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    shown: true,
    selectionText: 'NSN Management',
    perm: ElementConstants.SLEP_NSN_VIEW
  };
  public static readonly SLEP_ADD_NSN: RouteInfo = {
    url: '/addNsn',
    name: 'home.slep.nsnManagement.addNsn',
    breadcrumb: 'SLEP Add NSN',
    parent: RouteConstants.SLEP_NSN_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_ADD_NSN_VIEW
  };
  public static readonly SLEP_EDIT_NSN: RouteInfo = {
    url: '/editNsn',
    name: 'home.slep.nsnManagement.editNsn',
    breadcrumb: 'SLEP Edit NSN',
    parent: RouteConstants.SLEP_NSN_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_EDIT_NSN_VIEW
  };
  public static readonly SLEP_SITE_MANAGEMENT: RouteInfo = {
    url: '/siteManagement',
    name: 'home.slep.siteManagement',
    breadcrumb: 'SLEP Site Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    shown: true,
    selectionText: 'Site Management',
    perm: ElementConstants.SLEP_SITE_VIEW
  };
  public static readonly SLEP_ADD_SITE: RouteInfo = {
    url: '/addSite',
    name: 'home.slep.siteManagement.addSite',
    breadcrumb: 'SLEP Add Site',
    parent: RouteConstants.SLEP_SITE_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_ADD_SITE_VIEW
  };
  public static readonly SLEP_EDIT_SITE: RouteInfo = {
    url: '/editSite',
    name: 'home.slep.siteManagement.editSite',
    breadcrumb: 'SLEP Edit Site',
    parent: RouteConstants.SLEP_SITE_MANAGEMENT,
    navigationId: NavigationConstants.SLEP_NAV_ID,
    perm: ElementConstants.SLEP_EDIT_SITE_VIEW
  };

  public static readonly BUSINESS_INTELLIGENCE_ROOT: RouteInfo = {
    url: '/businessIntelligence',
    name: 'home.businessIntelligence',
    breadcrumb: 'Reporting & Analytics',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.BUSINESS_INTELLIGENCE_NAV_ID
  };

  public static readonly BUSINESS_INTELLIGENCE: RouteInfo = {
    url: '/businessIntelligence',
    name: 'home.businessIntelligence.businessIntelligence',
    breadcrumb: 'Reporting & Analytics Workspace',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.BUSINESS_INTELLIGENCE_NAV_ID,
    shown: false,
    selectionText: 'Reporting & Analytics Workspace',
    perm: ElementConstants.BUSINESS_INTELLIGENCE
  };

  public static readonly MAINTENANCE: RouteInfo = {
    url: '/asset',
    name: 'home.asset',
    breadcrumb: 'Maintenance',
    parent: RouteConstants.HOME_ROOT,
    perm: ElementConstants.ASSET,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID
  };

  public static readonly ASSET_WARRANTY_INFO: RouteInfo = {
    url: '/assetWarrantyInfo',
    name: 'home.asset.warrantyInfo',
    breadcrumb: 'Equipment Warranty Info',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
  };
  public static readonly ASSET_WARRANTY_INFO_DETAILS: RouteInfo = {
    url: '/assetWarrantyDetails',
    name: 'home.asset.warrantyInfo.details',
    breadcrumb: 'Equipment Details',
    parent: RouteConstants.ASSET_WARRANTY_INFO,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
  };
  public static readonly ASSET_CLASSIFICATION: RouteInfo = {
    url: '/classification',
    name: 'home.asset.classification',
    breadcrumb: 'Classification',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_CLASSIFICATION,
    selectionText: 'Classification'
  };
  public static readonly MAINTENANCE_PROCEDURES: RouteInfo = {
    url: '/maintenanceProcedures',
    name: 'home.maintenance.maintenanceProcedures',
    breadcrumb: 'Maintenance Procedures',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.MAINTENANCE_PROCEDURES,
    selectionText: 'Maintenance Procedures'
  };
  public static readonly ASSET_MAINTENANCE_PROCEDURES: RouteInfo = {
    url: '/maintenanceProcedures/realProperty',
    name: 'home.asset.maintenanceProcedures',
    breadcrumb: 'Maintenance Procedures',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_PROCEDURES
  };
  public static readonly MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURES: RouteInfo = {
    url: '/maintenanceProcedures/medicalEquipment',
    name: 'home.maintenance.medicalEquipmentMaintenanceProcedures',
    breadcrumb: 'Maintenance Procedures',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURES
  };
  public static readonly MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_NEW: RouteInfo = {
    url: '/new',
    name: 'home.maintenance.medicalEquipmentMaintenanceProcedures.new',
    breadcrumb: 'New Maintenance Procedure',
    parent: RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURES,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID
  };
  public static readonly MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_DETAILS: RouteInfo = {
    url: '/details?id',
    name: 'home.maintenance.medicalEquipmentMaintenanceProcedures.details',
    breadcrumb: 'Maintenance Procedure Details',
    parent: RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURES,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID
  };
  public static readonly MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_CHECKLIST: RouteInfo = {
    url: '/checklist?id',
    name: 'home.maintenance.medicalEquipmentMaintenanceProcedures.checklist',
    breadcrumb: 'Maintenance Procedure Checklist',
    parent: RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURES,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID
  };
  public static readonly ASSET_MAINTENANCE_PROCEDURES_BULK_UPDATE_CONFIRM: RouteInfo = {
    url: '/confirm',
    name: 'home.asset.maintenanceProcedures.bulkUpdateConfirm',
    breadcrumb: 'Bulk Update Confirmation',
    parent: RouteConstants.ASSET_MAINTENANCE_PROCEDURES,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_PROCEDURES_BULK_UPDATE,
    selectionText: 'Bulk Update Confirmation'
  };
  public static readonly ASSET_MAINTENANCE_PROCEDURES_BULK_UPDATE_RESULTS: RouteInfo = {
    url: '/results',
    name: 'home.asset.maintenanceProcedures.bulkUpdateResults',
    breadcrumb: 'Bulk Update Results',
    parent: RouteConstants.ASSET_MAINTENANCE_PROCEDURES,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_PROCEDURES_BULK_UPDATE,
    selectionText: 'Bulk Update Results'
  };
  public static readonly ASSET_MAINTENANCE_PROCEDURE_DETAIL: RouteInfo = {
    url: '/maintenanceProcedureDetail',
    name: 'home.asset.maintenanceProcedures.detail',
    breadcrumb: 'Maintenance Procedure Details',
    parent: RouteConstants.ASSET_MAINTENANCE_PROCEDURES,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_PROCEDURES_DETAIL,
    selectionText: 'Maintenance Procedure Detail'
  };
  public static readonly MAINTENANCE_PLANS_AND_SCHEDULES: RouteInfo = {
    url: '/maintenancePlansAndSchedules',
    name: 'home.asset.maintenancePlansAndSchedules',
    breadcrumb: 'Maintenance Plans and Schedules',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_PLANS_AND_SCHEDULES,
    selectionText: 'Maintenance Plans and Schedules',
    dividerFollows: true
  };
  public static readonly ASSET_MAINTENANCE_SCHEDULES: RouteInfo = {
    url: '/maintenanceSchedules',
    name: 'home.asset.maintenanceSchedules',
    breadcrumb: 'Maintenance Schedules',
    parent: RouteConstants.MAINTENANCE_PLANS_AND_SCHEDULES,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_SCHEDULES,
    selectionText: 'Maintenance Schedules'
  };
  public static readonly ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE: RouteInfo = {
    url: '/bulkUpdate',
    name: 'home.asset.maintenanceSchedules.bulkupdate',
    breadcrumb: 'Bulk Update',
    parent: RouteConstants.ASSET_MAINTENANCE_SCHEDULES,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_SCHEDULES
  };
  public static readonly ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_CONFIRMATION: RouteInfo = {
    url: '/confirmation',
    name: 'home.asset.maintenanceSchedules.bulkupdate.confirmation',
    breadcrumb: 'Confirmation',
    parent: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_SCHEDULES
  };
  public static readonly ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_RESULTS: RouteInfo = {
    url: '/results',
    name: 'home.asset.maintenanceSchedules.bulkupdate.results',
    breadcrumb: 'Results',
    parent: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_SCHEDULES
  };
  public static readonly ASSET_MAINTENANCE_SCHEDULES_DETAIL: RouteInfo = {
    url: '/maintenanceScheduleDetails',
    name: 'home.asset.maintenanceSchedules.detail',
    breadcrumb: 'Maintenance Schedule Detail',
    parent: RouteConstants.ASSET_MAINTENANCE_SCHEDULES,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_SCHEDULE,
    selectionText: 'Maintenance Schedule Detail'
  };
  public static readonly ASSET_MAINTENANCE_SCHEDULES_NEW_NON_ASSET_SCHEDULE: RouteInfo = {
    url: '/newMaintenanceSchedule',
    name: 'home.asset.maintenanceSchedules.newMaintenanceSchedule',
    breadcrumb: 'New Maintenance Schedule',
    parent: RouteConstants.ASSET_MAINTENANCE_SCHEDULES,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_NON_ASSET_SCHEDULE_CREATE,
    selectionText: 'New Maintenance Schedule'
  };
  public static readonly MAINTENANCE_PLANS: RouteInfo = {
    url: '/maintenancePlans',
    name: 'home.asset.maintenancePlans',
    breadcrumb: 'Maintenance Plans',
    parent: RouteConstants.MAINTENANCE_PLANS_AND_SCHEDULES,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_PLANS,
    selectionText: 'Maintenance Plans'
  };
  public static readonly MAINTENANCE_PLAN_DETAILS: RouteInfo = {
    url: '/details?id',
    name: 'home.asset.maintenancePlans.details',
    breadcrumb: 'Maintenance Plan Details',
    parent: RouteConstants.MAINTENANCE_PLANS
  };
  public static readonly NEW_MAINTENANCE_PLAN: RouteInfo = {
    url: '/new',
    name: 'home.asset.maintenancePlans.new',
    breadcrumb: 'New Maintenance Plan',
    parent: RouteConstants.MAINTENANCE_PLANS
  };
  public static readonly ASSET_DATA_MANAGEMENT: RouteInfo = {
    url: '/dataManagement',
    name: 'home.asset.dataManagement',
    breadcrumb: 'Data Management',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.ASSET_DATA_MANAGEMENT,
    selectionText: 'Data Management'
  };

  public static readonly MAINTENANCE_ROOT: RouteInfo = {
    url: '/maintenance',
    name: 'home.maintenance',
    parent: RouteConstants.HOME_ROOT,
    breadcrumb: 'Maintenance',
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    shown: false
  };
  public static readonly MAINTENANCE_TECHNICIANS: RouteInfo = {
    url: '/technicians',
    name: 'home.maintenance.technicians',
    breadcrumb: 'Technicians',
    parent: RouteConstants.MAINTENANCE_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.MAINTENANCE_TECHNICIANS,
    selectionText: 'Technicians'
  };
  public static readonly MAINTENANCE_TECHNICIAN_DETAILS: RouteInfo = {
    url: '/details?id',
    name: 'home.maintenance.technicians.details',
    breadcrumb: 'Technician Details',
    parent: RouteConstants.MAINTENANCE_TECHNICIANS
  };
  public static readonly MAINTENANCE_TECHNICIAN_NEW: RouteInfo = {
    url: '/new',
    name: 'home.maintenance.technicians.new',
    breadcrumb: 'New Technician',
    parent: RouteConstants.MAINTENANCE_TECHNICIANS
  };
  public static readonly MAINTENANCE_REFERENCE_DATA: RouteInfo = {
    url: '/referenceData',
    name: 'home.maintenance.referenceData',
    breadcrumb: 'Reference Data',
    parent: RouteConstants.MAINTENANCE_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.MAINTENANCE_REFERENCE_DATA,
    selectionText: 'Reference Data'
  };
  public static readonly MAINTENANCE_TEAMS: RouteInfo = {
    url: '/teams',
    name: 'home.maintenance.teams',
    breadcrumb: 'Teams',
    parent: RouteConstants.MAINTENANCE_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.MAINTENANCE_TEAMS,
    selectionText: 'Teams',
    dividerFollows: true
  };
  public static readonly MAINTENANCE_TEAM_NEW: RouteInfo = {
    url: '/new',
    name: 'home.maintenance.teams.new',
    breadcrumb: 'New Team',
    parent: RouteConstants.MAINTENANCE_TEAMS,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID
  };
  public static readonly MAINTENANCE_TEAM_DETAILS: RouteInfo = {
    url: '/details?id',
    name: 'home.maintenance.teams.details',
    breadcrumb: 'Team Details',
    parent: RouteConstants.MAINTENANCE_TEAMS,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID
  };
  public static readonly MAINTENANCE_ACTIVITY: RouteInfo = {
    url: '/activity',
    name: 'home.maintenance.activity',
    breadcrumb: 'Maintenance Activity',
    parent: RouteConstants.MAINTENANCE_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.MAINTENANCE_ACTIVITY,
    selectionText: 'Maintenance Activity'
  };
  public static readonly MAINTENANCE_ACTIVITY_NEW: RouteInfo = {
    url: '/new',
    name: 'home.maintenance.activity.new',
    breadcrumb: 'New Maintenance Activity',
    parent: RouteConstants.MAINTENANCE_ACTIVITY,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID
  };
  public static readonly MAINTENANCE_ACTIVITY_DETAILS: RouteInfo = {
    url: '/details?id',
    name: 'home.maintenance.activity.details',
    breadcrumb: 'Maintenance Activity Details',
    parent: RouteConstants.MAINTENANCE_ACTIVITY,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID
  };

  public static readonly EQUIPMENT_RECORDS: RouteInfo = {
    url: '/equipmentRecords',
    name: 'home.asset.assetManagement',
    breadcrumb: 'Equipment Records',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_MANAGEMENT_SEARCH,
    selectionText: 'Equipment Records'
  };
  public static readonly ASSET_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.asset.assetManagement.details',
    breadcrumb: 'Equipment Details',
    parent: RouteConstants.EQUIPMENT_RECORDS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Equipment Details'
  };
  public static readonly ASSET_MANAGEMENT_MAINTENANCE_SCHEDULE_DETAIL: RouteInfo = {
    url: '/maintenanceScheduleDetails',
    name: 'home.asset.assetManagement.details.scheduleDetails',
    breadcrumb: 'Maintenance Schedule Details',
    parent: RouteConstants.ASSET_DETAILS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_MAINTENANCE_SCHEDULE
  };
  public static readonly EQUIPMENT_RECORD_NEW: RouteInfo = {
    url: '/new',
    name: 'home.asset.assetManagement.newAsset',
    breadcrumb: 'New Equipment Record',
    parent: RouteConstants.EQUIPMENT_RECORDS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_MANAGEMENT_CREATE,
    selectionText: 'New Equipment Record',
    shown: false
  };
  public static readonly EQUIPMENT_RECORDS_BULK_UPDATE_SELECT_FIELDS: RouteInfo = {
    url: '/equipmentRecordsBulkUpdateSelectFields',
    name: 'home.asset.assetManagement.assetManagementBulkUpdateSelectFields',
    breadcrumb: 'Bulk Update - Select Field',
    parent: RouteConstants.EQUIPMENT_RECORDS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_MANAGEMENT_BULK_UPDATE,
    selectionText: 'Bulk Update - Select Field',
    shown: false
  };
  public static readonly EQUIPMENT_RECORDS_BULK_UPDATE_CONFIRM: RouteInfo = {
    url: '/equipmentRecordsBulkUpdateConfirm',
    name: 'home.asset.assetManagement.assetManagementBulkUpdateConfirm',
    breadcrumb: 'Bulk Update - Confirm',
    parent: RouteConstants.EQUIPMENT_RECORDS_BULK_UPDATE_SELECT_FIELDS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_MANAGEMENT_BULK_UPDATE,
    selectionText: 'Bulk Update - Confirm',
    shown: false
  };
  public static readonly EQUIPMENT_RECORDS_BULK_UPDATE_RESULTS: RouteInfo = {
    url: '/equipmentRecordsBulkUpdateResults',
    name: 'home.asset.assetManagement.assetManagementBulkUpdateResults',
    breadcrumb: 'Bulk Update - Results',
    parent: RouteConstants.EQUIPMENT_RECORDS_BULK_UPDATE_CONFIRM,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_MANAGEMENT_BULK_UPDATE,
    selectionText: 'Bulk Update - Results',
    shown: false
  };
  public static readonly EQUIPMENT_GROUPS: RouteInfo = {
    url: '/equipmentGroups',
    name: 'home.asset.assetGroups',
    breadcrumb: 'Equipment Groups',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_GROUPS,
    selectionText: 'Equipment Groups',
    dividerFollows: true
  };
  public static readonly EQUIPMENT_GROUPS_DETAIL: RouteInfo = {
    url: '/equipmentGroupsDetails',
    name: 'home.asset.assetGroups.details',
    breadcrumb: 'Equipment Groups Detail',
    parent: RouteConstants.EQUIPMENT_GROUPS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_GROUPS,
    selectionText: 'Equipment Groups Detail'
  };
  public static readonly ASSET_GROUPS_NEW: RouteInfo = {
    url: '/newAssetGroup',
    name: 'home.asset.assetGroups.newAssetGroup',
    breadcrumb: 'New Asset Group',
    parent: RouteConstants.EQUIPMENT_GROUPS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_GROUPS_CREATE,
    selectionText: 'New Asset Group',
    shown: false
  };

  public static readonly EQUIPMENT_LOOKUP: RouteInfo = {
    url: '/assetLookup',
    name: 'home.asset.assetLookup',
    breadcrumb: 'Reference Data',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_REFERENCE_DATA_VIEW,
    selectionText: 'Reference Data',
    shown: false,
    dividerFollows: true
  };
  public static readonly ASSET_LOOKUP_ASSEMBLY_CATEGORY: RouteInfo = {
    url: '/assemblyCategory',
    name: 'home.asset.assetLookup.assemblyCategory',
    breadcrumb: 'Assembly Category',
    parent: RouteConstants.EQUIPMENT_LOOKUP,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Assembly Category',
    shown: false
  };
  public static readonly ASSET_LOOKUP_FACILITY_SUB_SYSTEM: RouteInfo = {
    url: '/facilitySubSystem',
    name: 'home.asset.assetLookup.facilitySubSystem',
    breadcrumb: 'Facility Subsystem',
    parent: RouteConstants.EQUIPMENT_LOOKUP,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Facility Subsystem',
    shown: false
  };
  public static readonly ASSET_LOOKUP_FACILITY_SYSTEM: RouteInfo = {
    url: '/facilitySystem',
    name: 'home.asset.assetLookup.facilitySystem',
    breadcrumb: 'Facility System',
    parent: RouteConstants.EQUIPMENT_LOOKUP,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Facility System',
    shown: false
  };
  public static readonly ASSET_LOOKUP_FREQUENCY: RouteInfo = {
    url: '/frequency',
    name: 'home.asset.assetLookup.frequency',
    breadcrumb: 'Frequency',
    parent: RouteConstants.EQUIPMENT_LOOKUP,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Frequency',
    shown: false
  };
  public static readonly ASSET_LOOKUP_REGULATORY_COMPLIANCE_ACTION: RouteInfo = {
    url: '/regulatoryComplianceAction',
    name: 'home.asset.assetLookup.regulatoryComplianceAction',
    breadcrumb: 'Regulatory Compliance Action',
    parent: RouteConstants.EQUIPMENT_LOOKUP,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Regulatory Compliance Action',
    shown: false
  };
  public static readonly ASSET_LOOKUP_REGULATORY_COMPLIANCE_CODE: RouteInfo = {
    url: '/regulatoryComplianceCode',
    name: 'home.asset.assetLookup.regulatoryComplianceCode',
    breadcrumb: 'Regulatory Compliance Code',
    parent: RouteConstants.EQUIPMENT_LOOKUP,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Regulatory Compliance Code',
    shown: false
  };
  public static readonly ASSET_LOOKUP_SKILL: RouteInfo = {
    url: '/shops',
    name: 'home.asset.assetLookup.skill',
    breadcrumb: 'Shops',
    parent: RouteConstants.EQUIPMENT_LOOKUP,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Shops',
    shown: false
  };

  public static readonly ASSET_LOOKUP_SPECIALTY: RouteInfo = {
    url: '/specialty',
    name: 'home.asset.assetLookup.specialty',
    breadcrumb: 'Specialty',
    parent: RouteConstants.EQUIPMENT_LOOKUP,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Specialty',
    shown: false
  };
  public static readonly ASSET_LOOKUP_AUTH_SEC: RouteInfo = {
    url: '/authSec',
    name: 'home.asset.assetLookup.authSec',
    breadcrumb: 'Authoritative Space Equipment Criteria',
    parent: RouteConstants.EQUIPMENT_LOOKUP,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Authoritative Space Equipment Criteria',
    shown: false
  };
  public static readonly ASSET_LOOKUP_SEC: RouteInfo = {
    url: '/sec',
    name: 'home.asset.assetLookup.sec',
    breadcrumb: 'Agency Space Equipment Criteria',
    parent: RouteConstants.EQUIPMENT_LOOKUP,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Agency Space Equipment Criteria',
    shown: false
  };
  public static readonly ASSET_LOOKUP_1691: RouteInfo = {
    url: '/milStd1691',
    name: 'home.asset.assetLookup.milStd',
    breadcrumb: 'Military Standard 1691',
    parent: RouteConstants.EQUIPMENT_LOOKUP,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    selectionText: 'Military Standard 1691',
    shown: false
  };
  public static readonly ASSET_LOOKUP_1691_DETAILS: RouteInfo = {
    url: '/details',
    name: 'home.asset.assetLookup.milStd.details',
    breadcrumb: 'Military Standard 1691 Details',
    parent: RouteConstants.ASSET_LOOKUP_1691,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_REFERENCE_DATA_VIEW,
    shown: false
  };
  public static readonly EQUIPMENT_REQUEST_1691_DETAILS: RouteInfo = {
    url: '/milStdDetails',
    name: 'home.equipment.requests.request.milStdDetails',
    breadcrumb: 'Military Standard 1691 Details',
    parent: RouteConstants.EQUIPMENT_REQUESTS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_REFERENCE_DATA_VIEW,
    shown: false
  };
  public static readonly ASSET_LOOKUP_MEC: RouteInfo = {
    url: '/mec',
    name: 'home.asset.assetLookup.mec',
    breadcrumb: 'Minimum Essential Characteristics (MEC)',
    parent: RouteConstants.ASSET_LOOKUP_1691,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_REFERENCE_DATA_VIEW,
    shown: false
  };
  public static readonly ASSET_GRAPHICAL_SEARCH: RouteInfo = {
    url: '/graphicalSearch',
    name: 'home.asset.assetManagement.graphicalSearch',
    breadcrumb: 'Assets Graphical Search',
    parent: RouteConstants.EQUIPMENT_RECORDS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_MANAGEMENT_GRAPHICAL_SEARCH,
    selectionText: 'Assets Graphical Search',
    shown: false
  };
  public static readonly ASSET_DETAILS_DRAWING: RouteInfo = {
    url: '/drawing',
    name: 'home.asset.assetManagement.drawing',
    breadcrumb: 'Drawing',
    parent: RouteConstants.EQUIPMENT_RECORDS,
    navigationId: NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
    perm: ElementConstants.ASSET_MANAGEMENT_DRAWING_VIEW
  };

  public static readonly WORK_ORDER_CORE_SEARCH: RouteInfo = {
    url: '/workOrders',
    name: 'home.workOrdersCore',
    breadcrumb: 'Work Orders',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS_CORE,
    selectionText: 'Work Orders',
    dividerFollows: false
  };
  public static readonly WORK_ORDER_CORE_DETAILS: RouteInfo = {
    url: '/details?id',
    name: 'home.workOrdersCore.details',
    breadcrumb: 'Work Order Details',
    parent: RouteConstants.WORK_ORDER_CORE_SEARCH,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
  };
  public static readonly WORK_ORDER_SEARCH: RouteInfo = {
    url: '/workOrders/realProperty',
    name: 'home.workOrders',
    breadcrumb: 'Work Orders',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS,
    selectionText: 'Work Orders',
    dividerFollows: false
  };
  public static readonly WORK_ORDER_DETAILS: RouteInfo = {
    url: '/details?id',
    name: 'home.workOrders.details',
    breadcrumb: 'Work Order Details',
    parent: RouteConstants.WORK_ORDER_SEARCH,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS
  };
  public static readonly WORK_ORDER_PRIORITIZATION: RouteInfo = {
    url: '/workOrderPrioritization',
    name: 'home.workOrders.workOrderPrioritization',
    breadcrumb: 'Work Order Prioritization',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS_PRIORITIZATION,
    selectionText: 'Work Order Prioritization'
  };
  public static readonly WORK_ORDER_BULK_UPDATE: RouteInfo = {
    url: '/bulkUpdate',
    name: 'home.workOrders.bulkupdate',
    breadcrumb: 'Bulk Update',
    parent: RouteConstants.WORK_ORDER_SEARCH,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS
  };
  public static readonly WORK_ORDER_FORM_GENERATION: RouteInfo = {
    url: '/formGeneration',
    name: 'home.workOrders.formGeneration',
    breadcrumb: 'Form Generation',
    parent: RouteConstants.WORK_ORDER_SEARCH,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS
  };
  public static readonly WORK_ORDER_DETAILS_FORM_GENERATION: RouteInfo = {
    url: '/formGeneration',
    name: 'home.workOrders.details.formGeneration',
    breadcrumb: 'Form Generation',
    parent: RouteConstants.WORK_ORDER_DETAILS,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS
  };
  public static readonly WORK_ORDER_BULK_UPDATE_CONFIRM: RouteInfo = {
    url: '/confirm',
    name: 'home.workOrders.bulkupdate.confirm',
    breadcrumb: 'Bulk Update Confirmation',
    parent: RouteConstants.WORK_ORDER_BULK_UPDATE,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS
  };
  public static readonly WORK_ORDER_BULK_UPDATE_RESULTS: RouteInfo = {
    url: '/results',
    name: 'home.workOrders.bulkupdate.results',
    breadcrumb: 'Bulk Update Results',
    parent: RouteConstants.WORK_ORDER_BULK_UPDATE,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS
  };
  public static readonly NEW_WORK_ORDER: RouteInfo = {
    url: '/new',
    name: 'home.workOrders.new',
    breadcrumb: 'New Work Order',
    parent: RouteConstants.WORK_ORDER_SEARCH,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS
  };
  public static readonly WORK_ORDER_FACILITY_DRAWINGS: RouteInfo = {
    url: '/facilityDrawings',
    name: 'home.workOrders.details.facilitydrawings',
    breadcrumb: 'Facility Drawings',
    parent: RouteConstants.WORK_ORDER_DETAILS,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS
  };
  public static readonly WORK_ORDER_LOOKUP_CLASSIFICATION_TYPE: RouteInfo = {
    url: '/classificationType',
    name: 'home.maintenance.referenceData.classificationType',
    breadcrumb: 'Classification Type',
    parent: RouteConstants.MAINTENANCE_REFERENCE_DATA,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    selectionText: 'Classification Type',
    shown: false
  };
  public static readonly WORK_ORDER_LOOKUP_PRIORITY_GROUP: RouteInfo = {
    url: '/priorityGroup',
    name: 'home.maintenance.referenceData.priorityGroup',
    breadcrumb: 'Priority Group',
    parent: RouteConstants.MAINTENANCE_REFERENCE_DATA,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    selectionText: 'Priority Group',
    shown: false
  };
  public static readonly WORK_ORDER_LOOKUP_WORK_ORDER_TYPE: RouteInfo = {
    url: '/workOrderType',
    name: 'home.maintenance.referenceData.workOrderType',
    breadcrumb: 'Work Order Type',
    parent: RouteConstants.MAINTENANCE_REFERENCE_DATA,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    selectionText: 'Work Order Type',
    shown: false
  };
  public static readonly WORK_ORDER_LOOKUP_CMMS_EXPENSE_CENTER: RouteInfo = {
    url: '/cmmsExpenseCenter',
    name: 'home.maintenance.referenceData.cmmsExpenseCenter',
    breadcrumb: 'External CMMS Expense Center',
    parent: RouteConstants.MAINTENANCE_REFERENCE_DATA,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    selectionText: 'External CMMS Expense Center',
    shown: false
  };
  public static readonly WORK_ORDER_LOOKUP_SHOPS: RouteInfo = {
    url: '/shop',
    name: 'home.maintenance.referenceData.shops',
    breadcrumb: 'Shop',
    parent: RouteConstants.MAINTENANCE_REFERENCE_DATA,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    selectionText: 'Shop',
    shown: false
  };
  public static readonly MAINTENANCE_PROCEDURE_GENERIC_PARTS: RouteInfo = {
    url: '/genericParts',
    name: 'home.maintenance.referenceData.genericParts',
    breadcrumb: 'Generic Parts',
    parent: RouteConstants.MAINTENANCE_REFERENCE_DATA,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    selectionText: 'Generic Parts',
    shown: false
  };
  public static readonly MAINTENANCE_PROCEDURE_TEST_EQUIPMENT_SPECIAL_TOOLS: RouteInfo = {
    url: '/testEquipmentSpecialTools',
    name: 'home.maintenance.referenceData.testEquipmentSpecialTools',
    breadcrumb: 'Test Equipment/Special Tools',
    parent: RouteConstants.MAINTENANCE_REFERENCE_DATA,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    selectionText: 'Test Equipment/Special Tools',
    shown: false
  };
  public static readonly MAINTENANCE_PROCEDURE_MISCELLANEOUS_SUPPLIES: RouteInfo = {
    url: '/miscellaneousSupplies',
    name: 'home.maintenance.referenceData.miscellaneousSupplies',
    breadcrumb: 'Miscellaneous Supplies',
    parent: RouteConstants.MAINTENANCE_REFERENCE_DATA,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    selectionText: 'Miscellaneous Supplies',
    shown: false
  };
  public static readonly MAINTENANCE_PROCEDURE_SPECIAL_CHARACTERS: RouteInfo = {
    url: '/specialCharacters',
    name: 'home.maintenance.referenceData.specialCharacters',
    breadcrumb: 'Special Characters',
    parent: RouteConstants.MAINTENANCE_REFERENCE_DATA,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    selectionText: 'Special Characters',
    shown: false
  };
  public static readonly MAINTENANCE_MASTER_TRAINING: RouteInfo = {
    url: '/masterTraining',
    name: 'home.maintenance.referenceData.masterTraining',
    breadcrumb: 'Master Training',
    parent: RouteConstants.MAINTENANCE_REFERENCE_DATA,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    shown: false
  };

  public static readonly WORK_LOAD_SUMMARY: RouteInfo = {
    url: '/workLoadSummary',
    name: 'home.workOrders.workLoadSummary',
    breadcrumb: 'Work Load Summary',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    selectionText: 'Work Load Summary',
    perm: ElementConstants.WORK_LOAD_SUMMARY,
    dividerFollows: true
  };
  public static readonly WORK_LOAD_BULK_UPDATE: RouteInfo = {
    url: '/bulkUpdate',
    name: 'home.workOrders.workLoadSummary.bulkupdate',
    breadcrumb: 'Bulk Update',
    parent: RouteConstants.WORK_LOAD_SUMMARY,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_LOAD_SUMMARY
  };
  public static readonly WORK_LOAD_BULK_UPDATE_CONFIRM: RouteInfo = {
    url: '/confirm',
    name: 'home.workOrders.workLoadSummary.bulkupdate.confirm',
    breadcrumb: 'Bulk Update Confirmation',
    parent: RouteConstants.WORK_LOAD_BULK_UPDATE,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_LOAD_SUMMARY
  };
  public static readonly WORK_LOAD_FOR_NEXT_MONTH: RouteInfo = {
    url: '/workLoadForNextMonth',
    name: 'home.workOrders.workLoadForNextMonth',
    breadcrumb: 'Work Load For Next Month',
    parent: RouteConstants.WORK_ORDER_SEARCH,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    selectionText: 'Work Load For Next Month',
    perm: ElementConstants.WORK_LOAD_FOR_NEXT_MONTH
  };
  public static readonly WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE: RouteInfo = {
    url: '/bulkUpdate',
    name: 'home.workOrders.workLoadForNextMonth.bulkupdate',
    breadcrumb: 'Bulk Update',
    parent: RouteConstants.WORK_LOAD_FOR_NEXT_MONTH,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE
  };
  public static readonly WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE_CONFIRM: RouteInfo = {
    url: '/confirm',
    name: 'home.workOrders.workLoadForNextMonth.bulkupdate.confirm',
    breadcrumb: 'Bulk Update Confirmation',
    parent: RouteConstants.WORK_LOAD_FOR_NEXT_MONTH,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE
  };
  public static readonly WORK_LOAD_BULK_UPDATE_RESULTS: RouteInfo = {
    url: '/results',
    name: 'home.workOrders.workLoadSummary.bulkupdate.results',
    breadcrumb: 'Bulk Update Results',
    parent: RouteConstants.WORK_LOAD_BULK_UPDATE,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_LOAD_SUMMARY
  };
  public static readonly WORK_ORDER_GRAPHICAL_SEARCH: RouteInfo = {
    url: '/graphicalSearch',
    name: 'home.workOrders.graphicalSearch',
    breadcrumb: 'Work Orders Graphical Search',
    parent: RouteConstants.WORK_ORDER_SEARCH,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID,
    perm: ElementConstants.WORK_ORDERS_GRAPHICAL_SEARCH,
    selectionText: 'Work Orders Graphical Search',
    shown: false
  };
  public static readonly CMMS_ERRORS: RouteInfo = {
    url: '/cmmsErrors',
    name: 'home.workOrders.cmmsErrors',
    breadcrumb: 'External Computerized Maintenance Management System (CMMS)/Maximo Errors',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID
  };

  public static readonly MEDICAL_EQUIPMENT_WORK_ORDER_SEARCH: RouteInfo = {
    url: '/workOrders/medicalEquipment',
    name: 'home.medicalEquipmentWorkOrders',
    breadcrumb: 'Work Orders',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.MAINTENANCE_NAV_ID
  };
  public static readonly MEDICAL_EQUIPMENT_WORK_ORDER_DETAILS: RouteInfo = {
    url: '/details?id',
    name: 'home.medicalEquipmentWorkOrders.details',
    breadcrumb: 'Work Order Details',
    parent: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_SEARCH
  };
  public static readonly MEDICAL_EQUIPMENT_WORK_ORDER_NEW: RouteInfo = {
    url: '/new',
    name: 'home.medicalEquipmentWorkOrders.new',
    breadcrumb: 'New Work Order',
    parent: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_SEARCH
  };
  public static readonly MEDICAL_EQUIPMENT_WORK_ORDER_NEW_DETAILS: RouteInfo = {
    url: '/details?id',
    name: 'home.medicalEquipmentWorkOrders.new.details',
    breadcrumb: 'Work Order Details',
    parent: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_NEW
  };

  public static readonly NOTIFICATIONS_ROOT: RouteInfo = {
    url: '/notifications',
    name: 'home.notifications',
    breadcrumb: 'Notifications',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.NOTIFICATIONS_NAV_ID
  };
  public static readonly NOTIFICATIONS: RouteInfo = {
    url: '/notifications',
    name: 'home.notifications.notifications',
    breadcrumb: 'Notifications',
    parent: RouteConstants.NOTIFICATIONS_ROOT,
    navigationId: NavigationConstants.NOTIFICATIONS_NAV_ID,
    shown: true,
    selectionText: 'Notifications',
    perm: ElementConstants.NOTIFICATIONS
  };

  public static readonly SSO_SAP_TEWLS: RouteInfo = {
    url: '/sapTewls',
    name: 'home.sso.sapTewls',
    breadcrumb: 'SAP TEWLS Single Sign-On',
    parent: RouteConstants.HOME_ROOT,
    navigationId: NavigationConstants.SSO_SAP_TEWLS_NAV_ID,
    shown: true,
    selectionText: 'SAP TEWLS Single Sign-On',
    perm: ElementConstants.SSO_SAP_TEWLS
  };
}
