import {Directive, Input, OnInit, TemplateRef, ViewContainerRef} from '@angular/core';
import {LoggerService} from '../services/logger/logger.service';
import {PermissionService} from '../services/permission.service';

@Directive({
  selector: '[lcElementChecker]'
})
export class LcElementCheckerDirective implements OnInit {

  constructor(
    private logger: LoggerService,
    private permissionService: PermissionService,
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef) { }

  public elementName: string;

  @Input() set lcElementChecker(elementName: string) {
    this.elementName = elementName;
  }

  public ngOnInit() {
    if (this.elementName){
      const canAccess: boolean = this.permissionService.checkElements(this.elementName);
      this.logger.debug(`User can access: ${canAccess}, ${this.elementName}`);

      if (canAccess) {
        this.viewContainer.createEmbeddedView(this.templateRef);
      } else {
        this.viewContainer.clear();
      }

    }
  }

}
