import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LcElementCheckerDirective} from './lc-element-checker.directive';
import {LcHighlightDirective} from './lc-highlight.directive';
import {LcObserveVisibilityDirective} from './lc-observe-visibility.directive';
import {LcCrossFieldValidatorDirective} from './lc-cross-field-validator.directive';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    LcElementCheckerDirective,
    LcHighlightDirective,
    LcObserveVisibilityDirective,
    LcCrossFieldValidatorDirective
  ],
  exports: [
    LcElementCheckerDirective,
    LcHighlightDirective,
    LcObserveVisibilityDirective,
    LcCrossFieldValidatorDirective
  ]
})
export class DirectivesModule {
}
