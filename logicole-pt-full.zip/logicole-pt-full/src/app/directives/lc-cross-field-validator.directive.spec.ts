import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';
import {Component, ViewChild} from '@angular/core';
import {ErrorMessages, LcCrossFieldValidatorDirective, Operator} from 'app/directives/lc-cross-field-validator.directive';
import {FormControl, FormsModule, NgForm} from '@angular/forms';
import {CommonComponentsModule} from '@lc-common-components';
import {UtilService} from 'app/services/util.service';
import {UtilServiceMock} from 'app/services/util.service.mock';

interface Model {
  firstField: any;
  secondField: any;
}
@Component({
  selector: 'lc-test-component',
  template: `
  <form #testForm="ngForm"
        id="testFormId"
        name="testForm">
    <div #testModelGroup="ngModelGroup" ngModelGroup="testModelGroup"
        lcCrossFieldValidator
        [firstField]="firstField"
        [secondField]="secondField"
        [operator]="Operator.GreaterThan">
        <lc-text-input #firstField
                       name="firstField"
                       inputId="firstFieldId"
                       label="First Field"
                       [(ngModel)]="model.firstField"
                       [isRequired]="true">
        </lc-text-input>
        <lc-text-input #secondField
                       name="secondField"
                       inputId="secondFieldId"
                       label="Second Field"
                       [(ngModel)]="model.secondField"
                       [isRequired]="true">
        </lc-text-input>
    </div>
  </form>`,
})
class TestComponent {
  @ViewChild('testForm') public form: NgForm;
  @ViewChild(LcCrossFieldValidatorDirective) public lcCrossFieldValidator: LcCrossFieldValidatorDirective;
  public model = {firstField: 10, secondField: 11} as Model;
  public Operator = Operator;
}
describe('LcCrossFieldValidatorDirective', () => {
  let component: TestComponent;
  let fixture: ComponentFixture<TestComponent>;
  let testForm: NgForm;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonComponentsModule.forRoot(),
        FormsModule,
      ],
      declarations: [TestComponent, LcCrossFieldValidatorDirective],
      providers: [
        {provide: UtilService, useClass: UtilServiceMock},

      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    testForm = component.form;
  });

  afterEach(() => {
    testForm = null;
    component = null;
    fixture = null;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('viewChild should be created', () => {
    expect(component.lcCrossFieldValidator).toBeTruthy();
  });

  it('should have FirstField defined', () => {
    const actual: FormControl = component.lcCrossFieldValidator.firstField;
    expect(actual).toBeDefined();
  });

  it('should have SecondField defined', () => {
    const actual: FormControl = component.lcCrossFieldValidator.secondField;
    expect(actual).toBeDefined();
  });

  it('should have Operator defined', () => {
    const actual: Operator = component.lcCrossFieldValidator.operator;
    expect(actual).toBeDefined();
  });


  it('should display errorMsg when FirstField is NOT Greater than SecondField', waitForAsync(() => {
    component.model = {firstField: 2, secondField: 12};
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(testForm.controls['testModelGroup'].errors['errorMsg']).toEqual(ErrorMessages.GreaterThan);
    });
  }));

  it('should NOT display errorMsg when FirstField is Greater than SecondField', waitForAsync(() => {
    component.model = {firstField: 12, secondField: 2};
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(testForm.controls['testModelGroup'].errors).toBeNull();
    });
  }));

  it('should display errorMsg when FirstField is NOT Less than SecondField', waitForAsync(() => {
    component.lcCrossFieldValidator.operator = Operator.LessThan;
    component.model = {firstField: 12, secondField: 2};
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(testForm.controls['testModelGroup'].errors['errorMsg']).toEqual(ErrorMessages.LessThan);
    });
  }));

  it('should NOT display errorMsg when FirstField is Less than SecondField', waitForAsync(() => {
    component.model = {firstField: 2, secondField: 12};
    component.lcCrossFieldValidator.operator = Operator.LessThan;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(testForm.controls['testModelGroup'].errors).toBeNull();
    });
  }));

  it('should display errorMsg when FirstField is NOT Equal to SecondField', waitForAsync(() => {
    component.lcCrossFieldValidator.operator = Operator.Equal;
    component.model = {firstField: 'abc', secondField: 'def'};
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(testForm.controls['testModelGroup'].errors['errorMsg']).toEqual(ErrorMessages.Equal);
    });
  }));

  it('should NOT display errorMsg when FirstField is Equal to SecondField', waitForAsync(() => {
    component.model = {firstField: 'abc', secondField: 'abc'};
    component.lcCrossFieldValidator.operator = Operator.Equal;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(testForm.controls['testModelGroup'].errors).toBeNull();
    });
  }));
});

