import {Directive, Input} from '@angular/core';
import {AbstractControl, FormControl, NG_VALIDATORS, ValidationErrors, Validator, ValidatorFn} from '@angular/forms';

export enum Operator { Equal, LessThan, GreaterThan }
export enum ErrorMessages {
  Equal = 'Fields do not match.',
  LessThan = 'First field is not less than Second field.',
  GreaterThan = 'First field is not greater than Second field.' }
export function crossFieldValidator(firstField: string,
                                    secondField: string,
                                    operator: Operator,
                                    message: string): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    switch (operator) {
      case Operator.LessThan:
        if (+firstField < +secondField) {
          return null;
        } else {
          return { errorMsg: (message) ? message : ErrorMessages.LessThan };
        }
      case Operator.GreaterThan:
        if (+firstField > +secondField) {
          return null;
        } else {
          return { errorMsg: (message) ? message : ErrorMessages.GreaterThan };
        }
      default:
        if (firstField && secondField && firstField === secondField) {
          return null;
        } else {
          return { errorMsg: (message) ? message : ErrorMessages.Equal };
        }
    }
  };
}

@Directive({
  selector: '[lcCrossFieldValidator]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: LcCrossFieldValidatorDirective,
      multi: true
    }
  ]
})
export class LcCrossFieldValidatorDirective implements Validator {
  @Input() public firstField: FormControl;
  @Input() public secondField: FormControl;
  @Input() public operator: Operator = Operator.Equal;
  @Input() public message: string;

  public validate(control: AbstractControl): ValidationErrors | null {
    return crossFieldValidator(this.firstField['parentControl'].value, this.secondField['parentControl'].value, this.operator, this.message)(control);
  }
}
