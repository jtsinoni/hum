import {Directive, ElementRef, HostListener, Input} from '@angular/core';

@Directive({
  selector: '[lcHighlight]'
})
export class LcHighlightDirective {

  constructor(private el: ElementRef) { }

  @Input() public defaultColor: string;

  @Input('lcHighlight') public highlightColor: string;

  @HostListener('mouseenter') public onMouseEnter() {
    this.highlight(this.highlightColor || this.defaultColor || 'red');
  }

  @HostListener('mouseleave') public onMouseLeave() {
    this.highlight(null);
  }

  private highlight(color: string) {
    this.el.nativeElement.style.backgroundColor = color;
  }

}
