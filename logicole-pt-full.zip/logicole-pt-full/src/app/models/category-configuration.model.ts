import {CategoryOption} from './category-option.model';
import {Observable} from 'rxjs';

export class CategoryConfiguration {

  public displayLabel: string = '';
  public aggregationIdentifiers: Array<string> = [];
  public elasticSearchFieldNames: Array<string> = [];
  public initializeAsCollapsed: boolean = false;
  public topLevelInitialCategoryOptions$: Observable<string[]>;

  constructor(obj?: CategoryConfiguration) {
    this.displayLabel = obj && obj.displayLabel || '';
    this.aggregationIdentifiers = obj && obj.aggregationIdentifiers || [];
    this.elasticSearchFieldNames = obj && obj.elasticSearchFieldNames || [];
    this.initializeAsCollapsed = obj && obj.initializeAsCollapsed || false;
    this.topLevelInitialCategoryOptions$ = obj && obj.topLevelInitialCategoryOptions$;
  }
}
