export class UploadFile {

  public name: string = '';
  public size: Number = 0;
  public date: Date = new Date();
  public contents: any = null;

  constructor(obj?: UploadFile) {
    this.name = obj && obj.name || '';
    this.size = obj && obj.size || 0;
    this.date = obj && obj.date || new Date();
    this.contents = obj && obj.contents || null;
  }
}
