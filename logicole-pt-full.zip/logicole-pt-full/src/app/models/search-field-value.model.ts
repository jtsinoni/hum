export class SearchFieldValue {
  public field: string;
  public value: string;
  public dateValue: Date;
  public numericValue: number;
  public operator: string;

  constructor(obj?: SearchFieldValue) {
    this.field = obj && obj.field || null;
    this.value = obj && obj.value || null;
    this.dateValue = obj && obj.dateValue || null;
    this.numericValue = obj && obj.numericValue || null;
    this.operator = obj && obj.operator || null;
  }
}
