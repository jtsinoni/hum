export class SearchCategoryItemModel<T> {
  public value: T | string;
  public count: number;

  constructor(obj?: SearchCategoryItemModel<T>) {
    this.value = obj && obj.value;
    this.count = obj && obj.count;
  }
}
