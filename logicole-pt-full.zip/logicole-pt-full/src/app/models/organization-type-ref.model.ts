export interface IOrgTypeRefSelection {
  value: OrganizationTypeReference;
  text: string;

}


export class OrganizationTypeReference implements IOrgTypeRefSelection {

  public id: any = '';
  public name: string = '';
  public hashValue: number = 0;
  public level: number;
  public text: string;
  public value: OrganizationTypeReference;


  constructor(obj?: OrganizationTypeReference) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.hashValue = obj && obj.hashValue || null;
    this.level = obj && obj.level || null;
    this.text = obj && obj.name || '';
    this.value = obj;
  }

}
