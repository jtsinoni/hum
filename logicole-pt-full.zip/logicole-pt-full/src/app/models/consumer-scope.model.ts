export enum ConsumerScope {
  AT_NODE = 'AtNode',
  BELOW_NODE = 'BelowNode'
}
