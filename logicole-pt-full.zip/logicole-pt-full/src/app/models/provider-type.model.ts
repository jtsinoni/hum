export class ProviderType {
  public displayText: string;
  public value: string;
}
