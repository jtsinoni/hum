export abstract class IdData {
  public id: string = '';
  
}
