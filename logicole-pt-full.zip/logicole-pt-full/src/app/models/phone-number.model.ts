export class PhoneNumber {

  public phoneNumberType: string;
  public value: string;

  constructor(obj?: PhoneNumber) {
    this.phoneNumberType = obj && obj.phoneNumberType;
    this.value = obj && obj.value || '';
  }

}
