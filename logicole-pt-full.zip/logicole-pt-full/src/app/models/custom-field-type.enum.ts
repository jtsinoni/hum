export enum CustomFieldType {
  STRING = 'String',
  DATE = 'Date',
  INTEGER = 'Integer',
  CURRENCY = 'Currency'
}
