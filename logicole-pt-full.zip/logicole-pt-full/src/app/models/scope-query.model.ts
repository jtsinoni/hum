import {UserProfile} from './user-profile.model';

export class ScopeQuery {
  public nodeTypeId: String;
  public scopeList: Array<string>;
  public userProfile: UserProfile;

  constructor(id: string, scopeList: Array<string>) {
    this.nodeTypeId = id;
    this.scopeList = scopeList;
  }

}
