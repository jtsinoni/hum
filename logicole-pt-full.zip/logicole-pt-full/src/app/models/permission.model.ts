export class PermissionRef {
  public id: string;
  public name: string;
  public hashValue: number;
}

export class Permission {

  public id: any = '';
  public name: string = '';
  public description: string = '';
  public functionalArea: string = '';
  public active: boolean = true;
  public updatedDate: Date = null;
  public updatedBy: string = '';
  public isChecked: boolean = false;

  constructor(obj?: Permission) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.description = obj && obj.description || '';
    this.functionalArea = obj && obj.functionalArea || '';
    this.active = obj && obj.active || true;
    this.updatedDate = obj && obj.updatedDate || null;
    this.updatedBy = obj && obj.updatedBy || '';
    this.isChecked = obj && obj.isChecked || false;
  }

  public static getRef(id: string, name: string): PermissionRef {
    const permissionRef = new PermissionRef();
    permissionRef.id = id;
    permissionRef.name = name;
    return permissionRef;
  }

}



