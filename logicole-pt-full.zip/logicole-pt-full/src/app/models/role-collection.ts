export class RoleCollection {

  public allOpts: any[] = [];
  public displayName: string = null;

  /**
   @param displayName the display name of the functionalArea to show
   @param allPermOpts an array of objects to be used to create the checkboxes
   */
  constructor(displayName: string, allOpts: any[]) {
    this.displayName = displayName;
    this.allOpts = allOpts;

  }
}
