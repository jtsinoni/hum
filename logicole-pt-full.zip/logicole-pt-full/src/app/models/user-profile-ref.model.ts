export class UserProfileRef {
    public id: any = '';
    public hashValue?: number = 0;
    public fullName: string;

    constructor(obj?: Partial<UserProfileRef>) {
        this.id = obj && obj.id || null;
        this.hashValue = obj && obj.hashValue || null;
        this.fullName = obj && obj.fullName || null;
    }
}
