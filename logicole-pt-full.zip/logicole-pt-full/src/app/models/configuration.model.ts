import {Metadata} from './metadata.model';

export class Configuration {
  public id: string;
  public _metadata: Metadata;
  public name: string;
  public owner: string;
  public userEditable: boolean;
  public value: any;


  constructor(obj?: Configuration) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.owner = obj && obj.owner || '';
    this.userEditable = obj && obj.userEditable || false;
    this.value = obj && obj.value || '';
    this._metadata = obj && obj._metadata || new Metadata();
  }
}
