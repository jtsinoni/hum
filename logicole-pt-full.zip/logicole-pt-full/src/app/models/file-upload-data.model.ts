import {UploadFileInformation} from './upload-file-information.model';
export class FileUploadData {

  public orgId: string = '';
  public itemId: string = '';
  public manufacturerName: string = '';
  public description: string = '';
  public catalogNumber: string = '';
  public fileName: string = '';

  public static create(uploadFileInfo: UploadFileInformation): FileUploadData {
    const obj: FileUploadData = new FileUploadData();
    obj.orgId = uploadFileInfo.orgId;
    obj.itemId = uploadFileInfo.itemId;
    obj.manufacturerName = uploadFileInfo.manufacturerName;
    obj.description = uploadFileInfo.description;
    obj.catalogNumber = uploadFileInfo.catalogNumber;
    obj.fileName = uploadFileInfo.file.name;
    return obj;
  }

  constructor(obj?: FileUploadData) {
    this.orgId = obj && obj.orgId || '';
    this.itemId = obj && obj.itemId || '';
    this.manufacturerName = obj && obj.manufacturerName || '';
    this.description = obj && obj.description || '';
    this.catalogNumber = obj && obj.catalogNumber || '';
    this.fileName = obj && obj.fileName || '';
  }
}
