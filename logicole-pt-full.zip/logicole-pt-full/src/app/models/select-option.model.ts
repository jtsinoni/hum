export class SelectOption {
  public text: string;
  public value: string;
}
