import {OrganizationRef} from './organization-ref.model';

export class HierSourceData {

  public id: string = '';
  public containingNodeRef: OrganizationRef;
  public sourceJson: string;

  constructor(obj?: HierSourceData) {
    this.id = obj && obj.id || '';
    this.containingNodeRef = obj && obj.containingNodeRef || null;
    this.sourceJson = obj && obj.sourceJson || '';
  }
}
