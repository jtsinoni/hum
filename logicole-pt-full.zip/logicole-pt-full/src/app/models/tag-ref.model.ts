export class TagRef {

  public id: any = '';
  public name: string = '';

  constructor(obj?: TagRef) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
  }
}
