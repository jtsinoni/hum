export class Aggregation {
  public value: string;
  public count: number;

  constructor(obj?: Aggregation) {
    this.value = obj && obj.value || null;
    this.count = obj && obj.count || null;
  }
}
