import {CustomFieldRef} from './custom-field-ref.model';

export class CustomFieldValue {
  public customFieldRef: CustomFieldRef;
  public valString: string;
  public valDate: Date;
  public valInteger: number;
  public valCurrency: number;

  constructor(obj?: any) {
    this.customFieldRef = (obj && obj.hasOwnProperty('customFieldRef')) ? obj.customFieldRef : new CustomFieldRef();
    this.valString = obj && obj.valString || null;
    this.valDate = obj && obj.valDate || null;
    this.valInteger = obj && obj.valInteger || null;
    this.valCurrency = obj && obj.valCurrency || null;
  }
}
