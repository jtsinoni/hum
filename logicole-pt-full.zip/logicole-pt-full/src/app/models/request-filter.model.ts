import {FilterElement} from './filter-element.model';

export class RequestFilter {

  public operator: String = '';
  public fieldValues: Array<FilterElement> = [];
  public fromDate: FilterElement;
  public toDate: FilterElement;
  public fromValue: FilterElement;
  public toValue: FilterElement;

  constructor(obj?: RequestFilter) {
    this.operator = obj && obj.operator || '';
    this.fieldValues = obj && obj.fieldValues || [];
    this.fromDate = obj && obj.fromDate || null;
    this.toDate = obj && obj.toDate || null;
    this.fromValue = obj && obj.fromValue || null;
    this.toValue = obj && obj.toValue || null;

  }
}
