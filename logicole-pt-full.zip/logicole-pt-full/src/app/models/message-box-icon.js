"use strict";
exports.__esModule = true;
var MessageBoxIcon;
(function (MessageBoxIcon) {
    MessageBoxIcon[MessageBoxIcon["noIcon"] = 0] = "noIcon";
    MessageBoxIcon[MessageBoxIcon["informationIcon"] = 1] = "informationIcon";
    MessageBoxIcon[MessageBoxIcon["warningIcon"] = 2] = "warningIcon";
    MessageBoxIcon[MessageBoxIcon["errorIcon"] = 3] = "errorIcon";
})(MessageBoxIcon = exports.MessageBoxIcon || (exports.MessageBoxIcon = {}));
