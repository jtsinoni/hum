export class InputConfiguration {

  public name: string = '';
  public title?: string = '';
  public ariaLabel?: string = '';

  constructor() {
  }
}
