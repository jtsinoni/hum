import {Permission} from './permission.model';

export class RoleFunctionalArea {
  public functionalArea: string = '';
  public permissions: Permission[] = [];

  constructor() {
  }
}
