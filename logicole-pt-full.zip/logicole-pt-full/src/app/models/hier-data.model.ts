import {OrganizationRef} from './organization-ref.model';
import {HierSourceData} from './hier-source-data.model';
import {HierDataOverride} from './hier-data-override.model';
import {HDataType} from './hdatatype.model';

export class HierData {

  public id: string = '';
  public dataType: HDataType;

  public containingNodeRef: OrganizationRef;
  public hierSourceData: HierSourceData;

  public hierDataOverrides: Map<string, HierDataOverride>;
  public localJson: string;

  constructor(obj?: HierData) {
    this.id = obj && obj.id || '';
    this.dataType = obj && obj.dataType || null;
    this.containingNodeRef = obj && obj.containingNodeRef || null;
    this.hierSourceData = obj && obj.hierSourceData || null;
    this.hierDataOverrides = obj && obj.hierDataOverrides || null;
    this.localJson = obj && obj.localJson || '';
  }
}
