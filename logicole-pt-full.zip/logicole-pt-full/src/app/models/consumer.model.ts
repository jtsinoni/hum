import {ProviderRef} from './provider-ref.model';
import {OrganizationRef} from './organization-ref.model';

export class Consumer {
  public scope: string;
  public providerRef: ProviderRef;
  public pointerNodeRef: OrganizationRef;


  constructor(obj?: any);
  constructor(obj?: Consumer) {
    this.scope =  obj && obj.scope || null;
    this.providerRef = obj && obj.providerRef || null;
    this.pointerNodeRef = obj && obj.pointerNodeRef || null;
  }

}
