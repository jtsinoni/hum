import {ServiceRoles} from './service-roles.model';
import {Metadata} from './metadata.model';

export class ServiceProvider {

  public id: string;
  public name: string;
  public isEnabled: boolean;
  public consumer: ServiceRoles;
  public _metadata: Metadata;
  public updatedBy: string;

  constructor(obj?: ServiceProvider) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.isEnabled = obj && obj.isEnabled || false;
    this.consumer = obj && obj.consumer || new ServiceRoles();
    this._metadata = obj && obj._metadata || new Metadata();
    this.updatedBy = obj && obj.updatedBy || '';
  }
}
