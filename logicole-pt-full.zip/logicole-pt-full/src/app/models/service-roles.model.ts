import {RoleRef} from './role-ref.model';

export class ServiceRoles {

  public roleRefs: Array<RoleRef>;

  constructor(obj?: ServiceRoles) {
    this.roleRefs = obj && obj.roleRefs || [];
  }
}
