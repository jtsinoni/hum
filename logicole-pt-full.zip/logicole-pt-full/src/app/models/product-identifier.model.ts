export class ProductIdentifier {
  public identifier: string;
  public identifierType: string;

  constructor(obj?: ProductIdentifier) {
    this.identifier = obj && obj.identifier || null;
    this.identifierType = obj && obj.identifierType || null;
  }
}
