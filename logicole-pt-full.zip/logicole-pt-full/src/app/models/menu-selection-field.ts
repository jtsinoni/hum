export class MenuSelectionField {
  public label: string = '';
  public field: string = '';
  public isSelected: boolean = false;

  constructor(obj?: MenuSelectionField) {
    this.label = obj && obj.label || '';
    this.field = obj && obj.field || '';
    this.isSelected = obj && obj.isSelected || false;
  }

}
