import {OrganizationRef} from '@lc-app-models';

export class FeatureFlagRef {
  public id: string;
  public name: string;
  public isEnabled: boolean = false;
  public startDate: Date;
  public endDate: Date;
  public hashValue: number;
  public excludeOrganizations: Array<OrganizationRef>;
  public includeOrganizations: Array<OrganizationRef>;

  constructor (id: string, name: string, isEnabled: boolean,
               startDate: Date, endDate: Date, hashValue: number,
               excludedOrgs: Array<OrganizationRef>,
               includedOrgs: Array<OrganizationRef>) {
    this.id = id;
    this.name = name;
    this.isEnabled = isEnabled;
    this.startDate = startDate;
    this.endDate = endDate;
    this.hashValue = hashValue;
    this.excludeOrganizations = excludedOrgs;
    this.includeOrganizations = includedOrgs;
  }


}
