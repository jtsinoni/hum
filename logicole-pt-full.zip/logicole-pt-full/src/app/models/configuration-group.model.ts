import {Configuration} from '@lc-app-models';

export class ConfigurationGroup {
  public groupName: string;
  public owner: string;
  public groupConfigurations: Array<Configuration>;

  constructor(obj?: ConfigurationGroup) {
    this.groupName = obj && obj.groupName || '';
    this.owner = obj && obj.owner || '';
    this.groupConfigurations = obj && obj.groupConfigurations || new Array<Configuration>();

  }

}
