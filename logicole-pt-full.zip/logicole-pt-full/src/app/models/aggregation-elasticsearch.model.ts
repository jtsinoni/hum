import {AggregationElasticsearchBucket} from './aggregation-elasticsearch-bucket.model';

export class AggregationElasticsearch {
  public doc_count_error_upper_bound: number;
  public sum_other_doc_count: number;
  public buckets: Array<AggregationElasticsearchBucket> = [];

  constructor(obj?: AggregationElasticsearch) {
    this.doc_count_error_upper_bound = obj && obj.doc_count_error_upper_bound || null;
    this.sum_other_doc_count = obj && obj.sum_other_doc_count || null;
    this.buckets = obj && obj.buckets || [];
  }
}
