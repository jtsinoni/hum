import {ClassificationTypeRef} from '../home/work-orders/models/classification-type-ref.model';
import {PriorityGroupRef} from '../home/work-orders/models/priority-group-ref.model';
import {SiteRef} from '../home/real-property/models/site-ref.model';
import {FacilityRef} from '../home/real-property/models/facility-ref.model';
import {WorkflowState} from '../common-components/lc-workflow/models/workflow-state.model';
import {SpaceRef} from '../home/real-property/space/models/space-ref.model';
import {AssetRef} from '../home/asset/asset-management/models/asset-ref.model';
import {Attachment} from './attachment.model';
import {UserProfileRef} from './user-profile-ref.model';

export class ServiceRequest {
  public id: string;
  public requestType: string;
  public workOrderNumber: string;
  public subject: string;
  public description: string;
  public justification: string;
  public classificationTypeRef: ClassificationTypeRef;
  public estimatedStartDate: Date;
  public requestDate: Date;
  public requesterName: string;
  public requesterContactNumber: string;
  public priorityGroupRef: PriorityGroupRef;
  public siteRef: SiteRef;
  public facilityRef: FacilityRef;
  public workflowState: WorkflowState;
  public otherLocation: string;
  public spaceRefs: SpaceRef[];
  public assetRefs: AssetRef[];
  public attachments: Attachment[];
  public newComment: any;
  public createdByRef: UserProfileRef;
  public reviewCompleteComment: string;
  public requestCancelComment: string;
  public facilityManagerCancelComment: string;
  public finalAcceptanceAcceptComment: string;
  public isSurveyCompleted: boolean;

  // PT only
  public isRequestCancelPending: boolean;
  public otherLocationPreEdit: string;

  constructor(obj?: ServiceRequest) {
    this.id = obj && obj.id;
    this.requestType = obj && obj.requestType;
    this.workOrderNumber = obj && obj.workOrderNumber;
    this.subject = obj && obj.subject;
    this.description = obj && obj.description;
    this.justification = obj && obj.justification;
    this.classificationTypeRef = obj && obj.classificationTypeRef;
    this.estimatedStartDate = obj && obj.estimatedStartDate;
    this.requestDate = obj && obj.requestDate;
    this.requesterName = obj && obj.requesterName;
    this.requesterContactNumber = obj && obj.requesterContactNumber;
    this.priorityGroupRef = obj && obj.priorityGroupRef;
    this.siteRef = obj && obj.siteRef;
    this.facilityRef = obj && obj.facilityRef;
    this.workflowState = obj && obj.workflowState;
    this.otherLocation = obj && obj.otherLocation;
    this.spaceRefs = obj && obj.spaceRefs || [];
    this.assetRefs = obj && obj.assetRefs || [];
    this.attachments = obj && obj.attachments || [];
    this.createdByRef = obj && obj.createdByRef;
    this.requestCancelComment = obj && obj.requestCancelComment;
    this.facilityManagerCancelComment = obj && obj.facilityManagerCancelComment;
    this.isSurveyCompleted = obj && obj.isSurveyCompleted || false;
  }
}
