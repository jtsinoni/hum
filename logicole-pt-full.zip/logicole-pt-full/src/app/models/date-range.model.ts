export class DateRange {
  public startDate: Date;
  public endDate: Date;
}
