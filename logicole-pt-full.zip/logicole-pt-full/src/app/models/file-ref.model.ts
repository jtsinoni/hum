export class FileRef {

  public id: any;
  public uploadDateTime: Date;
  public fileId: string;
  public uploadedFileName: string;
  public fileSize: number;
  public uploadedBy: string;
  public uploadedByName: string;
  public filePath: string;

  constructor(obj?: FileRef) {
    this.id = obj && obj.id || null;
    this.fileId = obj && obj.fileId || '';
    this.uploadDateTime = obj && obj.uploadDateTime || null;
    this.uploadedFileName = obj && obj.uploadedFileName || '';
    this.fileSize = obj && obj.fileSize || null;
    this.uploadedBy = obj && obj.uploadedBy || '';
    this.uploadedByName = obj && obj.uploadedByName || '';
    this.filePath = obj && obj.filePath || '';
  }
}
