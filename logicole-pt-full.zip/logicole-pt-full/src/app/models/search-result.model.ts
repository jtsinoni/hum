import {SearchCategoryModel} from './search-category.model';

export class SearchResult<T> {
  public total: number;
  public limit: number;
  public aggregations: Array<SearchCategoryModel<T>>;
  public results = new Array<T>();

  constructor(obj?: SearchResult<T>) {
    this.total = obj && obj.total;
    this.limit = obj && obj.limit;
    this.aggregations = obj && obj.aggregations || [];
    this.results = obj && obj.results || [];
  }
}
