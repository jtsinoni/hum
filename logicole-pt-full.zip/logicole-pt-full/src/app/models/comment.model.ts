export class Comment {
  public id: string;
  public text: string;
  public created: Date;
  public userName: string;
  public userId: string;

  constructor(obj?: Comment) {
    this.id = obj && obj.id || '';
    this.text = obj && obj.text || '';
    this.created = obj && obj.created || null;
    this.userName = obj && obj.userName || '';
    this.userId = obj && obj.userId || '';
  }
}
