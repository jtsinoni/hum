export abstract class NamedData {
  public id: string;
  public name: string;
  public parameters: Array<string>;
}
