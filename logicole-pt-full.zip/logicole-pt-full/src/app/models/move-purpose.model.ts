export enum MovePurpose {
  ADD_ORGANIZATIONS = 'Add Organizations',
  MOVE_ORGANIZATIONS = 'Move Organizations'
}
