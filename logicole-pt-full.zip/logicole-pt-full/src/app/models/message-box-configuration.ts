import { MessageBoxIcon } from './message-box-icon';

export type ShowButtons = 'showYesNoButtons' | 'showOkCancelButtons' | 'showCloseButton' | 'showYesNoCascadeButtons';
export type ModalSize = 'small' | 'medium' | 'large';
export interface MessageBoxConfiguration {
  useAnimation?: boolean;
  allowEscapeToClose?: boolean;
  showBackdrop?: boolean;
  allowBackdropClickToClose?: boolean;
  showLargeModal?: boolean;
  // if you supply modalSize, it will take precedence over showLargeModal.
  modalSize?: ModalSize;
  icon?: MessageBoxIcon;
  parentCloseModal?: boolean;
  showButtons?: ShowButtons;
  // TODO: Will be removed after we convert to lc-message-box2
  showYesNoButtons?: boolean;
  showOkCancelButtons?: boolean;
  showCloseButton?: boolean;
}
