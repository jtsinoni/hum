import {RequestFilter} from './request-filter.model';
export class AppHistorySearch {

  public startDate: any = '';
  public endDate: string = '';
  public searchString: string = '';
  public filters: RequestFilter[] = null;

  constructor(obj?: AppHistorySearch) {
    this.startDate = obj && obj.startDate || '';
    this.endDate = obj && obj.endDate || '';
    this.searchString = obj && obj.searchString || '';
    this.filters = obj && obj.filters || null;
  }
}

