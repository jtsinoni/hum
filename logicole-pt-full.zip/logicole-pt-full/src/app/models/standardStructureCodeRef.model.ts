
export class StandardStructureCodeRef {

  public id: string;
  public guid: string;
  public type: string;
  public code: string;
  public nomenclature: string;
  public parent: string;
  public isActive: boolean;

  constructor(obj?: any);
  constructor(obj?: StandardStructureCodeRef) {
    this.id = obj && obj.id || '';
    this.guid = obj && obj.guid || '';
    this.type = obj && obj.type || '';
    this.code = obj && obj.code || '';
    this.nomenclature = obj && obj.nomenclature || '';
    this.parent = obj && obj.parent || '';
    this.isActive = obj && obj.isActive || true;
  }
}
