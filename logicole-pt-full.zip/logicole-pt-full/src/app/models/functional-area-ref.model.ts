export class FunctionalAreaRef {

  public id: string;
  public displayName: string;
  public parent: FunctionalAreaRef;

  constructor(obj?: FunctionalAreaRef) {
    this.id = obj && obj.id || null;
    this.displayName = obj && obj.displayName || null;
    this.parent = obj && obj.parent || null;
  }
}
