import {FileRef} from './file-ref.model';
export class Attachment {

  public description: string;
  public fileRef: FileRef;
  public section: string;
  public isMarkedForDelete: boolean = false;
  public category: string;
  public source: string;

  constructor(obj?: Attachment) {
    this.description = obj && obj.description || '';
    this.fileRef = obj && obj.fileRef || null;
    this.section = obj && obj.section || '';
    this.isMarkedForDelete = obj && obj.isMarkedForDelete || false;
    this.category = obj && obj.category || '';
    this.source = obj && obj.source || '';
  }
}
