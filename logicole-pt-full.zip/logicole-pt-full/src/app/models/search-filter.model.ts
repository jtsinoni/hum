import {SearchFieldValue} from './search-field-value.model';

export class SearchFilter {
  public operator: string;
  public fieldValues: SearchFieldValue[];
  public fromDate: SearchFieldValue;
  public toDate: SearchFieldValue;
  public fromValue: SearchFieldValue;
  public toValue: SearchFieldValue;

  constructor(obj?: SearchFilter) {
    this.operator = obj && obj.operator || null;
    this.fieldValues = obj && obj.fieldValues || [];
    this.fromDate = obj && obj.fromDate || null;
    this.toDate = obj && obj.toDate || null;
    this.fromValue = obj && obj.fromValue || null;
    this.toValue = obj && obj.toValue || null;
  }
}
