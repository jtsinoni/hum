export class ServiceProviderRef {
  public id: string = '';
  public name: string = '';
  public hashValue: number = 0;

  // UI Only
  public selected: boolean;

  constructor(obj?: ServiceProviderRef) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.hashValue = obj && obj.hashValue || 0;
  }
}
