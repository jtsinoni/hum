export class SearchCriterion {
  public propName: string = '';
  public propValues: Array<string | boolean | number | Date> = new Array<string | boolean | number | Date>();
  public method: string = '';

  constructor(obj?: SearchCriterion) {
    this.propName = obj && obj.propName || '';
    this.propValues = obj && obj.propValues || new Array<string | boolean | number | Date>();
    this.method = obj && obj.method || '';
  }
}
