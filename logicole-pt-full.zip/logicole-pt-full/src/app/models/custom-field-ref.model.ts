import {CustomFieldType} from './custom-field-type.enum';

export class CustomFieldRef {
  public id: string;
  public label: string;
  public fieldType: CustomFieldType;

  constructor(obj?: any) {
    this.id = obj && obj.id || '';
    this.label = obj && obj.label || '';
    this.fieldType = obj && obj.fieldType || null;
  }
}
