import {UserProfileTemplate} from './user-profile-template.model';

export class GroupInvitation {

  public id: any = null;
  public reason: string = '';
  public deletedDate: Date;
  public name: string = '';
  public expirationDate: Date;
  public profileExpDate: Date;
  public managedByNodeRefName: string = '';
  public invitationUrl: string = '';
  public userProfileTemplate: UserProfileTemplate;
  public pendingCount: number;
  public activeCount: number;
  public deniedCount: number;
  public isExpired: string;

  constructor(obj?: GroupInvitation) {
    this.id = obj && obj.id || null;
    this.profileExpDate = obj && obj.profileExpDate;
    this.reason = obj && obj.reason || '';
    this.deletedDate = obj && obj.deletedDate;
    this.managedByNodeRefName = obj && obj.managedByNodeRefName;
    this.name = obj && obj.name;
    this.expirationDate = obj && obj.expirationDate;
    this.invitationUrl = obj && obj.invitationUrl;
    this.userProfileTemplate = obj && obj.userProfileTemplate || new UserProfileTemplate();
    this.pendingCount = obj && obj.pendingCount;
    this.activeCount = obj && obj.activeCount;
    this.deniedCount = obj && obj.deniedCount;
    this.isExpired = obj && obj.isExpired;
  }
}
