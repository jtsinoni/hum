export class ProviderRef {
  public id: string;
  public name: string;
  public type: string;
  public referenceParameters: Array<string>;
  public addContainerIdAsParameter: boolean;


  constructor(obj?: any);
  constructor(obj?: ProviderRef) {
    this.referenceParameters = obj && obj.referenceParameters || [];

  }
}
