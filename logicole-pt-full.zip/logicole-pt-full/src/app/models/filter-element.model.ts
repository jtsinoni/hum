import {EFieldValueComparator} from './e-field-value-comparator.model';

export class FilterElement {
  public field: string;
  public value: string;
  public dateValue: Date;
  public numericValue: number;
  public operator: EFieldValueComparator;
}
