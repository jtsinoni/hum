export class ProductPackaging {
  public enterprisePackageIdentifier: string;
  public gtin: string;
  public otherPackageIdentifiers: string[];
  public packageUnit: string;
  public packageQuantity: number;
  public gudidIdentifierType: string;
  public barcodes: string[] = [];
  public packageUnitText: string;
  public packageUnitDescription: string;
  public doseOrUseCount: number;
  public innerPackMultiple: number;
  public nsn: string[] = [];

  constructor(obj: any) {
    this.enterprisePackageIdentifier = obj && obj.enterprisePackageIdentifier || null;
    this.gtin = obj && obj.gtin || null;
    this.otherPackageIdentifiers = obj && obj.otherPackageIdentifiers || [];
    this.packageUnit = obj && obj.packageUnit || null;
    this.packageQuantity = obj && obj.packageQuantity || null;
    this.gudidIdentifierType = obj && obj.gudidIdentifierType || null;
    this.barcodes = obj && obj.barcodes || [];
    this.packageUnitText = obj && obj.packageUnitText || null;
    this.packageUnitDescription = obj && obj.packageUnitDescription || null;
    this.doseOrUseCount = obj && obj.doseOrUseCount || null;
    this.innerPackMultiple = obj && obj.innerPackMultiple || null;
    this.nsn = obj && obj.nsn || [];
  }
}
