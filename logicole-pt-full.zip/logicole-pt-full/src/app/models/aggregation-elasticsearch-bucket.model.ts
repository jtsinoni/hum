export class AggregationElasticsearchBucket {
  public key: string;
  public doc_count: number;
  public distinctCount: {value: string};

  constructor(obj?: AggregationElasticsearchBucket) {
    this.key = obj && obj.key || null;
    this.doc_count = obj && obj.doc_count || null;
    this.distinctCount = obj && obj.distinctCount || null;
  }
}
