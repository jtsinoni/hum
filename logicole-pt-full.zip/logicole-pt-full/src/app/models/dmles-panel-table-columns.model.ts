export class DmlesPanelTableColumns {

  public title: string;
  public field: string;
  public show: boolean;
  public sortable: string;
  public type: string;
  public filter: any = null;
  public filterData: any = null;

  constructor(obj?: DmlesPanelTableColumns) {
    this.title = obj && obj.title || '';
    this.field = obj && obj.field || '';
    this.show = obj && obj.show || true;
    this.sortable = obj && obj.sortable || '';
    this.type = obj && obj.type || 'text';

    if (obj && obj.filter){
      this.filter = obj && obj.filter || null;
    }

    if (obj && obj.filterData){
      this.filterData = obj && obj.filterData || null;
    }
  }

}
