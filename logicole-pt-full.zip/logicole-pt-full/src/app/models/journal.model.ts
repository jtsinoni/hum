import {JournalAction} from './journal-action.model';

export class Journal {
  public journalId: string;  // Not an _id, but a GUID
  public journalSubject: string;
  public journalEntry: string;
  public journalActions: Array<JournalAction>;
  public firstName: string;
  public lastName: string;
  public userId: string;
  public createdDate: Date;
  public modifiedDate: Date;
  public isMarkedForDelete: boolean = false;
  public isMarkedForEditing: boolean = false;
  public canBeEdited: boolean = true;

  constructor(obj?: Journal) {
    this.journalId = obj && obj.journalId || '';
    this.journalSubject = obj && obj.journalSubject || '';
    this.journalEntry = obj && obj.journalEntry || '';
    this.journalActions = obj && obj.journalActions || [];
    this.firstName = obj && obj.firstName || '';
    this.lastName = obj && obj.lastName || '';
    this.userId = obj && obj.userId || '';
    this.createdDate = obj && obj.createdDate || null;
    this.modifiedDate = obj && obj.modifiedDate || null;
    this.isMarkedForDelete = obj && obj.isMarkedForDelete || false;
    this.isMarkedForEditing = obj && obj.isMarkedForEditing || false;
    this.canBeEdited = obj && obj.canBeEdited || true;
  }
}
