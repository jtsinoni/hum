import {OrganizationRef, PermissionRef, RoleRef} from '@lc-app-models';
import {PermElementRef} from './perm-element-ref.model';
import {PermStateRef} from './perm-state-ref.model';
import {PermEndpointRef} from './perm-endpoint-ref.model';

export class FeatureFlag {
  public id: string;
  public name: string;
  public description: string;
  public isEnabled: boolean = false;
  public startDate: Date;
  public endDate: Date;
  public hashValue: number;
  public excludeOrganizations: Array<OrganizationRef>;
  public includeOrganizations: Array<OrganizationRef>;
  public permissionRefList: Array<PermissionRef>;
  public roleRefList: Array<RoleRef>;
  public elementRefList: Array<PermElementRef>;
  public stateRefList: Array<PermStateRef>;
  public endpointRefList: Array<PermEndpointRef>;

  constructor(obj?: FeatureFlag) {
    this.id = obj && obj.id || null;
    this.name = obj && obj.name || null;
    this.description = obj && obj.description || null;
    this.isEnabled = obj && obj.isEnabled || null;
    this.startDate = obj && obj.startDate || new Date();
    this.hashValue = obj && obj.hashValue || 0;
    if (obj && obj.endDate) {
      this.endDate = obj.endDate;
    } else {
      const nextDate: Date = new Date();
      nextDate.setDate(nextDate.getDate() + 7);
      this.endDate = nextDate;
    }
    this.excludeOrganizations = obj && obj.excludeOrganizations || [];
    this.includeOrganizations = obj && obj.includeOrganizations || [];
    this.permissionRefList = obj && obj.permissionRefList || [];
    this.roleRefList = obj && obj.roleRefList || [];
    this.elementRefList = obj && obj.elementRefList || [];
    this.stateRefList = obj && obj.stateRefList || [];
    this.endpointRefList = obj && obj.endpointRefList || [];
  }
}


