import {PhoneNumber} from './phone-number.model';

export class Contact {
  public contactId: string;
  public firstName: string;
  public lastName: string;
  public title: string;
  public dutyTitle: string;
  public rankGrade: string;
  public phoneNumbers: Array<PhoneNumber>;
  public email: string;
  public website: string;
  public isDefault: boolean;
  public isPrimary: boolean;
  public division: string;
  public isQualityControlInspector: boolean;
  public isQualityAssuranceEvaluator: boolean;
  public isDeleted: boolean;

  // PT only
  public selectedWorkPhone: string;
  public selectedMobilePhone: string;

  // UI only
  public isMarkedForDelete: boolean = false;
  public isMarkedForEdit: boolean = false;
  public isNewRecord: boolean = false;

  constructor(obj?: any) {
    this.contactId = obj && obj.contactId || '';
    this.firstName = obj && obj.firstName || '';
    this.lastName = obj && obj.lastName || '';
    this.title = obj && obj.title || '';
    this.dutyTitle = obj && obj.dutyTitle || '';
    this.rankGrade = obj && obj.rankGrade || '';
    this.phoneNumbers = obj && obj.phoneNumbers || [new PhoneNumber()];
    this.email = obj && obj.email || '';
    this.website = obj && obj.website || '';
    this.isDefault = (obj && obj.hasOwnProperty('isDefault')) ? obj.isDefault : false;
    this.isPrimary = (obj && obj.hasOwnProperty('isPrimary')) ? obj.isPrimary : false;
    this.division = obj && obj.division || '';
    this.selectedWorkPhone = obj && obj.selectedWorkPhone || null;
    this.selectedMobilePhone = obj && obj.selectedMobilePhone || null;
    this.isQualityControlInspector = obj && obj.isQualityControlInspector;
    this.isQualityAssuranceEvaluator = obj && obj.isQualityAssuranceEvaluator;
    this.isDeleted = obj && obj.isDeleted;

    this.isMarkedForDelete = obj && obj.isMarkedForDelete;
    this.isMarkedForEdit = obj && obj.isMarkedForEdit;
    this.isNewRecord = obj && obj.isNewRecord;
  }
}
