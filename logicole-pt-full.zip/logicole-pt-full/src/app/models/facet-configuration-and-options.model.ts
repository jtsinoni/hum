import {FacetConfiguration} from './facet-configuration.model';
import {FacetOption} from './facet-option.model';

export class FacetConfigurationAndOptions {
  public config: FacetConfiguration;
  public options: FacetOption[] = [];

  constructor(obj?: FacetConfigurationAndOptions) {
    this.config = obj && obj.config || new FacetConfiguration();
    if (obj && obj.options) {
      this.options = [];
      for (let i = 0; i < obj.options.length; i++) {
        this.options.push(obj.options[i]);
      }
    } else {
      this.options = [];
    }
  }
}
