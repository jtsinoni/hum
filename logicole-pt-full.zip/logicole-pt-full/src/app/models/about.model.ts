export class About {

  public version: string = '';
  public buildDate: Date = new Date();

  constructor(obj?: About) {
    this.version = obj && obj.version || '';
    this.buildDate = obj && obj.buildDate || null;
  }
}
