import {UserProfileRef} from './user-profile-ref.model';

export class ProfileUpdateReason {
  public reason: string = null;
  public updatedDate: Date;
  public updatedBy: UserProfileRef;
  public profileSection: string = null;
}
