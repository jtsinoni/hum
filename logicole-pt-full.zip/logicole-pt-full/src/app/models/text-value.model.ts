export class TextValue {
  public text: string;
  public value: string;

  constructor(obj?: TextValue) {
    this.text = obj && obj.text || null;
    this.value = obj && obj.value || null;
  }
}
