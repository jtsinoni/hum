export class MarketInfo {
  public marketSize: string;
  public isPatientCare: boolean;
  public meprsCode: string;
  public supportFacility: string;
  public areaOfResponsibility: string;

  constructor(obj?: MarketInfo) {
    this.marketSize = obj && obj.marketSize || '';
    this.isPatientCare = obj && obj.isPatientCare;
    this.meprsCode = obj && obj.meprsCode || '';
    this.supportFacility = obj && obj.supportFacility || '';
    this.areaOfResponsibility = obj && obj.areaOfResponsibility || '';
  }
}
