export class RoleRef {

  public id: any = '';
  public name: string = '';

  constructor(obj?: RoleRef) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
  }
}
