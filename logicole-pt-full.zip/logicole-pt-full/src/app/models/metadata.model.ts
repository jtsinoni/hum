
export class Metadata {
  public modifiedDate: Date;
  public modifiedMillis: number;
  public createdDate: Date;
  public createdMillis: number;

  constructor(obj?: any) {
    this.modifiedDate = obj && obj.modifiedDate || 0;
    this.modifiedMillis = obj && obj.modifiedMillis || 0;
    this.createdDate = obj && obj.createdDate || 0;
    this.createdMillis = obj && obj.createdMillis || 0;
  }
}
