import {LcTreeData} from './lc-NodeTree.model';
import {OrganizationTypeReference} from './organization-type-ref.model';
import {StandardStructureCodeRef} from './standardStructureCodeRef.model';
import {ServiceProviderRef} from './service-provider-ref.model';
import {OrganizationRef} from './organization-ref.model';
import {Consumer} from './consumer.model';
import {BusinessServiceDefinition} from './business-service-definition/business-service-definition.model';
import {MarketInfo} from './marketinfo.model';


export class Organization extends LcTreeData {

  public id: string;
  public name: string;
  public organizationIdentifier: string;
  public stationIdentifier: string;
  public dmlssKey: string;
  public milServiceId: string;
  public providerCode: string;
  public ancestry: string;
  public childIds: Array<string>;
  public parentId: string;
  public standardStructureCode: string;
  public standardStructureCodeRef: StandardStructureCodeRef;
  public organizationTypeRef: OrganizationTypeReference;
  public serviceProviderRefs: Array<ServiceProviderRef> = [];
  public organizationHierarchy: string;
  public standardStructureHierarchy: string;
  public label: string;
  public consumers: Array<Consumer>;
  public businessServices: Array<BusinessServiceDefinition> = [];
  public effectiveBusinessServices: Array<BusinessServiceDefinition> = [];
  public marketInfo: MarketInfo;

  public hasConsumers: boolean = false;
  public facilitiesEnterpriseRegion: string;

  constructor(obj?: any);
  constructor(obj?: Organization) {
    super();
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.organizationIdentifier = obj && obj.organizationIdentifier || '';
    this.stationIdentifier = obj && obj.stationIdentifier || '';
    this.facilitiesEnterpriseRegion = obj && obj.facilitiesEnterpriseRegion || '';
    this.milServiceId = obj && obj.milServiceId || '';
    this.providerCode = obj && obj.providerCode || '';
    this.dmlssKey = obj && obj.dmlssKey || '';
    this.ancestry = obj && obj.ancestry || '';
    this.childIds = obj && obj.childIds || [];
    this.parentId = obj && obj.parentId || '';
    this.standardStructureCode = obj && obj.standardStructureCode || '';
    this.standardStructureCodeRef = obj && obj.standardStructureCodeRef || new StandardStructureCodeRef();
    this.organizationTypeRef = obj && obj.organizationTypeRef || new OrganizationTypeReference();
    this.serviceProviderRefs = obj && obj.serviceProviderRefs || [];
    this.organizationHierarchy = obj && obj.organizationHierarchy || '';
    this.standardStructureHierarchy = obj && obj.standardStructureHierarchy || '';
    this.label = obj && obj.label || '';
    this.consumers = obj && obj.consumers || null;
    this.businessServices = obj && obj.businessServices || [];
    this.effectiveBusinessServices = obj && obj.effectiveBusinessServices || [];
    this.marketInfo = obj && obj.marketInfo || new MarketInfo();

  }

  public static getRef(id: string, name: string, nodeId: string, ancestry: string): OrganizationRef {
    const organizationRef: OrganizationRef = new OrganizationRef();
    organizationRef.id = id;
    organizationRef.name = name;
    organizationRef.organizationIdentifier = nodeId;
    organizationRef.ancestry = ancestry;
    return organizationRef;
  }

  public toString(): string {
    return this.name;
  }

}
