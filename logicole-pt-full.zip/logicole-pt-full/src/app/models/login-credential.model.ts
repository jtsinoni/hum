import {CurrentUserProfile} from '@lc-app-models';

export class LoginCredential {

  public jsonWebToken: string;
  public currentUser: CurrentUserProfile;

  constructor(obj?: LoginCredential) {
    this.jsonWebToken = obj && obj.jsonWebToken || '';
    this.currentUser = obj && obj.currentUser || null;
  }
}
