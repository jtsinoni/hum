export class InstallationRef {
  public id: string;
  public name: string;
  public code: string;

  constructor(obj?: any) {
    this.id = obj && obj.id;
    this.name = obj && obj.name;
    this.code = obj && obj.code;
  }
}
