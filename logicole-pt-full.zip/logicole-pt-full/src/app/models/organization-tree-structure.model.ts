import {OrganizationRef} from './organization-ref.model';
import {OrganizationTypeReference} from './organization-type-ref.model';

export class OrganizationTreeStructure {

  public id: string;
  public organizationRef: OrganizationRef;
  public organizationTypeRef: OrganizationTypeReference;
  public allowChildOrgTypeRefs: Array<OrganizationTypeReference> = [];

  constructor(obj?: OrganizationTreeStructure) {
    this.id = obj && obj.id || '';
    this.organizationRef = obj && obj.organizationRef || null;
    this.organizationTypeRef = obj && obj.organizationTypeRef || null;
    this.allowChildOrgTypeRefs = obj && obj.allowChildOrgTypeRefs || [];

  }

}
