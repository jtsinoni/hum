export class LcNodeTree<T extends LcTreeData> {
  public id: string;
  public name: string;
  public description: string;
  public ancestry: string;

  public data: T;
  public children: Array<LcNodeTree<T>>;
  public expanded: boolean;
  public checked: boolean;
  public selected: boolean;
  public childIds: Array<string>;

  constructor(data: T, description: string, ancestry: string) {
    this.data = data;
    this.children = null;
    this.description = description;
    this.ancestry = ancestry;
  }
}

export abstract class LcTreeData {
  public id: string;
  public name: string;
  public parentId: string;
  public ancestry: string;
  public childIds: Array<string>;
}
