export class FormGroupError {

  public controlName: string;
  public errorMessage: string;

  constructor(obj?: FormGroupError) {
    this.controlName = obj && obj.controlName || null;
    this.errorMessage = obj && obj.errorMessage || null;
  }
}
