import {PermEndpoint} from './perm-endpoint.model';
import {PermState} from './perm-state.model';
import {PermElement} from './perm-element.model';
import {PermReport} from './perm-report.model';

export class PermissionDetailed {

  public id: any = '';
  public name: string = '';
  public description: string = '';
  public functionalArea: string = '';
  public elementRefs: Array<PermElement> = [];
  public stateRefs: Array<PermState> = [];
  public endpointRefs: Array<PermEndpoint> = [];
  public reportRefs: Array<PermReport> = [];
  public updatedDate: Date = null;
  public updatedBy: string = '';

  constructor(obj?: PermissionDetailed) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.description = obj && obj.description || '';
    this.functionalArea = obj && obj.functionalArea || '';
    this.elementRefs = obj && obj.elementRefs || [];
    this.stateRefs = obj && obj.stateRefs || [];
    this.endpointRefs = obj && obj.endpointRefs || [];
    this.reportRefs = obj && obj.reportRefs || [];
    this.updatedDate = obj && obj.updatedDate || null;
    this.updatedBy = obj && obj.updatedBy || '';
  }
}
