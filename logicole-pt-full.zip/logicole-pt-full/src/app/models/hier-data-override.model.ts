import {OrganizationRef} from './organization-ref.model';

export class HierDataOverride {

  public id: string = '';
  public containingNodeRef: OrganizationRef;
  public overrideJson: string;

  constructor(obj?: HierDataOverride) {
    this.id = obj && obj.id || '';
    this.containingNodeRef = obj && obj.containingNodeRef || null;
    this.overrideJson = obj && obj.overrideJson || '';
  }
}
