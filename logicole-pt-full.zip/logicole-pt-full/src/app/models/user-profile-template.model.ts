import {RoleRef} from './role-ref.model';
import {OrganizationRef} from './organization-ref.model';
import {OrganizationTypeReference} from './organization-type-ref.model';

export class UserProfileTemplate {

  public profileExpirationDate: Date;
  public currentNodeRef: OrganizationRef = new OrganizationRef();
  public managedByNodeRef: OrganizationRef = new OrganizationRef();
  public nodeTypeRef: OrganizationTypeReference = new OrganizationTypeReference();
  public scopeNodeRefs: Array<OrganizationRef> = [];
  public roleRefs: Array<RoleRef> = [];
  public assignableRoleRefs: Array<RoleRef> = [];
  public isAllAssignableRoles: boolean = false;
  public managedByNodeRefName: string = '';
  public assignedPermissions: Array<any> = [];

  constructor() {
  }
}
