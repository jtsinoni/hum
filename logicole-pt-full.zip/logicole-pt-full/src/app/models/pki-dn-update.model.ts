export class PkiDnUpdate {

  public id: string;
  public requesterPkiDn;
  public expirationDate: Date;
  public sentDate: Date;

  constructor(obj?: PkiDnUpdate) {
    this.id = obj && obj.id || '';
    this.requesterPkiDn = obj && obj.requesterPkiDn;
    this.expirationDate = obj && obj.expirationDate;
    this.sentDate = obj && obj.sentDate;
  }
}
