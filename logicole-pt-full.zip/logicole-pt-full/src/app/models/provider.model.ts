import {ProviderRef} from './provider-ref.model';

export class Provider {
  public id: string;
  public name: string;
  public type: string;
  public parameters: Array<string>;
  public addContainerIdAsParameter: boolean;


  public static getRef(id: string, name: string, providerType: string, addContainerIdAsParameter: boolean) {
    const providerRef: ProviderRef = new ProviderRef();
    providerRef.id = id;
    providerRef.name = name;
    providerRef.type = providerType;
    providerRef.addContainerIdAsParameter = addContainerIdAsParameter;
    return providerRef;
  }
}
