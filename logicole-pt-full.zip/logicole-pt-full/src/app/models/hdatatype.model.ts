export class HDataType {

  public displayText: string = '';
  public value: string = '';

  constructor(obj?: HDataType) {
    this.displayText = obj && obj.displayText || '';
    this.value = obj && obj.displayText || '';
  }
}
