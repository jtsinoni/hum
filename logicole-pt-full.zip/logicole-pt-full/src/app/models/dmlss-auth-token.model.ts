export class DmlssAuthToken {
  public accessToken: string;
  public tokenType: string;
  public expiresIn: number;
}
