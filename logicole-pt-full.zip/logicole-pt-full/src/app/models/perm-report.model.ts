import {FeatureFlagRef} from './feature-flag-ref.model';

export class PermReport {

  public id: any = '';
  public name: string = '';
  public functionalArea: string = '';
  public cuid: string = '';
  public featureFlagRef: FeatureFlagRef = null;

  constructor(obj?: PermReport) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.functionalArea = obj && obj.functionalArea || '';
    this.cuid = obj && obj.cuid || '';
    this.featureFlagRef = obj && obj.featureFlagRef || null;
  }
}
