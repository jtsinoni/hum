export enum MessageBoxIcon {
    noIcon,
    informationIcon,
    warningIcon,
    errorIcon
}
