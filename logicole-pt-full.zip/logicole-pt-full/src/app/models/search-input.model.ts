import {SearchCriterion} from './search-criterion.model';

export class SearchInput {
  public searchText: string = '';
  public searchCriteria: SearchCriterion[] = [];
  public resultSetSize: number;
  public resultSetOffset: number;
  public logAggregationQuery: boolean = false;

  constructor(obj?: SearchInput) {
    this.searchText = obj && obj.searchText || '';
    this.searchCriteria = obj && obj.searchCriteria || [];
    this.resultSetSize = obj && obj.resultSetSize;
    this.resultSetSize = obj && obj.resultSetOffset;
    this.logAggregationQuery = obj && obj.logAggregationQuery || false;
  }
}
