import {FunctionalAreaRef} from './functional-area-ref.model';

export class RoleFunctionalAreaConfig {

  public id: any = '';
  public option: string = '';
  public displayName: string = '';
  public parentRef: FunctionalAreaRef;

  constructor(obj?: RoleFunctionalAreaConfig) {
    this.id = obj && obj.id || '';
    this.option = obj && obj.option || '';
    this.displayName = obj && obj.displayName || '';
    this.parentRef = obj && obj.parentRef || null;
  }
}
