import {SearchCategoryItemModel} from './search-category-item.model';

export class SearchCategoryModel<T> {
  public name: string;
  public dataType: string;
  public values: Array<SearchCategoryItemModel<T>>;

  constructor(obj?: SearchCategoryModel<T>) {
    this.name = obj && obj.name;
    this.dataType = obj && obj.dataType;
    this.values = obj && obj.values || [];
  }
}
