import {Invitation} from './invitation.model';
import {PkiDnUpdate} from './pki-dn-update.model';
import {RoleRef} from './role-ref.model';
import {OrganizationRef} from './organization-ref.model';
import {OrganizationTypeReference} from './organization-type-ref.model';
import {UserRequestRef} from '../home/access/user-request-management/models/user-request-ref.model';
import {ProfileUpdateReason} from './profile-update-reason';
import {DashboardConfiguration} from './dashboard-configuration/dashboard-configuration.model';

export class UserProfile {

  public id: any = null;
  public email: string = '';
  public lastLoginDate: Date;
  public previousLoginDate: Date;
  public lastLoginIP: string;
  public lastLoginDateFormatted: string;
  public previousLoginIP: string;
  public firstName: string = '';
  public lastName: string = '';
  public pkiDn: string = '';
  public phoneNumbers: Array<any> = [];
  public serviceCode: string = '';
  public profileName: string = '';
  public assignedPermissions: Array<any> = [];
  public reasonForAccess: string = '';
  public lockStartDate: Date;
  public lockEndDate: Date;
  public deleteReason: string = '';
  public invitation: Invitation;
  public isSystemProfile: boolean;
  public pkiDnUpdate: PkiDnUpdate;
  public updatedDate: Date;
  public updatedBy: string;
  public createdDate: Date;
  public createdBy: string;
  public _isDeleted: boolean;
  public deletedDate: Date;
  public userProfileStatus: string;
  public profileExpirationDate: Date;
  public profileExpirationDateFormatted: string;
  public currentNodeRef: OrganizationRef;
  public managedByNodeRef: OrganizationRef;
  public nodeTypeRef: OrganizationTypeReference;
  public scopeNodeRefs: Array<OrganizationRef> = [];
  public roleRefs: Array<RoleRef> = [];
  public assignableRoleRefs: Array<RoleRef> = [];
  public isAllAssignableRoles: boolean = false;
  public managedByNodeRefName: string = '';
  public userRequestRef: UserRequestRef;
  public businessIntelligenceId: string = null;
  public recentProfileUpdateReason: string = null;
  public profileUpdateReasons: Array<ProfileUpdateReason> = [];
  public dashboardConfiguration: DashboardConfiguration;
  public invitationExpired: string;

  // PT only
  public isSite: boolean = false;
  public isLogCustomer: boolean = false;
  public isNonLogCustomer: boolean = false;

  constructor() {
  }
}
