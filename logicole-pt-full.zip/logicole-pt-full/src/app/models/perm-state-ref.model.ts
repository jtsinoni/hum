export class PermStateRef {
  public id: any = '';
  public name: string = '';

  constructor(obj?: any) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
  }
}
