export class ProductDocument {
    public documentType: string = '';
    public documentName: string = '';
    public fileName: string = '';
    public documentURL: string = '';

    constructor();
    constructor(obj?: ProductDocument) {
        this.documentType = obj && obj.documentType || '';
        this.documentName = obj && obj.documentName || '';
        this.fileName = obj && obj.fileName || '';
        this.documentURL = obj && obj.documentURL || '';
    }
}
