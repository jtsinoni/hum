import {Configuration, ConfigurationGroup} from '@lc-app-models';

export class ConfigurationCollection {
  public title: string;
  public configurationGroupList: Array<ConfigurationGroup>;
  public fileConfigurationList: Array<Configuration>;
}
