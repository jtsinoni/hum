export class PermEndpoint {

  public id: any = '';
  public businessMethod: string = '';
  public logMessage = '';
  public userMessage = '';
  public functionalArea: string = '';
  public saveResultInHistory: boolean = false;
  public saveParamtersInHistory: boolean = true;

  constructor(obj?: PermEndpoint) {
    this.id = obj && obj.id || '';
    this.businessMethod = obj && obj.businessMethod || '';
    this.logMessage = obj && obj.logMessage || '';
    this.userMessage = obj && obj.userMessage || '';
    this.functionalArea = obj && obj.functionalArea || '';
    this.saveResultInHistory = obj && obj.saveResultInHistory || false;
    this.saveParamtersInHistory = obj && obj.saveParamtersInHistory || false;
  }
}
