export class MiscInfo {
  public stationIdentifier: string;
  public facilitiesEnterpriseRegion: string;

  constructor(obj?: MiscInfo) {
    this.stationIdentifier = obj && obj.stationIdentifier || '';
    this.facilitiesEnterpriseRegion = obj && obj.facilitiesEnterpriseRegion || '';
  }
}
