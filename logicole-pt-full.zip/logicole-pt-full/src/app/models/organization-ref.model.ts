import {mapOrgRefIdAndName} from '../home/real-property/common/real-property-utils';

export class OrganizationRef {
  public id: string = '';
  public name: string = '';
  public organizationIdentifier: string = '';
  public ancestry: string = '';
  public hashValue: number = 0;
  public label?: string;
  // UI Only
  public orgIdAndName = '';

  constructor(obj?: Partial<OrganizationRef>) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.organizationIdentifier = obj && obj.organizationIdentifier || '';
    this.ancestry = obj && obj.ancestry || '';
    this.hashValue = obj && obj.hashValue || 0;
    this.label = obj && obj.label || '';
    this.orgIdAndName = obj ? mapOrgRefIdAndName(<OrganizationRef>obj) : '';
  }
}
