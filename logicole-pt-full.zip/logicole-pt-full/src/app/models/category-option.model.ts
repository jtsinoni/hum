export class CategoryOption {

  public type: string = '';
  public optionValue: string = '';
  public isSelected: boolean = false;
  public level: number = 0;
  public indent: string = '';

  constructor(obj?: CategoryOption) {
    this.type = obj && obj.type || '';
    this.optionValue = obj && obj.optionValue || '';
    this.isSelected = obj && obj.isSelected || false;
    this.level = obj && obj.level || 0;
  }
}
