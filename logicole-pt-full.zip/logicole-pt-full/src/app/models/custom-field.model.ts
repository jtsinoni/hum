import {OrganizationRef} from './organization-ref.model';
import {CustomFieldType} from './custom-field-type.enum';

export class CustomField {
  public id: any;
  public label: string;
  public fieldType: CustomFieldType;
  public managedByNodeRef: OrganizationRef;
  public customizableTypeId: string;

  // PT only field
  public isMarkedForDelete: boolean = false;
  public userHasEditScope: boolean = false;
}
