export class PermEndpointRef {
  public id: any = '';
  public businessMethod: string = '';

  constructor(obj?: any) {
    this.id = obj && obj.id || '';
    this.businessMethod = obj && obj.businessMethod || '';
  }
}
