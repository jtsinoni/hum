import {FunctionalAreaRef} from './functional-area-ref.model';


export class CustomizableType {
  public id: any;
  public displayName: string;
  public functionalAreaRef: FunctionalAreaRef;
}
