export class NodeImportStatus {
  public uploadDate: Date;
  public importedBy: string;
  public nodeStatuses: Array<string> = [];
}
