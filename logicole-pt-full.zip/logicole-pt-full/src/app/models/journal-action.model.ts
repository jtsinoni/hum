export class JournalAction {
  public journalActionId: string;   // Not an _id, but a GUID
  public journalAction: string;
  public firstName: string;
  public lastName: string;
  public userId: string;
  public createdDate: Date;
  public modifiedDate: Date;
  public requiredDate: Date;
  public completedDate: Date;
  public isMarkedForDelete: boolean = false;
  public isMarkedForEditing: boolean = false;

  constructor(obj?: JournalAction) {
    this.journalActionId = obj && obj.journalActionId || '';
    this.journalAction = obj && obj.journalAction || '';
    this.firstName = obj && obj.firstName || '';
    this.lastName = obj && obj.lastName || '';
    this.userId = obj && obj.userId || '';
    this.createdDate = obj && obj.createdDate || null;
    this.modifiedDate = obj && obj.modifiedDate || null;
    this.requiredDate = obj && obj.requiredDate || null;
    this.completedDate = obj && obj.completedDate || null;
    this.isMarkedForDelete = obj && obj.isMarkedForDelete || false;
    this.isMarkedForEditing = obj && obj.isMarkedForEditing || false;
  }
}
