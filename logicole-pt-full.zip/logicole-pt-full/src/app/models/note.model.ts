export class Note {
  public id: string;
  public noteId: string;  // Not an _id, but a GUID
  public noteText: string;
  public section: string;
  public firstName: string;
  public lastName: string;
  public userId: string;
  public dateCreated: Date;
  public dateModified: Date;
  public isMarkedForDelete: boolean = false;

  constructor(obj?: Note) {
    this.id = obj && obj.id || '';
    this.noteId = obj && obj.noteId || '';
    this.noteText = obj && obj.noteText || '';
    this.section = obj && obj.section || '';
    this.firstName = obj && obj.firstName || '';
    this.lastName = obj && obj.lastName || '';
    this.userId = obj && obj.userId || '';
    this.dateCreated = obj && obj.dateCreated || null;
    this.dateModified = obj && obj.dateModified || null;
    this.isMarkedForDelete = obj && obj.isMarkedForDelete || false;
  }
}
