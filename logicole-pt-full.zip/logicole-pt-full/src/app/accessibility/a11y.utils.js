"use strict";
exports.__esModule = true;
var axe_1 = require("./axe");
function prettyPrintA11Y(violations) {
    var data = [];
    var lineControl = '\r\n\t';
    if (violations.length > 0) {
        for (var _i = 0, violations_1 = violations; _i < violations_1.length; _i++) {
            var violation = violations_1[_i];
            data.push(lineControl + "ID: " + violation.id);
            data.push(lineControl + "Description: " + violation.description);
            data.push(lineControl + "Impact: " + violation.impact);
            data.push(lineControl + "Help: " + violation.help);
            data.push(lineControl + "Help URL: " + violation.helpUrl);
            if (violation.nodes.length > 0) {
                for (var _a = 0, _b = violation.nodes; _a < _b.length; _a++) {
                    var node = _b[_a];
                    data.push(lineControl + "\t" + node.html);
                }
            }
            data.push(lineControl);
        }
        data.push(lineControl);
    }
    return data.join('');
}
exports.prettyPrintA11Y = prettyPrintA11Y;
// export function a11yTests(context: any) {
//   axe.run(context, (err, result) => {
//     expect(err).toBe(null);
//     expect(result.violations.length).toBe(0, `${prettyPrintA11Y(result.violations)}`);
//   });
// }
function a11yTests(context, options) {
    if (options) {
        return axe_1.axe.run(context, options);
    }
    else {
        return axe_1.axe.run(context);
    }
}
exports.a11yTests = a11yTests;
