import { axe } from './axe';
import {AxeResults, RunOptions} from 'axe-core';

export function prettyPrintA11Y(violations: Array<any>): string {
  const data: Array<string> = [];
  const lineControl: string = '\r\n\t';

  if (violations.length > 0) {
    for (const violation of violations) {
      data.push(`${lineControl}ID: ${violation.id}`);
      data.push(`${lineControl}Description: ${violation.description}`);
      data.push(`${lineControl}Impact: ${violation.impact}`);
      data.push(`${lineControl}Help: ${violation.help}`);
      data.push(`${lineControl}Help URL: ${violation.helpUrl}`);
      if (violation.nodes.length > 0 ) {
        for (const node of violation.nodes) {
          data.push(`${lineControl}\t${node.html}`);
        }
      }
      data.push(lineControl);
    }
    data.push(lineControl);
  }
  return data.join('');
}

// export function a11yTests(context: any) {
//   axe.run(context, (err, result) => {
//     expect(err).toBe(null);
//     expect(result.violations.length).toBe(0, `${prettyPrintA11Y(result.violations)}`);
//   });
// }

export function a11yTests(context: any, options?: RunOptions): Promise<AxeResults> {
  if (options) {
    return axe.run(context, options);
  } else {
    return axe.run(context);
  }
}
