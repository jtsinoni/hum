"use strict";
exports.__esModule = true;
var axe = require("axe-core");
exports.axe = axe;
