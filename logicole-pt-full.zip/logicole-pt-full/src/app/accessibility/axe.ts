import * as axe from 'axe-core';
export { axe };
