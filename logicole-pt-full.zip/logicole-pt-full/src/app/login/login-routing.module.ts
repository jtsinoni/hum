import { NgModule } from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {LoginStates} from './login-states';
import {RouteConstants} from '@lc-constants/*';

const loginRoutes: RootModule = {
  states: [
    LoginStates.LOGIN_ROOT,
    LoginStates.LOGIN,
    LoginStates.CHOOSE_PROFILE,
    LoginStates.SINGLE_SIGN_ON,
    LoginStates.REQUEST_PKI_DN_UPDATE,
    LoginStates.UPDATE_PKI_DN,
    LoginStates.ACCESSIBILITY,
    LoginStates.USER_AGREEMENT,
    LoginStates.INVITATION,
    LoginStates.GROUP_INVITATION,
    LoginStates.INVITATION_INFO,
    LoginStates.USER_REQUEST_CANDIDATE_PORTAL,
    LoginStates.USER_REQUEST_INFO
  ],
  useHash: false,
  otherwise: RouteConstants.LOGIN.url,
};

@NgModule({
  imports: [UIRouterModule.forChild(loginRoutes)],
  exports: [UIRouterModule],
})
export class LoginRoutingModule { }
