import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {LoginShellComponent} from './login-shell.component';
import {LoginComponent} from './views/login/login.component';
import {ChooseProfileComponent} from './views/choose-profile/choose-profile.component';
import {RequestPkiDnUpdateComponent} from './views/request-pki-dn-update/request-pki-dn-update.component';
import {UpdatePkiDnComponent} from './views/update-pki-dn/update-pki-dn.component';
import {AccessibilityComponent} from './views/accessibility/accessibility.component';
import {UserAgreementComponent} from './views/user-agreement/user-agreement.component';
import {InvitationComponent} from './views/invitation/invitation.component';
import {GroupInvitationComponent} from './views/group-invitation/group-invitation.component';
import {InvitationInfoComponent} from './views/invitation-info/invitation-info.component';
import {UserRequestCandidatePortalComponent} from './views/user-request-candidate-portal/user-request-candidate-portal.component';
import {UserRequestInfoComponent} from './views/user-request-info/user-request-info.component';
import {SingleSignOnComponent} from './views/single-sign-on/single-sign-on.component';

export class LoginStates {

  public static LOGIN_ROOT: Ng2StateDeclaration = {
    url: RouteConstants.LOGIN_ROOT.url,
    name: RouteConstants.LOGIN_ROOT.name,
    component: LoginShellComponent
  };

  public static LOGIN: Ng2StateDeclaration = {
    url: RouteConstants.LOGIN.url,
    name: RouteConstants.LOGIN.name,
    component: LoginComponent
  };

  public static CHOOSE_PROFILE: Ng2StateDeclaration = {
    url: RouteConstants.CHOOSE_PROFILE.url,
    name: RouteConstants.CHOOSE_PROFILE.name,
    component: ChooseProfileComponent
  };

  public static SINGLE_SIGN_ON: Ng2StateDeclaration = {
    url: RouteConstants.SINGLE_SIGN_ON.url,
    name: RouteConstants.SINGLE_SIGN_ON.name,
    component: SingleSignOnComponent,
    params: {
      'jmarUser': false,
      'tewlsUser': false
    }
  };

  public static REQUEST_PKI_DN_UPDATE: Ng2StateDeclaration = {
    url: RouteConstants.REQUEST_PKI_DN_UPDATE.url,
    name: RouteConstants.REQUEST_PKI_DN_UPDATE.name,
    component: RequestPkiDnUpdateComponent
  };

  public static UPDATE_PKI_DN: Ng2StateDeclaration = {
    url: RouteConstants.UPDATE_PKI_DN.url,
    name: RouteConstants.UPDATE_PKI_DN.name,
    component: UpdatePkiDnComponent
  };

  public static ACCESSIBILITY: Ng2StateDeclaration = {
    url: RouteConstants.ACCESSIBILITY.url,
    name: RouteConstants.ACCESSIBILITY.name,
    component: AccessibilityComponent
  };

  public static USER_AGREEMENT: Ng2StateDeclaration = {
    url: RouteConstants.USER_AGREEMENT.url,
    name: RouteConstants.USER_AGREEMENT.name,
    component: UserAgreementComponent
  };
  public static INVITATION: Ng2StateDeclaration = {
    url: RouteConstants.INVITATION.url,
    name: RouteConstants.INVITATION.name,
    component: InvitationComponent
  };

  public static GROUP_INVITATION: Ng2StateDeclaration = {
    url: RouteConstants.GROUP_INVITATION.url,
    name: RouteConstants.GROUP_INVITATION.name,
    component: GroupInvitationComponent
  };

  public static INVITATION_INFO: Ng2StateDeclaration = {
    url: RouteConstants.INVITATION_INFO.url,
    name: RouteConstants.INVITATION_INFO.name,
    component: InvitationInfoComponent
  };
  public static USER_REQUEST_CANDIDATE_PORTAL: Ng2StateDeclaration = {
    url: RouteConstants.USER_REQUEST_CANDIDATE_PORTAL.url,
    name: RouteConstants.USER_REQUEST_CANDIDATE_PORTAL.name,
    component: UserRequestCandidatePortalComponent
  };
  public static USER_REQUEST_INFO: Ng2StateDeclaration = {
    url: RouteConstants.USER_REQUEST_INFO.url,
    name: RouteConstants.USER_REQUEST_INFO.name,
    component: UserRequestInfoComponent
  };
}

/*
export let LOGIN_STATES: Ng2StateDeclaration[] = [
  // A state for the 'lc.foo' submodule,
  // It fills the <ui-view> from the 'app' state with FooComponent
  { name: 'lc.login', url: '/login', component: LoginComponent },

  // A child state of lc.foo; it fills the <ui-view> in lc.foo with Nest1Component
  { name: 'lc.login.accessibility', url: '/accessibility', component: AccessibilityComponent },

  // A child state of lc.foo; it fills the <ui-view> in lc.foo with Nest2Component
  { name: 'lc.login.updatePkiDN', url: '/updatePkiDN', component: UpdatePkiDnComponent },

  // A child state of lc.foo.bar; it fills the <ui-view> in lc.foo with Nest3Component
  { name: 'lc.login.updatePkiDN.requestPkiDnUpdate', url: '/requestPkiDnUpdate', component: RequestPkiDnUpdateComponent },

  // A child state of lc.foo; it fills the <ui-view> in lc.foo with Nest2Component
  { name: 'lc.login.chooseProfile', url: '/chooseProfile', component: ChooseProfileComponent },

  // It fills the <ui-view> from the 'app' state with FooComponent
  { name: 'lc.invitation', url: '/invitation', component: InvitationComponent },

  // It fills the <ui-view> from the 'app' state with FooComponent
  { name: 'lc.groupInvitation', url: '/groupInvitation', component: InvitationComponent },
];
*/

