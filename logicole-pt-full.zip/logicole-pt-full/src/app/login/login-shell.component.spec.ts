import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {LoginShellComponent} from './login-shell.component';
import {UIRouterModule} from '@uirouter/angular';
import {APP_BASE_HREF} from '@angular/common';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {LoggerService} from '@lc-services/*';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';

describe('LoginShellComponent', () => {
  let component: LoginShellComponent;
  let fixture: ComponentFixture<LoginShellComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [UIRouterModule.forRoot()],
      declarations: [LoginShellComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{provide: APP_BASE_HREF, useValue: '/'}, LoggerService]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginShellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have no a11y violations', waitForAsync(() => {
    a11yTests(fixture.nativeElement)
      .then((results) => {
        expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
      })
      .catch((error) => {
        loggerService.error(`${error}`);
      });
  }));
});
