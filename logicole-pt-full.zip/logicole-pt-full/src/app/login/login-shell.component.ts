import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-login-shell',
  templateUrl: './login-shell.component.html'
})
export class LoginShellComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
