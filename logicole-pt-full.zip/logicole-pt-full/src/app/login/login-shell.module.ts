import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LoginShellComponent} from './login-shell.component';
import {LoginRoutingModule} from './login-routing.module';
import {CommonComponentsModule} from '@lc-common-components';
import {PipesModule} from '../pipes/pipes.module';
import {FormsModule} from '@angular/forms';
import {AccessModule} from '../home/access/access.module';
import {InvitationApiService} from '../home/access/profile-management/services/invitation-api.service';
import {OrganizationApiService} from '../home/organization/services/organization-api.service';
import {AccessibilityComponent} from './views/accessibility/accessibility.component';
import {ChooseProfileComponent} from './views/choose-profile/choose-profile.component';
import {LoginComponent} from './views/login/login.component';
import {SecurityCardComponent} from './components/security-card/security-card.component';
import {RequestPkiDnUpdateComponent} from './views/request-pki-dn-update/request-pki-dn-update.component';
import {InvitationComponent} from './views/invitation/invitation.component';
import {UpdatePkiDnComponent} from './views/update-pki-dn/update-pki-dn.component';
import {GroupInvitationComponent} from './views/group-invitation/group-invitation.component';
import {InvitationInfoComponent} from './views/invitation-info/invitation-info.component';
import {UserAgreementComponent} from './views/user-agreement/user-agreement.component';
import { UserRequestCandidatePortalComponent } from './views/user-request-candidate-portal/user-request-candidate-portal.component';
import { UserRequestInfoComponent } from './views/user-request-info/user-request-info.component';
import { LoginFooterComponent } from './views/login-footer/login-footer.component';
import {SingleSignOnComponent} from './views/single-sign-on/single-sign-on.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule.forRoot(),
    PipesModule.forRoot(),
    LoginRoutingModule,
    AccessModule
  ],
  declarations: [
    LoginShellComponent,
    AccessibilityComponent,
    UserAgreementComponent,
    ChooseProfileComponent,
    LoginComponent,
    SecurityCardComponent,
    UpdatePkiDnComponent,
    RequestPkiDnUpdateComponent,
    InvitationComponent,
    GroupInvitationComponent,
    InvitationInfoComponent,
    UserRequestCandidatePortalComponent,
    UserRequestInfoComponent,
    LoginFooterComponent,
    SingleSignOnComponent
  ],
  exports: [
    LoginShellComponent
  ],
  providers: [
    InvitationApiService,
    OrganizationApiService
  ]
})
export class LoginShellModule {
}
