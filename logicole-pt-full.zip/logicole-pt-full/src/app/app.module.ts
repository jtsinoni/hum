import {BrowserModule} from '@angular/platform-browser';
import {APP_INITIALIZER, Injector, NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import {AppComponent} from './app.component';
import {setAppInjector} from './app.injector';
import {AppRouterModule} from './app-router.module';
import {ServicesModule} from './services/services.module';
import {CommonComponentsModule} from '@lc-common-components';
import {PipesModule} from './pipes/pipes.module';
import {BrowserAnimationsModule, NoopAnimationsModule} from '@angular/platform-browser/animations';
import {ToastrModule} from 'ngx-toastr';
import {DirectivesModule} from './directives/directives.module';
import {LoginShellModule} from './login/login-shell.module';
import {AppConfigService} from './services/app-config.service';

export function initializeApp(appConfig: AppConfigService) {
  return () => appConfig.load();
}

@NgModule({
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRouterModule,
    FormsModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    ServicesModule.forRoot(),
    CommonComponentsModule.forRoot(),
    PipesModule.forRoot(),
    DirectivesModule,
    LoginShellModule,
    ToastrModule.forRoot({
      closeButton: true,
      maxOpened: 5,
      preventDuplicates: true,
      progressAnimation: 'increasing',
      progressBar: true,
      timeOut: 10000
    })
  ],
  declarations: [
    AppComponent
  ],
  exports: [
    BrowserAnimationsModule,
    NoopAnimationsModule,
    ToastrModule,
    DirectivesModule,
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: initializeApp,
      deps: [AppConfigService],
      multi: true
    }
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor(injector: Injector) {
    setAppInjector(injector);
  }
}
