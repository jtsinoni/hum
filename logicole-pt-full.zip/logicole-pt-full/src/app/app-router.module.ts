import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {uiRouterConfigFn} from './router-config';
import {RouteConstants} from '@lc-constants/*';
import {LoginStates} from './login/login-states';
import {HomeStates} from './home/home-states';

export const appRoutes: RootModule = {
  states: [
    {
      name: LoginStates.LOGIN_ROOT.name + '.**',
      url: LoginStates.LOGIN_ROOT.url,
      loadChildren: () => import('app/login/login-shell.module').then(m => m.LoginShellModule)
    }
    ,
    {
      name: HomeStates.HOME_ROOT.name + '.**',
      url: HomeStates.HOME_ROOT.url,
      loadChildren: () => import('app/home/home.module').then(m => m.HomeModule)
    }
  ],
  config: uiRouterConfigFn,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
imports: [UIRouterModule.forRoot(appRoutes)],
exports: [UIRouterModule]
})
export class AppRouterModule {

}
