import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-real-property',
  templateUrl: './real-property.component.html'
})
export class RealPropertyComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
