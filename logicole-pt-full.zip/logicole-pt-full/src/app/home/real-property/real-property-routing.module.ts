import {RootModule, UIRouterModule} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {RealPropertyStates} from './real-property-states';
import {NgModule} from '@angular/core';

const realPropertyRoutes: RootModule = {
  states: RealPropertyStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(realPropertyRoutes)],
  exports: [UIRouterModule],
})
export class RealPropertyRoutingModule {
}
