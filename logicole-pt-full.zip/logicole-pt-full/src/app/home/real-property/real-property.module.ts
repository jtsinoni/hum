import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {CommonModule, DatePipe, DecimalPipe} from '@angular/common';
import {CommonComponentsModule} from '@lc-common-components';
import {DirectivesModule} from '../../directives/directives.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {PaginationModule} from 'ngx-bootstrap/pagination';
import {TooltipModule} from 'ngx-bootstrap/tooltip';
import {PipesModule} from '../../pipes/pipes.module';
import {RealPropertyRoutingModule} from './real-property-routing.module';
import {AuthoritativeDataManagerComponent} from './authoritative-data-manager/authoritative-data-manager.component';
import {RealPropertyComponent} from './real-property.component';
import {RealPropertyComponentsModule} from './components/real-property-components.module';
import {DrawingSpaceFillComponent} from './drawing-space-fill/drawing-space-fill.component';
import {FacilityManagementComponent} from './facility/views/facility-management/facility-management.component';
import {FacilityManagementFilterPipe} from './facility/views/facility-management/pipes/facility-management-filter.pipe';
import {FacilityDetailsComponent} from './facility/views/facility-details/facility-details.component';
import {FacilityAddressComponent} from './facility/components/facility-address/facility-address.component';
import {FacilityAttachmentsComponent} from './facility/components/facility-attachments/facility-attachments.component';
import {FacilityCoreComponent} from './facility/components/facility-core/facility-core.component';
import {FacilityFinancialComponent} from './facility/components/facility-financial/facility-financial.component';
import {FacilityNotesComponent} from './facility/components/facility-notes/facility-notes.component';
import {FacilityReviewComponent} from './facility/components/facility-review/facility-review.component';
import {FacilitySpaceComponent} from './facility/components/facility-space/facility-space.component';
import {FacilityRelatedRecordsComponent} from './facility/components/facility-related-records/facility-related-records.component';
import {FacilityCapitalImprovementProjectsComponent} from './facility/components/facility-related-records/facility-capital-improvement-projects/facility-capital-improvement-projects.component';
import {FacilityAdditionalComponent} from './facility/components/facility-core/facility-additional/facility-additional.component';
import {FacilityClassificationComponent} from './facility/components/facility-core/facility-classification/facility-classification.component';
import {FacilityMeasurementComponent} from './facility/components/facility-core/facility-measurement/facility-measurement.component';
import {FacilityOccupancyComponent} from './facility/components/facility-core/facility-occupancy/facility-occupancy.component';
import {FacilityStructuralComponent} from './facility/components/facility-core/facility-structural/facility-structural.component';
import {FacilityAcquisitionComponent} from './facility/components/facility-financial/facility-acquisition/facility-acquisition.component';
import {FacilityFundingComponent} from './facility/components/facility-financial/facility-funding/facility-funding.component';
import {FacilityPermitsComponent} from './facility/components/facility-review/facility-permits/facility-permits.component';
import {FacilityStatementOfConditionsComponent} from './facility/components/facility-review/facility-statement-of-conditions/facility-statement-of-conditions.component';
import {FacilityAssetReviewsComponent} from './facility/components/facility-review/facility-asset-reviews/facility-asset-reviews.component';
import {FacilityAllocationsComponent} from './facility/components/facility-space/facility-allocations/facility-allocations.component';
import {FacilityConfigurationsComponent} from './facility/components/facility-space/facility-configurations/facility-configurations.component';
import {FacilityFunctionsComponent} from './facility/components/facility-space/facility-functions/facility-functions.component';
import {FacilityAuditComponent} from './facility/components/facility-review/facility-audit/facility-audit.component';
import {NewFacilityComponent} from './facility/views/new-facility/new-facility.component';
import {InstallationsManagementComponent} from './installations-and-sites/views/installations-management.component';
import {InstallationManagementComponent} from './installations-and-sites/views/installation-management/installation-management.component';
import {LcInstallationDetailsComponent} from './installations-and-sites/components/installation-details/lc-installation-details.component';
import {SiteManagementComponent} from './installations-and-sites/views/site-management/site-management.component';
import {SitesManagementComponent} from './installations-and-sites/views/sites-management.component';
import {NewInstallationComponent} from './installations-and-sites/views/new-installation/new-installation.component';
import {NewSiteComponent} from './installations-and-sites/views/new-site/new-site.component';
import {FacilityLeaseComponent} from './facility/components/facility-lease/facility-lease.component';
import {LcSiteDetailsComponent} from './installations-and-sites/components/site-details/lc-site-details.component';
import {FacilityFloorsViewFloorplansComponent} from './facility/components/facility-floors/facility-floors-view-floorplans/facility-floors-view-floorplans.component';
import {FacilityFloorsDetailsTableComponent} from './facility/components/facility-floors/facility-floors-details-table/facility-floors-details-table.component';
import {FacilityFloorsComponent} from './facility/components/facility-floors/facility-floors.component';
import {FacilityFloorHeaderComponent} from './facility/components/facility-floors/facility-floor-header/facility-floor-header.component';
import {FacilityZonesComponent} from './facility/components/facility-zones/facility-zones.component';
import {FacilityZonesEditDetailsComponent} from './facility/components/facility-zones/facility-zones-edit-details/facility-zones-edit-details.component';
import {FacilityRoomsComponent} from './facility/components/facility-related-records/facility-rooms/facility-rooms.component';
import {FacilityBulkUpdateConfirmComponent} from './facility/components/facility-bulk-update/facility-bulk-update-confirm/facility-bulk-update-confirm.component';
import {FacilityBulkUpdateResultsComponent} from './facility/components/facility-bulk-update/facility-bulk-update-results/facility-bulk-update-results.component';
import {FacilityConditionComponent} from './facility/components/facility-core/facility-condition/facility-condition.component';
import {FacilityCOBieImportComponent} from './facility/components/facility-cobie-import/facility-cobie-import.component';
import {FacilityContactsComponent} from './facility/components/facility-contacts/facility-contacts.component';
import {FacilityReportsComponent} from './facility/views/facility-reports/facility-reports.component';
import { FacilityAttributesComponent } from './facility/components/facility-review/facility-attributes/facility-attributes.component';
import {RealPropertyBase} from './common/real-property.base';

@NgModule({
  imports: [
    CommonModule,
    CommonComponentsModule.forRoot(),
    DirectivesModule,
    FormsModule,
    PaginationModule.forRoot(),
    PipesModule.forRoot(),
    TooltipModule.forRoot(),
    RealPropertyRoutingModule,
    ReactiveFormsModule,
    RealPropertyComponentsModule
  ],
  declarations: [
    RealPropertyBase,
    RealPropertyComponent,
    AuthoritativeDataManagerComponent,
    InstallationsManagementComponent,
    InstallationManagementComponent,
    LcInstallationDetailsComponent,
    SiteManagementComponent,
    LcSiteDetailsComponent,
    FacilityManagementComponent,
    FacilityManagementFilterPipe,
    FacilityDetailsComponent,
    FacilityAddressComponent,
    FacilityAttachmentsComponent,
    FacilityBulkUpdateConfirmComponent,
    FacilityBulkUpdateResultsComponent,
    FacilityCOBieImportComponent,
    FacilityCoreComponent,
    FacilityFinancialComponent,
    FacilityNotesComponent,
    FacilityReviewComponent,
    FacilitySpaceComponent,
    FacilityRelatedRecordsComponent,
    FacilityCapitalImprovementProjectsComponent,
    FacilityRoomsComponent,
    FacilityAdditionalComponent,
    FacilityClassificationComponent,
    FacilityMeasurementComponent,
    FacilityOccupancyComponent,
    FacilityStructuralComponent,
    FacilityAcquisitionComponent,
    FacilityFundingComponent,
    FacilityPermitsComponent,
    FacilityStatementOfConditionsComponent,
    FacilityAssetReviewsComponent,
    FacilityAllocationsComponent,
    FacilityConfigurationsComponent,
    FacilityFunctionsComponent,
    FacilityAuditComponent,
    NewInstallationComponent,
    SitesManagementComponent,
    NewSiteComponent,
    NewFacilityComponent,
    FacilityLeaseComponent,
    DrawingSpaceFillComponent,
    FacilityFloorHeaderComponent,
    FacilityFloorsComponent,
    FacilityFloorsDetailsTableComponent,
    FacilityFloorsViewFloorplansComponent,
    FacilityZonesComponent,
    FacilityZonesEditDetailsComponent,
    FacilityConditionComponent,
    FacilityContactsComponent,
    FacilityReportsComponent,
    FacilityAttributesComponent
  ],
  providers: [
    DatePipe,
    DecimalPipe,
  ],
  entryComponents: [
    RealPropertyComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class RealPropertyModule {
}
