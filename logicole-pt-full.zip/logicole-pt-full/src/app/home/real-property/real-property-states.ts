import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {AuthoritativeDataManagerComponent} from './authoritative-data-manager/authoritative-data-manager.component';
import {RealPropertyComponent} from './real-property.component';
import {DrawingSpaceFillComponent} from './drawing-space-fill/drawing-space-fill.component';
import {FacilityManagementComponent} from './facility/views/facility-management/facility-management.component';
import {FacilityDetailsComponent} from './facility/views/facility-details/facility-details.component';
import {NewFacilityComponent} from './facility/views/new-facility/new-facility.component';
import {InstallationsManagementComponent} from './installations-and-sites/views/installations-management.component';
import {InstallationManagementComponent} from './installations-and-sites/views/installation-management/installation-management.component';
import {NewInstallationComponent} from './installations-and-sites/views/new-installation/new-installation.component';
import {SitesManagementComponent} from './installations-and-sites/views/sites-management.component';
import {SiteManagementComponent} from './installations-and-sites/views/site-management/site-management.component';
import {NewSiteComponent} from './installations-and-sites/views/new-site/new-site.component';
import {FacilityBulkUpdateConfirmComponent} from './facility/components/facility-bulk-update/facility-bulk-update-confirm/facility-bulk-update-confirm.component';
import {FacilityBulkUpdateResultsComponent} from './facility/components/facility-bulk-update/facility-bulk-update-results/facility-bulk-update-results.component';
import {FacilityCOBieImportComponent} from './facility/components/facility-cobie-import/facility-cobie-import.component';
import {FacilityReportsComponent} from './facility/views/facility-reports/facility-reports.component';

export const REAL_PROPERTY_ROOT: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_ROOT.url,
  name: RouteConstants.REAL_PROPERTY_ROOT.name,
  component: RealPropertyComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_ROOT}
};

export const REAL_PROPERTY_DRAWING_SPACE_FILL: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_DRAWING_SPACE_FILL.url,
  name: RouteConstants.REAL_PROPERTY_DRAWING_SPACE_FILL.name,
  component: DrawingSpaceFillComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_DRAWING_SPACE_FILL}
};

export const DATA_MANAGER: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_DATA_MANAGER.url,
  name: RouteConstants.REAL_PROPERTY_DATA_MANAGER.name,
  component: AuthoritativeDataManagerComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_DATA_MANAGER}
};

export const REAL_PROPERTY_INSTALLATIONS: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_INSTALLATIONS.url,
  name: RouteConstants.REAL_PROPERTY_INSTALLATIONS.name,
  component: InstallationsManagementComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_INSTALLATIONS}
};
export const REAL_PROPERTY_INSTALLATION_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_INSTALLATION_MANAGEMENT.url,
  name: RouteConstants.REAL_PROPERTY_INSTALLATION_MANAGEMENT.name,
  component: InstallationManagementComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_INSTALLATION_MANAGEMENT}
};
export const REAL_PROPERTY_NEW_INSTALLATION: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_NEW_INSTALLATION.url,
  name: RouteConstants.REAL_PROPERTY_NEW_INSTALLATION.name,
  component: NewInstallationComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_NEW_INSTALLATION}
};

export const REAL_PROPERTY_SITES: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_SITES.url,
  name: RouteConstants.REAL_PROPERTY_SITES.name,
  component: SitesManagementComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_SITES}
};
export const REAL_PROPERTY_SITE_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_SITE_MANAGEMENT.url,
  name: RouteConstants.REAL_PROPERTY_SITE_MANAGEMENT.name,
  component: SiteManagementComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_SITE_MANAGEMENT}
};
export const REAL_PROPERTY_NEW_SITE: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_NEW_SITE.url,
  name: RouteConstants.REAL_PROPERTY_NEW_SITE.name,
  component: NewSiteComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_NEW_SITE}
};

export const REAL_PROPERTY_FACILITY_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_FACILITY_MANAGEMENT.url,
  name: RouteConstants.REAL_PROPERTY_FACILITY_MANAGEMENT.name,
  component: FacilityManagementComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_FACILITY_MANAGEMENT}
};

export const REAL_PROPERTY_FACILITY_REPORTS: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_FACILITY_REPORTS.url,
  name: RouteConstants.REAL_PROPERTY_FACILITY_REPORTS.name,
  component: FacilityReportsComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_FACILITY_REPORTS},
  params: {
    'reportSelection': null
  }
};

export const REAL_PROPERTY_FACILITY_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_FACILITY_VIEW.url,
  name: RouteConstants.REAL_PROPERTY_FACILITY_VIEW.name,
  component: FacilityDetailsComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_FACILITY_VIEW},
  params: {
    'searchFacilityId': null,
    'searchFloorId': null,
    'searchShowFloorTab': null
  }
};
export const REAL_PROPERTY_NEW_FACILITY: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_NEW_FACILITY.url,
  name: RouteConstants.REAL_PROPERTY_NEW_FACILITY.name,
  component: NewFacilityComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_NEW_FACILITY}
};
export const REAL_PROPERTY_FACILITY_BULK_UPDATE_CONFIRM: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_FACILITY_BULK_UPDATE_CONFIRM.url,
  name: RouteConstants.REAL_PROPERTY_FACILITY_BULK_UPDATE_CONFIRM.name,
  component: FacilityBulkUpdateConfirmComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_FACILITY_BULK_UPDATE_CONFIRM}
};
export const REAL_PROPERTY_FACILITY_BULK_UPDATE_RESULTS: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_FACILITY_BULK_UPDATE_RESULTS.url,
  name: RouteConstants.REAL_PROPERTY_FACILITY_BULK_UPDATE_RESULTS.name,
  component: FacilityBulkUpdateResultsComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_FACILITY_BULK_UPDATE_RESULTS}
};
export const REAL_PROPERTY_FACILITY_COBIE_IMPORT: Ng2StateDeclaration = {
  url: RouteConstants.REAL_PROPERTY_FACILITY_COBIE_IMPORT.url,
  name: RouteConstants.REAL_PROPERTY_FACILITY_COBIE_IMPORT.name,
  component: FacilityCOBieImportComponent,
  data: {'route': RouteConstants.REAL_PROPERTY_FACILITY_COBIE_IMPORT}
};

export const RealPropertyStates = [
  REAL_PROPERTY_ROOT,
  REAL_PROPERTY_DRAWING_SPACE_FILL,
  DATA_MANAGER,
  REAL_PROPERTY_INSTALLATIONS,
  REAL_PROPERTY_INSTALLATION_MANAGEMENT,
  REAL_PROPERTY_NEW_INSTALLATION,
  REAL_PROPERTY_SITES,
  REAL_PROPERTY_SITE_MANAGEMENT,
  REAL_PROPERTY_NEW_SITE,
  REAL_PROPERTY_FACILITY_MANAGEMENT,
  REAL_PROPERTY_FACILITY_REPORTS,
  REAL_PROPERTY_FACILITY_VIEW,
  REAL_PROPERTY_NEW_FACILITY,
  REAL_PROPERTY_FACILITY_BULK_UPDATE_CONFIRM,
  REAL_PROPERTY_FACILITY_BULK_UPDATE_RESULTS,
  REAL_PROPERTY_FACILITY_COBIE_IMPORT
];
