import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {RealPropertyComponent} from './real-property.component';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {a11yTests, prettyPrintA11Y} from '../../accessibility';
import {LoggerService} from '@lc-logger-service';
import {FormsModule} from '@angular/forms';

describe('RealPropertyComponent', () => {
  let component: RealPropertyComponent;
  let fixture: ComponentFixture<RealPropertyComponent>;
  let logger: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ RealPropertyComponent ],
      providers: [ LoggerService ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });

    logger = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RealPropertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      a11yTests(fixture.nativeElement)
        .then((results) => {
          expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
        })
        .catch((error) => {
          logger.error(`${error}`);
        });
    }));
  });
});
