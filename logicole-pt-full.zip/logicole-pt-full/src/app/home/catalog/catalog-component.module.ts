import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CommonComponentsModule} from '@lc-common-components';
import {PipesModule} from '../../pipes/pipes.module';
import {FormsModule} from '@angular/forms';
import {DirectivesModule} from '../../directives/directives.module';
import {InvOwnersModule} from '../inventory/inv-owners/inv-owners.module';
import {AbiManagementModule} from '../jmlfdc-admin/abi-management/abi-management.module';
import {ItemSearchComponent} from './item-management/item-search.component';
import {ItemDetailsComponent} from './item-management/views/item-details/item-details.component';
import {CatalogSearchComponent} from './catalog-management/catalog-search.component';
import {CatalogReferenceDataComponent} from './reference-data/catalog-reference-data.component';
import {BuyerAccountService} from '../organization/organization-role-services-management/buyer/buyer-details/buyer-accounts/services/buyer-account.service';
import {ItemSecondaryAbiSearchService} from './catalog-management/services/item-secondary-abi-search.service';
import {UIRouterModule} from '@uirouter/angular';
import {FulfillmentComponentModule} from '../fulfillment/fulfillment-component.module';
import {NonCatalogSearchComponent} from './catalog-management/views/non-catalog-search/non-catalog-search.component';
import {CommonCatalogModule} from './common/common-catalog.module';
import {EnterpriseProductIdentifierTypeDetailComponent} from './reference-data/components/enterprise-product-identifier-type/enterprise-product-identifier-type-detail/enterprise-product-identifier-type-detail.component';
import {EnterpriseProductIdentifierTypeComponent} from './reference-data/components/enterprise-product-identifier-type/enterprise-product-identifier-type.component';
import {CriticalItemCategoryDetailComponent} from './reference-data/components/critical-item-category/critical-item-category-detail/critical-item-category-detail.component';
import {CriticalItemCategoryComponent} from './reference-data/components/critical-item-category/critical-item-category.component';
import {HcpcsImplantDetailComponent} from './reference-data/components/hcpcs-implant/hcpcs-implant-detail/hcpcs-implant-detail.component';
import {HcpcsImplantComponent} from './reference-data/components/hcpcs-implant/hcpcs-implant.component';
import {UnspscCriticalItemCategoryMapDetailComponent} from './reference-data/components/ucicm/ucicm-detail/unspsc-critical-item-category-map-detail.component';
import {UnspscCriticalItemCategoryMapComponent} from './reference-data/components/ucicm/unspsc-critical-item-category-map.component';
import {ItemDetailsHeaderComponent} from './common/components/cards/item-details-header/item-details-header.component';

import {AttributeCasingComponent} from './reference-data/components/attribute-casing/attribute-casing.component';
import {AttributeCasingDetailComponent} from './reference-data/components/attribute-casing/attribute-casing-detail/attribute-casing-detail.component';
import {ProductNounDetailComponent} from './reference-data/components/product-noun/product-noun-detail/product-noun-detail.component';
import {ProductNounComponent} from './reference-data/components/product-noun/product-noun.component';
import {ProductTypeDetailComponent} from './reference-data/components/product-type/product-type-detail/product-type-detail.component';
import {ProductTypeComponent} from './reference-data/components/product-type/product-type.component';
import {GenericIdUnspscMapDetailComponent} from './reference-data/components/generic-id-unspsc-map/generic-id-unspsc-map-detail/generic-id-unspsc-map-detail.component';
import {GenericIdUnspscMapComponent} from './reference-data/components/generic-id-unspsc-map/generic-id-unspsc-map.component';
import {ManufacturerPrefixComponent} from './reference-data/components/manufacturer-prefix/manufacturer-prefix.component';
import {ManufacturerPrefixDetailComponent} from './reference-data/components/manufacturer-prefix/manufacturer-prefix-detail/manufacturer-prefix-detail.component';
import {BusinessComponent} from './reference-data/components/business/business.component';
import {BusinessDetailComponent} from './reference-data/components/business/business-detail/business-detail.component';


import {CatalogComponent} from './catalog.component';
import {PackagingUnitComponent} from './reference-data/components/packaging-unit/packaging-unit.component';
import {PackagingUnitDetailComponent} from './reference-data/components/packaging-unit/packaging-unit-detail/packaging-unit-detail.component';
import {NetContentComponent} from './reference-data/components/net-content/net-content.component';
import {NetContentDetailComponent} from './reference-data/components/net-content/net-content-detail/net-content-detail.component';
import {CatalogDetailsComponent} from './catalog-management/views/catalog-details/catalog-details.component';
import {LocalItemInformationComponent} from './catalog-management/components/local-item-information/local-item-information.component';
import {CustomAttributesComponent} from './catalog-management/components/custom-attributes/custom-attributes.component';
import {CatalogDetailsHeaderComponent} from './common/components/cards/catalog-details-header/catalog-details-header.component';
import {NewItemSearchViewComponent} from './item-management/views/new-item-search-view/new-item-search-view.component';
import {NewCatalogItemSearchViewComponent} from './catalog-management/views/new-catalog-item-search-view/new-catalog-item-search-view.component';
import {CatalogSourcingComponent} from './catalog-management/components/catalog-sourcing/catalog-sourcing.component';
import {CatalogSourcingDetailComponent} from './catalog-management/components/catalog-sourcing-detail/catalog-sourcing-detail.component';
import {SelectSupplierComponent} from './catalog-management/components/catalog-sourcing-detail/select-supplier/select-supplier.component';
import {SelectBuyerPackagingComponent} from './catalog-management/components/catalog-sourcing-detail/select-buyer-packaging/select-buyer-packaging.component';
import {SelectOrderNumberTypeComponent} from './catalog-management/components/catalog-sourcing-detail/select-order-number-type/select-order-number-type.component';
import {SelectSupplierPackagingComponent} from './catalog-management/components/catalog-sourcing-detail/select-supplier-packaging/select-supplier-packaging.component';
import {LcBusinessSearchInputComponent} from "./reference-data/components/business/lc-business-search-input/lc-business-search-input.component";
import {BusinessMergeComponent} from "./reference-data/components/business/business-merge/business-merge.component";


@NgModule({
  imports: [
    UIRouterModule,
    CommonModule,
    CommonComponentsModule,
    PipesModule.forRoot(),
    FormsModule,
    DirectivesModule,
    FulfillmentComponentModule,
    InvOwnersModule,
    AbiManagementModule,
    CommonCatalogModule
  ],
  declarations: [
    ItemSearchComponent,
    ItemDetailsComponent,
    CatalogDetailsComponent,
    NewItemSearchViewComponent,
    NewCatalogItemSearchViewComponent,
    CatalogSearchComponent,
    NonCatalogSearchComponent,
    CatalogReferenceDataComponent,
    CatalogComponent,
    EnterpriseProductIdentifierTypeComponent,
    EnterpriseProductIdentifierTypeDetailComponent,
    PackagingUnitComponent,
    PackagingUnitDetailComponent,
    CriticalItemCategoryComponent,
    CriticalItemCategoryDetailComponent,
    HcpcsImplantComponent,
    HcpcsImplantDetailComponent,
    UnspscCriticalItemCategoryMapComponent,
    UnspscCriticalItemCategoryMapDetailComponent,
    ItemDetailsHeaderComponent,
    CatalogDetailsHeaderComponent,
    AttributeCasingComponent,
    AttributeCasingDetailComponent,
    ProductNounComponent,
    ProductNounDetailComponent,
    ProductTypeComponent,
    ProductTypeDetailComponent,
    NetContentComponent,
    NetContentDetailComponent,
    GenericIdUnspscMapComponent,
    GenericIdUnspscMapDetailComponent,
    ManufacturerPrefixComponent,
    ManufacturerPrefixDetailComponent,
    BusinessComponent,
    BusinessDetailComponent,
    LocalItemInformationComponent,
    CustomAttributesComponent,
    CatalogSourcingComponent,
    CatalogSourcingDetailComponent,
    SelectSupplierComponent,
    SelectBuyerPackagingComponent,
    SelectOrderNumberTypeComponent,
    SelectSupplierPackagingComponent,
    LcBusinessSearchInputComponent,
    BusinessMergeComponent
  ],
  exports: [
    ItemSearchComponent,
    ItemDetailsComponent,
    CatalogDetailsComponent,
    NewItemSearchViewComponent,
    NewCatalogItemSearchViewComponent,
    CatalogSearchComponent,
    NonCatalogSearchComponent,
    CatalogReferenceDataComponent,
    CatalogComponent,
    EnterpriseProductIdentifierTypeComponent,
    EnterpriseProductIdentifierTypeDetailComponent,
    PackagingUnitComponent,
    PackagingUnitDetailComponent,
    CriticalItemCategoryComponent,
    CriticalItemCategoryDetailComponent,
    HcpcsImplantComponent,
    HcpcsImplantDetailComponent,
    UnspscCriticalItemCategoryMapComponent,
    UnspscCriticalItemCategoryMapDetailComponent,
    ItemDetailsHeaderComponent,
    CatalogDetailsHeaderComponent,
    AttributeCasingComponent,
    AttributeCasingDetailComponent,
    ProductNounComponent,
    ProductNounDetailComponent,
    ProductTypeComponent,
    ProductTypeDetailComponent,
    NetContentComponent,
    NetContentDetailComponent,
    GenericIdUnspscMapComponent,
    GenericIdUnspscMapDetailComponent,
    ManufacturerPrefixComponent,
    ManufacturerPrefixDetailComponent,
    BusinessComponent,
    BusinessDetailComponent,
    LocalItemInformationComponent,
    CustomAttributesComponent,
    CatalogSourcingComponent,
    CatalogSourcingDetailComponent,
    SelectSupplierComponent,
    SelectBuyerPackagingComponent,
    SelectOrderNumberTypeComponent,
    LcBusinessSearchInputComponent,
    BusinessMergeComponent
  ],
  providers: [BuyerAccountService, ItemSecondaryAbiSearchService]
})
export class CatalogComponentModule {
}
