import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-catalog',
  templateUrl: './catalog.component.html'
})
export class CatalogComponent implements OnInit {

  constructor() { }

  public ngOnInit(): void {
  }

}
