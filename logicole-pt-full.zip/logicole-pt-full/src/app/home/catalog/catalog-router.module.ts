import { NgModule } from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {CatalogStates} from './catalog-states';


const catalogRoutes: RootModule = {
  states:  CatalogStates,
};

@NgModule({
  imports: [UIRouterModule.forChild(catalogRoutes)],
  exports: [UIRouterModule]
})
export class CatalogRouterModule {

}
