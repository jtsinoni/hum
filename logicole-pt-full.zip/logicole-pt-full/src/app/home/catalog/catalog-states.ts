import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {ItemSearchComponent} from './item-management/item-search.component';
import {ItemDetailsComponent} from './item-management/views/item-details/item-details.component';
import {CatalogSearchComponent} from './catalog-management/catalog-search.component';
import {CatalogReferenceDataComponent} from './reference-data/catalog-reference-data.component';
import {NonCatalogSearchComponent} from './catalog-management/views/non-catalog-search/non-catalog-search.component';
import {EnterpriseProductIdentifierTypeComponent} from './reference-data/components/enterprise-product-identifier-type/enterprise-product-identifier-type.component';
import {CriticalItemCategoryComponent} from './reference-data/components/critical-item-category/critical-item-category.component';
import {HcpcsImplantComponent} from './reference-data/components/hcpcs-implant/hcpcs-implant.component';
import {UnspscCriticalItemCategoryMapComponent} from './reference-data/components/ucicm/unspsc-critical-item-category-map.component';
import {AttributeCasingComponent} from './reference-data/components/attribute-casing/attribute-casing.component';
import {ProductNounComponent} from './reference-data/components/product-noun/product-noun.component';
import {ProductTypeComponent} from './reference-data/components/product-type/product-type.component';
import {GenericIdUnspscMapComponent} from './reference-data/components/generic-id-unspsc-map/generic-id-unspsc-map.component';
import {CatalogComponent} from './catalog.component';
import {ManufacturerPrefixComponent} from './reference-data/components/manufacturer-prefix/manufacturer-prefix.component';
import {PackagingUnitComponent} from './reference-data/components/packaging-unit/packaging-unit.component';
import {NetContentComponent} from './reference-data/components/net-content/net-content.component';
import {CatalogDetailsComponent} from './catalog-management/views/catalog-details/catalog-details.component';
import {NewItemSearchViewComponent} from './item-management/views/new-item-search-view/new-item-search-view.component';
import {NewCatalogItemSearchViewComponent} from './catalog-management/views/new-catalog-item-search-view/new-catalog-item-search-view.component';
import {BusinessComponent} from './reference-data/components/business/business.component';

export const CATALOG_ROOT: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_ROOT.url,
  name: RouteConstants.CATALOG_ROOT.name,
  abstract: true,
  component: CatalogComponent, data: {'route': RouteConstants.CATALOG_ROOT}
};

export const ORDER_ITEM_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.ENTERPRISE_ITEM_SEARCH.url,
  name: RouteConstants.ENTERPRISE_ITEM_SEARCH.name,
  component: ItemSearchComponent, data: {'route': RouteConstants.ENTERPRISE_ITEM_SEARCH}
};

export const NEW_ITEM_SEARCH_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.NEW_ITEM_SEARCH_VIEW.url,
  name: RouteConstants.NEW_ITEM_SEARCH_VIEW.name,
  component: NewItemSearchViewComponent, data: { 'route': RouteConstants.NEW_ITEM_SEARCH_VIEW }
};

export const NEW_CATALOG_ITEM_SEARCH_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.NEW_CATALOG_ITEM_SEARCH_VIEW.url,
  name: RouteConstants.NEW_CATALOG_ITEM_SEARCH_VIEW.name,
  component: NewCatalogItemSearchViewComponent, data: { 'route': RouteConstants.NEW_CATALOG_ITEM_SEARCH_VIEW }
};

export const ORDER_ITEM_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ITEM_DETAILS.url,
  name: RouteConstants.ITEM_DETAILS.name,
  component: ItemDetailsComponent, data: {'route': RouteConstants.ITEM_DETAILS}
};

export const ORDER_CUSTOMER_ITEM_SOURCING_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.CUSTOMER_ITEM_SOURCING_SEARCH.url,
  name: RouteConstants.CUSTOMER_ITEM_SOURCING_SEARCH.name,
  component: CatalogSearchComponent, data: {'route': RouteConstants.CUSTOMER_ITEM_SOURCING_SEARCH}
};

export const ORDER_CATALOG_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_DETAILS.url,
  name: RouteConstants.CATALOG_DETAILS.name,
  component: CatalogDetailsComponent, data: {'route': RouteConstants.CATALOG_DETAILS}
};

export const ORDER_NON_CATALOG_CUSTOMER_ITEM_SOURCING_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.NON_CATALOG_SEARCH.url,
  name: RouteConstants.NON_CATALOG_SEARCH.name,
  component: NonCatalogSearchComponent, data: {'route': RouteConstants.NON_CATALOG_SEARCH}
};

export const ORDER_ADD_ITEM_TO_CATALOG: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_ADD_ITEM_TO_CATALOG.url,
  name: RouteConstants.ORDER_ADD_ITEM_TO_CATALOG.name,
  component: ItemDetailsComponent, data: {'route': RouteConstants.ORDER_ADD_ITEM_TO_CATALOG}
};

export const CATALOG_REFERENCE_DATA: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_REFERENCE_DATA.url,
  name: RouteConstants.CATALOG_REFERENCE_DATA.name,
  component: CatalogReferenceDataComponent,
  data: {'route': RouteConstants.CATALOG_REFERENCE_DATA}
};
export const CATALOG_ENTERPRISE_PRODUCT_IDENTIFIER_TYPE: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_ENTERPRISE_PRODUCT_IDENTIFIER_TYPE.url,
  name: RouteConstants.CATALOG_ENTERPRISE_PRODUCT_IDENTIFIER_TYPE.name,
  component: EnterpriseProductIdentifierTypeComponent,
  data: {'route': RouteConstants.CATALOG_ENTERPRISE_PRODUCT_IDENTIFIER_TYPE}
};
export const CATALOG_BUSINESS_NAME: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_BUSINESS_NAME.url,
  name: RouteConstants.CATALOG_BUSINESS_NAME.name,
  component: BusinessComponent,
  data: {'route': RouteConstants.CATALOG_BUSINESS_NAME}
};
export const CATALOG_PACKAGING_UNIT: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_PACKAGING_UNIT.url,
  name: RouteConstants.CATALOG_PACKAGING_UNIT.name,
  component: PackagingUnitComponent,
  data: {'route': RouteConstants.CATALOG_PACKAGING_UNIT}
};
export const CATALOG_CRITICAL_ITEM_CATEGORY: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_CRITICAL_ITEM_CATEGORY.url,
  name: RouteConstants.CATALOG_CRITICAL_ITEM_CATEGORY.name,
  component: CriticalItemCategoryComponent,
  data: {'route': RouteConstants.CATALOG_CRITICAL_ITEM_CATEGORY}
};
export const CATALOG_HCPCS_IMPLANT: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_HCPCS_IMPLANT.url,
  name: RouteConstants.CATALOG_HCPCS_IMPLANT.name,
  component: HcpcsImplantComponent,
  data: {'route': RouteConstants.CATALOG_HCPCS_IMPLANT}
};
export const CATALOG_UNSPSC_CRITICAL_ITEM_CATEGORY_MAP: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_UNSPSC_CRITICAL_ITEM_CATEGORY_MAP.url,
  name: RouteConstants.CATALOG_UNSPSC_CRITICAL_ITEM_CATEGORY_MAP.name,
  component: UnspscCriticalItemCategoryMapComponent,
  data: {'route': RouteConstants.CATALOG_UNSPSC_CRITICAL_ITEM_CATEGORY_MAP}
};
export const CATALOG_ATTRIBUTE_CASING: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_ATTRIBUTE_CASING.url,
  name: RouteConstants.CATALOG_ATTRIBUTE_CASING.name,
  component: AttributeCasingComponent,
  data: {'route': RouteConstants.CATALOG_ATTRIBUTE_CASING}
};
export const CATALOG_PRODUCT_NOUN: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_PRODUCT_NOUN.url,
  name: RouteConstants.CATALOG_PRODUCT_NOUN.name,
  component: ProductNounComponent,
  data: {'route': RouteConstants.CATALOG_PRODUCT_NOUN}
};
export const CATALOG_PRODUCT_TYPE: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_PRODUCT_TYPE.url,
  name: RouteConstants.CATALOG_PRODUCT_TYPE.name,
  component: ProductTypeComponent,
  data: {'route': RouteConstants.CATALOG_PRODUCT_TYPE}
};
export const CATALOG_NET_CONTENT: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_NET_CONTENT.url,
  name: RouteConstants.CATALOG_NET_CONTENT.name,
  component: NetContentComponent,
  data: {'route': RouteConstants.CATALOG_NET_CONTENT}
};
export const CATALOG_GENERIC_ID_UNSPSC_MAP: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_GENERIC_ID_UNSPSC_MAP.url,
  name: RouteConstants.CATALOG_GENERIC_ID_UNSPSC_MAP.name,
  component: GenericIdUnspscMapComponent,
  data: {'route': RouteConstants.CATALOG_GENERIC_ID_UNSPSC_MAP}
};
export const CATALOG_MANUFACTURER_PREFIX: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_MANUFACTURER_PREFIX.url,
  name: RouteConstants.CATALOG_MANUFACTURER_PREFIX.name,
  component: ManufacturerPrefixComponent,
  data: {'route': RouteConstants.CATALOG_MANUFACTURER_PREFIX}
};

export const CatalogStates: Ng2StateDeclaration[] = [
  CATALOG_ROOT,
  ORDER_ITEM_SEARCH,
  NEW_ITEM_SEARCH_VIEW,
  NEW_CATALOG_ITEM_SEARCH_VIEW,
  ORDER_ITEM_DETAILS,
  ORDER_CATALOG_DETAILS,
  ORDER_CUSTOMER_ITEM_SOURCING_SEARCH,
  ORDER_NON_CATALOG_CUSTOMER_ITEM_SOURCING_SEARCH,
  ORDER_ADD_ITEM_TO_CATALOG,
  CATALOG_REFERENCE_DATA,
  CATALOG_ENTERPRISE_PRODUCT_IDENTIFIER_TYPE,
  CATALOG_BUSINESS_NAME,
  CATALOG_PACKAGING_UNIT,
  CATALOG_CRITICAL_ITEM_CATEGORY,
  CATALOG_HCPCS_IMPLANT,
  CATALOG_UNSPSC_CRITICAL_ITEM_CATEGORY_MAP,
  CATALOG_ATTRIBUTE_CASING,
  CATALOG_PRODUCT_NOUN,
  CATALOG_PRODUCT_TYPE,
  CATALOG_NET_CONTENT,
  CATALOG_GENERIC_ID_UNSPSC_MAP,
  CATALOG_MANUFACTURER_PREFIX
];
