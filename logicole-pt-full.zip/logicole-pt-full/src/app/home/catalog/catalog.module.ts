import {NgModule} from '@angular/core';

import {CatalogRouterModule} from './catalog-router.module';
import {BuyerAccountService} from '../organization/organization-role-services-management/buyer/buyer-details/buyer-accounts/services/buyer-account.service';
import {ItemSecondaryAbiSearchService} from './catalog-management/services/item-secondary-abi-search.service';
import {CatalogComponentModule} from './catalog-component.module';
import {DropDownListsApiService} from './services/drop-down-lists-api/drop-down-lists-api.service';
import {PackageUnitApiService} from './services/package-unit-api/package-unit-api.service';
import {PackagingLabelsService} from './services/packaging-labels/packaging-labels.service';
import {ItemUpdateService} from './item-management/services/item-update.service';
import {CatalogUpdateService} from './catalog-management/services/catalog-update.service';
import {RecordUpdateManagerService} from './services/record-update-manager/record-update-manager.service';
import {CatalogPermissionsUtilityService} from './services/catalog-permissions-utility/catalog-permissions-utility.service';


@NgModule({
  imports: [
    CatalogRouterModule,
    CatalogComponentModule
  ],
  declarations: [],
  exports: [],
  providers: [
    BuyerAccountService,
    ItemSecondaryAbiSearchService,
    PackageUnitApiService,
    DropDownListsApiService,
    PackagingLabelsService,
    ItemUpdateService,
    CatalogUpdateService,
    RecordUpdateManagerService,
    CatalogPermissionsUtilityService,
  ]
})
export class CatalogModule {
}
