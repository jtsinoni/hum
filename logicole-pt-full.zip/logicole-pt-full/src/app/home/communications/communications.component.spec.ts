import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {CommunicationsComponent} from './communications.component';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {a11yTests, prettyPrintA11Y} from '../../accessibility';
import {LoggerService} from '@lc-logger-service';
import {FormsModule} from '@angular/forms';

describe('ComunicationsComponent', () => {
  let component: CommunicationsComponent;
  let fixture: ComponentFixture<CommunicationsComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ CommunicationsComponent ],
      providers: [ LoggerService ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });

    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommunicationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      const options: any = {rules: {'label': {enabled: false}}};

      a11yTests(fixture.nativeElement, options)
        .then((results) => {
          expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
        })
        .catch((error) => {
          loggerService.error(`${error}`);
        });
    }));
  });
});
