import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {CommunicationsComponent} from './communications.component';
import {CommunicationsOutboundConfigComponent} from './communications-outbound-config/communications-outbound-config.component';
import {EhrOutgoingTrafficComponent} from './ehr-messages/views/ehr-outgoing-traffic/ehr-outgoing-traffic.component';
import {EhrOutgoingTrafficDetailsComponent} from './ehr-messages/views/ehr-outgoing-traffic-details/ehr-outgoing-traffic-details.component';
import {EhrIncomingTrafficDetailsComponent} from './ehr-messages/views/ehr-incoming-traffic-details/ehr-incoming-traffic-details.component';
import {EhrRequestQueueComponent} from './ehr-messages/views/ehr-request-queue/ehr-request-queue.component';
import {EhrRequestQueueDetailsComponent} from './ehr-messages/views/ehr-request-queue-details/ehr-request-queue-details.component';
import {EhrOutgoingOrdersComponent} from './ehr-messages/views/ehr-outgoing-orders/ehr-outgoing-orders.component';
import {EhrOutgoingStatusMessagesComponent} from './ehr-messages/views/ehr-outgoing-status-messages/ehr-outgoing-status-messages.component';
import {EhrOutgoingOrderDetailsComponent} from './ehr-messages/views/ehr-outgoing-order-details/ehr-outgoing-order-details.component';
import {EhrPurchaseOrderStatusDetailsComponent} from './ehr-messages/views/ehr-purchase-order-status-details/ehr-purchase-order-status-details.component';
import {EhrTaskHistoryComponent} from './ehr-messages/views/ehr-task-history/ehr-task-history.component';
import {EhrMessagesComponent} from './ehr-messages/views/ehr-messages.component';
import {EhrIncomingTrafficComponent} from './ehr-messages/views/ehr-incoming-traffic/ehr-incoming-traffic.component';
import {CommunicationResponseTransactionsComponent} from './communication-transactions/views/communication-transactions/communication-response-transactions.component';
import {CommunicationResponseTransactionDetailComponent} from './communication-transactions/views/communication-transaction-detail/communication-response-transaction-detail.component';
import {DaasTestingComponent} from './daas/daas-testing.component';
import {EdiTestingComponent} from './edi-testing/edi-testing.component';

export const COMMUNICATIONS_ROOT: Ng2StateDeclaration = {
  abstract: true,
  url: RouteConstants.COMMUNICATIONS_ROOT.url,
  name: RouteConstants.COMMUNICATIONS_ROOT.name,
  component: CommunicationsComponent,
  data: {'route': RouteConstants.COMMUNICATIONS_ROOT}
};

export const COMMUNICATIONS_OUTBOUND_CONFIG: Ng2StateDeclaration = {
  url: RouteConstants.COMMUNICATIONS_OUTBOUND_CONFIG.url,
  name: RouteConstants.COMMUNICATIONS_OUTBOUND_CONFIG.name,
  component: CommunicationsOutboundConfigComponent,
  data: {'route': RouteConstants.COMMUNICATIONS_OUTBOUND_CONFIG}
};

export const DAAS_TESTING: Ng2StateDeclaration = {
  url: RouteConstants.DAAS_TESTING.url,
  name: RouteConstants.DAAS_TESTING.name,
  component: DaasTestingComponent,
  data: {'route': RouteConstants.DAAS_TESTING}
};

export const EDI_TESTING: Ng2StateDeclaration = {
  url: RouteConstants.EDI_TESTING.url,
  name: RouteConstants.EDI_TESTING.name,
  component: EdiTestingComponent,
  data: {'route': RouteConstants.EDI_TESTING}
};

export const EHR_MESSAGES: Ng2StateDeclaration = {
  url: RouteConstants.EHR_MESSAGES.url,
  name: RouteConstants.EHR_MESSAGES.name,
  abstract: true,
  component: EhrMessagesComponent,
  data: {'route': RouteConstants.EHR_MESSAGES}
};

export const EHR_INCOMING_TRAFFIC_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.EHR_INCOMING_TRAFFIC_VIEW.url,
  name: RouteConstants.EHR_INCOMING_TRAFFIC_VIEW.name,
  component: EhrIncomingTrafficComponent,
  data: {'route': RouteConstants.EHR_INCOMING_TRAFFIC_VIEW}
};

export const EHR_INCOMING_TRAFFIC_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.EHR_INCOMING_TRAFFIC_DETAILS.url,
  name: RouteConstants.EHR_INCOMING_TRAFFIC_DETAILS.name,
  component: EhrIncomingTrafficDetailsComponent,
  data: {'route': RouteConstants.EHR_INCOMING_TRAFFIC_DETAILS}
};

export const EHR_OUTGOING_TRAFFIC_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.EHR_OUTGOING_TRAFFIC_VIEW.url,
  name: RouteConstants.EHR_OUTGOING_TRAFFIC_VIEW.name,
  component: EhrOutgoingTrafficComponent,
  data: {'route': RouteConstants.EHR_OUTGOING_TRAFFIC_VIEW}
};

export const EHR_OUTGOING_TRAFFIC_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.EHR_OUTGOING_TRAFFIC_DETAILS.url,
  name: RouteConstants.EHR_OUTGOING_TRAFFIC_DETAILS.name,
  component: EhrOutgoingTrafficDetailsComponent,
  data: {'route': RouteConstants.EHR_OUTGOING_TRAFFIC_DETAILS}
};

export const EHR_REQUEST_QUEUE_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.EHR_REQUEST_QUEUE_VIEW.url,
  name: RouteConstants.EHR_REQUEST_QUEUE_VIEW.name,
  component: EhrRequestQueueComponent,
  data: {'route': RouteConstants.EHR_REQUEST_QUEUE_VIEW}
};

export const EHR_REQUEST_QUEUE_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.EHR_REQUEST_QUEUE_DETAILS.url,
  name: RouteConstants.EHR_REQUEST_QUEUE_DETAILS.name,
  component: EhrRequestQueueDetailsComponent,
  data: {'route': RouteConstants.EHR_REQUEST_QUEUE_DETAILS}
};

export const EHR_OUTGOING_ORDER_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.EHR_OUTGOING_ORDER_VIEW.url,
  name: RouteConstants.EHR_OUTGOING_ORDER_VIEW.name,
  component: EhrOutgoingOrdersComponent,
  data: {'route': RouteConstants.EHR_OUTGOING_ORDER_VIEW}
};

export const EHR_OUTGOING_ORDER_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.EHR_OUTGOING_ORDER_DETAILS.url,
  name: RouteConstants.EHR_OUTGOING_ORDER_DETAILS.name,
  component: EhrOutgoingOrderDetailsComponent,
  data: {'route': RouteConstants.EHR_OUTGOING_ORDER_DETAILS}
};

export const EHR_OUTGOING_STATUS_MESSAGE_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.EHR_OUTGOING_STATUS_MESSAGE_VIEW.url,
  name: RouteConstants.EHR_OUTGOING_STATUS_MESSAGE_VIEW.name,
  component: EhrOutgoingStatusMessagesComponent,
  data: {'route': RouteConstants.EHR_OUTGOING_STATUS_MESSAGE_VIEW}
};

export const EHR_OUTGOING_STATUS_MESSAGE_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.EHR_OUTGOING_STATUS_MESSAGE_DETAILS.url,
  name: RouteConstants.EHR_OUTGOING_STATUS_MESSAGE_DETAILS.name,
  component: EhrPurchaseOrderStatusDetailsComponent,
  data: {'route': RouteConstants.EHR_OUTGOING_STATUS_MESSAGE_DETAILS}
};

export const EHR_TASK_HISTORY_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.EHR_TASK_HISTORY_VIEW.url,
  name: RouteConstants.EHR_TASK_HISTORY_VIEW.name,
  component: EhrTaskHistoryComponent,
  data: {'route': RouteConstants.EHR_TASK_HISTORY_VIEW}
};

export const RESPONSE_TRANSACTIONS: Ng2StateDeclaration = {
  url: RouteConstants.COMMUNICATION_TRANSACTIONS.url,
  name: RouteConstants.COMMUNICATION_TRANSACTIONS.name,
  component: CommunicationResponseTransactionsComponent,
  data: {'route': RouteConstants.COMMUNICATION_TRANSACTIONS}
};

export const RESPONSE_TRANSACTION_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.COMMUNICATION_TRANSACTION_DETAILS.url,
  name: RouteConstants.COMMUNICATION_TRANSACTION_DETAILS.name,
  component: CommunicationResponseTransactionDetailComponent,
  data: {'route': RouteConstants.COMMUNICATION_TRANSACTION_DETAILS}
};

export const CommunicationsStates: Ng2StateDeclaration[] = [
  COMMUNICATIONS_ROOT,
  COMMUNICATIONS_OUTBOUND_CONFIG,
  DAAS_TESTING,
  EDI_TESTING,
  EHR_MESSAGES,
  EHR_INCOMING_TRAFFIC_VIEW,
  EHR_INCOMING_TRAFFIC_DETAILS,
  EHR_OUTGOING_TRAFFIC_VIEW,
  EHR_OUTGOING_TRAFFIC_DETAILS,
  EHR_REQUEST_QUEUE_VIEW,
  EHR_REQUEST_QUEUE_DETAILS,
  EHR_OUTGOING_ORDER_VIEW,
  EHR_OUTGOING_ORDER_DETAILS,
  EHR_OUTGOING_STATUS_MESSAGE_VIEW,
  EHR_OUTGOING_STATUS_MESSAGE_DETAILS,
  EHR_TASK_HISTORY_VIEW,
  RESPONSE_TRANSACTIONS,
  RESPONSE_TRANSACTION_DETAILS
];
