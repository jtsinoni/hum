import {CUSTOM_ELEMENTS_SCHEMA, NgModule} from '@angular/core';
import {CommonModule, DatePipe, DecimalPipe} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {CommunicationsComponent} from './communications.component';
import {CommunicationsOutboundConfigComponent} from './communications-outbound-config/communications-outbound-config.component';
import {CommunicationsTransmitApiService} from './services/communications-transmit-api.service';
import {CommunicationsRoutingModule} from './communications-routing.module';
import {LcYesNoDialogComponent} from './comms-common-components/lc-yes-no-dialog/lc-yes-no-dialog.component';
import {CommunicationsOutboundService} from './communications-outbound-config/services/communications-outbound.service';
import {CommunicationsEhrService} from './ehr-messages/services/communications-ehr.service';
import {RouteConstants} from '@lc-constants/*';
import {PipesModule} from '../../pipes/pipes.module';
import {PaginationModule} from 'ngx-bootstrap/pagination';
import {TooltipModule} from 'ngx-bootstrap/tooltip';
import {CommonComponentsModule} from '@lc-common-components';
import {DirectivesModule} from '../../directives/directives.module';
import {EhrMessagesComponent} from './ehr-messages/views/ehr-messages.component';
import {EhrIncomingTrafficDetailsComponent} from './ehr-messages/views/ehr-incoming-traffic-details/ehr-incoming-traffic-details.component';
import {EhrOutgoingTrafficDetailsComponent} from './ehr-messages/views/ehr-outgoing-traffic-details/ehr-outgoing-traffic-details.component';
import {EhrOutgoingTrafficComponent} from './ehr-messages/views/ehr-outgoing-traffic/ehr-outgoing-traffic.component';
import {EhrIncomingTrafficComponent} from './ehr-messages/views/ehr-incoming-traffic/ehr-incoming-traffic.component';
import {EhrTaskHistoryComponent} from './ehr-messages/views/ehr-task-history/ehr-task-history.component';
import {EhrRequestQueueComponent} from './ehr-messages/views/ehr-request-queue/ehr-request-queue.component';
import {EhrRequestQueueDetailsComponent} from './ehr-messages/views/ehr-request-queue-details/ehr-request-queue-details.component';
import {EhrOutgoingOrdersComponent} from './ehr-messages/views/ehr-outgoing-orders/ehr-outgoing-orders.component';
import {EhrOutgoingOrderDetailsComponent} from './ehr-messages/views/ehr-outgoing-order-details/ehr-outgoing-order-details.component';
import {EhrOutgoingStatusMessagesComponent} from './ehr-messages/views/ehr-outgoing-status-messages/ehr-outgoing-status-messages.component';
import {EhrPurchaseOrderStatusDetailsComponent} from './ehr-messages/views/ehr-purchase-order-status-details/ehr-purchase-order-status-details.component';
import {EhrDmlssPurchaseOrderStatusComponent} from './ehr-messages/components/ehr-dmlss-purchase-order-status/ehr-dmlss-purchase-order-status.component';
import {CommunicationsEhrApiService} from './ehr-messages/services/communications-ehr-api.service';
import {EhrPurchaseOrderStatusComponent} from './ehr-messages/components/ehr-purchase-order-status/ehr-purchase-order-status.component';
import {CommunicationResponseTransactionsComponent} from './communication-transactions/views/communication-transactions/communication-response-transactions.component';
import {CommunicationResponseTransactionDetailComponent} from './communication-transactions/views/communication-transaction-detail/communication-response-transaction-detail.component';
import {DaasTestingComponent} from './daas/daas-testing.component';
import {EdiTestingComponent} from './edi-testing/edi-testing.component';
import {DaasExternalApiService} from './daas/services/daas-external-api.service';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CommunicationsRoutingModule,
    CommonComponentsModule.forRoot(),
    DirectivesModule,
    FormsModule,
    PaginationModule.forRoot(),
    PipesModule.forRoot(),
    TooltipModule.forRoot(),
  ],
  declarations: [
    CommunicationsComponent,
    CommunicationsOutboundConfigComponent,
    DaasTestingComponent,
    EdiTestingComponent,
    LcYesNoDialogComponent,
    EhrMessagesComponent,
    EhrIncomingTrafficComponent,
    EhrOutgoingTrafficComponent,
    EhrIncomingTrafficDetailsComponent,
    EhrOutgoingTrafficDetailsComponent,
    EhrTaskHistoryComponent,
    EhrRequestQueueComponent,
    EhrRequestQueueDetailsComponent,
    EhrOutgoingOrdersComponent,
    EhrOutgoingOrderDetailsComponent,
    EhrOutgoingStatusMessagesComponent,
    EhrPurchaseOrderStatusDetailsComponent,
    EhrPurchaseOrderStatusComponent,
    EhrDmlssPurchaseOrderStatusComponent,
    CommunicationResponseTransactionsComponent,
    CommunicationResponseTransactionDetailComponent,
  ],
  providers: [
    DatePipe,
    DecimalPipe,
    RouteConstants,
    DaasExternalApiService,
    CommunicationsTransmitApiService,
    CommunicationsOutboundService,
    CommunicationsEhrApiService,
    CommunicationsEhrService
  ],
  exports: [
    LcYesNoDialogComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CommunicationsModule { }
