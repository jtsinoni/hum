import {RootModule, UIRouterModule} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {CommunicationsStates} from './communications-states';
import {NgModule} from '@angular/core';

const communicationsRoutes: RootModule = {
  states: CommunicationsStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(communicationsRoutes)],
  exports: [UIRouterModule],
})
export class CommunicationsRoutingModule {
}
