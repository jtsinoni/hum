import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'lc-communications',
  templateUrl: './communications.component.html'
})
export class CommunicationsComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }
}
