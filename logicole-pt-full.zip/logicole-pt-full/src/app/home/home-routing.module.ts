import {NgModule} from '@angular/core';
import {RouteConstants} from '@lc-constants/*';
import {Ng2StateDeclaration, RootModule, UIRouterModule} from '@uirouter/angular';
import {HomeStates} from './home-states';
import {RouteAssemblageConstants} from './assemblage/constants/route-assemblage.constants';
import {StandAloneHelpComponent} from './help/help-center/stand-alone-help/stand-alone-help.component';
import {RouteMedicalEquipmentConstants} from './asset/medical-equipment/constants/route-medical-equipment.constants';
import {RouteCustodianConstants} from './asset/custodian/constants/route-custodian.constants';
import {RouteModalityConstants} from './asset/modality/constants/route-modality.constants';
import {RouteUtilitiesConstants} from './utilities/constants/route-utilities.constants.ts';
import {RouteConsultantConstants} from './asset/consultant/constants/route-consultant.constants';

const SERVICE_REQUEST_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.SERVICE_REQUEST_SEARCH.name + '.**',
  url: RouteConstants.SERVICE_REQUEST_SEARCH.url,
  loadChildren: () => import('app/home/service-request/service-request.module').then(m => m.ServiceRequestModule)
};

const ABI_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.ABI_SEARCH.name + '.**',
  url: RouteConstants.ABI_SEARCH.url,
  loadChildren: () => import('app/home/abi-search/abi-search.module').then(m => m.AbiSearchModule)
};

const ASSEMBLAGE_MODULE: Ng2StateDeclaration = {
  name: RouteAssemblageConstants.ASSEMBLAGE_MANAGEMENT.name + '.**',
  url: RouteAssemblageConstants.ASSEMBLAGE_MANAGEMENT.url,
  loadChildren: () => import('app/home/assemblage/assemblage.module').then(m => m.AssemblageModule)
};

const ASSET_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.MAINTENANCE.name + '.**',
  url: RouteConstants.MAINTENANCE.url,
  loadChildren: () => import('app/home/asset/asset.module').then(m => m.AssetModule)
};

const INVENTORY_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.INVENTORY_ROOT.name + '.**', url: RouteConstants.INVENTORY_ROOT.url,
  loadChildren: () => import('app/home/inventory/inventory.module').then(m => m.InventoryModule)
};

const FINANCE_MODULE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_ROOT.url,
  name: RouteConstants.FINANCE_ROOT.name + '.**',
  loadChildren: () => import('app/home/finance/finance.module').then(m => m.FinanceModule)
};

const FULFILLMENT_MODULE: Ng2StateDeclaration = {
  url: RouteConstants.FULFILLMENT.url,
  name: RouteConstants.FULFILLMENT.name + '.**',
  loadChildren: () => import('app/home/fulfillment/fulfillment.module').then(m => m.FulfillmentModule)
};

const BUSINESS_INTELLIGENCE_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.BUSINESS_INTELLIGENCE_ROOT.name + '.**',
  url: RouteConstants.BUSINESS_INTELLIGENCE_ROOT.url,
  loadChildren: () => import('app/home/business-intelligence/business-intelligence.module').then(m => m.BusinessIntelligenceModule)
};

const COMMUNICATIONS_OUTBOUND_CONFIG_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.COMMUNICATIONS_ROOT.name + '.**',
  url: RouteConstants.COMMUNICATIONS_ROOT.url,
  loadChildren: () => import('app/home/communications/communications.module').then(m => m.CommunicationsModule)
};

const EQUIPMENT_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.EQUIPMENT_ROOT.name + '.**',
  url: RouteConstants.EQUIPMENT_ROOT.url,
  loadChildren: () => import('app/home/equipment/equipment.module').then(m => m.EquipmentModule)
};

const ORGANIZATION_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.ORGANIZATION_ROOT.name + '.**',
  url: RouteConstants.ORGANIZATION_ROOT.url,
  loadChildren: () => import('app/home/organization/organization.module').then(m => m.OrganizationModule)
};

const RECEIVING_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.RECEIVING_ROOT.name + '.**',
  url: RouteConstants.RECEIVING_ROOT.url,
  loadChildren: () => import('app/home/receiving/receiving.module').then(m => m.ReceivingModule)
};

const PROJECT_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.PROJECT_ROOT.name + '.**',
  url: RouteConstants.PROJECT_ROOT.url,
  loadChildren: () => import('app/home/real-property/project/project.module').then(m => m.ProjectModule)
};

const REAL_PROPERTY_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.REAL_PROPERTY_ROOT.name + '.**',
  url: RouteConstants.REAL_PROPERTY_ROOT.url,
  loadChildren: () => import('app/home/real-property/real-property.module').then(m => m.RealPropertyModule)
};

const REAL_PROPERTY_REFERENCE_DATA_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.REAL_PROPERTY_REFERENCE_DATA.name + '.**',
  url: RouteConstants.REAL_PROPERTY_REFERENCE_DATA.url,
  loadChildren: () => import('app/home/real-property/reference-data/reference-data.module').then(m => m.ReferenceDataModule)
};

const REQUIREMENTS_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.REQUIREMENTS_ROOT.name + '.**',
  url: RouteConstants.REQUIREMENTS_ROOT.url,
  loadChildren: () => import('app/home/real-property/requirements/requirements.module').then(m => m.RequirementsModule)
};

const SECTION_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.SECTION_ROOT.name + '.**',
  url: RouteConstants.SECTION_ROOT.url,
  loadChildren: () => import('app/home/real-property/section/section.module').then(m => m.SectionModule)
};

const SPACE_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.SPACE_ROOT.name + '.**',
  url: RouteConstants.SPACE_ROOT.url,
  loadChildren: () => import('app/home/real-property/space/space.module').then(m => m.SpaceModule)
};

const COBIE_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.COBIE_ROOT.name + '.**',
  url: RouteConstants.COBIE_ROOT.url,
  loadChildren: () => import('app/home/real-property/cobie/cobie.module').then(m => m.COBieModule)
};

const ACCESS_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.ACCESS_ROOT.name + '.**',
  url: RouteConstants.ACCESS_ROOT.url,
  loadChildren: () => import('app/home/access/access.module').then(m => m.AccessModule)
};

const JMLFDC_ADMIN_MODULE: Ng2StateDeclaration = {
  url: RouteConstants.JMLFDC_ADMIN.url,
  name: RouteConstants.JMLFDC_ADMIN.name + '.**',
  loadChildren: () => import('app/home/jmlfdc-admin/jmlfdc-admin.module').then(m => m.JmlfdcAdminModule)
};

const SLEP_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.SLEP_ROOT.name + '.**',
  url: RouteConstants.SLEP_ROOT.url,
  loadChildren: () => import('app/home/slep/slep.module').then(m => m.SlepModule)
};

const HELP: Ng2StateDeclaration = {
  url: RouteConstants.HELP.url,
  name: RouteConstants.HELP.name,
  component: StandAloneHelpComponent,
  data: {'route': RouteConstants.HELP}
};

const HELP_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.HELP_ROOT.name + '.**',
  url: RouteConstants.HELP_ROOT.url,
  loadChildren: () => import('app/home/help/help.module').then(m => m.HelpModule)
};

const NOTIFICATIONS_MODULE: Ng2StateDeclaration = {
  url: RouteConstants.NOTIFICATIONS_ROOT.url,
  name: RouteConstants.NOTIFICATIONS_ROOT.name + '.**',
  loadChildren: () => import('app/home/notifications/notifications.module').then(m => m.NotificationsModule)
};

const WORK_ORDERS_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.WORK_ORDER_CORE_SEARCH.name + '.**',
  url: RouteConstants.WORK_ORDER_CORE_SEARCH.url,
  loadChildren: () => import('app/home/work-orders/work-orders.module').then(m => m.WorkOrdersModule)
};

const WORK_ORDERS_REAL_PROPERTY_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.WORK_ORDER_SEARCH.name + '.**',
  url: RouteConstants.WORK_ORDER_SEARCH.url,
  loadChildren: () => import('app/home/work-orders/work-orders.module').then(m => m.WorkOrdersModule)
};

const WORK_ORDERS_MEDICAL_EQUIPMENT_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_SEARCH.name + '.**',
  url: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_SEARCH.url,
  loadChildren: () => import('app/home/work-orders/work-orders.module').then(m => m.WorkOrdersModule)
};

const UTILITIES_MODULE: Ng2StateDeclaration = {
  name: RouteUtilitiesConstants.UTILITIES_ROOT.name + '.**',
  url: RouteUtilitiesConstants.UTILITIES_ROOT.url,
  loadChildren: () => import('app/home/utilities/utilities.module').then(m => m.UtilitiesModule)
};

const MEDICAL_EQUIPMENT_MODULE: Ng2StateDeclaration = {
  name: RouteMedicalEquipmentConstants.MEDICAL_EQUIPMENT_ROOT.name + '.**',
  url: RouteMedicalEquipmentConstants.MEDICAL_EQUIPMENT_ROOT.url,
  loadChildren: () => import('app/home/asset/medical-equipment/medical-equipment.module').then(m => m.MedicalEquipmentModule)
};

const CONSULTANT_MODULE: Ng2StateDeclaration = {
  name: RouteConsultantConstants.CONSULTANT_ROOT.name + '.**',
  url: RouteConsultantConstants.CONSULTANT_ROOT.url,
  loadChildren: () => import('app/home/asset/consultant/consultant.module').then(m => m.ConsultantModule)
};

const CUSTODIAN_MODULE: Ng2StateDeclaration = {
  name: RouteCustodianConstants.CUSTODIAN_ROOT.name + '.**',
  url: RouteCustodianConstants.CUSTODIAN_ROOT.url,
  loadChildren: () => import('app/home/asset/custodian/custodian.module').then(m => m.CustodianModule)
};

const MODALITY_MODULE: Ng2StateDeclaration = {
  name: RouteModalityConstants.MODALITY_ROOT.name + '.**',
  url: RouteModalityConstants.MODALITY_ROOT.url,
  loadChildren: () => import('app/home/asset/modality/modality.module').then(m => m.ModalityModule)
};

const MAINTENANCE_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.MAINTENANCE_ROOT.name + '.**',
  url: RouteConstants.MAINTENANCE_ROOT.url,
  loadChildren: () => import('app/home/maintenance/maintenance.module').then(m => m.MaintenanceModule)
};

const ORDER_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.ORDER_ROOT.name + '.**',
  url: RouteConstants.ORDER_ROOT.url,
  loadChildren: () => import('app/home/order/order.module').then(m => m.OrderModule)
};

const homeRoutes: RootModule = {
  states: [
    HomeStates.HOME_ROOT,
    HomeStates.MY_DASHBOARD,
    HomeStates.ABOUT,
    HomeStates.LOADING,
    HomeStates.MY_PROFILE,
    SERVICE_REQUEST_MODULE,
    ABI_MODULE,
    ASSEMBLAGE_MODULE,
    ASSET_MODULE,
    INVENTORY_MODULE,
    FINANCE_MODULE,
    FULFILLMENT_MODULE,
    BUSINESS_INTELLIGENCE_MODULE,
    COMMUNICATIONS_OUTBOUND_CONFIG_MODULE,
    EQUIPMENT_MODULE,
    ORGANIZATION_MODULE,
    RECEIVING_MODULE,
    PROJECT_MODULE,
    REAL_PROPERTY_MODULE,
    REAL_PROPERTY_REFERENCE_DATA_MODULE,
    REQUIREMENTS_MODULE,
    SECTION_MODULE,
    SPACE_MODULE,
    COBIE_MODULE,
    ACCESS_MODULE,
    JMLFDC_ADMIN_MODULE,
    SLEP_MODULE,
    HELP,
    HELP_MODULE,
    NOTIFICATIONS_MODULE,
    WORK_ORDERS_MODULE,
    WORK_ORDERS_REAL_PROPERTY_MODULE,
    WORK_ORDERS_MEDICAL_EQUIPMENT_MODULE,
    UTILITIES_MODULE,
    MEDICAL_EQUIPMENT_MODULE,
    CONSULTANT_MODULE,
    CUSTODIAN_MODULE,
    MODALITY_MODULE,
    MAINTENANCE_MODULE,
    ORDER_MODULE
  ],
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(homeRoutes)],
  exports: [UIRouterModule]
})
export class HomeRoutingModule {

}
