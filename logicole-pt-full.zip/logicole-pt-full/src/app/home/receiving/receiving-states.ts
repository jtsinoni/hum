import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {ReceiptsComponent} from './receipts/receipts.component';
import {DueInComponent} from './dueIns/duein.component';
import {ReceiptDetailComponent} from './receipts/receipt-details/receipt-detail.component';


// ToDo: restore if we decide to implement PutAway Inventory functionality
// export const RECEIVE_PUT_AWAY: Ng2StateDeclaration = {
//   url: RouteConstants.RECEIVE_PUT_AWAY.url,
//   name: RouteConstants.RECEIVE_PUT_AWAY.name,
//   component: PutAwayComponent, data: {'route': RouteConstants.RECEIVE_PUT_AWAY},
// };
export const RECEIVING_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.RECEIVE_RECEIPT_DETAILS.url,
  name: RouteConstants.RECEIVE_RECEIPT_DETAILS.name,
  component: ReceiptDetailComponent,
  data: {'route': RouteConstants.RECEIVE_RECEIPT_DETAILS}
};

export const RECEIVE_HISTORY: Ng2StateDeclaration = {
  url: RouteConstants.RECEIVE_HISTORY.url,
  name: RouteConstants.RECEIVE_HISTORY.name,
  component: ReceiptsComponent, data: {'route': RouteConstants.RECEIVE_HISTORY},
};

export const RECEIVE_DUEIN: Ng2StateDeclaration = {
  url: RouteConstants.RECEIVE_DUEIN.url,
  name: RouteConstants.RECEIVE_DUEIN.name,
  component: DueInComponent, data: {'route': RouteConstants.RECEIVE_DUEIN},
  params: {'rerunSearch': null},
};

export const RECEIVING: Ng2StateDeclaration = {
  url: RouteConstants.RECEIVING_ROOT.url,
  name: RouteConstants.RECEIVING_ROOT.name,
  component: DueInComponent, data: {'route': RouteConstants.RECEIVING_ROOT},
};

export const ReceivingStates: Ng2StateDeclaration[] = [
  RECEIVING,
  RECEIVE_DUEIN,
  RECEIVE_HISTORY,
  RECEIVING_DETAILS
  // RECEIVE_PUT_AWAY
];
