import { NgModule } from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {ReceivingStates} from './receiving-states';

const receivingRoutes: RootModule = {
  states: ReceivingStates
};


@NgModule({
  imports: [UIRouterModule.forChild(receivingRoutes)],
  exports: [UIRouterModule]
})
export class ReceivingRouterModule { }
