import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {DueInComponent} from './dueIns/duein.component';
import {PutAwayComponent} from './put-away/put-away.component';
import {ReceiptsComponent} from './receipts/receipts.component';
import {ReceivingRouterModule} from './receiving-router.module';
import {CommonComponentsModule} from '@lc-common-components';
import {FormsModule} from '@angular/forms';
import {PipesModule} from '../../pipes/pipes.module';
import {ReceiptNotesComponent} from './receipts/receipt-notes/receipt-notes.component';
import {ReceiptAttachmentsComponent} from './receipts/receipt-attachments/receipt-attachments.component';
import {ReceiptDetailComponent} from './receipts/receipt-details/receipt-detail.component';
import { ReceiptDiscrepancyComponent } from './receipts/receipt-details/components/receipt-discrepancy/receipt-discrepancy.component';
import { DiscrepancyDistributionsComponent } from './receipts/receipt-details/components/receipt-discrepancy/discrepancy-distributions.component';
import {ReceiptApiService} from './receipts/services/receipt-api.service';
import {ReceiptService} from './receipts/services/receipt.service';
import {ReceiptDetailApiService} from './receipts/services/receipt-detail-api.service';
import {ReceiptDetailService} from './receipts/services/receipt-detail-service';
import {DiscrepanciesListComponent} from './receipts/receipt-details/components/receipt-discrepancy/discrepancies-list.component';
import { ReceiptDueoutsComponent} from './receipts/receipt-dueouts/receipt-dueouts.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule,
    PipesModule.forRoot(),
    ReceivingRouterModule
  ],
  declarations: [
    DueInComponent,
    PutAwayComponent,
    ReceiptsComponent,
    ReceiptDetailComponent,
    ReceiptDiscrepancyComponent,
    DiscrepancyDistributionsComponent,
    ReceiptAttachmentsComponent,
    ReceiptNotesComponent,
    DiscrepanciesListComponent,
    ReceiptDueoutsComponent
  ],
  exports: [
    DueInComponent,
    PutAwayComponent,
    ReceiptsComponent,
    ReceiptDetailComponent,
    ReceiptDiscrepancyComponent,
    ReceiptAttachmentsComponent,
    ReceiptNotesComponent,
    DiscrepanciesListComponent
  ],
  providers: [ReceiptApiService,
    ReceiptService,
    ReceiptDetailService,
    ReceiptDetailApiService
  ]
})
export class ReceivingModule { }
