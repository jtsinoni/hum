import {Ng2StateDeclaration} from '@uirouter/angular';
import {HomeComponent} from './home.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {AboutComponent} from './home-components/about.component';
import {MyProfileComponent} from './home-components/my-profile.component';
import {LoadingComponent} from './home-components/loading.component';
import {RouteConstants} from '@lc-constants/*';

export class HomeStates {

  public static HOME_ROOT: Ng2StateDeclaration = {
    url: RouteConstants.HOME_ROOT.url,
    name: RouteConstants.HOME_ROOT.name,
    component: HomeComponent, data: {'route': RouteConstants.HOME_ROOT}
  };

  public static MY_DASHBOARD: Ng2StateDeclaration = {
    url: RouteConstants.MY_DASHBOARD.url,
    name: RouteConstants.MY_DASHBOARD.name,
    component: DashboardComponent, data: {'route': RouteConstants.MY_DASHBOARD}
  };

  public static ABOUT: Ng2StateDeclaration = {
    url: RouteConstants.ABOUT.url,
    name: RouteConstants.ABOUT.name,
    component: AboutComponent, data: {'route': RouteConstants.ABOUT}
  };

  public static MY_PROFILE: Ng2StateDeclaration = {
    url: RouteConstants.MY_PROFILE.url,
    name: RouteConstants.MY_PROFILE.name,
    component: MyProfileComponent, data: {'route': RouteConstants.MY_PROFILE}
  };

  public static LOADING: Ng2StateDeclaration = {
    name: RouteConstants.LOADING.name,
    url: RouteConstants.LOADING.url,
    component: LoadingComponent, data: {'breadcrumb': RouteConstants.LOGIN.breadcrumb}
  };
}
