import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {MaintenanceComponent} from './maintenance.component';
import {MaintenanceRoutingModule} from './maintenance-routing.module';
import {MaintenanceProcedureModule} from './maintenance-procedure/maintenance-procedure.module';


@NgModule({
  declarations: [
    MaintenanceComponent
  ],
  imports: [
    CommonModule,
    MaintenanceRoutingModule,
    MaintenanceProcedureModule
  ]
})
export class MaintenanceModule {
}
