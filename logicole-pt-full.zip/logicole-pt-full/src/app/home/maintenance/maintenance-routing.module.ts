import {Ng2StateDeclaration, RootModule, UIRouterModule} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {NgModule} from '@angular/core';
import {MaintenanceStates} from './maintenance-states';

const MAINTENANCE_TEAM_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.MAINTENANCE_TEAMS.name + '.**',
  url: RouteConstants.MAINTENANCE_TEAMS.url,
  loadChildren: () => import('app/home/maintenance/maintenance-team/maintenance-team.module').then(m => m.MaintenanceTeamModule)
};

const MAINTENANCE_ACTIVITY_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.MAINTENANCE_ACTIVITY.name + '.**',
  url: RouteConstants.MAINTENANCE_ACTIVITY.url,
  loadChildren: () => import('app/home/maintenance/maintenance-activity/maintenance-activity.module').then(m => m.MaintenanceActivityModule)
};

const maintenanceRoutes: RootModule = {
  states: [
    ...MaintenanceStates,
    MAINTENANCE_TEAM_MODULE,
    MAINTENANCE_ACTIVITY_MODULE
  ],
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(maintenanceRoutes)],
  exports: [UIRouterModule]
})
export class MaintenanceRoutingModule {
}
