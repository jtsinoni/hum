import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {MaintenanceComponent} from './maintenance.component';
import {TECHNICIAN_MODULE} from './technician/technician-states';
import {REFERENCE_DATA_MODULE} from './reference-data/reference-data-states';
import {MaintenanceProcedureComponent} from './maintenance-procedure/maintenance-procedure.component';
import {MedicalEquipmentMaintenanceProceduresComponent} from './maintenance-procedure/view/medical-equipment-maintenance-procedures/medical-equipment-maintenance-procedures.component';
import {MedicalEquipmentMaintenanceProcedureNewComponent} from './maintenance-procedure/view/medical-equipment-maintenance-procedure-new/medical-equipment-maintenance-procedure-new.component';
import {MedicalEquipmentMaintenanceProcedureDetailsComponent} from './maintenance-procedure/view/medical-equipment-maintenance-procedure-details/medical-equipment-maintenance-procedure-details.component';
import {MedicalEquipmentMaintenanceProcedureChecklistComponent} from './maintenance-procedure/view/medical-equipment-maintenance-procedure-checklist/medical-equipment-maintenance-procedure-checklist.component';


export const MAINTENANCE_ROOT: Ng2StateDeclaration = {
  url: RouteConstants.MAINTENANCE_ROOT.url,
  name: RouteConstants.MAINTENANCE_ROOT.name,
  abstract: true,
  component: MaintenanceComponent,
  data: {'route': RouteConstants.MAINTENANCE_ROOT}
};

export const MAINTENANCE_PROCEDURES: Ng2StateDeclaration = {
  url: RouteConstants.MAINTENANCE_PROCEDURES.url,
  name: RouteConstants.MAINTENANCE_PROCEDURES.name,
  component: MaintenanceProcedureComponent,
  data: {'route': RouteConstants.MAINTENANCE_PROCEDURES}
};

export const MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURES: Ng2StateDeclaration = {
  url: RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURES.url,
  name: RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURES.name,
  component: MedicalEquipmentMaintenanceProceduresComponent,
  data: {'route': RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURES}
};

export const MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_NEW: Ng2StateDeclaration = {
  url: RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_NEW.url,
  name: RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_NEW.name,
  component: MedicalEquipmentMaintenanceProcedureNewComponent,
  data: {'route': RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_NEW}
};

export const MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_DETAILS.url,
  name: RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_DETAILS.name,
  component: MedicalEquipmentMaintenanceProcedureDetailsComponent,
  data: {'route': RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_DETAILS},
  params: {'id': null, 'refresh': null, 'selectedTab': null, 'timestamp': null} // 'timestamp' is to force refresh of page/state after an update is made
};

export const MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_CHECKLIST: Ng2StateDeclaration = {
  url: RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_CHECKLIST.url,
  name: RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_CHECKLIST.name,
  component: MedicalEquipmentMaintenanceProcedureChecklistComponent,
  data: {'route': RouteConstants.MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_CHECKLIST},
  params: {'id': null}
};

export const MaintenanceStates = [
  MAINTENANCE_ROOT,
  TECHNICIAN_MODULE,
  REFERENCE_DATA_MODULE,
  MAINTENANCE_PROCEDURES,
  MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURES,
  MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_NEW,
  MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_DETAILS,
  MEDICAL_EQUIPMENT_MAINTENANCE_PROCEDURE_CHECKLIST
];
