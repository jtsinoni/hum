import {Ng2StateDeclaration} from '@uirouter/angular';
import {UtilitiesComponent} from './utilities.component';
import {BusinessContactsComponent} from './business-contacts/business-contacts.component';
import {NewBusinessContactComponent} from './business-contacts/views/new-business-contact/new-business-contact.component';
import {BusinessContactDetailsComponent} from './business-contacts/views/business-contact-details/business-contact-details.component';
import {CustomFieldsComponent} from './custom-fields/custom-fields.component';
import {TagManagementComponent} from './tag-management/views/tag-management/tag-management.component';
import {RouteUtilitiesConstants} from './constants/route-utilities.constants.ts';
import {TransactionHistoryShellComponent} from './transaction-history/views/transaction-history-shell/transaction-history-shell.component';
import {TransactionHistoryDetailsComponent} from './transaction-history/views/transaction-history-details/transaction-history-details.component';
import {MaterialManagementArchiveDetailsComponent} from './transaction-history/components/material-management-archive-details/material-management-archive-details.component';
import {EquipmentArchiveTransactionDetailsComponent} from './transaction-history/components/equipment-archive-transaction-details/equipment-archive-transaction-details.component';

const UTILITIES_MODULE: Ng2StateDeclaration = {
  name: RouteUtilitiesConstants.UTILITIES_ROOT.name + '.**',
  url: RouteUtilitiesConstants.UTILITIES_ROOT.url,
  loadChildren: () => import('app/home/utilities/utilities.module').then(m => m.UtilitiesModule)
};

export const UTILITIES: Ng2StateDeclaration = {
  url: RouteUtilitiesConstants.UTILITIES_ROOT.url,
  name: RouteUtilitiesConstants.UTILITIES_ROOT.name,
  abstract: true,
  component: UtilitiesComponent,
  data: {'route': RouteUtilitiesConstants.UTILITIES_ROOT}
};

export const BUSINESS_CONTACTS: Ng2StateDeclaration = {
  url: RouteUtilitiesConstants.BUSINESS_CONTACTS.url,
  name: RouteUtilitiesConstants.BUSINESS_CONTACTS.name,
  component: BusinessContactsComponent,
  data: {'route': RouteUtilitiesConstants.BUSINESS_CONTACTS}
};

export const NEW_BUSINESS_CONTACT: Ng2StateDeclaration = {
  url: RouteUtilitiesConstants.NEW_BUSINESS_CONTACT.url,
  name: RouteUtilitiesConstants.NEW_BUSINESS_CONTACT.name,
  component: NewBusinessContactComponent,
  data: {'route': RouteUtilitiesConstants.NEW_BUSINESS_CONTACT}
};

export const BUSINESS_CONTACT_DETAILS: Ng2StateDeclaration = {
  url: RouteUtilitiesConstants.BUSINESS_CONTACT_DETAILS.url,
  name: RouteUtilitiesConstants.BUSINESS_CONTACT_DETAILS.name,
  component: BusinessContactDetailsComponent,
  data: {'route': RouteUtilitiesConstants.BUSINESS_CONTACT_DETAILS}
};

export const TRANSACTION_HISTORY_SHELL: Ng2StateDeclaration = {
  url: RouteUtilitiesConstants.TRANSACTION_HISTORY_SHELL.url,
  name: RouteUtilitiesConstants.TRANSACTION_HISTORY_SHELL.name,
  component: TransactionHistoryShellComponent,
  data: {'route': RouteUtilitiesConstants.TRANSACTION_HISTORY_SHELL}
};

export const TRANSACTION_HISTORY_DETAILS: Ng2StateDeclaration = {
  url: RouteUtilitiesConstants.TRANSACTION_HISTORY_DETAILS.url,
  name: RouteUtilitiesConstants.TRANSACTION_HISTORY_DETAILS.name,
  component: TransactionHistoryDetailsComponent,
  data: {'route': RouteUtilitiesConstants.TRANSACTION_HISTORY_DETAILS},
  params: {
    'id': null,
    'area': null
  }
};

export const EQUIPMENT_ARCHIVE_TRANSACTION_DETAILS: Ng2StateDeclaration = {
  url: RouteUtilitiesConstants.EQUIPMENT_ARCHIVE_TRANSACTION_DETAILS.url,
  name: RouteUtilitiesConstants.EQUIPMENT_ARCHIVE_TRANSACTION_DETAILS.name,
  component: EquipmentArchiveTransactionDetailsComponent,
  data: {'route': RouteUtilitiesConstants.EQUIPMENT_ARCHIVE_TRANSACTION_DETAILS},
  params: {
    'transactionSerial': null,
    'dodaac': null,
    'documentNumber': null,
    'transactionCode': null
  }
};

export const MM_ARCHIVE_TRANSACTION_DETAILS: Ng2StateDeclaration = {
  url: RouteUtilitiesConstants.MM_ARCHIVE_TRANSACTION_DETAILS.url,
  name: RouteUtilitiesConstants.MM_ARCHIVE_TRANSACTION_DETAILS.name,
  component: MaterialManagementArchiveDetailsComponent,
  data: {'route': RouteUtilitiesConstants.MM_ARCHIVE_TRANSACTION_DETAILS},
  params: {
    'id': null
  }
};

export const CUSTOM_FIELDS: Ng2StateDeclaration = {
  url: RouteUtilitiesConstants.CUSTOM_FIELDS.url,
  name: RouteUtilitiesConstants.CUSTOM_FIELDS.name,
  component: CustomFieldsComponent,
  data: {'route': RouteUtilitiesConstants.CUSTOM_FIELDS}
};

export const TAG_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteUtilitiesConstants.TAG_MANAGEMENT.url,
  name: RouteUtilitiesConstants.TAG_MANAGEMENT.name,
  component: TagManagementComponent,
  data: {'route': RouteUtilitiesConstants.TAG_MANAGEMENT}
};

export const UtilityStates: Ng2StateDeclaration[] = [
  UTILITIES,
  BUSINESS_CONTACTS,
  TRANSACTION_HISTORY_SHELL,
  TRANSACTION_HISTORY_DETAILS,
  EQUIPMENT_ARCHIVE_TRANSACTION_DETAILS,
  MM_ARCHIVE_TRANSACTION_DETAILS,
  NEW_BUSINESS_CONTACT,
  BUSINESS_CONTACT_DETAILS,
  CUSTOM_FIELDS,
  TAG_MANAGEMENT
];
