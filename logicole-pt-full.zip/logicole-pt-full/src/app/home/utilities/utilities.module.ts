import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {UtilitiesComponent} from './utilities.component';
import {BusinessContactDetailsComponent} from './business-contacts/views/business-contact-details/business-contact-details.component';
import {BusinessContactsComponent} from './business-contacts/business-contacts.component';
import {NewBusinessContactSkillComponent} from './business-contacts/components/new-business-contact-skill/new-business-contact-skill.component';
import {NewBusinessContactSkillsComponent} from './business-contacts/components/new-business-contact-skills/new-business-contact-skills.component';
import {NewBusinessContactInformationComponent} from './business-contacts/components/new-business-contact-information/new-business-contact-information.component';
import {NewBusinessContactContactComponent} from './business-contacts/components/new-business-contact-contact/new-business-contact-contact.component';
import {NewBusinessContactAddressComponent} from './business-contacts/components/new-business-contact-address/new-business-contact-address.component';
import {NewBusinessContactComponent} from './business-contacts/views/new-business-contact/new-business-contact.component';
import {NewBusinessContactContactsComponent} from './business-contacts/components/new-business-contact-contacts/new-business-contact-contacts.component';
import {BusinessContactInformationComponent} from './business-contacts/components/business-contact-information/business-contact-information.component';
import {BusinessContactSkillsComponent} from './business-contacts/components/business-contact-skills/business-contact-skills.component';
import {BusinessContactContactsComponent} from './business-contacts/components/business-contact-contacts/business-contact-contacts.component';
import {BusinessContactContactComponent} from './business-contacts/components/business-contact-contact/business-contact-contact.component';
import {BusinessContactAddressComponent} from './business-contacts/components/business-contact-address/business-contact-address.component';
import {BusinessContactSkillComponent} from './business-contacts/components/business-contact-skill/business-contact-skill.component';
import {BusinessContactsService} from './business-contacts/services/business-contacts.service';
import {UtilitiesRoutingModule} from './utilities-routing.module';
import {CommonComponentsModule} from '@lc-common-components';
import {DirectivesModule} from '../../directives/directives.module';
import {FormsModule} from '@angular/forms';
import {PaginationModule} from 'ngx-bootstrap/pagination';
import {TooltipModule} from 'ngx-bootstrap/tooltip';
import {PipesModule} from '../../pipes/pipes.module';
import {OrganizationComponentModule} from '../organization/organization-component.module';
import {BusinessContactsApiService} from './business-contacts/services/business-contacts-api-service';
import {CustomFieldsComponent} from './custom-fields/custom-fields.component';
import {TagManagementComponent} from './tag-management/views/tag-management/tag-management.component';
import {LiveTransactionHistoryComponent} from './transaction-history/components/live-transaction-history-data/live-transaction-history.component';
import {MaterielManagementArchiveDataComponent} from './transaction-history/components/material-management-archive-data/materiel-management-archive-data.component';
import {TransactionHistoryShellComponent} from './transaction-history/views/transaction-history-shell/transaction-history-shell.component';
import {TransactionHistoryDetailsComponent} from './transaction-history/views/transaction-history-details/transaction-history-details.component';
import {FinanceBusinessEventDetailsComponent} from './transaction-history/components/business-event-details/finance-business-event-details/finance-business-event-details.component';
import {EquipmentBusinessEventDetailsComponent} from './transaction-history/components/business-event-details/equipment-business-event-details/equipment-business-event-details.component';
import {MaterialManagementArchiveDetailsComponent} from './transaction-history/components/material-management-archive-details/material-management-archive-details.component';
import {EquipmentArchiveDataComponent} from './transaction-history/components/equipment-archive-data/equipment-archive-data.component';
import {EquipmentArchiveTransactionDetailsComponent} from './transaction-history/components/equipment-archive-transaction-details/equipment-archive-transaction-details.component';
import {WorkOrderBusinessEventDetailsComponent} from './transaction-history/components/business-event-details/real-property-business-event-details/work-order-business-event-details/work-order-business-event-details.component';
import {ProjectBusinessEventDetailsComponent} from './transaction-history/components/business-event-details/real-property-business-event-details/project-business-event-details/project-business-event-details.component';
import {RequirementBusinessEventDetailsComponent} from './transaction-history/components/business-event-details/real-property-business-event-details/requirement-business-event-details/requirement-business-event-details.component';
import {OrderBusinessEventDetailsComponent} from './transaction-history/components/business-event-details/order-business-event-details/order-business-event-details.component';
import { LiveTransactionHistoryProjectComponent } from './transaction-history/components/live-transaction-history-data/live-transaction-history-project/live-transaction-history-project.component';
import { LiveTransactionHistoryRequirementComponent } from './transaction-history/components/live-transaction-history-data/live-transaction-history-requirement/live-transaction-history-requirement.component';
import {LiveTransactionHistoryWorkOrderComponent} from "./transaction-history/components/live-transaction-history-data/live-transaction-history-work-order/live-transaction-history-work-order.component";

@NgModule({
  declarations: [
    UtilitiesComponent,
    BusinessContactsComponent,
    BusinessContactDetailsComponent,
    BusinessContactInformationComponent,
    BusinessContactAddressComponent,
    BusinessContactContactComponent,
    BusinessContactContactsComponent,
    BusinessContactSkillsComponent,
    BusinessContactSkillComponent,
    NewBusinessContactComponent,
    NewBusinessContactAddressComponent,
    NewBusinessContactContactComponent,
    NewBusinessContactInformationComponent,
    NewBusinessContactSkillsComponent,
    NewBusinessContactSkillComponent,
    NewBusinessContactContactsComponent,
    CustomFieldsComponent,
    TagManagementComponent,
    LiveTransactionHistoryComponent,
    MaterielManagementArchiveDataComponent,
    TransactionHistoryShellComponent,
    TransactionHistoryDetailsComponent,
    FinanceBusinessEventDetailsComponent,
    EquipmentBusinessEventDetailsComponent,
    MaterialManagementArchiveDetailsComponent,
    EquipmentArchiveDataComponent,
    EquipmentArchiveTransactionDetailsComponent,
    WorkOrderBusinessEventDetailsComponent,
    ProjectBusinessEventDetailsComponent,
    RequirementBusinessEventDetailsComponent,
    OrderBusinessEventDetailsComponent,
    LiveTransactionHistoryProjectComponent,
    LiveTransactionHistoryRequirementComponent,
    LiveTransactionHistoryWorkOrderComponent
  ],
  imports: [
    CommonModule,
    CommonComponentsModule.forRoot(),
    DirectivesModule,
    FormsModule,
    PaginationModule.forRoot(),
    PipesModule.forRoot(),
    TooltipModule.forRoot(),
    OrganizationComponentModule,
    UtilitiesRoutingModule
  ],
  providers: [
    BusinessContactsService,
    BusinessContactsApiService
  ]
})
export class UtilitiesModule { }
