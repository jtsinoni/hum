import {RootModule, UIRouterModule} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {NgModule} from '@angular/core';
import {UtilityStates} from './utilities-states';

const utilityRoutes: RootModule = {
  states: UtilityStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(utilityRoutes)],
  exports: [UIRouterModule],
})
export class UtilitiesRoutingModule {
}
