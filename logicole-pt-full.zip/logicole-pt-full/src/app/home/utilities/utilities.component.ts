import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-utilities',
  templateUrl: './utilities.component.html'
})
export class UtilitiesComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
