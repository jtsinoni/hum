import { NgModule } from '@angular/core';
import {OrganizationComponent} from './organization.component';
import {OrganizationManagementComponent} from './organization-management/organization-management.component';
import {OrganizationServicesComponent} from './components/organization-services/organization-services.component';
import {OrganizationRefListComponent} from './organization-ref-list/organization-ref-list.component';
import {UIRouterModule} from '@uirouter/angular';
import {CommonModule} from '@angular/common';
import {PipesModule} from '../../pipes/pipes.module';
import {FormsModule} from '@angular/forms';
import {CommonComponentsModule} from '@lc-common-components';
import {OrganizationTreeStructureComponent} from './components/organization-tree-structure/organization-tree-structure.component';
import {AddUpdateConsumerComponent} from './components/add-update-consumer/add-update-consumer.component';
import {ConsumersComponent} from './components/consumers/consumers.component';
import {OrganizationRoleServicesManagementComponent} from './organization-role-services-management/organization-role-services-management.component';
import {InvOwnersModule} from '../inventory/inv-owners/inv-owners.module';
import {DirectivesModule} from '../../directives/directives.module';
import {BuyerAccountCreateComponent} from './organization-role-services-management/buyer/views/buyer-account-create/buyer-account-create.component';
import {BuyerInfoComponent} from './organization-role-services-management/buyer/components/buyer-info.component';
import {BuyerShippingAddressComponent} from './organization-role-services-management/buyer/components/buyer-shipping-address.component';
import {BuyerContactComponent} from './organization-role-services-management/buyer/components/buyer-contact.component';
import {BuyerAssociatedBuyerAccountComponent} from './organization-role-services-management/buyer/components/buyer-associated-buyer-account.component';
import {BuyerExpenseCenterComponent} from './organization-role-services-management/buyer/components/buyer-expense-center.component';
import {BuyerCodesComponent} from './organization-role-services-management/buyer/components/buyer-codes.component';
import {BuyerDetailsComponent} from './organization-role-services-management/buyer/buyer-details/buyer-details.component';
import {BuyerAccountConfigurationComponent} from './organization-role-services-management/buyer/buyer-details/buyer-accounts/buyer-account-configuration/buyer-account-configuration.component';
import {NewBuyerAccountComponent} from './organization-role-services-management/buyer/buyer-details/buyer-accounts/new-buyer-account/new-buyer-account.component';
import {SupplierListComponent} from './organization-role-services-management/buyer/buyer-details/buyer-accounts/new-buyer-account/supplier-list.component';
import {BuyerAccountComponent} from './organization-role-services-management/buyer/buyer-details/buyer-accounts/buyer-account.component';
import {OrderComponentModule} from '../order/order-component.module';
import {BusinessServicesDefinitionComponent} from './business-services/business-services-definition/business-services-definition.component';
import {EngagementModelDefinitionsComponent} from './business-services/components/engagement-model-definitions/engagement-model-definitions.component';
import {BusinessServiceDefinitionAddUpdateComponent} from './business-services/components/business-service-definition-add-update/business-service-definition-add-update.component';
import {OrganizationBusinessServicesComponent} from './components/organization-business-services/organization-business-services.component';
import {ProviderManagementComponent} from './provider-management/provider-management.component';
import {AddUpdateProviderComponent} from './components/add-update-provider/add-update-provider.component';
import {FinanceCommonComponentsModule} from '../finance/common-components/finance-common-components.module';
import {OrganizationTestComponent} from './organization-test/organization-test.component';
import {ConsumerProviderWorkflowComponent} from './components/consumer-provider-workflow/consumer-provider-workflow.component';
import {MarketDetailsComponent} from './components/market-details/market-details.component';
import {OrganizationDataUploadComponent} from './components/organization-data-upload/organization-data-upload.component';
import {OrgMiscellaneousDetailsComponent} from './components/org-miscellaneous-details/org-miscellaneous-details.component';


@NgModule({
  declarations: [
    AddUpdateConsumerComponent,
    AddUpdateProviderComponent,
    ConsumersComponent,
    OrganizationComponent,
    OrganizationManagementComponent,
    OrganizationServicesComponent,
    OrganizationRefListComponent,
    OrganizationTreeStructureComponent,
    OrganizationRoleServicesManagementComponent,
    OrganizationTestComponent,
    BuyerAccountCreateComponent,
    BuyerInfoComponent,
    BuyerShippingAddressComponent,
    BuyerContactComponent,
    BuyerAssociatedBuyerAccountComponent,
    BuyerExpenseCenterComponent,
    BuyerCodesComponent,
    BuyerDetailsComponent,
    BuyerAccountConfigurationComponent,
    NewBuyerAccountComponent,
    ProviderManagementComponent,
    SupplierListComponent,
    BuyerAccountComponent,
    BusinessServicesDefinitionComponent,
    EngagementModelDefinitionsComponent,
    BusinessServiceDefinitionAddUpdateComponent,
    OrganizationBusinessServicesComponent,
    ConsumerProviderWorkflowComponent,
    MarketDetailsComponent,
    OrgMiscellaneousDetailsComponent,
    OrganizationDataUploadComponent,
  ],
    imports: [
        UIRouterModule,
        CommonModule,
        PipesModule,
        FormsModule,
        DirectivesModule,
        CommonComponentsModule.forRoot(),
        CommonComponentsModule,
        OrderComponentModule,
        InvOwnersModule,
        FinanceCommonComponentsModule
    ],
  exports: [
    AddUpdateConsumerComponent,
    AddUpdateProviderComponent,
    BusinessServicesDefinitionComponent,
    BusinessServiceDefinitionAddUpdateComponent,
    ConsumersComponent,
    EngagementModelDefinitionsComponent,
    OrganizationComponent,
    OrganizationManagementComponent,
    OrganizationServicesComponent,
    OrganizationRefListComponent,
    OrganizationTreeStructureComponent,
    OrganizationRoleServicesManagementComponent,
    OrganizationTreeStructureComponent,
    OrganizationTestComponent,
    ProviderManagementComponent
  ]
})
export class OrganizationComponentModule { }
