import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {OrganizationComponent} from './organization.component';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {a11yTests, prettyPrintA11Y} from '../../accessibility';
import {LoggerService} from '@lc-logger-service';

describe('OrganizationComponent', () => {
  let component: OrganizationComponent;
  let fixture: ComponentFixture<OrganizationComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule],
      declarations: [OrganizationComponent],
      providers: [LoggerService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrganizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      a11yTests(fixture.nativeElement)
        .then((results) => {
          expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
        })
        .catch((error) => {
          loggerService.error(`${error}`);
        });
    }));
  });
});
