import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {OrganizationManagementComponent} from './organization-management/organization-management.component';
import {OrganizationComponent} from './organization.component';
import {AddUpdateConsumerComponent} from './components/add-update-consumer/add-update-consumer.component';
import {OrganizationRoleServicesManagementComponent} from './organization-role-services-management/organization-role-services-management.component';
import {BuyerAccountComponent} from './organization-role-services-management/buyer/buyer-details/buyer-accounts/buyer-account.component';
import {SupplierListComponent} from './organization-role-services-management/buyer/buyer-details/buyer-accounts/new-buyer-account/supplier-list.component';
import {NewBuyerAccountComponent} from './organization-role-services-management/buyer/buyer-details/buyer-accounts/new-buyer-account/new-buyer-account.component';
import {BuyerAccountCreateComponent} from './organization-role-services-management/buyer/views/buyer-account-create/buyer-account-create.component';
import {BusinessServicesDefinitionComponent} from './business-services/business-services-definition/business-services-definition.component';
import {BusinessServiceDefinitionAddUpdateComponent} from './business-services/components/business-service-definition-add-update/business-service-definition-add-update.component';
import {ProviderManagementComponent} from './provider-management/provider-management.component';
import {AddUpdateProviderComponent} from './components/add-update-provider/add-update-provider.component';
import {OrganizationTestComponent} from './organization-test/organization-test.component';
import {OrganizationDataUploadComponent} from './components/organization-data-upload/organization-data-upload.component';

export const ORGANIZATION_ROOT: Ng2StateDeclaration = {
  abstract: true,
  url: RouteConstants.ORGANIZATION_ROOT.url,
  name: RouteConstants.ORGANIZATION_ROOT.name,
  component: OrganizationComponent,
  data: {'route': RouteConstants.ORGANIZATION_ROOT}
};

export const ORGANIZATION_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.ORGANIZATION_MANAGEMENT.url,
  name: RouteConstants.ORGANIZATION_MANAGEMENT.name,
  component: OrganizationManagementComponent,
  data: {'route': RouteConstants.ORGANIZATION_MANAGEMENT},
};
export const ORGANIZATION_DATA_UPLOAD: Ng2StateDeclaration = {
  url: RouteConstants.ORGANIZATION_DATA_UPLOAD.url,
  name: RouteConstants.ORGANIZATION_DATA_UPLOAD.name,
  component: OrganizationDataUploadComponent,
  data: {'route': RouteConstants.ORGANIZATION_DATA_UPLOAD},
};
export const ORGANIZATION_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.ORGANIZATION_VIEW.url,
  name: RouteConstants.ORGANIZATION_VIEW.name,
  component: OrganizationManagementComponent,
  data: {'route': RouteConstants.ORGANIZATION_VIEW},
};

export const ORGANIZATION_CONSUMER_ADD_UPDATE: Ng2StateDeclaration = {
  url: RouteConstants.ORGANIZATION_CONSUMER_ADD_UPDATE.url,
  name: RouteConstants.ORGANIZATION_CONSUMER_ADD_UPDATE.name,
  component: AddUpdateConsumerComponent,
  data: {'route': RouteConstants.ORGANIZATION_CONSUMER_ADD_UPDATE},
};

export const ORGANIZATION_SERVICES: Ng2StateDeclaration = {
  url: RouteConstants.ORGANIZATION_SERVICES.url,
  name: RouteConstants.ORGANIZATION_SERVICES.name,
  component: OrganizationRoleServicesManagementComponent,
  data: {'route': RouteConstants.ORGANIZATION_SERVICES},
};
export const ORGANIZATION_SERVICES_CUSTOMER_SUPPLIER_ACCOUNTS: Ng2StateDeclaration = {
  url: RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_SUPPLIER_ACCOUNTS.url,
  name: RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_SUPPLIER_ACCOUNTS.name,
  component: BuyerAccountComponent,
  data: {'route': RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_SUPPLIER_ACCOUNTS},
};
export const ORGANIZATION_SERVICES_CUSTOMER_SELECT_NEW_SUPPLIER: Ng2StateDeclaration = {
  url: RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_SELECT_NEW_SUPPLIER.url,
  name: RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_SELECT_NEW_SUPPLIER.name,
  component: SupplierListComponent,
  data: {'route': RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_SELECT_NEW_SUPPLIER},
};
export const ORGANIZATION_SERVICES_CUSTOMER_NEW_SUPPLIER_ACCOUNT: Ng2StateDeclaration = {
  url: RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_NEW_SUPPLIER_ACCOUNT.url,
  name: RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_NEW_SUPPLIER_ACCOUNT.name,
  component: NewBuyerAccountComponent,
  data: {'route': RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_NEW_SUPPLIER_ACCOUNT},
};
export const ORGANIZATION_SERVICES_CUSTOMER_NEW_CUSTOMER: Ng2StateDeclaration = {
  url: RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_NEW_CUSTOMER.url,
  name: RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_NEW_CUSTOMER.name,
  component: BuyerAccountCreateComponent,
  data: {'route': RouteConstants.ORGANIZATION_SERVICES_CUSTOMER_NEW_CUSTOMER},
};

export const BUSINESS_SERVICE_DEFINITION_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.BUSINESS_SERVICE_DEFINITION_MANAGEMENT.url,
  name: RouteConstants.BUSINESS_SERVICE_DEFINITION_MANAGEMENT.name,
  component: BusinessServicesDefinitionComponent,
  data: {'route': RouteConstants.BUSINESS_SERVICE_DEFINITION_MANAGEMENT},
};

export const BUSINESS_SERVICE_DEFINITION_ADD_UPDATE: Ng2StateDeclaration = {
  url: RouteConstants.BUSINESS_SERVICE_DEFINITION_ADD_UPDATE.url,
  name: RouteConstants.BUSINESS_SERVICE_DEFINITION_ADD_UPDATE.name,
  component: BusinessServiceDefinitionAddUpdateComponent,
  data: {'route': RouteConstants.BUSINESS_SERVICE_DEFINITION_ADD_UPDATE},
};

export const PROVIDER_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.PROVIDER_MANAGEMENT.url,
  name: RouteConstants.PROVIDER_MANAGEMENT.name,
  component: ProviderManagementComponent,
  data: {'route': RouteConstants.PROVIDER_MANAGEMENT},
};

export const PROVIDER_ADD_UPDATE: Ng2StateDeclaration = {
  url: RouteConstants.PROVIDER_ADD_UPDATE.url,
  name: RouteConstants.PROVIDER_ADD_UPDATE.name,
  component: AddUpdateProviderComponent,
  data: {'route': RouteConstants.PROVIDER_ADD_UPDATE},
};

export const ORGANIZATION_TESTING: Ng2StateDeclaration = {
  url: RouteConstants.ORGANIZATION_TESTING.url,
  name: RouteConstants.ORGANIZATION_TESTING.name,
  component: OrganizationTestComponent,
  data: {'route': RouteConstants.ORGANIZATION_TESTING},
};


export const ORGANIZATION_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.ORGANIZATION_ROOT.name + '.**',
  url: RouteConstants.ORGANIZATION_ROOT.url,
  loadChildren: () => import('app/home/organization/organization.module').then(m => m.OrganizationModule)
};

export const OrganizationStates: Ng2StateDeclaration[] = [
  ORGANIZATION_ROOT,
  ORGANIZATION_MANAGEMENT,
  ORGANIZATION_VIEW,
  ORGANIZATION_DATA_UPLOAD,
  ORGANIZATION_CONSUMER_ADD_UPDATE,
  ORGANIZATION_SERVICES,
  ORGANIZATION_SERVICES_CUSTOMER_SUPPLIER_ACCOUNTS,
  ORGANIZATION_SERVICES_CUSTOMER_SELECT_NEW_SUPPLIER,
  ORGANIZATION_SERVICES_CUSTOMER_NEW_SUPPLIER_ACCOUNT,
  ORGANIZATION_SERVICES_CUSTOMER_NEW_CUSTOMER,
  ORGANIZATION_TESTING,
  BUSINESS_SERVICE_DEFINITION_MANAGEMENT,
  BUSINESS_SERVICE_DEFINITION_ADD_UPDATE,
  PROVIDER_MANAGEMENT,
  PROVIDER_ADD_UPDATE
];
