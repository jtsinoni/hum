import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-organization',
  templateUrl: './organization.component.html'
})
export class OrganizationComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
