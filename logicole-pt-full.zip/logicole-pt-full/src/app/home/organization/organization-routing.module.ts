import {RootModule, UIRouterModule} from '@uirouter/angular';
import {NgModule} from '@angular/core';
import {OrganizationStates} from './organization-states';

const organizationRoutes: RootModule = {
  states: OrganizationStates
};

@NgModule({
  imports: [UIRouterModule.forChild(organizationRoutes)],
  exports: [UIRouterModule]
})

export class OrganizationRoutingModule {
}
