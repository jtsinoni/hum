import {NgModule} from '@angular/core';
import {OrganizationManagementComponent} from './organization-management/organization-management.component';
import {OrganizationApiService} from './services/organization-api.service';
import {OrganizationService} from './services/organization.service';
import {OrganizationRefListComponent } from './organization-ref-list/organization-ref-list.component';
import {OrganizationRoutingModule} from './organization-routing.module';
import {LoggerService} from '@lc-logger-service';
import {OrganizationComponentModule} from './organization-component.module';

@NgModule({
  imports: [
    OrganizationRoutingModule,
    OrganizationComponentModule
  ],

  declarations: [


  ],
  exports: [OrganizationManagementComponent, OrganizationRefListComponent],
  providers: [
    OrganizationService,
    OrganizationApiService
  ]
})
export class OrganizationModule {
  constructor(private logger: LoggerService) {
    this.logger.debug('In Org module ####');
  }
}
