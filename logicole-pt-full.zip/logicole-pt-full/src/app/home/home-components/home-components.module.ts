import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AboutComponent} from './about.component';
import {MyProfileComponent} from './my-profile.component';
import {LoadingComponent} from './loading.component';
import {PipesModule} from '../../pipes/pipes.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {UIRouterModule} from '@uirouter/angular';
import {BreadcrumbComponent} from '../home-header/breadcrumb.component';
import {TreeModule} from '@circlon/angular-tree-component';
import {CommonComponentsModule} from '@lc-common-components';
import {AssemblageDashboardConfigurationComponent} from './dashboard-configuration/assemblage-dashboard-configuration/assemblage-dashboard-configuration.component';
import {DirectivesModule} from '../../directives/directives.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    PipesModule,
    UIRouterModule,
    TreeModule,
    CommonComponentsModule.forRoot(),
    DirectivesModule
  ],
  declarations: [
    AboutComponent,
    MyProfileComponent,
    LoadingComponent,
    BreadcrumbComponent,
    AssemblageDashboardConfigurationComponent,
  ],
  exports: [AboutComponent,
    MyProfileComponent,
    LoadingComponent,
    BreadcrumbComponent,
  ]
})
export class HomeComponentsModule {
}
