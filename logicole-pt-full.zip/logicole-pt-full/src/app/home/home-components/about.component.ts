import { Component, OnInit } from '@angular/core';
import {environment} from '../../../environments/environment';
import {VersionInformation} from './models/version-information';
import {SystemApiService} from '../../services/system-api.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html'
})
export class AboutComponent implements OnInit {

  public ptBuildVersion: string = environment.version;
  public ptBuildDate: string = environment.date;
  public btVersionInfo: VersionInformation[];
  public dbVersionInfo: VersionInformation;

  constructor(private systemApiService: SystemApiService) { }

  public ngOnInit() {
    this.getVersionInfo();
  }

  private getVersionInfo() {
    this.systemApiService.getSystemVersionInformation().subscribe(data => {
      this.btVersionInfo = data;
    });
    this.systemApiService.getDatabaseVersionInformation().subscribe(data => {
      this.dbVersionInfo = data;
    });
  }
}
