import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {LoadingComponent} from './loading.component';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {LoggerService} from '@lc-services/*';

describe('LoadingComponent', () => {
  let component: LoadingComponent;
  let fixture: ComponentFixture<LoadingComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [LoadingComponent], providers: [LoggerService]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      a11yTests(fixture.nativeElement)
        .then((results) => {
          expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
        })
        .catch((error) => {
          loggerService.error(`${error}`);
        });
    }));
  });
});
