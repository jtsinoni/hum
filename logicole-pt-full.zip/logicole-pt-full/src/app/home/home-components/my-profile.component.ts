import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {LoggerService, LoginService, NotificationService, ProfileApiService, ProfileService, StateNavigationService} from '@lc-services/*';
import {ChangeProfileAccessComponent} from '@lc-common-components';
import {RouteConstants} from '@lc-constants/*';
import {RoleApiService} from '../../services/role-api.service';
import {PermissionApiService} from '../../services/permission-api.service';
import {TreeComponent} from '@circlon/angular-tree-component';
import {NgForm} from '@angular/forms';
import {UtilService} from '../../services/util.service';
import {finalize, takeUntil} from 'rxjs/operators';
import {PermissionService} from '../../services/permission.service';
import {UserProfile} from '@lc-app-models';
import {ElementAssemblageConstants} from '../assemblage/constants/element-assemblage.constants';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html'
})
export class MyProfileComponent extends ChangeProfileAccessComponent implements OnInit, OnDestroy {

  public userProfileRoleNodes: any[];
  public userProfileAssignableRoleNodes: any[];
  public editing: boolean = false;
  public editProfile: UserProfile;
  public profileValid: boolean;
  public isAllAssignableRoles: boolean = false;

  public assemblageManagementCollapsed: boolean = false;
  public assemblageManagementDisplay: boolean = false;

  public areRolesLoading: boolean = false;
  public areAssignableRolesLoading: boolean = false;

  @ViewChild('tree') public tree: TreeComponent;
  @ViewChild('assignableRolesTree') public assignableRolesTree: TreeComponent;
  @ViewChild('myProfileForm') public myProfileForm: NgForm;

  constructor(public loginService: LoginService,
              protected logger: LoggerService,
              public profileService: ProfileService,
              private profileApiService: ProfileApiService,
              private notificationService: NotificationService,
              protected navigationService: StateNavigationService,
              private roleApiService: RoleApiService,
              private permissionApiService: PermissionApiService,
              protected permissionService: PermissionService,
              private utilService: UtilService) {
    super(logger, profileService, navigationService, permissionService);
  }

  public ngOnInit(): void {
    if (this.loginService.getCurrentUser()
      && this.loginService.getCurrentUser().profile) {
      this.isAllAssignableRoles = this.loginService.getCurrentUser().profile.isAllAssignableRoles;
    }
    this.profileService.initSignedInProfile()
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        this.loadUserProfileRoleNodes();
        this.loadUserProfileAssignableRoleNodes();
      });
    this.setDisplayIndicators();
  }

  public ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.complete();
  }

  public loadUserProfileRoleNodes(): void {
    this.areRolesLoading = true;
    this.userProfileRoleNodes = [];
    const roleIds = this.profileService.currRoles.map(roleRef => roleRef.id);
    this.roleApiService.getRoles(roleIds)
      .pipe(
        finalize(() => {
          this.areRolesLoading = false;
        }),
        takeUntil(this.destroy$))
      .subscribe(roles => {
      roles.forEach(role => {
        const childrenPerms = [];
        role.assignedPermissions.filter(perm => !perm.name.endsWith('Endpoints')).forEach(perm => {
          childrenPerms.push({
            id: role.id + perm.id,
            name: perm.name,
            description: 'Permission',
            nodeType: 'permission',
            hasChildren: true,
            children: [],
            permissionId: perm.id
          });
        });
        this.userProfileRoleNodes.push({
          id: role.id,
          name: role.name,
          description: role.description,
          hasChildren: true,
          children: childrenPerms,
          nodeType: 'role',
          roleId: role.id
        });
      });
      if (this.tree && this.tree.treeModel) {
        this.tree.treeModel.update();
      }
    });
  }

  public loadUserProfileAssignableRoleNodes(): void {
    this.areAssignableRolesLoading = true;
    this.userProfileAssignableRoleNodes = [];
    const assignableRoleIds = this.profileService.currAssignableRoles.map(assignableRoleRef => assignableRoleRef.id);
    this.roleApiService.getRoles(assignableRoleIds)
      .pipe(
        finalize(() => {
          this.areAssignableRolesLoading = false;
        }),
        takeUntil(this.destroy$))
      .subscribe(assignableRoles => {
      assignableRoles.forEach(assignableRole => {
        const childrenPerms = [];
        assignableRole.assignedPermissions.filter(perm => !perm.name.endsWith('Endpoints')).forEach(perm => {
          childrenPerms.push({
            id: assignableRole.id + perm.id,
            name: perm.name,
            description: 'Permission',
            nodeType: 'permission',
            hasChildren: true,
            children: [],
            permissionId: perm.id
          });
        });
        this.userProfileAssignableRoleNodes.push({
          id: assignableRole.id,
          name: assignableRole.name,
          description: assignableRole.description,
          hasChildren: true,
          children: childrenPerms,
          nodeType: 'role',
          roleId: assignableRole.id
        });
      });
      if (this.assignableRolesTree && this.assignableRolesTree.treeModel) {
        this.assignableRolesTree.treeModel.update();
      }
    });
  }

  public startEditProfile(): void {
    this.profileApiService.getUserProfileById(this.loginService.getCurrentUser().profile.id).subscribe(userProfile => {
      this.editProfile = userProfile;
      this.editing = true;
    });
  }

  public changeMyProfile(event): void {
    this.changeProfile(this.profileService.selectedProfile.id, RouteConstants.MY_PROFILE);
  }

  public changeMyAccess(event): void {
    this.changeAccess(event, RouteConstants.MY_PROFILE);
  }

  public onEvent(event, isAssignableRoles?: boolean): void {
    if (event.isExpanded && !event.node.data.children.length) {
      if (event.node.data.nodeType === 'permission') {
        this.loadPermissionDetails(event, isAssignableRoles);
      }
    }
  }

  private loadPermissionDetails(event, isAssignableRoles?: boolean): void {
    this.permissionApiService.getPermission(event.node.data.permissionId).subscribe(perm => {
      if (perm.stateRefs) {
        perm.stateRefs.forEach(state => {
          event.node.data.children.push({
            id: perm.id + state.id,
            name: state.name,
            description: 'State/View'
          });
        });
      }

      if (!perm.stateRefs) {
        event.node.data.hasChildren = false;
      }

      if (!perm.elementRefs && !perm.stateRefs) {
        event.node.data.hasChildren = false;
      }

      if (isAssignableRoles) {
        if (this.assignableRolesTree && this.assignableRolesTree.treeModel) {
          this.assignableRolesTree.treeModel.update();
        }
      } else {
        if (this.tree && this.tree.treeModel) {
          this.tree.treeModel.update();
        }
      }
    });
  }

  public isValid(): boolean {
    let isMatchAndUserMadeEdits: boolean;
    const currPro = this.loginService.getCurrentUser().profile;
    if (currPro) {
      isMatchAndUserMadeEdits = (currPro.profileName === this.editProfile.profileName) &&
        (currPro.firstName === this.editProfile.firstName) && (currPro.lastName === this.editProfile.lastName) &&
        (currPro.email === this.editProfile.email) && (this.editProfile.phoneNumbers[0].value === currPro.phoneNumbers[0].value);
    }
    this.profileValid = this.myProfileForm.valid && !isMatchAndUserMadeEdits;

    return this.profileValid;
  }

  public saveProfile() {
    if (this.isValid()) {
      this.profileApiService.updateMyProfileInfo(this.editProfile).subscribe((uProfile) => {
        this.editProfile = <UserProfile>{...uProfile};
        this.loginService.updateCurrentUser(this.editProfile);
        this.notificationService.successMsg('Profile Updated');
        this.editing = false;
      });
    } else {
      if (this.myProfileForm.invalid) {
        this.notificationService.errorMsgWithHtml(this.utilService.getFormValidationError(this.myProfileForm));
      } else {
        this.notificationService.warningMsg('You have not made any updates to your profile. Please update at least one field before saving.');
      }
      this.editing = false;
    }
  }

  public cancelEdits() {
    this.editProfile = null;
    this.editing = false;
    this.profileValid = false;
  }

  private setDisplayIndicators() {
    this.assemblageManagementDisplay = this.permissionService.checkElements(ElementAssemblageConstants.ASSEMBLAGE_VIEW);
  }
}
