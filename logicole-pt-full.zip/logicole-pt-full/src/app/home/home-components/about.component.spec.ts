import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {AboutComponent} from './about.component';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {LoggerService} from '@lc-services/*';
import {PipesModule} from '../../pipes/pipes.module';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {SystemApiService} from '../../services/system-api.service';
import {SystemApiServiceMock} from '../../services/system-api.service.mock';

describe('AboutComponent', () => {
  let component: AboutComponent;
  let fixture: ComponentFixture<AboutComponent>;
  let loggerService: LoggerService;


  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [PipesModule.forRoot()],
      declarations: [AboutComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        {provide: SystemApiService, useClass: SystemApiServiceMock},
        LoggerService
      ]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      a11yTests(fixture.nativeElement)
        .then((results) => {
          expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
        })
        .catch((error) => {
          loggerService.error(`${error}`);
        });
    }));
  });
});
