import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {MyProfileComponent} from './my-profile.component';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {PipesModule} from '../../pipes/pipes.module';
import {LoggerService, LoginService, NotificationService, ProfileApiService, ProfileService, StateNavigationService} from '@lc-services/*';
import {MainNavService} from '../main-nav/main-nav.service';
import {CurrentUserProfile} from '@lc-app-models';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {PermissionApiService} from '../../services/permission-api.service';
import {PermissionApiServiceMock} from '../../services/permission-api.service.mock';
import {RoleApiService} from '../../services/role-api.service';
import {RoleApiServiceMock} from '../../services/role-api.service.mock';
import {ProfileServiceMock} from '../../services/core/profile.service.mock';
import {ProfileApiServiceMock} from '../../services/core/profile-api.service.mock';
import {StateNavigationServiceMock} from '../../services/state-navigation.service.mock';
import {NotificationServiceMock} from '../../services/core/notification.service.mock';
import {MainNavServiceMock} from '../main-nav/main-nav.service.mock';
import {UtilService} from '../../services/util.service';
import {DmlesSimpleTreeService} from '@lc-common-components';
import {TreeDragDirective, TreeModule} from '@circlon/angular-tree-component';
import {NgxBootstrapModule} from '../../common-components/ngx-bootstrap/ngx-bootstrap.module';
import {UtilServiceMock} from '../../services/util.service.mock';
import {PermissionService} from '../../services/permission.service';
import {PermissionServiceMock} from '../../services/permission.service.mock';

export class LoginServiceMock {
  private _currentUser: CurrentUserProfile = new CurrentUserProfile();

  constructor () {
    this._currentUser.profile.phoneNumbers.push('301-555-1212');
  }

  public getCurrentUser() {
    return this._currentUser;
  }
}

describe('MyProfileComponent', () => {
  let component: MyProfileComponent;
  let fixture: ComponentFixture<MyProfileComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        PipesModule,
        TreeModule,
        NgxBootstrapModule.forRoot()
      ],
      declarations: [ MyProfileComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        DmlesSimpleTreeService,
        TreeDragDirective,
        {provide: ProfileService, useClass: ProfileServiceMock},
        {provide: MainNavService, useClass: MainNavServiceMock},
        {provide: ProfileApiService, useClass: ProfileApiServiceMock},
        {provide: NotificationService, useClass: NotificationServiceMock},
        {provide: StateNavigationService, useClass: StateNavigationServiceMock},
        {provide: LoginService, useClass: LoginServiceMock},
        {provide: PermissionService, useClass: PermissionServiceMock},
        {provide: PermissionApiService, useClass: PermissionApiServiceMock, useValue: {}},
        {provide: RoleApiService, useClass: RoleApiServiceMock, useValue: {}},
        LoggerService,
        {provide: UtilService, useClass: UtilServiceMock}
      ]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      a11yTests(fixture.nativeElement)
        .then((results) => {
          expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
        })
        .catch((error) => {
          loggerService.error(`${error}`);
        });
    }));
  });
});
