import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-inventory',
  templateUrl: './inventory.component.html',
})
export class InventoryComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
