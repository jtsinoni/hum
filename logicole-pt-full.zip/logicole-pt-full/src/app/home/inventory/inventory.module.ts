import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CommonComponentsModule} from '@lc-common-components';
import {InvRecSearchModule} from './inv-rec-search/inv-rec-search.module';
import {InvManagementModule} from './inv-management/inv-management.module';
import {InvStorageLocationsModule} from './inv-storage-locations/inv-storage-locations.module';
import {InvLocationsModule} from './inv-locations/inv-locations.module';
import {InvOwnersModule} from './inv-owners/inv-owners.module';
import {InvAuditModule} from './inv-audit/inv-audit.module';
import {InvShippingModule} from './inv-shipping/inv-shipping.module';
import {InvExcessModule} from './inv-excess/inv-excess.module';
import {InvPlanningModule} from './inv-planning/inv-planning.module';
import {InvLogbayModule} from './inv-logbay/inv-logbay.module';
import {InvReturnModule} from './inv-return/inv-return.module';
import {FormsModule} from '@angular/forms';
import { InventoryComponent } from './inventory.component';
import {InventoryRoutingModule} from './inventory-routing.module';
import {DirectivesModule} from '../../directives/directives.module';
import {InvReplenishmentModule} from './inv-replenishment/inv-replenishment.module';
import {InventorySystemSearchModule} from './inventory-detail-search/inventory-system-search.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule,
    DirectivesModule,
    InvOwnersModule,
    InvManagementModule,
    InvStorageLocationsModule,
    InvLocationsModule,
    InvRecSearchModule,
    InventorySystemSearchModule,
    InvExcessModule,
    InvLogbayModule,
    InvAuditModule,
    InvPlanningModule,
    InvShippingModule,
    InvReturnModule,
    InventoryRoutingModule,
    InvReplenishmentModule

  ],
  declarations: [InventoryComponent],
})
export class InventoryModule {
}
