import { NgModule } from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {InventoryStates} from './inventory-states';
const invRoutes: RootModule = {
  states: InventoryStates
};

@NgModule({
  imports: [UIRouterModule.forChild(invRoutes)],
  exports: [UIRouterModule]
})
export class InventoryRoutingModule { }
