import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {InvAuditComponent} from './inv-audit/inv-audit.component';
import {InvAuditScheduledCreateComponent} from './inv-audit/inv-audit-scheduled-create/inv-audit-scheduled-create.component';
import {InvAuditScheduledDetailsComponent} from './inv-audit/inv-audit-scheduled-details/inv-audit-scheduled-details.component';
import {InvAuditProgressDetailsComponent} from './inv-audit/inv-audit-progress-details/inv-audit-progress-details.component';
import {InvAuditResearchDetailsComponent} from './inv-audit/inv-audit-research-details/inv-audit-research-details.component';
import {InvAuditFinalizeDetailsComponent} from './inv-audit/inv-audit-finalize-details/inv-audit-finalize-details.component';
import {InvAuditCompletedDetailsComponent} from './inv-audit/inv-audit-completed-details/inv-audit-completed-details.component';
import {InvAuditCancelledDetailsComponent} from './inv-audit/inv-audit-cancelled-details/inv-audit-cancelled-details.component';
import {InvExcessReportComponent} from './inv-excess/inv-excess-report/inv-excess-report.component';
import {InvExcessReportDetailsComponent} from './inv-excess/inv-excess-report/inv-excess-report-details/inv-excess-report-details.component';
import {InvMyExcessReportsDetailsComponent} from './inv-excess/inv-excess-report/inv-my-excess-reports-details/inv-my-excess-reports-details.component';
import {InvExcessRequestComponent} from './inv-excess/inv-excess-request/inv-excess-request.component';
import {InvExcessRequestDetailsComponent} from './inv-excess/inv-excess-request/inv-excess-request-details/inv-excess-request-details.component';
import {InvExcessRequestStatusComponent} from './inv-excess/inv-excess-request/inv-excess-request-status/inv-excess-request-status.component';
import {InvExcessCustomerRequestDetailsComponent} from './inv-excess/inv-excess-request/inv-excess-customer-request-details/inv-excess-customer-request-details.component';
import {InvLogbayManagerComponent} from './inv-logbay/inv-logbay-manager/inv-logbay-manager.component';
import {InvLogbayItemDetailsComponent} from './inv-logbay/inv-logbay-item-details/inv-logbay-item-details.component';
import {InvLogbaySearchComponent} from './inv-logbay/inv-logbay-search/inv-logbay-search.component';
import {InvManagementComponent} from './inv-management/inv-management.component';
import {InvOwnerDetailsComponent} from './inv-owners/inv-owner-details/inv-owner-details.component';
import {InvRecDetailsComponent} from './inv-rec-search/inv-rec-details/inv-rec-details.component';
import {InvRecLocDetailsComponent} from './inv-rec-search/inv-rec-loc-details/inv-rec-loc-details.component';
import {InvStorageLocationAddComponent} from './inv-storage-locations/inv-storage-location-add/inv-storage-location-add.component';
import {InvOwnersComponent} from './inv-owners/inv-owners.component';
import {InvPlanningComponent} from './inv-planning/inv-planning.component';
import {InvPlanningDetailsComponent} from './inv-planning/inv-planning-details/inv-planning-details.component';
import {InvRecSearchComponent} from './inv-rec-search/inv-rec-search.component';
import {InvRecAddComponent} from './inv-rec-search/inv-rec-add/inv-rec-add.component';
import {InvReturnComponent} from './inv-return/inv-return.component';
import {InvReturnPickupDetailsComponent} from './inv-return/inv-return-pickup-details/inv-return-pickup-details.component';
import {InvReturnActionTypeDetailsComponent} from './inv-return/inv-return-action-type-details/inv-return-action-type-details.component';
import {InvReturnFinalReviewComponent} from './inv-return/inv-return-final-review/inv-return-final-review.component';
import {InvReturnCompleteComponent} from './inv-return/inv-return-complete/inv-return-complete.component';
import {InvShippingComponent} from './inv-shipping/inv-shipping.component';
import {InvShipmentDetailsComponent} from './inv-shipping/inv-shipment-details/inv-shipment-details.component';
import {InvShippersComponent} from './inv-shipping/inv-shippers/inv-shippers.component';
import {InvShipperAddComponent} from './inv-shipping/inv-shipper-add/inv-shipper-add.component';
import {InvShipperDetailsComponent} from './inv-shipping/inv-shipper-details/inv-shipper-details.component';
import {InventoryComponent} from './inventory.component';
import {InvRecAccountabilityComponent} from './inv-rec-accountability/inv-rec-accountability.component';
import {InvRecAccountabilityDetailsComponent} from './inv-rec-accountability/inv-rec-accountability-details/inv-rec-accountability-details.component';
import {InvRecLocAccountabilityDetailsComponent} from './inv-rec-accountability/inv-rec-loc-accountability-details/inv-rec-loc-accountability-details.component';
import {InvReplenishmentComponent} from './inv-replenishment/inv-replenishment.component';

import {InventoryDetailsComponent} from './inventory-detail-search/inventory-details/inventory-details.component';

export const INVENTORY_ROOT: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_ROOT.url,
  name: RouteConstants.INVENTORY_ROOT.name,
  component: InventoryComponent, data: {'route': RouteConstants.INVENTORY_ROOT}
};

export const INVENTORY_AUDIT: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_AUDIT.url,
  name: RouteConstants.INVENTORY_AUDIT.name,
  component: InvAuditComponent,
  data: {'route': RouteConstants.INVENTORY_AUDIT},
};

export const INVENTORY_AUDIT_SCHEDULED_CREATE: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_AUDIT_SCHEDULED_CREATE.url,
  name: RouteConstants.INVENTORY_AUDIT_SCHEDULED_CREATE.name,
  component: InvAuditScheduledCreateComponent,
  data: {'route': RouteConstants.INVENTORY_AUDIT_SCHEDULED_CREATE},
};

export const INVENTORY_AUDIT_SCHEDULED_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_AUDIT_SCHEDULED_DETAILS.url,
  name: RouteConstants.INVENTORY_AUDIT_SCHEDULED_DETAILS.name,
  component: InvAuditScheduledDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_AUDIT_SCHEDULED_DETAILS},
};

export const INVENTORY_AUDIT_INPROGRESS_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_AUDIT_INPROGRESS_DETAILS.url,
  name: RouteConstants.INVENTORY_AUDIT_INPROGRESS_DETAILS.name,
  component: InvAuditProgressDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_AUDIT_INPROGRESS_DETAILS},
};

export const INVENTORY_AUDIT_RESEARCH_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_AUDIT_RESEARCH_DETAILS.url,
  name: RouteConstants.INVENTORY_AUDIT_RESEARCH_DETAILS.name,
  component: InvAuditResearchDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_AUDIT_RESEARCH_DETAILS},
};

export const INVENTORY_AUDIT_FINALIZE_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_AUDIT_FINALIZE_DETAILS.url,
  name: RouteConstants.INVENTORY_AUDIT_FINALIZE_DETAILS.name,
  component: InvAuditFinalizeDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_AUDIT_FINALIZE_DETAILS},
};

export const INVENTORY_AUDIT_COMPLETED_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_AUDIT_COMPLETED_DETAILS.url,
  name: RouteConstants.INVENTORY_AUDIT_COMPLETED_DETAILS.name,
  component: InvAuditCompletedDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_AUDIT_COMPLETED_DETAILS},
};

export const INVENTORY_AUDIT_CANCELLED_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_AUDIT_CANCELLED_DETAILS.url,
  name: RouteConstants.INVENTORY_AUDIT_CANCELLED_DETAILS.name,
  component: InvAuditCancelledDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_AUDIT_CANCELLED_DETAILS},
};

export const INVENTORY_POTENTIAL_EXCESS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_POTENTIAL_EXCESS.url,
  name: RouteConstants.INVENTORY_POTENTIAL_EXCESS.name,
  component: InvExcessReportComponent,
  data: {'route': RouteConstants.INVENTORY_POTENTIAL_EXCESS},
};

export const INVENTORY_POTENTIAL_EXCESS_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_POTENTIAL_EXCESS_DETAILS.url,
  name: RouteConstants.INVENTORY_POTENTIAL_EXCESS_DETAILS.name,
  component: InvExcessReportDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_POTENTIAL_EXCESS_DETAILS},
};

export const INVENTORY_MY_EXCESS_REPORT_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_MY_EXCESS_REPORT_DETAILS.url,
  name: RouteConstants.INVENTORY_MY_EXCESS_REPORT_DETAILS.name,
  component: InvMyExcessReportsDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_MY_EXCESS_REPORT_DETAILS},
};

export const INVENTORY_SITE_EXCESS_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT.url,
  name: RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT.name,
  component: InvExcessRequestComponent,
  data: {'route': RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT},
};

export const INVENTORY_RETURN: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_RETURNS.url,
  name: RouteConstants.INVENTORY_RETURNS.name,
  component: InvReturnComponent,
  data: {'route': RouteConstants.INVENTORY_RETURNS},
};

export const INVENTORY_RETURN_PICKUP_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_RETURN_PICKUP_DETAILS.url,
  name: RouteConstants.INVENTORY_RETURN_PICKUP_DETAILS.name,
  component: InvReturnPickupDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_RETURN_PICKUP_DETAILS},
};

export const INVENTORY_RETURN_ACTION_TYPE_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_RETURN_ACTION_TYPE_DETAILS.url,
  name: RouteConstants.INVENTORY_RETURN_ACTION_TYPE_DETAILS.name,
  component: InvReturnActionTypeDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_RETURN_ACTION_TYPE_DETAILS},
};

export const INVENTORY_RETURN_FINAL_REVIEW: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_RETURN_FINAL_REVIEW.url,
  name: RouteConstants.INVENTORY_RETURN_FINAL_REVIEW.name,
  component: InvReturnFinalReviewComponent,
  data: {'route': RouteConstants.INVENTORY_RETURN_FINAL_REVIEW},
};

export const INVENTORY_RETURN_COMPLETE: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_RETURN_COMPLETE.url,
  name: RouteConstants.INVENTORY_RETURN_COMPLETE.name,
  component: InvReturnCompleteComponent,
  data: {'route': RouteConstants.INVENTORY_RETURN_COMPLETE},
};


export const INVENTORY_SITE_EXCESS_MANAGEMENT_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT_DETAILS.url,
  name: RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT_DETAILS.name,
  component: InvExcessRequestDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT_DETAILS},
};

export const INVENTORY_SITE_EXCESS_MANAGEMENT_STATUS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT_STATUS.url,
  name: RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT_STATUS.name,
  component: InvExcessRequestStatusComponent,
  data: {'route': RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT_STATUS},
};

export const INVENTORY_CUSTOMER_EXCESS_MANAGEMENT_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_CUSTOMER_EXCESS_MANAGEMENT_DETAILS.url,
  name: RouteConstants.INVENTORY_CUSTOMER_EXCESS_MANAGEMENT_DETAILS.name,
  component: InvExcessCustomerRequestDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_CUSTOMER_EXCESS_MANAGEMENT_DETAILS},
};

export const INVENTORY_ENTERPRISE_EXCESS_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_MANAGEMENT.url,
  name: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_MANAGEMENT.name,
  component: InvLogbayManagerComponent,
  data: {'route': RouteConstants.INVENTORY_ENTERPRISE_EXCESS_MANAGEMENT},
};

export const INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_MANAGER: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_MANAGER.url,
  name: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_MANAGER.name,
  component: InvLogbayItemDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_MANAGER},
};

export const INVENTORY_ENTERPRISE_EXCESS_SHIPMENT_STATUS_DETAILS_FROM_MANAGER: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_SHIPMENT_STATUS_DETAILS_FROM_MANAGER.url,
  name: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_SHIPMENT_STATUS_DETAILS_FROM_MANAGER.name,
  component: InvLogbayItemDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_ENTERPRISE_EXCESS_SHIPMENT_STATUS_DETAILS_FROM_MANAGER},
};

export const INVENTORY_ENTERPRISE_EXCESS_DELINQUENT_ITEM_DETAILS_FROM_MANAGER: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_DELINQUENT_ITEM_DETAILS_FROM_MANAGER.url,
  name: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_DELINQUENT_ITEM_DETAILS_FROM_MANAGER.name,
  component: InvLogbayItemDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_ENTERPRISE_EXCESS_DELINQUENT_ITEM_DETAILS_FROM_MANAGER},
};

export const INVENTORY_ENTERPRISE_EXCESS_ITEM_HISTORY_DETAILS_FROM_MANAGER: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_ITEM_HISTORY_DETAILS_FROM_MANAGER.url,
  name: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_ITEM_HISTORY_DETAILS_FROM_MANAGER.name,
  component: InvLogbayItemDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_ENTERPRISE_EXCESS_ITEM_HISTORY_DETAILS_FROM_MANAGER},
};

export const INVENTORY_ENTERPRISE_EXCESS_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_SEARCH.url,
  name: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_SEARCH.name,
  component: InvLogbaySearchComponent,
  data: {'route': RouteConstants.INVENTORY_ENTERPRISE_EXCESS_SEARCH},
};
export const INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_SEARCH.url,
  name: RouteConstants.INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_SEARCH.name,
  component: InvLogbayItemDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_SEARCH},
};

export const INVENTORY_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_MANAGEMENT.url,
  name: RouteConstants.INVENTORY_MANAGEMENT.name,
  component: InvManagementComponent,
  data: {'route': RouteConstants.INVENTORY_MANAGEMENT},
};

// export const INVENTORY_OWNER_DETAILS_FROM_INVENTORY_MANAGEMENT: Ng2StateDeclaration = {
//   url: RouteConstants.INVENTORY_OWNER_DETAILS_FROM_INVENTORY_MANAGEMENT.url,
//   name: RouteConstants.INVENTORY_OWNER_DETAILS_FROM_INVENTORY_MANAGEMENT.name,
//   component: InvOwnerDetailsComponent,
//   data: {'route': RouteConstants.INVENTORY_OWNER_DETAILS_FROM_INVENTORY_MANAGEMENT},
// };

export const INVENTORY_REC_DETAILS_FROM_INVENTORY_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_DETAILS_FROM_INVENTORY_MANAGEMENT.url,
  name: RouteConstants.INVENTORY_REC_DETAILS_FROM_INVENTORY_MANAGEMENT.name,
  component: InvRecDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_REC_DETAILS_FROM_INVENTORY_MANAGEMENT},
};

export const INVENTORY_REC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT.url,
  name: RouteConstants.INVENTORY_REC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT.name,
  component: InvRecAccountabilityDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_REC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT},
};

export const INVENTORY_REC_LOC_DETAILS_FROM_INVENTORY_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_LOC_DETAILS_FROM_INVENTORY_MANAGEMENT.url,
  name: RouteConstants.INVENTORY_REC_LOC_DETAILS_FROM_INVENTORY_MANAGEMENT.name,
  component: InvRecLocDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_REC_LOC_DETAILS_FROM_INVENTORY_MANAGEMENT},
};


export const INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT.url,
  name: RouteConstants.INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT.name,
  component: InvRecLocAccountabilityDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT},
};

export const INVENTORY_STORAGE_AREA_CREATE: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_STORAGE_LOCATION_ADD_UPDATE.url,
  name: RouteConstants.INVENTORY_STORAGE_LOCATION_ADD_UPDATE.name,
  component: InvStorageLocationAddComponent,
  data: {'route': RouteConstants.INVENTORY_STORAGE_LOCATION_ADD_UPDATE},
  params: {
    'fromItemDetails': false
  }
};

export const INVENTORY_OWNERS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_SYSTEMS.url,
  name: RouteConstants.INVENTORY_SYSTEMS.name,
  component: InvOwnersComponent,
  data: {'route': RouteConstants.INVENTORY_SYSTEMS},
};

export const INVENTORY_OWNER_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_OWNER_DETAILS.url,
  name: RouteConstants.INVENTORY_OWNER_DETAILS.name,
  component: InvOwnerDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_OWNER_DETAILS},
  params: {'mode': null},
};
export const INVENTORY_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_DETAILS.url,
  name: RouteConstants.INVENTORY_DETAILS.name,
  component: InventoryDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_DETAILS},
  params: {
    'fromInventoryDetails': true
  },
};

export const INVENTORY_PLANNING: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_PLANNING.url,
  name: RouteConstants.INVENTORY_PLANNING.name,
  component: InvPlanningComponent,
  data: {'route': RouteConstants.INVENTORY_PLANNING},
};

export const INVENTORY_PLANNING_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_PLANNING_DETAILS.url,
  name: RouteConstants.INVENTORY_PLANNING_DETAILS.name,
  component: InvPlanningDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_PLANNING_DETAILS},
};

export const INVENTORY_REC_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_SEARCH.url,
  name: RouteConstants.INVENTORY_REC_SEARCH.name,
  component: InvRecSearchComponent,
  data: {'route': RouteConstants.INVENTORY_REC_SEARCH}
};

export const INVENTORY_REC_ACCOUNTABILITY: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_ACCOUNTABILITY.url,
  name: RouteConstants.INVENTORY_REC_ACCOUNTABILITY.name,
  component: InvRecAccountabilityComponent,
  data: {'route': RouteConstants.INVENTORY_REC_ACCOUNTABILITY}
};

export const INVENTORY_REC_ACCOUNTABILITY_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_ACCOUNTABILITY_DETAILS.url,
  name: RouteConstants.INVENTORY_REC_ACCOUNTABILITY_DETAILS.name,
  component: InvRecAccountabilityDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_REC_ACCOUNTABILITY_DETAILS}
};

export const INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS.url,
  name: RouteConstants.INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS.name,
  component: InvRecLocAccountabilityDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS},
  params: {'mode': null},
};

export const INVENTORY_REC_ADD: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_ADD.url,
  name: RouteConstants.INVENTORY_REC_ADD.name,
  component: InvRecAddComponent,
  data: {'route': RouteConstants.INVENTORY_REC_ADD}
};

export const INVENTORY_REC_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_DETAILS.url,
  name: RouteConstants.INVENTORY_REC_DETAILS.name,
  component: InvRecDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_REC_DETAILS},
};

export const INVENTORY_REPLENISHMENT: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REPLENISHMENT.url,
  name: RouteConstants.INVENTORY_REPLENISHMENT.name,
  component: InvReplenishmentComponent,
  data: {'route': RouteConstants.INVENTORY_REPLENISHMENT},
};

export const INVENTORY_REC_DETAILS_NEW_LOCATION: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_NEW_LOCATION.url,
  name: RouteConstants.INVENTORY_REC_NEW_LOCATION.name,
  component: InvStorageLocationAddComponent, data: {'route': RouteConstants.INVENTORY_REC_NEW_LOCATION},
  params: {
    'fromItemDetails': false
  }
};

export const INVENTORY_REC_LOC_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_REC_LOC_DETAILS.url,
  name: RouteConstants.INVENTORY_REC_LOC_DETAILS.name,
  component: InvRecLocDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_REC_LOC_DETAILS},
};

export const INVENTORY_SHIPPING: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_SHIPPING.url,
  name: RouteConstants.INVENTORY_SHIPPING.name,
  component: InvShippingComponent,
  data: {'route': RouteConstants.INVENTORY_SHIPPING},
};

export const INVENTORY_SHIPMENT_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_SHIPMENT_DETAILS.url,
  name: RouteConstants.INVENTORY_SHIPMENT_DETAILS.name,
  component: InvShipmentDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_SHIPMENT_DETAILS},
};

export const INVENTORY_SHIPPERS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_SHIPPERS.url,
  name: RouteConstants.INVENTORY_SHIPPERS.name,
  component: InvShippersComponent,
  data: {'route': RouteConstants.INVENTORY_SHIPPERS},
};

export const INVENTORY_SHIPPER_ADD: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_SHIPPER_ADD.url,
  name: RouteConstants.INVENTORY_SHIPPER_ADD.name,
  component: InvShipperAddComponent,
  data: {'route': RouteConstants.INVENTORY_SHIPPER_ADD},
};

export const INVENTORY_SHIPPER_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.INVENTORY_SHIPPER_DETAILS.url,
  name: RouteConstants.INVENTORY_SHIPPER_DETAILS.name,
  component: InvShipperDetailsComponent,
  data: {'route': RouteConstants.INVENTORY_SHIPPER_DETAILS},
};



export const InventoryStates: Ng2StateDeclaration[] = [
  INVENTORY_ROOT,
  INVENTORY_AUDIT,
  INVENTORY_AUDIT_SCHEDULED_CREATE,
  INVENTORY_AUDIT_SCHEDULED_DETAILS,
  INVENTORY_AUDIT_INPROGRESS_DETAILS,
  INVENTORY_AUDIT_RESEARCH_DETAILS,
  INVENTORY_AUDIT_FINALIZE_DETAILS,
  INVENTORY_AUDIT_COMPLETED_DETAILS,
  INVENTORY_AUDIT_CANCELLED_DETAILS,
  INVENTORY_POTENTIAL_EXCESS,
  INVENTORY_POTENTIAL_EXCESS_DETAILS,
  INVENTORY_MY_EXCESS_REPORT_DETAILS,
  INVENTORY_SITE_EXCESS_MANAGEMENT,
  INVENTORY_SITE_EXCESS_MANAGEMENT_DETAILS,
  INVENTORY_SITE_EXCESS_MANAGEMENT_STATUS,
  INVENTORY_CUSTOMER_EXCESS_MANAGEMENT_DETAILS,
  INVENTORY_ENTERPRISE_EXCESS_MANAGEMENT,
  INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_MANAGER,
  INVENTORY_ENTERPRISE_EXCESS_SHIPMENT_STATUS_DETAILS_FROM_MANAGER,
  INVENTORY_ENTERPRISE_EXCESS_DELINQUENT_ITEM_DETAILS_FROM_MANAGER,
  INVENTORY_ENTERPRISE_EXCESS_ITEM_HISTORY_DETAILS_FROM_MANAGER,
  INVENTORY_ENTERPRISE_EXCESS_SEARCH,
  INVENTORY_ENTERPRISE_EXCESS_AVAILABLE_ITEM_DETAILS_FROM_SEARCH,
  INVENTORY_MANAGEMENT,
  INVENTORY_DETAILS,
  INVENTORY_REC_DETAILS_FROM_INVENTORY_MANAGEMENT,
  INVENTORY_REC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT,
  INVENTORY_REC_LOC_DETAILS_FROM_INVENTORY_MANAGEMENT,
  INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS_FROM_INVENTORY_MANAGEMENT,
  INVENTORY_STORAGE_AREA_CREATE,
  INVENTORY_OWNERS,
  INVENTORY_OWNER_DETAILS,
  INVENTORY_PLANNING,
  INVENTORY_PLANNING_DETAILS,
  INVENTORY_REC_SEARCH,
  INVENTORY_REC_ADD,
  INVENTORY_REC_ACCOUNTABILITY,
  INVENTORY_REC_ACCOUNTABILITY_DETAILS,
  INVENTORY_REC_LOC_ACCOUNTABILITY_DETAILS,
  INVENTORY_REC_DETAILS,
  INVENTORY_REC_DETAILS_NEW_LOCATION,
  INVENTORY_REC_LOC_DETAILS,
  INVENTORY_RETURN,
  INVENTORY_RETURN_PICKUP_DETAILS,
  INVENTORY_RETURN_ACTION_TYPE_DETAILS,
  INVENTORY_RETURN_FINAL_REVIEW,
  INVENTORY_RETURN_COMPLETE,
  INVENTORY_SHIPPING,
  INVENTORY_SHIPMENT_DETAILS,
  INVENTORY_SHIPPERS,
  INVENTORY_SHIPPER_ADD,
  INVENTORY_SHIPPER_DETAILS,
  INVENTORY_REPLENISHMENT

];
