import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-order',
  templateUrl: './order.component.html'
})
export class OrderComponent implements OnInit {

  constructor() { }

  public ngOnInit(): void {
  }

}
