import { NgModule } from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {OrderStates} from './order-states';


const orderRoutes: RootModule = {
  states:  OrderStates,
};

@NgModule({
  imports: [UIRouterModule.forChild(orderRoutes)],
  exports: [UIRouterModule]
})
export class OrderRouterModule {

}
