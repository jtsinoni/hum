import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {ViewOrderComponent} from './view-orders/view-order.component';
import {OrderDetailComponent} from './view-orders/order-detail/order-detail.component';
import {ListsComponent} from './lists/lists.component';
import {CartComponent} from './cart/cart.component';
import {CheckoutComponent} from './cart/checkout/checkout.component';
import {SummaryComponent} from './cart/checkout/summary.component';
import {SellerDetailsComponent} from './seller/seller-details/seller-details.component';
import {SellerComponent} from './seller/seller.component';
import {CatalogComponent} from './catalog/catalog-search/catalog.component';
import {NewCatalogItemComponent} from './catalog/catalog-search/new-catalog-item/new-catalog-item.component';
import {OrderComponent} from './order.component';
import {OrderSummaryFormGenerationComponent} from './components/order-summary-forms/order-summary-form-generation.component';
import {CartItemDetailsComponent} from "./cart/cart-item-details/cart-item-details.component";
import {CatalogDetailsComponent} from '../catalog/catalog-management/views/catalog-details/catalog-details.component';
import {DistributionReviewComponent} from './distribution-review/distribution-review.component';

export const ORDER_ROOT: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_ROOT.url,
  name: RouteConstants.ORDER_ROOT.name,
  abstract: true,
  component: OrderComponent, data: {'route': RouteConstants.ORDER_ROOT}
};

export const ORDER_CATALOG: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_CATALOG.url,
  name: RouteConstants.ORDER_CATALOG.name,
  component: CatalogComponent, data: {'route': RouteConstants.ORDER_CATALOG}
};
export const ORDER_CATALOG_ITEM_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_CATALOG_ITEM_DETAILS.url,
  name: RouteConstants.ORDER_CATALOG_ITEM_DETAILS.name,
  component: CatalogDetailsComponent, data: {'route': RouteConstants.ORDER_CATALOG_ITEM_DETAILS}
};

export const CART_CATALOG_ITEM_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.CART_CATALOG_ITEM_DETAILS.url,
  name: RouteConstants.CART_CATALOG_ITEM_DETAILS.name,
  component: CatalogDetailsComponent, data: {'route': RouteConstants.CART_CATALOG_ITEM_DETAILS}
};

export const ORDER_CATALOG_ONE_TIME_BUY: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_CATALOG_NON_CATALOG_PURCHASE.url,
  name: RouteConstants.ORDER_CATALOG_NON_CATALOG_PURCHASE.name,
  component: NewCatalogItemComponent, data: {'route': RouteConstants.ORDER_CATALOG_NON_CATALOG_PURCHASE}
};

export const ORDER_CART: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_CART.url,
  name: RouteConstants.ORDER_CART.name,
  component: CartComponent, data: {'route': RouteConstants.ORDER_CART}
};

export const ORDER_CART_ITEM_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_CART_ITEM_DETAILS.url,
  name: RouteConstants.ORDER_CART_ITEM_DETAILS.name,
  component: CartItemDetailsComponent, data: {'route': RouteConstants.ORDER_CART_ITEM_DETAILS}
};

export const ORDER_CART_CHECKOUT: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_CART_CHECKOUT.url,
  name: RouteConstants.ORDER_CART_CHECKOUT.name,
  component: CheckoutComponent, data: {'route': RouteConstants.ORDER_CART_CHECKOUT}
};

export const ORDER_REVIEW: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_REVIEW.url,
  name: RouteConstants.ORDER_REVIEW.name,
  component: DistributionReviewComponent, data: {'route': RouteConstants.ORDER_REVIEW}
};

export const ORDER_REVIEW_ITEM_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_REVIEW_ITEM_DETAILS.url,
  name: RouteConstants.ORDER_REVIEW_ITEM_DETAILS.name,
  component: CatalogDetailsComponent, data: {'route': RouteConstants.ORDER_REVIEW_ITEM_DETAILS}
};

export const ORDER_CART_SUMMARY: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_CART_SUMMARY.url,
  name: RouteConstants.ORDER_CART_SUMMARY.name,
  component: SummaryComponent, data: {'route': RouteConstants.ORDER_CART_SUMMARY}
};

export const ORDER_CART_SUMMARY_FORM_GENERATION: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_CART_SUMMARY_FORM_GENERATION.url,
  name: RouteConstants.ORDER_CART_SUMMARY_FORM_GENERATION.name,
  component: OrderSummaryFormGenerationComponent, data: {'route': RouteConstants.ORDER_CART_SUMMARY_FORM_GENERATION}
};

export const ORDER_CATALOG_NEW_SUPPLIER: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_CATALOG_NEW_SUPPLIER.url,
  name: RouteConstants.ORDER_CATALOG_NEW_SUPPLIER.name,
  component: SellerDetailsComponent, data: {'route': RouteConstants.ORDER_CATALOG_NEW_SUPPLIER}
};

// export const ORDER_LISTS: Ng2StateDeclaration = {
//   url: RouteConstants.ORDER_LISTS.url,
//   name: RouteConstants.ORDER_LISTS.name,
//   component: ListsComponent, data: {'route': RouteConstants.ORDER_LISTS}
// };

export const ORDER_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_VIEW.url,
  name: RouteConstants.ORDER_VIEW.name,
  component: ViewOrderComponent, data: {'route': RouteConstants.ORDER_VIEW}
};

export const ORDER_VIEW_DETAIL: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_VIEW_DETAIL.url,
  name: RouteConstants.ORDER_VIEW_DETAIL.name,
  component: OrderDetailComponent, data: {'route': RouteConstants.ORDER_VIEW_DETAIL},
  params: {'backToPage': null},
};

export const ORDER_VIEW_DETAIL_FORM_GENERATION: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_VIEW_DETAIL_FORM_GENERATION.url,
  name: RouteConstants.ORDER_VIEW_DETAIL_FORM_GENERATION.name,
  component: OrderSummaryFormGenerationComponent, data: {'route': RouteConstants.ORDER_VIEW_DETAIL_FORM_GENERATION}
};

export const ORDER_SELLER: Ng2StateDeclaration = {
  name: RouteConstants.ORDER_SELLER.name,
  url: RouteConstants.ORDER_SELLER.url,
  component: SellerComponent, data: {'route': RouteConstants.ORDER_SELLER}
};

export const ORDER_SELLER_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ORDER_SELLER_DETAILS.url,
  name: RouteConstants.ORDER_SELLER_DETAILS.name,
  component: SellerDetailsComponent, data: {'route': RouteConstants.ORDER_SELLER_DETAILS}
};


export const OrderStates: Ng2StateDeclaration[] = [
  ORDER_ROOT,
  ORDER_CATALOG,
  ORDER_CATALOG_ITEM_DETAILS,
  ORDER_CATALOG_ONE_TIME_BUY,
  ORDER_CART,
  CART_CATALOG_ITEM_DETAILS,
  ORDER_CART_ITEM_DETAILS,
  ORDER_REVIEW,
  ORDER_REVIEW_ITEM_DETAILS,
  ORDER_CART_CHECKOUT,
  ORDER_CART_SUMMARY,
  ORDER_CART_SUMMARY_FORM_GENERATION,
  ORDER_CATALOG_NEW_SUPPLIER,
//  ORDER_LISTS,
  ORDER_VIEW,
  ORDER_VIEW_DETAIL,
  ORDER_VIEW_DETAIL_FORM_GENERATION,
  ORDER_SELLER,
  ORDER_SELLER_DETAILS
];
