import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CommonComponentsModule} from '@lc-common-components';
import {PipesModule} from '../../pipes/pipes.module';
import {FormsModule} from '@angular/forms';
import {DirectivesModule} from '../../directives/directives.module';
import {OrderPipesModule} from './pipes/order-pipes.module';
import {InvOwnersModule} from '../inventory/inv-owners/inv-owners.module';
import {AbiManagementModule} from '../jmlfdc-admin/abi-management/abi-management.module';
import {CartComponent} from './cart/cart.component';
import {CartItemsComponent} from './cart/cart-items/cart-items.component';
import {CheckoutComponent} from './cart/checkout/checkout.component';
import {SummaryComponent} from './cart/checkout/summary.component';
import {ListsComponent} from './lists/lists.component';
import {ViewOrderComponent} from './view-orders/view-order.component';
import {OrderDetailComponent} from './view-orders/order-detail/order-detail.component';
import {ViewOrdersSearchPipe} from './view-orders/services/vieworder.pipe';
import {LcAddNewListMessageBoxComponent} from './components/lc-add-new-list-message-box.component';
import {LcAddBuyerAddressMessageBoxComponent} from './components/add-buyer-address-message-box/lc-add-buyer-address-message-box.component';
import {BuyerAccountService} from '../organization/organization-role-services-management/buyer/buyer-details/buyer-accounts/services/buyer-account.service';
import {UIRouterModule} from '@uirouter/angular';
import {FulfillmentComponentModule} from '../fulfillment/fulfillment-component.module';
import {SellerComponent} from './seller/seller.component';
import {SellerDetailsComponent} from './seller/seller-details/seller-details.component';
import {SellerAddressComponent} from './seller/configuration/seller-address.component';
import {SellerAssociatedBuyerAccountComponent} from './seller/configuration/seller-associated-buyer-account.component';
import {CatalogItemPipesModule} from './catalog/catalog-search/pipes/catalog-item-pipes.module';
import {CatalogComponent} from './catalog/catalog-search/catalog.component';
import {CatalogItemDetailsComponent} from './catalog/catalog-search/catalog-item-details/catalog-item-details.component';
import {NewCatalogItemComponent} from './catalog/catalog-search/new-catalog-item/new-catalog-item.component';
import {AddItemToCustomerCatalogComponent} from './catalog/catalog-search/add-item-to-customer-catalog/add-item-to-customer-catalog.component';
import {OrderComponent} from './order.component';
import {NgxBarcodeModule} from 'ngx-barcode';
import {OrderSummaryFormGenerationComponent} from './components/order-summary-forms/order-summary-form-generation.component';
import {OrderSummary1155FormComponent} from './components/order-summary-forms/order-summary-1155-form/order-summary-1155-form.component';
import {OrderSummary336OptionalFormComponent} from './components/order-summary-forms/order-summary-336-optional-form/order-summary-336-optional-form.component';
import {CartItemDetailsComponent} from "./cart/cart-item-details/cart-item-details.component";
import {CatalogComponentModule} from '../catalog/catalog-component.module';
import {DistributionReviewComponent} from './distribution-review/distribution-review.component';

@NgModule({
    imports: [
        UIRouterModule,
        CommonModule,
        CommonComponentsModule,
        PipesModule.forRoot(),
        CatalogItemPipesModule.forRoot(),
        FormsModule,
        DirectivesModule,
        OrderPipesModule,
        FulfillmentComponentModule,
        InvOwnersModule,
        AbiManagementModule,
        NgxBarcodeModule,
        CatalogComponentModule
    ],
  declarations: [
    OrderComponent,
    CatalogComponent,
    CatalogItemDetailsComponent,
    NewCatalogItemComponent,
    AddItemToCustomerCatalogComponent,
    CartComponent,
    CartItemsComponent,
    CartItemDetailsComponent,
    CheckoutComponent,
    SummaryComponent,
    DistributionReviewComponent,
    OrderSummaryFormGenerationComponent,
    OrderSummary1155FormComponent,
    OrderSummary336OptionalFormComponent,
    ListsComponent,
    ViewOrderComponent,
    OrderDetailComponent,
    ViewOrdersSearchPipe,
    LcAddNewListMessageBoxComponent,
    SellerComponent,
    SellerDetailsComponent,
    SellerAddressComponent,
    SellerAssociatedBuyerAccountComponent,
    LcAddBuyerAddressMessageBoxComponent],
  exports: [
    CatalogComponent,
    CatalogItemDetailsComponent,
    NewCatalogItemComponent,
    CartComponent,
    CartItemsComponent,
    CheckoutComponent,
    SummaryComponent,
    OrderSummaryFormGenerationComponent,
    OrderSummary1155FormComponent,
    ListsComponent,
    ViewOrderComponent,
    OrderDetailComponent,
    ViewOrdersSearchPipe,
    LcAddNewListMessageBoxComponent,
    SellerComponent,
    SellerDetailsComponent,
    SellerAddressComponent,
    SellerAssociatedBuyerAccountComponent,
    LcAddBuyerAddressMessageBoxComponent
  ],
  providers: [ViewOrdersSearchPipe, BuyerAccountService]
})
export class OrderComponentModule {
}
