import {NgModule} from '@angular/core';

import {ViewOrdersSearchPipe} from './view-orders/services/vieworder.pipe';
import {OrderRouterModule} from './order-router.module';
import {BuyerAccountService} from '../organization/organization-role-services-management/buyer/buyer-details/buyer-accounts/services/buyer-account.service';
import {OrderComponentModule} from './order-component.module';



@NgModule({
    imports: [
      OrderRouterModule,
      OrderComponentModule
    ],
  declarations: [
],
  exports: [

  ],
  providers: [ViewOrdersSearchPipe, BuyerAccountService]
})
export class OrderModule {
}
