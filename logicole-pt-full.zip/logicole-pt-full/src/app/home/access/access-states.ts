import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from 'app/constants/route.constants';
import {AccessComponent} from 'app/home/access/access.component';
import {ProfileManagementComponent} from './profile-management/views/profile-management/profile-management.component';
import {NewInvitationComponent} from './profile-management/views/new-invitation/new-invitation.component';
import {ProfileAccessComponent} from './profile-management/views/profile-access/profile-access.component';
import {ProfileRolesComponent} from './profile-management/views/profile-roles/profile-roles.component';
import {NewInvitationConfirmComponent} from './profile-management/views/new-invitation-confirm/new-invitation-confirm.component';
import {GroupInvitationInformationComponent} from './profile-management/views/group-invitation-information/group-invitation-information.component';
import {NewGroupInvitationConfirmComponent} from './profile-management/views/new-group-invitation-confirm/new-group-invitation-confirm.component';
import {NewGroupInvitationUrlComponent} from './profile-management/views/new-group-invitation-url/new-group-invitation-url.component';
import {ProfileComponent} from './profile-management/views/profile/profile.component';
import {ProfileIdentificationComponent} from './profile-management/components/profile-identification/profile-identification.component';
import {ProfileStatusComponent} from './profile-management/views/profile-status/profile-status.component';
import {ProfileInvitationComponent} from './profile-management/views/profile-invitation/profile-invitation.component';
import {NewRoleComponent} from './role-management/views/new-role/new-role.component';
import {RoleDetailsComponent} from './role-management/views/role-details/role-details.component';
import {PermissionsComponent} from './permission-management/views/permissions/permissions.component';
import {NewPermissionComponent} from './permission-management/views/new-permission/new-permission.component';
import {PermissionDetailsComponent} from './permission-management/views/permission-details/permission-details.component';
import {StatesComponent} from './permission-management/views/states/states.component';
import {EndpointsComponent} from './permission-management/views/endpoints/endpoints.component';
import {ElementsComponent} from './permission-management/views/elements/elements.component';
import {BiReportsComponent} from './permission-management/views/bireports/bi-reports.component';
import {RoleManagementComponent} from './role-management/views/role-management/role-management.component';
import {GroupInvitationComponent} from './profile-management/views/group-invitation/group-invitation.component';
import {RoleServiceManagementComponent} from './role-service-management/views/role-service-management/role-service-management.component';
import {NewRoleServiceComponent} from './role-service-management/views/new-role-service/new-role-service.component';
import {RoleServiceDetailsComponent} from './role-service-management/views/role-service-details/role-service-details.component';
import {PermissionManagementComponent} from './permission-management/permission-management.component';
import {UserRequestManagementComponent} from './user-request-management/user-request-management.component';
import {UserRequestComponent} from './user-request-management/views/user-request/user-request.component';

export const ACCESS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_ROOT.url,
  name: RouteConstants.ACCESS_ROOT.name,
  component: AccessComponent,
  abstract: true,
  data: {'route': RouteConstants.ACCESS_ROOT}
};
export const ACCESS_USER_REQUEST_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_USER_REQUEST_MANAGEMENT.url, name: RouteConstants.ACCESS_USER_REQUEST_MANAGEMENT.name,
  component: UserRequestManagementComponent, data: {'route': RouteConstants.ACCESS_USER_REQUEST_MANAGEMENT}
};
export const ACCESS_USER_REQUEST: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_USER_REQUEST.url, name: RouteConstants.ACCESS_USER_REQUEST.name,
  component: UserRequestComponent, data: {'route': RouteConstants.ACCESS_USER_REQUEST}
};
export const ACCESS_PROFILE_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_PROFILE_MANAGEMENT.url, name: RouteConstants.ACCESS_PROFILE_MANAGEMENT.name,
  component: ProfileManagementComponent, data: {'route': RouteConstants.ACCESS_PROFILE_MANAGEMENT}
};
export const ACCESS_NEW_INVITATION: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_INVITATION.url, name: RouteConstants.ACCESS_NEW_INVITATION.name,
  component: NewInvitationComponent, data: {'route': RouteConstants.ACCESS_NEW_INVITATION}
};
export const ACCESS_NEW_INVITATION_ACCESS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_INVITATION_ACCESS.url, name: RouteConstants.ACCESS_NEW_INVITATION_ACCESS.name,
  component: ProfileAccessComponent, data: {'route': RouteConstants.ACCESS_NEW_INVITATION_ACCESS}
};
export const ACCESS_NEW_INVITATION_ROLES: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_INVITATION_ROLES.url, name: RouteConstants.ACCESS_NEW_INVITATION_ROLES.name,
  component: ProfileRolesComponent, data: {'route': RouteConstants.ACCESS_NEW_INVITATION_ROLES}
};
export const ACCESS_NEW_INVITATION_CONFIRM: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_INVITATION_CONFIRM.url, name: RouteConstants.ACCESS_NEW_INVITATION_CONFIRM.name,
  component: NewInvitationConfirmComponent, data: {'route': RouteConstants.ACCESS_NEW_INVITATION_CONFIRM}
};
export const ACCESS_NEW_GROUP_INVITATION: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_GROUP_INVITATION.url, name: RouteConstants.ACCESS_NEW_GROUP_INVITATION.name,
  component: GroupInvitationInformationComponent, data: {'route': RouteConstants.ACCESS_NEW_GROUP_INVITATION}
};
export const ACCESS_NEW_GROUP_INVITATION_ACCESS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_GROUP_INVITATION_ACCESS.url,
  name: RouteConstants.ACCESS_NEW_GROUP_INVITATION_ACCESS.name,
  component: ProfileAccessComponent,
  data: {'route': RouteConstants.ACCESS_NEW_GROUP_INVITATION_ACCESS}
};
export const ACCESS_NEW_GROUP_INVITATION_ROLES: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_GROUP_INVITATION_ROLES.url,
  name: RouteConstants.ACCESS_NEW_GROUP_INVITATION_ROLES.name,
  component: ProfileRolesComponent,
  data: {'route': RouteConstants.ACCESS_NEW_GROUP_INVITATION_ROLES}
};
export const ACCESS_NEW_GROUP_INVITATION_CONFIRM: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_GROUP_INVITATION_CONFIRM.url,
  name: RouteConstants.ACCESS_NEW_GROUP_INVITATION_CONFIRM.name,
  component: NewGroupInvitationConfirmComponent,
  data: {'route': RouteConstants.ACCESS_NEW_GROUP_INVITATION_CONFIRM}
};
export const ACCESS_NEW_GROUP_INVITATION_URL: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_GROUP_INVITATION_URL.url, name: RouteConstants.ACCESS_NEW_GROUP_INVITATION_URL.name,
  component: NewGroupInvitationUrlComponent, data: {'route': RouteConstants.ACCESS_NEW_GROUP_INVITATION_URL}
};
export const ACCESS_PROFILE: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_PROFILE.url, name: RouteConstants.ACCESS_PROFILE.name,
  component: ProfileComponent, data: {'route': RouteConstants.ACCESS_PROFILE}
};
export const ACCESS_PROFILE_IDENTIFICATION: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_PROFILE_IDENTIFICATION.url, name: RouteConstants.ACCESS_PROFILE_IDENTIFICATION.name,
  component: ProfileIdentificationComponent, data: {'route': RouteConstants.ACCESS_PROFILE_IDENTIFICATION}
};
export const ACCESS_PROFILE_ACCESS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_PROFILE_ACCESS.url, name: RouteConstants.ACCESS_PROFILE_ACCESS.name,
  component: ProfileAccessComponent, data: {'route': RouteConstants.ACCESS_PROFILE_ACCESS}
};
export const ACCESS_PROFILE_ROLES: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_PROFILE_ROLES.url, name: RouteConstants.ACCESS_PROFILE_ROLES.name,
  component: ProfileRolesComponent, data: {'route': RouteConstants.ACCESS_PROFILE_ROLES}
};
export const ACCESS_PROFILE_STATUS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_PROFILE_STATUS.url, name: RouteConstants.ACCESS_PROFILE_STATUS.name,
  component: ProfileStatusComponent, data: {'route': RouteConstants.ACCESS_PROFILE_STATUS}
};
export const ACCESS_PROFILE_INVITATION: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_PROFILE_INVITATION.url, name: RouteConstants.ACCESS_PROFILE_INVITATION.name,
  component: ProfileInvitationComponent, data: {'route': RouteConstants.ACCESS_PROFILE_INVITATION}
};
export const ACCESS_GROUP_INVITATION: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_GROUP_INVITATION.url, name: RouteConstants.ACCESS_GROUP_INVITATION.name,
  component: GroupInvitationComponent, data: {'route': RouteConstants.ACCESS_GROUP_INVITATION}
};
export const ACCESS_GROUP_INVITATION_INFORMATION: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_GROUP_INVITATION_INFORMATION.url,
  name: RouteConstants.ACCESS_GROUP_INVITATION_INFORMATION.name,
  component: GroupInvitationInformationComponent,
  data: {'route': RouteConstants.ACCESS_GROUP_INVITATION_INFORMATION}
};
export const ACCESS_GROUP_INVITATION_ACCESS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_GROUP_INVITATION_ACCESS.url, name: RouteConstants.ACCESS_GROUP_INVITATION_ACCESS.name,
  component: ProfileAccessComponent, data: {'route': RouteConstants.ACCESS_GROUP_INVITATION_ACCESS}
};
export const ACCESS_GROUP_INVITATION_ROLES: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_GROUP_INVITATION_ROLES.url, name: RouteConstants.ACCESS_GROUP_INVITATION_ROLES.name,
  component: ProfileRolesComponent, data: {'route': RouteConstants.ACCESS_GROUP_INVITATION_ROLES}
};
export const ACCESS_GROUP_PROFILE: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_GROUP_PROFILE.url, name: RouteConstants.ACCESS_GROUP_PROFILE.name,
  component: ProfileComponent, data: {'route': RouteConstants.ACCESS_GROUP_PROFILE}
};
export const ACCESS_ROLE_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_ROLE_MANAGEMENT.url, name: RouteConstants.ACCESS_ROLE_MANAGEMENT.name,
  component: RoleManagementComponent, data: {'route': RouteConstants.ACCESS_ROLE_MANAGEMENT}
};
export const ACCESS_ROLE_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_ROLE_DETAILS.url, name: RouteConstants.ACCESS_ROLE_DETAILS.name,
  component: RoleDetailsComponent, data: {'route': RouteConstants.ACCESS_ROLE_DETAILS}
};

export const ACCESS_NEW_ROLE: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_ROLE.url, name: RouteConstants.ACCESS_NEW_ROLE.name,
  component: NewRoleComponent, data: {'route': RouteConstants.ACCESS_NEW_ROLE}
};

export const ACCESS_PERMISSION_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_PERMISSION_MANAGEMENT.url, name: RouteConstants.ACCESS_PERMISSION_MANAGEMENT.name,
  component: PermissionManagementComponent, data: {'route': RouteConstants.ACCESS_PERMISSION_MANAGEMENT},
  abstract: true
};
export const ACCESS_PERMISSIONS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_PERMISSIONS.url, name: RouteConstants.ACCESS_PERMISSIONS.name,
  component: PermissionsComponent, data: {'route': RouteConstants.ACCESS_PERMISSIONS}
};
export const ACCESS_NEW_PERMISSION: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_PERMISSION.url, name: RouteConstants.ACCESS_NEW_PERMISSION.name,
  component: NewPermissionComponent, data: {'route': RouteConstants.ACCESS_NEW_PERMISSION}
};
export const ACCESS_PERMISSION_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_PERMISSION_DETAILS.url, name: RouteConstants.ACCESS_PERMISSION_DETAILS.name,
  component: PermissionDetailsComponent, data: {'route': RouteConstants.ACCESS_PERMISSION_DETAILS}
};
export const ACCESS_STATES: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_STATES.url, name: RouteConstants.ACCESS_STATES.name,
  component: StatesComponent, data: {'route': RouteConstants.ACCESS_STATES}
};
export const ACCESS_ENDPOINTS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_ENDPOINTS.url, name: RouteConstants.ACCESS_ENDPOINTS.name,
  component: EndpointsComponent, data: {'route': RouteConstants.ACCESS_ENDPOINTS}
};
export const ACCESS_ELEMENTS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_ELEMENTS.url, name: RouteConstants.ACCESS_ELEMENTS.name,
  component: ElementsComponent, data: {'route': RouteConstants.ACCESS_ELEMENTS}
};
export const ACCESS_REPORTS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_REPORTS.url, name: RouteConstants.ACCESS_REPORTS.name,
  component: BiReportsComponent, data: {'route': RouteConstants.ACCESS_REPORTS}
};
export const ACCESS_ROLE_SERVICE_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_ROLE_SERVICE_MANAGEMENT.url, name: RouteConstants.ACCESS_ROLE_SERVICE_MANAGEMENT.name,
  component: RoleServiceManagementComponent, data: {'route': RouteConstants.ACCESS_ROLE_SERVICE_MANAGEMENT}
};
export const ACCESS_NEW_ROLE_SERVICE: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_NEW_ROLE_SERVICE.url, name: RouteConstants.ACCESS_NEW_ROLE_SERVICE.name,
  component: NewRoleServiceComponent, data: {'route': RouteConstants.ACCESS_NEW_ROLE_SERVICE}
};
export const ACCESS_ROLE_SERVICE_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ACCESS_ROLE_SERVICE_DETAILS.url, name: RouteConstants.ACCESS_ROLE_SERVICE_DETAILS.name,
  component: RoleServiceDetailsComponent, data: {'route': RouteConstants.ACCESS_ROLE_SERVICE_DETAILS}
};

export const AccessStates = [
  ACCESS,
  ACCESS_USER_REQUEST_MANAGEMENT,
  ACCESS_USER_REQUEST,
  ACCESS_PROFILE_MANAGEMENT,
  ACCESS_NEW_INVITATION,
  ACCESS_NEW_INVITATION_ACCESS,
  ACCESS_NEW_INVITATION_ROLES,
  ACCESS_NEW_INVITATION_CONFIRM,
  ACCESS_NEW_GROUP_INVITATION,
  ACCESS_NEW_GROUP_INVITATION_ACCESS,
  ACCESS_NEW_GROUP_INVITATION_ROLES,
  ACCESS_NEW_GROUP_INVITATION_CONFIRM,
  ACCESS_NEW_GROUP_INVITATION_URL,
  ACCESS_PROFILE,
  ACCESS_PROFILE_IDENTIFICATION,
  ACCESS_PROFILE_ACCESS,
  ACCESS_PROFILE_ROLES,
  ACCESS_PROFILE_STATUS,
  ACCESS_PROFILE_INVITATION,
  ACCESS_GROUP_INVITATION,
  ACCESS_GROUP_INVITATION_INFORMATION,
  ACCESS_GROUP_INVITATION_ACCESS,
  ACCESS_GROUP_INVITATION_ROLES,
  ACCESS_GROUP_PROFILE,
  ACCESS_ROLE_MANAGEMENT,
  ACCESS_ROLE_DETAILS,
  ACCESS_NEW_ROLE,
  ACCESS_PERMISSION_MANAGEMENT,
  ACCESS_PERMISSIONS,
  ACCESS_NEW_PERMISSION,
  ACCESS_PERMISSION_DETAILS,
  ACCESS_STATES,
  ACCESS_ENDPOINTS,
  ACCESS_ELEMENTS,
  ACCESS_REPORTS,
  ACCESS_ROLE_SERVICE_MANAGEMENT,
  ACCESS_NEW_ROLE_SERVICE,
  ACCESS_ROLE_SERVICE_DETAILS
];
