import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {AccessStates} from './access-states';
import {RouteConstants} from '@lc-constants/*';

const accessRoutes: RootModule = {
  states: AccessStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(accessRoutes)],
  exports: [UIRouterModule]
})
export class AccessRoutingModule {
}
