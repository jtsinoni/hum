import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {AccessRoutingModule} from './access-routing.module';
import {CommonComponentsModule} from '@lc-common-components';
import {PipesModule} from '../../pipes/pipes.module';
import {DirectivesModule} from '../../directives/directives.module';
import {AccessComponent} from './access.component';
import {ProfileManagementComponent} from './profile-management/views/profile-management/profile-management.component';
import {PermissionDetailsComponent} from './permission-management/views/permission-details/permission-details.component';
import {PermissionManagementComponent} from './permission-management/permission-management.component';
import {PermissionsComponent} from './permission-management/views/permissions/permissions.component';
import {RoleManagementComponent} from './role-management/views/role-management/role-management.component';
import {EndpointsComponent} from './permission-management/views/endpoints/endpoints.component';
import {NewPermissionComponent} from './permission-management/views/new-permission/new-permission.component';
import {PermissionInformationComponent} from './permission-management/components/permission-information/permission-information.component';
import {PermissionElementsComponent} from './permission-management/components/permission-elements/permission-elements.component';
import {PermissionStatesComponent} from './permission-management/components/permission-states/permission-states.component';
import {PermissionEndpointsComponent} from './permission-management/components/permission-endpoints/permission-endpoints.component';
import {StatesComponent} from './permission-management/views/states/states.component';
import {ElementsComponent} from './permission-management/views/elements/elements.component';
import {NewRoleComponent} from './role-management/views/new-role/new-role.component';
import {RoleDetailsComponent} from './role-management/views/role-details/role-details.component';
import {RoleAssignedPermissionsComponent} from './role-management/components/role-assigned-permissions/role-assigned-permissions.component';
import {RolePermissionCollectionComponent} from './role-management/components/role-permission-collection/role-permission-collection.component';
import {RoleInformationComponent} from './role-management/components/role-information/role-information.component';
import {ProfileIdentificationComponent} from './profile-management/components/profile-identification/profile-identification.component';
import {ProfileAccessComponent} from './profile-management/views/profile-access/profile-access.component';
import {ProfileRolesComponent} from './profile-management/views/profile-roles/profile-roles.component';
import {ProfileStatusComponent} from './profile-management/views/profile-status/profile-status.component';
import {NewInvitationComponent} from './profile-management/views/new-invitation/new-invitation.component';
import {ProfileComponent} from './profile-management/views/profile/profile.component';
import {ProfileInvitationComponent} from './profile-management/views/profile-invitation/profile-invitation.component';
import {RoleCollectionsComponent} from './profile-management/components/role-collections/role-collections.component';
import {NewInvitationConfirmComponent} from './profile-management/views/new-invitation-confirm/new-invitation-confirm.component';
import {GroupInvitationInformationComponent} from './profile-management/views/group-invitation-information/group-invitation-information.component';
import {NewGroupInvitationConfirmComponent} from './profile-management/views/new-group-invitation-confirm/new-group-invitation-confirm.component';
import {NewGroupInvitationUrlComponent} from './profile-management/views/new-group-invitation-url/new-group-invitation-url.component';
import {GroupInvitationComponent} from './profile-management/views/group-invitation/group-invitation.component';
import {RoleCollectionComponent} from './profile-management/components/role-collection/role-collection.component';
import {PermissionApiService} from './permission-management/services/permission-api.service';
import {RoleSelectionService} from './role-management/services/role-selection.service';
import {RoleApiService} from './role-management/services/role-api.service';
import {PermissionSelectionService} from './permission-management/services/permission-selection.service';
import {ProfileManagementService} from './profile-management/services/profile-management.service';
import {OrganizationApiService} from '../organization/services/organization-api.service';
import {ProfileApiService} from '@lc-services/*';
import {InvitationApiService} from './profile-management/services/invitation-api.service';
import {JmlfdcAdminModule} from '../jmlfdc-admin/jmlfdc-admin.module';
import {RoleServiceManagementComponent} from './role-service-management/views/role-service-management/role-service-management.component';
import {RoleServiceApiService} from './role-service-management/services/role-service-api.service';
import {RoleServiceManagementService} from './role-service-management/services/role-service-management.service';
import {NewRoleServiceComponent} from './role-service-management/views/new-role-service/new-role-service.component';
import {RoleServiceDetailsComponent} from './role-service-management/views/role-service-details/role-service-details.component';
import {RoleServiceInformationComponent} from './role-service-management/components/role-service-information/role-service-information.component';
import {RoleServiceRolesComponent} from './role-service-management/components/role-service-roles/role-service-roles.component';
import {UserRequestManagementComponent} from './user-request-management/user-request-management.component';
import {UserRequestManagementService} from './user-request-management/services/user-request-management.service';
import {UserRequestApiService} from './user-request-management/services/user-request-api.service';
import {UserRequestComponent} from './user-request-management/views/user-request/user-request.component';
import {UserRequestIdentificationComponent} from './user-request-management/components/user-request-identification/user-request-identification.component';
import {UserRequestRequirementsComponent} from './user-request-management/components/user-request-requirements/user-request-requirements.component';
import {UserRequestParticipantsListComponent} from './user-request-management/components/user-request-participants-list/user-request-participants-list.component';
import {OrganizationComponentModule} from '../organization/organization-component.module';
import {RequirementFileUploadComponent} from './user-request-management/components/user-request-requirements/requirement-file-upload/requirement-file-upload.component';
import {RequirementDocumentCompletionComponent} from './user-request-management/components/user-request-requirements/requirement-document-completion/requirement-document-completion.component';
import {RequirementReviewAndAcknowledgeComponent} from './user-request-management/components/user-request-requirements/requirement-review-and-acknowledge/requirement-review-and-acknowledge.component';
import {ProgressTimelineComponent} from './user-request-management/components/progress-timeline/progress-timeline.component';
import {UserRequestRequirementsService} from './user-request-management/services/user-request-requirements.service';
import {RequirementCommentsComponent} from './user-request-management/components/user-request-requirements/requirement-comments/requirement-comments.component';
import {LcUserRequestParticipantsMessageBoxComponent} from './user-request-management/components/lc-user-request-participants-message-box/lc-user-request-participants-message-box.component';
import {BiReportsComponent} from './permission-management/views/bireports/bi-reports.component';
import {PermissionBiReportsComponent} from './permission-management/components/permission-bireports/permission-bi-reports.component';

@NgModule({
  imports: [
    CommonModule,
    AccessRoutingModule,
    CommonComponentsModule.forRoot(),
    FormsModule,
    PipesModule.forRoot(),
    DirectivesModule,
    JmlfdcAdminModule,
    OrganizationComponentModule

  ],
  declarations: [
    AccessComponent,
    ProfileManagementComponent,
    RoleManagementComponent,
    PermissionManagementComponent,
    PermissionsComponent,
    PermissionDetailsComponent,
    EndpointsComponent,
    NewPermissionComponent,
    PermissionInformationComponent,
    PermissionElementsComponent,
    PermissionStatesComponent,
    PermissionEndpointsComponent,
    StatesComponent,
    ElementsComponent,
    NewRoleComponent,
    RoleDetailsComponent,
    RoleInformationComponent,
    RoleAssignedPermissionsComponent,
    RolePermissionCollectionComponent,
    RoleServiceManagementComponent,
    NewRoleServiceComponent,
    RoleServiceDetailsComponent,
    RoleServiceInformationComponent,
    RoleServiceRolesComponent,
    ProfileIdentificationComponent,
    ProfileAccessComponent,
    ProfileRolesComponent,
    ProfileStatusComponent,
    NewInvitationComponent,
    ProfileComponent,
    ProfileInvitationComponent,
    RoleCollectionsComponent,
    NewInvitationConfirmComponent,
    GroupInvitationInformationComponent,
    NewGroupInvitationConfirmComponent,
    NewGroupInvitationUrlComponent,
    GroupInvitationComponent,
    RoleCollectionComponent,
    UserRequestManagementComponent,
    UserRequestComponent,
    UserRequestIdentificationComponent,
    UserRequestRequirementsComponent,
    UserRequestParticipantsListComponent,
    RequirementFileUploadComponent,
    RequirementDocumentCompletionComponent,
    RequirementReviewAndAcknowledgeComponent,
    RequirementCommentsComponent,
    ProgressTimelineComponent,
    LcUserRequestParticipantsMessageBoxComponent,
    BiReportsComponent,
    PermissionBiReportsComponent
  ],
  providers: [
    PermissionApiService,
    PermissionSelectionService,
    RoleApiService,
    RoleSelectionService,
    RoleServiceApiService,
    RoleServiceManagementService,
    ProfileManagementService,
    OrganizationApiService,
    ProfileApiService,
    InvitationApiService,
    UserRequestManagementService,
    UserRequestApiService,
    UserRequestRequirementsService
  ],
  exports: [
    ProfileIdentificationComponent,
    UserRequestParticipantsListComponent,
    RequirementFileUploadComponent,
    RequirementDocumentCompletionComponent,
    RequirementReviewAndAcknowledgeComponent,
    UserRequestIdentificationComponent,
    UserRequestRequirementsComponent,
  ]
})
export class AccessModule {
}
