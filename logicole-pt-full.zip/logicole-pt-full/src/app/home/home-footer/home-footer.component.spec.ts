import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';

import {HomeFooterComponent} from './home-footer.component';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {LoggerService, LoginService, NotificationService, ProfileApiService} from '@lc-services/*';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {ProfileApiServiceMock} from '../../services/core/profile-api.service.mock';
import {LoginServiceMock} from '../../services/core/login.service.mock';
import {PipesModule} from '../../pipes/pipes.module';
import {DatePipe} from '@angular/common';
import {NotificationServiceMock} from '../../services/core/notification.service.mock';

describe('HomeFooterComponent', () => {
  let component: HomeFooterComponent;
  let fixture: ComponentFixture<HomeFooterComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [HomeFooterComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        PipesModule.forRoot()
      ],
      providers: [
        LoggerService, DatePipe,
        {provide: ProfileApiService, useClass: ProfileApiServiceMock},
        {provide: LoginService, useClass: LoginServiceMock},
        {provide: NotificationService, useClass: NotificationServiceMock}
      ]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      a11yTests(fixture.nativeElement)
        .then((results) => {
          expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
        })
        .catch((error) => {
          loggerService.error(`${error}`);
        });
    }));
  });
});
