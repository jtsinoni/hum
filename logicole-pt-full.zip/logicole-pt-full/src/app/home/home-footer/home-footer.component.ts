import {Component, OnInit} from '@angular/core';
import {LoggerService, LoginService, NotificationService} from '@lc-services/*';
import {DatePipe} from '@angular/common';

@Component({
  selector: 'app-home-footer',
  templateUrl: './home-footer.component.html'
})
export class HomeFooterComponent implements OnInit {

  public loginDateTime: Date;
  public dateTime: Date;
  public dateTimeZone: string;
  public lastLoginIP: string;
  public showLastLoginInfo: boolean;
  public logiColeAnimation: string = 'slideInUp';

  constructor(private logger: LoggerService,
              private notificationService: NotificationService,
              private loginService: LoginService,
              public datePipe: DatePipe) {
  }

  public ngOnInit() {
    if (this.loginService.getCurrentUser() &&
      this.loginService.getCurrentUser().profile &&
      this.loginService.getCurrentUser().profile.previousLoginDate) {
      this.showLastLoginInfo = true;
      this.loginDateTime = this.loginService.getCurrentUser().profile.lastLoginDate;
      this.lastLoginIP = this.loginService.getCurrentUser().profile.lastLoginIP;

      this.dateTime = new Date();
      this.dateTimeZone = this.datePipe.transform(this.dateTime, 'ZZZZ');

      setInterval(() => {
        this.dateTime = new Date();
      }, 1000);

    } else {
      this.showLastLoginInfo = false;
    }
  }

  public hideLoginPane() {
    this.logiColeAnimation = 'slideOutDown';
  }

  public goToMainContent() {
    this.loginService.mockCall().subscribe(result => {
      this.loginService.jumpToMain$.next(true);
    });
  }
}
