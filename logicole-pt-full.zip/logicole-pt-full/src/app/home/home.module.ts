import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {CommonComponentsModule} from '@lc-common-components';
import {PipesModule} from '../pipes/pipes.module';
import {HomeComponentsModule} from './home-components/home-components.module';
import {HomeFooterComponent} from './home-footer/home-footer.component';
import {HomeHeaderComponent} from './home-header/home-header.component';
import {MainNavComponent} from './main-nav/main-nav.component';
import {UtilService} from '../services/util.service';
import {MainNavSelectorComponent} from './main-nav/main-nav-selector/main-nav-selector.component';
import {HomeComponent} from './home.component';
import {HomeRoutingModule} from './home-routing.module';
import {LoggerService} from 'app/services/logger/logger.service';
import {DirectivesModule} from 'app/directives/directives.module';
import {DashboardModule} from './dashboard/dashboard.module';
import {HelpModule} from './help/help.module';
import {ApplicationNotificationsComponent} from './home-header/application-notifications.component';
import {OrderModule} from './order/order.module';
import {ReportModule} from './report/report.module';
import {CatalogModule} from './catalog/catalog.module';

// TODO Don't import any child modules unless you want them to be loaded eagerly (as opposed to lazily)
// For services use the Injectable( { providedIn: 'root' }) in each service. That will ensure they are created singly in
// each lazy loaded module. You can also place them in app/services directory if they are needed globally (also with providedIn: 'root')
@NgModule({
  imports: [
    CommonModule,
    HomeRoutingModule,
    FormsModule,
    CommonComponentsModule,
    PipesModule.forRoot(),
    HomeComponentsModule,
    DirectivesModule,
    DashboardModule,
    HelpModule,
    CatalogModule,
    ReportModule
  ],
  declarations: [
    HomeFooterComponent,
    HomeComponent,
    HomeHeaderComponent,
    MainNavComponent,
    MainNavSelectorComponent,
    HomeComponent,
    ApplicationNotificationsComponent
    // BusinessIntelligenceComponent
  ],
  exports: [
    HomeFooterComponent
  ],
  providers: [
    UtilService
  ]
})
export class HomeModule {
  // adding this to check if the module is lazy loaded - constructor normally not needed
  constructor(private logger: LoggerService) {
    this.logger.debug('In Home module ####');
  }
}
