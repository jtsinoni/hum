import {Component, OnInit} from '@angular/core';
import {LoggerService, LoginService, ProfileApiService, ProfileService, StateNavigationService} from '@lc-services/*';
import {ElementConstants} from '@lc-constants/*';
import {SystemNotificationService} from '../jmlfdc-admin/system-notification/services/system-notification.service';
import {DashboardService} from './services/dashboard.service';
import {SafeHtmlPipe} from '../../pipes/safe-html.pipe';
import {Observable} from 'rxjs';
import {StorageService} from '../../services/storage.service';
import {ElementAssemblageConstants} from '../assemblage/constants/element-assemblage.constants';

@Component({
  selector: 'lc-dashboard',
  templateUrl: './dashboard.component.html',
  providers: [SystemNotificationService, DashboardService, SafeHtmlPipe]
})
export class DashboardComponent implements OnInit {

  public activeNotifications: Array<string> = [];
  public drawingElement: string = ElementConstants.REAL_PROPERTY_DRAWING_MANAGEMENT;
  public realPropertyElement: string = ElementConstants.REAL_PROPERTY_FACILITY_MANAGEMENT;
  public spaceElement: string = ElementConstants.REAL_PROPERTY_SPACE_MANAGEMENT;
  public userRequestManagementElement: string = ElementConstants.USER_REQUEST_VIEW;
  public userProfileManagementElement: string = ElementConstants.USER_PROFILE_MANAGEMENT;
  public abiManagementElement: string = ElementConstants.MANAGE_ABI_STAGING;
  public equipRecordElement: string = ElementConstants.DMLES_EQUIP_RECORDS_VIEW;
  public equipRequestElement: string = ElementConstants.EQUIP_REQUESTS_DASH;
  public assetManagementInventoryDashElement: string = ElementConstants.ASSET_MANAGEMENT_INVENTORY_DASH;
  public workOrderElement: string = ElementConstants.WORK_ORDERS_DASHBOARD;
  public sectionElement: string = ElementConstants.REAL_PROPERTY_SECTION_MANAGEMENT;
  public projectManagementElement: string = ElementConstants.REAL_PROPERTY_PROJECT_MANAGEMENT;
  public requirementManagementElement: string = ElementConstants.REAL_PROPERTY_REQUIREMENTS_MANAGEMENT;
  public medicalEquipmentWorkOrderElement: string = ElementConstants.MEDICAL_EQUIPMENT_WORK_ORDERS_DASHBOARD;
  public assemblageManagementElement: string = ElementAssemblageConstants.ASSEMBLAGE_VIEW;

  constructor(private logger: LoggerService,
              public systemNotificationService: SystemNotificationService,
              public dashboardService: DashboardService,
              private storageService: StorageService,
              private profileApiService: ProfileApiService) {
  }

  public ngOnInit() {
    this.systemNotificationService.getGroupedSystemNotifications().subscribe(t => {
      this.logger.debug('System Notifications returned.');
      this.systemNotificationService.activeNotifications = t;
    });

    this.getUserExpirationWarningMessage().subscribe(t => {
      this.logger.debug('User Expiration Notification returned.');
      this.activeNotifications = t;
    });
  }

  public setSystemNotificationClass(notificationType: string): string {
    const value = notificationType === 'Information' ? 'alert-info' :
      (notificationType === 'New Feature' ? 'alert-warning' : 'alert-danger');
    return `row alert ${value} alert-dismissible fade show`;
  }

  public onDismissed(id: string) {
    this.systemNotificationService.setDismissed(id);
  }

  public getIsDismissed(id: string): boolean {
    return this.systemNotificationService.getDismissed(id);
  }

  public onUserExpirationDismissed(id: string) {
    this.setUserNotificationDismissed(id);
  }

  public getUserExpirationIsDismissed(id: string): boolean {
    return this.getUserNotificationDismissed(id);
  }

  public getUserExpirationWarningMessage(): Observable<Array<string>> {
    return this.profileApiService.getUserExpirationWarningMessage();
  }

  public setUserNotificationDismissed(id: string) {
    this.storageService.storeData(id, true, false);
  }

  public getUserNotificationDismissed(id: string): boolean {
    const obj = this.storageService.getData(id);
    return obj != null;
  }

}
