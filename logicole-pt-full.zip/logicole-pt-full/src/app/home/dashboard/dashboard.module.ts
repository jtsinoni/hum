import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {DashboardComponent} from './dashboard.component';
import {LoggerService} from '@lc-services/*';
import {EquipmentRecordSearchService} from '../equipment/equipment-records/services/equipment-record-search.service';
import {DirectivesModule} from '../../directives/directives.module';
import {PipesModule} from '../../pipes/pipes.module';
import {CommonComponentsModule} from '@lc-common-components';
import {LcDashboardBadgeComponent} from './components/dashboard-badge/lc-dashboard-badge.component';
import {LcDashboardCardWrapperComponent} from './components/dashboard-card-wrapper/lc-dashboard-card-wrapper.component';
import {RequestService} from '../equipment/equipment-requests/services/request.service';
import {RequestApiService} from '../equipment/equipment-requests/services/request-api.service';
import {ProfileManagementDashboardComponent} from './components/profile-management-dashboard/profile-management-dashboard.component';
import {EquipmentRequestDashboardComponent} from './components/equipment-request-dashboard/equipment-request-dashboard.component';
import {EquipmentRecordDashboardComponent} from './components/equipment-record-dashboard/equipment-record-dashboard.component';
import {RealPropertyDashboardComponent} from './components/real-property-dashboard/real-property-dashboard.component';
import {FacilityApiService} from '../real-property/services/facility-api.service';
import {InvitationManagementDashboardComponent} from './components/invitation-management-dashboard/invitation-management-dashboard.component';
import {AbiManagementDashboardComponent} from './components/abi-management-dashboard/abi-management-dashboard.component';
import {UserRequestManagementDashboardComponent} from './components/user-request-management-dashboard/user-request-management-dashboard.component';
import {FormsModule} from '@angular/forms';
import {UserRequestApiService} from '../access/user-request-management/services/user-request-api.service';
import {ClassificationRequestDashboardComponent} from './components/classification-request-dashboard/classification-request-dashboard.component';
import {ClassificationRequestApiService} from '../asset/classification-request/services/classification-request-api.service';
import {SpaceManagementDashboardComponent} from './components/space-management-dashboard/space-management-dashboard.component';
import {SpaceApiService} from '../real-property/services/space-api.service';
import {DrawingManagementDashboardComponent} from './components/drawing-management-dashboard/drawing-management-dashboard.component';
import {AssetManagementInventoryDashboardComponent} from './components/asset-management-inventory-dashboard/asset-management-inventory-dashboard.component';
import {AssetApiService} from '../asset/asset-management/services/asset-api.service';
import {WorkOrderDashboardComponent} from './components/work-order-dashboard/work-order-dashboard.component';
import {WorkOrdersApiService} from '../work-orders/services/work-orders-api.service';
import {SectionManagementDashboardComponent} from './components/section-management-dashboard/section-management-dashboard.component';
import {ProjectManagementDashboardComponent} from './components/project-management-dashboard/project-management-dashboard.component';
import {RequirementManagementDashboardComponent} from './components/requirement-management-dashboard/requirement-management-dashboard.component';
import {RequirementsApiService} from '../real-property/services/requirements-api.service';
import {MedicalEquipmentWorkOrderDashboardComponent} from './components/medical-equipment-work-order-dashboard/medical-equipment-work-order-dashboard.component';
import {AssemblageManagementDashboardComponent} from './components/assemblage-management-dashboard/assemblage-management-dashboard.component';

@NgModule({
  imports: [
    CommonModule,
    CommonComponentsModule,
    DirectivesModule,
    PipesModule,
    FormsModule
  ],
  declarations: [
    DashboardComponent,
    LcDashboardBadgeComponent,
    LcDashboardCardWrapperComponent,
    ProfileManagementDashboardComponent,
    EquipmentRequestDashboardComponent,
    EquipmentRecordDashboardComponent,
    RealPropertyDashboardComponent,
    SpaceManagementDashboardComponent,
    InvitationManagementDashboardComponent,
    AbiManagementDashboardComponent,
    UserRequestManagementDashboardComponent,
    ClassificationRequestDashboardComponent,
    DrawingManagementDashboardComponent,
    AssetManagementInventoryDashboardComponent,
    WorkOrderDashboardComponent,
    SectionManagementDashboardComponent,
    ProjectManagementDashboardComponent,
    RequirementManagementDashboardComponent,
    MedicalEquipmentWorkOrderDashboardComponent,
    AssemblageManagementDashboardComponent
  ],
  providers: [
    EquipmentRecordSearchService,
    RequestService,
    RequestApiService,
    FacilityApiService,
    SpaceApiService,
    UserRequestApiService,
    ClassificationRequestApiService,
    AssetApiService,
    WorkOrdersApiService,
    RequirementsApiService
  ]
})
export class DashboardModule {
  // adding this to check if the module is lazy loaded - constructor normally not needed
  constructor(private logger: LoggerService) {
    this.logger.debug('In My Dashboard module ####');
  }
}
