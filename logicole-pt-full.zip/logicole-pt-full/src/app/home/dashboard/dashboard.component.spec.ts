import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {DashboardComponent} from './dashboard.component';
import {AuthenticationService, LoggerService, ProfileApiService} from '@lc-services/*';
import {SystemNotificationApiService} from '../jmlfdc-admin/system-notification/services/system-notification-api.service';
import {SystemNotificationApiServiceMock} from '../jmlfdc-admin/system-notification/services/system-notification-api.service.mock';
import {DashboardService} from './services/dashboard.service';
import {DashboardServiceMock} from './services/dashboard.service.mock';
import {SystemNotificationService} from '../jmlfdc-admin/system-notification/services/system-notification.service';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {CommonComponentsModule} from '@lc-common-components';
import {CommonModule, CurrencyPipe} from '@angular/common';
import {DirectivesModule} from '../../directives/directives.module';
import {PipesModule} from '../../pipes/pipes.module';
import {LcDashboardBadgeComponent} from './components/dashboard-badge/lc-dashboard-badge.component';
import {LcDashboardCardWrapperComponent} from './components/dashboard-card-wrapper/lc-dashboard-card-wrapper.component';
import {StorageService} from '../../services/storage.service';
import {WindowService} from '../../services/window.service';
import {UtilService} from '../../services/util.service';
import {ProfileApiServiceMock} from '../../services/core/profile-api.service.mock';
import {EquipmentRecordSearchServiceMock} from '../equipment/equipment-records/services/equipment-record-search.service.mock';
import {EquipmentRecordSearchService} from '../equipment/equipment-records/services/equipment-record-search.service';
import {RequestServiceMock} from '../equipment/equipment-requests/services/request.service.mock';
import {RequestService} from '../equipment/equipment-requests/services/request.service';
import {PermissionService} from '../../services/permission.service';
import {PermissionApiService} from '../access/permission-management/services/permission-api.service';
import {PermissionApiServiceMock} from '../access/permission-management/services/permission-api.service.mock';
import {FacilityApiService} from '../real-property/services/facility-api.service';
import {FacilityApiServiceMock} from '../real-property/services/facility-api.service.mock';
import {PermissionServiceMock} from '../../services/permission.service.mock';
import {runA11yTests} from '../../spec-helper/a11y-tests.spec';
import {AbiStagingManagementApiService} from '../jmlfdc-admin/abi-management/services/abi-staging-management-api.service';
import {AbiStagingManagementApiServiceMock} from '../jmlfdc-admin/abi-management/services/abi-staging-management-api.service.mock';
import {FloorPlanApiService} from '../../services/floor-plan-api.service';
import {FloorPlanApiServiceMock} from '../../services/floor-plan-api.service.mock';
import {RequestApiService} from '../equipment/equipment-requests/services/request-api.service';
import {RequestApiServiceMock} from '../equipment/equipment-requests/services/request-api.service.mock';
import {InvitationApiService} from '../access/profile-management/services/invitation-api.service';
import {InvitationApiServiceMock} from '../access/profile-management/services/invitation-api.service.mock';
import {ClassificationRequestApiService} from '../asset/classification-request/services/classification-request-api.service';
import {ClassificationRequestApiServiceMock} from '../asset/classification-request/services/classification-request-api.service.mock';
import {HttpTestModule} from '@lc-test-modules';
import {AuthenticationServiceMock} from '../../services/core/authentication.service.mock';
import {LoaderService} from '../../services/loader.service';
import {UserRequestApiServiceMock} from '../access/user-request-management/services/user-request-api.service.mock';
import {UserRequestApiService} from '../access/user-request-management/services/user-request-api.service';
import {ProfileManagementService} from '../access/profile-management/services/profile-management.service';
import {ProfileManagementServiceMock} from '../access/profile-management/services/profile-management-service.mock';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let loggerService: LoggerService;
  let originalTimeout;

  beforeEach(function() {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;
  });

  afterEach(function() {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule, CommonComponentsModule, DirectivesModule, PipesModule, HttpTestModule
      ],
      declarations: [
        DashboardComponent, LcDashboardBadgeComponent, LcDashboardCardWrapperComponent
      ],
      providers: [
        {provide: DashboardService, useClass: DashboardServiceMock},
        {provide: SystemNotificationService, useClass: SystemNotificationService},
        {provide: StorageService, useClass: StorageService},
        {provide: WindowService, useClass: WindowService},
        {provide: UtilService, useClass: UtilService},
        {provide: CurrencyPipe, useClass: CurrencyPipe},
        {provide: ProfileApiService, useClass: ProfileApiServiceMock},
        {provide: EquipmentRecordSearchService, useClass: EquipmentRecordSearchServiceMock},
        {provide: RequestService, useClass: RequestServiceMock},
        {provide: PermissionService, useClass: PermissionServiceMock},
        {provide: PermissionApiService, useClass: PermissionApiServiceMock},
        {provide: FacilityApiService, useClass: FacilityApiServiceMock},
        {provide: SystemNotificationApiService, useClass: SystemNotificationApiServiceMock},
        {provide: FacilityApiService, useClass: FacilityApiServiceMock},
        {provide: AbiStagingManagementApiService, useClass: AbiStagingManagementApiServiceMock},
        {provide: FloorPlanApiService, useClass: FloorPlanApiServiceMock},
        {provide: RequestApiService, useClass: RequestApiServiceMock},
        {provide: InvitationApiService, useClass: InvitationApiServiceMock},
        {provide: ClassificationRequestApiService, useClass: ClassificationRequestApiServiceMock},
        {provide: AuthenticationService, useClass: AuthenticationServiceMock},
        LoaderService,
        {provide: UserRequestApiService, useClass: UserRequestApiServiceMock},
        {provide: ProfileManagementService, useClass: ProfileManagementServiceMock}

      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      runA11yTests(fixture.nativeElement, loggerService);
    }));
  });

});
