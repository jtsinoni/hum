import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {WorkOrdersStates} from './work-orders-states';
import {RouteConstants} from '@lc-constants/*';

const workOrderRoutes: RootModule = {
  states: WorkOrdersStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(workOrderRoutes)],
  exports: [UIRouterModule]
})
export class WorkOrdersRoutingModule {
}
