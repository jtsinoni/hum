import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {WorkOrderSearchComponent} from './views/work-order-search/work-order-search.component';
import {WorkOrderDetailsComponent} from './views/work-order-details/work-order-details.component';
import {WorkOrderNewComponent} from './views/work-order-new/work-order-new.component';
import {WorkOrderFacilityDrawingsComponent} from './views/work-order-facility-drawings/work-order-facility-drawings.component';
import {WorkOrderBulkUpdateComponent} from './views/work-order-bulk-update/work-order-bulk-update.component';
import {WorkOrderBulkUpdateConfirmComponent} from './views/work-order-bulk-update-confirm/work-order-bulk-update-confirm.component';
import {WorkLoadSummaryComponent} from './views/work-load-summary/work-load-summary.component';
import {WorkLoadForNextMonthComponent} from './views/work-load-for-next-month/work-load-for-next-month.component';
import {WorkLoadBulkUpdateComponent} from './views/work-load-bulk-update/work-load-bulk-update.component';
import {WorkLoadBulkUpdateConfirmComponent} from './views/work-load-bulk-update-confirm/work-load-bulk-update-confirm.component';
import {WorkOrderBulkResultsComponent} from './views/work-order-bulk-results/work-order-bulk-results.component';
import {WorkLoadBulkResultsComponent} from './views/work-load-bulk-results/work-load-bulk-results.component';
import {WorkOrderFormGenerationComponent} from './views/work-order-form-generation/work-order-form-generation.component';
import {WorkOrderPrioritizationComponent} from './views/work-order-prioritization/work-order-prioritization.component';
import {WorkOrderGraphicalSearchComponent} from './views/work-order-graphical-search/work-order-graphical-search.component';
import {CmmsErrorsComponent} from './views/cmms-errors/cmms-errors.component';
import {CoreSearchComponent} from './views/core-search/core-search.component';
import {CoreDetailsComponent} from './views/core-details/core-details.component';
import {MedicalEquipmentWorkOrderSearchComponent} from './medical-equipment/views/medical-equipment-work-order-search/medical-equipment-work-order-search.component';
import {MedicalEquipmentWorkOrderDetailsComponent} from './medical-equipment/views/medical-equipment-work-order-details/medical-equipment-work-order-details.component';
import {MedicalEquipmentWorkOrderNewComponent} from './medical-equipment/views/medical-equipment-work-order-new/medical-equipment-work-order-new.component';


export const WORK_ORDER_CORE_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_CORE_SEARCH.url,
  name: RouteConstants.WORK_ORDER_CORE_SEARCH.name,
  component: CoreSearchComponent,
  data: {'route': RouteConstants.WORK_ORDER_CORE_SEARCH},
  params: {
    'searchRoomId': null,
    'searchRoomNumber': null,
    'searchShowDetail': null,
    'searchWorkOrder': null,
    'isRequiringRework': null,
    'preDefinedSearch': null,
    'days': null,
    'ids': null,
    'searchCriteria': null,
    'workOrderNumbers': null,
    'filterScheduled': false
  }
};

export const WORK_ORDER_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_SEARCH.url,
  name: RouteConstants.WORK_ORDER_SEARCH.name,
  component: WorkOrderSearchComponent,
  data: {'route': RouteConstants.WORK_ORDER_SEARCH},
  params: {
    'searchRoomId': null,
    'searchRoomNumber': null,
    'searchShowDetail': null,
    'searchWorkOrder': null,
    'isRequiringRework': null,
    'preDefinedSearch': null,
    'days': null,
    'ids': null,
    'searchCriteria': null,
    'workOrderNumbers': null,
    'filterScheduled': false
  }
};

export const WORK_ORDER_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_DETAILS.url,
  name: RouteConstants.WORK_ORDER_DETAILS.name,
  component: WorkOrderDetailsComponent,
  data: {'route': RouteConstants.WORK_ORDER_DETAILS},
  params: {'id': null}
};

export const WORK_ORDER_CORE_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_CORE_DETAILS.url,
  name: RouteConstants.WORK_ORDER_CORE_DETAILS.name,
  component: CoreDetailsComponent,
  data: {'route': RouteConstants.WORK_ORDER_CORE_DETAILS},
  params: {'id': null}
};

export const WORK_ORDER_PRIORITIZATION: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_PRIORITIZATION.url,
  name: RouteConstants.WORK_ORDER_PRIORITIZATION.name,
  component: WorkOrderPrioritizationComponent,
  data: {'route': RouteConstants.WORK_ORDER_PRIORITIZATION}
};

export const WORK_ORDER_BULK_UPDATE: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_BULK_UPDATE.url,
  name: RouteConstants.WORK_ORDER_BULK_UPDATE.name,
  component: WorkOrderBulkUpdateComponent,
  data: {'route': RouteConstants.WORK_ORDER_BULK_UPDATE}
};

export const WORK_ORDER_FORM_GENERATION: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_FORM_GENERATION.url,
  name: RouteConstants.WORK_ORDER_FORM_GENERATION.name,
  component: WorkOrderFormGenerationComponent,
  data: {'route': RouteConstants.WORK_ORDER_FORM_GENERATION},
  params: {'id': {type: 'string', array: true, value: null}}
};

export const WORK_ORDER_DETAILS_FORM_GENERATION: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_DETAILS_FORM_GENERATION.url,
  name: RouteConstants.WORK_ORDER_DETAILS_FORM_GENERATION.name,
  component: WorkOrderFormGenerationComponent,
  data: {'route': RouteConstants.WORK_ORDER_DETAILS_FORM_GENERATION},
  params: {'id': {type: 'string', array: true, value: null}}
};

export const WORK_ORDER_BULK_UPDATE_CONFIRM: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_BULK_UPDATE_CONFIRM.url,
  name: RouteConstants.WORK_ORDER_BULK_UPDATE_CONFIRM.name,
  component: WorkOrderBulkUpdateConfirmComponent,
  data: {'route': RouteConstants.WORK_ORDER_BULK_UPDATE_CONFIRM}
};

export const WORK_ORDER_BULK_UPDATE_RESULTS: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_BULK_UPDATE_RESULTS.url,
  name: RouteConstants.WORK_ORDER_BULK_UPDATE_RESULTS.name,
  component: WorkOrderBulkResultsComponent,
  data: {'route': RouteConstants.WORK_ORDER_BULK_UPDATE_RESULTS}
};

export const NEW_WORK_ORDER: Ng2StateDeclaration = {
  url: RouteConstants.NEW_WORK_ORDER.url,
  name: RouteConstants.NEW_WORK_ORDER.name,
  component: WorkOrderNewComponent,
  data: {'route': RouteConstants.NEW_WORK_ORDER}
};

export const WORK_ORDER_FACILITY_DRAWINGS: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_FACILITY_DRAWINGS.url,
  name: RouteConstants.WORK_ORDER_FACILITY_DRAWINGS.name,
  component: WorkOrderFacilityDrawingsComponent,
  data: {'route': RouteConstants.WORK_ORDER_FACILITY_DRAWINGS}
};

export const WORK_LOAD_SUMMARY: Ng2StateDeclaration = {
  url: RouteConstants.WORK_LOAD_SUMMARY.url,
  name: RouteConstants.WORK_LOAD_SUMMARY.name,
  component: WorkLoadSummaryComponent,
  data: {'route': RouteConstants.WORK_LOAD_SUMMARY},
  params: {fromDate: null, toDate: null}
};

export const WORK_LOAD_FOR_NEXT_MONTH: Ng2StateDeclaration = {
  url: RouteConstants.WORK_LOAD_FOR_NEXT_MONTH.url,
  name: RouteConstants.WORK_LOAD_FOR_NEXT_MONTH.name,
  component: WorkLoadForNextMonthComponent,
  data: {'route': RouteConstants.WORK_LOAD_FOR_NEXT_MONTH}
};

export const WORK_LOAD_BULK_UPDATE: Ng2StateDeclaration = {
  url: RouteConstants.WORK_LOAD_BULK_UPDATE.url,
  name: RouteConstants.WORK_LOAD_BULK_UPDATE.name,
  component: WorkLoadBulkUpdateComponent,
  data: {'route': RouteConstants.WORK_LOAD_BULK_UPDATE}
};

export const WORK_LOAD_BULK_UPDATE_CONFIRM: Ng2StateDeclaration = {
  url: RouteConstants.WORK_LOAD_BULK_UPDATE_CONFIRM.url,
  name: RouteConstants.WORK_LOAD_BULK_UPDATE_CONFIRM.name,
  component: WorkLoadBulkUpdateConfirmComponent,
  data: {'route': RouteConstants.WORK_LOAD_BULK_UPDATE_CONFIRM}
};

export const WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE: Ng2StateDeclaration = {
  url: RouteConstants.WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE.url,
  name: RouteConstants.WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE.name,
  component: WorkLoadBulkUpdateComponent,
  data: {'route': RouteConstants.WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE}
};

export const WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE_CONFIRM: Ng2StateDeclaration = {
  url: RouteConstants.WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE_CONFIRM.url,
  name: RouteConstants.WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE_CONFIRM.name,
  component: WorkLoadBulkUpdateConfirmComponent,
  data: {'route': RouteConstants.WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE_CONFIRM}
};

export const WORK_LOAD_BULK_UPDATE_RESULTS: Ng2StateDeclaration = {
  url: RouteConstants.WORK_LOAD_BULK_UPDATE_RESULTS.url,
  name: RouteConstants.WORK_LOAD_BULK_UPDATE_RESULTS.name,
  component: WorkLoadBulkResultsComponent,
  data: {'route': RouteConstants.WORK_LOAD_BULK_UPDATE_RESULTS}
};

export const WORK_ORDER_GRAPHICAL_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.WORK_ORDER_GRAPHICAL_SEARCH.url,
  name: RouteConstants.WORK_ORDER_GRAPHICAL_SEARCH.name,
  component: WorkOrderGraphicalSearchComponent,
  data: {'route': RouteConstants.WORK_ORDER_GRAPHICAL_SEARCH},
  params: {'roomIds': null}
};

export const CMMS_ERRORS: Ng2StateDeclaration = {
  url: RouteConstants.CMMS_ERRORS.url,
  name: RouteConstants.CMMS_ERRORS.name,
  component: CmmsErrorsComponent,
  data: {'route': RouteConstants.CMMS_ERRORS}
};

export const MEDICAL_EQUIPMENT_WORK_ORDER_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_SEARCH.url,
  name: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_SEARCH.name,
  component: MedicalEquipmentWorkOrderSearchComponent,
  data: {'route': RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_SEARCH},
  params: {
    'preDefinedSearch': null
  }
};

export const MEDICAL_EQUIPMENT_WORK_ORDER_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_DETAILS.url,
  name: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_DETAILS.name,
  component: MedicalEquipmentWorkOrderDetailsComponent,
  data: {'route': RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_DETAILS},
  params: {'id': null}
};

export const MEDICAL_EQUIPMENT_WORK_ORDER_NEW: Ng2StateDeclaration = {
  url: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_NEW.url,
  name: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_NEW.name,
  component: MedicalEquipmentWorkOrderNewComponent,
  data: {'route': RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_NEW}
};

export const MEDICAL_EQUIPMENT_WORK_ORDER_NEW_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_NEW_DETAILS.url,
  name: RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_NEW_DETAILS.name,
  component: MedicalEquipmentWorkOrderDetailsComponent,
  data: {'route': RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_NEW_DETAILS},
  params: {'id': null}
};

export const WorkOrdersStates = [
  WORK_ORDER_CORE_SEARCH,
  WORK_ORDER_CORE_DETAILS,
  WORK_ORDER_SEARCH,
  WORK_ORDER_DETAILS,
  WORK_ORDER_PRIORITIZATION,
  WORK_ORDER_BULK_UPDATE,
  WORK_ORDER_FORM_GENERATION,
  WORK_ORDER_DETAILS_FORM_GENERATION,
  WORK_ORDER_BULK_UPDATE_CONFIRM,
  NEW_WORK_ORDER,
  WORK_ORDER_FACILITY_DRAWINGS,
  WORK_LOAD_SUMMARY,
  WORK_LOAD_FOR_NEXT_MONTH,
  WORK_LOAD_BULK_UPDATE,
  WORK_LOAD_BULK_UPDATE_CONFIRM,
  WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE,
  WORK_LOAD_FOR_NEXT_MONTH_BULK_UPDATE_CONFIRM,
  WORK_ORDER_BULK_UPDATE_RESULTS,
  WORK_LOAD_BULK_UPDATE_RESULTS,
  WORK_ORDER_GRAPHICAL_SEARCH,
  CMMS_ERRORS,
  MEDICAL_EQUIPMENT_WORK_ORDER_SEARCH,
  MEDICAL_EQUIPMENT_WORK_ORDER_DETAILS,
  MEDICAL_EQUIPMENT_WORK_ORDER_NEW,
  MEDICAL_EQUIPMENT_WORK_ORDER_NEW_DETAILS
];
