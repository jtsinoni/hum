import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {WorkOrderSearchComponent} from './views/work-order-search/work-order-search.component';
import {UIRouterModule} from '@uirouter/angular';
import {CommonComponentsModule} from '@lc-common-components';
import {FormsModule} from '@angular/forms';
import {WorkOrdersService} from './services/work-orders.service';
import {PipesModule} from '../../pipes/pipes.module';
import {WorkOrdersRoutingModule} from './work-orders-routing.module';
import {WorkOrderDetailsComponent} from './views/work-order-details/work-order-details.component';
import {WorkOrderDetailHeaderComponent} from './components/work-order-detail-header/work-order-detail-header.component';
import {WorkOrderDetailTabContentComponent} from './components/work-order-detail-tab-content/work-order-detail-tab-content.component';
import {WorkOrderCostAssignmentComponent} from './components/work-order-cost-assignment/work-order-cost-assignment.component';
import {WorkOrderNewComponent} from './views/work-order-new/work-order-new.component';
import {WorkOrderLocationComponent} from './components/work-order-location/work-order-location.component';
import {WorkOrderManageComponent} from './components/work-order-manage/work-order-manage.component';
import {WorkOrderImpactsComponent} from './components/work-order-impacts/work-order-impacts.component';
import {WorkOrderCommentsComponent} from './components/work-order-comments/work-order-comments.component';
import {DirectivesModule} from '../../directives/directives.module';
import {WorkOrderImpactAreasComponent} from './components/work-order-impact-areas/work-order-impact-areas.component';
import {WorkOrderImpactComponent} from './components/work-order-impact/work-order-impact.component';
import {WorkOrderImpactDetailsComponent} from './components/work-order-impact-details/work-order-impact-details.component';
import {WorkOrderFacilityDrawingsComponent} from './views/work-order-facility-drawings/work-order-facility-drawings.component';
import {WorkOrderNonCatalogPartsComponent} from './components/work-order-non-catalog-parts/work-order-non-catalog-parts.component';
import {WorkOrderPartsAndMaterialComponent} from './components/work-order-parts-and-material/work-order-parts-and-material.component';
import {WorkOrderStandardsComponent} from './components/work-order-standards/work-order-standards.component';
import {WorkOrderBulkUpdateComponent} from './views/work-order-bulk-update/work-order-bulk-update.component';
import {WorkOrderBulkUpdateService} from './services/work-order-bulk-update.service';
import {WorkOrderBulkUpdateConfirmComponent} from './views/work-order-bulk-update-confirm/work-order-bulk-update-confirm.component';
import {WorkOrderImpactOccupantsComponent} from './components/work-order-impact-occupants/work-order-impact-occupants.component';
import {WorkLoadSummaryComponent} from './views/work-load-summary/work-load-summary.component';
import {WorkLoadComponent} from './components/work-load/work-load.component';
import {WorkLoadForNextMonthComponent} from './views/work-load-for-next-month/work-load-for-next-month.component';
import {WorkOrderEquipmentTabContentComponent} from './components/work-order-equipment-tab-content/work-order-equipment-tab-content.component';
import {WorkOrderSpaceTabContentComponent} from './components/work-order-space-tab-content/work-order-space-tab-content.component';
import {WorkOrderEnvironmentalImpactsComponent} from './components/work-order-environmental-impacts/work-order-environmental-impacts.component';
import {WorkLoadBulkUpdateService} from './services/work-load-bulk-update.service';
import {WorkLoadBulkUpdateComponent} from './views/work-load-bulk-update/work-load-bulk-update.component';
import {WorkLoadBulkUpdateConfirmComponent} from './views/work-load-bulk-update-confirm/work-load-bulk-update-confirm.component';
import {WorkOrderAssignmentComponent} from './components/work-order-assignment/work-order-assignment.component';
import {WorkOrderAssignmentEstimatedCostsComponent} from './components/work-order-assignment-estimated-costs/work-order-assignment-estimated-costs.component';
import {WorkOrderAssignmentActualCostsComponent} from './components/work-order-assignment-actual-costs/work-order-assignment-actual-costs.component';
import {WorkOrderAssignmentReworkCostsComponent} from './components/work-order-assignment-rework-costs/work-order-assignment-rework-costs.component';
import {WorkOrderBulkResultsComponent} from './views/work-order-bulk-results/work-order-bulk-results.component';
import {WorkOrderAssignmentProrateActualCostComponent} from './components/work-order-assignment-prorate-actual-cost/work-order-assignment-prorate-actual-cost.component';
import {WorkOrderAssociatedRecordsComponent} from './components/work-order-associated-records/work-order-associated-records.component';
import {WorkOrderProjectComponent} from './components/work-order-project/work-order-project.component';
import {WorkOrderQualityEventsComponent} from './components/work-order-quality-events/work-order-quality-events.component';
import {WorkOrderNewQualityEventComponent} from './components/work-order-new-quality-event/work-order-new-quality-event.component';
import {WorkLoadBulkResultsComponent} from './views/work-load-bulk-results/work-load-bulk-results.component';
import {WorkOrderChangePriorityComponent} from './components/work-order-change-priority/work-order-change-priority.component';
import {WorkOrderPrioritizationComponent} from './views/work-order-prioritization/work-order-prioritization.component';
import {DragDropModule} from '@angular/cdk/drag-drop';
import {WorkOrderPrioritizationStateService} from './services/work-order-prioritization-state.service';
import {WorkOrderFormGenerationComponent} from './views/work-order-form-generation/work-order-form-generation.component';
import {NgxBarcodeModule} from 'ngx-barcode';
import {WorkOrderFormsComponent} from './components/work-order-forms/work-order-forms.component';
import {UnscheduledWorkRequestFormComponent} from './components/work-order-forms/unscheduled-work-request-form/unscheduled-work-request-form.component';
import {WorkOrderTagsComponent} from './components/work-order-tags/work-order-tags.component';
import {PreventativeMaintenanceWorkOrderFormComponent} from './components/work-order-forms/preventative-maintenance-work-order-form/preventative-maintenance-work-order-form.component';
import {Navfac9WorkRequestFormComponent} from './components/work-order-forms/navfac9-work-request-form/navfac9-work-request-form.component';
import {CustomerComplaintRecordFormComponent} from './components/work-order-forms/customer-complaint-record-form/customer-complaint-record-form.component';
import {WorkOrderEquipmentInspectionComponent} from './components/work-order-equipment-inspection/work-order-equipment-inspection.component';
import {WorkOrderGraphicalSearchComponent} from './views/work-order-graphical-search/work-order-graphical-search.component';
import {CmmsErrorsComponent} from './views/cmms-errors/cmms-errors.component';
import {EquipmentComponent} from './components/equipment/equipment.component';
import {WorkOrderSurveyComponent} from './components/work-order-survey/work-order-survey.component';
import {LegacyWorkRequestStatusHistoryComponent} from './components/legacy-work-request-status-history/legacy-work-request-status-history.component';
import {LegacyQualityControlStatusHistoryComponent} from './components/legacy-quality-control-status-history/legacy-quality-control-status-history.component';
import {LegacyQualityAssuranceStatusHistoryComponent} from './components/legacy-quality-assurance-status-history/legacy-quality-assurance-status-history.component';
import {DaForm4283Component} from './components/work-order-forms/da-form4283/da-form4283.component';
import {CoreWorkOrdersModule} from './core-work-orders/core-work-orders.module';
import {CoreSearchComponent} from './views/core-search/core-search.component';
import {WorkOrderDomainSelectorComponent} from './core-work-orders/components/work-order-domain-selector/work-order-domain-selector.component';
import {CoreDetailsComponent} from './views/core-details/core-details.component';
import {MedicalEquipmentModule} from './medical-equipment/medical-equipment.module';
import {WorkOrdersApiService} from './services/work-orders-api.service';
import {WorkOrderApiServiceFactory} from './factory/work-order-api-service.factory';
import {RealPropertyWorkOrderHeaderComponent} from './real-property/components/real-property-work-order-header/real-property-work-order-header.component';
import {RealPropertyWorkOrderAssociatedProjectRequirementsComponent} from './real-property/components/real-property-work-order-associated-project-requirements/real-property-work-order-associated-project-requirements.component';
import {WorkOrderServiceFactory} from './factory/work-order-service.factory';
import {RealPropertyWorkOrderService} from './real-property/services/real-property-work-order.service';
import {WorkOrderAssignmentEditActualCostComponent} from './components/work-order-assignment-edit-actual-cost/work-order-assignment-edit-actual-cost.component';

@NgModule({
  declarations: [
    WorkOrderSearchComponent,
    WorkOrderDetailsComponent,
    WorkOrderDetailHeaderComponent,
    WorkOrderDetailTabContentComponent,
    WorkOrderCostAssignmentComponent,
    WorkOrderNewComponent,
    WorkOrderLocationComponent,
    WorkOrderNewComponent,
    WorkOrderManageComponent,
    WorkOrderImpactsComponent,
    WorkOrderCommentsComponent,
    WorkOrderImpactAreasComponent,
    WorkOrderImpactComponent,
    WorkOrderImpactDetailsComponent,
    WorkOrderCommentsComponent,
    WorkOrderFacilityDrawingsComponent,
    WorkOrderNonCatalogPartsComponent,
    WorkOrderPartsAndMaterialComponent,
    WorkOrderStandardsComponent,
    WorkOrderSurveyComponent,
    WorkOrderTagsComponent,
    WorkOrderBulkUpdateComponent,
    WorkOrderBulkUpdateConfirmComponent,
    WorkOrderImpactOccupantsComponent,
    WorkLoadSummaryComponent,
    WorkLoadComponent,
    WorkOrderEquipmentTabContentComponent,
    WorkOrderSpaceTabContentComponent,
    WorkOrderEnvironmentalImpactsComponent,
    WorkLoadComponent,
    WorkLoadForNextMonthComponent,
    WorkLoadBulkUpdateComponent,
    WorkLoadBulkUpdateConfirmComponent,
    WorkOrderAssignmentComponent,
    WorkOrderAssignmentEstimatedCostsComponent,
    WorkOrderAssignmentActualCostsComponent,
    WorkOrderAssignmentReworkCostsComponent,
    WorkOrderBulkResultsComponent,
    WorkOrderAssignmentProrateActualCostComponent,
    WorkOrderAssociatedRecordsComponent,
    WorkOrderProjectComponent,
    WorkOrderQualityEventsComponent,
    WorkOrderNewQualityEventComponent,
    WorkLoadBulkResultsComponent,
    WorkOrderChangePriorityComponent,
    WorkOrderPrioritizationComponent,
    WorkOrderChangePriorityComponent,
    WorkOrderNewQualityEventComponent,
    WorkOrderFormGenerationComponent,
    WorkOrderFormsComponent,
    UnscheduledWorkRequestFormComponent,
    PreventativeMaintenanceWorkOrderFormComponent,
    Navfac9WorkRequestFormComponent,
    CustomerComplaintRecordFormComponent,
    WorkOrderEquipmentInspectionComponent,
    WorkOrderGraphicalSearchComponent,
    CmmsErrorsComponent,
    EquipmentComponent,
    LegacyWorkRequestStatusHistoryComponent,
    LegacyQualityControlStatusHistoryComponent,
    LegacyQualityAssuranceStatusHistoryComponent,
    DaForm4283Component,
    CoreSearchComponent,
    CoreDetailsComponent,
    CoreSearchComponent,
    RealPropertyWorkOrderHeaderComponent,
    RealPropertyWorkOrderAssociatedProjectRequirementsComponent,
    WorkOrderAssignmentEditActualCostComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule.forRoot(),
    UIRouterModule.forChild(),
    PipesModule,
    WorkOrdersRoutingModule,
    DirectivesModule,
    DragDropModule,
    NgxBarcodeModule,
    CoreWorkOrdersModule,
    MedicalEquipmentModule
  ],
  exports: [
    WorkOrderDomainSelectorComponent
  ],
  providers: [
    WorkOrdersService,
    WorkOrdersApiService,
    WorkOrderBulkUpdateService,
    WorkLoadBulkUpdateService,
    WorkOrderPrioritizationStateService,
    WorkOrderApiServiceFactory,
    RealPropertyWorkOrderService,
    WorkOrderServiceFactory
  ]
})
export class WorkOrdersModule {
}
