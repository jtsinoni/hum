import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {CommonComponentsModule} from '@lc-common-components';
import {PipesModule} from '../../pipes/pipes.module';
import {FormsModule} from '@angular/forms';
import {DeliverylistFilterPipe} from './pipes/deliverylist-filter-pipe';
import {FulfillmentActivityComponent} from './fulfillment-activity/fulfillment-activity.component';
import {OrderFulfillmentComponent} from './order-fulfillment/order-fulfillment.component';
import {PicklistManagementComponent} from './picklist-management/picklist-management.component';
import {StagedItemsComponent} from './staged-items/staged-items.component';
import {FulfillmentPipesModule} from './pipes/fulfillment-pipes.module';
import {UIRouterModule} from '@uirouter/angular';
import {PickListReportComponent} from './picklist-management/pick-list-report/pick-list-report.component';
import {PicklistNotesComponent} from './picklist-management/picklist-notes/picklist-notes.component';
import {PickListReprintReportComponent} from './reprint-picklist/pick-list-reprint-report/pick-list-reprint-report.component';


@NgModule({
  imports: [
    UIRouterModule,
    CommonModule,
    CommonComponentsModule.forRoot(),
    PipesModule,
    FormsModule,
    FulfillmentPipesModule.forRoot()

  ],
  entryComponents: [PickListReportComponent, PickListReprintReportComponent],
  declarations: [
    FulfillmentActivityComponent,
    OrderFulfillmentComponent,
    PicklistManagementComponent,
    PicklistNotesComponent,
    StagedItemsComponent,
    PickListReportComponent,
    PickListReprintReportComponent
  ],
  exports: [
    FulfillmentActivityComponent,
    OrderFulfillmentComponent,
    StagedItemsComponent,
    PicklistManagementComponent,
    StagedItemsComponent,
    DeliverylistFilterPipe,
    PickListReportComponent,
    PickListReprintReportComponent
  ]
})
export class FulfillmentComponentModule {
}
