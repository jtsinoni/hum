import {NgModule} from '@angular/core';

import {DeliverylistFilterPipe} from './pipes/deliverylist-filter-pipe';
import {FulfillmentActivityComponent} from './fulfillment-activity/fulfillment-activity.component';
import {OrderFulfillmentComponent} from './order-fulfillment/order-fulfillment.component';
import {PicklistManagementComponent} from './picklist-management/picklist-management.component';
import {FulfillmentRoutingModule} from './fulfillment-router.module';
import {StagedItemsComponent} from './staged-items/staged-items.component';
import {FulfillmentComponentModule} from './fulfillment-component.module';
import {PickListPrintComponent} from './picklist-management/pick-list-print/pick-list-print.component';
import {PickListReportComponent} from './picklist-management/pick-list-report/pick-list-report.component';
import {DeliveryListReportComponent} from './deliverylist-management/print-delivery-list/delivery-list-report/delivery-list-report.component';
import {DeliveryListMultipleReportsComponent} from './deliverylist-management/delivery-list-multiple-reports/delivery-list-multiple-reports.component';
import {PrintDeliveryListComponent} from './deliverylist-management/print-delivery-list/print-delivery-list.component';
import {DeliveryListPrintComponent} from './deliverylist-management/print-delivery-list/delivery-list-print/delivery-list-print.component';
import {CommonComponentsModule} from '@lc-common-components';
import {CommonModule} from '@angular/common';
import {FulfillmentManagementComponent} from './fulfillment-management/fulfillment-management.component';
import {ReprintPicklistComponent} from './reprint-picklist/reprint-picklist.component';
import {PipesModule} from '../../pipes/pipes.module';
import {FormsModule} from '@angular/forms';
import {PicklistMultipleReportsComponent} from './reprint-picklist/picklist-multiple-reports/picklist-multiple-reports.component';
import {PicklistLayoutComponent} from './picklist-layout/picklist-layout.component';
import {PickListReprintReportComponent} from './reprint-picklist/pick-list-reprint-report/pick-list-reprint-report.component';
import {GeneratedDeliveryListComponent} from './deliverylist-management/generated-delivery-list/generated-delivery-list.component';
import {NgxBarcodeModule} from 'ngx-barcode';


@NgModule({
  imports: [
    CommonModule,
    FulfillmentRoutingModule,
    FulfillmentComponentModule,
    CommonComponentsModule,
    PipesModule,
    FormsModule,
    NgxBarcodeModule,

  ],
  entryComponents: [PickListReportComponent, PickListReprintReportComponent, DeliveryListReportComponent, PicklistMultipleReportsComponent, PrintDeliveryListComponent],
  declarations: [
    DeliveryListReportComponent,
    PrintDeliveryListComponent,
    DeliveryListMultipleReportsComponent,
    DeliveryListPrintComponent,
    FulfillmentManagementComponent,
    PickListPrintComponent,
    ReprintPicklistComponent,
    PicklistLayoutComponent,
    PicklistMultipleReportsComponent,
    GeneratedDeliveryListComponent
  ],
  exports: [
    FulfillmentActivityComponent,
    OrderFulfillmentComponent,
    StagedItemsComponent,
    PicklistManagementComponent,
    StagedItemsComponent,
    DeliverylistFilterPipe,
    DeliveryListReportComponent,
    PrintDeliveryListComponent,
    DeliveryListMultipleReportsComponent,
    DeliveryListPrintComponent,
    ReprintPicklistComponent,
    GeneratedDeliveryListComponent
  ]
})
export class FulfillmentModule {
}
