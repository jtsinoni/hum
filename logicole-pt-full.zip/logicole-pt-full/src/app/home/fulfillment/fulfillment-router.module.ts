import {RootModule, UIRouterModule} from '@uirouter/angular';
import {FulfillmentStates} from './fulfillment-states';
import {NgModule} from '@angular/core';

const fulfillmentRoutes: RootModule = {
  states: FulfillmentStates
};

@NgModule({
  imports: [UIRouterModule.forChild(fulfillmentRoutes)],
  exports: [UIRouterModule]

})
export class FulfillmentRoutingModule {
}
