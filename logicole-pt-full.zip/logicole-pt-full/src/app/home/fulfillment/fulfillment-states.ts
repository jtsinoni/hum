import {RouteConstants} from '@lc-constants/*';
import {Ng2StateDeclaration} from '@uirouter/angular';
import {PicklistManagementComponent} from './picklist-management/picklist-management.component';
import {StagedItemsComponent} from './staged-items/staged-items.component';
import {FulfillmentActivityComponent} from './fulfillment-activity/fulfillment-activity.component';
import {PickListPrintComponent} from './picklist-management/pick-list-print/pick-list-print.component';
import {DeliveryListPrintComponent} from './deliverylist-management/print-delivery-list/delivery-list-print/delivery-list-print.component';
import {FulfillmentManagementComponent} from './fulfillment-management/fulfillment-management.component';
import {PicklistNotesComponent} from './picklist-management/picklist-notes/picklist-notes.component';

export const FULFILLMENT_ROOT: Ng2StateDeclaration = {
  url: RouteConstants.FULFILLMENT.url,
  name: RouteConstants.FULFILLMENT.name,
  component: FulfillmentActivityComponent, data: {'route': RouteConstants.FULFILLMENT}
};

export const FULFILLMENT_ORDER_FULFILLMENT_ACTIVITY: Ng2StateDeclaration = {
  name: RouteConstants.FULFILLMENT_FULFILLMENT_ACTIVITY.name,
  url: RouteConstants.FULFILLMENT_FULFILLMENT_ACTIVITY.url,
  component: FulfillmentActivityComponent, data: {'route': RouteConstants.FULFILLMENT_FULFILLMENT_ACTIVITY}
};

export const FULFILLMENT_ORDER_FULFILLMENT: Ng2StateDeclaration = {
  name: RouteConstants.FULFILLMENT_ORDER_FULFILLMENT.name,
  url: RouteConstants.FULFILLMENT_ORDER_FULFILLMENT.url,
  component: FulfillmentManagementComponent, data: {'route': RouteConstants.FULFILLMENT_ORDER_FULFILLMENT},
  params: {
    'fulfillmentManagementActiveTab': null,
  }
};
export const FULFILLMENT_STAGED_ITEMS: Ng2StateDeclaration = {
  name: RouteConstants.FULFILLMENT_STAGED_ITEMS.name,
  url: RouteConstants.FULFILLMENT_STAGED_ITEMS.url,
  component: StagedItemsComponent, data: {'route': RouteConstants.FULFILLMENT_STAGED_ITEMS}
};
export const FULFILLMENT_PICKLIST_MANAGEMENT: Ng2StateDeclaration = {
  name: RouteConstants.FULFILLMENT_PICKLIST_MANAGEMENT.name,
  url: RouteConstants.FULFILLMENT_PICKLIST_MANAGEMENT.url,
  component: PicklistManagementComponent, data: {'route': RouteConstants.FULFILLMENT_PICKLIST_MANAGEMENT}
};
export const FULFILLMENT_PICKLIST_NOTES: Ng2StateDeclaration = {
  name: RouteConstants.PICKLIST_NOTES.name,
  url: RouteConstants.PICKLIST_NOTES.url,
  component: PicklistNotesComponent, data: {'route': RouteConstants.PICKLIST_NOTES}
};
export const FULFILLMENT_PICKLIST_REPORT: Ng2StateDeclaration = {
  name: RouteConstants.FULFILLMENT_PICKLIST_REPORT.name,
  url: RouteConstants.FULFILLMENT_PICKLIST_REPORT.url,
  component: PickListPrintComponent, data: {'route': RouteConstants.FULFILLMENT_PICKLIST_REPORT},
  params: {
    'component': null,
    'goPrint': null,
    'fulfillmentManagementActiveTab': null
  }
};
export const FULFILLMENT_DELIVERY_LIST_REPORT: Ng2StateDeclaration = {
  name: RouteConstants.FULFILLMENT_DELIVERY_LIST_REPORT.name,
  url: RouteConstants.FULFILLMENT_DELIVERY_LIST_REPORT.url,
  component: DeliveryListPrintComponent, data: {'route': RouteConstants.FULFILLMENT_DELIVERY_LIST_REPORT},
    params: {
  'component': null,
    'goPrint': null,
    'fulfillmentManagementActiveTab': null
}
};


export const FulfillmentStates: Ng2StateDeclaration[] = [
  FULFILLMENT_ROOT,
  FULFILLMENT_DELIVERY_LIST_REPORT,
  FULFILLMENT_PICKLIST_MANAGEMENT,
  FULFILLMENT_ORDER_FULFILLMENT,
  FULFILLMENT_ORDER_FULFILLMENT_ACTIVITY,
  FULFILLMENT_STAGED_ITEMS,
  FULFILLMENT_PICKLIST_NOTES,
  FULFILLMENT_PICKLIST_REPORT
];
