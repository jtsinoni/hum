import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {AssetComponent} from './asset.component';
import {MaintenanceProceduresComponent} from './maintenance-procedures/views/maintenance-procedures/maintenance-procedures.component';
import {AssetDataManagementComponent} from './data-management/asset-data-management.component';
import {ClassificationRequestsComponent} from './classification-request/views/classification-requests/classification-requests.component';
import {NewClassificationRequestComponent} from './classification-request/views/new-classification-request/new-classification-request.component';
import {ManufacturerRequestManagementComponent} from './classification-request/views/manufacturer-request-management/manufacturer-request-management.component';
import {NomenclatureRequestManagementComponent} from './classification-request/views/nomenclature-request-management/nomenclature-request-management.component';
import {NomenclatureSearchComponent} from './classification/nomenclature/views/nomenclature-search/nomenclature-search.component';
import {NomenclatureDetailsComponent} from './classification/nomenclature/views/nomenclature-details/nomenclature-details.component';
import {ManufacturerSearchComponent} from './classification/manufacturer/views/manufacturer-search/manufacturer-search.component';
import {ManufacturerDetailsComponent} from './classification/manufacturer/views/manufacturer-details/manufacturer-details.component';
import {MaintenanceProcedureDetailComponent} from './maintenance-procedures/views/maintenance-procedure-detail/maintenance-procedure-detail.component';
import {AssetManagementComponent} from './asset-management/asset-management.component';
import {AssetDetailsComponent} from './asset-management/views/asset-details/asset-details.component';
import {ProcedureScheduleDetailComponent} from './maintenance-schedule/views/procedure-schedule-detail/procedure-schedule-detail.component';
import {AssetNewComponent} from './asset-management/views/asset-new/asset-new.component';
import {MaintenanceSchedulesComponent} from './maintenance-schedule/views/maintenance-schedules/maintenance-schedules.component';
import {AssetGroupsComponent} from './asset-groups/asset-groups.component';
import {AssetGroupsDetailsComponent} from './asset-groups/views/asset-groups-details/asset-groups-details.component';
import {AssetManagementLookupComponent} from './asset-management-lookup/asset-management-lookup.component';
import {AssemblyCategoryComponent} from './asset-management-lookup/components/assembly-category/assembly-category.component';
import {FacilitySubSystemComponent} from './asset-management-lookup/components/facility-sub-system/facility-sub-system.component';
import {FacilitySystemComponent} from './asset-management-lookup/components/facility-system/facility-system.component';
import {FrequencyComponent} from './asset-management-lookup/components/frequency/frequency.component';
import {SkillComponent} from '../../common-components/lc-reference-data/skill/skill.component';
import {SpecialtyComponent} from './asset-management-lookup/components/specialty/specialty.component';
import {AssetWarrantyInfoComponent} from './asset-warranty-info/asset-warranty-info.component';
import {AssetWarrantyDetailsComponent} from './asset-warranty-info/views/asset-warranty-details/asset-warranty-details.component';
import {MaintenanceSchedulesBulkUpdateComponent} from './maintenance-schedule/views/maintenance-schedules-bulk-update/maintenance-schedules-bulk-update.component';
import {MaintenanceSchedulesBulkUpdateConfirmComponent} from './maintenance-schedule/views/maintenance-schedules-bulk-update-confirm/maintenance-schedules-bulk-update-confirm.component';
import {RegulatoryComplianceActionComponent} from './asset-management-lookup/components/regulatory-compliance-action/regulatory-compliance-action.component';
import {RegulatoryComplianceCodeComponent} from './asset-management-lookup/components/regulatory-compliance-code/regulatory-compliance-code.component';
import {NewNonAssetScheduleComponent} from './maintenance-schedule/components/new-non-asset-schedule/new-non-asset-schedule.component';
import {BulkUpdateConfirmComponent} from './asset-management/views/bulk-update-confirm/bulk-update-confirm.component';
import {BulkUpdateResultsComponent} from './asset-management/views/bulk-update-results/bulk-update-results.component';
import {BulkSelectFieldsComponent} from './asset-management/views/bulk-select-fields/bulk-select-fields.component';
import {MaintenanceProceduresBulkUpdateConfirmComponent} from './maintenance-procedures/views/maintenance-procedures-bulk-update-confirm/maintenance-procedures-bulk-update-confirm.component';
import {MaintenanceProceduresBulkUpdateResultsComponent} from './maintenance-procedures/views/maintenance-procedures-bulk-update-results/maintenance-procedures-bulk-update-results.component';
import {AssetGraphicalSearchComponent} from './asset-management/views/asset-graphical-search/asset-graphical-search.component';
import {SpaceEquipmentCriteriaComponent} from './asset-management-lookup/components/space-and-equipment-criteria/space-equipment-criteria.component';
import {AuthoritativeSpaceAndEquipmentCriteriaComponent} from './asset-management-lookup/components/authoritative-space-and-equipment-criteria/authoritative-space-and-equipment-criteria.component';
import {MilitaryStandard1691Component} from './asset-management-lookup/components/military-standard-1691/military-standard-1691.component';
import {MilitaryStandard1691DetailsComponent} from './asset-management-lookup/components/military-standard-1691-details/military-standard-1691-details.component';
import {MinimumEssentialCharacteristicsComponent} from './minimum-essential-characteristics/minimum-essential-characteristics.component';
import {AssetDetailsDrawingComponent} from './asset-management/views/asset-details-drawing/asset-details-drawing.component';
import {MaintenanceSchedulesBulkUpdateResultsComponent} from './maintenance-schedule/views/maintenance-schedules-bulk-update-results/maintenance-schedules-bulk-update-results.component';
import {NewNomenclatureComponent} from './classification/nomenclature/views/new-nomenclature/new-nomenclature.component';
import {MaintenancePlansComponent} from '../maintenance/maintenance-plan/view/maintenance-plans/maintenance-plans.component';
import {MaintenancePlansAndSchedulesComponent} from '../maintenance/maintenance-plan/view/maintenance-plans-and-schedules/maintenance-plans-and-schedules.component';
import {MaintenancePlanNewComponent} from '../maintenance/maintenance-plan/view/maintenance-plan-new/maintenance-plan-new.component';
import {MaintenancePlanDetailsComponent} from '../maintenance/maintenance-plan/view/maintenance-plan-details/maintenance-plan-details.component';
import {ManufacturerCreateComponent} from './classification/manufacturer/views/manufacturer-create/manufacturer-create.component';

export const ASSET: Ng2StateDeclaration = {
  url: RouteConstants.MAINTENANCE.url,
  name: RouteConstants.MAINTENANCE.name,
  abstract: true,
  component: AssetComponent,
  data: {'route': RouteConstants.MAINTENANCE}
};

export const ASSET_WARRANTY_INFO: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_WARRANTY_INFO.url,
  name: RouteConstants.ASSET_WARRANTY_INFO.name,
  component: AssetWarrantyInfoComponent,
  data: {'route': RouteConstants.ASSET_WARRANTY_INFO}
};

export const ASSET_WARRANTY_INFO_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_WARRANTY_INFO_DETAILS.url,
  name: RouteConstants.ASSET_WARRANTY_INFO_DETAILS.name,
  component: AssetWarrantyDetailsComponent,
  data: {'route': RouteConstants.ASSET_WARRANTY_INFO_DETAILS}
};

export const ASSET_NOMENCLATURE: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_NOMENCLATURE.url,
  name: RouteConstants.EQUIPMENT_NOMENCLATURE.name,
  component: NomenclatureSearchComponent,
  data: {'route': RouteConstants.EQUIPMENT_NOMENCLATURE}
};

export const EQUIPMENT_NOMENCLATURE_NEW: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_NOMENCLATURE_NEW.url,
  name: RouteConstants.EQUIPMENT_NOMENCLATURE_NEW.name,
  component: NewNomenclatureComponent,
  data: {'route': RouteConstants.EQUIPMENT_NOMENCLATURE_NEW}
};

export const ASSET_NOMENCLATURE_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_NOMENCLATURE_DETAILS.url,
  name: RouteConstants.EQUIPMENT_NOMENCLATURE_DETAILS.name,
  component: NomenclatureDetailsComponent,
  data: {'route': RouteConstants.EQUIPMENT_NOMENCLATURE_DETAILS},
  params: {'id': null, 'code': null}
};

export const ASSET_MANUFACTURER: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_MANUFACTURER.url,
  name: RouteConstants.EQUIPMENT_MANUFACTURER.name,
  component: ManufacturerSearchComponent,
  data: {'route': RouteConstants.EQUIPMENT_MANUFACTURER}
};

export const ASSET_MANUFACTURER_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_MANUFACTURER_DETAILS.url,
  name: RouteConstants.EQUIPMENT_MANUFACTURER_DETAILS.name,
  component: ManufacturerDetailsComponent,
  data: {'route': RouteConstants.EQUIPMENT_MANUFACTURER_DETAILS}
};

export const ASSET_MANUFACTURER_NEW: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_MANUFACTURER_NEW.url,
  name: RouteConstants.EQUIPMENT_MANUFACTURER_NEW.name,
  component: ManufacturerCreateComponent,
  data: {'route': RouteConstants.EQUIPMENT_MANUFACTURER_NEW}
};

export const MAINTENANCE_PROCEDURES: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_MAINTENANCE_PROCEDURES.url,
  name: RouteConstants.ASSET_MAINTENANCE_PROCEDURES.name,
  component: MaintenanceProceduresComponent,
  data: {'route': RouteConstants.ASSET_MAINTENANCE_PROCEDURES}
};

export const MAINTENANCE_PROCEDURES_BULK_UPDATE_CONFIRM: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_MAINTENANCE_PROCEDURES_BULK_UPDATE_CONFIRM.url,
  name: RouteConstants.ASSET_MAINTENANCE_PROCEDURES_BULK_UPDATE_CONFIRM.name,
  component: MaintenanceProceduresBulkUpdateConfirmComponent,
  data: {'route': RouteConstants.ASSET_MAINTENANCE_PROCEDURES_BULK_UPDATE_CONFIRM}
};

export const MAINTENANCE_PROCEDURES_BULK_UPDATE_RESULTS: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_MAINTENANCE_PROCEDURES_BULK_UPDATE_RESULTS.url,
  name: RouteConstants.ASSET_MAINTENANCE_PROCEDURES_BULK_UPDATE_RESULTS.name,
  component: MaintenanceProceduresBulkUpdateResultsComponent,
  data: {'route': RouteConstants.ASSET_MAINTENANCE_PROCEDURES_BULK_UPDATE_RESULTS}
};

export const MAINTENANCE_PROCEDURES_DETAIL: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_MAINTENANCE_PROCEDURE_DETAIL.url,
  name: RouteConstants.ASSET_MAINTENANCE_PROCEDURE_DETAIL.name,
  component: MaintenanceProcedureDetailComponent,
  data: {'route': RouteConstants.ASSET_MAINTENANCE_PROCEDURE_DETAIL},
  params: {'id': {type: 'string', value: null, dynamic: true}}
};

export const MAINTENANCE_PLANS_AND_SCHEDULES: Ng2StateDeclaration = {
  url: RouteConstants.MAINTENANCE_PLANS_AND_SCHEDULES.url,
  name: RouteConstants.MAINTENANCE_PLANS_AND_SCHEDULES.name,
  component: MaintenancePlansAndSchedulesComponent,
  data: {'route': RouteConstants.MAINTENANCE_PLANS_AND_SCHEDULES}
};

export const MAINTENANCE_SCHEDULES: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_MAINTENANCE_SCHEDULES.url,
  name: RouteConstants.ASSET_MAINTENANCE_SCHEDULES.name,
  component: MaintenanceSchedulesComponent,
  data: {'route': RouteConstants.ASSET_MAINTENANCE_SCHEDULES}
};

export const ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE.url,
  name: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE.name,
  component: MaintenanceSchedulesBulkUpdateComponent,
  data: {'route': RouteConstants.ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE}
};

export const ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_CONFIRMATION: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_CONFIRMATION.url,
  name: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_CONFIRMATION.name,
  component: MaintenanceSchedulesBulkUpdateConfirmComponent,
  data: {'route': RouteConstants.ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_CONFIRMATION}
};

export const ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_RESULTS: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_RESULTS.url,
  name: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_RESULTS.name,
  component: MaintenanceSchedulesBulkUpdateResultsComponent,
  data: {'route': RouteConstants.ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_RESULTS}
};

export const MAINTENANCE_SCHEDULES_DETAIL: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_DETAIL.url,
  name: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_DETAIL.name,
  component: ProcedureScheduleDetailComponent,
  data: {'route': RouteConstants.ASSET_MAINTENANCE_SCHEDULES_DETAIL},
  params: {'id': {type: 'string', value: null, dynamic: true}}
};

export const MAINTENANCE_SCHEDULES_NEW_NON_ASSET_SCHEDULE: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_NEW_NON_ASSET_SCHEDULE.url,
  name: RouteConstants.ASSET_MAINTENANCE_SCHEDULES_NEW_NON_ASSET_SCHEDULE.name,
  component: NewNonAssetScheduleComponent,
  data: {'route': RouteConstants.ASSET_MAINTENANCE_SCHEDULES_NEW_NON_ASSET_SCHEDULE}
};

export const MAINTENANCE_PLANS: Ng2StateDeclaration = {
  url: RouteConstants.MAINTENANCE_PLANS.url,
  name: RouteConstants.MAINTENANCE_PLANS.name,
  component: MaintenancePlansComponent,
  data: {'route': RouteConstants.MAINTENANCE_PLANS}
};

export const MAINTENANCE_PLAN_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.MAINTENANCE_PLAN_DETAILS.url,
  name: RouteConstants.MAINTENANCE_PLAN_DETAILS.name,
  component: MaintenancePlanDetailsComponent,
  data: {'route': RouteConstants.MAINTENANCE_PLAN_DETAILS},
  params: {'id': null}
};

export const NEW_MAINTENANCE_PLAN: Ng2StateDeclaration = {
  url: RouteConstants.NEW_MAINTENANCE_PLAN.url,
  name: RouteConstants.NEW_MAINTENANCE_PLAN.name,
  component: MaintenancePlanNewComponent,
  data: {'route': RouteConstants.NEW_MAINTENANCE_PLAN},
  params: {'id': null, 'procedureSummary': null}
};

export const DATA_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_DATA_MANAGEMENT.url,
  name: RouteConstants.ASSET_DATA_MANAGEMENT.name,
  component: AssetDataManagementComponent,
  data: {'route': RouteConstants.ASSET_DATA_MANAGEMENT}
};

export const ASSET_MANAGEMENT_MAINTENANCE_SCHEDULE_DETAIL: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_MANAGEMENT_MAINTENANCE_SCHEDULE_DETAIL.url,
  name: RouteConstants.ASSET_MANAGEMENT_MAINTENANCE_SCHEDULE_DETAIL.name,
  component: ProcedureScheduleDetailComponent,
  data: {'route': RouteConstants.ASSET_MANAGEMENT_MAINTENANCE_SCHEDULE_DETAIL},
  params: {'id' : {type: 'string'}}
};

export const EQUIPMENT_CLASSIFICATION_REQUEST: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_CLASSIFICATION_REQUEST.url,
  name: RouteConstants.EQUIPMENT_CLASSIFICATION_REQUEST.name,
  component: ClassificationRequestsComponent,
  data: {'route': RouteConstants.EQUIPMENT_CLASSIFICATION_REQUEST}
};

export const EQUIPMENT_NEW_CLASSIFICATION_REQUEST: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_NEW_CLASSIFICATION_REQUEST.url,
  name: RouteConstants.EQUIPMENT_NEW_CLASSIFICATION_REQUEST.name,
  component: NewClassificationRequestComponent,
  data: {'route': RouteConstants.EQUIPMENT_NEW_CLASSIFICATION_REQUEST}
};

export const EQUIPMENT_MANUFACTURER_REQUEST_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_MANUFACTURER_REQUEST_MANAGEMENT.url,
  name: RouteConstants.EQUIPMENT_MANUFACTURER_REQUEST_MANAGEMENT.name,
  component: ManufacturerRequestManagementComponent,
  data: {'route': RouteConstants.EQUIPMENT_MANUFACTURER_REQUEST_MANAGEMENT}
};

export const EQUIPMENT_NOMENCLATURE_REQUEST_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_NOMENCLATURE_REQUEST_MANAGEMENT.url,
  name: RouteConstants.EQUIPMENT_NOMENCLATURE_REQUEST_MANAGEMENT.name,
  component: NomenclatureRequestManagementComponent,
  data: {'route': RouteConstants.EQUIPMENT_NOMENCLATURE_REQUEST_MANAGEMENT}
};

export const ASSET_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_RECORDS.url,
  name: RouteConstants.EQUIPMENT_RECORDS.name,
  component: AssetManagementComponent,
  data: {'route': RouteConstants.EQUIPMENT_RECORDS},
  params: {
    'searchRoomId': null,
    'searchRoomNumber': null,
    'id': null
  }
};

export const ASSET_MANAGEMENT_BULK_UPDATE_SELECT_FIELDS: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_RECORDS_BULK_UPDATE_SELECT_FIELDS.url,
  name: RouteConstants.EQUIPMENT_RECORDS_BULK_UPDATE_SELECT_FIELDS.name,
  component: BulkSelectFieldsComponent,
  data: {'route': RouteConstants.EQUIPMENT_RECORDS_BULK_UPDATE_SELECT_FIELDS}
};

export const ASSET_MANAGEMENT_BULK_UPDATE_CONFIRM: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_RECORDS_BULK_UPDATE_CONFIRM.url,
  name: RouteConstants.EQUIPMENT_RECORDS_BULK_UPDATE_CONFIRM.name,
  component: BulkUpdateConfirmComponent,
  data: {'route': RouteConstants.EQUIPMENT_RECORDS_BULK_UPDATE_CONFIRM}
};

export const ASSET_MANAGEMENT_BULK_UPDATE_RESULTS: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_RECORDS_BULK_UPDATE_RESULTS.url,
  name: RouteConstants.EQUIPMENT_RECORDS_BULK_UPDATE_RESULTS.name,
  component: BulkUpdateResultsComponent,
  data: {'route': RouteConstants.EQUIPMENT_RECORDS_BULK_UPDATE_RESULTS}
};

export const ASSET_GROUPS: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_GROUPS.url,
  name: RouteConstants.EQUIPMENT_GROUPS.name,
  component: AssetGroupsComponent,
  data: {'route': RouteConstants.EQUIPMENT_GROUPS}
};

export const ASSET_GROUPS_DETAIL: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_GROUPS_DETAIL.url,
  name: RouteConstants.EQUIPMENT_GROUPS_DETAIL.name,
  component: AssetGroupsDetailsComponent,
  data: {'route': RouteConstants.EQUIPMENT_GROUPS_DETAIL},
  params: {
    'id': null
  }
};

export const ASSET_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_DETAILS.url,
  name: RouteConstants.ASSET_DETAILS.name,
  component: AssetDetailsComponent,
  data: {'route': RouteConstants.ASSET_DETAILS},
  params: {
    'id': null
  }
};

export const ASSET_NEW: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_RECORD_NEW.url,
  name: RouteConstants.EQUIPMENT_RECORD_NEW.name,
  component: AssetNewComponent,
  data: {'route': RouteConstants.EQUIPMENT_RECORD_NEW}
};

export const ASSET_LOOKUP: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_LOOKUP.url,
  name: RouteConstants.EQUIPMENT_LOOKUP.name,
  component: AssetManagementLookupComponent,
  data: {'route': RouteConstants.EQUIPMENT_LOOKUP}
};

export const ASSET_LOOKUP_ASSEMBLY_CATEGORY: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_ASSEMBLY_CATEGORY.url,
  name: RouteConstants.ASSET_LOOKUP_ASSEMBLY_CATEGORY.name,
  component: AssemblyCategoryComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_ASSEMBLY_CATEGORY}
};

export const ASSET_LOOKUP_FACILITY_SUBSYSTEM: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_FACILITY_SUB_SYSTEM.url,
  name: RouteConstants.ASSET_LOOKUP_FACILITY_SUB_SYSTEM.name,
  component: FacilitySubSystemComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_FACILITY_SUB_SYSTEM}
};

export const ASSET_LOOKUP_FACILITY_SYSTEM: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_FACILITY_SYSTEM.url,
  name: RouteConstants.ASSET_LOOKUP_FACILITY_SYSTEM.name,
  component: FacilitySystemComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_FACILITY_SYSTEM}
};

export const ASSET_LOOKUP_FREQUENCY: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_FREQUENCY.url,
  name: RouteConstants.ASSET_LOOKUP_FREQUENCY.name,
  component: FrequencyComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_FREQUENCY}
};

export const ASSET_LOOKUP_REGULATORY_COMPLIANCE_ACTION: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_REGULATORY_COMPLIANCE_ACTION.url,
  name: RouteConstants.ASSET_LOOKUP_REGULATORY_COMPLIANCE_ACTION.name,
  component: RegulatoryComplianceActionComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_REGULATORY_COMPLIANCE_ACTION}
};

export const ASSET_LOOKUP_REGULATORY_COMPLIANCE_CODE: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_REGULATORY_COMPLIANCE_CODE.url,
  name: RouteConstants.ASSET_LOOKUP_REGULATORY_COMPLIANCE_CODE.name,
  component: RegulatoryComplianceCodeComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_REGULATORY_COMPLIANCE_CODE}
};

export const ASSET_LOOKUP_SKILL: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_SKILL.url,
  name: RouteConstants.ASSET_LOOKUP_SKILL.name,
  component: SkillComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_SKILL}
};

export const ASSET_LOOKUP_SPECIALTY: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_SPECIALTY.url,
  name: RouteConstants.ASSET_LOOKUP_SPECIALTY.name,
  component: SpecialtyComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_SPECIALTY}
};

export const ASSET_LOOKUP_AUTH_SEC: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_AUTH_SEC.url,
  name: RouteConstants.ASSET_LOOKUP_AUTH_SEC.name,
  component: AuthoritativeSpaceAndEquipmentCriteriaComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_AUTH_SEC}
};

export const ASSET_LOOKUP_SEC: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_SEC.url,
  name: RouteConstants.ASSET_LOOKUP_SEC.name,
  component: SpaceEquipmentCriteriaComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_SEC}
};

export const ASSET_LOOKUP_1691: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_1691.url,
  name: RouteConstants.ASSET_LOOKUP_1691.name,
  component: MilitaryStandard1691Component,
  data: {'route': RouteConstants.ASSET_LOOKUP_1691}
};

export const ASSET_LOOKUP_1691_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_1691_DETAILS.url,
  name: RouteConstants.ASSET_LOOKUP_1691_DETAILS.name,
  component: MilitaryStandard1691DetailsComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_1691_DETAILS},
  params: {
    'jsn': null
  }
};

export const ASSET_LOOKUP_MEC: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_LOOKUP_MEC.url,
  name: RouteConstants.ASSET_LOOKUP_MEC.name,
  component: MinimumEssentialCharacteristicsComponent,
  data: {'route': RouteConstants.ASSET_LOOKUP_MEC}
};

export const ASSET_GRAPHICAL_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_GRAPHICAL_SEARCH.url,
  name: RouteConstants.ASSET_GRAPHICAL_SEARCH.name,
  component: AssetGraphicalSearchComponent,
  data: {'route': RouteConstants.ASSET_GRAPHICAL_SEARCH},
  params: {
    'roomIds': null
  }
};

export const ASSET_DETAILS_DRAWING: Ng2StateDeclaration = {
  url: RouteConstants.ASSET_DETAILS_DRAWING.url,
  name: RouteConstants.ASSET_DETAILS_DRAWING.name,
  component: AssetDetailsDrawingComponent,
  data: {'route': RouteConstants.ASSET_DETAILS_DRAWING},
  params: {floor: null, roomNumber: null}
};

export const AssetStates = [
  ASSET,
  ASSET_WARRANTY_INFO,
  ASSET_WARRANTY_INFO_DETAILS,
  ASSET_NEW,
  ASSET_DETAILS,
  ASSET_MANAGEMENT,
  ASSET_MANAGEMENT_BULK_UPDATE_SELECT_FIELDS,
  ASSET_MANAGEMENT_BULK_UPDATE_CONFIRM,
  ASSET_MANAGEMENT_BULK_UPDATE_RESULTS,
  ASSET_MANUFACTURER,
  ASSET_NOMENCLATURE,
  ASSET_MANUFACTURER_DETAILS,
  ASSET_MANUFACTURER_NEW,
  ASSET_NOMENCLATURE_DETAILS,
  EQUIPMENT_CLASSIFICATION_REQUEST,
  EQUIPMENT_NEW_CLASSIFICATION_REQUEST,
  EQUIPMENT_MANUFACTURER_REQUEST_MANAGEMENT,
  EQUIPMENT_NOMENCLATURE_REQUEST_MANAGEMENT,
  DATA_MANAGEMENT,
  MAINTENANCE_PROCEDURES,
  MAINTENANCE_PROCEDURES_BULK_UPDATE_CONFIRM,
  MAINTENANCE_PROCEDURES_BULK_UPDATE_RESULTS,
  MAINTENANCE_PROCEDURES_DETAIL,
  MAINTENANCE_SCHEDULES,
  ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE,
  ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_CONFIRMATION,
  ASSET_MAINTENANCE_SCHEDULES_BULK_UPDATE_RESULTS,
  MAINTENANCE_SCHEDULES_DETAIL,
  MAINTENANCE_SCHEDULES_NEW_NON_ASSET_SCHEDULE,
  ASSET_MANAGEMENT_MAINTENANCE_SCHEDULE_DETAIL,
  ASSET_GROUPS,
  ASSET_GROUPS_DETAIL,
  ASSET_LOOKUP,
  ASSET_LOOKUP_ASSEMBLY_CATEGORY,
  ASSET_LOOKUP_FACILITY_SUBSYSTEM,
  ASSET_LOOKUP_FACILITY_SYSTEM,
  ASSET_LOOKUP_FREQUENCY,
  ASSET_LOOKUP_REGULATORY_COMPLIANCE_ACTION,
  ASSET_LOOKUP_REGULATORY_COMPLIANCE_CODE,
  ASSET_LOOKUP_SKILL,
  ASSET_LOOKUP_SPECIALTY,
  ASSET_LOOKUP_AUTH_SEC,
  ASSET_LOOKUP_SEC,
  ASSET_LOOKUP_1691,
  ASSET_LOOKUP_1691_DETAILS,
  ASSET_LOOKUP_MEC,
  ASSET_GRAPHICAL_SEARCH,
  ASSET_DETAILS_DRAWING,
  EQUIPMENT_NOMENCLATURE_NEW,
  MAINTENANCE_PLANS,
  MAINTENANCE_PLANS_AND_SCHEDULES,
  NEW_MAINTENANCE_PLAN,
  MAINTENANCE_PLAN_DETAILS
];
