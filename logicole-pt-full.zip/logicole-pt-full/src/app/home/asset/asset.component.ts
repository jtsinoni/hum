import {Component} from '@angular/core';

@Component({
  selector: 'app-asset',
  templateUrl: './asset.component.html'
})
export class AssetComponent {

  constructor() {
  }

}
