import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {CommonComponentsModule} from '@lc-common-components';
import {AssetRoutingModule} from './asset-routing.module';
import {AssetDataManagementComponent} from './data-management/asset-data-management.component';
import {MaintenanceProceduresModule} from './maintenance-procedures/maintenance-procedures.module';
import {AssetComponent} from './asset.component';
import {EquipmentRecordPaginationService} from '../equipment/equipment-records/services/equipment-record-pagination.service';
import {EquipmentRecordSearchService} from '../equipment/equipment-records/services/equipment-record-search.service';
import {EquipmentRecordService} from '../equipment/equipment-records/services/equipment-record.service';
import {RequestApiService} from '../equipment/equipment-requests/services/request-api.service';
import {RequestService} from '../equipment/equipment-requests/services/request.service';
import {PaginationModule} from 'ngx-bootstrap/pagination';
import {TooltipModule} from 'ngx-bootstrap/tooltip';
import {PipesModule} from '../../pipes/pipes.module';
import {AssetAuthoritativeDataApiService} from './services/asset-authoritative-data-api.service';
import {ClassificationComponent} from './classification/classification.component';
import {NomenclatureDetailsComponent} from './classification/nomenclature/views/nomenclature-details/nomenclature-details.component';
import {NomenclatureSearchComponent} from './classification/nomenclature/views/nomenclature-search/nomenclature-search.component';
import {NomenclatureStatusFilterComponent} from './classification/nomenclature/components/nomenclature-status-filter/nomenclature-status-filter.component';
import {NomenclatureViewFilterComponent} from './classification/nomenclature/components/nomenclature-view-filter/nomenclature-view-filter.component';
import {ManufacturerDetailsComponent} from './classification/manufacturer/views/manufacturer-details/manufacturer-details.component';
import {ManufacturerSearchComponent} from './classification/manufacturer/views/manufacturer-search/manufacturer-search.component';
import {ManufacturerStatusFilterComponent} from './classification/manufacturer/components/manufacturer-status-filter/manufacturer-status-filter.component';
import {ManufacturerViewFilterComponent} from './classification/manufacturer/components/manufacturer-view-filter/manufacturer-view-filter.component';
import {NomenclatureDetailsService} from './classification/nomenclature/services/nomenclature-details.service';
import {NomenclaturePaginationService} from './classification/nomenclature/services/nomenclature-pagination.service';
import {NomenclatureSearchService} from './classification/nomenclature/services/nomenclature-search.service';
import {ManufacturerDetailsService} from './classification/manufacturer/services/manufacturer-details.service';
import {ManufacturerPaginationService} from './classification/manufacturer/services/manufacturer-pagination.service';
import {ManufacturerSearchService} from './classification/manufacturer/services/manufacturer-search.service';
import {AssetAuthoritativeDataService} from './services/asset-authoritative-data.service';
import {NomenclatureRequestManagementComponent} from './classification-request/views/nomenclature-request-management/nomenclature-request-management.component';
import {NomenclatureRequestDetailsComponent} from './classification-request/components/nomenclature-request-details/nomenclature-request-details.component';
import {ManufacturerRequestDetailsComponent} from './classification-request/components/manufacturer-request-details/manufacturer-request-details.component';
import {NewClassificationRequestComponent} from './classification-request/views/new-classification-request/new-classification-request.component';
import {ClassificationRequestsComponent} from './classification-request/views/classification-requests/classification-requests.component';
import {ClassificationRequestApiService} from './classification-request/services/classification-request-api.service';
import {ClassificationRequestService} from './classification-request/services/classification-request.service';
import {DirectivesModule} from '../../directives/directives.module';
import {AssetClassificationService} from './classification/services/asset-classification.service';
import {AssetClassificationApiService} from './classification/services/asset-classification-api.service';
import {AssetDataManagementService} from './data-management/services/asset-data-management.service';
import {AssetDataManagementApiService} from './data-management/services/asset-data-management-api.service';
import {ClassificationRequestStatusBarComponent} from './classification-request/components/classification-request-status-bar/classification-request-status-bar.component';
import {MaintenanceScheduleModule} from './maintenance-schedule/maintenance-schedule.module';
import {MaintenanceScheduleApiService} from './maintenance-schedule/services/maintenance-schedule-api.service';
import {MaintenanceScheduleService} from './maintenance-schedule/services/maintenance-schedule.service';
import {AssetManagementComponent} from './asset-management/asset-management.component';
import {AssetService} from './asset-management/services/asset.service';
import {AssetApiService} from './asset-management/services/asset-api.service';
import {AssetDetailsComponent} from './asset-management/views/asset-details/asset-details.component';
import {PartsComponent} from './asset-management/components/parts/parts.component';
import {MaintenanceComponent} from './asset-management/components/maintenance/maintenance.component';
import {MainComponent} from './asset-management/components/main/main.component';
import {SpecificationsComponent} from './asset-management/components/main/specifications/specifications.component';
import {AssemblyComponent} from './asset-management/components/main/assembly/assembly.component';
import {AdditionalComponent} from './asset-management/components/main/additional/additional.component';
import {CapacityComponent} from './asset-management/components/main/capacity/capacity.component';
import {HazardsComponent} from './asset-management/components/main/hazards/hazards.component';
import {AcquisitionComponent} from './asset-management/components/acquisition/acquisition.component';
import {ConditionComponent} from './asset-management/components/condition/condition.component';
import {LocationComponent} from './asset-management/components/main/location/location.component';
import {AssetNewComponent} from './asset-management/views/asset-new/asset-new.component';
import {NewRpeAssetComponent} from './asset-management/components/new-rpe-asset/new-rpe-asset.component';
import {NewEquipmentAssetComponent} from './asset-management/components/new-equipment-asset/new-equipment-asset.component';
import {WorkOrdersApiService} from '../work-orders/services/work-orders-api.service';
import {AssetGroupsComponent} from './asset-groups/asset-groups.component';
import {AssetGroupsDetailsComponent} from './asset-groups/views/asset-groups-details/asset-groups-details.component';
import {AssetManagementLookupComponent} from './asset-management-lookup/asset-management-lookup.component';
import {FrequencyComponent} from './asset-management-lookup/components/frequency/frequency.component';
import {AssemblyCategoryComponent} from './asset-management-lookup/components/assembly-category/assembly-category.component';
import {FacilitySystemComponent} from './asset-management-lookup/components/facility-system/facility-system.component';
import {FacilitySubSystemComponent} from './asset-management-lookup/components/facility-sub-system/facility-sub-system.component';
import {SpecialtyComponent} from './asset-management-lookup/components/specialty/specialty.component';
import {AssetGroupService} from './asset-groups/services/asset-group.service';
import {AssetGroupApiService} from './asset-groups/services/asset-group-api.service';
import {RequirementsService} from '../real-property/services/requirements.service';
import {RequirementsApiService} from '../real-property/services/requirements-api.service';
import {RequirementLookupApiService} from '../real-property/services/requirements-lookup-api.service';
import {AssetWarrantyInfoComponent} from './asset-warranty-info/asset-warranty-info.component';
import {AssetAttachmentsComponent} from './asset-management/components/asset-attachments/asset-attachments.component';
import {AssetManagementBulkUpdateService} from './asset-management/services/asset-management-bulk-update.service';
import {AssetWarrantyDetailsComponent} from './asset-warranty-info/views/asset-warranty-details/asset-warranty-details.component';
import {AssetNotesComponent} from './asset-management/components/asset-notes/asset-notes.component';
import {RegulatoryComplianceActionComponent} from './asset-management-lookup/components/regulatory-compliance-action/regulatory-compliance-action.component';
import {RegulatoryComplianceCodeComponent} from './asset-management-lookup/components/regulatory-compliance-code/regulatory-compliance-code.component';
import {StandardsComplianceComponent} from './asset-management/components/main/standards-compliance/standards-compliance.component';
import {NgSelectModule} from '@ng-select/ng-select';
import {RoomNumberComponent} from './asset-management/components/bulk-update/fields/room-number/room-number.component';
import {OtherLocationComponent} from './asset-management/components/bulk-update/fields/other-location/other-location.component';
import {AssemblyBarcodeComponent} from './asset-management/components/bulk-update/fields/assembly-barcode/assembly-barcode.component';
import {AssemblyNomenclatureComponent} from './asset-management/components/bulk-update/fields/assembly-nomenclature/assembly-nomenclature.component';
import {AuditQaInspectionMethodComponent} from './asset-management/components/bulk-update/fields/audit-qa-inspection-method/audit-qa-inspection-method.component';
import {AuditQcInspectionMethodComponent} from './asset-management/components/bulk-update/fields/audit-qc-inspection-method/audit-qc-inspection-method.component';
import {AuditRiskFactorComponent} from './asset-management/components/bulk-update/fields/audit-risk-factor/audit-risk-factor.component';
import {CapacitiesComponent} from './asset-management/components/bulk-update/fields/capacities/capacities.component';
import {ConditionAssessmentComponent} from './asset-management/components/bulk-update/fields/condition-assessment/condition-assessment.component';
import {ConditionCodeComponent} from './asset-management/components/bulk-update/fields/condition-code/condition-code.component';
import {ConditionDateComponent} from './asset-management/components/bulk-update/fields/condition-date/condition-date.component';
import {OrganizationComponent} from './asset-management/components/bulk-update/fields/organization/organization.component';
import {PointOfContactComponent} from './asset-management/components/bulk-update/fields/point-of-contact/point-of-contact.component';
import {RelatedCauseComponent} from './asset-management/components/bulk-update/fields/related-cause/related-cause.component';
import {ConditionAssessmentRequiredComponent} from './asset-management/components/bulk-update/fields/condition-assessment-required/condition-assessment-required.component';
import {BulkUpdateHazardsComponent} from './asset-management/components/bulk-update/fields/bulk-update-hazards/bulk-update-hazards.component';
import {InstallDateComponent} from './asset-management/components/bulk-update/fields/install-date/install-date.component';
import {LifeExpectancyComponent} from './asset-management/components/bulk-update/fields/life-expectancy/life-expectancy.component';
import {BulkUpdateSpecificationsComponent} from './asset-management/components/bulk-update/fields/bulk-update-specifications/bulk-update-specifications.component';
import {TypeMainComponent} from './asset-management/components/bulk-update/types/type-main/type-main.component';
import {TypeCapacitiesComponent} from './asset-management/components/bulk-update/types/type-capacities/type-capacities.component';
import {TypeSpecificationsComponent} from './asset-management/components/bulk-update/types/type-specifications/type-specifications.component';
import {TypeConditionAssessmentComponent} from './asset-management/components/bulk-update/types/type-condition-assessment/type-condition-assessment.component';
import {TypeHazardsComponent} from './asset-management/components/bulk-update/types/type-hazards/type-hazards.component';
import {TypeConditionInformationComponent} from './asset-management/components/bulk-update/types/type-condition-information/type-condition-information.component';
import {BulkUpdateConfirmComponent} from './asset-management/views/bulk-update-confirm/bulk-update-confirm.component';
import {BulkUpdateResultsComponent} from './asset-management/views/bulk-update-results/bulk-update-results.component';
import {BulkSelectFieldsComponent} from './asset-management/views/bulk-select-fields/bulk-select-fields.component';
import {TypeConditionComponent} from './asset-management/components/bulk-update/types/type-condition/type-condition.component';
import {ReferenceDocumentsComponent} from './asset-management/components/acquisition/reference-documents/reference-documents.component';
import {AcquisitionCostComponent} from './asset-management/components/bulk-update/fields/acquisition-cost/acquisition-cost.component';
import {AuditByComponent} from './asset-management/components/bulk-update/fields/audit-by/audit-by.component';
import {AuditDateComponent} from './asset-management/components/bulk-update/fields/audit-date/audit-date.component';
import {ProductCatalogNumberComponent} from './asset-management/components/bulk-update/fields/product-catalog-number/product-catalog-number.component';
import {MaintenanceContractNumberComponent} from './asset-management/components/bulk-update/fields/maintenance-contract-number/maintenance-contract-number.component';
import {MaintenanceContractorComponent} from './asset-management/components/bulk-update/fields/maintenance-contractor/maintenance-contractor.component';
import {MaintenanceContractStartDateComponent} from './asset-management/components/bulk-update/fields/maintenance-contract-start-date/maintenance-contract-start-date.component';
import {MaintenanceContractEndDateComponent} from './asset-management/components/bulk-update/fields/maintenance-contract-end-date/maintenance-contract-end-date.component';
import {ProductManufacturerNameComponent} from './asset-management/components/bulk-update/fields/product-manufacturer-name/product-manufacturer-name.component';
import {ProductManufacturerSerialNumberComponent} from './asset-management/components/bulk-update/fields/product-manufacturer-serial-number/product-manufacturer-serial-number.component';
import {ProductModelNumberComponent} from './asset-management/components/bulk-update/fields/product-model-number/product-model-number.component';
import {WarrantyStartDateComponent} from './asset-management/components/bulk-update/fields/warranty-start-date/warranty-start-date.component';
import {WarrantyPurchaseOrderNumberComponent} from './asset-management/components/bulk-update/fields/warranty-purchase-order-number/warranty-purchase-order-number.component';
import {CostInformationReplacementCostComponent} from './asset-management/components/bulk-update/fields/cost-information-replacement-cost/cost-information-replacement-cost.component';
import {AssemblyRealPropertyEquipmentSpareComponent} from './asset-management/components/bulk-update/fields/assembly-real-property-equipment-spare/assembly-real-property-equipment-spare.component';
import {AssemblyEngineeringRpeEquipmentIdComponent} from './asset-management/components/bulk-update/fields/assembly-engineering-rpe-equipment-id/assembly-engineering-rpe-equipment-id.component';
import {WarrantyVendorContactComponent} from './asset-management/components/bulk-update/fields/warranty-vendor-contact/warranty-vendor-contact.component';
import {AssemblySectionNameComponent} from './asset-management/components/bulk-update/fields/assembly-section-name/assembly-section-name.component';
import {AssemblyPrimeComponentComponent} from './asset-management/components/bulk-update/fields/assembly-prime-component/assembly-prime-component.component';
import {TypeCustomFieldsComponent} from './asset-management/components/bulk-update/types/type-custom-fields/type-custom-fields.component';
import {TypeLocationComponent} from './asset-management/components/bulk-update/types/type-location/type-location.component';
import {TypeWarrantyInformationComponent} from './asset-management/components/bulk-update/types/type-warranty-information/type-warranty-information.component';
import {CustomFieldComponent} from './asset-management/components/bulk-update/fields/custom-field/custom-field.component';
import {SubComponentsComponent} from './asset-management/components/sub-components/sub-components.component';
import {EquipmentTagsComponent} from './asset-management/components/main/equipment-tags/equipment-tags.component';
import {WarrantyPartsDurationComponent} from './asset-management/components/bulk-update/fields/warranty-parts-duration/warranty-parts-duration.component';
import {WarrantyLaborDurationComponent} from './asset-management/components/bulk-update/fields/warranty-labor-duration/warranty-labor-duration.component';
import {EquipmentSpaceComponent} from './asset-management/components/main/equipment-space/equipment-space.component';
import {EquipmentAuditComponent} from './asset-management/components/main/equipment-audit/equipment-audit.component';
import {TypeAssemblyComponent} from './asset-management/components/bulk-update/types/type-assembly/type-assembly.component';
import {TypeAuditComponent} from './asset-management/components/bulk-update/types/type-audit/type-audit.component';
import {TypeProductInformationComponent} from './asset-management/components/bulk-update/types/type-product-information/type-product-information.component';
import {TypeCostInformationComponent} from './asset-management/components/bulk-update/types/type-cost-information/type-cost-information.component';
import {TypeMaintenanceContractInformationComponent} from './asset-management/components/bulk-update/types/type-maintenance-contract-information/type-maintenance-contract-information.component';
import {MaintenanceContractTitleComponent} from './asset-management/components/bulk-update/fields/maintenance-contract-title/maintenance-contract-title.component';
import {TypeSpaceComponent} from './asset-management/components/bulk-update/types/type-space/type-space.component';
import {SpaceRoomsComponent} from './asset-management/components/bulk-update/fields/space-rooms/space-rooms.component';
import {ReferencesComponent} from './asset-management/components/bulk-update/fields/references/references.component';
import {TypeReferenceDocumentComponent} from './asset-management/components/bulk-update/types/type-reference-document/type-reference-document.component';
import {TypeStandardsComponent} from './asset-management/components/bulk-update/types/type-standards/type-standards.component';
import {StandardsComponent} from './asset-management/components/bulk-update/fields/standards/standards.component';
import {TypeSpaceRoomsComponent} from './asset-management/components/bulk-update/types/type-space-rooms/type-space-rooms.component';
import {TypeSpaceZonesComponent} from './asset-management/components/bulk-update/types/type-space-zones/type-space-zones.component';
import {SpaceZonesComponent} from './asset-management/components/bulk-update/fields/space-zones/space-zones.component';
import {TypeAdditionalComponent} from './asset-management/components/bulk-update/types/type-additional/type-additional.component';
import {AssemblyPmScheduleRequiredComponent} from './asset-management/components/bulk-update/fields/assembly-pm-schedule-required/assembly-pm-schedule-required.component';
import {PmPerformedWithPrimeComponentComponent} from './asset-management/components/bulk-update/fields/pm-performed-with-prime-component/pm-performed-with-prime-component.component';
import {EquipmentRelatedItemsComponent} from './asset-management/components/equipment-related-items/equipment-related-items.component';
import {EquipmentRelatedProjectsComponent} from './asset-management/components/equipment-related-items/equipment-related-projects/equipment-related-projects.component';
import {EquipmentRelatedSectionsComponent} from './asset-management/components/equipment-related-items/equipment-related-sections/equipment-related-sections.component';
import {EquipmentRelatedRequirementsComponent} from './asset-management/components/equipment-related-items/equipment-related-requirements/equipment-related-requirements.component';
import {AssetGraphicalSearchComponent} from './asset-management/views/asset-graphical-search/asset-graphical-search.component';
import {SpaceEquipmentCriteriaComponent} from './asset-management-lookup/components/space-and-equipment-criteria/space-equipment-criteria.component';
import {AuthoritativeSpaceAndEquipmentCriteriaComponent} from './asset-management-lookup/components/authoritative-space-and-equipment-criteria/authoritative-space-and-equipment-criteria.component';
import {MilitaryStandard1691Component} from './asset-management-lookup/components/military-standard-1691/military-standard-1691.component';
import {MilitaryStandard1691DetailsComponent} from './asset-management-lookup/components/military-standard-1691-details/military-standard-1691-details.component';
import {MinimumEssentialCharacteristicsComponent} from './minimum-essential-characteristics/minimum-essential-characteristics.component';
import {MinimumEssentialCharacteristicsApiService} from './minimum-essential-characteristics/services/minimum-essential-characteristics-api.service';
import {AssetLookupService} from './services/asset-lookup.service';
import {ZoneComponent} from './asset-management/components/bulk-update/fields/zone/zone.component';
import {AssetDetailsDrawingComponent} from './asset-management/views/asset-details-drawing/asset-details-drawing.component';
import {MaintenancePlanModule} from '../maintenance/maintenance-plan/maintenance-plan.module';
import {ManufacturerGeneralComponent} from './classification/manufacturer/components/main/manufacturer-general/manufacturer-general.component';
import {ManufacturerContactComponent} from './classification/manufacturer/components/main/manufacturer-contact/manufacturer-contact.component';
import {ManufacturerMainTabContentComponent} from './classification/manufacturer/components/main/manufacturer-main-tab-content/manufacturer-main-tab-content.component';
import {ManufacturerKnownAsComponent} from './classification/manufacturer/components/main/manufacturer-known-as/manufacturer-known-as.component';
import {ManufacturerPocComponent} from './classification/manufacturer/components/manufacturer-poc/manufacturer-poc.component';
import {NomenclatureDetailMainCardComponent} from './classification/nomenclature/components/nomenclature-detail-main-card/nomenclature-detail-main-card.component';
import {NomenclatureDetailMainCardViewComponent} from './classification/nomenclature/components/nomenclature-detail-main-card/view/view.component';
import {NomenclatureDetailMainCardEditComponent} from './classification/nomenclature/components/nomenclature-detail-main-card/edit/edit.component';
import {NewNomenclatureComponent} from './classification/nomenclature/views/new-nomenclature/new-nomenclature.component';
import {NomenclatureProductItemCardComponent} from './classification/nomenclature/components/nomenclature-product-item-card/nomenclature-product-item-card.component';
import {ManufacturerCreateComponent} from './classification/manufacturer/views/manufacturer-create/manufacturer-create.component';
import {ManufacturerRequestManagementComponent} from './classification-request/views/manufacturer-request-management/manufacturer-request-management.component';
import {NomenclatureRequestNotesComponent} from './classification-request/components/nomenclature-request-notes/nomenclature-request-notes.component';
import {ManufacturerRequestNotesComponent} from './classification-request/components/manufacturer-request-notes/manufacturer-request-notes.component';
import {ManufacturerRequestGeneralComponent} from './classification-request/components/manufacturer-request-general/manufacturer-request-general.component';
import {ManufacturerRequestContactComponent} from './classification-request/components/manufacturer-request-contact/manufacturer-request-contact.component';
import {ManufacturerRequestKnownAsComponent} from './classification-request/components/manufacturer-request-known-as/manufacturer-request-known-as.component';

@NgModule({
  declarations: [
    AcquisitionComponent,
    AcquisitionCostComponent,
    AdditionalComponent,
    AssemblyBarcodeComponent,
    AssemblyCategoryComponent,
    AssemblyCategoryComponent,
    AssemblyComponent,
    AssemblyEngineeringRpeEquipmentIdComponent,
    AssemblyNomenclatureComponent,
    AssemblyPmScheduleRequiredComponent,
    AssemblyPrimeComponentComponent,
    AssemblyRealPropertyEquipmentSpareComponent,
    AssemblySectionNameComponent,
    AssetAttachmentsComponent,
    AssetComponent,
    AssetDataManagementComponent,
    AssetDetailsComponent,
    AssetDetailsDrawingComponent,
    AssetGraphicalSearchComponent,
    AssetGroupsComponent,
    AssetGroupsDetailsComponent,
    AssetManagementComponent,
    AssetManagementLookupComponent,
    AssetNewComponent,
    AssetNotesComponent,
    AssetWarrantyDetailsComponent,
    AssetWarrantyDetailsComponent,
    AssetWarrantyInfoComponent,
    AuditByComponent,
    AuditDateComponent,
    AuditQaInspectionMethodComponent,
    AuditQcInspectionMethodComponent,
    AuditRiskFactorComponent,
    AuthoritativeSpaceAndEquipmentCriteriaComponent,
    BulkSelectFieldsComponent,
    BulkUpdateConfirmComponent,
    BulkUpdateHazardsComponent,
    BulkUpdateResultsComponent,
    BulkUpdateSpecificationsComponent,
    CapacitiesComponent,
    CapacityComponent,
    ClassificationComponent,
    ClassificationRequestStatusBarComponent,
    ClassificationRequestsComponent,
    ConditionAssessmentComponent,
    ConditionAssessmentRequiredComponent,
    ConditionCodeComponent,
    ConditionComponent,
    ConditionDateComponent,
    CostInformationReplacementCostComponent,
    CustomFieldComponent,
    EquipmentAuditComponent,
    EquipmentRelatedItemsComponent,
    EquipmentRelatedProjectsComponent,
    EquipmentRelatedRequirementsComponent,
    EquipmentRelatedSectionsComponent,
    EquipmentSpaceComponent,
    EquipmentSpaceComponent,
    EquipmentTagsComponent,
    FacilitySubSystemComponent,
    FacilitySubSystemComponent,
    FacilitySystemComponent,
    FacilitySystemComponent,
    FrequencyComponent,
    FrequencyComponent,
    HazardsComponent,
    InstallDateComponent,
    LifeExpectancyComponent,
    LocationComponent,
    MainComponent,
    MaintenanceComponent,
    MaintenanceContractEndDateComponent,
    MaintenanceContractNumberComponent,
    MaintenanceContractStartDateComponent,
    MaintenanceContractTitleComponent,
    MaintenanceContractorComponent,
    ManufacturerContactComponent,
    ManufacturerCreateComponent,
    ManufacturerDetailsComponent,
    ManufacturerGeneralComponent,
    ManufacturerKnownAsComponent,
    ManufacturerMainTabContentComponent,
    ManufacturerPocComponent,
    ManufacturerRequestDetailsComponent,
    ManufacturerRequestGeneralComponent,
    ManufacturerRequestContactComponent,
    ManufacturerRequestKnownAsComponent,
    ManufacturerRequestManagementComponent,
    ManufacturerSearchComponent,
    ManufacturerStatusFilterComponent,
    ManufacturerViewFilterComponent,
    MilitaryStandard1691Component,
    MilitaryStandard1691DetailsComponent,
    MinimumEssentialCharacteristicsComponent,
    NewClassificationRequestComponent,
    NewEquipmentAssetComponent,
    NewNomenclatureComponent,
    NewRpeAssetComponent,
    NomenclatureDetailMainCardComponent,
    NomenclatureDetailMainCardEditComponent,
    NomenclatureDetailMainCardViewComponent,
    NomenclatureDetailsComponent,
    NomenclatureProductItemCardComponent,
    NomenclatureRequestDetailsComponent,
    NomenclatureRequestManagementComponent,
    NomenclatureRequestNotesComponent,
    NomenclatureSearchComponent,
    NomenclatureStatusFilterComponent,
    NomenclatureViewFilterComponent,
    OrganizationComponent,
    OtherLocationComponent,
    PartsComponent,
    PmPerformedWithPrimeComponentComponent,
    PointOfContactComponent,
    ProductCatalogNumberComponent,
    ProductManufacturerNameComponent,
    ProductManufacturerSerialNumberComponent,
    ProductModelNumberComponent,
    ReferenceDocumentsComponent,
    ReferencesComponent,
    RegulatoryComplianceActionComponent,
    RegulatoryComplianceCodeComponent,
    RelatedCauseComponent,
    RoomNumberComponent,
    SpaceEquipmentCriteriaComponent,
    SpaceRoomsComponent,
    SpaceZonesComponent,
    SpecialtyComponent,
    SpecialtyComponent,
    SpecificationsComponent,
    StandardsComplianceComponent,
    StandardsComponent,
    SubComponentsComponent,
    TypeAdditionalComponent,
    TypeAssemblyComponent,
    TypeAuditComponent,
    TypeCapacitiesComponent,
    TypeConditionAssessmentComponent,
    TypeConditionComponent,
    TypeConditionComponent,
    TypeConditionInformationComponent,
    TypeCostInformationComponent,
    TypeCustomFieldsComponent,
    TypeCustomFieldsComponent,
    TypeHazardsComponent,
    TypeLocationComponent,
    TypeMainComponent,
    TypeMaintenanceContractInformationComponent,
    TypeProductInformationComponent,
    TypeReferenceDocumentComponent,
    TypeSpaceComponent,
    TypeSpaceRoomsComponent,
    TypeSpaceZonesComponent,
    TypeSpecificationsComponent,
    TypeStandardsComponent,
    TypeWarrantyInformationComponent,
    WarrantyLaborDurationComponent,
    WarrantyPartsDurationComponent,
    WarrantyPurchaseOrderNumberComponent,
    WarrantyStartDateComponent,
    WarrantyVendorContactComponent,
    ZoneComponent,
    ManufacturerRequestNotesComponent
  ],
  imports: [
    AssetRoutingModule,
    CommonComponentsModule.forRoot(),
    CommonModule,
    DirectivesModule,
    FormsModule,
    MaintenancePlanModule,
    MaintenanceProceduresModule,
    MaintenanceScheduleModule,
    NgSelectModule,
    PaginationModule.forRoot(),
    PipesModule.forRoot(),
    TooltipModule.forRoot()
  ],
  providers: [
    AssetApiService,
    AssetAuthoritativeDataApiService,
    AssetAuthoritativeDataService,
    AssetClassificationApiService,
    AssetClassificationService,
    AssetDataManagementApiService,
    AssetDataManagementService,
    AssetGroupApiService,
    AssetGroupService,
    AssetLookupService,
    AssetManagementBulkUpdateService,
    AssetService,
    ClassificationRequestApiService,
    ClassificationRequestService,
    EquipmentRecordPaginationService,
    EquipmentRecordSearchService,
    EquipmentRecordService,
    MaintenanceScheduleApiService,
    MaintenanceScheduleService,
    ManufacturerDetailsService,
    ManufacturerPaginationService,
    ManufacturerSearchService,
    MinimumEssentialCharacteristicsApiService,
    NomenclatureDetailsService,
    NomenclaturePaginationService,
    NomenclatureSearchService,
    RequestApiService,
    RequestService,
    RequirementLookupApiService,
    RequirementsApiService,
    RequirementsService,
    WorkOrdersApiService
  ],
  exports: [
    AssetAttachmentsComponent,
    AssetNotesComponent
  ]
})
export class AssetModule {
}
