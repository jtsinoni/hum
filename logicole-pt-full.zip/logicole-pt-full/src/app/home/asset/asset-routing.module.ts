import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {AssetStates} from './asset-states';
import {RouteConstants} from '@lc-constants/*';

const assetRoutes: RootModule = {
  states: AssetStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(assetRoutes)],
  exports: [UIRouterModule]
})
export class AssetRoutingModule {
}
