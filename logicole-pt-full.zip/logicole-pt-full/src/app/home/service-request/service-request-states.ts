import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {ServiceRequestNewComponent} from './views/service-request-new/service-request-new.component';
import {ServiceRequestSearchComponent} from './views/service-request-search/service-request-search.component';
import {ServiceRequestDetailsComponent} from './views/service-request-details/service-request-details.component';


export const SERVICE_REQUEST_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.SERVICE_REQUEST_SEARCH.url,
  name: RouteConstants.SERVICE_REQUEST_SEARCH.name,
  component: ServiceRequestSearchComponent,
  data: {'route': RouteConstants.SERVICE_REQUEST_SEARCH}
};

export const SERVICE_REQUEST_NEW: Ng2StateDeclaration = {
  url: RouteConstants.SERVICE_REQUEST_NEW.url,
  name: RouteConstants.SERVICE_REQUEST_NEW.name,
  component: ServiceRequestNewComponent,
  data: {'route': RouteConstants.SERVICE_REQUEST_NEW},
  params: {'cloneFromId': null}
};

export const SERVICE_REQUEST_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.SERVICE_REQUEST_DETAILS.url,
  name: RouteConstants.SERVICE_REQUEST_DETAILS.name,
  component: ServiceRequestDetailsComponent,
  data: {'route': RouteConstants.SERVICE_REQUEST_DETAILS}
};

export const ServiceRequestStates: Ng2StateDeclaration[] = [
  SERVICE_REQUEST_SEARCH,
  SERVICE_REQUEST_NEW,
  SERVICE_REQUEST_DETAILS
];
