import {RootModule, UIRouterModule} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {ServiceRequestStates} from './service-request-states';
import {NgModule} from '@angular/core';

const ServiceRequestRoutes: RootModule = {
  states: ServiceRequestStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(ServiceRequestRoutes)],
  exports: [UIRouterModule],
})
export class ServiceRequestRoutingModule {
}
