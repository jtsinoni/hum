import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ServiceRequestSearchComponent} from './views/service-request-search/service-request-search.component';
import {ServiceRequestNewComponent} from './views/service-request-new/service-request-new.component';
import {CommonComponentsModule} from '@lc-common-components';
import {UIRouterModule} from '@uirouter/angular';
import {FormsModule} from '@angular/forms';
import {ServiceRequestService} from './services/service-request.service';
import {ServiceRequestApiService} from './services/service-request-api.service';
import {PipesModule} from '../../pipes/pipes.module';
import {DirectivesModule} from '../../directives/directives.module';
import {ServiceRequestRoutingModule} from './service-request-routing.module';
import {ServiceRequestDetailsComponent} from './views/service-request-details/service-request-details.component';
import {ServiceRequestDetailsContentComponent} from './components/service-request-details-content/service-request-details-content.component';
import {ServiceRequestLocationContentComponent} from './components/service-request-location-content/service-request-location-content.component';
import {ServiceRequestEquipmentContentComponent} from './components/service-request-equipment-content/service-request-equipment-content.component';
import {ServiceRequestAttachmentsContentComponent} from './components/service-request-attachments-content/service-request-attachments-content.component';
import {ServiceRequestSurveyComponent} from './components/service-request-survey/service-request-survey.component';


@NgModule({
  declarations: [
    ServiceRequestSearchComponent,
    ServiceRequestNewComponent,
    ServiceRequestDetailsComponent,
    ServiceRequestDetailsContentComponent,
    ServiceRequestLocationContentComponent,
    ServiceRequestEquipmentContentComponent,
    ServiceRequestAttachmentsContentComponent,
    ServiceRequestSurveyComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule.forRoot(),
    PipesModule,
    DirectivesModule,
    UIRouterModule,
    ServiceRequestRoutingModule
  ],
  providers: [
    ServiceRequestApiService,
    ServiceRequestService
  ]
})
export class ServiceRequestModule {
}
