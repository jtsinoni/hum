import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewReportComponent } from './view-report/view-report.component';
import { ReportService } from './services/report.service';
import {ReportRoutingModule} from './report-routing.module';
import {LcSlepModalComponent} from '../slep/components/lc-slep-modal/lc-slep-modal.component';

@NgModule({
  imports: [
    CommonModule,
    ReportRoutingModule
  ],
  declarations: [ViewReportComponent],
  providers: [ReportService],

  exports: [ViewReportComponent],
  entryComponents: [ViewReportComponent]


})
export class ReportModule { }
