import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from 'app/constants/route.constants';
import {ViewReportComponent} from './view-report/view-report.component';

export class ReportStates {
 /* public static VIEW_REPORT: Ng2StateDeclaration = {
    url: RouteConstants.VIEW_REPORT.url,
    name: RouteConstants.VIEW_REPORT.name,
    component: ViewReportComponent,
    data: {'route': RouteConstants.VIEW_REPORT}
  };*/

}
