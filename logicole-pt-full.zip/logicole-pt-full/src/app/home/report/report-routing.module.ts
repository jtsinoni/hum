import {NgModule } from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {ReportStates} from './report-states';

// NOTE: The reporting area is commented out for now, this area will be uncommented out once reports are made available.

const reportRoutes: RootModule = {
  states: [
 //   ReportStates.VIEW_REPORT,
  ]
};

@NgModule({
  imports: [
    UIRouterModule.forChild(reportRoutes)
  ],
  exports: [
    UIRouterModule
  ],
})
export class ReportRoutingModule { }
