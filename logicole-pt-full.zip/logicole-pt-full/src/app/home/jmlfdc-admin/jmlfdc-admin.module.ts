import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {JmlfdcAdminRoutingModule} from './jmlfdc-admin-routing.module';
import {AdminComponent} from './admin/admin.component';
import {SystemNotificationModule} from './system-notification/system-notification.module';
import {SystemNotificationsComponent} from './system-notification/system-notifications.component';
import {CommonComponentsModule} from '@lc-common-components';
import {PipesModule} from '../../pipes/pipes.module';
import {FormsModule} from '@angular/forms';
import {PullFacilityRecordsComponent} from './pull-facility-records/pull-facility-records.component';
import {AbiManagementModule} from './abi-management/abi-management.module';
import {EmailCheckComponent} from './email-check/views/email-check.component';
import {EmailCheckService} from './email-check/services/email-check.service';
import {EmailCheckApiService} from './email-check/services/email-check-api.service';
import {DmlssHostComponent} from './dmlss-host/dmlss-host.component';
import {DmlssHostManagementService} from './dmlss-host/services/dmlss-host-management.service';
import {DmlssHostApiService} from './dmlss-host/services/dmlss-host-api.service';
import {HealthStatusComponent} from './health-status/health-status.component';
import {HealthCheckDetailComponent} from './health-status/components/health-check-detail/health-check-detail.component';
import {HealthStatusApiService} from './health-status/services/health-status-api.service';
import {HealthStatusService} from './health-status/services/health-status.service';
import {FeatureFlagSelectorComponent} from './feature-flag/components/feature-flag-selector/feature-flag-selector.component';
import {FeatureFlagListComponent} from './feature-flag/views/feature-flag-list/feature-flag-list.component';
import {AddUpdateFeatureFlagComponent} from './feature-flag/views/add-update-feature-flag/add-update-feature-flag.component';
import {PullFacilityRecordsApiService} from './pull-facility-records/services/pull-facility-records-api.service';
import {SystemConfigurationsComponent} from './system-configuration/system-configurations/system-configurations.component';
import {CommunicationsDmlssApiService} from './dmlss-host/services/communications-dmlss-api.service';
import {CommunicationsTransmitApiService} from '../communications/services/communications-transmit-api.service';
import {EhrManagementModule} from './ehr/ehr-management.module';
import {EquipmentTestingComponent} from './equipment-testing/equipment-testing.component';
import {EquipmentTestingService} from './equipment-testing/services/equipment-testing.service';
import {EquipmentTestingApiService} from './equipment-testing/services/equipment-testing-api.service';
import {InstallationSiteService} from '../real-property/services/installation-site.service';
import {InstallationSiteApiService} from '../real-property/services/installation-site-api.service';
import {RealPropertyLookupApiService} from '../real-property/services/real-property-lookup-api.service';
import {RealPropertyLookupService} from '../real-property/services/real-property-lookup.service';
import {AuthoritativeDataApiService} from '../real-property/services/authoritative-data-api.service';
import {AuthoritativeDataService} from '../real-property/services/authoritative-data.service';
import {SyncFacilityRecordsApiService} from './pull-facility-records/services/sync-facility-records-api.service';
import {ConfigurationGroupComponent} from './system-configuration/components/configuration-group/configuration-group.component';
import {AddUpdateConfigurationComponent} from './system-configuration/add-update-configuration/add-update-configuration.component';
import {DmlssLiveDataManagementComponent} from './dmlss-live-data-management/dmlss-live-data-management.component';
import {DmlssApiService} from '../abi-search/services/dmlss-api.service';
import {DmlssServerManagementComponent} from './dmlss-live-data-management/components/dmlss-server-management/dmlss-server-management.component';
import {DirectivesModule} from '../../directives/directives.module';
import {OrganizationComponentModule} from '../organization/organization-component.module';
import {TranslateIncomingDocumentComponent} from './edi-translation/components/translate-incoming-document/translate-incoming-document.component';
import {TranslateOutgoingDocumentComponent} from './edi-translation/components/translate-outgoing-document/translate-outgoing-document.component';
import {CommunicationsTranslationsComponent} from './edi-translation/views/communications-translations/communications-translations.component';
import {MaximoManagementModule} from './maximo/maximo-management.module';
import {DataManagementComponent} from './data-management/data-management.component';
import {CatalogManagementComponent} from './catalog-management/catalog-management.component';
import {CatalogManagementApiService} from './catalog-management/services/catalog-management-api.service';
import {MmcTestComponent} from './mmc-test/mmc-test.component';
import { FeatureFlagRolesComponent } from './feature-flag/components/feature-flag-roles/feature-flag-roles.component';
import { FeatureFlagPermissionsComponent } from './feature-flag/components/feature-flag-permissions/feature-flag-permissions.component';
import { FeatureFlagElementsComponent } from './feature-flag/components/feature-flag-elements/feature-flag-elements.component';
import { FeatureFlagStatesComponent } from './feature-flag/components/feature-flag-states/feature-flag-states.component';
import { FeatureFlagEndpointsComponent } from './feature-flag/components/feature-flag-endpoints/feature-flag-endpoints.component';
import {ServerConfigurationsComponent} from './system-configuration/components/server-configurations/server-configurations.component';
import {CatalogManagementUploadsComponent} from './catalog-management/components/catalog-management-uploads/catalog-management-uploads.component';
import {VaRrcImportsComponent} from './catalog-management/components/va-rrc-imports/va-rrc-imports.component';
import {VaRrcTaskRequestsComponent} from './catalog-management/components/va-rrc-task-requests/va-rrc-task-requests.component';
import {VaRrcTaskRequestDetailsComponent} from './catalog-management/components/va-rrc-task-request-details/va-rrc-task-request-details.component';

@NgModule({
  imports: [
    CommonModule,
    JmlfdcAdminRoutingModule,
    SystemNotificationModule,
    CommonComponentsModule.forRoot(),
    PipesModule,
    AbiManagementModule,
    EhrManagementModule,
    FormsModule,
    DirectivesModule,
    OrganizationComponentModule,
    MaximoManagementModule
  ],
  declarations: [
    AdminComponent,
    SystemNotificationsComponent,
    AddUpdateFeatureFlagComponent,
    FeatureFlagListComponent,
    FeatureFlagSelectorComponent,
    EmailCheckComponent,
    DmlssHostComponent,
    HealthStatusComponent,
    HealthCheckDetailComponent,
    PullFacilityRecordsComponent,
    SystemConfigurationsComponent,
    ServerConfigurationsComponent,
    EquipmentTestingComponent,
    ConfigurationGroupComponent,
    AddUpdateConfigurationComponent,
    DmlssLiveDataManagementComponent,
    DmlssServerManagementComponent,
    AddUpdateConfigurationComponent,
    TranslateIncomingDocumentComponent,
    TranslateOutgoingDocumentComponent,
    CommunicationsTranslationsComponent,
    DmlssServerManagementComponent,
    DataManagementComponent,
    CatalogManagementComponent,
    MmcTestComponent,
    FeatureFlagRolesComponent,
    FeatureFlagPermissionsComponent,
    FeatureFlagElementsComponent,
    FeatureFlagStatesComponent,
    FeatureFlagEndpointsComponent,
    CatalogManagementUploadsComponent,
    VaRrcImportsComponent,
    VaRrcTaskRequestsComponent,
    VaRrcTaskRequestDetailsComponent
  ],
  exports: [
    AdminComponent,
    FeatureFlagSelectorComponent,
    EmailCheckComponent,
    DmlssHostComponent,
    HealthStatusComponent,
    PullFacilityRecordsComponent,
    EquipmentTestingComponent
  ],

  providers: [
    EmailCheckService,
    EmailCheckApiService,
    DmlssHostManagementService,
    DmlssHostApiService,
    HealthStatusApiService,
    HealthStatusService,
    PullFacilityRecordsApiService,
    SyncFacilityRecordsApiService,
    CommunicationsDmlssApiService,
    CommunicationsTransmitApiService,
    EquipmentTestingService,
    EquipmentTestingApiService,
    InstallationSiteService,
    InstallationSiteApiService,
    AuthoritativeDataApiService,
    AuthoritativeDataService,
    RealPropertyLookupApiService,
    RealPropertyLookupService,
    DmlssApiService,
    CatalogManagementApiService
  ]
})
export class JmlfdcAdminModule {

  constructor() {
  }
}
