import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {AdminComponent} from './admin/admin.component';
import {SystemNotificationsComponent} from './system-notification/system-notifications.component';
import {CreateNotificationComponent} from './system-notification/views/create-notification/create-notification.component';
import {EditNotificationComponent} from './system-notification/views/edit-notification/edit-notification.component';
import {PullFacilityRecordsComponent} from './pull-facility-records/pull-facility-records.component';
import {FeatureFlagListComponent} from './feature-flag/views/feature-flag-list/feature-flag-list.component';
import {AddUpdateFeatureFlagComponent} from './feature-flag/views/add-update-feature-flag/add-update-feature-flag.component';
import {ViewStagingRecordsComponent} from './abi-management/views/manage-staging/view-staging-records/view-staging-records.component';
import {EditStagingRecordComponent} from './abi-management/views/manage-staging/edit-staging-record/edit-staging-record.component';
import {SetTaxonomyComponent} from './abi-management/views/manage-staging/set-taxonomy/set-taxonomy.component';
import {SetAttributesComponent} from './abi-management/views/manage-staging/set-attributes/set-attributes.component';
import {MergeRecordsComponent} from './abi-management/views/manage-staging/merge-records/merge-records.component';
import {MergeByMmcComponent} from './abi-management/views/manage-staging/merge-by-mmc/merge-by-mmc.component';
import {AbiManagementComponent} from './abi-management/abi-management.component';
import {EmailCheckComponent} from './email-check/views/email-check.component';
import {SystemConfigurationsComponent} from './system-configuration/system-configurations/system-configurations.component';
import {ManageMergedRecordsComponent} from './abi-management/views/manage-staging/manage-merged-records/manage-merged-records.component';
import {ViewDeltaRecordsComponent} from './abi-management/views/manage-delta/view-delta-records/view-delta-records.component';
import {DeltaRecordDetailsComponent} from './abi-management/views/manage-delta/delta-record-details/delta-record-details.component';
import {MoveRecordsToProductionComponent} from './abi-management/views/move-records-to-production/move-records-to-production.component';
import {ManageSiteRecordLinkageComponent} from './abi-management/views/manage-site-record-linkage/manage-site-record-linkage.component';
import {ManageConfigurationComponent} from './abi-management/views/manage-configuration/manage-configuration.component';
import {ViewMergeDetailsComponent} from './abi-management/views/manage-staging/view-merge-details/view-merge-details.component';
import {StagingRequestUtilityComponent} from './abi-management/views/manage-staging/staging-request-utility/staging-request-utility.component';
import {ManageDownloadsUtilityComponent} from './abi-management/views/manage-staging/manage-downloads-utility/manage-downloads-utility.component';
import {ManageUploadsUtilityComponent} from './abi-management/views/manage-staging/manage-uploads-utility/manage-uploads-utility.component';
import {ManageDataCollectionsUtilityComponent} from './abi-management/views/manage-staging/manage-data-collections-utility/manage-data-collections-utility.component';
import {UnspscCriticalItemCategoryMappingComponent} from './abi-management/views/manage-staging/unspsc-critical-item-category-mapping/unspsc-critical-item-category-mapping.component';
import {EditUnspscCriticalItemCategoryMappingComponent} from './abi-management/views/manage-staging/edit-unspsc-critical-item-category-mapping/edit-unspsc-critical-item-category-mapping.component';
import {SearchAndReplaceUtilityComponent} from './abi-management/views/manage-staging/search-and-replace-utility/search-and-replace-utility.component';
import {DataCollectionComponent} from './abi-management/views/manage-staging/data-collection/data-collection.component';
import {DmlssHostComponent} from './dmlss-host/dmlss-host.component';
import {HealthStatusComponent} from './health-status/health-status.component';
import {EhrTestingComponent} from './ehr/ehr-testing/ehr-testing.component';
import {EhrEquipmentSyncComponent} from './ehr/ehr-equipment-sync/ehr-equipment-sync.component';
import {EhrItemSyncComponent} from './ehr/ehr-item-sync/ehr-item-sync.component';
import {EhrSiteCustomerManagementComponent} from './ehr/ehr-site-customer-management/ehr-site-customer-management.component';
import {EhrOfferSearchComponent} from './ehr/ehr-item-sync/views/ehr-offer-search/ehr-offer-search.component';
import {EhrItemSyncDetailsComponent} from './ehr/ehr-item-sync/views/ehr-item-sync-details/ehr-item-sync-details.component';
import {EhrAbiSearchComponent} from './ehr/ehr-item-sync/views/ehr-abi-search/ehr-abi-search.component';
import {EhrAbiSearchDetailsComponent} from './ehr/ehr-item-sync/views/ehr-abi-search-details/ehr-abi-search-details.component';
import {EhrManagementComponent} from './ehr/ehr-management.component';
import {EhrManageEndpointClientComponent} from './ehr/ehr-manage-endpoint-client/ehr-manage-endpoint-client.component';
import {EquipmentTestingComponent} from './equipment-testing/equipment-testing.component';
import {DmlssLiveDataManagementComponent} from './dmlss-live-data-management/dmlss-live-data-management.component';
import {CommunicationsTranslationsComponent} from './edi-translation/views/communications-translations/communications-translations.component';
import {TranslateIncomingDocumentComponent} from './edi-translation/components/translate-incoming-document/translate-incoming-document.component';
import {TranslateOutgoingDocumentComponent} from './edi-translation/components/translate-outgoing-document/translate-outgoing-document.component';
import {MaximoManagementComponent} from './maximo/maximo-management.component';
import {MaximoWorkOrderComponent} from './maximo/maximo-work-order/maximo-work-order.component';
import {DataManagementComponent} from './data-management/data-management.component';
import {CatalogManagementComponent} from './catalog-management/catalog-management.component';
import {MmcTestComponent} from './mmc-test/mmc-test.component';
import {ServerConfigurationsComponent} from './system-configuration/components/server-configurations/server-configurations.component';


export const JMLFDC_ADMIN: Ng2StateDeclaration = {
  url: RouteConstants.JMLFDC_ADMIN.url,
  name: RouteConstants.JMLFDC_ADMIN.name,
  abstract: true,
  component: AdminComponent,
  data: {'route': RouteConstants.JMLFDC_ADMIN}
};

export const ABI_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.ABI_MANAGEMENT.url,
  name: RouteConstants.ABI_MANAGEMENT.name,
  abstract: true,
  component: AbiManagementComponent,
  data: {'route': RouteConstants.ABI_MANAGEMENT}
};
export const ABI_VIEW_STAGING_RECORDS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_VIEW_STAGING_RECORDS.url,
  name: RouteConstants.ABI_VIEW_STAGING_RECORDS.name,
  component: ViewStagingRecordsComponent,
  data: {'route': RouteConstants.ABI_VIEW_STAGING_RECORDS}
};
export const ABI_EDIT_STAGING_RECORD: Ng2StateDeclaration = {
  url: RouteConstants.ABI_EDIT_STAGING_RECORD.url,
  name: RouteConstants.ABI_EDIT_STAGING_RECORD.name,
  component: EditStagingRecordComponent,
  data: {'route': RouteConstants.ABI_EDIT_STAGING_RECORD}
};
export const ABI_STAGING_SET_UNSPSC: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_SET_UNSPSC.url,
  name: RouteConstants.ABI_STAGING_SET_UNSPSC.name,
  component: SetTaxonomyComponent,
  data: {'route': RouteConstants.ABI_STAGING_SET_UNSPSC}
};
export const ABI_STAGING_SET_ATTRS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_SET_ATTRS.url,
  name: RouteConstants.ABI_STAGING_SET_ATTRS.name,
  component: SetAttributesComponent,
  data: {'route': RouteConstants.ABI_STAGING_SET_ATTRS}
};
export const ABI_STAGING_MERGE_RECORDS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_MERGE_RECORDS.url,
  name: RouteConstants.ABI_STAGING_MERGE_RECORDS.name,
  component: MergeRecordsComponent,
  data: {'route': RouteConstants.ABI_STAGING_MERGE_RECORDS}
};
export const ABI_STAGING_MERGE_BY_MMC: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_MERGE_BY_MMC.url,
  name: RouteConstants.ABI_STAGING_MERGE_BY_MMC.name,
  component: MergeByMmcComponent,
  data: {'route': RouteConstants.ABI_STAGING_MERGE_BY_MMC}
};
export const ABI_STAGING_MANAGE_MERGED_RECORDS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_MANAGE_MERGED_RECORDS.url,
  name: RouteConstants.ABI_STAGING_MANAGE_MERGED_RECORDS.name,
  component: ManageMergedRecordsComponent,
  data: {'route': RouteConstants.ABI_STAGING_MANAGE_MERGED_RECORDS}
};
export const ABI_STAGING_VIEW_MERGED_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_VIEW_MERGED_DETAILS.url,
  name: RouteConstants.ABI_STAGING_VIEW_MERGED_DETAILS.name,
  component: ViewMergeDetailsComponent,
  data: {'route': RouteConstants.ABI_STAGING_VIEW_MERGED_DETAILS}
};
export const ABI_STAGING_EDIT_MERGED_RECORDS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_EDIT_MERGED_RECORDS.url,
  name: RouteConstants.ABI_STAGING_EDIT_MERGED_RECORDS.name,
  component: MergeRecordsComponent,
  data: {'route': RouteConstants.ABI_STAGING_EDIT_MERGED_RECORDS}
};
export const ABI_STAGING_MANAGE_STAGING_REQUESTS_UTILITY: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_MANAGE_STAGING_REQUESTS_UTILITY.url,
  name: RouteConstants.ABI_STAGING_MANAGE_STAGING_REQUESTS_UTILITY.name,
  component: StagingRequestUtilityComponent,
  data: {'route': RouteConstants.ABI_STAGING_MANAGE_STAGING_REQUESTS_UTILITY}
};
export const ABI_STAGING_MANAGE_DOWNLOADS_UTILITY: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_MANAGE_DOWNLOADS_UTILITY.url,
  name: RouteConstants.ABI_STAGING_MANAGE_DOWNLOADS_UTILITY.name,
  component: ManageDownloadsUtilityComponent,
  data: {'route': RouteConstants.ABI_STAGING_MANAGE_DOWNLOADS_UTILITY}
};
export const ABI_STAGING_MANAGE_UPLOADS_UTILITY: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_MANAGE_UPLOADS_UTILITY.url,
  name: RouteConstants.ABI_STAGING_MANAGE_UPLOADS_UTILITY.name,
  component: ManageUploadsUtilityComponent,
  data: {'route': RouteConstants.ABI_STAGING_MANAGE_UPLOADS_UTILITY}
};
export const ABI_STAGING_MANAGE_DATA_COLLECTIONS_UTILITY: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_MANAGE_DATA_COLLECTIONS_UTILITY.url,
  name: RouteConstants.ABI_STAGING_MANAGE_DATA_COLLECTIONS_UTILITY.name,
  component: ManageDataCollectionsUtilityComponent,
  data: {'route': RouteConstants.ABI_STAGING_MANAGE_DATA_COLLECTIONS_UTILITY}
};
export const UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING: Ng2StateDeclaration = {
  url: RouteConstants.UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING.url,
  name: RouteConstants.UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING.name,
  component: UnspscCriticalItemCategoryMappingComponent,
  data: {'route': RouteConstants.UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING}
};
export const EDIT_UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING: Ng2StateDeclaration = {
  url: RouteConstants.EDIT_UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING.url,
  name: RouteConstants.EDIT_UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING.name,
  component: EditUnspscCriticalItemCategoryMappingComponent,
  data: {'route': RouteConstants.EDIT_UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING}
};
export const ABI_STAGING_DATA_COLLECTION: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_DATA_COLLECTION.url,
  name: RouteConstants.ABI_STAGING_DATA_COLLECTION.name,
  component: DataCollectionComponent,
  data: {'route': RouteConstants.ABI_STAGING_DATA_COLLECTION}
};
export const ABI_STAGING_SEARCH_REPLACE_UTILITY: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_SEARCH_REPLACE_UTILITY.url,
  name: RouteConstants.ABI_STAGING_SEARCH_REPLACE_UTILITY.name,
  component: SearchAndReplaceUtilityComponent,
  data: {'route': RouteConstants.ABI_STAGING_SEARCH_REPLACE_UTILITY}
};
export const ABI_STAGING_VIEW_DELTA_RECORDS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_VIEW_DELTA_RECORDS.url,
  name: RouteConstants.ABI_STAGING_VIEW_DELTA_RECORDS.name,
  component: ViewDeltaRecordsComponent,
  data: {'route': RouteConstants.ABI_STAGING_VIEW_DELTA_RECORDS}
};
export const ABI_STAGING_DELTA_RECORD_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_DELTA_RECORD_DETAILS.url,
  name: RouteConstants.ABI_STAGING_DELTA_RECORD_DETAILS.name,
  component: DeltaRecordDetailsComponent,
  data: {'route': RouteConstants.ABI_STAGING_DELTA_RECORD_DETAILS}
};
export const ABI_STAGING_MOVE_TO_PRODUCTION: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_MOVE_TO_PRODUCTION.url,
  name: RouteConstants.ABI_STAGING_MOVE_TO_PRODUCTION.name,
  component: MoveRecordsToProductionComponent,
  data: {'route': RouteConstants.ABI_STAGING_MOVE_TO_PRODUCTION}
};
export const ABI_STAGING_MANAGE_SITE_RECORD_LINKAGE: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_MANAGE_SITE_RECORD_LINKAGE.url,
  name: RouteConstants.ABI_STAGING_MANAGE_SITE_RECORD_LINKAGE.name,
  component: ManageSiteRecordLinkageComponent,
  data: {'route': RouteConstants.ABI_STAGING_MANAGE_SITE_RECORD_LINKAGE}
};
export const ABI_STAGING_MANAGE_CONFIGURATION: Ng2StateDeclaration = {
  url: RouteConstants.ABI_STAGING_MANAGE_CONFIGURATION.url,
  name: RouteConstants.ABI_STAGING_MANAGE_CONFIGURATION.name,
  component: ManageConfigurationComponent,
  data: {'route': RouteConstants.ABI_STAGING_MANAGE_CONFIGURATION}
};

export const NOTIFICATIONS_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.NOTIFICATIONS_VIEW.url,
  name: RouteConstants.NOTIFICATIONS_VIEW.name,
  component: SystemNotificationsComponent,
  data: {'route': RouteConstants.NOTIFICATIONS_VIEW}
};
export const NOTIFICATIONS_ADD: Ng2StateDeclaration = {
  url: RouteConstants.NOTIFICATIONS_ADD.url,
  name: RouteConstants.NOTIFICATIONS_ADD.name,
  component: CreateNotificationComponent,
  data: {'route': RouteConstants.NOTIFICATIONS_ADD}
};
export const NOTIFICATIONS_EDIT: Ng2StateDeclaration = {
  url: RouteConstants.NOTIFICATIONS_EDIT.url,
  name: RouteConstants.NOTIFICATIONS_EDIT.name,
  component: EditNotificationComponent,
  data: {'route': RouteConstants.NOTIFICATIONS_EDIT}
};
export const FEATURE_FLAG_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.FEATURE_FLAG_VIEW.url,
  name: RouteConstants.FEATURE_FLAG_VIEW.name,
  component: FeatureFlagListComponent,
  data: {'route': RouteConstants.FEATURE_FLAG_VIEW}
};
export const FEATURE_FLAG_EDIT: Ng2StateDeclaration = {
  url: RouteConstants.FEATURE_FLAG_EDIT.url,
  name: RouteConstants.FEATURE_FLAG_EDIT.name,
  component: AddUpdateFeatureFlagComponent,
  data: {'route': RouteConstants.FEATURE_FLAG_EDIT}
};
export const EMAIL_CHECK: Ng2StateDeclaration = {
  url: RouteConstants.EMAIL_CHECK.url,
  name: RouteConstants.EMAIL_CHECK.name,
  component: EmailCheckComponent,
  data: {'route': RouteConstants.EMAIL_CHECK}
};
export const DATA_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.DATA_MANAGEMENT.url,
  name: RouteConstants.DATA_MANAGEMENT.name,
  component: DataManagementComponent,
  data: {'route': RouteConstants.DATA_MANAGEMENT}
};
export const DMLSS_HOST: Ng2StateDeclaration = {
  url: RouteConstants.DMLSS_HOST.url,
  name: RouteConstants.DMLSS_HOST.name,
  component: DmlssHostComponent,
  data: {'route': RouteConstants.DMLSS_HOST}
};
export const DMLSS_LIVE_DATA_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.DMLSS_LIVE_DATA_MANAGEMENT.url,
  name: RouteConstants.DMLSS_LIVE_DATA_MANAGEMENT.name,
  component: DmlssLiveDataManagementComponent,
  data: {'route': RouteConstants.DMLSS_LIVE_DATA_MANAGEMENT}
};
export const HEALTH_STATUS: Ng2StateDeclaration = {
  url: RouteConstants.HEALTH_STATUS.url,
  name: RouteConstants.HEALTH_STATUS.name,
  component: HealthStatusComponent,
  data: {'route': RouteConstants.HEALTH_STATUS}
};
export const MMC_TEST: Ng2StateDeclaration = {
  url: RouteConstants.MMC_TEST.url,
  name: RouteConstants.MMC_TEST.name,
  component: MmcTestComponent,
  data: {'route': RouteConstants.MMC_TEST}
};
export const EQUIPMENT_TESTING: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_TESTING.url,
  name: RouteConstants.EQUIPMENT_TESTING.name,
  component: EquipmentTestingComponent,
  data: {'route': RouteConstants.EQUIPMENT_TESTING}
};
export const FEATURE_FLAG_CREATE: Ng2StateDeclaration = {
  url: RouteConstants.FEATURE_FLAG_CREATE.url,
  name: RouteConstants.FEATURE_FLAG_CREATE.name,
  component: AddUpdateFeatureFlagComponent,
  data: {'route': RouteConstants.FEATURE_FLAG_CREATE}
};
export const FACILITY_RECORDS_DMLSS_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.FACILITY_RECORDS_DMLSS_MANAGEMENT.url,
  name: RouteConstants.FACILITY_RECORDS_DMLSS_MANAGEMENT.name,
  component: PullFacilityRecordsComponent,
  data: {'route': RouteConstants.FACILITY_RECORDS_DMLSS_MANAGEMENT}
};
export const EHR_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.EHR_MANAGEMENT.url,
  name: RouteConstants.EHR_MANAGEMENT.name,
  abstract: true,
  component: EhrManagementComponent,
  data: {'route': RouteConstants.EHR_MANAGEMENT}
};
export const EHR_SITE_CUSTOMER_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.EHR_SITE_CUSTOMER_MANAGEMENT.url,
  name: RouteConstants.EHR_SITE_CUSTOMER_MANAGEMENT.name,
  component: EhrSiteCustomerManagementComponent,
  data: {'route': RouteConstants.EHR_SITE_CUSTOMER_MANAGEMENT}
};
export const EHR_EQUIPMENT_SYNC: Ng2StateDeclaration = {
  url: RouteConstants.EHR_EQUIPMENT_SYNC.url,
  name: RouteConstants.EHR_EQUIPMENT_SYNC.name,
  component: EhrEquipmentSyncComponent,
  data: {'route': RouteConstants.EHR_EQUIPMENT_SYNC}
};
export const EHR_TESTING: Ng2StateDeclaration = {
  url: RouteConstants.EHR_TESTING.url,
  name: RouteConstants.EHR_TESTING.name,
  component: EhrTestingComponent,
  data: {'route': RouteConstants.EHR_TESTING}
};
export const EHR_ITEM_SYNC: Ng2StateDeclaration = {
  url: RouteConstants.EHR_ITEM_SYNC.url,
  name: RouteConstants.EHR_ITEM_SYNC.name,
  abstract: true,
  component: EhrItemSyncComponent,
  data: {'route': RouteConstants.EHR_ITEM_SYNC}
};
export const EHR_ITEM_SYNC_ITEM_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.EHR_ITEM_SYNC_ITEM_SEARCH.url,
  name: RouteConstants.EHR_ITEM_SYNC_ITEM_SEARCH.name,
  component: EhrOfferSearchComponent,
  data: {'route': RouteConstants.EHR_ITEM_SYNC_ITEM_SEARCH}
};
export const EHR_ITEM_SYNC_ITEM_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.EHR_ITEM_SYNC_ITEM_DETAILS.url,
  name: RouteConstants.EHR_ITEM_SYNC_ITEM_DETAILS.name,
  component: EhrItemSyncDetailsComponent,
  data: {'route': RouteConstants.EHR_ITEM_SYNC_ITEM_DETAILS}
};
export const EHR_ITEM_SYNC_ABI_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.EHR_ITEM_SYNC_ABI_SEARCH.url,
  name: RouteConstants.EHR_ITEM_SYNC_ABI_SEARCH.name,
  component: EhrAbiSearchComponent,
  data: {'route': RouteConstants.EHR_ITEM_SYNC_ABI_SEARCH}
};
export const EHR_ITEM_SYNC_ABI_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.EHR_ITEM_SYNC_ABI_DETAILS.url,
  name: RouteConstants.EHR_ITEM_SYNC_ABI_DETAILS.name,
  component: EhrAbiSearchDetailsComponent,
  data: {'route': RouteConstants.EHR_ITEM_SYNC_ABI_DETAILS}
};
export const EHR_MANAGE_ENDPOINT_CLIENT: Ng2StateDeclaration = {
  url: RouteConstants.EHR_MANAGE_CLIENT_URLS.url,
  name: RouteConstants.EHR_MANAGE_CLIENT_URLS.name,
  component: EhrManageEndpointClientComponent,
  data: {'route': RouteConstants.EHR_MANAGE_CLIENT_URLS}
};

export const CONFIGURATIONS_VIEW: Ng2StateDeclaration = {
  url: RouteConstants.CONFIGURATIONS_VIEW.url,
  name: RouteConstants.CONFIGURATIONS_VIEW.name,
  component: SystemConfigurationsComponent,
  data: {'route': RouteConstants.CONFIGURATIONS_VIEW}
};

export const CONFIGURATIONS_SERVER: Ng2StateDeclaration = {
  url: RouteConstants.CONFIGURATIONS_SERVER.url,
  name: RouteConstants.CONFIGURATIONS_SERVER.name,
  component: ServerConfigurationsComponent,
  data: {'route': RouteConstants.CONFIGURATIONS_SERVER}
};

export const COMMUNICATIONS_TRANSLATIONS: Ng2StateDeclaration = {
  url: RouteConstants.COMMUNICATIONS_TRANSLATIONS.url,
  name: RouteConstants.COMMUNICATIONS_TRANSLATIONS.name,
  component: CommunicationsTranslationsComponent,
  data: {'route': RouteConstants.COMMUNICATIONS_TRANSLATIONS}
};

export const COMMUNICATIONS_INBOUND_TRANSLATION: Ng2StateDeclaration = {
  url: RouteConstants.INBOUND_TRANSLATION.url,
  name: RouteConstants.INBOUND_TRANSLATION.name,
  component: TranslateIncomingDocumentComponent,
  data: {'route': RouteConstants.INBOUND_TRANSLATION}
};

export const COMMUNICATIONS_OUTBOUND_TRANSLATION: Ng2StateDeclaration = {
  url: RouteConstants.OUTBOUND_TRANSLATION.url,
  name: RouteConstants.OUTBOUND_TRANSLATION.name,
  component: TranslateOutgoingDocumentComponent,
  data: {'route': RouteConstants.OUTBOUND_TRANSLATION}
};

export const MAXIMO_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.MAXIMO_MANAGEMENT.url,
  name: RouteConstants.MAXIMO_MANAGEMENT.name,
  abstract: true,
  component: MaximoManagementComponent,
  data: {'route': RouteConstants.MAXIMO_MANAGEMENT}
};
export const MAXIMO_WORK_ORDER: Ng2StateDeclaration = {
  url: RouteConstants.MAXIMO_WORK_ORDER.url,
  name: RouteConstants.MAXIMO_WORK_ORDER.name,
  component: MaximoWorkOrderComponent,
  data: {'route': RouteConstants.MAXIMO_WORK_ORDER}
};
export const CATALOG_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteConstants.CATALOG_MANAGEMENT.url,
  name: RouteConstants.CATALOG_MANAGEMENT.name,
  component: CatalogManagementComponent,
  data: {'route': RouteConstants.CATALOG_MANAGEMENT}
};


export const JmlfdcAdminStates: Ng2StateDeclaration[] = [
  JMLFDC_ADMIN,
  ABI_MANAGEMENT,
  ABI_VIEW_STAGING_RECORDS,
  ABI_EDIT_STAGING_RECORD,
  ABI_STAGING_SET_UNSPSC,
  ABI_STAGING_SET_ATTRS,
  ABI_STAGING_MERGE_RECORDS,
  ABI_STAGING_MERGE_BY_MMC,
  ABI_STAGING_MANAGE_MERGED_RECORDS,
  ABI_STAGING_VIEW_MERGED_DETAILS,
  ABI_STAGING_EDIT_MERGED_RECORDS,
  ABI_STAGING_MANAGE_STAGING_REQUESTS_UTILITY,
  ABI_STAGING_MANAGE_DOWNLOADS_UTILITY,
  ABI_STAGING_MANAGE_UPLOADS_UTILITY,
  ABI_STAGING_MANAGE_DATA_COLLECTIONS_UTILITY,
  UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING,
  EDIT_UNSPSC_CRITICAL_ITEM_CATEGORY_MAPPING,
  ABI_STAGING_DATA_COLLECTION,
  ABI_STAGING_SEARCH_REPLACE_UTILITY,
  ABI_STAGING_VIEW_DELTA_RECORDS,
  ABI_STAGING_DELTA_RECORD_DETAILS,
  ABI_STAGING_MOVE_TO_PRODUCTION,
  ABI_STAGING_MANAGE_SITE_RECORD_LINKAGE,
  ABI_STAGING_MANAGE_CONFIGURATION,
  NOTIFICATIONS_VIEW,
  NOTIFICATIONS_ADD,
  NOTIFICATIONS_EDIT,
  FEATURE_FLAG_VIEW,
  FEATURE_FLAG_EDIT,
  EMAIL_CHECK,
  DATA_MANAGEMENT,
  DMLSS_HOST,
  DMLSS_LIVE_DATA_MANAGEMENT,
  HEALTH_STATUS,
  MMC_TEST,
  EQUIPMENT_TESTING,
  FEATURE_FLAG_CREATE,
  FACILITY_RECORDS_DMLSS_MANAGEMENT,
  EHR_MANAGEMENT,
  EHR_SITE_CUSTOMER_MANAGEMENT,
  EHR_EQUIPMENT_SYNC,
  EHR_TESTING,
  EHR_ITEM_SYNC,
  EHR_ITEM_SYNC_ITEM_SEARCH,
  EHR_ITEM_SYNC_ITEM_DETAILS,
  EHR_ITEM_SYNC_ABI_SEARCH,
  EHR_ITEM_SYNC_ABI_DETAILS,
  EHR_MANAGE_ENDPOINT_CLIENT,
  CONFIGURATIONS_VIEW,
  CONFIGURATIONS_SERVER,
  COMMUNICATIONS_TRANSLATIONS,
  COMMUNICATIONS_INBOUND_TRANSLATION,
  COMMUNICATIONS_OUTBOUND_TRANSLATION,
  MAXIMO_MANAGEMENT,
  MAXIMO_WORK_ORDER,
  CATALOG_MANAGEMENT
];
