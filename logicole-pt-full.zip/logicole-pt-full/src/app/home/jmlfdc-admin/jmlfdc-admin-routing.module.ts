import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {JmlfdcAdminStates} from './jmlfdc-admin-states';
import {RouteConstants} from '@lc-constants/*';

const adminRoutes: RootModule = {
  states: JmlfdcAdminStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(adminRoutes)],
  exports: [UIRouterModule]
})
export class JmlfdcAdminRoutingModule {
}
