import { Injectable } from '@angular/core';
import {SystemNotification} from './system-notification/models/system-notification';

@Injectable({
  providedIn: 'root'
})
export class JmlfdcAdminService {

  public systemNotification: SystemNotification;

  constructor() { }
}
