import {Component, OnInit} from '@angular/core';
import {HelpCenterService} from './help/help-center/help-center.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html'
})
export class HomeComponent implements OnInit {

  constructor(public helpCenterService: HelpCenterService) {
  }

  public ngOnInit() {
  }

}
