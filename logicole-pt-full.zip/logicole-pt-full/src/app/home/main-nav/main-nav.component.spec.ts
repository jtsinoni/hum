import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {MainNavComponent} from './main-nav.component';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {LoggerService} from '@lc-logger-service';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {NgxBootstrapModule} from '../../common-components/ngx-bootstrap/ngx-bootstrap.module';
import {MainNavService} from './main-nav.service';
import {StateNavigationService} from '../../services/state-navigation.service';
import {StateNavigationServiceMock} from '../../services/state-navigation.service.mock';
import {LoginService} from '@lc-services/*';
import {LoginServiceMock} from '../../services/core/login.service.mock';
import {UtilService} from '../../services/util.service';
import {CurrencyPipe} from '@angular/common';
import {StorageService} from '../../services/storage.service';
import {WindowService} from '../../services/window.service';
import {SsoSapTewlsApiService} from '../../services/sso-sap-tewls-api.service';

describe('MainNavComponent', () => {
  let component: MainNavComponent;
  let fixture: ComponentFixture<MainNavComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [NgxBootstrapModule.forRoot()],
      declarations: [ MainNavComponent ],
      providers: [
        LoggerService,
        MainNavService,
        UtilService,
        CurrencyPipe,
        StorageService,
        {provide: StateNavigationService, useClass: StateNavigationServiceMock},
        {provide: LoginService, useClass: LoginServiceMock},
        {provide: WindowService, useClass: WindowService}
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      a11yTests(fixture.nativeElement)
        .then((results) => {
          expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
        })
        .catch((error) => {
          loggerService.error(`${error}`);
        });
    }));
  });
});
