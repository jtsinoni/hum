import {RouteInfo} from '@lc-constants/*';
import {NavigationModel} from './navigation.model';
import {Ng2StateDeclaration} from '@uirouter/angular';

export class MainNavServiceMock {

  public currentRouteInfo: RouteInfo;

  public myNav: Array<NavigationModel> = [];

  constructor() {
  }

  public loadMyNavPerRole(currUser) {
  }

  public setCurrentState(toState: Ng2StateDeclaration) {

  }

  public activateMainNav(navigationId?: string): void {

  }

}

