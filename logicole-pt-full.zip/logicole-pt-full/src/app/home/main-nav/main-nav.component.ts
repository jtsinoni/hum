import {Component, OnInit} from '@angular/core';
import {MainNavService} from './main-nav.service';
import {LoggerService, LoginService} from '@lc-services/*';
import {RouteConstants, RouteInfo} from '@lc-constants/*';
import {StateNavigationService} from '@lc-services/*';
import {SsoSapTewlsApiService} from '../../services/sso-sap-tewls-api.service';

@Component({
  selector: 'app-main-nav',
  templateUrl: './main-nav.component.html',
})
export class MainNavComponent implements OnInit {

  constructor(public mainNavService: MainNavService,
              private logger: LoggerService,
              private navigationService: StateNavigationService,
              private loginService: LoginService,
              private ssoSapTewlsApiService: SsoSapTewlsApiService) {
  }

  public ngOnInit() {
    this.mainNavService.loadMyNavPerRole(this.loginService.getCurrentUser());
  }

  public isSimpleButton(id: string): boolean {
    return id === 'dashboard' || id === 'sso-sap-tewls';
  }

  public showButton(id: string): boolean {
    if (id === 'sso-sap-tewls' && !this.ssoSapTewlsApiService.hasTewlsUrl()) {
      return false;
    }
    return true;
  }

  public goTo(id: string): void {
    if (id === 'dashboard') {
      this.goToDashboard();
    } else if (id === 'sso-sap-tewls') {
      this.goToTewlsSso();
    }
  }

  public goToDashboard(): void {
    this.navigationService.navigateToState(RouteConstants.MY_DASHBOARD, true);
  }

  public goToTewlsSso(): void {
    this.ssoSapTewlsApiService.openTewlsTab();
  }

  public navigateTo(routeInfo: RouteInfo): void {
    this.logger.debug(`going to ${routeInfo.name}`);
    this.navigationService.navigateTo(routeInfo);
  }
}
