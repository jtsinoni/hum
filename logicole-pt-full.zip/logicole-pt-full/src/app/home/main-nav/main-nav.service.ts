import {Injectable} from '@angular/core';
import {LoggerService} from '@lc-logger-service';
import {ApiConstants, NavigationConstants, RouteConstants, RouteInfo} from '@lc-constants/*';
import {NavigationModel} from './navigation.model';
import {Ng2StateDeclaration} from '@uirouter/angular';
import {UtilService} from '../../services/util.service';
import {StorageService} from '../../services/storage.service';
import {RouteAssemblageConstants} from '../assemblage/constants/route-assemblage.constants';
import {RouteMedicalEquipmentConstants} from '../asset/medical-equipment/constants/route-medical-equipment.constants';
import {RouteCustodianConstants} from '../asset/custodian/constants/route-custodian.constants';
import {RouteModalityConstants} from '../asset/modality/constants/route-modality.constants';
import {RouteUtilitiesConstants} from '../utilities/constants/route-utilities.constants.ts';
import {RouteConsultantConstants} from '../asset/consultant/constants/route-consultant.constants';

@Injectable()
export class MainNavService {

  public currentRouteInfo: RouteInfo;
  private serviceName: string = 'MainNavService';
  public masterNav: Array<NavigationModel> = [
    {
      'id': 'dashboard',
      'active': true,
      'tooltip': 'Dashboard',
      'icon': 'fa-tachometer-alt',
      'buttonGroup': '',
      'statesCovered': [
        RouteConstants.HOME_ROOT
      ],
      'navChoices': null
    },
    {
      'id': NavigationConstants.ABI_NAV_ID,
      'active': false,
      'tooltip': 'ABi Search',
      'icon': 'fa-search',
      'buttonGroup': 'btnGroupABiSearch',
      'statesCovered': [
        RouteConstants.ABI_SEARCH
      ],
      'navChoices': [
        RouteConstants.ABI_SEARCH
      ]
    },
    {
      'id': NavigationConstants.ACCESS_NAV_ID,
      'active': false,
      'tooltip': 'Access Management',
      'icon': 'fa-users',
      'buttonGroup': 'btnGroupAccess',
      'statesCovered': [
        RouteConstants.ACCESS_ROOT
      ],
      'navChoices': [
        RouteConstants.ACCESS_USER_REQUEST_MANAGEMENT,
        RouteConstants.ACCESS_PROFILE_MANAGEMENT,
        RouteConstants.ACCESS_ROLE_MANAGEMENT,
        RouteConstants.ACCESS_ROLE_SERVICE_MANAGEMENT,
        RouteConstants.ACCESS_PERMISSIONS
      ]
    },
    {
      'id': NavigationConstants.ASSEMBLAGE_NAV_ID,
      'active': false,
      'tooltip': 'Assemblage Management',
      'icon': 'fa-layer-group',
      'buttonGroup': 'btnGroupAssemblage',
      'statesCovered': [
        RouteAssemblageConstants.ASSEMBLAGE_MANAGEMENT,
        RouteAssemblageConstants.ASSEMBLAGE_REFERENCE_DATA
      ],
      'navChoices': [
        RouteAssemblageConstants.AUTHORITATIVE_ASSEMBLAGES,
        RouteAssemblageConstants.VIEW_STAGING_RECORDS,
        RouteAssemblageConstants.ASSEMBLAGES,
        RouteAssemblageConstants.ASSEMBLAGE_MASS_UPDATE,
        RouteAssemblageConstants.ASSEMBLAGE_ALLOWANCE,
        RouteAssemblageConstants.ASSEMBLAGE_ALLOWANCE_UPLOAD,
        RouteAssemblageConstants.ASSEMBLAGE_SHIPMENTS,
        RouteAssemblageConstants.ASSEMBLAGE_FUNDS_ASSOCIATION_MANAGEMENT,
        RouteAssemblageConstants.ASSEMBLAGE_CART,
        RouteAssemblageConstants.ASSEMBLAGE_REFERENCE_DATA
      ]
    },
    {
      'id': NavigationConstants.BUSINESS_INTELLIGENCE_NAV_ID,
      'active': false,
      'tooltip': 'Reporting & Analytics',
      'icon': 'fa-chart-pie',
      'buttonGroup': 'btnGroupBI',
      'statesCovered': [
        RouteConstants.BUSINESS_INTELLIGENCE_ROOT
      ],
      'navChoices': [
        RouteConstants.BUSINESS_INTELLIGENCE
      ]
    },
    {
      'id': NavigationConstants.CATALOG_NAV_ID,
      'active': false,
      'tooltip': 'Catalog Management',
      'icon': 'fa-notes-medical',
      'buttonGroup': 'btnGroupCatalog',
      'statesCovered': [
        RouteConstants.CATALOG_ROOT
      ],
      'navChoices': [
       // RouteConstants.ORDER_CATALOG,
        RouteConstants.ENTERPRISE_ITEM_SEARCH,
        // RouteConstants.ITEM_SOURCING_SEARCH,
        RouteConstants.CUSTOMER_ITEM_SOURCING_SEARCH,
        // RouteConstants.NON_CATALOG_SEARCH,
        RouteConstants.CATALOG_REFERENCE_DATA
      ]
    },
    {
      'id': NavigationConstants.COMMUNICATIONS_NAV_ID,
      'active': false,
      'tooltip': 'Communications',
      'icon': 'fa-broadcast-tower',
      'buttonGroup': 'btnGroupComm',
      'statesCovered': [
        RouteConstants.COMMUNICATIONS_ROOT
      ],
      'navChoices': [
        RouteConstants.COMMUNICATION_TRANSACTIONS,
        RouteConstants.DAAS_TESTING,
        RouteConstants.EDI_TESTING,
        RouteConstants.EHR_INCOMING_TRAFFIC_VIEW,
        RouteConstants.COMMUNICATIONS_OUTBOUND_CONFIG
      ]
    },
    {
      'id': NavigationConstants.EQUIPMENT_MANAGEMENT_NAV_ID,
      'active': false,
      'tooltip': 'Equipment Management',
      'icon': 'fa-medkit',
      'buttonGroup': 'btnGroupEquip',
      'statesCovered': [],
      'navChoices': [
        RouteConstants.EQUIPMENT_REQUESTS,
        RouteConstants.EQUIPMENT_PRIORITIZATION,
        RouteConstants.EQUIPMENT_RECORDS,
        RouteConstants.EQUIPMENT_GROUPS,
        RouteConsultantConstants.CONSULTANT_MANAGEMENT,
        RouteCustodianConstants.CUSTODIAN_MANAGEMENT,
        RouteConstants.EQUIPMENT_MANUFACTURER,
        RouteConstants.EQUIPMENT_NOMENCLATURE,
        RouteConstants.EQUIPMENT_CLASSIFICATION_REQUEST,
        RouteModalityConstants.MODALITY_MANAGEMENT,
        RouteConstants.EQUIPMENT_LOOKUP,
        RouteConstants.DMLSS_EQUIPMENT_RECORDS,
        RouteMedicalEquipmentConstants.MEDICAL_EQUIPMENT_MANAGEMENT,
        RouteMedicalEquipmentConstants.MEDICAL_EQUIPMENT_GAIN,
        RouteMedicalEquipmentConstants.MEDICAL_EQUIPMENT_LOAN,
        RouteMedicalEquipmentConstants.MEDICAL_EQUIPMENT_SOFTWARE
      ]
    },
    {
      'id': NavigationConstants.FINANCE_NAV_ID,
      'active': false,
      'tooltip': 'Finance',
      'icon': 'fa-dollar-sign',
      'buttonGroup': 'btnGroupFinance',
      'statesCovered': [
        RouteConstants.FINANCE_ROOT
      ],
      'navChoices': [
        RouteConstants.FINANCE_FUNDING_SEARCH,
        RouteConstants.FINANCE_FUNDING_SOURCE_SEARCH,
        RouteConstants.FINANCE_REF_DATA_SEARCH,
        RouteConstants.FINANCE_PURCHASE_CARDS,
        RouteConstants.FINANCE_ROLLOVER
      ]
    },
    {
      'id': NavigationConstants.INVENTORY_NAV_ID,
      'active': false,
      'tooltip': 'Inventory',
      'icon': 'fa-boxes',
      'buttonGroup': 'btnGroupInventory',
      'statesCovered': [
        RouteConstants.INVENTORY_REC_SEARCH
      ],
      'navChoices': [
        RouteConstants.INVENTORY_MANAGEMENT,
        RouteConstants.INVENTORY_DETAILS,
        RouteConstants.INVENTORY_REC_SEARCH,
        RouteConstants.INVENTORY_REC_ACCOUNTABILITY,
        RouteConstants.INVENTORY_REC_ACCOUNTABILITY_DETAILS,
        RouteConstants.INVENTORY_REPLENISHMENT,

        RouteConstants.INVENTORY_AUDIT,
        RouteConstants.INVENTORY_PLANNING,
        RouteConstants.INVENTORY_SHIPPING,
        RouteConstants.INVENTORY_RETURNS,

        RouteConstants.INVENTORY_POTENTIAL_EXCESS,
        RouteConstants.INVENTORY_SITE_EXCESS_MANAGEMENT,
        RouteConstants.INVENTORY_ENTERPRISE_EXCESS_SEARCH,
        RouteConstants.INVENTORY_ENTERPRISE_EXCESS_MANAGEMENT
      ]
    },
    {
      'id': NavigationConstants.MAINTENANCE_NAV_ID,
      'active': false,
      'tooltip': 'Maintenance',
      'icon': 'fa-wrench',
      'buttonGroup': 'btnGroupMaint',
      'statesCovered': [
        RouteConstants.ASSET_DATA_MANAGEMENT,
        RouteConstants.ASSET_MAINTENANCE_PROCEDURES,
        RouteConstants.MAINTENANCE_ROOT,
        RouteConstants.MAINTENANCE_PLANS_AND_SCHEDULES,
        RouteConstants.WORK_ORDER_CORE_SEARCH,
        RouteConstants.MEDICAL_EQUIPMENT_WORK_ORDER_SEARCH,
        RouteConstants.WORK_ORDER_PRIORITIZATION,
        RouteConstants.WORK_LOAD_SUMMARY,
        RouteConstants.MAINTENANCE_REFERENCE_DATA
      ],
      'navChoices': [
        RouteConstants.ASSET_DATA_MANAGEMENT,
        RouteConstants.MAINTENANCE_ACTIVITY,
        RouteConstants.MAINTENANCE_PROCEDURES,
        RouteConstants.MAINTENANCE_PLANS_AND_SCHEDULES,
        RouteConstants.MAINTENANCE_TECHNICIANS,
        RouteConstants.MAINTENANCE_TEAMS,
        RouteConstants.WORK_ORDER_CORE_SEARCH,
        RouteConstants.WORK_ORDER_PRIORITIZATION,
        RouteConstants.WORK_LOAD_SUMMARY,
        RouteConstants.MAINTENANCE_REFERENCE_DATA
      ]
    },
    {
      'id': NavigationConstants.NOTIFICATIONS_NAV_ID,
      'active': false,
      'tooltip': 'Notifications',
      'icon': 'fa-bell',
      'buttonGroup': 'btnGroupNotifications',
      'statesCovered': [
        RouteConstants.NOTIFICATIONS_ROOT
      ],
      'navChoices': [
        RouteConstants.NOTIFICATIONS
      ]
    },
    {
      'id': NavigationConstants.FULFILLMENT_NAV_ID,
      'active': false,
      'tooltip': 'Order Fulfillment',
      'icon': 'fa-dolly',
      'buttonGroup': 'btnGroupSeller',
      'statesCovered': [
        RouteConstants.FULFILLMENT
      ],
      'navChoices': [
        RouteConstants.FULFILLMENT_FULFILLMENT_ACTIVITY,
        RouteConstants.FULFILLMENT_ORDER_FULFILLMENT,
      ]
    },
    {
      'id': NavigationConstants.ORGANIZATION_NAV_ID,
      'active': false,
      'tooltip': 'Organization',
      'icon': 'fa-sitemap',
      'buttonGroup': 'btnGroupOrg',
      'statesCovered': [
        RouteConstants.ORGANIZATION_ROOT
      ],
      'navChoices': [
        RouteConstants.BUSINESS_SERVICE_DEFINITION_MANAGEMENT,
        RouteConstants.ORGANIZATION_MANAGEMENT,
        RouteConstants.ORGANIZATION_TESTING,
        RouteConstants.ORGANIZATION_VIEW,
        RouteConstants.PROVIDER_MANAGEMENT,
        RouteConstants.ORGANIZATION_DATA_UPLOAD
      ]
    },
    {
      'id': NavigationConstants.ORDERING_NAV_ID,
      'active': false,
      'tooltip': 'Purchasing',
      'icon': 'fa-credit-card',
      'buttonGroup': 'btnGroupOrder',
      'statesCovered': [
        RouteConstants.ORDER_VIEW

      ],
      'navChoices': [
        RouteConstants.ORDER_CATALOG,
        RouteConstants.ORDER_CATALOG_NON_CATALOG_PURCHASE,
        RouteConstants.ORDER_CART,
        RouteConstants.ORDER_REVIEW,
        //RouteConstants.ORDER_LISTS,
        RouteConstants.ORDER_VIEW,
        RouteConstants.ORDER_SELLER,
      ]
    },
    {
      'id': NavigationConstants.REAL_PROPERTY_NAV_ID,
      'active': false,
      'tooltip': 'Real Property',
      'icon': 'fa-hospital-alt',
      'buttonGroup': 'btnGroupRP',
      'statesCovered': [
        RouteConstants.REAL_PROPERTY_ROOT,
        RouteConstants.SECTION_ROOT
      ]
      ,
      'navChoices': [
        RouteConstants.REAL_PROPERTY_INSTALLATIONS,
        RouteConstants.REAL_PROPERTY_SITES,
        RouteConstants.REAL_PROPERTY_FACILITY_MANAGEMENT,
        RouteConstants.REAL_PROPERTY_SECTION_MANAGEMENT,
        RouteConstants.REAL_PROPERTY_SPACE_MANAGEMENT,
        RouteConstants.REAL_PROPERTY_SPACE_OCCUPANTS,
        RouteConstants.REAL_PROPERTY_DRAWING_MANAGEMENT,

        RouteConstants.REAL_PROPERTY_REQUIREMENTS_MANAGEMENT,
        RouteConstants.REAL_PROPERTY_REQUIREMENTS_PRIORITIZATION,

        RouteConstants.REAL_PROPERTY_PROJECT_MANAGEMENT,

        RouteConstants.REAL_PROPERTY_REFERENCE_DATA,
        RouteConstants.REAL_PROPERTY_DRAWING_SPACE_FILL,
        RouteConstants.REAL_PROPERTY_DATA_MANAGER,
        RouteConstants.REAL_PROPERTY_COBIE_ADMINISTRATION
      ]
    },
    {
      'id': NavigationConstants.RECEIVING_NAV_ID,
      'active': false,
      'tooltip': 'Receiving',
      'icon': 'fa-box-open',
      'buttonGroup': 'btnGroupReceiving',
      'statesCovered': [
        RouteConstants.RECEIVE_DUEIN
      ],
      'navChoices': [
        RouteConstants.RECEIVE_DUEIN
        // RouteConstants.RECEIVE_PUT_AWAY
      ]
    },
    {
      'id': NavigationConstants.SLEP_NAV_ID,
      'active': false,
      'tooltip': 'Shelf Life Extension Program (SLEP)',
      'icon': 'fa-recycle',
      'buttonGroup': 'btnGroupSlep',
      'statesCovered': [
        RouteConstants.SLEP_ROOT
      ],
      'navChoices': [
        RouteConstants.SLEP_ACCESS_CONTROL,
        RouteConstants.SLEP_INVENTORY_MANAGEMENT,
        RouteConstants.SLEP_LOT_MANAGEMENT,
        RouteConstants.SLEP_PROJECT_MANAGEMENT,
        RouteConstants.SLEP_NSN_MANAGEMENT,
        RouteConstants.SLEP_SITE_MANAGEMENT
      ]
    },
    {
      'id': NavigationConstants.SSO_SAP_TEWLS_NAV_ID,
      'active': false,
      'tooltip': 'DML-ES - SAP (TEWLS LEGACY) Single Sign-On',
      'icon': 'fa-dolly-flatbed',
      'buttonGroup': 'btnGroupSso',
      'statesCovered': [
        RouteConstants.SSO_SAP_TEWLS,
      ],
      'navChoices': [
        RouteConstants.SSO_SAP_TEWLS,
      ]
    },
    {
      'id': NavigationConstants.HELP_DEV_ID,
      'active': false,
      'tooltip': 'Training Development',
      'icon': 'fa-graduation-cap',
      'buttonGroup': 'btnGroupTrain',
      'statesCovered': [
        RouteConstants.HELP_ROOT
      ],
      'navChoices': [
        RouteConstants.HELP_BUILDER,
        RouteConstants.HELP_TOC_EDITOR,
        RouteConstants.HELP_CENTER_IMPORT_EXPORT,
        RouteConstants.HELP_PACKAGE_UPLOAD,
        RouteConstants.HELP_RELEASE_EDITOR,

        RouteConstants.HELP_CONTENT_REPORT,
        RouteConstants.HELP_CONTEXT_MAP_REPORT
      ]
    },
    {
      'id': NavigationConstants.UTIL_NAV_ID,
      'active': false,
      'tooltip': 'Utilities',
      'icon': 'fa-tools',
      'buttonGroup': 'btnGroupUtils',
      'statesCovered': [
        RouteUtilitiesConstants.UTILITIES_ROOT
      ],
      'navChoices': [
        RouteUtilitiesConstants.BUSINESS_CONTACTS,
        RouteUtilitiesConstants.CUSTOM_FIELDS,
        RouteUtilitiesConstants.TAG_MANAGEMENT,
        RouteUtilitiesConstants.TRANSACTION_HISTORY_SHELL

      ]
    },
    {
      'id': NavigationConstants.ADMIN_NAV_ID,
      'active': false,
      'tooltip': 'LogiCole Admin',
      'icon': 'fa-cogs',
      'buttonGroup': 'btnGroupAdmin',
      'statesCovered': [
        RouteConstants.JMLFDC_ADMIN
      ],
      'navChoices': [
        RouteConstants.ABI_VIEW_STAGING_RECORDS,
        RouteConstants.CATALOG_MANAGEMENT,
        RouteConstants.MAXIMO_WORK_ORDER,
        RouteConstants.CONFIGURATIONS_VIEW,
        RouteConstants.DATA_MANAGEMENT,
        RouteConstants.FACILITY_RECORDS_DMLSS_MANAGEMENT,
        RouteConstants.DMLSS_HOST,
        RouteConstants.DMLSS_LIVE_DATA_MANAGEMENT,
        RouteConstants.EHR_SITE_CUSTOMER_MANAGEMENT,
        RouteConstants.EMAIL_CHECK,
        RouteConstants.EQUIPMENT_TESTING,
        RouteConstants.FEATURE_FLAG_VIEW,
        RouteConstants.HEALTH_STATUS,
        RouteConstants.MMC_TEST,
        RouteConstants.NOTIFICATIONS_VIEW
      ]
    }
  ];

  public myNav: Array<NavigationModel> = [];

  constructor(private logger: LoggerService, private utilService: UtilService, private storageService: StorageService) {
    this.logger.info('%s - Start', this.serviceName);
  }

  private getRoute(): RouteInfo {
    return this.storageService.getData(ApiConstants.LC_ROUTE_KEY);
  }

  public loadMyNavPerRole(currUser): void {
    this.myNav = this.masterNav.map(masterNav => {
      const masterNavCopy = this.utilService.deepCopy(masterNav);
      masterNavCopy.navChoices = (masterNav.navChoices || []).filter(navItem => currUser.elements.indexOf(navItem.perm) > -1);
      return masterNavCopy;
    }).filter(masterNav => masterNav.id === 'dashboard' || (masterNav.navChoices && masterNav.navChoices.length));

    const savedRoute: RouteInfo = this.getRoute();
    if (savedRoute){
      this.activateMainNav(savedRoute);
    }
  }

  public setCurrentState(toState: Ng2StateDeclaration): void {
    this.currentRouteInfo = toState.data['route'];
    this.activateMainNav(this.currentRouteInfo);
  }

  public activateMainNav(routeInfo: RouteInfo): void {
    let navigationModel: NavigationModel;
    for (const navItem of this.myNav) {
      navItem.active = false;
    }
    let navigationId = routeInfo.navigationId;
    if (!navigationId && routeInfo.name === RouteConstants.MY_DASHBOARD.name) {
      navigationId = 'dashboard';
    }
    navigationModel = this.myNav.find((nav) => nav.id === navigationId);

    if (navigationModel) {
      navigationModel.active = true;
    }
  }
}
