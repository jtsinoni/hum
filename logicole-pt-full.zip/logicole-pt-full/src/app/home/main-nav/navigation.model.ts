import {RouteInfo} from '../../constants';
// export interface IState {
//   state: RouteInfo;
// }
//
// export interface INavigationSelection {
//   id: string;
//   icon: string;
//   perm: string;
//   state: RouteInfo;
//   text: string;
//   shown: boolean;
//   dividerFollows?: boolean;
// }

export class NavigationModel {
  public id: string;
  public active: boolean;
  public tooltip: string;
  public icon: string;
  public buttonGroup: string;
  public statesCovered: Array<RouteInfo>;
  public navChoices: Array<RouteInfo>;
}
