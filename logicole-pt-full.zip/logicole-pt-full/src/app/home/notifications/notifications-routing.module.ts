import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';

import {RouteConstants} from '@lc-constants/*';
import {NotificationStates} from './notifications-states';

const notificationsRoutes: RootModule = {
  states: NotificationStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(notificationsRoutes)],
  exports: [UIRouterModule]
})
export class NotificationsRoutingModule {
}
