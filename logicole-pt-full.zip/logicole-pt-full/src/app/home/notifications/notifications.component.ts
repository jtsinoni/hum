import {Component, OnInit, ViewChild} from '@angular/core';
import {LcDataWrapperComponent, LcDataWrapperSettings} from '@lc-common-components';
import {ApplicationNotificationService} from '../../services/application-notification-service';
import {ApplicationNotification} from '../jmlfdc-admin/system-notification/models/application-notification';


@Component({
  selector: 'lc-notifications',
  templateUrl: './notifications.component.html',
  styles: []
})
export class NotificationsComponent implements OnInit {

  constructor(
    public appNotificationService: ApplicationNotificationService,
  ) { }

  public wrapper: LcDataWrapperComponent;
  public notifications: ApplicationNotification[] = [];
  public isLoadingNotifications: boolean = false;

  @ViewChild('notificationsWrapper', { static: true })
  public notificationsWrapper: LcDataWrapperComponent;

  public notificationsListWrapperSettings: LcDataWrapperSettings = {
    id: 'notificationsListWrapper',
    title: 'Notifications',
    filterSettings: {
      fields: [
        'subSystem',
        'name',
        'content'
      ],
      placeholder: 'Filter...'
    },
    paginationSettings: {
      itemsPerPage: 10
    },
    showRefresh: true
  };

  public ngOnInit() {
    this.loadNotifications();
  }

  public notificationsDisplayUpdated(data: any): void {
    this.notifications = data.length ? data : [];
  }

  public loadNotifications(): void {
    this.isLoadingNotifications = true;
    this.appNotificationService.getAllNotifications();
    this.isLoadingNotifications = false;
  }

}
