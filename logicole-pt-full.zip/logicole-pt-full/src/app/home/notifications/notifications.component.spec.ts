import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {NotificationsComponent} from './notifications.component';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {ApplicationNotificationService} from '../../services/application-notification-service';
import {PipesModule} from '../../pipes/pipes.module';
import {ApplicationNotificationServiceMock} from '../../services/application-notification.service.mock';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {LoggerService} from '@lc-logger-service';

describe('NotificationsComponent', () => {
  let component: NotificationsComponent;
  let fixture: ComponentFixture<NotificationsComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [PipesModule.forRoot()],
      declarations: [NotificationsComponent],
      providers: [LoggerService,
        {provide: ApplicationNotificationService, useClass: ApplicationNotificationServiceMock}],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have no a11y violations', waitForAsync(() => {
    a11yTests(fixture.nativeElement)
      .then((results) => {
        expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
      })
      .catch((error) => {
        loggerService.error(`${error}`);
      });
  }));
});
