import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationsComponent } from './notifications.component';
import {NotificationsRoutingModule} from './notifications-routing.module';
import {CommonComponentsModule} from '@lc-common-components';
import {PipesModule} from '../../pipes/pipes.module';

@NgModule({
  declarations: [NotificationsComponent],
  imports: [
    CommonModule,
    NotificationsRoutingModule,
    CommonComponentsModule,
    PipesModule,
  ]

})
export class NotificationsModule { }
