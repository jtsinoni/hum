import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from 'app/constants/route.constants';
import {NotificationsComponent} from './notifications.component';

export const NOTIFICATIONS: Ng2StateDeclaration = {
    url: RouteConstants.NOTIFICATIONS.url,
    name: RouteConstants.NOTIFICATIONS.name,
    component: NotificationsComponent,
    data: {'route': RouteConstants.NOTIFICATIONS}
  };

export const NOTIFICATIONS_ROOT: Ng2StateDeclaration = {
  url: RouteConstants.NOTIFICATIONS_ROOT.url,
  name: RouteConstants.NOTIFICATIONS_ROOT.name,
  component: NotificationsComponent,
  data: {'route': RouteConstants.NOTIFICATIONS_ROOT}
};

export const NotificationStates: Ng2StateDeclaration[] = [
  NOTIFICATIONS,
  NOTIFICATIONS_ROOT
];

