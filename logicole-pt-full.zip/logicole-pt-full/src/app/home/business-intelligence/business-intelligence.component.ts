import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'lc-business-intelligence',
  templateUrl: './business-intelligence.component.html'
})
export class BusinessIntelligenceComponent implements OnInit {

  constructor() {
  }

  public ngOnInit() {
  }
}
