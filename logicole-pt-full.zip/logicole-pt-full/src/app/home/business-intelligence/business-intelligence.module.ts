import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {CommonComponentsModule} from '@lc-common-components';
import {BusinessIntelligenceRoutingModule} from './business-intelligence-routing.module';
import {PipesModule} from '../..//pipes/pipes.module';
import {TreeModule} from '@circlon/angular-tree-component';
import {HttpClientModule} from '@angular/common/http';
import {BusinessIntelligenceComponent} from './business-intelligence.component';
import {BiComponent} from './bi/bi.component';
import {DirectivesModule} from '../../directives/directives.module';

@NgModule({
  imports: [
    BusinessIntelligenceRoutingModule,
    CommonModule,
    CommonComponentsModule,
    DirectivesModule,
    PipesModule.forRoot(),
    TreeModule,
    FormsModule,
    HttpClientModule
  ],
  declarations: [
    BusinessIntelligenceComponent,
    BiComponent
  ]
})
export class BusinessIntelligenceModule {
}

