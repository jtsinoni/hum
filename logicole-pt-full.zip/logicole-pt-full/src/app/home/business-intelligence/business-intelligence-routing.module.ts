import {RootModule, UIRouterModule} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {NgModule} from '@angular/core';
import {BusinessIntelligenceStates} from './business-intelligence-states';

const businessIntelligenceRoutes: RootModule = {
  states: BusinessIntelligenceStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(businessIntelligenceRoutes)],
  exports: [UIRouterModule],
})

export class BusinessIntelligenceRoutingModule {
}
