import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {BusinessIntelligenceComponent} from './business-intelligence.component';
import {BiComponent} from './bi/bi.component';


export const BUSINESS_INTELLIGENCE_ROOT: Ng2StateDeclaration = {
  url: RouteConstants.BUSINESS_INTELLIGENCE_ROOT.url,
  name: RouteConstants.BUSINESS_INTELLIGENCE_ROOT.name,
  component: BusinessIntelligenceComponent,
  data: {'route': RouteConstants.BUSINESS_INTELLIGENCE_ROOT}
};

export const BUSINESS_INTELLIGENCE: Ng2StateDeclaration = {
  url: RouteConstants.BUSINESS_INTELLIGENCE.url,
  name: RouteConstants.BUSINESS_INTELLIGENCE.name,
  component: BiComponent,
  data: {'route': RouteConstants.BUSINESS_INTELLIGENCE}
};

export const BusinessIntelligenceStates: Ng2StateDeclaration[] = [
  BUSINESS_INTELLIGENCE_ROOT,
  BUSINESS_INTELLIGENCE
];
