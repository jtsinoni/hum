import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {LoggerService} from '@lc-logger-service';
import {BusinessIntelligenceComponent} from './business-intelligence.component';
import {UIRouterModule} from '@uirouter/angular';
import {runA11yTests} from '../../spec-helper/a11y-tests.spec';

describe('BusinessIntelligenceComponent', () => {
  let component: BusinessIntelligenceComponent;
  let fixture: ComponentFixture<BusinessIntelligenceComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        UIRouterModule.forRoot()
      ],
      declarations: [
        BusinessIntelligenceComponent
      ],
      providers: [
        LoggerService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessIntelligenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      runA11yTests(fixture.nativeElement, loggerService);
    }));
  });
});
