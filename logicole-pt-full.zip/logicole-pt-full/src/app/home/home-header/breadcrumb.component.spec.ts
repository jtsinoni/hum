import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {BreadcrumbComponent} from './breadcrumb.component';
import {LoggerService, LoginService} from '@lc-services/*';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {StateRegistry, UIRouter} from '@uirouter/core/lib';
import {CommonComponentsModule} from '@lc-common-components';
import {BreadcrumbService} from '../../services/breadcrumb.service';
import {HttpTestModule, NavigationTestModule} from '@lc-test-modules';
import {UIRouterModule} from '@uirouter/angular';
import {UtilService} from '../../services/util.service';
import {runA11yTests} from '../../spec-helper/a11y-tests.spec';
import {LoginServiceMock} from '../../services/core/login.service.mock';
import {BusinessIntelligenceService} from '../../services/business-intelligence.service';
import {BusinessIntelligenceServiceMock} from '../../services/business-intelligence.service.mock';
import { CurrencyPipe } from '@angular/common';
import {UtilServiceMock} from '../../services/util.service.mock';

describe('BreadcrumbComponent', () => {
  let component: BreadcrumbComponent;
  let fixture: ComponentFixture<BreadcrumbComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [CommonComponentsModule, NavigationTestModule.forRoot(), UIRouterModule,  HttpTestModule],
      declarations: [BreadcrumbComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [LoggerService, BreadcrumbService, CurrencyPipe,
        {provide:  UtilService, useClass: UtilServiceMock},
        {provide: LoginService, useClass: LoginServiceMock},
        {provide: BusinessIntelligenceService, useClass: BusinessIntelligenceServiceMock},
        {
        provide: StateRegistry, useClass:
          class {
            public mockStateRegistry = new StateRegistry(new UIRouter());
          }
      }]

    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`breadcrumbs array should be undefined`, waitForAsync(() => {
    const breadcrumbComponent = fixture.debugElement.componentInstance;
    expect(breadcrumbComponent.breadcrumbs).toBeUndefined();
  }));

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      runA11yTests(fixture.nativeElement, loggerService);
    }));
  });
});
