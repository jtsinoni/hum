import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';

import {ApplicationNotificationsComponent} from './application-notifications.component';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {LoggerService} from '@lc-logger-service';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {PipesModule} from '../../pipes/pipes.module';
import {StateNavigationService} from '../../services/state-navigation.service';
import {StateNavigationServiceMock} from '../../services/state-navigation.service.mock';
import {ApplicationNotificationService} from '../../services/application-notification-service';
import {ApplicationNotificationServiceMock} from '../../services/application-notification.service.mock';

describe('ApplicationNotificationsComponent', () => {
  let component: ApplicationNotificationsComponent;
  let fixture: ComponentFixture<ApplicationNotificationsComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ApplicationNotificationsComponent],
      imports: [PipesModule.forRoot()],
      providers: [LoggerService,
        {provide: StateNavigationService, useClass: StateNavigationServiceMock},
        {provide: ApplicationNotificationService, useClass: ApplicationNotificationServiceMock}],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationNotificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have no a11y violations', waitForAsync(() => {
    a11yTests(fixture.nativeElement)
      .then((results) => {
        expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
      })
      .catch((error) => {
        loggerService.error(`${error}`);
      });
  }));
});
