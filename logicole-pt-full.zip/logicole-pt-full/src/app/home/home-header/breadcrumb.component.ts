import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {BreadcrumbService} from '../../services/breadcrumb.service';
import {LoginService, NotificationService} from '@lc-services/*';
import {UtilService} from '../../services/util.service';
import {Subject} from 'rxjs';

@Component({
  selector: 'lc-breadcrumb',
  templateUrl: './breadcrumb.component.html'
})
export class BreadcrumbComponent implements OnInit {
  private destroy$: Subject<boolean> = new Subject<boolean>();

  @ViewChild('mainLinkElement', { read: ElementRef, static: false })
  public mainLinkElement: ElementRef;

  constructor(
    public breadcrumbService: BreadcrumbService,
    private loginService: LoginService,
    private utilService: UtilService
  ) {}

  public ngOnInit() {
    this.subscribeToEvents();
  }

  private subscribeToEvents() {
    this.utilService.subscribeToRefresh(this.destroy$,
      this.loginService.jumpToMain$,
      this.jumpToMainContent.bind(this));
  }

  private jumpToMainContent(){
    setTimeout(() => this.mainLinkElement.nativeElement.focus(), 0);
  }

}

