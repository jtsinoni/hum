import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';

import {HomeHeaderComponent} from './home-header.component';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {LoggerService, LoginService, NotificationService, ProfileApiService, ProfileService, StateNavigationService} from '@lc-services/*';
import {MainNavService} from '../main-nav/main-nav.service';
import {StateRegistry, UIRouter} from '@uirouter/core/lib';
import {FilterOnPipe} from '../../pipes/filter-on.pipe';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {HelpCenterService} from '../help/help-center/help-center.service';
import {NotificationServiceMock} from '../../services/core/notification.service.mock';
import {HelpCenterServiceMock} from '../help/help-center/help-center.service.mock';
import {ProfileApiServiceMock} from '../../services/core/profile-api.service.mock';
import {StateNavigationServiceMock} from '../../services/state-navigation.service.mock';
import {ApplicationNotificationService} from '../../services/application-notification-service';
import {ApplicationNotificationServiceMock} from '../../services/application-notification.service.mock';
import {LoginServiceMock} from '../../services/core/login.service.mock';
import {FormsModule} from '@angular/forms';
import {PipesModule} from '../../pipes/pipes.module';
import {UIRouterModule} from '@uirouter/angular';
import {ProfileServiceMock} from '../../services/core/profile.service.mock';
import {PermissionService} from '../../services/permission.service';
import {PermissionServiceMock} from '../../services/permission.service.mock';
import {HttpTestModule} from '@lc-test-modules';

describe('HomeHeaderComponent', () => {
  let component: HomeHeaderComponent;
  let fixture: ComponentFixture<HomeHeaderComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [HttpTestModule.forRoot(),
        FormsModule,
        PipesModule.forRoot(),
        UIRouterModule.forRoot()],
      declarations: [HomeHeaderComponent],
      providers: [LoggerService, MainNavService,
        NotificationService, FilterOnPipe,
        {
          provide:
          StateRegistry, useClass:
            class {
              public mockStateRegistry = new StateRegistry(new UIRouter());
            }
        },
        {provide: NotificationService, useClass: NotificationServiceMock},
        {provide: HelpCenterService, useClass: HelpCenterServiceMock},
        {provide: ProfileService, useClass: ProfileServiceMock},
        {provide: PermissionService, useClass: PermissionServiceMock},
        {provide: ProfileApiService, useClass: ProfileApiServiceMock},
        {provide: StateNavigationService, useClass: StateNavigationServiceMock},
        {provide: ApplicationNotificationService, useClass: ApplicationNotificationServiceMock},
        {provide: LoginService, useClass: LoginServiceMock}

      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have no a11y violations', waitForAsync(() => {
    a11yTests(fixture.nativeElement)
      .then((results) => {
        expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
      })
      .catch((error) => {
        loggerService.error(`${error}`);
      });
  }));
});
