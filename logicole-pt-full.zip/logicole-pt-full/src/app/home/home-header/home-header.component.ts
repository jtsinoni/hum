import {Component, OnInit} from '@angular/core';
import {LoggerService, LoginService, NotificationService, ProfileService, StateNavigationService} from '@lc-services/*';
import {ElementConstants, RouteConstants} from '@lc-constants/*';
import {ChangeProfileAccessComponent} from 'app/common-components/dropdown/change-profile-access.component';
import {CartService} from '../order/cart/services/cart.service';
import {HelpCenterService} from '../help/help-center/help-center.service';
import {ApplicationNotificationService} from '../../services/application-notification-service';
import {UtilService} from '../../services/util.service';
import {takeUntil} from 'rxjs/operators';
import {PermissionService} from '../../services/permission.service';

@Component({
  selector: 'app-home-header',
  templateUrl: './home-header.component.html',
})
export class HomeHeaderComponent extends ChangeProfileAccessComponent implements OnInit {

  public myProfilePage = RouteConstants.MY_PROFILE.name;
  public serviceRequestsPage = RouteConstants.SERVICE_REQUEST_SEARCH.name;
  public aboutPage = RouteConstants.ABOUT.name;

  constructor(
    private loginService: LoginService,
    protected logger: LoggerService,
    public profileService: ProfileService,
    protected navigationService: StateNavigationService,
    protected permissionService: PermissionService,
    private utilService: UtilService,
    private notificationService: NotificationService,
    public cartService: CartService,
    public applicationNotificationService: ApplicationNotificationService,
    private helpCenterService: HelpCenterService) {
    super(logger, profileService, navigationService, permissionService);
  }

  public goToCart(): void {
    this.navigationService.navigateToState(RouteConstants.ORDER_CART, true);
  }

  public ngOnInit() {
    this.profileService.initSignedInProfile()
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        this.profileService.hasServiceRequestPermission = this.permissionService.checkElements(ElementConstants.SERVICE_REQUESTS_HEADER);
      });
  }

  public logout(): void {
    this.loginService.logout().subscribe(() => {
      this.navigationService.navigateToState(RouteConstants.LOGIN, true).then(() => {
        this.notificationService.successMsg('Logged Out.');
      });
    });
  }

  public isCurrentState(): boolean {
    return this.navigationService.isCurrentState(RouteConstants.ORDER_CART.name);
  }

  public goToHelp(standAlone: boolean): void {
    this.helpCenterService.openHelp(standAlone);
  }

  public goToNotifications(): void {
    this.navigationService.navigateToState(RouteConstants.NOTIFICATIONS_VIEW);
  }

  public goToAbout(): void {
    this.navigationService.navigateToState(RouteConstants.ABOUT);
  }

  public toggleUnreadNotifications() {
    this.applicationNotificationService.toggleUnreadNotifications();
  }

  public goToMainContent(){
    this.loginService.mockCall().subscribe(result => {
      this.loginService.jumpToMain$.next(true);
    });
  }

}
