import {Component, OnInit} from '@angular/core';
import {ApplicationNotificationService} from '../../services/application-notification-service';
import {RouteConstants, RouteInfo} from '../../constants';
import {StateNavigationService} from '../../services/state-navigation.service';

@Component({
  selector: 'application-notifications',
  templateUrl: './application-notifications.component.html'
})
export class ApplicationNotificationsComponent implements OnInit {

  constructor(public appNotificationService: ApplicationNotificationService,
              protected navigationService: StateNavigationService) {
  }

  public accessManagementRoute: RouteInfo = RouteConstants.ACCESS_PROFILE_MANAGEMENT;
  public loadingNotifications: boolean;

  public ngOnInit(): void {
    this.appNotificationService.getUnreadNotificationCount();
  }

  public goTo(route: RouteInfo) {
    // Not ready yet
    // this.navigationService.navigateToState(route);
  }

}
