import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {FinanceComponent} from './finance.component';
import {FinanceRoutingModule} from './finance-routing.module';
import {RefDataSearchModule} from './ref-data-search/ref-data-search.module';
import {CommonComponentsModule} from '@lc-common-components';
import {FinancePipesModule} from './pipes/finance-pipes.module';
import {AppropriationAddComponent} from './appropriation-add/appropriation-add.component';
import {FinanceDetailComponent} from './detail/detail.component';
import {FundingChildAddComponent} from './funding-child-add/funding-child-add.component';
import {FundingChildViewEditComponent} from './funding-child-view-edit/funding-child-view-edit.component';
import {PipesModule} from '../../pipes/pipes.module';
import {FinanceAdminService} from './services/finance-admin.service';
import {FinanceCommonComponentsModule} from './common-components/finance-common-components.module';
import {LoggerService} from '@lc-logger-service';
import {FundingNodeAddEditComponent} from './funding-node-add-edit/funding-node-add-edit.component';
import {FundingSearchComponent} from './funding-search/funding-search.component';
import {FundingSourceSearchComponent} from './funding-source-search/funding-source-search.component';
import {FundingSourceContinuationComponent} from './funding-source-continuation/funding-source-continuation.component';
import {PurchaseCardsComponent} from './purchase-cards/purchase-cards.component';
import {PurchaseCardNewComponent} from './purchase-card-new/purchase-card-new.component';
import {PurchaseCardDetailsComponent} from './purchase-card-details/purchase-card-details.component';
import {PurchaseCardReconciliationDetailsComponent} from './purchase-card-reconciliation-details/purchase-card-reconciliation-details.component';
import {PurchaseCardReconciliationHistoryComponent} from './purchase-card-register-history/purchase-card-reconciliation-history.component';
import {PurchaseCardCcValidationComponent} from './common/purchase-card-cc-validation/purchase-card-cc-validation.component';
import {DirectivesModule} from '../../directives/directives.module';
import {FinanceReferenceDataApiService} from './services/finance-reference-data-api.service';
import { FundingRolloverComponent } from './funding-rollover/funding-rollover.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule,
    FinanceCommonComponentsModule,
    FinanceRoutingModule,
    PipesModule,
    RefDataSearchModule, // TODO remove when ag-grid is gone
    FinancePipesModule.forRoot(),
    DirectivesModule
  ],
  declarations: [
    AppropriationAddComponent,
    FinanceComponent,
    FinanceDetailComponent,
    FundingChildAddComponent,
    FundingChildViewEditComponent,
    FundingNodeAddEditComponent,
    FundingSearchComponent,
    FundingSourceSearchComponent,
    FundingSourceContinuationComponent,
    PurchaseCardsComponent,
    PurchaseCardNewComponent,
    PurchaseCardDetailsComponent,
    PurchaseCardReconciliationDetailsComponent,
    PurchaseCardReconciliationHistoryComponent,
    PurchaseCardCcValidationComponent,
    FundingRolloverComponent,
  ],
  exports: [
    AppropriationAddComponent,
    FinanceComponent,
    FinanceDetailComponent,
    FundingChildAddComponent,
    FundingChildViewEditComponent,
    FundingNodeAddEditComponent,
    FundingSearchComponent,
    FundingSourceSearchComponent,
    FundingSourceContinuationComponent,
    RefDataSearchModule,
  ],
  providers: [FinanceAdminService, FinanceReferenceDataApiService]
})
export class FinanceModule {
  constructor(private logger: LoggerService) {
    this.logger.debug('In Finance module ####');
  }
}
