import {Ng2StateDeclaration} from '@uirouter/angular';
import {FinanceComponent} from './finance.component';
import {RouteConstants} from '@lc-constants/*';
import {FundingSearchComponent} from './funding-search/funding-search.component';
import {FundingSourceSearchComponent} from './funding-source-search/funding-source-search.component';
import {RefDataSearchComponent} from './ref-data-search/ref-data-search.component';
import {FinanceDetailComponent} from './detail/detail.component';
import {AppropriationAddComponent} from './appropriation-add/appropriation-add.component';
import {FundingChildViewEditComponent} from './funding-child-view-edit/funding-child-view-edit.component';
import {FundingNodeAddEditComponent} from './funding-node-add-edit/funding-node-add-edit.component';
import {FundingChildAddComponent} from './funding-child-add/funding-child-add.component';
import {FundingSourceContinuationComponent} from './funding-source-continuation/funding-source-continuation.component';
import {PurchaseCardsComponent} from './purchase-cards/purchase-cards.component';
import {PurchaseCardNewComponent} from './purchase-card-new/purchase-card-new.component';
import {PurchaseCardDetailsComponent} from './purchase-card-details/purchase-card-details.component';
import {PurchaseCardReconciliationDetailsComponent} from './purchase-card-reconciliation-details/purchase-card-reconciliation-details.component';
import {RefDataListComponent} from './ref-data-search/components/ref-data-list/ref-data-list.component';
import {RefDataCollectionNames} from './enums/ref-data-collection-names.enum';
import {Transition} from '@uirouter/core';
import {FundingRolloverComponent} from './funding-rollover/funding-rollover.component';

export const FINANCE_ROOT: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_ROOT.url,
  name: RouteConstants.FINANCE_ROOT.name,
  component: FinanceComponent, data: {'route': RouteConstants.FINANCE_ROOT}
};

export const FINANCE_FUNDING_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_SEARCH.url,
  name: RouteConstants.FINANCE_FUNDING_SEARCH.name,
  component: FundingSearchComponent, data: {'route': RouteConstants.FINANCE_FUNDING_SEARCH}
};

export const FINANCE_FUNDING_SOURCE_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_SOURCE_SEARCH.url,
  name: RouteConstants.FINANCE_FUNDING_SOURCE_SEARCH.name,
  component: FundingSourceSearchComponent, data: {'route': RouteConstants.FINANCE_FUNDING_SOURCE_SEARCH}
};

export const FINANCE_REF_DATA_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_SEARCH.url,
  name: RouteConstants.FINANCE_REF_DATA_SEARCH.name,
  component: RefDataSearchComponent, data: {'route': RouteConstants.FINANCE_REF_DATA_SEARCH}
};

export const FINANCE_REF_DATA_ACCOUNTING_CLASSIFICATION: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_ACCOUNTING_CLASSIFICATION.url,
  name: RouteConstants.FINANCE_REF_DATA_ACCOUNTING_CLASSIFICATION.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_ACCOUNTING_CLASSIFICATION},
  params: {
    'collectionName': RefDataCollectionNames.ACCOUNTING_CLASSIFICATION,
    'defaultSortField': 'code',
    'title': 'Accounting Classification'
  }};

export const FINANCE_ROLLOVER: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_ROLLOVER.url,
  name: RouteConstants.FINANCE_ROLLOVER.name,
  component: FundingRolloverComponent, data: {'route': RouteConstants.FINANCE_ROLLOVER}
};

export const FINANCE_REF_DATA_BILLED_SERVICE_CODE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_BILLED_SERVICE_CODE.url,
  name: RouteConstants.FINANCE_REF_DATA_BILLED_SERVICE_CODE.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_BILLED_SERVICE_CODE},
  params: {
    'collectionName': RefDataCollectionNames.BILLED_SERVICE_CODE,
    'defaultSortField': 'code',
    'title': 'Billed Service Code'
  }};

export const FINANCE_REF_DATA_BUDGET_LINE_ITEM: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_BUDGET_LINE_ITEM.url,
  name: RouteConstants.FINANCE_REF_DATA_BUDGET_LINE_ITEM.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_BUDGET_LINE_ITEM},
  params: {
    'collectionName': RefDataCollectionNames.BUDGET_LINE_ITEM,
    'defaultSortField': 'code',
    'title': 'Budget Line Item'
  }
};

export const FINANCE_REF_DATA_COMMODTTY_CODE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_COMMODITY_CODE.url,
  name: RouteConstants.FINANCE_REF_DATA_COMMODITY_CODE.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_COMMODITY_CODE},
  params: {
    'collectionName': RefDataCollectionNames.COMMODITY_CODE,
    'defaultSortField': 'code',
    'title': 'Commodity Code'
  }
};

export const FINANCE_REF_DATA_COST_CENTER: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_COST_CENTER.url,
  name: RouteConstants.FINANCE_REF_DATA_COST_CENTER.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_COST_CENTER},
  params: {
    'collectionName': RefDataCollectionNames.COST_CENTER,
    'defaultSortField': 'code',
    'title': 'Cost Center'
  }
};

export const FINANCE_REF_DATA_FINANCIAL_SYSTEM: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_FINANCIAL_SYSTEM.url,
  name: RouteConstants.FINANCE_REF_DATA_FINANCIAL_SYSTEM.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_FINANCIAL_SYSTEM},
  params: {
    'collectionName': RefDataCollectionNames.FINANCIAL_SYSTEM,
    'defaultSortField': 'name',
    'title': 'Financial System'
  }
};

export const FINANCE_REF_DATA_FOREIGN_CURRENCY: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_FOREIGN_CURRENCY.url,
  name: RouteConstants.FINANCE_REF_DATA_FOREIGN_CURRENCY.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_FOREIGN_CURRENCY},
  params: {
    'collectionName': RefDataCollectionNames.FOREIGN_CURRENCY,
    'defaultSortField': 'code',
    'title': 'Foreign Currency'
  }
};

export const FINANCE_REF_DATA_FUND_CODE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_FUND_CODE.url,
  name: RouteConstants.FINANCE_REF_DATA_FUND_CODE.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_FUND_CODE},
  params: {
    'collectionName': RefDataCollectionNames.FUND_CODE,
    'defaultSortField': 'name',
    'title': 'Fund Code'
  }
};

export const FINANCE_REF_DATA_FUND_IDENTIFICATION: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_FUND_IDENTIFICATION.url,
  name: RouteConstants.FINANCE_REF_DATA_FUND_IDENTIFICATION.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_FUND_IDENTIFICATION},
  params: {
    'collectionName': RefDataCollectionNames.FUND_IDENTIFICATION,
    'defaultSortField': 'name',
    'title': 'Fund Identification'
  }
};

export const FINANCE_REF_DATA_FUND_USAGE_TYPE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_FUND_USAGE_TYPE.url,
  name: RouteConstants.FINANCE_REF_DATA_FUND_USAGE_TYPE.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_FUND_USAGE_TYPE},
  params: {
    'collectionName': RefDataCollectionNames.FUND_USAGE_TYPE,
    'defaultSortField': 'name',
    'title': 'Fund Usage Type'
  }
};

export const FINANCE_REF_DATA_LINE_OF_ACCOUNTING_TEMPLATE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_LINE_OF_ACCOUNTING_TEMPLATE.url,
  name: RouteConstants.FINANCE_REF_DATA_LINE_OF_ACCOUNTING_TEMPLATE.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_MAIN_ACCOUNT_CODE},
  params: {
    'collectionName': RefDataCollectionNames.LINE_OF_ACCOUNTING_TEMPLATE,
    'defaultSortField': 'code',
    'title': 'Line of Accounting Template'
  }
};

export const FINANCE_REF_DATA_MAIN_ACCOUNT_CODE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_MAIN_ACCOUNT_CODE.url,
  name: RouteConstants.FINANCE_REF_DATA_MAIN_ACCOUNT_CODE.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_MAIN_ACCOUNT_CODE},
  params: {
    'collectionName': RefDataCollectionNames.MAIN_ACCOUNT_CODE,
    'defaultSortField': 'code',
    'title': 'Main Account Code'
  }
};

export const FINANCE_REF_DATA_MAIN_ACCOUNT_TYPE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_MAIN_ACCOUNT_TYPE.url,
  name: RouteConstants.FINANCE_REF_DATA_MAIN_ACCOUNT_TYPE.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_MAIN_ACCOUNT_TYPE},
  params: {
    'collectionName': RefDataCollectionNames.MAIN_ACCOUNT_TYPE,
    'defaultSortField': 'code',
    'title': 'Main Account Type'
  }
};

export const FINANCE_REF_DATA_MAIN_ACCOUNT_TEMPLATE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_MAIN_ACCOUNT_TEMPLATE.url,
  name: RouteConstants.FINANCE_REF_DATA_MAIN_ACCOUNT_TEMPLATE.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_MAIN_ACCOUNT_TEMPLATE},
  params: {
    'collectionName': RefDataCollectionNames.MAIN_ACCOUNT_TEMPLATE,
    'defaultSortField': 'mainAccountRef.code',
    'title': 'Main Account Template'
  }
};

export const FINANCE_REF_DATA_SALES_CODE_TYPE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_SALES_CODE_TYPE.url,
  name: RouteConstants.FINANCE_REF_DATA_SALES_CODE_TYPE.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_SALES_CODE_TYPE},
  params: {
    'collectionName': RefDataCollectionNames.SALES_CODE_TYPE,
    'defaultSortField': 'code',
    'title': 'Sales Code Type'
  }
};

export const FINANCE_REF_DATA_SUB_ALLOCATION_HOLDER: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_SUB_ALLOCATION_HOLDER.url,
  name: RouteConstants.FINANCE_REF_DATA_SUB_ALLOCATION_HOLDER.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_SUB_ALLOCATION_HOLDER},
  params: {
    'collectionName': RefDataCollectionNames.SUB_ALLOCATION_HOLDER,
    'defaultSortField': 'code',
    'title': 'Sub Allocation Holder'
  }
};

export const FINANCE_REF_DATA_SUB_CLASS: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_SUB_CLASS.url,
  name: RouteConstants.FINANCE_REF_DATA_SUB_CLASS.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_SUB_CLASS},
  params: {
    'collectionName': RefDataCollectionNames.SUB_CLASS,
    'defaultSortField': 'code',
    'title': 'Sub Class'
  }
};

export const FINANCE_REF_DATA_TREASURY_DEPARTMENT: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_REF_DATA_TREASURY_DEPARTMENT.url,
  name: RouteConstants.FINANCE_REF_DATA_TREASURY_DEPARTMENT.name,
  component: RefDataListComponent,
  data: {'route': RouteConstants.FINANCE_REF_DATA_TREASURY_DEPARTMENT},
  params: {
    'collectionName': RefDataCollectionNames.TREASURY_DEPARTMENT,
    'defaultSortField': 'code',
    'title': 'Treasury Department'
  }
};


export const FINANCE_DETAIL: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_DETAIL.url,
  name: RouteConstants.FINANCE_DETAIL.name,
  component: FinanceDetailComponent, data: {'route': RouteConstants.FINANCE_DETAIL},
  params: {
    'fundingNodesFundingNodeId': null,
    'fundingSourceId': null,
  },
  resolve: [
    {
      token: 'fundingSourceId',
      deps: [Transition],
      resolveFn: (transition: Transition) => transition.params().fundingSourceId,
    },
    {
      token: 'fundingNodesFundingNodeId',
      deps: [Transition],
      resolveFn: (transition: Transition) => transition.params().fundingNodesFundingNodeId,
    },
  ]
};

export const FINANCE_FUNDING_SOURCE_ADD: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_SOURCE_ADD.url,
  name: RouteConstants.FINANCE_FUNDING_SOURCE_ADD.name,
  component: AppropriationAddComponent, data: {'route': RouteConstants.FINANCE_FUNDING_SOURCE_ADD},
  params: {
    'fundingSourceId': null,
    'isEditing': null,
  },
  resolve: [
    {
      token: 'fundingSourceId',
      deps: [Transition],
      resolveFn: (transition: Transition) => transition.params().fundingSourceId,
    },
    {
      token: 'isEditing',
      deps: [Transition],
      resolveFn: (transition: Transition) => transition.params().isEditing,
    },
  ]
};

export const FINANCE_FUNDING_CHILD_EDIT: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_CHILD_EDIT.url,
  name: RouteConstants.FINANCE_FUNDING_CHILD_EDIT.name,
  component: FundingChildViewEditComponent, data: {'route': RouteConstants.FINANCE_FUNDING_CHILD_EDIT},
  params: {
    'fundingSourceId': null,
    'fundingNodeId': null,
    'editing': true,
  }
};

export const FINANCE_FUNDING_NODE_ADD: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_NODE_ADD.url,
  name: RouteConstants.FINANCE_FUNDING_NODE_ADD.name,
  component: FundingNodeAddEditComponent, data: {'route': RouteConstants.FINANCE_FUNDING_NODE_ADD},
  params: {
    'fundingSourceId': null,
    'fundingNodeId': null,
  }
};

export const FINANCE_FUNDING_CHILD_ADD: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_CHILD_ADD.url,
  name: RouteConstants.FINANCE_FUNDING_CHILD_ADD.name,
  component: FundingChildAddComponent, data: {'route': RouteConstants.FINANCE_FUNDING_CHILD_ADD},
  params: {
    'fundingSourceId': null,
    'fundingNodeId': null,
  }
};

export const FINANCE_FUNDING_SOURCE_DETAIL: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_SOURCE_DETAIL.url,
  name: RouteConstants.FINANCE_FUNDING_SOURCE_DETAIL.name,
  component: FinanceDetailComponent, data: {'route': RouteConstants.FINANCE_FUNDING_SOURCE_DETAIL},
  params: {
    'fundingNodesFundingNodeId': null,
    'fundingSourceId': null,
  },
  resolve: [
    {
      token: 'fundingSourceId',
      deps: [Transition],
      resolveFn: (transition: Transition) => transition.params().fundingSourceId,
    },
  ]
};

export const FINANCE_FUNDING_SOURCE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_SOURCE.url,
  name: RouteConstants.FINANCE_FUNDING_SOURCE.name,
  component: AppropriationAddComponent, data: {'route': RouteConstants.FINANCE_FUNDING_SOURCE},
  params: {
    'fundingSourceId': null,
    'isEditing': null,
  },
  resolve: [
    {
      token: 'fundingSourceId',
      deps: [Transition],
      resolveFn: (transition: Transition) => transition.params().fundingSourceId,
    },
    {
      token: 'isEditing',
      deps: [Transition],
      resolveFn: (transition: Transition) => transition.params().isEditing,
    },
  ]
};

export const FINANCE_FUNDING_SOURCE_EDIT: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_SOURCE_EDIT.url,
  name: RouteConstants.FINANCE_FUNDING_SOURCE_EDIT.name,
  component: AppropriationAddComponent, data: {'route': RouteConstants.FINANCE_FUNDING_SOURCE_EDIT},
  params: {
    'fundingSourceId': null,
    'isEditing': null,
  },
  resolve: [
    {
      token: 'fundingSourceId',
      deps: [Transition],
      resolveFn: (transition: Transition) => transition.params().fundingSourceId,
    },
    {
      token: 'isEditing',
      deps: [Transition],
      resolveFn: (transition: Transition) => transition.params().isEditing,
    },
  ]
};

export const FINANCE_CONTINUING_RESOLUTION: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_CONTINUING_RESOLUTION.url,
  name: RouteConstants.FINANCE_CONTINUING_RESOLUTION.name,
  component: FundingSourceContinuationComponent, data: {'route': RouteConstants.FINANCE_CONTINUING_RESOLUTION}
};

export const FINANCE_FUNDING_SOURCE_FUNDING_CHILD: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_SOURCE_FUNDING_CHILD.url,
  name: RouteConstants.FINANCE_FUNDING_SOURCE_FUNDING_CHILD.name,
  component: FundingChildViewEditComponent, data: {'route': RouteConstants.FINANCE_FUNDING_SOURCE_FUNDING_CHILD},
  params: {
    'fundingSourceId': null,
    'fundingNodeId': null,
    'editing': false,
  }
};

export const FINANCE_FUNDING_SOURCE_FUNDING_NODE: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_SOURCE_FUNDING_NODE.url,
  name: RouteConstants.FINANCE_FUNDING_SOURCE_FUNDING_NODE.name,
  component: FundingNodeAddEditComponent, data: {'route': RouteConstants.FINANCE_FUNDING_SOURCE_FUNDING_NODE},
  params: {
    'fundingSourceId': null,
    'fundingNodeId': null,
  }
};

export const FINANCE_FUNDING_SOURCE_FUNDING_CHILD_ADD: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_FUNDING_SOURCE_FUNDING_CHILD_ADD.url,
  name: RouteConstants.FINANCE_FUNDING_SOURCE_FUNDING_CHILD_ADD.name,
  component: FundingChildAddComponent, data: {'route': RouteConstants.FINANCE_FUNDING_SOURCE_FUNDING_CHILD_ADD},
  params: {
    'fundingSourceId': null,
    'fundingNodeId': null,
  }
};

export const FINANCE_PURCHASE_CARDS: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_PURCHASE_CARDS.url,
  name: RouteConstants.FINANCE_PURCHASE_CARDS.name,
  component: PurchaseCardsComponent, data: {'route': RouteConstants.FINANCE_PURCHASE_CARDS}
};

export const FINANCE_PURCHASE_CARD_NEW: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_PURCHASE_CARD_NEW.url,
  name: RouteConstants.FINANCE_PURCHASE_CARD_NEW.name,
  component: PurchaseCardNewComponent, data: {'route': RouteConstants.FINANCE_PURCHASE_CARD_NEW}
};

export const FINANCE_PURCHASE_CARD_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_PURCHASE_CARD_DETAILS.url,
  name: RouteConstants.FINANCE_PURCHASE_CARD_DETAILS.name,
  component: PurchaseCardDetailsComponent, data: {'route': RouteConstants.FINANCE_PURCHASE_CARD_DETAILS},
  params: {
    'id': null,
    'purchaseCard': null,
    'edit': false,
  }
};

export const FINANCE_PURCHASE_CARD_RECONCILIATION_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.FINANCE_PURCHASE_CARD_RECONCILIATION_DETAILS.url,
  name: RouteConstants.FINANCE_PURCHASE_CARD_RECONCILIATION_DETAILS.name,
  component: PurchaseCardReconciliationDetailsComponent,
  data: {'route': RouteConstants.FINANCE_PURCHASE_CARD_RECONCILIATION_DETAILS},
  params: {
    'id': null,
    'purchaseCard': null,
  }
};

export const FinanceStates: Ng2StateDeclaration[] = [
  FINANCE_ROOT,
  FINANCE_FUNDING_SEARCH,
  FINANCE_FUNDING_SOURCE_SEARCH,
  FINANCE_REF_DATA_SEARCH,
  FINANCE_REF_DATA_ACCOUNTING_CLASSIFICATION,
  FINANCE_REF_DATA_BILLED_SERVICE_CODE,
  FINANCE_REF_DATA_BUDGET_LINE_ITEM,
  FINANCE_REF_DATA_COMMODTTY_CODE,
  FINANCE_REF_DATA_COST_CENTER,
  FINANCE_REF_DATA_FINANCIAL_SYSTEM,
  FINANCE_REF_DATA_FOREIGN_CURRENCY,
  FINANCE_REF_DATA_FUND_CODE,
  FINANCE_REF_DATA_FUND_IDENTIFICATION,
  FINANCE_REF_DATA_FUND_USAGE_TYPE,
  FINANCE_REF_DATA_LINE_OF_ACCOUNTING_TEMPLATE,
  FINANCE_REF_DATA_MAIN_ACCOUNT_CODE,
  FINANCE_REF_DATA_MAIN_ACCOUNT_TYPE,
  FINANCE_REF_DATA_MAIN_ACCOUNT_TEMPLATE,
  FINANCE_REF_DATA_SALES_CODE_TYPE,
  FINANCE_REF_DATA_SUB_ALLOCATION_HOLDER,
  FINANCE_REF_DATA_SUB_CLASS,
  FINANCE_REF_DATA_TREASURY_DEPARTMENT,
  FINANCE_DETAIL,
  FINANCE_FUNDING_SOURCE_ADD,
  FINANCE_FUNDING_CHILD_EDIT,
  FINANCE_FUNDING_NODE_ADD,
  FINANCE_FUNDING_CHILD_ADD,
  FINANCE_FUNDING_SOURCE_DETAIL,
  FINANCE_FUNDING_SOURCE,
  FINANCE_FUNDING_SOURCE_EDIT,
  FINANCE_CONTINUING_RESOLUTION,
  FINANCE_FUNDING_SOURCE_FUNDING_CHILD,
  FINANCE_FUNDING_SOURCE_FUNDING_NODE,
  FINANCE_FUNDING_SOURCE_FUNDING_CHILD_ADD,
  FINANCE_PURCHASE_CARDS,
  FINANCE_PURCHASE_CARD_NEW,
  FINANCE_PURCHASE_CARD_DETAILS,
  FINANCE_PURCHASE_CARD_RECONCILIATION_DETAILS,
  FINANCE_ROLLOVER,
];
