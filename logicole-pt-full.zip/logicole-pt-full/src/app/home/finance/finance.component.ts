import {Component, OnInit} from '@angular/core';
import { FinanceDashboardService } from './services/finance-dashboard.service';
import {FinanceAdminService} from './services/finance-admin.service';
import {LoggerService, StateNavigationService} from '@lc-services/*';
import {RouteConstants} from '@lc-constants/*';

@Component({
  selector: 'lc-finance',
  templateUrl: './finance.component.html'
})
export class FinanceComponent implements OnInit {

  constructor(private logger: LoggerService,
              private navigationService: StateNavigationService,
              public financeDashboardService: FinanceDashboardService,
              public financeAdminService: FinanceAdminService) { }

  public ngOnInit() {
    this.financeDashboardService.getFinanceDashboardStats();
  }

  public isActionable(newClass: string, count: number){
    let useClass: string = 'badge-dark';
    if (count > 0){
      useClass = newClass;
    }
    return useClass;
  }

  public canSearchFunds(): boolean {
    const canSearchFunds: boolean = true;
    // TODO add permissionservice
    // if(this.PermissionService.checkElements(this.ResourceConstants.EQUIP_REQUESTS_CREATE)){
    //   canSearchFunds = true;
    // }

    return canSearchFunds;
  }

  public haveAlert(): boolean {
    let rc: boolean = false;

    if (this.financeDashboardService.negativeTargets > 0) {
      rc = true;
    }
    return rc;
  }

  public haveExpiringFund(): boolean {
    let rc: boolean = false;

    if (this.financeDashboardService.expiringFunds > 0) {
      rc = true;
    }
    return rc;
  }

  public haveNegativeTarget(): boolean {
    let rc: boolean = false;

    if (this.financeDashboardService.negativeTargets > 0) {
      rc = true;
    }
    return rc;
  }

  public gotoFundingSearch() {
    this.navigationService.navigateTo(RouteConstants.FINANCE_FUNDING_SEARCH);
  }

  public gotoMyApropriations() {
    this.navigationService.navigateTo(RouteConstants.FINANCE_FUNDING_SOURCE_SEARCH);
  }

  public gotoRefDataSearch() {
    this.navigationService.navigateTo(RouteConstants.FINANCE_REF_DATA_SEARCH);
  }
}
