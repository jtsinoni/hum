import {NgModule} from '@angular/core';
import {FinanceStates} from './finance-states';
import {StateNavigationService} from '@lc-services/*';
import {RootModule, UIRouterModule} from '@uirouter/angular';

const financeRoutes: RootModule = {
  states: FinanceStates
};

@NgModule({
  imports: [UIRouterModule.forChild(financeRoutes)],
  exports: [UIRouterModule],
  providers: [
    StateNavigationService
  ]
})
export class FinanceRoutingModule {
}
