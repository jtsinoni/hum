import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { FinanceComponent } from './finance.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { PipesModule } from '../../pipes/pipes.module';
import { HttpTestModule } from '../../common-components/test/http-test.module';
import { ToastrModule } from 'ngx-toastr';
import {NavigationTestModule} from '../../common-components/test/navigation-test/navigation-test.module';
import {FormsModule} from '@angular/forms';
import { FinanceDashboardService } from './services/finance-dashboard.service';
import {FinanceAdminService} from './services/finance-admin.service';
import {FinanceAdminApiService} from './services/finance-admin-api.service';
import {FinanceAdminServiceMock} from './services/finance-admin.service.mock';
import {FinanceAdminApiServiceMock} from './services/finance-admin-api.service.mock';

describe('FinanceComponent', () => {
  let component: FinanceComponent;
  let fixture: ComponentFixture<FinanceComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [NavigationTestModule.forRoot(), FormsModule,
       PipesModule, HttpTestModule.forRoot(), ToastrModule.forRoot()],
      declarations: [ FinanceComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [FinanceDashboardService,
        {provide: FinanceAdminService, useClass: FinanceAdminServiceMock},
        {provide: FinanceAdminApiService, useClass: FinanceAdminApiServiceMock}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
