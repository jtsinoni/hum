import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';

import {HomeComponent} from './home.component';
import {HomeHeaderComponent} from './home-header/home-header.component';
import {HomeFooterComponent} from './home-footer/home-footer.component';
import {AuthenticationService, LoggerService, LoginService, NotificationService, ProfileApiService, ProfileService, StateNavigationService} from '@lc-services/*';
import {PipesModule} from '../pipes/pipes.module';
import {BreadcrumbComponent} from './home-header/breadcrumb.component';
import {MainNavService} from './main-nav/main-nav.service';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {ProfileApiServiceMock} from '../services/core/profile-api.service.mock';
import {MainNavServiceMock} from './main-nav/main-nav.service.mock';
import {LoginServiceMock} from '../services/core/login.service.mock';
import {ProfileServiceMock} from '../services/core/profile.service.mock';
import {HelpCenterService} from './help/help-center/help-center.service';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {UIRouterModule} from '@uirouter/angular';
import {ApplicationNotificationService} from '../services/application-notification-service';
import {ApplicationNotificationServiceMock} from '../services/application-notification.service.mock';
import {HelpCenterServiceMock} from './help/help-center/help-center.service.mock';
import {NotificationServiceMock} from '../services/core/notification.service.mock';
import {StateNavigationServiceMock} from '../services/state-navigation.service.mock';
import {BreadcrumbService} from '../services/breadcrumb.service';
import {PermissionService} from '../services/permission.service';
import {PermissionServiceMock} from '../services/permission.service.mock';
import {UtilService} from '../services/util.service';
import {UtilServiceMock} from '../services/util.service.mock';
import {FilterOnPipe} from '../pipes/filter-on.pipe';
import {HttpTestModule} from '@lc-test-modules';
import {AuthenticationServiceMock} from '../services/core/authentication.service.mock';
import {LoaderService} from '../services/loader.service';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let loggerService: LoggerService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule, PipesModule, UIRouterModule.forRoot(), HttpTestModule],
      declarations: [HomeComponent, HomeHeaderComponent, HomeFooterComponent, BreadcrumbComponent],
      providers: [
        LoggerService,
        BreadcrumbService,
        FilterOnPipe,
        LoaderService,
        {provide: ApplicationNotificationService, useClass: ApplicationNotificationServiceMock},
        {provide: NotificationService, useClass: NotificationServiceMock},
        {provide: ProfileApiService, useClass: ProfileApiServiceMock},
        {provide: MainNavService, useClass: MainNavServiceMock},
        {provide: LoginService, useClass: LoginServiceMock},
        {provide: PermissionService, useClass: PermissionServiceMock},
        {provide: ProfileService, useClass: ProfileServiceMock},
        {provide: HelpCenterService, useClass: HelpCenterServiceMock},
        {provide: StateNavigationService, useClass: StateNavigationServiceMock},
        {provide: UtilService, useClass: UtilServiceMock},
        {provide: AuthenticationService, useClass: AuthenticationServiceMock }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have no a11y violations', waitForAsync(() => {
    a11yTests(fixture.nativeElement)
      .then((results) => {
        expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
      })
      .catch((error) => {
        loggerService.error(`${error}`);
      });
  }));
});
