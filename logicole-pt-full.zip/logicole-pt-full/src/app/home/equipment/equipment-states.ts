import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {EquipmentComponent} from './equipment.component';
import {EquipmentRecordsSearchComponent} from './equipment-records/views/equipment-records-search/equipment-records-search.component';
import {EquipmentRecordDetailsComponent} from './equipment-records/views/equipment-record-details/equipment-record-details.component';
import {RequestsComponent} from './equipment-requests/views/requests/requests.component';
import {RequestComponent} from './equipment-requests/views/request/request.component';
import {PrintRequestComponent} from './equipment-requests/views/print-request/print-request.component';
import {EquipmentRequestPrioritizationComponent} from './equipment-request-prioritization/equipment-request-prioritization.component';
import {EquipmentMilitaryStandard1691DetailsComponent} from './equipment-requests/components/request-content/military-standard-1691-details/equipment-military-standard-1691-details.component';

export const EQUIPMENT_ROOT: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_ROOT.url,
  name: RouteConstants.EQUIPMENT_ROOT.name,
  component: EquipmentComponent,
  data: {'route': RouteConstants.EQUIPMENT_ROOT}
};

export const EQUIPMENT_REQUESTS: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_REQUESTS.url,
  name: RouteConstants.EQUIPMENT_REQUESTS.name,
  component: RequestsComponent,
  data: {'route': RouteConstants.EQUIPMENT_REQUESTS}
};

export const EQUIPMENT_REQUEST: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_REQUEST.url,
  name: RouteConstants.EQUIPMENT_REQUEST.name,
  component: RequestComponent,
  data: {'route': RouteConstants.EQUIPMENT_REQUEST},
  params: { 'referer': null }
};

export const EQUIPMENT_REQUEST_1691_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_REQUEST_1691_DETAILS.url,
  name: RouteConstants.EQUIPMENT_REQUEST_1691_DETAILS.name,
  component: EquipmentMilitaryStandard1691DetailsComponent,
  data: {'route': RouteConstants.EQUIPMENT_REQUEST_1691_DETAILS},
  params: {
    'jsn': null
  }
};

export const EQUIPMENT_PRIORITIZATION: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_PRIORITIZATION.url,
  name: RouteConstants.EQUIPMENT_PRIORITIZATION.name,
  component: EquipmentRequestPrioritizationComponent,
  data: {'route': RouteConstants.EQUIPMENT_PRIORITIZATION}
};

export const EQUIPMENT_REQUEST_PRINT: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_REQUEST_PRINT.url,
  name: RouteConstants.EQUIPMENT_REQUEST_PRINT.name,
  component: PrintRequestComponent,
  data: {'route': RouteConstants.EQUIPMENT_REQUEST_PRINT}
};

export const EQUIPMENT_RECORDS: Ng2StateDeclaration = {
  url: RouteConstants.DMLSS_EQUIPMENT_RECORDS.url,
  name: RouteConstants.DMLSS_EQUIPMENT_RECORDS.name,
  component: EquipmentRecordsSearchComponent,
  data: {'route': RouteConstants.DMLSS_EQUIPMENT_RECORDS}
};

export const EQUIPMENT_RECORD_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.EQUIPMENT_RECORD_DETAILS.url,
  name: RouteConstants.EQUIPMENT_RECORD_DETAILS.name,
  component: EquipmentRecordDetailsComponent,
  data: {'route': RouteConstants.EQUIPMENT_RECORD_DETAILS},
  params: {'dodaac': null, 'meId': null}
};

export const EquipmentStates: Ng2StateDeclaration[] = [
  EQUIPMENT_ROOT,
  EQUIPMENT_REQUESTS,
  EQUIPMENT_REQUEST,
  EQUIPMENT_REQUEST_1691_DETAILS,
  EQUIPMENT_PRIORITIZATION,
  EQUIPMENT_REQUEST_PRINT,
  EQUIPMENT_RECORDS,
  EQUIPMENT_RECORD_DETAILS
];
