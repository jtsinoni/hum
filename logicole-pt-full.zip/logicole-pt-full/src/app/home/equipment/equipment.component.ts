import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-equipment',
  templateUrl: './equipment.component.html'
})
export class EquipmentComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
