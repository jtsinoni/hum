import {RootModule, UIRouterModule} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {NgModule} from '@angular/core';
import {EquipmentStates} from './equipment-states';

const equipmentRoutes: RootModule = {
  states: EquipmentStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(equipmentRoutes)],
  exports: [UIRouterModule],
})
export class EquipmentRoutingModule {
}
