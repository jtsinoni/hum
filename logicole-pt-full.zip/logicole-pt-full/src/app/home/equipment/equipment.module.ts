import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {EquipmentComponent} from './equipment.component';
import {EquipmentRoutingModule} from './equipment-routing.module';
import {CommonComponentsModule} from '@lc-common-components';
import {FormsModule} from '@angular/forms';
import {PipesModule} from '../../pipes/pipes.module';
import {DirectivesModule} from '../../directives/directives.module';
import {RequestApiService} from './equipment-requests/services/request-api.service';
import {RequestService} from './equipment-requests/services/request.service';
import {PaginationModule} from 'ngx-bootstrap/pagination';
import {TooltipModule} from 'ngx-bootstrap/tooltip';
import {AcquisitionCostFilterComponent} from './equipment-records/components/acquisition-cost-filter/acquisition-cost-filter.component';
import {ApprovalComponent} from './equipment-records/components/approval/approval.component';
import {EquipmentRecordsSearchComponent} from './equipment-records/views/equipment-records-search/equipment-records-search.component';
import {EquipmentRecordDetailsComponent} from './equipment-records/views/equipment-record-details/equipment-record-details.component';
import {DetailsPaginationComponent} from './equipment-records/components/details-pagination/details-pagination.component';
import {ComponentsComponent} from './equipment-records/components/components/components.component';
import {EquipmentStatusFilterComponent} from './equipment-records/components/equipment-status-filter/equipment-status-filter.component';
import {EquipmentViewFilterComponent} from './equipment-records/components/equipment-view-filter/equipment-view-filter.component';
import {LocationComponent} from './equipment-records/components/location/location.component';
import {MainComponent} from './equipment-records/components/main/main.component';
import {MaintenanceCostComponent} from './equipment-records/components/maintenance-cost/maintenance-cost.component';
import {MaintenanceDataComponent} from './equipment-records/components/maintenance-data/maintenance-data.component';
import {NetworkComponent} from './equipment-records/components/network/network.component';
import {NotesComponent} from './equipment-records/components/notes/notes.component';
import {SoftwareComponent} from './equipment-records/components/software/software.component';
import {EquipmentRecordPaginationService} from './equipment-records/services/equipment-record-pagination.service';
import {EquipmentRecordSearchService} from './equipment-records/services/equipment-record-search.service';
import {EquipmentRecordService} from './equipment-records/services/equipment-record.service';
import {NotesAttachmentsButtonsComponent} from './equipment-requests/components/notes-attachments-buttons/notes-attachments-buttons.component';
import {RequestContentComponent} from './equipment-requests/components/request-content/request-content.component';
import {CompAccSupComponent} from './equipment-requests/components/request-content/comp-acc-sup/comp-acc-sup.component';
import {CompAccSupReadonlyComponent} from './equipment-requests/components/request-content/comp-acc-sup-readonly/comp-acc-sup-readonly.component';
import {CustomerInfoComponent} from './equipment-requests/components/request-content/customer-info/customer-info.component';
import {CustomerInfoReadonlyComponent} from './equipment-requests/components/request-content/customer-info-readonly/customer-info-readonly.component';
import {EquipmentInfoComponent} from './equipment-requests/components/request-content/equipment-info/equipment-info.component';
import {RequestInfoComponent} from './equipment-requests/components/request-content/request-info/request-info.component';
import {RequestInfoReadonlyComponent} from './equipment-requests/components/request-content/request-info-readonly/request-info-readonly.component';
import {SuggestedSourceComponent} from './equipment-requests/components/request-content/suggested-source/suggested-source.component';
import {SuggestedSourceReadonlyComponent} from './equipment-requests/components/request-content/suggested-source-readonly/suggested-source-readonly.component';
import {TrainingComponent} from './equipment-requests/components/request-content/training/training.component';
import {TrainingReadonlyComponent} from './equipment-requests/components/request-content/training-readonly/training-readonly.component';
import {EquipmentInfoReadonlyComponent} from './equipment-requests/components/request-content/equipment-info-readonly/equipment-info-readonly.component';
import {SourceAdditionalInfoComponent} from './equipment-requests/components/request-content/suggested-source/source-additional-info/source-additional-info.component';
import {FacilitiesContentComponent} from './equipment-requests/components/facilities-content/facilities-content.component';
import {MaintenanceContentComponent} from './equipment-requests/components/maintenance-content/maintenance-content.component';
import {SafetyContentComponent} from './equipment-requests/components/safety-content/safety-content.component';
import {TechnologyContentComponent} from './equipment-requests/components/technology-content/technology-content.component';
import {RequestsComponent} from './equipment-requests/views/requests/requests.component';
import {RequestComponent} from './equipment-requests/views/request/request.component';
import {FacilitiesContentReadonlyComponent} from './equipment-requests/components/facilities-content-readonly/facilities-content-readonly.component';
import {MaintenanceContentReadonlyComponent} from './equipment-requests/components/maintenance-content-readonly/maintenance-content-readonly.component';
import {SafetyContentReadonlyComponent} from './equipment-requests/components/safety-content-readonly/safety-content-readonly.component';
import {TechnologyContentReadonlyComponent} from './equipment-requests/components/technology-content-readonly/technology-content-readonly.component';
import {ManageContentComponent} from './equipment-requests/components/manage-content/manage-content.component';
import {ReviewCommentsComponent} from './equipment-requests/components/review-comments/review-comments.component';
import {ReviewSubmitButtonsComponent} from './equipment-requests/components/review-submit-buttons/review-submit-buttons.component';
import {ReviewStatusResultLabelComponent} from './equipment-requests/components/review-status-result-label/review-status-result-label.component';
import {PrintRequestComponent} from './equipment-requests/views/print-request/print-request.component';
import {CatalogContentComponent} from './equipment-requests/components/catalog-content/catalog-content.component';
import {PrintNotesComponent} from './equipment-requests/components/print-notes/print-notes.component';
import {EquipmentRequestPrioritizationComponent} from './equipment-request-prioritization/equipment-request-prioritization.component';
import {EquipmentRequestPrioritizationService} from './equipment-request-prioritization/services/equipment-request-prioritization.service';
import {EquipmentRequestPrioritizationApiService} from './equipment-request-prioritization/services/equipment-request-prioritization-api.service';
import {DragDropModule} from '@angular/cdk/drag-drop';
import {PrioritizationTotalCostPipe} from './equipment-request-prioritization/services/request-prioritization-total-cost.pipe';
import {EquipmentMilitaryStandard1691DetailsComponent} from './equipment-requests/components/request-content/military-standard-1691-details/equipment-military-standard-1691-details.component';
import { AcquisitionContentReviewComponent } from './equipment-requests/components/acquisition-content-review/acquisition-content-review.component';
import {AcquisitionContentComponent} from './equipment-requests/components/acquisition-content/acquisition-content.component';

@NgModule({
  imports: [
    CommonModule,
    CommonComponentsModule.forRoot(),
    DirectivesModule,
    FormsModule,
    PaginationModule.forRoot(),
    PipesModule.forRoot(),
    TooltipModule.forRoot(),
    EquipmentRoutingModule,
    DragDropModule
  ],
  declarations: [
    EquipmentComponent,
    AcquisitionCostFilterComponent,
    ApprovalComponent,
    ComponentsComponent,
    DetailsPaginationComponent,
    EquipmentRecordsSearchComponent,
    EquipmentRecordDetailsComponent,
    EquipmentStatusFilterComponent,
    EquipmentViewFilterComponent,
    LocationComponent,
    MainComponent,
    MaintenanceCostComponent,
    MaintenanceDataComponent,
    NetworkComponent,
    NotesComponent,
    SoftwareComponent,
    RequestsComponent,
    RequestComponent,
    EquipmentMilitaryStandard1691DetailsComponent,
    NotesAttachmentsButtonsComponent,
    RequestContentComponent,
    CompAccSupComponent,
    CompAccSupReadonlyComponent,
    CustomerInfoComponent,
    CustomerInfoReadonlyComponent,
    EquipmentInfoComponent,
    RequestInfoComponent,
    RequestInfoReadonlyComponent,
    SuggestedSourceComponent,
    SuggestedSourceReadonlyComponent,
    TrainingComponent,
    TrainingReadonlyComponent,
    EquipmentInfoReadonlyComponent,
    SourceAdditionalInfoComponent,
    FacilitiesContentComponent,
    MaintenanceContentComponent,
    SafetyContentComponent,
    TechnologyContentComponent,
    FacilitiesContentReadonlyComponent,
    MaintenanceContentReadonlyComponent,
    SafetyContentReadonlyComponent,
    TechnologyContentReadonlyComponent,
    ManageContentComponent,
    ReviewCommentsComponent,
    ReviewSubmitButtonsComponent,
    ReviewStatusResultLabelComponent,
    PrintRequestComponent,
    CatalogContentComponent,
    PrintNotesComponent,
    EquipmentRequestPrioritizationComponent,
    PrioritizationTotalCostPipe,
    AcquisitionContentComponent,
    AcquisitionContentReviewComponent
  ],
  providers: [
    EquipmentRecordPaginationService,
    EquipmentRecordSearchService,
    EquipmentRecordService,
    RequestApiService,
    RequestService,
    EquipmentRequestPrioritizationApiService,
    EquipmentRequestPrioritizationService,
    PrioritizationTotalCostPipe
  ]
})
export class EquipmentModule {
}
