import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {CommonComponentsModule} from '@lc-common-components';
import {ServicesModule} from '../../services/services.module';
import {SlepComponent} from './slep.component';
import {SlepRoutingModule} from './slep-routing.module';
import {LcSlepModalComponent} from './components/lc-slep-modal/lc-slep-modal.component';
import {SlepApiService} from './services/slep-api.service';
import {SlepNsnStatusService} from './services/slep-nsn-status.service';
import {SlepUnsavedChangesService} from './services/slep-unsaved-changes.service';

@NgModule({
  imports: [
    CommonComponentsModule.forRoot(),
    CommonModule,
    FormsModule,
    ServicesModule,
    SlepRoutingModule
  ],
  declarations: [
    SlepComponent,
    LcSlepModalComponent
  ],
  exports: [
    SlepComponent,
    LcSlepModalComponent
  ],
  providers: [
    SlepNsnStatusService,
    SlepApiService,
    SlepUnsavedChangesService
  ],
  entryComponents: [LcSlepModalComponent]
})
export class SlepModule {
}
