import {Component, OnInit} from '@angular/core';
import {SlepApiService} from './services/slep-api.service';

@Component({
  selector: 'app-slep',
  templateUrl: './slep.component.html'
})
export class SlepComponent implements OnInit {

  constructor(private slepApiService: SlepApiService) {
  }

  public ngOnInit() {
    // Load static lists of data that we use throughout SLEP
    this.slepApiService.getStaticSlepDataLists();
  }

}
