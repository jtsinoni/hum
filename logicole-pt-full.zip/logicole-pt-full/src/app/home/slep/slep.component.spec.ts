import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';

import {SlepComponent} from './slep.component';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {a11yTests, prettyPrintA11Y} from '@lc-a11y/*';
import {LoggerService} from '@lc-services/*';
import {SlepApiService} from './services/slep-api.service';
import {SlepApiMockService} from './services/slep-api-mock.service';

describe('SlepComponent', () => {
  let component: SlepComponent;
  let fixture: ComponentFixture<SlepComponent>;
  let loggerService: LoggerService;
  let originalTimeout;

  beforeEach(function () {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;
  });

  afterEach(function () {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        SlepComponent
      ],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        LoggerService,
        {provide: SlepApiService, useClass: SlepApiMockService}
      ]
    });
    loggerService = TestBed.inject(LoggerService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SlepComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Accessibility Tests', () => {
    it('should have no a11y violations', waitForAsync(() => {
      a11yTests(fixture.nativeElement)
        .then((results) => {
          expect(results.violations.length).toBe(0, `${prettyPrintA11Y(results.violations)}`);
        })
        .catch((error) => {
          loggerService.error(`${error}`);
        });
    }));
  });
});
