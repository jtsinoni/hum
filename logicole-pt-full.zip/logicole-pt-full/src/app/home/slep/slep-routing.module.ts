import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';

import {SlepStates} from './slep-states';

const slepRoutes: RootModule = {
  states: SlepStates
};

@NgModule({
  imports: [
    UIRouterModule.forChild(slepRoutes)
  ],
  exports: [
    UIRouterModule
  ],
})
export class SlepRoutingModule {
}
