import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from 'app/constants/route.constants';
import {SlepComponent} from 'app/home/slep/slep.component';

export const SLEP: Ng2StateDeclaration = {
  url: RouteConstants.SLEP_ROOT.url,
  name: RouteConstants.SLEP_ROOT.name,
  component: SlepComponent,
  data: {'route': RouteConstants.SLEP_ROOT}
};
export const SLEP_ACCESS_CONTROL_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.SLEP_ACCESS_CONTROL.name + '.**',
  url: RouteConstants.SLEP_ACCESS_CONTROL.url,
  loadChildren: () => import('app/home/slep/access-control/access-control.module').then(m => m.AccessControlModule)
};
export const SLEP_INVENTORY_MANAGEMENT_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.SLEP_INVENTORY_MANAGEMENT.name + '.**',
  url: RouteConstants.SLEP_INVENTORY_MANAGEMENT.url,
  loadChildren: () => import('app/home/slep/inventory-management/inventory-management.module').then(m => m.InventoryManagementModule)
};
export const SLEP_LOT_MANAGEMENT_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.SLEP_LOT_MANAGEMENT.name + '.**',
  url: RouteConstants.SLEP_LOT_MANAGEMENT.url,
  loadChildren: () => import('app/home/slep/lot-management/lot-management.module').then(m => m.LotManagementModule)
};
export const SLEP_PROJECT_MANAGEMENT_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.SLEP_PROJECT_MANAGEMENT.name + '.**',
  url: RouteConstants.SLEP_PROJECT_MANAGEMENT.url,
  loadChildren: () => import('app/home/slep/project-management/project-management.module').then(m => m.ProjectManagementModule)
};
export const SLEP_NSN_MANAGEMENT_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.SLEP_NSN_MANAGEMENT.name + '.**',
  url: RouteConstants.SLEP_NSN_MANAGEMENT.url,
  loadChildren: () => import('app/home/slep/nsn-management/nsn-management.module').then(m => m.NsnManagementModule)
};
export const SLEP_SITE_MANAGEMENT_MODULE: Ng2StateDeclaration = {
  name: RouteConstants.SLEP_SITE_MANAGEMENT.name + '.**',
  url: RouteConstants.SLEP_SITE_MANAGEMENT.url,
  loadChildren: () => import('app/home/slep/site-management/site-management.module').then(m => m.SiteManagementModule)
};

export const SlepStates: Ng2StateDeclaration[] = [
  SLEP,
  SLEP_ACCESS_CONTROL_MODULE,
  SLEP_INVENTORY_MANAGEMENT_MODULE,
  SLEP_LOT_MANAGEMENT_MODULE,
  SLEP_PROJECT_MANAGEMENT_MODULE,
  SLEP_NSN_MANAGEMENT_MODULE,
  SLEP_SITE_MANAGEMENT_MODULE
];
