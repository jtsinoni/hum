import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {AbiSearchComponent} from './views/abi-search/abi-search.component';
import {ProductComparisonComponent} from './views/product-comparison/product-comparison.component';
import {ProductDetailsComponent} from './views/product-details/product-details.component';
import {RelatedSiteRecordsComponent} from './views/related-site-records/related-site-records.component';
import {RelatedProductsComponent} from './views/related-products/related-products.component';
import {EquivalentProductsComponent} from './views/equivalent-products/equivalent-products.component';
import {SiteEquipmentComponent} from './views/site-equipment/site-equipment.component';
import {PreferredProductComponent} from './views/preferred-product/preferred-product.component';


export const ABI_SEARCH: Ng2StateDeclaration = {
  url: RouteConstants.ABI_SEARCH.url,
  name: RouteConstants.ABI_SEARCH.name,
  component: AbiSearchComponent,
  data: {'route': RouteConstants.ABI_SEARCH}
};

export const ABI_PRODUCT_COMPARISON: Ng2StateDeclaration = {
  url: RouteConstants.ABI_PRODUCT_COMPARISON.url,
  name: RouteConstants.ABI_PRODUCT_COMPARISON.name,
  component: ProductComparisonComponent,
  data: {'route': RouteConstants.ABI_PRODUCT_COMPARISON}
};

export const ABI_RELATED_SITE_RECORDS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_RELATED_SITE_RECORDS.url,
  name: RouteConstants.ABI_RELATED_SITE_RECORDS.name,
  component: RelatedSiteRecordsComponent,
  data: {'route': RouteConstants.ABI_RELATED_SITE_RECORDS}
};

export const ABI_SITE_EQUIPMENT: Ng2StateDeclaration = {
  url: RouteConstants.ABI_SITE_EQUIPMENT.url,
  name: RouteConstants.ABI_SITE_EQUIPMENT.name,
  component: SiteEquipmentComponent,
  data: {'route': RouteConstants.ABI_SITE_EQUIPMENT}
};

export const ABI_RELATED_PRODUCTS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_RELATED_PRODUCTS.url,
  name: RouteConstants.ABI_RELATED_PRODUCTS.name,
  component: RelatedProductsComponent,
  data: {'route': RouteConstants.ABI_RELATED_PRODUCTS}
};

export const ABI_EQUIVALENT_PRODUCTS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_EQUIVALENT_PRODUCTS.url,
  name: RouteConstants.ABI_EQUIVALENT_PRODUCTS.name,
  component: EquivalentProductsComponent,
  data: {'route': RouteConstants.ABI_EQUIVALENT_PRODUCTS}
};

export const ABI_PRODUCT_DETAILS: Ng2StateDeclaration = {
  url: RouteConstants.ABI_PRODUCT_DETAILS.url,
  name: RouteConstants.ABI_PRODUCT_DETAILS.name,
  component: ProductDetailsComponent,
  data: {'route': RouteConstants.ABI_PRODUCT_DETAILS}
};

export const ABI_PREFERRED_PRODUCT: Ng2StateDeclaration = {
  url: RouteConstants.ABI_PREFERRED_PRODUCT.url,
  name: RouteConstants.ABI_PREFERRED_PRODUCT.name,
  component: PreferredProductComponent,
  data: {'route': RouteConstants.ABI_PREFERRED_PRODUCT}
};



export const AbiSearchStates: Ng2StateDeclaration[] = [
  ABI_SEARCH,
  ABI_PRODUCT_COMPARISON,
  ABI_RELATED_SITE_RECORDS,
  ABI_SITE_EQUIPMENT,
  ABI_RELATED_PRODUCTS,
  ABI_EQUIVALENT_PRODUCTS,
  ABI_PRODUCT_DETAILS,
  ABI_PREFERRED_PRODUCT,

];
