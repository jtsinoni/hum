import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {AbiSearchStates} from './abi-search-states';

const abiRoutes: RootModule = {
  states: AbiSearchStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(abiRoutes)],
  exports: [UIRouterModule]
})
export class AbiSearchRoutingModule {
}
