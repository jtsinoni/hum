import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AbiSearchComponent} from './views/abi-search/abi-search.component';
import {AbiSearchRoutingModule} from './abi-search-routing.module';
import {CommonComponentsModule} from '@lc-common-components';
import {FormsModule} from '@angular/forms';
import {AbiService} from './services/abi.service';
import {PaginationModule} from 'ngx-bootstrap/pagination';
import {TooltipModule} from 'ngx-bootstrap/tooltip';
import {RelatedSitesCellRendererComponent} from './components/related-sites-cell-renderer/related-sites-cell-renderer.component';
import {PreferredProductCellRendererComponent} from './components/preferred-product-cell-renderer/preferred-product-cell-renderer.component';
import {TaxonomyService} from './services/taxonomy.service';
import {ProductDetailsComponent} from './views/product-details/product-details.component';
import {ProductComparisonComponent} from './views/product-comparison/product-comparison.component';
import {AbiProductSelectionService} from './services/abi-product-selection.service';
import {FileManagerService} from '../../services/file-manager.service';
import {RelatedSiteRecordsComponent} from './views/related-site-records/related-site-records.component';
import {RelatedProductsComponent} from './views/related-products/related-products.component';
import {EquivalentProductsComponent} from './views/equivalent-products/equivalent-products.component';
import {SiteEquipmentComponent} from './views/site-equipment/site-equipment.component';
import {PreferredProductComponent} from './views/preferred-product/preferred-product.component';
import {AbiSecondarySearchService} from './services/abi-secondary-search.service';
import {AbiProductApiService} from './services/abi-product-api.service';
import {PipesModule} from '../../pipes/pipes.module';
import {DmlssApiService} from './services/dmlss-api.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    AbiSearchRoutingModule,
    CommonComponentsModule.forRoot(),
    TooltipModule.forRoot(),
    PaginationModule.forRoot(),
    PipesModule.forRoot()
  ],
  declarations: [
    AbiSearchComponent,
    RelatedSitesCellRendererComponent,
    PreferredProductCellRendererComponent,
    ProductComparisonComponent,
    ProductDetailsComponent,
    RelatedSiteRecordsComponent,
    RelatedProductsComponent,
    EquivalentProductsComponent,
    SiteEquipmentComponent,
    PreferredProductComponent,

  ],
  providers: [
    AbiService,
    AbiProductSelectionService,
    AbiSecondarySearchService,
    FileManagerService,
    TaxonomyService,
    AbiProductApiService,

    DmlssApiService
  ]
})
export class AbiSearchModule {
}
