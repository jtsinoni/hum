import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AssemblageManagementComponent} from './assemblage-management.component';
import {AssemblageRoutingModule} from './assemblage-routing.module';
import {CommonComponentsModule} from '@lc-common-components';
import {DirectivesModule} from '../../directives/directives.module';
import {FormsModule} from '@angular/forms';
import {PaginationModule} from 'ngx-bootstrap/pagination';
import {TooltipModule} from 'ngx-bootstrap/tooltip';
import {PipesModule} from '../../pipes/pipes.module';
import {NgSelectModule} from '@ng-select/ng-select';
import {AssemblagesComponent} from './components/assemblage/assemblages.component';
import {AuthoritativeAssemblagesComponent} from './components/authoritative-assemblages/authoritative-assemblages.component';
import {ReferenceDataComponent} from './components/reference-data/reference-data.component';
import {CriticalCodeComponent} from './components/reference-data/critical-code/critical-code.component';
import {CriticalCodeDetailComponent} from './components/reference-data/critical-code/critical-code-detail/critical-code-detail.component';
import {DeferredCodeComponent} from './components/reference-data/deferred-code/deferred-code.component';
import {DeferredCodeDetailComponent} from './components/reference-data/deferred-code/deferred-code-detail/deferred-code-detail.component';
import {AssemblageNewComponent} from './views/assemblage-new/assemblage-new.component';
import {AssemblageHeaderComponent} from './views/assemblage-header/assemblage-header.component';
import {AssemblageDetailsComponent} from './views/assemblage-details/assemblage-details.component';
import {AssemblageAdditionalDetailsComponent} from './components/assemblage-additional-details/assemblage-additional-details.component';
import {AuthoritativeAssemblageHeaderComponent} from './views/authoritative-assemblage-header/authoritative-assemblage-header.component';
import {AuthoritativeAssemblagesAdditionalDetailsComponent} from './components/authoritative-assemblages-additional-details/authoritative-assemblages-additional-details.component';
import {EquipmentReportingCodeComponent} from './components/reference-data/equipment-reporting-code/equipment-reporting-code.component';
import {EquipmentReportingCodeDetailComponent} from './components/reference-data/equipment-reporting-code/equipment-reporting-code-detail/equipment-reporting-code-detail.component';
import {AssemblageItemNewComponent} from './views/assemblage-item-new/assemblage-item-new.component';
import {AssemblageItemsComponent} from './components/assemblage-items/assemblage-items.component';
import {AuthoritativeAssemblageDetailsComponent} from './views/authoritative-assemblage-details/authoritative-assemblage-details.component';
import {SetBuilderComponent} from './views/authoritative-assemblage-set-builder/set-builder/set-builder.component';
import {ViewStagingRecordsComponent} from './views/authoritative-assemblage-set-builder/view-staging-records/view-staging-records.component';
import {MoveRecordsToProductionComponent} from './views/authoritative-assemblage-set-builder/move-records-to-production/move-records-to-production.component';
import {EditStagingRecordComponent} from './views/authoritative-assemblage-set-builder/edit-staging-record/edit-staging-record.component';
import {AuthoritativeAssemblageItemNewComponent} from './views/authoritative-assemblage-item-new/authoritative-assemblage-item-new.component';
import {CommingledCodeComponent} from './components/reference-data/commingled-code/commingled-code.component';
import {CommingledCodeDetailComponent} from './components/reference-data/commingled-code/commingled-code-detail/commingled-code-detail.component';
import {AssemblageAllowanceComponent} from './components/assemblage-allowance/assemblage-allowance.component';
import {AssemblageAllowanceUploadComponent} from './components/assemblage-allowance-upload/assemblage-allowance-upload.component';
import {AssemblageAllowanceUploadCorrectionComponent} from './components/assemblage-allowance-upload-correction/assemblage-allowance-upload-correction.component';
import {AssemblageLocationsComponent } from './components/assemblage-locations/assemblage-locations.component';
import {AssemblageConfigurationComponent} from './views/assemblage-configuration/assemblage-configuration.component';
import {AssemblageInventoryCycleComponent } from './components/assemblage-inventory-cycle/assemblage-inventory-cycle.component';
import {AssemblageItemComponent} from './components/assemblage-item/assemblage-item.component';
import {AssemblageItemRelationshipsComponent} from './components/assemblage-item-relationships/assemblage-item-relationships.component';
import {AssemblageItemRelationshipsEndItemComponent} from './components/assemblage-item-relationships-end-item/assemblage-item-relationships-end-item.component';
import {AssemblageItemRelationshipsSupportItemComponent} from './components/assemblage-item-relationships-support-item/assemblage-item-relationships-support-item.component';
import {AssemblageItemRelationshipsPrimeSubComponent} from './components/assemblage-item-relationships-prime-sub/assemblage-item-relationships-prime-sub.component';
import {AssemblageMassUpdateComponent} from './components/assemblage-mass-update/assemblage-mass-update.component';
import {AssemblageCartComponent} from './views/assemblage-cart/assemblage-cart.component';
import {OrderComponentModule} from '../order/order-component.module';
import {AssemblageReplenishmentComponent} from './views/assemblage-replenishment/assemblage-replenishment.component';
import {AssemblageCatalogItemDetailsComponent} from './views/assemblage-catalog-item-details/assemblage-catalog-item-details.component';
import {AssemblageFundsAssociationComponent} from './components/assemblage-funds-association/assemblage-funds-association.component';
import {AssemblageFundsAssociationManagementComponent} from './components/assemblage-funds-association-managment/assemblage-funds-association-management.component';
import {AssemblageFundViewComponent} from './views/assemblage-fund-view/assemblage-fund-view.component';
import {AssemblageAssetInternalTransferComponent} from './views/assemblage-asset-internal-transfer/assemblage-asset-internal-transfer.component';
import {AssemblageCheckoutComponent} from './views/assemblage-checkout/assemblage-checkout.component';
import {AssemblageCartSummaryComponent} from './views/assemblage-cart-summary/assemblage-cart-summary.component';
import {MissingBuildControlNumberComponent} from './components/assemblage-dashboard/missing-build-control-number/missing-build-control-number.component';
import {UpcomingInventoriesComponent} from './components/assemblage-dashboard/upcoming-inventories/upcoming-inventories.component';
import {MissingInventoryCycleComponent} from './components/assemblage-dashboard/missing-inventory-cycle/missing-inventory-cycle.component';
import { AssemblageShipmentsComponent } from './components/assemblage-shipments/assemblage-shipments.component';
import { AssemblageInShipmentComponent } from './components/assemblage-in-shipment/assemblage-in-shipment.component';
import { AssemblageOutShipmentComponent } from './components/assemblage-out-shipment/assemblage-out-shipment.component';
import {MissingFundComponent} from './components/assemblage-dashboard/missing-fund/missing-fund.component';

@NgModule({
  declarations: [
    AssemblageManagementComponent,
    AssemblagesComponent,
    AuthoritativeAssemblagesComponent,
    ReferenceDataComponent,
    CriticalCodeComponent,
    CriticalCodeDetailComponent,
    DeferredCodeComponent,
    DeferredCodeDetailComponent,
    AssemblageNewComponent,
    AssemblageHeaderComponent,
    AssemblageAdditionalDetailsComponent,
    AssemblageDetailsComponent,
    AuthoritativeAssemblageDetailsComponent,
    AuthoritativeAssemblageHeaderComponent,
    AssemblageItemNewComponent,
    AssemblageItemsComponent,
    AuthoritativeAssemblagesAdditionalDetailsComponent,
    EquipmentReportingCodeComponent,
    EquipmentReportingCodeDetailComponent,
    SetBuilderComponent,
    ViewStagingRecordsComponent,
    MoveRecordsToProductionComponent,
    EditStagingRecordComponent,
    AuthoritativeAssemblageItemNewComponent,
    CommingledCodeComponent,
    CommingledCodeDetailComponent,
    AssemblageAllowanceComponent,
    AssemblageAllowanceUploadComponent,
    AssemblageAllowanceUploadCorrectionComponent,
    AssemblageLocationsComponent,
    AssemblageConfigurationComponent,
    AssemblageReplenishmentComponent,
    AssemblageCatalogItemDetailsComponent,
    AssemblageInventoryCycleComponent,
    AssemblageItemComponent,
    AssemblageItemRelationshipsComponent,
    AssemblageItemRelationshipsPrimeSubComponent,
    AssemblageItemRelationshipsEndItemComponent,
    AssemblageItemRelationshipsSupportItemComponent,
    AssemblageMassUpdateComponent,
    AssemblageCartComponent,
    AssemblageAssetInternalTransferComponent,
    AssemblageFundsAssociationComponent,
    AssemblageFundsAssociationManagementComponent,
    AssemblageFundViewComponent,
    AssemblageCheckoutComponent,
    AssemblageCartSummaryComponent,
    MissingBuildControlNumberComponent,
    UpcomingInventoriesComponent,
    MissingInventoryCycleComponent,
    AssemblageShipmentsComponent,
    AssemblageInShipmentComponent,
    AssemblageOutShipmentComponent,
    MissingFundComponent
  ],
  imports: [
    AssemblageRoutingModule,
    CommonModule,
    CommonComponentsModule.forRoot(),
    PaginationModule.forRoot(),
    PipesModule.forRoot(),
    TooltipModule.forRoot(),
    NgSelectModule,
    DirectivesModule,
    FormsModule,
    OrderComponentModule
  ]
})
export class AssemblageModule { }
