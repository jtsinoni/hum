import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lc-assemblage-management',
  templateUrl: './assemblage-management.component.html'
})
export class AssemblageManagementComponent implements OnInit {

  constructor() { }

  public ngOnInit() {
  }

}
