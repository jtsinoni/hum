import {NgModule} from '@angular/core';
import {RootModule, UIRouterModule} from '@uirouter/angular';
import {RouteConstants} from '@lc-constants/*';
import {AssemblageStates} from './assemblage-states';

const assemblageRoutes: RootModule = {
  states: AssemblageStates,
  useHash: false,
  otherwise: RouteConstants.LOGIN.url
};

@NgModule({
  imports: [UIRouterModule.forChild(assemblageRoutes)],
  exports: [UIRouterModule]
})
export class AssemblageRoutingModule {
}
