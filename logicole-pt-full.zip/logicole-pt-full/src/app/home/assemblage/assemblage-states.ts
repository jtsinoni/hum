import {Ng2StateDeclaration} from '@uirouter/angular';
import {RouteAssemblageConstants} from './constants/route-assemblage.constants';
import {AssemblageManagementComponent} from './assemblage-management.component';
import {AssemblagesComponent} from './components/assemblage/assemblages.component';
import {AuthoritativeAssemblagesComponent} from './components/authoritative-assemblages/authoritative-assemblages.component';
import {ReferenceDataComponent} from './components/reference-data/reference-data.component';
import {CriticalCodeComponent} from './components/reference-data/critical-code/critical-code.component';
import {CommingledCodeComponent} from './components/reference-data/commingled-code/commingled-code.component';
import {DeferredCodeComponent} from './components/reference-data/deferred-code/deferred-code.component';
import {AssemblageNewComponent} from './views/assemblage-new/assemblage-new.component';
import {AssemblageDetailsComponent} from './views/assemblage-details/assemblage-details.component';
import {AssemblageItemNewComponent} from './views/assemblage-item-new/assemblage-item-new.component';
import {EquipmentReportingCodeComponent} from './components/reference-data/equipment-reporting-code/equipment-reporting-code.component';
import {AuthoritativeAssemblageDetailsComponent} from './views/authoritative-assemblage-details/authoritative-assemblage-details.component';
import {SetBuilderComponent} from './views/authoritative-assemblage-set-builder/set-builder/set-builder.component';
import {EditStagingRecordComponent} from './views/authoritative-assemblage-set-builder/edit-staging-record/edit-staging-record.component';
import {MoveRecordsToProductionComponent} from './views/authoritative-assemblage-set-builder/move-records-to-production/move-records-to-production.component';
import {ViewStagingRecordsComponent} from './views/authoritative-assemblage-set-builder/view-staging-records/view-staging-records.component';
import {AuthoritativeAssemblageItemNewComponent} from './views/authoritative-assemblage-item-new/authoritative-assemblage-item-new.component';
import {AssemblageAllowanceComponent} from './components/assemblage-allowance/assemblage-allowance.component';
import {AssemblageAllowanceUploadComponent} from './components/assemblage-allowance-upload/assemblage-allowance-upload.component';
import {AssemblageAllowanceUploadCorrectionComponent} from './components/assemblage-allowance-upload-correction/assemblage-allowance-upload-correction.component';
import {AssemblageMassUpdateComponent} from './components/assemblage-mass-update/assemblage-mass-update.component';
import {AssemblageCartComponent} from './views/assemblage-cart/assemblage-cart.component';
import {AssemblageCatalogItemDetailsComponent} from './views/assemblage-catalog-item-details/assemblage-catalog-item-details.component';
import {AssemblageFundsAssociationManagementComponent} from './components/assemblage-funds-association-managment/assemblage-funds-association-management.component';
import {AssemblageFundViewComponent} from './views/assemblage-fund-view/assemblage-fund-view.component';
import {AssemblageAssetInternalTransferComponent} from './views/assemblage-asset-internal-transfer/assemblage-asset-internal-transfer.component';
import {AssemblageCheckoutComponent} from './views/assemblage-checkout/assemblage-checkout.component';
import {AssemblageCartSummaryComponent} from './views/assemblage-cart-summary/assemblage-cart-summary.component';
import {MissingBuildControlNumberComponent} from './components/assemblage-dashboard/missing-build-control-number/missing-build-control-number.component';
import {MissingInventoryCycleComponent} from './components/assemblage-dashboard/missing-inventory-cycle/missing-inventory-cycle.component';
import {UpcomingInventoriesComponent} from './components/assemblage-dashboard/upcoming-inventories/upcoming-inventories.component';
import {AssemblageShipmentsComponent} from './components/assemblage-shipments/assemblage-shipments.component';
import {MissingFundComponent} from './components/assemblage-dashboard/missing-fund/missing-fund.component';

export const ASSEMBLAGE_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_MANAGEMENT.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_MANAGEMENT.name,
  abstract: true,
  component: AssemblageManagementComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_MANAGEMENT}
};

export const AUTHORITATIVE_ASSEMBLAGES: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.AUTHORITATIVE_ASSEMBLAGES.url,
  name: RouteAssemblageConstants.AUTHORITATIVE_ASSEMBLAGES.name,
  abstract: false,
  component: AuthoritativeAssemblagesComponent,
  data: {'route': RouteAssemblageConstants.AUTHORITATIVE_ASSEMBLAGES}
};

export const ASSEMBLAGES: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGES.url,
  name: RouteAssemblageConstants.ASSEMBLAGES.name,
  abstract: false,
  component: AssemblagesComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGES}
};

export const ASSEMBLAGE_ALLOWANCE: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_ALLOWANCE.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_ALLOWANCE.name,
  component: AssemblageAllowanceComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_ALLOWANCE}
};
export const ASSEMBLAGE_ALLOWANCE_UPLOAD: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_ALLOWANCE_UPLOAD.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_ALLOWANCE_UPLOAD.name,
  component: AssemblageAllowanceUploadComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_ALLOWANCE_UPLOAD}
};
export const ASSEMBLAGE_ALLOWANCE_UPLOAD_CORRECTION: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_ALLOWANCE_UPLOAD_CORRECTION.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_ALLOWANCE_UPLOAD_CORRECTION.name,
  abstract: false,
  component: AssemblageAllowanceUploadCorrectionComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_ALLOWANCE_UPLOAD_CORRECTION},
  params: {
    'allowanceImport': null,
    'allowanceItemImport': null
  }
};

export const ASSEMBLAGE_SHIPMENTS: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_SHIPMENTS.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_SHIPMENTS.name,
  component: AssemblageShipmentsComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_SHIPMENTS}
};

export const ASSEMBLAGE_MASS_UPDATE: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_MASS_UPDATE.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_MASS_UPDATE.name,
  component: AssemblageMassUpdateComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_MASS_UPDATE}
};

export const ASSEMBLAGE_REFERENCE_DATA: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_REFERENCE_DATA.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_REFERENCE_DATA.name,
  component: ReferenceDataComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_REFERENCE_DATA}
};
export const ASSEMBLAGE_CRITICAL_CODE: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_CRITICAL_CODE.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_CRITICAL_CODE.name,
  component: CriticalCodeComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_CRITICAL_CODE}
};
export const ASSEMBLAGE_DEFERRED_CODE: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_DEFERRED_CODE.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_DEFERRED_CODE.name,
  component: DeferredCodeComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_DEFERRED_CODE}
};

export const ASSEMBLAGES_NEW: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGES_NEW.url,
  name: RouteAssemblageConstants.ASSEMBLAGES_NEW.name,
  abstract: false,
  component: AssemblageNewComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGES_NEW}
};

export const ASSEMBLAGE_ITEM_NEW: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_ITEM_NEW.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_ITEM_NEW.name,
  abstract: false,
  component: AssemblageItemNewComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_ITEM_NEW},
  params: {
    'assemblage': null
  }
};

export const ASSEMBLAGE_DETAILS: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_DETAILS.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_DETAILS.name,
  component: AssemblageDetailsComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_DETAILS},
  params: {
    'id': null,
    'assemblage': null,
    'activeTab': null
  }
};

export const ASSEMBLAGE_CATALOG_ITEM_DETAILS: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_CATALOG_ITEM_DETAILS.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_CATALOG_ITEM_DETAILS.name,
  component: AssemblageCatalogItemDetailsComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_CATALOG_ITEM_DETAILS},
  params: {
    'display': null
  }
};

export const ASSEMBLAGE_ASSET_INTERNAL_TRANSFER: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_ASSET_INTERNAL_TRANSFER.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_ASSET_INTERNAL_TRANSFER.name,
  component: AssemblageAssetInternalTransferComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_ASSET_INTERNAL_TRANSFER}
};

export const AUTHORITATIVE_ASSEMBLAGE_DETAILS: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.AUTHORITATIVE_ASSEMBLAGE_DETAILS.url,
  name: RouteAssemblageConstants.AUTHORITATIVE_ASSEMBLAGE_DETAILS.name,
  component: AuthoritativeAssemblageDetailsComponent,
  data: {'route': RouteAssemblageConstants.AUTHORITATIVE_ASSEMBLAGE_DETAILS},
  params: {
    'id': null,
    'assemblage': null,
  }
};

export const ASSEMBLAGE_EQUIPMENT_REPORTING_CODE: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_EQUIPMENT_REPORTING_CODE.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_EQUIPMENT_REPORTING_CODE.name,
  component: EquipmentReportingCodeComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_EQUIPMENT_REPORTING_CODE}
};

export const SET_BUILDER: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.SET_BUILDER.url,
  name: RouteAssemblageConstants.SET_BUILDER.name,
  abstract: true,
  component: SetBuilderComponent,
  data: {'route': RouteAssemblageConstants.SET_BUILDER}
};

export const VIEW_STAGING_RECORDS: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.VIEW_STAGING_RECORDS.url,
  name: RouteAssemblageConstants.VIEW_STAGING_RECORDS.name,
  component: ViewStagingRecordsComponent,
  data: {'route': RouteAssemblageConstants.VIEW_STAGING_RECORDS}
};

export const MOVE_RECORDS_TO_PRODUCTION: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.MOVE_RECORDS_TO_PRODUCTION.url,
  name: RouteAssemblageConstants.MOVE_RECORDS_TO_PRODUCTION.name,
  component: MoveRecordsToProductionComponent,
  data: {'route': RouteAssemblageConstants.MOVE_RECORDS_TO_PRODUCTION}
};

export const EDIT_STAGING_RECORD: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.EDIT_STAGING_RECORD.url,
  name: RouteAssemblageConstants.EDIT_STAGING_RECORD.name,
  component: EditStagingRecordComponent,
  data: {'route': RouteAssemblageConstants.EDIT_STAGING_RECORD}
};

export const AUTHORITATIVE_ASSEMBLAGE_ITEM_NEW: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.AUTHORITATIVE_ASSEMBLAGE_ITEM_NEW.url,
  name: RouteAssemblageConstants.AUTHORITATIVE_ASSEMBLAGE_ITEM_NEW.name,
  abstract: false,
  component: AuthoritativeAssemblageItemNewComponent,
  data: {'route': RouteAssemblageConstants.AUTHORITATIVE_ASSEMBLAGE_ITEM_NEW},
  params: {
    'product': null,
    'isEdit': false
  }
};

export const ASSEMBLAGE_COMMINGLED_CODE: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_COMMINGLED_CODE.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_COMMINGLED_CODE.name,
  component: CommingledCodeComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_COMMINGLED_CODE}
};

export const ASSEMBLAGE_CART: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_CART.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_CART.name,
  component: AssemblageCartComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_CART}
};

export const ASSEMBLAGE_CART_ITEM_DETAILS: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_CART_ITEM_DETAILS.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_CART_ITEM_DETAILS.name,
  component: AssemblageCatalogItemDetailsComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_CART_ITEM_DETAILS}
};

export const ASSEMBLAGE_CART_CHECKOUT: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_CART_CHECKOUT.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_CART_CHECKOUT.name,
  component: AssemblageCheckoutComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_CART_CHECKOUT}
};

export const ASSEMBLAGE_CART_SUMMARY: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_CART_SUMMARY.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_CART_SUMMARY.name,
  component: AssemblageCartSummaryComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_CART_SUMMARY}
};

export const ASSEMBLAGE_FUND_VIEW: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_FUND_VIEW.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_FUND_VIEW.name,
  abstract: false,
  component: AssemblageFundViewComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_FUND_VIEW},
  params: {'assemblage': null}
};

export const ASSEMBLAGE_FUNDS_ASSOCIATION_MANAGEMENT: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_FUNDS_ASSOCIATION_MANAGEMENT.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_FUNDS_ASSOCIATION_MANAGEMENT.name,
  component: AssemblageFundsAssociationManagementComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_FUNDS_ASSOCIATION_MANAGEMENT}
};

export const ASSEMBLAGE_DASHBOARD_MISSING_BUILD_CONTROL_NUMBER: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_MISSING_BUILD_CONTROL_NUMBER.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_MISSING_BUILD_CONTROL_NUMBER.name,
  component: MissingBuildControlNumberComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_MISSING_BUILD_CONTROL_NUMBER}
};

export const ASSEMBLAGE_DASHBOARD_MISSING_INVENTORY_CYCLE: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_MISSING_INVENTORY_CYCLE.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_MISSING_INVENTORY_CYCLE.name,
  component: MissingInventoryCycleComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_MISSING_INVENTORY_CYCLE}
};

export const ASSEMBLAGE_DASHBOARD_UPCOMING_INVENTORIES: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_UPCOMING_INVENTORIES.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_UPCOMING_INVENTORIES.name,
  component: UpcomingInventoriesComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_UPCOMING_INVENTORIES},
  params: {'dueInTime': 0}
};

export const ASSEMBLAGE_DASHBOARD_MISSING_FUND: Ng2StateDeclaration = {
  url: RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_MISSING_FUND.url,
  name: RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_MISSING_FUND.name,
  component: MissingFundComponent,
  data: {'route': RouteAssemblageConstants.ASSEMBLAGE_DASHBOARD_MISSING_FUND},
  params: {'ownedBy': ''}
};

export const AssemblageStates = [
  ASSEMBLAGE_MANAGEMENT,
  AUTHORITATIVE_ASSEMBLAGES,
  ASSEMBLAGES,
  ASSEMBLAGE_REFERENCE_DATA,
  ASSEMBLAGE_CRITICAL_CODE,
  ASSEMBLAGE_DEFERRED_CODE,
  ASSEMBLAGES_NEW,
  ASSEMBLAGE_DETAILS,
  AUTHORITATIVE_ASSEMBLAGE_DETAILS,
  ASSEMBLAGE_CATALOG_ITEM_DETAILS,
  ASSEMBLAGE_ITEM_NEW,
  ASSEMBLAGE_EQUIPMENT_REPORTING_CODE,
  ASSEMBLAGE_ALLOWANCE,
  ASSEMBLAGE_ALLOWANCE_UPLOAD,
  ASSEMBLAGE_ALLOWANCE_UPLOAD_CORRECTION,
  ASSEMBLAGE_SHIPMENTS,
  ASSEMBLAGE_MASS_UPDATE,
  SET_BUILDER,
  VIEW_STAGING_RECORDS,
  MOVE_RECORDS_TO_PRODUCTION,
  EDIT_STAGING_RECORD,
  AUTHORITATIVE_ASSEMBLAGE_ITEM_NEW,
  ASSEMBLAGE_COMMINGLED_CODE,
  ASSEMBLAGE_CART,
  ASSEMBLAGE_CART_ITEM_DETAILS,
  ASSEMBLAGE_CART_CHECKOUT,
  ASSEMBLAGE_CART_SUMMARY,
  ASSEMBLAGE_ASSET_INTERNAL_TRANSFER,
  ASSEMBLAGE_FUND_VIEW,
  ASSEMBLAGE_FUNDS_ASSOCIATION_MANAGEMENT,
  ASSEMBLAGE_DASHBOARD_MISSING_BUILD_CONTROL_NUMBER,
  ASSEMBLAGE_DASHBOARD_MISSING_INVENTORY_CYCLE,
  ASSEMBLAGE_DASHBOARD_UPCOMING_INVENTORIES,
  ASSEMBLAGE_DASHBOARD_MISSING_FUND
];
