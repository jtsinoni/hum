import {Injector} from '@angular/core';
import {UIRouter} from '@uirouter/angular';
import {RouteConstants, RouteInfo} from './constants/route.constants';
import {BreadcrumbService} from './services/breadcrumb.service';
import {MainNavService} from './home/main-nav/main-nav.service';
import {PermissionService} from './services/permission.service';
import {AuthenticationService, LoggerService} from '@lc-services/*';
import {StorageService} from './services/storage.service';
import {ApiConstants} from '@lc-constants/*';
import {Title} from '@angular/platform-browser';

// Helpful refs:
// https://ui-router.github.io/guide/transitionhooks
// https://ui-router.github.io/guide/transitions

/** UIRouter Config  */
export function uiRouterConfigFn(router: UIRouter, injector: Injector) {

  const preTitle: string = 'LogiCole';

  const authService: AuthenticationService = injector.get(AuthenticationService);
  const permissionService: PermissionService = injector.get(PermissionService);
  const breadcrumbService: BreadcrumbService = injector.get(BreadcrumbService);
  const mainNavService: MainNavService = injector.get(MainNavService);
  const loggerService: LoggerService = injector.get(LoggerService);
  const storageService: StorageService = injector.get(StorageService);
  const titleService: Title = injector.get(Title);

  // If no URL matches, go to the `login` state by default
  router.urlService.rules.otherwise({state: RouteConstants.LOGIN.name});

  router.transitionService.onSuccess({to: 'home.**'}, (transition) => {
    breadcrumbService.setCurrentState(transition.to());
    mainNavService.setCurrentState(transition.to());
    breadcrumbService.setPreviousState(transition.from());
    const routeInfo: RouteInfo = transition.to().data['route'];
    storageService.storeData(ApiConstants.LC_ROUTE_KEY, routeInfo, true);

    let title = '';
    if(mainNavService.currentRouteInfo && mainNavService.currentRouteInfo.breadcrumb){
      title = mainNavService.currentRouteInfo.breadcrumb;
      titleService.setTitle(preTitle + ' - ' + title);
    }
  });

  router.transitionService.onSuccess({to: 'login.**'}, (transition) => {
    titleService.setTitle(preTitle);
  });

  router.transitionService.onStart({to: 'home.**'}, (_) => {
    breadcrumbService.setPreviousState(null);
  });

  router.transitionService.onBefore({}, (transition) => {
    const transitionTo: string = transition.to().name;
    let fn: any;

    if (transition.to().abstract) {
      const name = transition.from().name;
      fn = router.stateService.target(name);
    } else {

      switch (transitionTo) {
        // If login is entered, redirect to loginForm
        case  RouteConstants.LOGIN_ROOT.name:
          fn = router.stateService.target(RouteConstants.LOGIN.name);
          break;
        // If home is entered, redirect to Dashboard
        case RouteConstants.HOME_ROOT.name:
          fn = router.stateService.target(RouteConstants.MY_DASHBOARD.name);
          break;
        // If access is entered, redirect to Dashboard
        case RouteConstants.ACCESS_ROOT.name:
          fn = router.stateService.target(RouteConstants.MY_DASHBOARD.name);
          break;
        // If equipment is entered, redirect to Dashboard
        case RouteConstants.EQUIPMENT_ROOT.name:
          fn = router.stateService.target(RouteConstants.MY_DASHBOARD.name);
          break;
        // If organization is entered, redirect to Dashboard
        case RouteConstants.ORGANIZATION_ROOT.name:
          fn = router.stateService.target(RouteConstants.MY_DASHBOARD.name);
          break;
        // If equipment is entered, redirect to Dashboard
        case RouteConstants.REAL_PROPERTY_ROOT.name:
          fn = router.stateService.target(RouteConstants.MY_DASHBOARD.name);
          break;
        case RouteConstants.HELP_ROOT.name:
          fn = router.stateService.target(RouteConstants.MY_DASHBOARD.name);
          break;
        // If slep is entered, redirect to Dashboard
        case RouteConstants.SLEP_ROOT.name:
          fn = router.stateService.target(RouteConstants.MY_DASHBOARD.name);
          break;
      }

      const doesIncludeHomeState = transitionTo.includes('home.');
      if (doesIncludeHomeState) {

        let goingToState = 'unknown state';
        if (transition.to()) {
          goingToState = transition.to().name;
        }

        // Comment this out to turn state permission check off
        const isAllowed: boolean = permissionService.checkStates(goingToState);
        if (!isAllowed) {
          loggerService.warn(`User profile does not contain state: ${goingToState}`);
          authService.logout();
          fn = router.stateService.target(RouteConstants.LOGIN.name);
        }
      }

    }
    return fn;
  });

  // Use ui-router-visualizer to show the states as a tree
  // and transitions as a timeline
  // visualizer(router);
}
