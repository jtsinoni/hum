// Assumes node and npm are already in place

// Update pom version
mvn versions:set -DnewVersion=1.9.0 versions:commit

// Update environment vars [version] [date in millis]
npm run updateBuild -- 1.9.0 0

// Install/update npm packages
npm install

// Bundle
ng build --prod

// Push to Nexus
mvn deploy -B -f deployment-assemblies/src-assembly/pom.xml